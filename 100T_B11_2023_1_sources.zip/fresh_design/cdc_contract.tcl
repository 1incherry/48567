# Every exception is an explicit synchronizer or stable-data mailbox. No blanket camera/pixel clock groups.
proc required_cells {pattern} {
 set c [get_cells -hier -regexp $pattern]
 if {![llength $c]} {error "CDC_CONTRACT_NO_MATCH $pattern"}
 puts "CDC_CONTRACT_CELLS [llength $c] $pattern"
 return $c
}
proc first_stage {pattern} {
 set c [required_cells $pattern]
 set_false_path -to [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]
}
proc bounded_mailbox {source destination limit skew} {
 set s [required_cells $source];set d [required_cells $destination]
 set_max_delay -datapath_only $limit -from $s -to $d
 set_false_path -hold -from $s -to $d
 set_bus_skew $skew -from $s -to $d
}
# Scalars and immutable one-shot debug records retain the same max/hold bounds.
# Do not represent duplicated flag drivers or constant bits as a bus-skew group.
proc bounded_stable_record {source destination limit} {
 set s [required_cells $source];set d [required_cells $destination]
 set_max_delay -datapath_only $limit -from $s -to $d
 set_false_path -hold -from $s -to $d
}
# Fixed raw camera CRC observation, held between frames (>milliseconds).
first_stage {.*input_crc/toggle_sync_reg\[0\]}
bounded_mailbox {.*input_crc/held_snapshot_reg\[[0-9]+\]} {.*input_crc/data_meta_reg\[[0-9]+\]} 16.0 4.0
# Diagnostic Gray counters are free-running; no multi-bit resets while sampling.
bounded_mailbox {.*pclk_gray_reg\[[0-9]+\]} {.*p1_reg\[[0-9]+\]} 4.0 4.0
bounded_mailbox {.*wr_gray_reg\[[0-9]+\]} {.*w1_reg\[[0-9]+\]} 4.0 4.0
bounded_mailbox {.*rd_gray_reg\[[0-9]+\]} {.*r1_reg\[[0-9]+\]} 4.0 4.0
# PHY/MAC status/control synchronizers; no packet payload exceptions here.
first_stage {.*ethernet/control_rx/(send_sync|ack_sync)_reg\[0\]}
bounded_mailbox {.*ethernet/control_rx/held_header_reg\[[0-9]+\]} {.*ethernet/header_stage/header_reg\[[0-9]+\]} 16.0 4.0
first_stage {.*ethernet/(ds1_reg\[[0-9]+\]|configured_sync_reg\[0\]|profile_sync_reg\[0\])}
first_stage {.*ethernet/u_mac/(rx_prescale_sync|rx_mii_select_sync|tx_mii_select_sync)_reg\[0\]}
# Camera/mailbox toggle/level first stages. Payload is separately bounded below.
first_stage {.*ethernet/camera_source/(result_sync|block_sync|release_ack_sync|ui_idle_sync|req_sync|release_sync|block_req_sync|cam_commit_sync|cam_idle_sync|wrbusy_sync|cam_req_sync|cam_rel_sync|cam_ack_sync)_reg\[0\]}
bounded_mailbox {.*ethernet/camera_source/held_(width|height|epoch)_reg\[[0-9]+\]} {.*ethernet/camera_source/ui_(width|height|epoch)_reg\[[0-9]+\]} 16.0 4.0
bounded_mailbox {.*ethernet/camera_source/held_offset_reg\[[0-9]+\]} {.*ethernet/camera_source/ui_offset_reg\[[0-9]+\]} 16.0 4.0
bounded_mailbox {.*ethernet/camera_source/ui_(width|height|epoch)_reg\[[0-9]+\]} {.*ethernet/camera_source/cam_(width|height|epoch_meta)_reg\[[0-9]+\]} 16.0 4.0
bounded_mailbox {.*ethernet/camera_source/camera_capture/(frame_crc|commit_cancel)_reg(\[[0-9]+\])?} {.*ethernet/camera_source/ui_cam_(crc|cancel)_reg(\[[0-9]+\])?} 16.0 4.0
bounded_mailbox {.*ethernet/camera_source/ui_crc_reg\[[0-9]+\]} {.*ethernet/camera_source/capture_crc_reg\[[0-9]+\]} 16.0 4.0
bounded_stable_record {.*ethernet/camera_source/ui_(error|block_error)_reg} {.*ethernet/camera_source/(capture_error|capture_complete|tx_block_error)_reg} 16.0
# camera_capture.capture_error is unused in this top and optimized away; no live CDC path remains. Store error is published via the bounded UI result mailbox.
# Actual vendor FIFO Gray pointers: each bus paired with its own first stage.
set sources [required_cells {.*pntr_cdc_inst/src_gray_ff_reg\[[0-9]+\]}]
set sources [concat $sources [required_cells {.*ethernet/context_cdc/report_fifo/.*pntr_cdc_dc_inst/src_gray_ff_reg\[[0-9]+\]}]]
set prefixes {}
foreach s $sources {regsub {/src_gray_ff_reg\[[0-9]+\]$} $s {} p;lappend prefixes $p}
foreach prefix [lsort -unique $prefixes] {
 set ss [get_cells -hier -filter "NAME =~ ${prefix}/src_gray_ff_reg*"]
 set dd [get_cells -hier -filter "NAME =~ ${prefix}/dest_graysync_ff_reg*"]
 set first {}
 foreach x $dd {if {[regexp {/dest_graysync_ff_reg\[0\]\[[0-9]+\]$} $x]} {lappend first $x}}
 if {![llength $first]} {error "FIFO_GRAY_FIRST_STAGE_MISSING $prefix"}
 set skew 4.0
 if {[string match *context_cdc/report_fifo/* $prefix]} {
  set expected_width 7
  if {[string match *pntr_cdc_dc_inst $prefix]} {set expected_width 8}
  if {[llength $ss]!=$expected_width||[llength $first]!=$expected_width} {error R12_CONTEXT_ACTUAL_GRAY_WIDTH_MISMATCH}
  set skew 1.0
 }
 set_max_delay -datapath_only 4.0 -from $ss -to $first
 set_false_path -hold -from $ss -to $first
 set_bus_skew $skew -from $ss -to $first
 puts "FIFO_GRAY_BOUNDED $prefix [llength $ss] [llength $first] MAX4 SKEW$skew"
}

first_stage {.*ethernet/rx_config_sync_reg\[0\]}

first_stage {.*ethernet/camera_source/cam_store_error_sync_reg\[0\]}
source [file join $root reset_sync_only.tcl]

# Native FIFO reset synchronizers: asynchronous input reaches only first FF D.
set ff [required_cells {.*capture_fifo/.*xpm_cdc_(single|sync_rst)_inst_[^/]+/syncstages_ff_reg\[0\]}]
if {[llength $ff]!=4} {error FIFO_RESET_FIRST_STAGE_COUNT}
foreach c $ff {if {[string tolower [get_property ASYNC_REG $c]] ni {true 1}} {error FIFO_RESET_NOT_ASYNC_REG}}
set_false_path -to [get_pins -of_objects $ff -filter {REF_PIN_NAME == D}]

# One-shot PHY debug snapshot only: immutable after terminal FSM, capture after 3-stage valid.
first_stage {.*phy_debug_valid_sync_reg\[0\]}
first_stage {.*mig_cal_sync_reg\[0\]}
# Terminal snapshot never changes after debug_valid. Three 50MHz valid stages
# precede capture (>=60ns); all dynamic payload paths still bounded16ns. Four
# optimized constant bits have no launch path, so no fictitious skew endpoints.
bounded_stable_record {.*ethernet/init/debug_snapshot_reg\[[0-9]+\]} {.*phy_debug_local_reg\[[0-9]+\]} 16.0

first_stage {.*ethernet/context_cdc/(ack_sync|request_sync|commit_sync|source_fault_sync|destination_fault_sync|fifo_live_sync)_reg\[0\]}
# R12 architecture change: source_bundle is source-clock local serializer;
# destination_data is destination-clock local FIFO assembly. No direct2048bit
# cross-domain held bus exists, so the R11 6ns/1ns group is removed, not waived
# or reported as passing. Actual XPM32bit async RAM + fouractual Gray groups:
# normal rd/wr7bit and extended rd/wr8bit, all present in actual linked synth.
set context_gray [get_cells -hier -regexp {.*ethernet/context_cdc/report_fifo/.*pntr_cdc(_dc)?_inst/src_gray_ff_reg\[[0-9]+\]}]
if {[llength $context_gray]!=30} {error R12_CONTEXT_FOUR_ACTUAL_GRAY_BUSES_MISSING}
set context_fifo_reset [required_cells {.*ethernet/context_cdc/report_fifo/.*gen_rst_ic[./](wrst_rd_inst|rrst_wr_inst)/syncstages_ff_reg\[0\]}]
if {[llength $context_fifo_reset]!=2} {error R12_CONTEXT_VENDOR_RESET_FIRST_STAGE_COUNT}
foreach c $context_fifo_reset {
 if {[string tolower [get_property ASYNC_REG $c]] ni {true 1}} {error R12_CONTEXT_VENDOR_RESET_NOT_SYNC}
 set_false_path -to [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]
}
first_stage {.*ethernet/context_fault_sync_reg\[0\]}
foreach p {{.*camera_control_release_reg\[[0-2]\]}} {
 set cc [required_cells $p];if {[llength $cc]!=3} {error CAMERA_CONTROL_RESET_COUNT};set_false_path -to [get_pins -of_objects $cc -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
}
foreach p {{.*ethernet/context_rx_release_reg\[[0-2]\]} {.*ethernet/context_cdc/(destination_release|destination_alive)_reg\[[0-2]\]}} {
 set cc [required_cells $p];set_false_path -to [get_pins -of_objects $cc -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
}
foreach {p n} {
 {.*ethernet/context_cdc/fifo_reset_release_reg\[[0-7]\]} 8
 {.*ethernet/context_cdc/(fifo_live_sync|commit_sync|source_fault_sync|destination_fault_sync|ack_sync|request_sync)_reg\[[0-2]\]} 18
} {
 set cc [required_cells $p];if {[llength $cc]!=$n} {error R12_EXPLICIT_RESET_SYNC_COUNT}
 foreach c $cc {
  if {[string tolower [get_property ASYNC_REG $c]] ni {true 1}} {error R12_EXPLICIT_RESET_NOT_SYNC}
  set pp [get_pins -of_objects $c -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
  if {[llength $pp]!=1} {error R12_EXPLICIT_RESET_PIN_COUNT}
  set_false_path -to $pp
 }
}
# A one-bit pending latch captures even a reset while source clock is stopped;
# synchronous clear is accepted only after the eight-stage release pipe. No
# business D path or inter-clock clock-group exception is made here.
set pending [required_cells {.*ethernet/context_cdc/fifo_reset_pending_reg}]
if {[llength $pending]!=1} {error R12_RESET_PENDING_COUNT}
set pp [get_pins -of_objects $pending -filter {REF_PIN_NAME == PRE}]
if {[llength $pp]!=1} {error R12_RESET_PENDING_ASYNC_SET_PIN}
set_false_path -to $pp

# Serial reservation only samples two actual UI resource-empty levels. No data/command bypass.
first_stage {.*ethernet/serial_lock/(bridge_quiet_sync|shared_quiet_sync)_reg\[0\]}
set serial_reset [required_cells {.*ethernet/serial_lock/(bridge_quiet_sync|shared_quiet_sync|memory_alive)_reg\[[0-2]\]}]
if {[llength $serial_reset]!=9} {error SERIAL_RESERVATION_RESET_COUNT}
foreach c $serial_reset {
 if {[string tolower [get_property ASYNC_REG $c]] ni {true 1}} {error SERIAL_RESET_NOT_SYNC}
 set pp [get_pins -of_objects $c -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
 if {[llength $pp]!=1} {error SERIAL_RESET_PIN_COUNT}
 set_false_path -to $pp
}

# Raw replay is a trusted-PC one-shot held TX->UI mailbox. No camera-domain
# exception is needed: replay never arms DVP, and live-camera behavior is kept.
bounded_mailbox {.*ethernet/camera_source/held_replay_reg} {.*ethernet/camera_source/ui_replay_reg} 16.0 4.0
bounded_mailbox {.*ethernet/camera_source/held_replay_crc_reg\[[0-9]+\]} {.*ethernet/camera_source/ui_replay_crc_reg\[[0-9]+\]} 16.0 4.0
