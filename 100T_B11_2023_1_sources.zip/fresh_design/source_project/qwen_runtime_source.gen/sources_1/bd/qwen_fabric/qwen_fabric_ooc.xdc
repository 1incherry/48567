################################################################################

# This XDC is used only for OOC mode of synthesis, implementation
# This constraints file contains default clock frequencies to be used during
# out-of-context flows such as OOC Synthesis and Hierarchical Designs.
# This constraints file is not used in normal top-down synthesis (default flow
# of Vivado)
################################################################################
create_clock -name core_clk -period 8 [get_ports core_clk]
create_clock -name ddr_clk -period 10 [get_ports ddr_clk]
create_clock -name eth_clk125 -period 8 [get_ports eth_clk125]
create_clock -name runtime_clk50 -period 20 [get_ports runtime_clk50]

################################################################################