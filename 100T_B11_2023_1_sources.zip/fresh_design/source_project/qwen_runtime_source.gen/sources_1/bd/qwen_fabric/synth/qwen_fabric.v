//Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
//Copyright 2022-2023 Advanced Micro Devices, Inc. All Rights Reserved.
//--------------------------------------------------------------------------------
//Tool Version: Vivado v.2023.1 (lin64) Build 3865809 Sun May  7 15:04:56 MDT 2023
//Date        : Mon Nov  2 02:14:51 2026
//Host        : zzc running 64-bit Ubuntu 22.04.5 LTS
//Command     : generate_target qwen_fabric.bd
//Design      : qwen_fabric
//Purpose     : IP block netlist
//--------------------------------------------------------------------------------
`timescale 1 ps / 1 ps

(* CORE_GENERATION_INFO = "qwen_fabric,IP_Integrator,{x_ipVendor=xilinx.com,x_ipLibrary=BlockDiagram,x_ipName=qwen_fabric,x_ipVersion=1.00.a,x_ipLanguage=VERILOG,numBlks=6,numReposBlks=6,numNonXlnxBlks=0,numHierBlks=0,maxHierDepth=0,numSysgenBlks=0,numHlsBlks=0,numHdlrefBlks=2,numPkgbdBlks=0,bdsource=USER,synth_mode=Global}" *) (* HW_HANDOFF = "qwen_fabric.hwdef" *) 
module qwen_fabric
   (BOOT_SIDE_AXI_araddr,
    BOOT_SIDE_AXI_arprot,
    BOOT_SIDE_AXI_arready,
    BOOT_SIDE_AXI_arvalid,
    BOOT_SIDE_AXI_awaddr,
    BOOT_SIDE_AXI_awprot,
    BOOT_SIDE_AXI_awready,
    BOOT_SIDE_AXI_awvalid,
    BOOT_SIDE_AXI_bready,
    BOOT_SIDE_AXI_bresp,
    BOOT_SIDE_AXI_bvalid,
    BOOT_SIDE_AXI_rdata,
    BOOT_SIDE_AXI_rready,
    BOOT_SIDE_AXI_rresp,
    BOOT_SIDE_AXI_rvalid,
    BOOT_SIDE_AXI_wdata,
    BOOT_SIDE_AXI_wready,
    BOOT_SIDE_AXI_wstrb,
    BOOT_SIDE_AXI_wvalid,
    DDR_AXI_araddr,
    DDR_AXI_arburst,
    DDR_AXI_arcache,
    DDR_AXI_arlen,
    DDR_AXI_arlock,
    DDR_AXI_arprot,
    DDR_AXI_arqos,
    DDR_AXI_arready,
    DDR_AXI_arsize,
    DDR_AXI_arvalid,
    DDR_AXI_awaddr,
    DDR_AXI_awburst,
    DDR_AXI_awcache,
    DDR_AXI_awlen,
    DDR_AXI_awlock,
    DDR_AXI_awprot,
    DDR_AXI_awqos,
    DDR_AXI_awready,
    DDR_AXI_awsize,
    DDR_AXI_awvalid,
    DDR_AXI_bready,
    DDR_AXI_bresp,
    DDR_AXI_bvalid,
    DDR_AXI_rdata,
    DDR_AXI_rlast,
    DDR_AXI_rready,
    DDR_AXI_rresp,
    DDR_AXI_rvalid,
    DDR_AXI_wdata,
    DDR_AXI_wlast,
    DDR_AXI_wready,
    DDR_AXI_wstrb,
    DDR_AXI_wvalid,
    ETH_AXI_araddr,
    ETH_AXI_arprot,
    ETH_AXI_arready,
    ETH_AXI_arvalid,
    ETH_AXI_awaddr,
    ETH_AXI_awprot,
    ETH_AXI_awready,
    ETH_AXI_awvalid,
    ETH_AXI_bready,
    ETH_AXI_bresp,
    ETH_AXI_bvalid,
    ETH_AXI_rdata,
    ETH_AXI_rready,
    ETH_AXI_rresp,
    ETH_AXI_rvalid,
    ETH_AXI_wdata,
    ETH_AXI_wready,
    ETH_AXI_wstrb,
    ETH_AXI_wvalid,
    RUNTIME_AXI_araddr,
    RUNTIME_AXI_arprot,
    RUNTIME_AXI_arready,
    RUNTIME_AXI_arvalid,
    RUNTIME_AXI_awaddr,
    RUNTIME_AXI_awprot,
    RUNTIME_AXI_awready,
    RUNTIME_AXI_awvalid,
    RUNTIME_AXI_bready,
    RUNTIME_AXI_bresp,
    RUNTIME_AXI_bvalid,
    RUNTIME_AXI_rdata,
    RUNTIME_AXI_rready,
    RUNTIME_AXI_rresp,
    RUNTIME_AXI_rvalid,
    RUNTIME_AXI_wdata,
    RUNTIME_AXI_wready,
    RUNTIME_AXI_wstrb,
    RUNTIME_AXI_wvalid,
    core_clk,
    core_resetn,
    ddr_clk,
    ddr_resetn,
    engine_ready,
    eth_clk125,
    eth_resetn,
    runtime_clk50,
    runtime_resetn,
    sct_drain_ack125,
    sct_drain_fault125,
    sct_freeze_disable,
    sct_freeze_precommit,
    sct_independent_fault100,
    sct_main_active,
    sct_main_closed_ack,
    sct_main_fault,
    sct_main_good,
    sct_main_prepare,
    sct_main_qualified,
    sct_main_ready,
    sct_main_response_consumed,
    sct_main_start,
    sct_other_quiet100,
    sct_qualify_done,
    sct_qualify_fault,
    sct_qualify_good,
    sct_qualify_ready,
    sct_qualify_start,
    sct_release_completion_toggle50,
    sct_release_owned125,
    sct_release_owned50,
    sct_release_permit125,
    sct_side_retire_ack,
    sct_side_retire_req,
    sct_transport_fault100,
    sct_trusted_stop100,
    sct_trusted_stop125,
    token_board_resetn,
    token_bridge_quiet,
    token_camera_completed,
    token_camera_done,
    token_camera_fault,
    token_camera_owner_live,
    token_camera_request,
    token_cpu_ddr_allowed,
    token_cpu_ddr_idle,
    token_cpu_park_ack,
    token_cpu_parked,
    token_guard_fault,
    token_shared_quiet,
    token_unpark_allow,
    transport_resetn,
    uart_rx,
    uart_tx);
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI ARADDR" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME BOOT_SIDE_AXI, ADDR_WIDTH 32, ARUSER_WIDTH 0, AWUSER_WIDTH 0, BUSER_WIDTH 0, CLK_DOMAIN qwen_fabric_eth_clk125, DATA_WIDTH 32, FREQ_HZ 125000000, HAS_BRESP 1, HAS_BURST 0, HAS_CACHE 0, HAS_LOCK 0, HAS_PROT 1, HAS_QOS 0, HAS_REGION 0, HAS_RRESP 1, HAS_WSTRB 1, ID_WIDTH 0, INSERT_VIP 0, MAX_BURST_LENGTH 1, NUM_READ_OUTSTANDING 1, NUM_READ_THREADS 1, NUM_WRITE_OUTSTANDING 1, NUM_WRITE_THREADS 1, PHASE 0.0, PROTOCOL AXI4LITE, READ_WRITE_MODE READ_WRITE, RUSER_BITS_PER_BYTE 0, RUSER_WIDTH 0, SUPPORTS_NARROW_BURST 0, WUSER_BITS_PER_BYTE 0, WUSER_WIDTH 0" *) output [31:0]BOOT_SIDE_AXI_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI ARPROT" *) output [2:0]BOOT_SIDE_AXI_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI ARREADY" *) input BOOT_SIDE_AXI_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI ARVALID" *) output BOOT_SIDE_AXI_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI AWADDR" *) output [31:0]BOOT_SIDE_AXI_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI AWPROT" *) output [2:0]BOOT_SIDE_AXI_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI AWREADY" *) input BOOT_SIDE_AXI_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI AWVALID" *) output BOOT_SIDE_AXI_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI BREADY" *) output BOOT_SIDE_AXI_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI BRESP" *) input [1:0]BOOT_SIDE_AXI_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI BVALID" *) input BOOT_SIDE_AXI_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI RDATA" *) input [31:0]BOOT_SIDE_AXI_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI RREADY" *) output BOOT_SIDE_AXI_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI RRESP" *) input [1:0]BOOT_SIDE_AXI_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI RVALID" *) input BOOT_SIDE_AXI_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI WDATA" *) output [31:0]BOOT_SIDE_AXI_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI WREADY" *) input BOOT_SIDE_AXI_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI WSTRB" *) output [3:0]BOOT_SIDE_AXI_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 BOOT_SIDE_AXI WVALID" *) output BOOT_SIDE_AXI_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARADDR" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME DDR_AXI, ADDR_WIDTH 32, ARUSER_WIDTH 0, AWUSER_WIDTH 0, BUSER_WIDTH 0, CLK_DOMAIN qwen_fabric_ddr_clk, DATA_WIDTH 128, FREQ_HZ 100000000, HAS_BRESP 1, HAS_BURST 1, HAS_CACHE 1, HAS_LOCK 1, HAS_PROT 1, HAS_QOS 1, HAS_REGION 0, HAS_RRESP 1, HAS_WSTRB 1, ID_WIDTH 0, INSERT_VIP 0, MAX_BURST_LENGTH 256, NUM_READ_OUTSTANDING 2, NUM_READ_THREADS 1, NUM_WRITE_OUTSTANDING 2, NUM_WRITE_THREADS 1, PHASE 0.0, PROTOCOL AXI4, READ_WRITE_MODE READ_WRITE, RUSER_BITS_PER_BYTE 0, RUSER_WIDTH 0, SUPPORTS_NARROW_BURST 0, WUSER_BITS_PER_BYTE 0, WUSER_WIDTH 0" *) output [31:0]DDR_AXI_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARBURST" *) output [1:0]DDR_AXI_arburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARCACHE" *) output [3:0]DDR_AXI_arcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARLEN" *) output [7:0]DDR_AXI_arlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARLOCK" *) output [0:0]DDR_AXI_arlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARPROT" *) output [2:0]DDR_AXI_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARQOS" *) output [3:0]DDR_AXI_arqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARREADY" *) input DDR_AXI_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARSIZE" *) output [2:0]DDR_AXI_arsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI ARVALID" *) output DDR_AXI_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWADDR" *) output [31:0]DDR_AXI_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWBURST" *) output [1:0]DDR_AXI_awburst;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWCACHE" *) output [3:0]DDR_AXI_awcache;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWLEN" *) output [7:0]DDR_AXI_awlen;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWLOCK" *) output [0:0]DDR_AXI_awlock;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWPROT" *) output [2:0]DDR_AXI_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWQOS" *) output [3:0]DDR_AXI_awqos;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWREADY" *) input DDR_AXI_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWSIZE" *) output [2:0]DDR_AXI_awsize;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI AWVALID" *) output DDR_AXI_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI BREADY" *) output DDR_AXI_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI BRESP" *) input [1:0]DDR_AXI_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI BVALID" *) input DDR_AXI_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI RDATA" *) input [127:0]DDR_AXI_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI RLAST" *) input DDR_AXI_rlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI RREADY" *) output DDR_AXI_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI RRESP" *) input [1:0]DDR_AXI_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI RVALID" *) input DDR_AXI_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI WDATA" *) output [127:0]DDR_AXI_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI WLAST" *) output DDR_AXI_wlast;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI WREADY" *) input DDR_AXI_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI WSTRB" *) output [15:0]DDR_AXI_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 DDR_AXI WVALID" *) output DDR_AXI_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI ARADDR" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME ETH_AXI, ADDR_WIDTH 32, ARUSER_WIDTH 0, AWUSER_WIDTH 0, BUSER_WIDTH 0, CLK_DOMAIN qwen_fabric_eth_clk125, DATA_WIDTH 32, FREQ_HZ 125000000, HAS_BRESP 1, HAS_BURST 0, HAS_CACHE 0, HAS_LOCK 0, HAS_PROT 1, HAS_QOS 0, HAS_REGION 0, HAS_RRESP 1, HAS_WSTRB 1, ID_WIDTH 0, INSERT_VIP 0, MAX_BURST_LENGTH 1, NUM_READ_OUTSTANDING 2, NUM_READ_THREADS 1, NUM_WRITE_OUTSTANDING 2, NUM_WRITE_THREADS 1, PHASE 0.0, PROTOCOL AXI4LITE, READ_WRITE_MODE READ_WRITE, RUSER_BITS_PER_BYTE 0, RUSER_WIDTH 0, SUPPORTS_NARROW_BURST 0, WUSER_BITS_PER_BYTE 0, WUSER_WIDTH 0" *) output [31:0]ETH_AXI_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI ARPROT" *) output [2:0]ETH_AXI_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI ARREADY" *) input ETH_AXI_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI ARVALID" *) output ETH_AXI_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI AWADDR" *) output [31:0]ETH_AXI_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI AWPROT" *) output [2:0]ETH_AXI_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI AWREADY" *) input ETH_AXI_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI AWVALID" *) output ETH_AXI_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI BREADY" *) output ETH_AXI_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI BRESP" *) input [1:0]ETH_AXI_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI BVALID" *) input ETH_AXI_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI RDATA" *) input [31:0]ETH_AXI_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI RREADY" *) output ETH_AXI_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI RRESP" *) input [1:0]ETH_AXI_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI RVALID" *) input ETH_AXI_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI WDATA" *) output [31:0]ETH_AXI_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI WREADY" *) input ETH_AXI_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI WSTRB" *) output [3:0]ETH_AXI_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 ETH_AXI WVALID" *) output ETH_AXI_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI ARADDR" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RUNTIME_AXI, ADDR_WIDTH 32, ARUSER_WIDTH 0, AWUSER_WIDTH 0, BUSER_WIDTH 0, CLK_DOMAIN qwen_fabric_runtime_clk50, DATA_WIDTH 32, FREQ_HZ 50000000, HAS_BRESP 1, HAS_BURST 1, HAS_CACHE 1, HAS_LOCK 1, HAS_PROT 1, HAS_QOS 1, HAS_REGION 1, HAS_RRESP 1, HAS_WSTRB 1, ID_WIDTH 0, INSERT_VIP 0, MAX_BURST_LENGTH 1, NUM_READ_OUTSTANDING 1, NUM_READ_THREADS 1, NUM_WRITE_OUTSTANDING 1, NUM_WRITE_THREADS 1, PHASE 0.0, PROTOCOL AXI4LITE, READ_WRITE_MODE READ_WRITE, RUSER_BITS_PER_BYTE 0, RUSER_WIDTH 0, SUPPORTS_NARROW_BURST 0, WUSER_BITS_PER_BYTE 0, WUSER_WIDTH 0" *) input [31:0]RUNTIME_AXI_araddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI ARPROT" *) input [2:0]RUNTIME_AXI_arprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI ARREADY" *) output RUNTIME_AXI_arready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI ARVALID" *) input RUNTIME_AXI_arvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI AWADDR" *) input [31:0]RUNTIME_AXI_awaddr;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI AWPROT" *) input [2:0]RUNTIME_AXI_awprot;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI AWREADY" *) output RUNTIME_AXI_awready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI AWVALID" *) input RUNTIME_AXI_awvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI BREADY" *) input RUNTIME_AXI_bready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI BRESP" *) output [1:0]RUNTIME_AXI_bresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI BVALID" *) output RUNTIME_AXI_bvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI RDATA" *) output [31:0]RUNTIME_AXI_rdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI RREADY" *) input RUNTIME_AXI_rready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI RRESP" *) output [1:0]RUNTIME_AXI_rresp;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI RVALID" *) output RUNTIME_AXI_rvalid;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI WDATA" *) input [31:0]RUNTIME_AXI_wdata;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI WREADY" *) output RUNTIME_AXI_wready;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI WSTRB" *) input [3:0]RUNTIME_AXI_wstrb;
  (* X_INTERFACE_INFO = "xilinx.com:interface:aximm:1.0 RUNTIME_AXI WVALID" *) input RUNTIME_AXI_wvalid;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.CORE_CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.CORE_CLK, ASSOCIATED_RESET core_resetn, CLK_DOMAIN qwen_fabric_core_clk, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input core_clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.CORE_RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.CORE_RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input core_resetn;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.DDR_CLK CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.DDR_CLK, ASSOCIATED_BUSIF DDR_AXI, ASSOCIATED_RESET ddr_resetn:transport_resetn, CLK_DOMAIN qwen_fabric_ddr_clk, FREQ_HZ 100000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input ddr_clk;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.DDR_RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.DDR_RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input ddr_resetn;
  input engine_ready;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.ETH_CLK125 CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.ETH_CLK125, ASSOCIATED_BUSIF ETH_AXI:BOOT_SIDE_AXI, ASSOCIATED_RESET eth_resetn, CLK_DOMAIN qwen_fabric_eth_clk125, FREQ_HZ 125000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input eth_clk125;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.ETH_RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.ETH_RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input eth_resetn;
  (* X_INTERFACE_INFO = "xilinx.com:signal:clock:1.0 CLK.RUNTIME_CLK50 CLK" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME CLK.RUNTIME_CLK50, ASSOCIATED_BUSIF RUNTIME_AXI, ASSOCIATED_RESET runtime_resetn, CLK_DOMAIN qwen_fabric_runtime_clk50, FREQ_HZ 50000000, FREQ_TOLERANCE_HZ 0, INSERT_VIP 0, PHASE 0.0" *) input runtime_clk50;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.RUNTIME_RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.RUNTIME_RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input runtime_resetn;
  output sct_drain_ack125;
  output sct_drain_fault125;
  input sct_freeze_disable;
  input sct_freeze_precommit;
  input sct_independent_fault100;
  output sct_main_active;
  output sct_main_closed_ack;
  output sct_main_fault;
  output sct_main_good;
  input sct_main_prepare;
  output sct_main_qualified;
  output sct_main_ready;
  input sct_main_response_consumed;
  input sct_main_start;
  input sct_other_quiet100;
  output sct_qualify_done;
  output sct_qualify_fault;
  output sct_qualify_good;
  output sct_qualify_ready;
  input sct_qualify_start;
  input sct_release_completion_toggle50;
  output sct_release_owned125;
  input sct_release_owned50;
  output sct_release_permit125;
  input sct_side_retire_ack;
  output sct_side_retire_req;
  output sct_transport_fault100;
  output sct_trusted_stop100;
  output sct_trusted_stop125;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.TOKEN_BOARD_RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.TOKEN_BOARD_RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input token_board_resetn;
  input token_bridge_quiet;
  input token_camera_completed;
  input token_camera_done;
  input token_camera_fault;
  input token_camera_owner_live;
  output token_camera_request;
  input token_cpu_ddr_allowed;
  input token_cpu_ddr_idle;
  input token_cpu_park_ack;
  input token_cpu_parked;
  input token_guard_fault;
  input token_shared_quiet;
  output token_unpark_allow;
  (* X_INTERFACE_INFO = "xilinx.com:signal:reset:1.0 RST.TRANSPORT_RESETN RST" *) (* X_INTERFACE_PARAMETER = "XIL_INTERFACENAME RST.TRANSPORT_RESETN, INSERT_VIP 0, POLARITY ACTIVE_LOW" *) input transport_resetn;
  input uart_rx;
  output uart_tx;

  wire [31:0]RUNTIME_AXI_1_ARADDR;
  wire [2:0]RUNTIME_AXI_1_ARPROT;
  wire RUNTIME_AXI_1_ARREADY;
  wire RUNTIME_AXI_1_ARVALID;
  wire [31:0]RUNTIME_AXI_1_AWADDR;
  wire [2:0]RUNTIME_AXI_1_AWPROT;
  wire RUNTIME_AXI_1_AWREADY;
  wire RUNTIME_AXI_1_AWVALID;
  wire RUNTIME_AXI_1_BREADY;
  wire [1:0]RUNTIME_AXI_1_BRESP;
  wire RUNTIME_AXI_1_BVALID;
  wire [31:0]RUNTIME_AXI_1_RDATA;
  wire RUNTIME_AXI_1_RREADY;
  wire [1:0]RUNTIME_AXI_1_RRESP;
  wire RUNTIME_AXI_1_RVALID;
  wire [31:0]RUNTIME_AXI_1_WDATA;
  wire RUNTIME_AXI_1_WREADY;
  wire [3:0]RUNTIME_AXI_1_WSTRB;
  wire RUNTIME_AXI_1_WVALID;
  wire [31:0]boot_side_clock_converter_M_AXI_ARADDR;
  wire [2:0]boot_side_clock_converter_M_AXI_ARPROT;
  wire boot_side_clock_converter_M_AXI_ARREADY;
  wire boot_side_clock_converter_M_AXI_ARVALID;
  wire [31:0]boot_side_clock_converter_M_AXI_AWADDR;
  wire [2:0]boot_side_clock_converter_M_AXI_AWPROT;
  wire boot_side_clock_converter_M_AXI_AWREADY;
  wire boot_side_clock_converter_M_AXI_AWVALID;
  wire boot_side_clock_converter_M_AXI_BREADY;
  wire [1:0]boot_side_clock_converter_M_AXI_BRESP;
  wire boot_side_clock_converter_M_AXI_BVALID;
  wire [31:0]boot_side_clock_converter_M_AXI_RDATA;
  wire boot_side_clock_converter_M_AXI_RREADY;
  wire [1:0]boot_side_clock_converter_M_AXI_RRESP;
  wire boot_side_clock_converter_M_AXI_RVALID;
  wire [31:0]boot_side_clock_converter_M_AXI_WDATA;
  wire boot_side_clock_converter_M_AXI_WREADY;
  wire [3:0]boot_side_clock_converter_M_AXI_WSTRB;
  wire boot_side_clock_converter_M_AXI_WVALID;
  wire core_clk_1;
  wire core_resetn_1;
  wire ddr_clk_1;
  wire [31:0]engine_M_AXI_ARADDR;
  wire [1:0]engine_M_AXI_ARBURST;
  wire [7:0]engine_M_AXI_ARLEN;
  wire engine_M_AXI_ARREADY;
  wire [2:0]engine_M_AXI_ARSIZE;
  wire engine_M_AXI_ARVALID;
  wire [31:0]engine_M_AXI_AWADDR;
  wire [1:0]engine_M_AXI_AWBURST;
  wire [7:0]engine_M_AXI_AWLEN;
  wire engine_M_AXI_AWREADY;
  wire [2:0]engine_M_AXI_AWSIZE;
  wire engine_M_AXI_AWVALID;
  wire engine_M_AXI_BREADY;
  wire [1:0]engine_M_AXI_BRESP;
  wire engine_M_AXI_BVALID;
  wire [127:0]engine_M_AXI_RDATA;
  wire engine_M_AXI_RLAST;
  wire engine_M_AXI_RREADY;
  wire [1:0]engine_M_AXI_RRESP;
  wire engine_M_AXI_RVALID;
  wire [127:0]engine_M_AXI_WDATA;
  wire engine_M_AXI_WLAST;
  wire engine_M_AXI_WREADY;
  wire [15:0]engine_M_AXI_WSTRB;
  wire engine_M_AXI_WVALID;
  wire engine_ready_1;
  wire engine_token_camera_request;
  wire engine_token_unpark_allow;
  wire engine_uart_tx;
  wire eth_clk125_1;
  wire eth_resetn_1;
  wire [31:0]fabric_M00_AXI_ARADDR;
  wire [1:0]fabric_M00_AXI_ARBURST;
  wire [3:0]fabric_M00_AXI_ARCACHE;
  wire [7:0]fabric_M00_AXI_ARLEN;
  wire [0:0]fabric_M00_AXI_ARLOCK;
  wire [2:0]fabric_M00_AXI_ARPROT;
  wire [3:0]fabric_M00_AXI_ARQOS;
  wire fabric_M00_AXI_ARREADY;
  wire [2:0]fabric_M00_AXI_ARSIZE;
  wire fabric_M00_AXI_ARVALID;
  wire [31:0]fabric_M00_AXI_AWADDR;
  wire [1:0]fabric_M00_AXI_AWBURST;
  wire [3:0]fabric_M00_AXI_AWCACHE;
  wire [7:0]fabric_M00_AXI_AWLEN;
  wire [0:0]fabric_M00_AXI_AWLOCK;
  wire [2:0]fabric_M00_AXI_AWPROT;
  wire [3:0]fabric_M00_AXI_AWQOS;
  wire fabric_M00_AXI_AWREADY;
  wire [2:0]fabric_M00_AXI_AWSIZE;
  wire fabric_M00_AXI_AWVALID;
  wire fabric_M00_AXI_BREADY;
  wire [1:0]fabric_M00_AXI_BRESP;
  wire fabric_M00_AXI_BVALID;
  wire [127:0]fabric_M00_AXI_RDATA;
  wire fabric_M00_AXI_RLAST;
  wire fabric_M00_AXI_RREADY;
  wire [1:0]fabric_M00_AXI_RRESP;
  wire fabric_M00_AXI_RVALID;
  wire [127:0]fabric_M00_AXI_WDATA;
  wire fabric_M00_AXI_WLAST;
  wire fabric_M00_AXI_WREADY;
  wire [15:0]fabric_M00_AXI_WSTRB;
  wire fabric_M00_AXI_WVALID;
  wire [31:0]fabric_M01_AXI_ARADDR;
  wire [2:0]fabric_M01_AXI_ARPROT;
  wire fabric_M01_AXI_ARREADY;
  wire fabric_M01_AXI_ARVALID;
  wire [31:0]fabric_M01_AXI_AWADDR;
  wire [2:0]fabric_M01_AXI_AWPROT;
  wire fabric_M01_AXI_AWREADY;
  wire fabric_M01_AXI_AWVALID;
  wire fabric_M01_AXI_BREADY;
  wire [1:0]fabric_M01_AXI_BRESP;
  wire fabric_M01_AXI_BVALID;
  wire [31:0]fabric_M01_AXI_RDATA;
  wire fabric_M01_AXI_RREADY;
  wire [1:0]fabric_M01_AXI_RRESP;
  wire fabric_M01_AXI_RVALID;
  wire [31:0]fabric_M01_AXI_WDATA;
  wire fabric_M01_AXI_WREADY;
  wire [3:0]fabric_M01_AXI_WSTRB;
  wire fabric_M01_AXI_WVALID;
  wire [31:0]fabric_M02_AXI_ARADDR;
  wire [2:0]fabric_M02_AXI_ARPROT;
  wire fabric_M02_AXI_ARREADY;
  wire fabric_M02_AXI_ARVALID;
  wire [31:0]fabric_M02_AXI_AWADDR;
  wire [2:0]fabric_M02_AXI_AWPROT;
  wire fabric_M02_AXI_AWREADY;
  wire fabric_M02_AXI_AWVALID;
  wire fabric_M02_AXI_BREADY;
  wire [1:0]fabric_M02_AXI_BRESP;
  wire fabric_M02_AXI_BVALID;
  wire [31:0]fabric_M02_AXI_RDATA;
  wire fabric_M02_AXI_RREADY;
  wire [1:0]fabric_M02_AXI_RRESP;
  wire fabric_M02_AXI_RVALID;
  wire [31:0]fabric_M02_AXI_WDATA;
  wire fabric_M02_AXI_WREADY;
  wire [3:0]fabric_M02_AXI_WSTRB;
  wire fabric_M02_AXI_WVALID;
  wire [31:0]loader_M_AXI_ARADDR;
  wire [1:0]loader_M_AXI_ARBURST;
  wire [3:0]loader_M_AXI_ARCACHE;
  wire [0:0]loader_M_AXI_ARID;
  wire [7:0]loader_M_AXI_ARLEN;
  wire loader_M_AXI_ARLOCK;
  wire [2:0]loader_M_AXI_ARPROT;
  wire [3:0]loader_M_AXI_ARQOS;
  wire loader_M_AXI_ARREADY;
  wire [2:0]loader_M_AXI_ARSIZE;
  wire loader_M_AXI_ARVALID;
  wire [31:0]loader_M_AXI_AWADDR;
  wire [1:0]loader_M_AXI_AWBURST;
  wire [3:0]loader_M_AXI_AWCACHE;
  wire [0:0]loader_M_AXI_AWID;
  wire [7:0]loader_M_AXI_AWLEN;
  wire loader_M_AXI_AWLOCK;
  wire [2:0]loader_M_AXI_AWPROT;
  wire [3:0]loader_M_AXI_AWQOS;
  wire loader_M_AXI_AWREADY;
  wire [2:0]loader_M_AXI_AWSIZE;
  wire loader_M_AXI_AWVALID;
  wire loader_M_AXI_BID;
  wire loader_M_AXI_BREADY;
  wire [1:0]loader_M_AXI_BRESP;
  wire loader_M_AXI_BVALID;
  wire [31:0]loader_M_AXI_RDATA;
  wire loader_M_AXI_RID;
  wire loader_M_AXI_RLAST;
  wire loader_M_AXI_RREADY;
  wire [1:0]loader_M_AXI_RRESP;
  wire loader_M_AXI_RVALID;
  wire [31:0]loader_M_AXI_WDATA;
  wire loader_M_AXI_WLAST;
  wire loader_M_AXI_WREADY;
  wire [3:0]loader_M_AXI_WSTRB;
  wire loader_M_AXI_WVALID;
  wire runtime_clk50_1;
  wire [31:0]runtime_clock_converter_M_AXI_ARADDR;
  wire [2:0]runtime_clock_converter_M_AXI_ARPROT;
  wire runtime_clock_converter_M_AXI_ARREADY;
  wire runtime_clock_converter_M_AXI_ARVALID;
  wire [31:0]runtime_clock_converter_M_AXI_AWADDR;
  wire [2:0]runtime_clock_converter_M_AXI_AWPROT;
  wire runtime_clock_converter_M_AXI_AWREADY;
  wire runtime_clock_converter_M_AXI_AWVALID;
  wire runtime_clock_converter_M_AXI_BREADY;
  wire [1:0]runtime_clock_converter_M_AXI_BRESP;
  wire runtime_clock_converter_M_AXI_BVALID;
  wire [31:0]runtime_clock_converter_M_AXI_RDATA;
  wire runtime_clock_converter_M_AXI_RREADY;
  wire [1:0]runtime_clock_converter_M_AXI_RRESP;
  wire runtime_clock_converter_M_AXI_RVALID;
  wire [31:0]runtime_clock_converter_M_AXI_WDATA;
  wire runtime_clock_converter_M_AXI_WREADY;
  wire [3:0]runtime_clock_converter_M_AXI_WSTRB;
  wire runtime_clock_converter_M_AXI_WVALID;
  wire runtime_resetn_1;
  wire sct_freeze_disable_1;
  wire sct_freeze_precommit_1;
  wire sct_independent_fault100_1;
  wire sct_main_prepare_1;
  wire sct_main_response_consumed_1;
  wire sct_main_start_1;
  wire sct_other_quiet100_1;
  wire sct_qualify_start_1;
  wire sct_release_completion_toggle50_1;
  wire sct_release_owned50_1;
  wire sct_side_retire_ack_1;
  wire [31:0]shared_control_B_AXI_ARADDR;
  wire [2:0]shared_control_B_AXI_ARPROT;
  wire shared_control_B_AXI_ARREADY;
  wire shared_control_B_AXI_ARVALID;
  wire [31:0]shared_control_B_AXI_AWADDR;
  wire [2:0]shared_control_B_AXI_AWPROT;
  wire shared_control_B_AXI_AWREADY;
  wire shared_control_B_AXI_AWVALID;
  wire shared_control_B_AXI_BREADY;
  wire [1:0]shared_control_B_AXI_BRESP;
  wire shared_control_B_AXI_BVALID;
  wire [31:0]shared_control_B_AXI_RDATA;
  wire shared_control_B_AXI_RREADY;
  wire [1:0]shared_control_B_AXI_RRESP;
  wire shared_control_B_AXI_RVALID;
  wire [31:0]shared_control_B_AXI_WDATA;
  wire shared_control_B_AXI_WREADY;
  wire [3:0]shared_control_B_AXI_WSTRB;
  wire shared_control_B_AXI_WVALID;
  wire [31:0]shared_control_M_AXI_ARADDR;
  wire [1:0]shared_control_M_AXI_ARBURST;
  wire [3:0]shared_control_M_AXI_ARCACHE;
  wire shared_control_M_AXI_ARID;
  wire [7:0]shared_control_M_AXI_ARLEN;
  wire shared_control_M_AXI_ARLOCK;
  wire [2:0]shared_control_M_AXI_ARPROT;
  wire [3:0]shared_control_M_AXI_ARQOS;
  wire shared_control_M_AXI_ARREADY;
  wire [2:0]shared_control_M_AXI_ARSIZE;
  wire shared_control_M_AXI_ARVALID;
  wire [31:0]shared_control_M_AXI_AWADDR;
  wire [1:0]shared_control_M_AXI_AWBURST;
  wire [3:0]shared_control_M_AXI_AWCACHE;
  wire shared_control_M_AXI_AWID;
  wire [7:0]shared_control_M_AXI_AWLEN;
  wire shared_control_M_AXI_AWLOCK;
  wire [2:0]shared_control_M_AXI_AWPROT;
  wire [3:0]shared_control_M_AXI_AWQOS;
  wire shared_control_M_AXI_AWREADY;
  wire [2:0]shared_control_M_AXI_AWSIZE;
  wire shared_control_M_AXI_AWVALID;
  wire [0:0]shared_control_M_AXI_BID;
  wire shared_control_M_AXI_BREADY;
  wire [1:0]shared_control_M_AXI_BRESP;
  wire shared_control_M_AXI_BVALID;
  wire [31:0]shared_control_M_AXI_RDATA;
  wire [0:0]shared_control_M_AXI_RID;
  wire shared_control_M_AXI_RLAST;
  wire shared_control_M_AXI_RREADY;
  wire [1:0]shared_control_M_AXI_RRESP;
  wire shared_control_M_AXI_RVALID;
  wire [31:0]shared_control_M_AXI_WDATA;
  wire shared_control_M_AXI_WLAST;
  wire shared_control_M_AXI_WREADY;
  wire [3:0]shared_control_M_AXI_WSTRB;
  wire shared_control_M_AXI_WVALID;
  wire shared_control_drain_ack125;
  wire shared_control_drain_fault125;
  wire shared_control_main_active;
  wire shared_control_main_closed_ack;
  wire shared_control_main_fault;
  wire shared_control_main_good;
  wire shared_control_main_qualified;
  wire shared_control_main_ready;
  wire shared_control_qualify_done;
  wire shared_control_qualify_fault;
  wire shared_control_qualify_good;
  wire shared_control_qualify_ready;
  wire shared_control_release_owned125;
  wire shared_control_release_permit125;
  wire shared_control_side_retire_req;
  wire shared_control_transport_fault100;
  wire shared_control_trusted_stop100;
  wire shared_control_trusted_stop125;
  wire token_board_resetn_1;
  wire token_bridge_quiet_1;
  wire token_camera_completed_1;
  wire token_camera_done_1;
  wire token_camera_fault_1;
  wire token_camera_owner_live_1;
  wire token_cpu_ddr_allowed_1;
  wire token_cpu_ddr_idle_1;
  wire token_cpu_park_ack_1;
  wire token_cpu_parked_1;
  wire token_guard_fault_1;
  wire token_shared_quiet_1;
  wire transport_resetn_1;
  wire uart_rx_1;

  assign BOOT_SIDE_AXI_araddr[31:0] = boot_side_clock_converter_M_AXI_ARADDR;
  assign BOOT_SIDE_AXI_arprot[2:0] = boot_side_clock_converter_M_AXI_ARPROT;
  assign BOOT_SIDE_AXI_arvalid = boot_side_clock_converter_M_AXI_ARVALID;
  assign BOOT_SIDE_AXI_awaddr[31:0] = boot_side_clock_converter_M_AXI_AWADDR;
  assign BOOT_SIDE_AXI_awprot[2:0] = boot_side_clock_converter_M_AXI_AWPROT;
  assign BOOT_SIDE_AXI_awvalid = boot_side_clock_converter_M_AXI_AWVALID;
  assign BOOT_SIDE_AXI_bready = boot_side_clock_converter_M_AXI_BREADY;
  assign BOOT_SIDE_AXI_rready = boot_side_clock_converter_M_AXI_RREADY;
  assign BOOT_SIDE_AXI_wdata[31:0] = boot_side_clock_converter_M_AXI_WDATA;
  assign BOOT_SIDE_AXI_wstrb[3:0] = boot_side_clock_converter_M_AXI_WSTRB;
  assign BOOT_SIDE_AXI_wvalid = boot_side_clock_converter_M_AXI_WVALID;
  assign DDR_AXI_araddr[31:0] = fabric_M00_AXI_ARADDR;
  assign DDR_AXI_arburst[1:0] = fabric_M00_AXI_ARBURST;
  assign DDR_AXI_arcache[3:0] = fabric_M00_AXI_ARCACHE;
  assign DDR_AXI_arlen[7:0] = fabric_M00_AXI_ARLEN;
  assign DDR_AXI_arlock[0] = fabric_M00_AXI_ARLOCK;
  assign DDR_AXI_arprot[2:0] = fabric_M00_AXI_ARPROT;
  assign DDR_AXI_arqos[3:0] = fabric_M00_AXI_ARQOS;
  assign DDR_AXI_arsize[2:0] = fabric_M00_AXI_ARSIZE;
  assign DDR_AXI_arvalid = fabric_M00_AXI_ARVALID;
  assign DDR_AXI_awaddr[31:0] = fabric_M00_AXI_AWADDR;
  assign DDR_AXI_awburst[1:0] = fabric_M00_AXI_AWBURST;
  assign DDR_AXI_awcache[3:0] = fabric_M00_AXI_AWCACHE;
  assign DDR_AXI_awlen[7:0] = fabric_M00_AXI_AWLEN;
  assign DDR_AXI_awlock[0] = fabric_M00_AXI_AWLOCK;
  assign DDR_AXI_awprot[2:0] = fabric_M00_AXI_AWPROT;
  assign DDR_AXI_awqos[3:0] = fabric_M00_AXI_AWQOS;
  assign DDR_AXI_awsize[2:0] = fabric_M00_AXI_AWSIZE;
  assign DDR_AXI_awvalid = fabric_M00_AXI_AWVALID;
  assign DDR_AXI_bready = fabric_M00_AXI_BREADY;
  assign DDR_AXI_rready = fabric_M00_AXI_RREADY;
  assign DDR_AXI_wdata[127:0] = fabric_M00_AXI_WDATA;
  assign DDR_AXI_wlast = fabric_M00_AXI_WLAST;
  assign DDR_AXI_wstrb[15:0] = fabric_M00_AXI_WSTRB;
  assign DDR_AXI_wvalid = fabric_M00_AXI_WVALID;
  assign ETH_AXI_araddr[31:0] = fabric_M02_AXI_ARADDR;
  assign ETH_AXI_arprot[2:0] = fabric_M02_AXI_ARPROT;
  assign ETH_AXI_arvalid = fabric_M02_AXI_ARVALID;
  assign ETH_AXI_awaddr[31:0] = fabric_M02_AXI_AWADDR;
  assign ETH_AXI_awprot[2:0] = fabric_M02_AXI_AWPROT;
  assign ETH_AXI_awvalid = fabric_M02_AXI_AWVALID;
  assign ETH_AXI_bready = fabric_M02_AXI_BREADY;
  assign ETH_AXI_rready = fabric_M02_AXI_RREADY;
  assign ETH_AXI_wdata[31:0] = fabric_M02_AXI_WDATA;
  assign ETH_AXI_wstrb[3:0] = fabric_M02_AXI_WSTRB;
  assign ETH_AXI_wvalid = fabric_M02_AXI_WVALID;
  assign RUNTIME_AXI_1_ARADDR = RUNTIME_AXI_araddr[31:0];
  assign RUNTIME_AXI_1_ARPROT = RUNTIME_AXI_arprot[2:0];
  assign RUNTIME_AXI_1_ARVALID = RUNTIME_AXI_arvalid;
  assign RUNTIME_AXI_1_AWADDR = RUNTIME_AXI_awaddr[31:0];
  assign RUNTIME_AXI_1_AWPROT = RUNTIME_AXI_awprot[2:0];
  assign RUNTIME_AXI_1_AWVALID = RUNTIME_AXI_awvalid;
  assign RUNTIME_AXI_1_BREADY = RUNTIME_AXI_bready;
  assign RUNTIME_AXI_1_RREADY = RUNTIME_AXI_rready;
  assign RUNTIME_AXI_1_WDATA = RUNTIME_AXI_wdata[31:0];
  assign RUNTIME_AXI_1_WSTRB = RUNTIME_AXI_wstrb[3:0];
  assign RUNTIME_AXI_1_WVALID = RUNTIME_AXI_wvalid;
  assign RUNTIME_AXI_arready = RUNTIME_AXI_1_ARREADY;
  assign RUNTIME_AXI_awready = RUNTIME_AXI_1_AWREADY;
  assign RUNTIME_AXI_bresp[1:0] = RUNTIME_AXI_1_BRESP;
  assign RUNTIME_AXI_bvalid = RUNTIME_AXI_1_BVALID;
  assign RUNTIME_AXI_rdata[31:0] = RUNTIME_AXI_1_RDATA;
  assign RUNTIME_AXI_rresp[1:0] = RUNTIME_AXI_1_RRESP;
  assign RUNTIME_AXI_rvalid = RUNTIME_AXI_1_RVALID;
  assign RUNTIME_AXI_wready = RUNTIME_AXI_1_WREADY;
  assign boot_side_clock_converter_M_AXI_ARREADY = BOOT_SIDE_AXI_arready;
  assign boot_side_clock_converter_M_AXI_AWREADY = BOOT_SIDE_AXI_awready;
  assign boot_side_clock_converter_M_AXI_BRESP = BOOT_SIDE_AXI_bresp[1:0];
  assign boot_side_clock_converter_M_AXI_BVALID = BOOT_SIDE_AXI_bvalid;
  assign boot_side_clock_converter_M_AXI_RDATA = BOOT_SIDE_AXI_rdata[31:0];
  assign boot_side_clock_converter_M_AXI_RRESP = BOOT_SIDE_AXI_rresp[1:0];
  assign boot_side_clock_converter_M_AXI_RVALID = BOOT_SIDE_AXI_rvalid;
  assign boot_side_clock_converter_M_AXI_WREADY = BOOT_SIDE_AXI_wready;
  assign core_clk_1 = core_clk;
  assign core_resetn_1 = core_resetn;
  assign ddr_clk_1 = ddr_clk;
  assign engine_ready_1 = engine_ready;
  assign eth_clk125_1 = eth_clk125;
  assign eth_resetn_1 = eth_resetn;
  assign fabric_M00_AXI_ARREADY = DDR_AXI_arready;
  assign fabric_M00_AXI_AWREADY = DDR_AXI_awready;
  assign fabric_M00_AXI_BRESP = DDR_AXI_bresp[1:0];
  assign fabric_M00_AXI_BVALID = DDR_AXI_bvalid;
  assign fabric_M00_AXI_RDATA = DDR_AXI_rdata[127:0];
  assign fabric_M00_AXI_RLAST = DDR_AXI_rlast;
  assign fabric_M00_AXI_RRESP = DDR_AXI_rresp[1:0];
  assign fabric_M00_AXI_RVALID = DDR_AXI_rvalid;
  assign fabric_M00_AXI_WREADY = DDR_AXI_wready;
  assign fabric_M02_AXI_ARREADY = ETH_AXI_arready;
  assign fabric_M02_AXI_AWREADY = ETH_AXI_awready;
  assign fabric_M02_AXI_BRESP = ETH_AXI_bresp[1:0];
  assign fabric_M02_AXI_BVALID = ETH_AXI_bvalid;
  assign fabric_M02_AXI_RDATA = ETH_AXI_rdata[31:0];
  assign fabric_M02_AXI_RRESP = ETH_AXI_rresp[1:0];
  assign fabric_M02_AXI_RVALID = ETH_AXI_rvalid;
  assign fabric_M02_AXI_WREADY = ETH_AXI_wready;
  assign runtime_clk50_1 = runtime_clk50;
  assign runtime_resetn_1 = runtime_resetn;
  assign sct_drain_ack125 = shared_control_drain_ack125;
  assign sct_drain_fault125 = shared_control_drain_fault125;
  assign sct_freeze_disable_1 = sct_freeze_disable;
  assign sct_freeze_precommit_1 = sct_freeze_precommit;
  assign sct_independent_fault100_1 = sct_independent_fault100;
  assign sct_main_active = shared_control_main_active;
  assign sct_main_closed_ack = shared_control_main_closed_ack;
  assign sct_main_fault = shared_control_main_fault;
  assign sct_main_good = shared_control_main_good;
  assign sct_main_prepare_1 = sct_main_prepare;
  assign sct_main_qualified = shared_control_main_qualified;
  assign sct_main_ready = shared_control_main_ready;
  assign sct_main_response_consumed_1 = sct_main_response_consumed;
  assign sct_main_start_1 = sct_main_start;
  assign sct_other_quiet100_1 = sct_other_quiet100;
  assign sct_qualify_done = shared_control_qualify_done;
  assign sct_qualify_fault = shared_control_qualify_fault;
  assign sct_qualify_good = shared_control_qualify_good;
  assign sct_qualify_ready = shared_control_qualify_ready;
  assign sct_qualify_start_1 = sct_qualify_start;
  assign sct_release_completion_toggle50_1 = sct_release_completion_toggle50;
  assign sct_release_owned125 = shared_control_release_owned125;
  assign sct_release_owned50_1 = sct_release_owned50;
  assign sct_release_permit125 = shared_control_release_permit125;
  assign sct_side_retire_ack_1 = sct_side_retire_ack;
  assign sct_side_retire_req = shared_control_side_retire_req;
  assign sct_transport_fault100 = shared_control_transport_fault100;
  assign sct_trusted_stop100 = shared_control_trusted_stop100;
  assign sct_trusted_stop125 = shared_control_trusted_stop125;
  assign token_board_resetn_1 = token_board_resetn;
  assign token_bridge_quiet_1 = token_bridge_quiet;
  assign token_camera_completed_1 = token_camera_completed;
  assign token_camera_done_1 = token_camera_done;
  assign token_camera_fault_1 = token_camera_fault;
  assign token_camera_owner_live_1 = token_camera_owner_live;
  assign token_camera_request = engine_token_camera_request;
  assign token_cpu_ddr_allowed_1 = token_cpu_ddr_allowed;
  assign token_cpu_ddr_idle_1 = token_cpu_ddr_idle;
  assign token_cpu_park_ack_1 = token_cpu_park_ack;
  assign token_cpu_parked_1 = token_cpu_parked;
  assign token_guard_fault_1 = token_guard_fault;
  assign token_shared_quiet_1 = token_shared_quiet;
  assign token_unpark_allow = engine_token_unpark_allow;
  assign transport_resetn_1 = transport_resetn;
  assign uart_rx_1 = uart_rx;
  assign uart_tx = engine_uart_tx;
  qwen_fabric_boot_side_clock_converter_0 boot_side_clock_converter
       (.m_axi_aclk(eth_clk125_1),
        .m_axi_araddr(boot_side_clock_converter_M_AXI_ARADDR),
        .m_axi_aresetn(eth_resetn_1),
        .m_axi_arprot(boot_side_clock_converter_M_AXI_ARPROT),
        .m_axi_arready(boot_side_clock_converter_M_AXI_ARREADY),
        .m_axi_arvalid(boot_side_clock_converter_M_AXI_ARVALID),
        .m_axi_awaddr(boot_side_clock_converter_M_AXI_AWADDR),
        .m_axi_awprot(boot_side_clock_converter_M_AXI_AWPROT),
        .m_axi_awready(boot_side_clock_converter_M_AXI_AWREADY),
        .m_axi_awvalid(boot_side_clock_converter_M_AXI_AWVALID),
        .m_axi_bready(boot_side_clock_converter_M_AXI_BREADY),
        .m_axi_bresp(boot_side_clock_converter_M_AXI_BRESP),
        .m_axi_bvalid(boot_side_clock_converter_M_AXI_BVALID),
        .m_axi_rdata(boot_side_clock_converter_M_AXI_RDATA),
        .m_axi_rready(boot_side_clock_converter_M_AXI_RREADY),
        .m_axi_rresp(boot_side_clock_converter_M_AXI_RRESP),
        .m_axi_rvalid(boot_side_clock_converter_M_AXI_RVALID),
        .m_axi_wdata(boot_side_clock_converter_M_AXI_WDATA),
        .m_axi_wready(boot_side_clock_converter_M_AXI_WREADY),
        .m_axi_wstrb(boot_side_clock_converter_M_AXI_WSTRB),
        .m_axi_wvalid(boot_side_clock_converter_M_AXI_WVALID),
        .s_axi_aclk(ddr_clk_1),
        .s_axi_araddr(shared_control_B_AXI_ARADDR),
        .s_axi_aresetn(transport_resetn_1),
        .s_axi_arprot(shared_control_B_AXI_ARPROT),
        .s_axi_arready(shared_control_B_AXI_ARREADY),
        .s_axi_arvalid(shared_control_B_AXI_ARVALID),
        .s_axi_awaddr(shared_control_B_AXI_AWADDR),
        .s_axi_awprot(shared_control_B_AXI_AWPROT),
        .s_axi_awready(shared_control_B_AXI_AWREADY),
        .s_axi_awvalid(shared_control_B_AXI_AWVALID),
        .s_axi_bready(shared_control_B_AXI_BREADY),
        .s_axi_bresp(shared_control_B_AXI_BRESP),
        .s_axi_bvalid(shared_control_B_AXI_BVALID),
        .s_axi_rdata(shared_control_B_AXI_RDATA),
        .s_axi_rready(shared_control_B_AXI_RREADY),
        .s_axi_rresp(shared_control_B_AXI_RRESP),
        .s_axi_rvalid(shared_control_B_AXI_RVALID),
        .s_axi_wdata(shared_control_B_AXI_WDATA),
        .s_axi_wready(shared_control_B_AXI_WREADY),
        .s_axi_wstrb(shared_control_B_AXI_WSTRB),
        .s_axi_wvalid(shared_control_B_AXI_WVALID));
  qwen_fabric_engine_0 engine
       (.aclk(core_clk_1),
        .aresetn(core_resetn_1),
        .engine_ready(engine_ready_1),
        .m_axi_araddr(engine_M_AXI_ARADDR),
        .m_axi_arburst(engine_M_AXI_ARBURST),
        .m_axi_arlen(engine_M_AXI_ARLEN),
        .m_axi_arready(engine_M_AXI_ARREADY),
        .m_axi_arsize(engine_M_AXI_ARSIZE),
        .m_axi_arvalid(engine_M_AXI_ARVALID),
        .m_axi_awaddr(engine_M_AXI_AWADDR),
        .m_axi_awburst(engine_M_AXI_AWBURST),
        .m_axi_awlen(engine_M_AXI_AWLEN),
        .m_axi_awready(engine_M_AXI_AWREADY),
        .m_axi_awsize(engine_M_AXI_AWSIZE),
        .m_axi_awvalid(engine_M_AXI_AWVALID),
        .m_axi_bready(engine_M_AXI_BREADY),
        .m_axi_bresp(engine_M_AXI_BRESP),
        .m_axi_bvalid(engine_M_AXI_BVALID),
        .m_axi_rdata(engine_M_AXI_RDATA),
        .m_axi_rlast(engine_M_AXI_RLAST),
        .m_axi_rready(engine_M_AXI_RREADY),
        .m_axi_rresp(engine_M_AXI_RRESP),
        .m_axi_rvalid(engine_M_AXI_RVALID),
        .m_axi_wdata(engine_M_AXI_WDATA),
        .m_axi_wlast(engine_M_AXI_WLAST),
        .m_axi_wready(engine_M_AXI_WREADY),
        .m_axi_wstrb(engine_M_AXI_WSTRB),
        .m_axi_wvalid(engine_M_AXI_WVALID),
        .s_axi_araddr(fabric_M01_AXI_ARADDR),
        .s_axi_arprot(fabric_M01_AXI_ARPROT),
        .s_axi_arready(fabric_M01_AXI_ARREADY),
        .s_axi_arvalid(fabric_M01_AXI_ARVALID),
        .s_axi_awaddr(fabric_M01_AXI_AWADDR),
        .s_axi_awprot(fabric_M01_AXI_AWPROT),
        .s_axi_awready(fabric_M01_AXI_AWREADY),
        .s_axi_awvalid(fabric_M01_AXI_AWVALID),
        .s_axi_bready(fabric_M01_AXI_BREADY),
        .s_axi_bresp(fabric_M01_AXI_BRESP),
        .s_axi_bvalid(fabric_M01_AXI_BVALID),
        .s_axi_rdata(fabric_M01_AXI_RDATA),
        .s_axi_rready(fabric_M01_AXI_RREADY),
        .s_axi_rresp(fabric_M01_AXI_RRESP),
        .s_axi_rvalid(fabric_M01_AXI_RVALID),
        .s_axi_wdata(fabric_M01_AXI_WDATA),
        .s_axi_wready(fabric_M01_AXI_WREADY),
        .s_axi_wstrb(fabric_M01_AXI_WSTRB),
        .s_axi_wvalid(fabric_M01_AXI_WVALID),
        .token_board_resetn(token_board_resetn_1),
        .token_bridge_quiet(token_bridge_quiet_1),
        .token_camera_completed(token_camera_completed_1),
        .token_camera_done(token_camera_done_1),
        .token_camera_fault(token_camera_fault_1),
        .token_camera_owner_live(token_camera_owner_live_1),
        .token_camera_request(engine_token_camera_request),
        .token_cpu_ddr_allowed(token_cpu_ddr_allowed_1),
        .token_cpu_ddr_idle(token_cpu_ddr_idle_1),
        .token_cpu_park_ack(token_cpu_park_ack_1),
        .token_cpu_parked(token_cpu_parked_1),
        .token_guard_fault(token_guard_fault_1),
        .token_shared_quiet(token_shared_quiet_1),
        .token_unpark_allow(engine_token_unpark_allow),
        .uart_rx(uart_rx_1),
        .uart_tx(engine_uart_tx));
  qwen_fabric_fabric_0 fabric
       (.M00_AXI_araddr(fabric_M00_AXI_ARADDR),
        .M00_AXI_arburst(fabric_M00_AXI_ARBURST),
        .M00_AXI_arcache(fabric_M00_AXI_ARCACHE),
        .M00_AXI_arlen(fabric_M00_AXI_ARLEN),
        .M00_AXI_arlock(fabric_M00_AXI_ARLOCK),
        .M00_AXI_arprot(fabric_M00_AXI_ARPROT),
        .M00_AXI_arqos(fabric_M00_AXI_ARQOS),
        .M00_AXI_arready(fabric_M00_AXI_ARREADY),
        .M00_AXI_arsize(fabric_M00_AXI_ARSIZE),
        .M00_AXI_arvalid(fabric_M00_AXI_ARVALID),
        .M00_AXI_awaddr(fabric_M00_AXI_AWADDR),
        .M00_AXI_awburst(fabric_M00_AXI_AWBURST),
        .M00_AXI_awcache(fabric_M00_AXI_AWCACHE),
        .M00_AXI_awlen(fabric_M00_AXI_AWLEN),
        .M00_AXI_awlock(fabric_M00_AXI_AWLOCK),
        .M00_AXI_awprot(fabric_M00_AXI_AWPROT),
        .M00_AXI_awqos(fabric_M00_AXI_AWQOS),
        .M00_AXI_awready(fabric_M00_AXI_AWREADY),
        .M00_AXI_awsize(fabric_M00_AXI_AWSIZE),
        .M00_AXI_awvalid(fabric_M00_AXI_AWVALID),
        .M00_AXI_bready(fabric_M00_AXI_BREADY),
        .M00_AXI_bresp(fabric_M00_AXI_BRESP),
        .M00_AXI_bvalid(fabric_M00_AXI_BVALID),
        .M00_AXI_rdata(fabric_M00_AXI_RDATA),
        .M00_AXI_rlast(fabric_M00_AXI_RLAST),
        .M00_AXI_rready(fabric_M00_AXI_RREADY),
        .M00_AXI_rresp(fabric_M00_AXI_RRESP),
        .M00_AXI_rvalid(fabric_M00_AXI_RVALID),
        .M00_AXI_wdata(fabric_M00_AXI_WDATA),
        .M00_AXI_wlast(fabric_M00_AXI_WLAST),
        .M00_AXI_wready(fabric_M00_AXI_WREADY),
        .M00_AXI_wstrb(fabric_M00_AXI_WSTRB),
        .M00_AXI_wvalid(fabric_M00_AXI_WVALID),
        .M01_AXI_araddr(fabric_M01_AXI_ARADDR),
        .M01_AXI_arprot(fabric_M01_AXI_ARPROT),
        .M01_AXI_arready(fabric_M01_AXI_ARREADY),
        .M01_AXI_arvalid(fabric_M01_AXI_ARVALID),
        .M01_AXI_awaddr(fabric_M01_AXI_AWADDR),
        .M01_AXI_awprot(fabric_M01_AXI_AWPROT),
        .M01_AXI_awready(fabric_M01_AXI_AWREADY),
        .M01_AXI_awvalid(fabric_M01_AXI_AWVALID),
        .M01_AXI_bready(fabric_M01_AXI_BREADY),
        .M01_AXI_bresp(fabric_M01_AXI_BRESP),
        .M01_AXI_bvalid(fabric_M01_AXI_BVALID),
        .M01_AXI_rdata(fabric_M01_AXI_RDATA),
        .M01_AXI_rready(fabric_M01_AXI_RREADY),
        .M01_AXI_rresp(fabric_M01_AXI_RRESP),
        .M01_AXI_rvalid(fabric_M01_AXI_RVALID),
        .M01_AXI_wdata(fabric_M01_AXI_WDATA),
        .M01_AXI_wready(fabric_M01_AXI_WREADY),
        .M01_AXI_wstrb(fabric_M01_AXI_WSTRB),
        .M01_AXI_wvalid(fabric_M01_AXI_WVALID),
        .M02_AXI_araddr(fabric_M02_AXI_ARADDR),
        .M02_AXI_arprot(fabric_M02_AXI_ARPROT),
        .M02_AXI_arready(fabric_M02_AXI_ARREADY),
        .M02_AXI_arvalid(fabric_M02_AXI_ARVALID),
        .M02_AXI_awaddr(fabric_M02_AXI_AWADDR),
        .M02_AXI_awprot(fabric_M02_AXI_AWPROT),
        .M02_AXI_awready(fabric_M02_AXI_AWREADY),
        .M02_AXI_awvalid(fabric_M02_AXI_AWVALID),
        .M02_AXI_bready(fabric_M02_AXI_BREADY),
        .M02_AXI_bresp(fabric_M02_AXI_BRESP),
        .M02_AXI_bvalid(fabric_M02_AXI_BVALID),
        .M02_AXI_rdata(fabric_M02_AXI_RDATA),
        .M02_AXI_rready(fabric_M02_AXI_RREADY),
        .M02_AXI_rresp(fabric_M02_AXI_RRESP),
        .M02_AXI_rvalid(fabric_M02_AXI_RVALID),
        .M02_AXI_wdata(fabric_M02_AXI_WDATA),
        .M02_AXI_wready(fabric_M02_AXI_WREADY),
        .M02_AXI_wstrb(fabric_M02_AXI_WSTRB),
        .M02_AXI_wvalid(fabric_M02_AXI_WVALID),
        .S00_AXI_araddr(engine_M_AXI_ARADDR),
        .S00_AXI_arburst(engine_M_AXI_ARBURST),
        .S00_AXI_arcache({1'b0,1'b0,1'b1,1'b1}),
        .S00_AXI_arlen(engine_M_AXI_ARLEN),
        .S00_AXI_arlock(1'b0),
        .S00_AXI_arprot({1'b0,1'b0,1'b0}),
        .S00_AXI_arqos({1'b0,1'b0,1'b0,1'b0}),
        .S00_AXI_arready(engine_M_AXI_ARREADY),
        .S00_AXI_arsize(engine_M_AXI_ARSIZE),
        .S00_AXI_arvalid(engine_M_AXI_ARVALID),
        .S00_AXI_awaddr(engine_M_AXI_AWADDR),
        .S00_AXI_awburst(engine_M_AXI_AWBURST),
        .S00_AXI_awcache({1'b0,1'b0,1'b1,1'b1}),
        .S00_AXI_awlen(engine_M_AXI_AWLEN),
        .S00_AXI_awlock(1'b0),
        .S00_AXI_awprot({1'b0,1'b0,1'b0}),
        .S00_AXI_awqos({1'b0,1'b0,1'b0,1'b0}),
        .S00_AXI_awready(engine_M_AXI_AWREADY),
        .S00_AXI_awsize(engine_M_AXI_AWSIZE),
        .S00_AXI_awvalid(engine_M_AXI_AWVALID),
        .S00_AXI_bready(engine_M_AXI_BREADY),
        .S00_AXI_bresp(engine_M_AXI_BRESP),
        .S00_AXI_bvalid(engine_M_AXI_BVALID),
        .S00_AXI_rdata(engine_M_AXI_RDATA),
        .S00_AXI_rlast(engine_M_AXI_RLAST),
        .S00_AXI_rready(engine_M_AXI_RREADY),
        .S00_AXI_rresp(engine_M_AXI_RRESP),
        .S00_AXI_rvalid(engine_M_AXI_RVALID),
        .S00_AXI_wdata(engine_M_AXI_WDATA),
        .S00_AXI_wlast(engine_M_AXI_WLAST),
        .S00_AXI_wready(engine_M_AXI_WREADY),
        .S00_AXI_wstrb(engine_M_AXI_WSTRB),
        .S00_AXI_wvalid(engine_M_AXI_WVALID),
        .S01_AXI_araddr(shared_control_M_AXI_ARADDR),
        .S01_AXI_arburst(shared_control_M_AXI_ARBURST),
        .S01_AXI_arcache(shared_control_M_AXI_ARCACHE),
        .S01_AXI_arid(shared_control_M_AXI_ARID),
        .S01_AXI_arlen(shared_control_M_AXI_ARLEN),
        .S01_AXI_arlock(shared_control_M_AXI_ARLOCK),
        .S01_AXI_arprot(shared_control_M_AXI_ARPROT),
        .S01_AXI_arqos(shared_control_M_AXI_ARQOS),
        .S01_AXI_arready(shared_control_M_AXI_ARREADY),
        .S01_AXI_arsize(shared_control_M_AXI_ARSIZE),
        .S01_AXI_arvalid(shared_control_M_AXI_ARVALID),
        .S01_AXI_awaddr(shared_control_M_AXI_AWADDR),
        .S01_AXI_awburst(shared_control_M_AXI_AWBURST),
        .S01_AXI_awcache(shared_control_M_AXI_AWCACHE),
        .S01_AXI_awid(shared_control_M_AXI_AWID),
        .S01_AXI_awlen(shared_control_M_AXI_AWLEN),
        .S01_AXI_awlock(shared_control_M_AXI_AWLOCK),
        .S01_AXI_awprot(shared_control_M_AXI_AWPROT),
        .S01_AXI_awqos(shared_control_M_AXI_AWQOS),
        .S01_AXI_awready(shared_control_M_AXI_AWREADY),
        .S01_AXI_awsize(shared_control_M_AXI_AWSIZE),
        .S01_AXI_awvalid(shared_control_M_AXI_AWVALID),
        .S01_AXI_bid(shared_control_M_AXI_BID),
        .S01_AXI_bready(shared_control_M_AXI_BREADY),
        .S01_AXI_bresp(shared_control_M_AXI_BRESP),
        .S01_AXI_bvalid(shared_control_M_AXI_BVALID),
        .S01_AXI_rdata(shared_control_M_AXI_RDATA),
        .S01_AXI_rid(shared_control_M_AXI_RID),
        .S01_AXI_rlast(shared_control_M_AXI_RLAST),
        .S01_AXI_rready(shared_control_M_AXI_RREADY),
        .S01_AXI_rresp(shared_control_M_AXI_RRESP),
        .S01_AXI_rvalid(shared_control_M_AXI_RVALID),
        .S01_AXI_wdata(shared_control_M_AXI_WDATA),
        .S01_AXI_wlast(shared_control_M_AXI_WLAST),
        .S01_AXI_wready(shared_control_M_AXI_WREADY),
        .S01_AXI_wstrb(shared_control_M_AXI_WSTRB),
        .S01_AXI_wvalid(shared_control_M_AXI_WVALID),
        .aclk(ddr_clk_1),
        .aclk1(core_clk_1),
        .aclk2(eth_clk125_1),
        .aresetn(transport_resetn_1));
  qwen_fabric_loader_0 loader
       (.aclk(ddr_clk_1),
        .aresetn(transport_resetn_1),
        .m_axi_araddr(loader_M_AXI_ARADDR),
        .m_axi_arburst(loader_M_AXI_ARBURST),
        .m_axi_arcache(loader_M_AXI_ARCACHE),
        .m_axi_arid(loader_M_AXI_ARID),
        .m_axi_arlen(loader_M_AXI_ARLEN),
        .m_axi_arlock(loader_M_AXI_ARLOCK),
        .m_axi_arprot(loader_M_AXI_ARPROT),
        .m_axi_arqos(loader_M_AXI_ARQOS),
        .m_axi_arready(loader_M_AXI_ARREADY),
        .m_axi_arsize(loader_M_AXI_ARSIZE),
        .m_axi_arvalid(loader_M_AXI_ARVALID),
        .m_axi_awaddr(loader_M_AXI_AWADDR),
        .m_axi_awburst(loader_M_AXI_AWBURST),
        .m_axi_awcache(loader_M_AXI_AWCACHE),
        .m_axi_awid(loader_M_AXI_AWID),
        .m_axi_awlen(loader_M_AXI_AWLEN),
        .m_axi_awlock(loader_M_AXI_AWLOCK),
        .m_axi_awprot(loader_M_AXI_AWPROT),
        .m_axi_awqos(loader_M_AXI_AWQOS),
        .m_axi_awready(loader_M_AXI_AWREADY),
        .m_axi_awsize(loader_M_AXI_AWSIZE),
        .m_axi_awvalid(loader_M_AXI_AWVALID),
        .m_axi_bid(loader_M_AXI_BID),
        .m_axi_bready(loader_M_AXI_BREADY),
        .m_axi_bresp(loader_M_AXI_BRESP),
        .m_axi_bvalid(loader_M_AXI_BVALID),
        .m_axi_rdata(loader_M_AXI_RDATA),
        .m_axi_rid(loader_M_AXI_RID),
        .m_axi_rlast(loader_M_AXI_RLAST),
        .m_axi_rready(loader_M_AXI_RREADY),
        .m_axi_rresp(loader_M_AXI_RRESP),
        .m_axi_rvalid(loader_M_AXI_RVALID),
        .m_axi_wdata(loader_M_AXI_WDATA),
        .m_axi_wlast(loader_M_AXI_WLAST),
        .m_axi_wready(loader_M_AXI_WREADY),
        .m_axi_wstrb(loader_M_AXI_WSTRB),
        .m_axi_wvalid(loader_M_AXI_WVALID));
  qwen_fabric_runtime_clock_converter_0 runtime_clock_converter
       (.m_axi_aclk(ddr_clk_1),
        .m_axi_araddr(runtime_clock_converter_M_AXI_ARADDR),
        .m_axi_aresetn(transport_resetn_1),
        .m_axi_arprot(runtime_clock_converter_M_AXI_ARPROT),
        .m_axi_arready(runtime_clock_converter_M_AXI_ARREADY),
        .m_axi_arvalid(runtime_clock_converter_M_AXI_ARVALID),
        .m_axi_awaddr(runtime_clock_converter_M_AXI_AWADDR),
        .m_axi_awprot(runtime_clock_converter_M_AXI_AWPROT),
        .m_axi_awready(runtime_clock_converter_M_AXI_AWREADY),
        .m_axi_awvalid(runtime_clock_converter_M_AXI_AWVALID),
        .m_axi_bready(runtime_clock_converter_M_AXI_BREADY),
        .m_axi_bresp(runtime_clock_converter_M_AXI_BRESP),
        .m_axi_bvalid(runtime_clock_converter_M_AXI_BVALID),
        .m_axi_rdata(runtime_clock_converter_M_AXI_RDATA),
        .m_axi_rready(runtime_clock_converter_M_AXI_RREADY),
        .m_axi_rresp(runtime_clock_converter_M_AXI_RRESP),
        .m_axi_rvalid(runtime_clock_converter_M_AXI_RVALID),
        .m_axi_wdata(runtime_clock_converter_M_AXI_WDATA),
        .m_axi_wready(runtime_clock_converter_M_AXI_WREADY),
        .m_axi_wstrb(runtime_clock_converter_M_AXI_WSTRB),
        .m_axi_wvalid(runtime_clock_converter_M_AXI_WVALID),
        .s_axi_aclk(runtime_clk50_1),
        .s_axi_araddr(RUNTIME_AXI_1_ARADDR),
        .s_axi_aresetn(runtime_resetn_1),
        .s_axi_arprot(RUNTIME_AXI_1_ARPROT),
        .s_axi_arready(RUNTIME_AXI_1_ARREADY),
        .s_axi_arvalid(RUNTIME_AXI_1_ARVALID),
        .s_axi_awaddr(RUNTIME_AXI_1_AWADDR),
        .s_axi_awprot(RUNTIME_AXI_1_AWPROT),
        .s_axi_awready(RUNTIME_AXI_1_AWREADY),
        .s_axi_awvalid(RUNTIME_AXI_1_AWVALID),
        .s_axi_bready(RUNTIME_AXI_1_BREADY),
        .s_axi_bresp(RUNTIME_AXI_1_BRESP),
        .s_axi_bvalid(RUNTIME_AXI_1_BVALID),
        .s_axi_rdata(RUNTIME_AXI_1_RDATA),
        .s_axi_rready(RUNTIME_AXI_1_RREADY),
        .s_axi_rresp(RUNTIME_AXI_1_RRESP),
        .s_axi_rvalid(RUNTIME_AXI_1_RVALID),
        .s_axi_wdata(RUNTIME_AXI_1_WDATA),
        .s_axi_wready(RUNTIME_AXI_1_WREADY),
        .s_axi_wstrb(RUNTIME_AXI_1_WSTRB),
        .s_axi_wvalid(RUNTIME_AXI_1_WVALID));
  qwen_fabric_shared_control_0 shared_control
       (.b_araddr(shared_control_B_AXI_ARADDR),
        .b_arprot(shared_control_B_AXI_ARPROT),
        .b_arready(shared_control_B_AXI_ARREADY),
        .b_arvalid(shared_control_B_AXI_ARVALID),
        .b_awaddr(shared_control_B_AXI_AWADDR),
        .b_awprot(shared_control_B_AXI_AWPROT),
        .b_awready(shared_control_B_AXI_AWREADY),
        .b_awvalid(shared_control_B_AXI_AWVALID),
        .b_bready(shared_control_B_AXI_BREADY),
        .b_bresp(shared_control_B_AXI_BRESP),
        .b_bvalid(shared_control_B_AXI_BVALID),
        .b_rdata(shared_control_B_AXI_RDATA),
        .b_rready(shared_control_B_AXI_RREADY),
        .b_rresp(shared_control_B_AXI_RRESP),
        .b_rvalid(shared_control_B_AXI_RVALID),
        .b_wdata(shared_control_B_AXI_WDATA),
        .b_wready(shared_control_B_AXI_WREADY),
        .b_wstrb(shared_control_B_AXI_WSTRB),
        .b_wvalid(shared_control_B_AXI_WVALID),
        .board_reset_n(transport_resetn_1),
        .c_araddr(runtime_clock_converter_M_AXI_ARADDR),
        .c_arprot(runtime_clock_converter_M_AXI_ARPROT),
        .c_arready(runtime_clock_converter_M_AXI_ARREADY),
        .c_arvalid(runtime_clock_converter_M_AXI_ARVALID),
        .c_awaddr(runtime_clock_converter_M_AXI_AWADDR),
        .c_awprot(runtime_clock_converter_M_AXI_AWPROT),
        .c_awready(runtime_clock_converter_M_AXI_AWREADY),
        .c_awvalid(runtime_clock_converter_M_AXI_AWVALID),
        .c_bready(runtime_clock_converter_M_AXI_BREADY),
        .c_bresp(runtime_clock_converter_M_AXI_BRESP),
        .c_bvalid(runtime_clock_converter_M_AXI_BVALID),
        .c_rdata(runtime_clock_converter_M_AXI_RDATA),
        .c_rready(runtime_clock_converter_M_AXI_RREADY),
        .c_rresp(runtime_clock_converter_M_AXI_RRESP),
        .c_rvalid(runtime_clock_converter_M_AXI_RVALID),
        .c_wdata(runtime_clock_converter_M_AXI_WDATA),
        .c_wready(runtime_clock_converter_M_AXI_WREADY),
        .c_wstrb(runtime_clock_converter_M_AXI_WSTRB),
        .c_wvalid(runtime_clock_converter_M_AXI_WVALID),
        .drain_ack125(shared_control_drain_ack125),
        .drain_fault125(shared_control_drain_fault125),
        .freeze_disable(sct_freeze_disable_1),
        .freeze_precommit(sct_freeze_precommit_1),
        .h_araddr(loader_M_AXI_ARADDR),
        .h_arburst(loader_M_AXI_ARBURST),
        .h_arcache(loader_M_AXI_ARCACHE),
        .h_arid(loader_M_AXI_ARID),
        .h_arlen(loader_M_AXI_ARLEN),
        .h_arlock(loader_M_AXI_ARLOCK),
        .h_arprot(loader_M_AXI_ARPROT),
        .h_arqos(loader_M_AXI_ARQOS),
        .h_arready(loader_M_AXI_ARREADY),
        .h_arsize(loader_M_AXI_ARSIZE),
        .h_arvalid(loader_M_AXI_ARVALID),
        .h_awaddr(loader_M_AXI_AWADDR),
        .h_awburst(loader_M_AXI_AWBURST),
        .h_awcache(loader_M_AXI_AWCACHE),
        .h_awid(loader_M_AXI_AWID),
        .h_awlen(loader_M_AXI_AWLEN),
        .h_awlock(loader_M_AXI_AWLOCK),
        .h_awprot(loader_M_AXI_AWPROT),
        .h_awqos(loader_M_AXI_AWQOS),
        .h_awready(loader_M_AXI_AWREADY),
        .h_awsize(loader_M_AXI_AWSIZE),
        .h_awvalid(loader_M_AXI_AWVALID),
        .h_bid(loader_M_AXI_BID),
        .h_bready(loader_M_AXI_BREADY),
        .h_bresp(loader_M_AXI_BRESP),
        .h_bvalid(loader_M_AXI_BVALID),
        .h_rdata(loader_M_AXI_RDATA),
        .h_rid(loader_M_AXI_RID),
        .h_rlast(loader_M_AXI_RLAST),
        .h_rready(loader_M_AXI_RREADY),
        .h_rresp(loader_M_AXI_RRESP),
        .h_rvalid(loader_M_AXI_RVALID),
        .h_wdata(loader_M_AXI_WDATA),
        .h_wlast(loader_M_AXI_WLAST),
        .h_wready(loader_M_AXI_WREADY),
        .h_wstrb(loader_M_AXI_WSTRB),
        .h_wvalid(loader_M_AXI_WVALID),
        .host_clk(ddr_clk_1),
        .independent_fault100(sct_independent_fault100_1),
        .m_araddr(shared_control_M_AXI_ARADDR),
        .m_arburst(shared_control_M_AXI_ARBURST),
        .m_arcache(shared_control_M_AXI_ARCACHE),
        .m_arid(shared_control_M_AXI_ARID),
        .m_arlen(shared_control_M_AXI_ARLEN),
        .m_arlock(shared_control_M_AXI_ARLOCK),
        .m_arprot(shared_control_M_AXI_ARPROT),
        .m_arqos(shared_control_M_AXI_ARQOS),
        .m_arready(shared_control_M_AXI_ARREADY),
        .m_arsize(shared_control_M_AXI_ARSIZE),
        .m_arvalid(shared_control_M_AXI_ARVALID),
        .m_awaddr(shared_control_M_AXI_AWADDR),
        .m_awburst(shared_control_M_AXI_AWBURST),
        .m_awcache(shared_control_M_AXI_AWCACHE),
        .m_awid(shared_control_M_AXI_AWID),
        .m_awlen(shared_control_M_AXI_AWLEN),
        .m_awlock(shared_control_M_AXI_AWLOCK),
        .m_awprot(shared_control_M_AXI_AWPROT),
        .m_awqos(shared_control_M_AXI_AWQOS),
        .m_awready(shared_control_M_AXI_AWREADY),
        .m_awsize(shared_control_M_AXI_AWSIZE),
        .m_awvalid(shared_control_M_AXI_AWVALID),
        .m_bid(shared_control_M_AXI_BID),
        .m_bready(shared_control_M_AXI_BREADY),
        .m_bresp(shared_control_M_AXI_BRESP),
        .m_bvalid(shared_control_M_AXI_BVALID),
        .m_rdata(shared_control_M_AXI_RDATA),
        .m_rid(shared_control_M_AXI_RID),
        .m_rlast(shared_control_M_AXI_RLAST),
        .m_rready(shared_control_M_AXI_RREADY),
        .m_rresp(shared_control_M_AXI_RRESP),
        .m_rvalid(shared_control_M_AXI_RVALID),
        .m_wdata(shared_control_M_AXI_WDATA),
        .m_wlast(shared_control_M_AXI_WLAST),
        .m_wready(shared_control_M_AXI_WREADY),
        .m_wstrb(shared_control_M_AXI_WSTRB),
        .m_wvalid(shared_control_M_AXI_WVALID),
        .main_active(shared_control_main_active),
        .main_closed_ack(shared_control_main_closed_ack),
        .main_fault(shared_control_main_fault),
        .main_good(shared_control_main_good),
        .main_prepare(sct_main_prepare_1),
        .main_qualified(shared_control_main_qualified),
        .main_ready(shared_control_main_ready),
        .main_response_consumed(sct_main_response_consumed_1),
        .main_start(sct_main_start_1),
        .other_quiet100(sct_other_quiet100_1),
        .qualify_done(shared_control_qualify_done),
        .qualify_fault(shared_control_qualify_fault),
        .qualify_good(shared_control_qualify_good),
        .qualify_ready(shared_control_qualify_ready),
        .qualify_start(sct_qualify_start_1),
        .release_completion_toggle50(sct_release_completion_toggle50_1),
        .release_owned125(shared_control_release_owned125),
        .release_owned50(sct_release_owned50_1),
        .release_permit125(shared_control_release_permit125),
        .side_retire_ack(sct_side_retire_ack_1),
        .side_retire_req(shared_control_side_retire_req),
        .source_clk(eth_clk125_1),
        .source_reset_n(eth_resetn_1),
        .transport_fault100(shared_control_transport_fault100),
        .trusted_stop100(shared_control_trusted_stop100),
        .trusted_stop125(shared_control_trusted_stop125));
endmodule
