set_property IOSTANDARD LVCMOS33 [get_ports {eth_rxd[*] eth_rx_ctl eth_rxc eth_txd[*] eth_tx_ctl eth_txc eth_mdc eth_mdio}]
set_property PACKAGE_PIN F22 [get_ports eth_mdc]
set_property PACKAGE_PIN J20 [get_ports eth_mdio]
set_property PULLUP true [get_ports eth_mdio]
set_property PACKAGE_PIN K21 [get_ports eth_rxc]
set_property PACKAGE_PIN M14 [get_ports eth_rx_ctl]
set_property PACKAGE_PIN L14 [get_ports {eth_rxd[0]}]
set_property PACKAGE_PIN K15 [get_ports {eth_rxd[1]}]
set_property PACKAGE_PIN J14 [get_ports {eth_rxd[2]}]
set_property PACKAGE_PIN J15 [get_ports {eth_rxd[3]}]
set_property PACKAGE_PIN J16 [get_ports eth_txc]
set_property PACKAGE_PIN G20 [get_ports eth_tx_ctl]
set_property PACKAGE_PIN K16 [get_ports {eth_txd[0]}]
set_property PACKAGE_PIN K17 [get_ports {eth_txd[1]}]
set_property PACKAGE_PIN K18 [get_ports {eth_txd[2]}]
set_property PACKAGE_PIN H19 [get_ports {eth_txd[3]}]
set_property PACKAGE_PIN G21 [get_ports eth_rst_n]
set_property IOSTANDARD LVCMOS33 [get_ports eth_rst_n]
create_clock -period 8.000 -name rgmii_rx_clk [get_ports eth_rxc]
# MAC forwards the 90-degree (2ns) clock; disable the PHY internal TX delay.
create_generated_clock -name rgmii_tx_clk -source [get_pins ethernet/u_mmcm/CLKOUT1] -divide_by 1 [get_ports eth_txc]
# Explicit initial engineering budget: receiver setup/hold1ns, board skew0.
# This budget is not a measured PCB/PHY timing characterization.
set_output_delay -clock rgmii_tx_clk -max 1.000 [get_ports {eth_txd[*] eth_tx_ctl}]
set_output_delay -clock rgmii_tx_clk -min -1.000 [get_ports {eth_txd[*] eth_tx_ctl}]
set_output_delay -clock rgmii_tx_clk -clock_fall -max 1.000 -add_delay [get_ports {eth_txd[*] eth_tx_ctl}]
set_output_delay -clock rgmii_tx_clk -clock_fall -min -1.000 -add_delay [get_ports {eth_txd[*] eth_tx_ctl}]
# RX uses BUFIO sampling and BUFG for the MAC fabric clock.
create_clock -name rgmii_rx_virtual -period 8.000
set_input_delay -clock rgmii_rx_virtual -max -0.950 [get_ports {eth_rxd[*] eth_rx_ctl}]
set_input_delay -clock rgmii_rx_virtual -min -3.050 [get_ports {eth_rxd[*] eth_rx_ctl}]
set_input_delay -clock rgmii_rx_virtual -clock_fall -max -0.950 -add_delay [get_ports {eth_rxd[*] eth_rx_ctl}]
set_input_delay -clock rgmii_rx_virtual -clock_fall -min -3.050 -add_delay [get_ports {eth_rxd[*] eth_rx_ctl}]
set_false_path -rise_from [get_clocks rgmii_rx_virtual] -fall_to [get_clocks rgmii_rx_clk] -setup
set_false_path -fall_from [get_clocks rgmii_rx_virtual] -rise_to [get_clocks rgmii_rx_clk] -setup
set_false_path -rise_from [get_clocks rgmii_rx_virtual] -rise_to [get_clocks rgmii_rx_clk] -hold
set_false_path -fall_from [get_clocks rgmii_rx_virtual] -fall_to [get_clocks rgmii_rx_clk] -hold
set_multicycle_path -from [get_clocks rgmii_rx_virtual] -to [get_clocks rgmii_rx_clk] -setup 0
set_multicycle_path -from [get_clocks rgmii_rx_virtual] -to [get_clocks rgmii_rx_clk] -hold -1



# RX internal PHY delay enabled; 1.2 ns minimum setup/hold minus 0.25 ns PCB budget.
# Engineering interface budget requires physical validation; not measured board skew.

set_false_path -from [get_ports eth_mdio] -to [get_pins ethernet/mdio/mdio_sync1_reg/D]
set_false_path -to [get_ports {eth_rst_n eth_mdc eth_mdio}]
