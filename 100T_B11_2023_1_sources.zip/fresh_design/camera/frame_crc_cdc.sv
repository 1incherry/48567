// Completed-frame snapshot: {frame_sequence, byte_count, CRC32}. Reflected Ethernet/zlib CRC.
// Bundled data is held in source registers between frame events; toggle and data cross separately.
module frame_crc_cdc #(parameter DATA_BYTES=1)(
 input src_clk,src_rst_n,frame_sync,valid,input [15:0] data,
 input dst_clk,dst_rst_n,output reg [95:0] snapshot=0);
 function automatic [31:0] crc8(input [31:0] previous,input [7:0] value);
  reg [31:0] c;integer i;
  begin c=previous^{24'd0,value};for(i=0;i<8;i=i+1)c=c[0]?(c>>1)^32'hedb88320:c>>1;crc8=c;end
 endfunction
 reg [31:0] crc=32'hffffffff,count=0,seq=0;
 reg frame_prev=0,toggle=0;
 reg [95:0] held_snapshot=0;
 wire [31:0] next_crc=DATA_BYTES==1?crc8(crc,data[7:0]):crc8(crc8(crc,data[15:8]),data[7:0]);
 always @(posedge src_clk)begin
  frame_prev<=frame_sync;
  if(!src_rst_n)begin crc<=32'hffffffff;count<=0;seq<=0;frame_prev<=0;toggle<=0;held_snapshot<=0;end
  else if(frame_sync&&!frame_prev)begin
   held_snapshot<={seq+32'd1,count,crc^32'hffffffff};toggle<=!toggle;
   seq<=seq+1'b1;crc<=32'hffffffff;count<=0;
  end else if(valid)begin crc<=next_crc;count<=count+DATA_BYTES;end
 end
 (* ASYNC_REG="TRUE" *) reg [1:0] toggle_sync=0;
 (* ASYNC_REG="TRUE" *) reg [95:0] data_meta=0,data_sync=0;
 reg seen=0;reg [2:0] settle=0;
 always @(posedge dst_clk)begin
  toggle_sync<={toggle_sync[0],toggle};data_meta<=held_snapshot;data_sync<=data_meta;
  if(!dst_rst_n)begin toggle_sync<=0;data_meta<=0;data_sync<=0;seen<=0;settle<=0;snapshot<=0;end
  else if(toggle_sync[1]!=seen)begin seen<=toggle_sync[1];settle<=3;end
  else if(settle!=0)begin
   settle<=settle-1'b1;if(settle==1)snapshot<=data_sync;
  end
 end
endmodule
