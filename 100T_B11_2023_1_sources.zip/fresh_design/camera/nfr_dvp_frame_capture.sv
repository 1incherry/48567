`timescale 1ns/1ps
// Camera-domain complete-frame capture boundary. The memory backend must accept
// every valid pixel or record overflow; it cannot stall the DVP camera.
// commit_ready may assert only after all accepted memory writes have drained.
module nfr_dvp_frame_capture #(parameter ALLOW_TEST_SHAPE=0)(
 input wire clk,rst_n,input wire[7:0]camera_data,input wire camera_href,camera_vsync,
 input wire capture_request,release_frame,cancel,
 input wire[15:0]request_width,request_height,input wire[31:0]request_epoch,
 input wire memory_ready,output wire capture_ready,output reg memory_begin,
 output wire pixel_valid,input wire pixel_ready,output wire[15:0]pixel_data,output wire[31:0]pixel_address,
 output wire commit_valid,output reg commit_cancel,input wire commit_ready,commit_error,
 output wire capture_complete,output reg capture_error,output reg[31:0]frame_crc,epoch,
 output reg[15:0]completed_rows,bad_rows,min_line_bytes,max_line_bytes,
 output reg[31:0]wire_bytes,output wire frozen
);
 localparam IDLE=0,WAIT_VS=1,CAPTURE=2,COMMIT=3,HELD=4;
 reg[2:0]state;reg[7:0]sampled_data,high_byte;
 reg href,vsync,hprev,vprev,phase,failed,release_pending;
 reg[15:0]width,height,line_bytes;reg[31:0]crc,expected_bytes;
 wire rise_v=vsync&&!vprev,fall_h=!href&&hprev;
 wire shape_ok=ALLOW_TEST_SHAPE?(request_width>0&&request_width<=1920&&request_height>0&&request_height<=1080):
 ((request_width==640&&request_height==480)||(request_width==1920&&request_height==1080));
 assign capture_ready=state==IDLE&&memory_ready;
 assign pixel_valid=state==CAPTURE&&href&&phase&&!failed&&!cancel&&!release_frame;
 assign pixel_data={high_byte,sampled_data};
 assign pixel_address={completed_rows,12'b0}+{15'd0,line_bytes[15:1],1'b0};
 assign commit_valid=state==COMMIT;
 assign frozen=state==HELD;
 assign capture_complete=state==HELD&&!commit_cancel&&!capture_error&&!release_pending;
 function automatic[31:0]cb(input[31:0]c0,input[7:0]d);reg[31:0]c;integer k;begin c=c0^d;for(k=0;k<8;k=k+1)c=c[0]?(c>>1)^32'hedb88320:c>>1;cb=c;end endfunction
 always @(posedge clk)begin
  sampled_data<=camera_data;href<=camera_href;vsync<=camera_vsync;hprev<=href;vprev<=vsync;
  if(!rst_n)begin
   state<=IDLE;sampled_data<=0;high_byte<=0;href<=0;vsync<=0;hprev<=0;vprev<=0;phase<=0;failed<=0;release_pending<=0;
   width<=0;height<=0;line_bytes<=0;crc<=32'hffffffff;expected_bytes<=0;memory_begin<=0;commit_cancel<=0;
   capture_error<=0;frame_crc<=0;epoch<=0;completed_rows<=0;bad_rows<=0;min_line_bytes<=16'hffff;max_line_bytes<=0;wire_bytes<=0;
  end else begin
   memory_begin<=0;
   case(state)
    IDLE:if(capture_request&&capture_ready)begin
     width<=request_width;height<=request_height;epoch<=request_epoch;expected_bytes<=request_width*request_height*2;
     memory_begin<=1;capture_error<=0;failed<=!shape_ok;commit_cancel<=0;release_pending<=0;state<=WAIT_VS;
     completed_rows<=0;bad_rows<=0;min_line_bytes<=16'hffff;max_line_bytes<=0;wire_bytes<=0;line_bytes<=0;phase<=0;crc<=32'hffffffff;
    end
    WAIT_VS:if(rise_v)begin
     state<=CAPTURE;completed_rows<=0;bad_rows<=0;min_line_bytes<=16'hffff;max_line_bytes<=0;wire_bytes<=0;line_bytes<=0;phase<=0;crc<=32'hffffffff;
    end
    CAPTURE:begin
     if(href)begin
      crc<=cb(crc,sampled_data);wire_bytes<=wire_bytes+1'b1;line_bytes<=line_bytes+1'b1;phase<=!phase;
      if(!phase)high_byte<=sampled_data;
      if(line_bytes>=width*2||completed_rows>=height)failed<=1;
      if(pixel_valid&&!pixel_ready)failed<=1;
     end
     if(fall_h)begin
      completed_rows<=completed_rows+1'b1;line_bytes<=0;phase<=0;
      if(line_bytes!=width*2||phase)begin bad_rows<=bad_rows+1'b1;failed<=1;end
      if(line_bytes<min_line_bytes)min_line_bytes<=line_bytes;if(line_bytes>max_line_bytes)max_line_bytes<=line_bytes;
     end
     if(rise_v)begin
      frame_crc<=~crc;commit_cancel<=failed||href||(completed_rows+(fall_h?1:0))!=height||bad_rows!=0||(fall_h&&(line_bytes!=width*2||phase))||wire_bytes!=expected_bytes;
      state<=COMMIT;
     end
    end
    COMMIT:if(commit_ready)begin
     capture_error<=commit_cancel||commit_error;
     if(release_pending)state<=IDLE;else state<=HELD;
    end
    HELD:if(release_frame)begin state<=IDLE;release_pending<=0;end
    default:begin state<=COMMIT;commit_cancel<=1;release_pending<=1;end
   endcase
   if((cancel||release_frame)&&(state==WAIT_VS||state==CAPTURE))begin
    state<=COMMIT;commit_cancel<=1;release_pending<=release_frame;frame_crc<=~crc;
   end else if((cancel||release_frame)&&state==COMMIT)begin commit_cancel<=1;if(release_frame)release_pending<=1;end
  end
 end
endmodule
