`timescale 1ns/1ps
// Single immutable camera frame in native MIG memory, UI-clock domain.
// Native MIG has no B response. Publication requires a complete DDR read-back
// CRC, not merely command/write-data acceptance. Memory is private to this module.
// fifo_data is FWFT: 8 chronological RGB565 pixels, first in bits 127:112.
module nfr_mig_frame_store_replay #(
 parameter [26:0] FRAME_BASE_WORD=0,
 parameter integer TIMEOUT_CYCLES=1000000,
 parameter integer ALLOW_TEST_SHAPE=0
)(
 input wire clk,rst_n,calibrated,
 input wire frame_start,input wire[15:0]frame_width,frame_height,
 input wire frame_replay,input wire[31:0]replay_expected_crc,
 output wire frame_ready,
 input wire[127:0]fifo_data,input wire fifo_valid,output wire fifo_pop,
 input wire capture_commit,capture_cancel,input wire[31:0]capture_crc,
 output reg commit_ack,commit_error,output reg frozen,output reg[31:0]sealed_crc,
 input wire release_frame,
 input wire block_request,input wire[31:0]block_offset,output wire block_accept,
 output wire[7:0]block_data,output wire block_valid,block_last,input wire block_ready,output reg block_error,
 output reg[26:0]app_addr,output reg[2:0]app_cmd,output reg app_en,input wire app_rdy,
 output wire[127:0]app_wdf_data,output wire[15:0]app_wdf_mask,output wire app_wdf_end,app_wdf_wren,input wire app_wdf_rdy,
 input wire[127:0]app_rd_data,input wire app_rd_data_valid,app_rd_data_end,
 output reg[31:0]write_beats,read_beats,maximum_write_stall,maximum_read_stall,
 output wire[3:0]debug_state
);
 localparam IDLE=0,CAP=1,VREQ=2,VWAIT=3,VBYTES=4,HELD=5,BREQ=6,BWAIT=7,BBYTES=8,FAIL=9,ABORT_WAIT=10;
 reg[3:0]state;
 reg[15:0]width,height,beats_per_row,wr_row,wr_col,rd_row,rd_col;
 reg[31:0]total_beats,total_bytes,expected_crc,crc,next_offset,timeout_count,stall_count;
 reg eof_seen,cancel_seen,release_pending,read_outstanding;
 reg[127:0]read_word;
 reg[3:0]byte_index;
 reg[10:0]block_index;
 wire shape_ok=ALLOW_TEST_SHAPE?(frame_width>0&&frame_width<=1920&&frame_width[2:0]==0&&frame_height>0&&frame_height<=1080):
 ((frame_width==640&&frame_height==480)||(frame_width==1920&&frame_height==1080));
 wire write_fire=state==CAP&&fifo_valid&&app_rdy&&app_wdf_rdy&&write_beats<total_beats&&!(capture_commit&&capture_cancel)&&!release_frame&&!cancel_seen;
 assign frame_ready=state==IDLE&&calibrated;
 assign fifo_pop=write_fire;
 assign app_wdf_data=fifo_data;assign app_wdf_mask=0;
 assign app_wdf_wren=write_fire;assign app_wdf_end=write_fire;
 assign block_accept=state==HELD&&frozen&&!block_error&&block_request&&block_offset==next_offset&&block_offset+1024<=total_bytes&&!release_frame;
 assign block_data=read_word[127:120];
 assign block_valid=state==BBYTES&&!release_pending&&!release_frame;
 assign block_last=block_valid&&block_index==1023;
 assign debug_state=state;
 function automatic[31:0]cb(input[31:0]c0,input[7:0]d);reg[31:0]c;integer k;begin c=c0^d;for(k=0;k<8;k=k+1)c=c[0]?(c>>1)^32'hedb88320:c>>1;cb=c;end endfunction
 always @*begin
  app_addr=FRAME_BASE_WORD+({11'd0,wr_row}<<11)+({11'd0,wr_col}<<3);app_cmd=0;app_en=write_fire;
  if(state==VREQ||state==BREQ)begin
   app_addr=FRAME_BASE_WORD+({11'd0,rd_row}<<11)+({11'd0,rd_col}<<3);app_cmd=1;app_en=!release_frame&&!release_pending;
  end
 end
 task automatic next_read_position;begin
  if(rd_col==beats_per_row-1)begin rd_col<=0;rd_row<=rd_row+1'b1;end else rd_col<=rd_col+1'b1;
 end endtask
 task automatic fail_frame;begin commit_error<=1;frozen<=0;commit_ack<=1;state<=FAIL;timeout_count<=0;end endtask
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;width<=0;height<=0;beats_per_row<=0;wr_row<=0;wr_col<=0;rd_row<=0;rd_col<=0;
   total_beats<=0;total_bytes<=0;expected_crc<=0;crc<=32'hffffffff;next_offset<=0;timeout_count<=0;stall_count<=0;
   eof_seen<=0;cancel_seen<=0;release_pending<=0;read_outstanding<=0;read_word<=0;byte_index<=0;block_index<=0;
   commit_ack<=0;commit_error<=0;frozen<=0;sealed_crc<=0;block_error<=0;write_beats<=0;read_beats<=0;maximum_write_stall<=0;maximum_read_stall<=0;
  end else begin
   if(!capture_commit&&state==IDLE)commit_ack<=0;
   // Latched cancellation never permits a partially read frame to be reused.
   if(release_frame&&state!=IDLE)begin release_pending<=1;frozen<=0;end
   if(state==CAP&&fifo_valid&&!write_fire)begin
    stall_count<=stall_count+1'b1;if(stall_count+1>maximum_write_stall)maximum_write_stall<=stall_count+1'b1;
   end else if(state==VREQ||state==VWAIT||state==BREQ||state==BWAIT)begin
    stall_count<=stall_count+1'b1;if(stall_count+1>maximum_read_stall)maximum_read_stall<=stall_count+1'b1;
   end else stall_count<=0;
   case(state)
    IDLE:if(frame_start&&frame_ready)begin
     width<=frame_width;height<=frame_height;beats_per_row<=frame_width>>3;
     total_beats<=(frame_width>>3)*frame_height;total_bytes<=frame_width*frame_height*2;
     wr_row<=0;wr_col<=0;rd_row<=0;rd_col<=0;write_beats<=0;read_beats<=0;maximum_write_stall<=0;maximum_read_stall<=0;
     expected_crc<=0;crc<=32'hffffffff;next_offset<=0;timeout_count<=0;eof_seen<=0;cancel_seen<=0;release_pending<=0;read_outstanding<=0;
     commit_ack<=0;commit_error<=0;frozen<=0;block_error<=0;sealed_crc<=0;
     // Trusted-PC raw replay uses the SAME DDR verifier and sender path.
     // Only the fixed production 640x480 window may bypass camera writes.
     if(!shape_ok||(frame_replay&&(frame_width!=640||frame_height!=480)))fail_frame();
     else if(frame_replay)begin expected_crc<=replay_expected_crc;eof_seen<=1;state<=VREQ;end
     else state<=CAP;
    end
    CAP:begin
     if(write_fire)begin
      write_beats<=write_beats+1'b1;timeout_count<=0;
      if(wr_col==beats_per_row-1)begin wr_col<=0;wr_row<=wr_row+1'b1;end else wr_col<=wr_col+1'b1;
     end
     if(capture_commit&&!eof_seen)begin eof_seen<=1;cancel_seen<=capture_cancel;expected_crc<=capture_crc;timeout_count<=0;end
     if((eof_seen&&cancel_seen)||(capture_commit&&capture_cancel)||release_pending||release_frame)begin fail_frame();end
     else if(eof_seen)begin
      if(write_beats==total_beats)begin state<=VREQ;rd_row<=0;rd_col<=0;crc<=32'hffffffff;timeout_count<=0;end
      else if(!write_fire)begin if(timeout_count==TIMEOUT_CYCLES-1)fail_frame();else timeout_count<=timeout_count+1'b1;end
     end
    end
    VREQ,BREQ:begin
     if(release_pending||release_frame)begin state<=ABORT_WAIT;end
     else if(app_en&&app_rdy)begin read_outstanding<=1;timeout_count<=0;if(state==VREQ)state<=VWAIT;else state<=BWAIT;end
     else if(timeout_count==TIMEOUT_CYCLES-1)begin block_error<=state==BREQ;fail_frame();end
     else timeout_count<=timeout_count+1'b1;
    end
    VWAIT,BWAIT:begin
     if(app_rd_data_valid)begin
      read_outstanding<=0;read_beats<=read_beats+1'b1;read_word<=app_rd_data;byte_index<=0;timeout_count<=0;
      if(!app_rd_data_end)begin block_error<=state==BWAIT;fail_frame();end
      else if(release_pending||release_frame)state<=ABORT_WAIT;
      else if(state==VWAIT)state<=VBYTES;else state<=BBYTES;
     end else if(timeout_count==TIMEOUT_CYCLES-1)begin
      // An accepted read cannot be abandoned and reused: quarantine until response.
      commit_error<=1;block_error<=state==BWAIT;frozen<=0;state<=ABORT_WAIT;
     end else timeout_count<=timeout_count+1'b1;
    end
    VBYTES:begin
     crc<=cb(crc,read_word[127:120]);read_word<={read_word[119:0],8'd0};byte_index<=byte_index+1'b1;
     if(release_pending||release_frame)state<=ABORT_WAIT;
     else if(byte_index==15)begin
      next_read_position();
      if(rd_row==height-1&&rd_col==beats_per_row-1)begin
       sealed_crc<=~cb(crc,read_word[127:120]);commit_ack<=1;
       if((~cb(crc,read_word[127:120]))!=expected_crc)fail_frame();
       else begin frozen<=1;state<=HELD;rd_row<=0;rd_col<=0;end
      end else state<=VREQ;
     end
    end
    HELD:begin
     if(release_pending||release_frame)begin state<=IDLE;release_pending<=0;frozen<=0;end
     else if(block_request)begin
      if(!block_accept)block_error<=1;
      else begin block_index<=0;byte_index<=0;state<=BREQ;timeout_count<=0;end
     end
    end
    BBYTES:if(release_pending||release_frame)state<=ABORT_WAIT;
    else if(block_valid&&block_ready)begin
     read_word<={read_word[119:0],8'd0};byte_index<=byte_index+1'b1;block_index<=block_index+1'b1;
     if(byte_index==15)begin next_read_position();if(block_index==1023)begin next_offset<=next_offset+1024;state<=HELD;end else begin state<=BREQ;timeout_count<=0;end end
    end
    FAIL:if(release_pending||release_frame)begin if(read_outstanding)state<=ABORT_WAIT;else begin state<=IDLE;release_pending<=0;end end
    ABORT_WAIT:begin
     if(app_rd_data_valid)read_outstanding<=0;
     if(!read_outstanding)begin commit_ack<=1;commit_error<=1;state<=FAIL;end
    end
    default:fail_frame();
   endcase
  end
 end
endmodule
