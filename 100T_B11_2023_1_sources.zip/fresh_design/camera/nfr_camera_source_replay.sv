`timescale 1ns/1ps
// Three-domain frozen camera source. The sensor mode must already match REQUEST.
// Request/commit/release are closed-loop mailboxes: all bundled fields remain
// stable until their response and must have explicit max-delay/bus-skew limits.
module nfr_camera_source_replay #(
 parameter [26:0] FRAME_BASE_WORD=27'h7800000,
 parameter integer FIFO_RESET_UI_CYCLES=400,
 parameter integer TIMEOUT_CYCLES=1000000
)(
 input wire clk,ui_clk,camera_clk,rst_n,ui_rst_n,camera_rst_n,calibrated,
 input wire[7:0]camera_data,input wire camera_href,camera_vsync,
 input wire camera_configured,input wire[15:0]configured_width,configured_height,
 input wire capture_request,release_frame,input wire[15:0]width,height,input wire[7:0]flags,
 input wire capture_replay,capture_replay_valid,input wire[31:0]replay_expected_crc,
 output wire capture_ready,output reg capture_complete,capture_error,output reg[31:0]capture_crc,
 input wire block_request,input wire[31:0]block_offset,output wire block_accept,
 output wire[7:0]block_data,output wire block_valid,block_last,input wire block_ready,output reg block_error,
 output wire[26:0]app_addr,output wire[2:0]app_cmd,output wire app_en,input wire app_rdy,
 output wire[127:0]app_wdf_data,output wire[15:0]app_wdf_mask,output wire app_wdf_end,app_wdf_wren,input wire app_wdf_rdy,
 input wire[127:0]app_rd_data,input wire app_rd_data_valid,app_rd_data_end,
 output wire[31:0]write_beats,read_beats,maximum_write_stall,maximum_read_stall,
 output wire[15:0]debug_status
);
 // Any participating domain reset aborts the complete mailbox epoch. Reset
 // assertion is asynchronous; each domain releases only after three own edges.
 wire common_reset=!rst_n||!ui_rst_n||!camera_rst_n;
 (* ASYNC_REG="TRUE" *)reg[2:0]tx_reset_pipe=7,ui_reset_pipe=7,cam_reset_pipe=7;
 always @(posedge clk or posedge common_reset)if(common_reset)tx_reset_pipe<=7;else tx_reset_pipe<={tx_reset_pipe[1:0],1'b0};
 always @(posedge ui_clk or posedge common_reset)if(common_reset)ui_reset_pipe<=7;else ui_reset_pipe<={ui_reset_pipe[1:0],1'b0};
 always @(posedge camera_clk or posedge common_reset)if(common_reset)cam_reset_pipe<=7;else cam_reset_pipe<={cam_reset_pipe[1:0],1'b0};
 wire tx_run=!tx_reset_pipe[2],ui_run=!ui_reset_pipe[2],cam_run=!cam_reset_pipe[2];
 localparam TIDLE=0,TWAIT=1,THELD=2,TBLOCK=3,TSTREAM=4,TRELEASE=5,TLOAD=6;
 reg[2:0]ts;
 reg req_toggle,release_toggle,block_toggle;
 reg[15:0]held_width,held_height;reg[31:0]held_epoch,held_offset;
 (* DONT_TOUCH="TRUE" *)reg held_replay;(* DONT_TOUCH="TRUE" *)reg[31:0]held_replay_crc;
 (* ASYNC_REG="TRUE" *)reg[2:0]result_sync,block_sync,release_ack_sync;
 (* ASYNC_REG="TRUE" *)reg[1:0]ui_idle_sync;
 reg result_seen,block_seen;reg[10:0]tx_byte;
 (* DONT_TOUCH="TRUE" *)reg tx_block_error;
 // Dual-clock packet RAM: write side has exclusive ownership until block_done.
 (* ram_style="block" *)reg[7:0]packet_ram[0:1023];
 reg[7:0]packet_q;
 wire ui_idle;reg result_toggle,block_done_toggle,release_ack;reg[31:0]ui_crc;reg ui_error,ui_block_error;
 wire tx_read_fire=ts==TSTREAM&&block_ready;
 wire packet_re=(ts==TLOAD&&!tx_block_error)||(tx_read_fire&&tx_byte!=1023);
 wire[9:0]packet_raddr=ts==TLOAD?10'd0:tx_byte[9:0]+10'd1;
 always @(posedge clk)if(packet_re)packet_q<=packet_ram[packet_raddr];
 assign capture_ready=ts==TIDLE&&ui_idle_sync[1];
 assign block_accept=ts==THELD&&capture_complete&&!capture_error&&!block_error&&block_request;
 assign block_data=packet_q;assign block_valid=ts==TSTREAM&&!release_frame;assign block_last=block_valid&&tx_byte==1023;
 always @(posedge clk)begin
  ui_idle_sync<={ui_idle_sync[0],ui_idle};result_sync<={result_sync[1:0],result_toggle};block_sync<={block_sync[1:0],block_done_toggle};release_ack_sync<={release_ack_sync[1:0],release_ack};
  if(!tx_run)begin
   ts<=TIDLE;req_toggle<=0;release_toggle<=0;block_toggle<=0;held_width<=0;held_height<=0;held_epoch<=0;held_offset<=0;held_replay<=0;held_replay_crc<=0;
   result_sync<=0;block_sync<=0;release_ack_sync<=0;ui_idle_sync<=0;result_seen<=0;block_seen<=0;tx_byte<=0;tx_block_error<=0;
   capture_complete<=0;capture_error<=0;capture_crc<=0;block_error<=0;
  end else begin
   case(ts)
    TIDLE:if(capture_request&&capture_ready)begin
     capture_complete<=0;capture_error<=0;capture_crc<=0;block_error<=0;
     if(flags!=0||(capture_replay?(!capture_replay_valid||width!=640||height!=480):(!camera_configured||width!=configured_width||height!=configured_height||!((width==640&&height==480)||(width==1920&&height==1080)))))begin capture_error<=1;ts<=THELD;end
     else begin held_replay<=capture_replay;held_replay_crc<=replay_expected_crc;held_width<=width;held_height<=height;held_epoch<=held_epoch+1'b1;req_toggle<=!req_toggle;ts<=TWAIT;end
    end
    TWAIT:if(result_sync[2]!=result_seen)begin
     result_seen<=result_sync[2];capture_crc<=ui_crc;capture_error<=ui_error;capture_complete<=!ui_error;ts<=THELD;
    end
    THELD:if(block_accept)begin held_offset<=block_offset;block_toggle<=!block_toggle;ts<=TBLOCK;end
    TBLOCK:if(block_sync[2]!=block_seen)begin
     block_seen<=block_sync[2];tx_block_error<=ui_block_error;ts<=TLOAD;
    end
    TLOAD:begin block_error<=tx_block_error;if(tx_block_error)ts<=THELD;else begin tx_byte<=0;ts<=TSTREAM;end end
    TSTREAM:if(tx_read_fire)begin
     if(tx_byte==1023)ts<=THELD;
     else begin tx_byte<=tx_byte+1'b1;end
    end
    TRELEASE:if(release_ack_sync[2]==release_toggle&&ui_idle_sync[1])begin
     ts<=TIDLE;capture_complete<=0;capture_error<=0;block_error<=0;
     result_seen<=result_sync[2];block_seen<=block_sync[2];
    end
    default:ts<=TRELEASE;
   endcase
   if(release_frame&&ts!=TIDLE&&ts!=TRELEASE)begin release_toggle<=!release_toggle;ts<=TRELEASE;capture_complete<=0;end
  end
 end
 // Native UI control. Reset FIFO >=4us at 100MHz, then wait both reset-busy.
 localparam UIDLE=0,URESET=1,UWAIT=2,UACTIVE=3,UHELD=4,URELEASE=5;
 reg[2:0]us;reg[15:0]reset_count;
 (* ASYNC_REG="TRUE" *)reg[2:0]req_sync,release_sync,block_req_sync,cam_commit_sync;
 (* ASYNC_REG="TRUE" *)reg[1:0]cam_idle_sync,wrbusy_sync;
 reg req_seen,release_seen,block_req_seen;
 // Camera commit payload is copied once into UI-owned immutable registers.
 // Three synchronized valid edges precede this capture; the source holds
 // every field until the final ACK. Store consumes valid one cycle later.
 reg ui_cam_commit;(* DONT_TOUCH="TRUE" *)reg ui_cam_cancel;(* DONT_TOUCH="TRUE" *)reg[31:0]ui_cam_crc;
 (* DONT_TOUCH="TRUE" *)reg[15:0]ui_width,ui_height;(* DONT_TOUCH="TRUE" *)reg[31:0]ui_epoch;
 reg cam_request_toggle,cam_release_toggle,store_start,store_release;
 (* DONT_TOUCH="TRUE" *)reg ui_replay;(* DONT_TOUCH="TRUE" *)reg[31:0]ui_replay_crc;
 reg fifo_reset;
 // The native FIFO reset asserts asynchronously. Its external write-enable
 // gate must release on camera edges too; never use raw UI fifo_reset there.
 wire fifo_global_reset=fifo_reset||!ui_run||!cam_run;
 (* ASYNC_REG="TRUE" *)reg[2:0]fifo_write_reset_pipe=7;
 always @(posedge camera_clk or posedge fifo_global_reset)
  if(fifo_global_reset)fifo_write_reset_pipe<=7;
  else fifo_write_reset_pipe<={fifo_write_reset_pipe[1:0],1'b0};
 wire fifo_write_ready=!fifo_write_reset_pipe[2];
 wire fifo_wrbusy,fifo_rdbusy,fifo_full,fifo_empty,fifo_progfull;
 wire[127:0]fifo_data;wire fifo_pop;
 wire store_ready,store_ack,store_error,store_frozen;wire[31:0]store_crc;
 wire ui_baccept,ui_bvalid,ui_blast,store_block_error;wire[7:0]ui_bdata;reg ui_breq;reg[31:0]ui_offset;reg[10:0]ui_index;reg ui_loading;
 wire[3:0]store_state;
 wire cam_commit,cam_cancel,cam_ready;wire[31:0]cam_crc;
 assign ui_idle=us==UIDLE&&store_ready&&cam_idle_sync[1];
 always @(posedge ui_clk)begin
  req_sync<={req_sync[1:0],req_toggle};release_sync<={release_sync[1:0],release_toggle};block_req_sync<={block_req_sync[1:0],block_toggle};
  cam_commit_sync<={cam_commit_sync[1:0],cam_commit};cam_idle_sync<={cam_idle_sync[0],cam_ready};wrbusy_sync<={wrbusy_sync[0],fifo_wrbusy};
  store_start<=0;store_release<=0;
  if(!ui_run)begin
   us<=UIDLE;reset_count<=0;req_sync<=0;release_sync<=0;block_req_sync<=0;cam_commit_sync<=0;cam_idle_sync<=0;wrbusy_sync<=3;
   req_seen<=0;release_seen<=0;block_req_seen<=0;ui_width<=0;ui_height<=0;ui_epoch<=0;ui_replay<=0;ui_replay_crc<=0;cam_request_toggle<=0;cam_release_toggle<=0;
   store_start<=0;store_release<=0;ui_cam_commit<=0;ui_cam_cancel<=0;ui_cam_crc<=0;fifo_reset<=1;result_toggle<=0;block_done_toggle<=0;release_ack<=0;ui_crc<=0;ui_error<=0;ui_block_error<=0;
   ui_breq<=0;ui_offset<=0;ui_index<=0;ui_loading<=0;
  end else begin
   if(us==UACTIVE&&!ui_replay&&!ui_cam_commit&&cam_commit_sync[2])begin ui_cam_crc<=cam_crc;ui_cam_cancel<=cam_cancel;ui_cam_commit<=1;end
   case(us)
    UIDLE:if(req_sync[2]!=req_seen&&store_ready&&cam_idle_sync[1])begin
     req_seen<=req_sync[2];ui_width<=held_width;ui_height<=held_height;ui_epoch<=held_epoch;ui_replay<=held_replay;ui_replay_crc<=held_replay_crc;
     fifo_reset<=1;reset_count<=0;ui_cam_commit<=0;ui_cam_cancel<=0;ui_cam_crc<=0;ui_error<=0;ui_block_error<=0;us<=URESET;
    end
    URESET:if(reset_count==FIFO_RESET_UI_CYCLES-1)begin fifo_reset<=0;reset_count<=0;us<=UWAIT;end else reset_count<=reset_count+1'b1;
    UWAIT:if(!fifo_rdbusy&&!wrbusy_sync[1]&&reset_count>=32)begin
     store_start<=1;if(!ui_replay)cam_request_toggle<=!cam_request_toggle;us<=UACTIVE;
    end else if(reset_count!=65535)reset_count<=reset_count+1'b1;
    UACTIVE:if(store_ack)begin ui_crc<=store_crc;ui_error<=store_error;result_toggle<=!result_toggle;us<=UHELD;end
    UHELD:begin
     if(block_req_sync[2]!=block_req_seen&&!ui_loading&&!ui_breq)begin
      block_req_seen<=block_req_sync[2];ui_offset<=held_offset;ui_index<=0;ui_breq<=1;
     end
     if(ui_baccept)begin ui_breq<=0;ui_loading<=1;end
     if(ui_loading&&ui_bvalid)begin
      packet_ram[ui_index[9:0]]<=ui_bdata;ui_index<=ui_index+1'b1;
      if(ui_blast)begin ui_loading<=0;ui_block_error<=0;block_done_toggle<=!block_done_toggle;end
     end
     if(store_block_error&&(ui_loading||ui_breq))begin
      ui_loading<=0;ui_breq<=0;ui_block_error<=1;block_done_toggle<=!block_done_toggle;
     end
    end
    URELEASE:if(store_ready&&cam_idle_sync[1]&&!cam_commit_sync[2])begin us<=UIDLE;ui_loading<=0;ui_breq<=0;release_ack<=release_seen;req_seen<=req_sync[2];end
    default:us<=URELEASE;
   endcase
   if(release_sync[2]!=release_seen)begin
    release_seen<=release_sync[2];ui_cam_commit<=0;store_release<=1;if(!ui_replay)cam_release_toggle<=!cam_release_toggle;us<=URELEASE;ui_loading<=0;ui_breq<=0;
   end
  end
 end
 // Camera arm/commit CDC: metadata does not change until UI release completes.
 (* ASYNC_REG="TRUE" *)reg[2:0]cam_req_sync,cam_rel_sync,cam_ack_sync;
 (* ASYNC_REG="TRUE" *)reg[1:0]cam_store_error_sync;
 reg cam_req_seen,cam_rel_seen,cam_arm,cam_release;
 (* DONT_TOUCH="TRUE" *)reg[15:0]cam_width,cam_height;
 (* DONT_TOUCH="TRUE" *)reg[31:0]cam_epoch_meta;
 wire px_valid;wire[15:0]px_data;wire[31:0]px_addr;wire cam_complete,cam_error,cam_frozen;wire[15:0]rows,bad,min_bytes,max_bytes;wire[31:0]wire_bytes,cam_epoch;
 always @(posedge camera_clk)begin
  cam_req_sync<={cam_req_sync[1:0],cam_request_toggle};cam_rel_sync<={cam_rel_sync[1:0],cam_release_toggle};cam_ack_sync<={cam_ack_sync[1:0],store_ack||(us==URELEASE&&store_ready)};
  cam_store_error_sync<={cam_store_error_sync[0],store_error||(us==URELEASE)};
  cam_arm<=0;cam_release<=0;
  if(!cam_run)begin cam_req_sync<=0;cam_rel_sync<=0;cam_ack_sync<=0;cam_store_error_sync<=0;cam_req_seen<=0;cam_rel_seen<=0;cam_arm<=0;cam_release<=0;cam_width<=0;cam_height<=0;cam_epoch_meta<=0;end
  else begin
   if(cam_rel_sync[2]!=cam_rel_seen)begin cam_rel_seen<=cam_rel_sync[2];cam_req_seen<=cam_req_sync[2];cam_release<=1;end
   else if(cam_req_sync[2]!=cam_req_seen&&cam_ready)begin cam_req_seen<=cam_req_sync[2];cam_width<=ui_width;cam_height<=ui_height;cam_epoch_meta<=ui_epoch;cam_arm<=1;end
  end
 end
 nfr_dvp_frame_capture camera_capture(.clk(camera_clk),.rst_n(cam_run),.camera_data(camera_data),.camera_href(camera_href),.camera_vsync(camera_vsync),.capture_request(cam_arm),.release_frame(cam_release),.cancel(1'b0),.request_width(cam_width),.request_height(cam_height),.request_epoch(cam_epoch_meta),.memory_ready(1'b1),.capture_ready(cam_ready),.memory_begin(),.pixel_valid(px_valid),.pixel_ready(!fifo_progfull&&!fifo_full&&!fifo_wrbusy&&fifo_write_ready),.pixel_data(px_data),.pixel_address(px_addr),.commit_valid(cam_commit),.commit_cancel(cam_cancel),.commit_ready(cam_ack_sync[2]),.commit_error(cam_store_error_sync[1]),.capture_complete(cam_complete),.capture_error(cam_error),.frame_crc(cam_crc),.epoch(cam_epoch),.completed_rows(rows),.bad_rows(bad),.min_line_bytes(min_bytes),.max_line_bytes(max_bytes),.wire_bytes(wire_bytes),.frozen(cam_frozen));
 // Existing verified FIFO IP: 4096x16 -> 512x128, FWFT. Names are historical:
 // ddr_fifo_rd is the CAMERA input FIFO (not the opposite display FIFO).
 ddr_fifo_rd capture_fifo(.rst(fifo_global_reset),.wr_clk(camera_clk),.rd_clk(ui_clk),.din(px_data),.wr_en(px_valid&&!fifo_progfull&&!fifo_full&&!fifo_wrbusy&&fifo_write_ready),.rd_en(fifo_pop),.dout(fifo_data),.full(fifo_full),.empty(fifo_empty),.prog_full(fifo_progfull),.wr_rst_busy(fifo_wrbusy),.rd_rst_busy(fifo_rdbusy));
 nfr_mig_frame_store_replay #(.FRAME_BASE_WORD(FRAME_BASE_WORD),.TIMEOUT_CYCLES(TIMEOUT_CYCLES))store(.clk(ui_clk),.rst_n(ui_run),.calibrated(calibrated),.frame_start(store_start),.frame_replay(ui_replay),.replay_expected_crc(ui_replay_crc),.frame_width(ui_width),.frame_height(ui_height),.frame_ready(store_ready),.fifo_data(fifo_data),.fifo_valid(!fifo_empty&&!fifo_rdbusy&&!fifo_reset),.fifo_pop(fifo_pop),.capture_commit(ui_cam_commit),.capture_cancel(ui_cam_cancel),.capture_crc(ui_cam_crc),.commit_ack(store_ack),.commit_error(store_error),.frozen(store_frozen),.sealed_crc(store_crc),.release_frame(store_release),.block_request(ui_breq),.block_offset(ui_offset),.block_accept(ui_baccept),.block_data(ui_bdata),.block_valid(ui_bvalid),.block_last(ui_blast),.block_ready(ui_loading),.block_error(store_block_error),.app_addr(app_addr),.app_cmd(app_cmd),.app_en(app_en),.app_rdy(app_rdy),.app_wdf_data(app_wdf_data),.app_wdf_mask(app_wdf_mask),.app_wdf_end(app_wdf_end),.app_wdf_wren(app_wdf_wren),.app_wdf_rdy(app_wdf_rdy),.app_rd_data(app_rd_data),.app_rd_data_valid(app_rd_data_valid),.app_rd_data_end(app_rd_data_end),.write_beats(write_beats),.read_beats(read_beats),.maximum_write_stall(maximum_write_stall),.maximum_read_stall(maximum_read_stall),.debug_state(store_state));
 assign debug_status={store_state,us,ts,fifo_progfull,fifo_full,fifo_rdbusy,fifo_wrbusy,store_error,store_frozen};
endmodule
