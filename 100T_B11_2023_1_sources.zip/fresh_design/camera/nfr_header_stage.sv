`timescale 1ns/1ps
// Final destination capture for a source-held mailbox. Its valid has already
// crossed three synchronizer FFs. The source holds every header bit until ack.
// Capture the complete word once, then use only this clock's registered copy.
module nfr_header_stage(input wire clk,rst_n,input wire source_valid,input wire[383:0]source_header,output wire source_release,output reg header_valid,output reg[383:0]header,input wire header_release);
 reg seen;
 assign source_release=header_valid&&header_release;
 always @(posedge clk)begin
  if(!rst_n)begin seen<=0;header_valid<=0;header<=0;end
  else begin
   if(!source_valid)seen<=0;
   if(header_valid&&header_release)header_valid<=0;
   if(source_valid&&!seen&&!header_valid)begin header<=source_header;header_valid<=1;seen<=1;end
  end
 end
endmodule
