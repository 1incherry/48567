`timescale 1ns/1ps
// Immutable generated-image diagnostic source, not a real camera capture buffer.
// Full wire-image CRC is calculated before publishing frozen/complete.
module nfr_pattern_source(
 input wire clk,rst_n,capture_request,release_frame,
 input wire[15:0]width,height,input wire[7:0]flags,
 output wire capture_ready,output reg capture_complete,capture_error,output reg[31:0]capture_crc,
 input wire block_request,input wire[31:0]block_offset,output wire block_accept,
 output wire[7:0]block_data,output wire block_valid,block_last,input wire block_ready,output reg block_error
);
 reg calculating,streaming,mode1080,phase,bphase;
 reg[11:0]x,y,bx,by;reg[10:0]index;
 reg[31:0]crc,total,next_offset;
 wire[11:0]w=mode1080?1920:640,h=mode1080?1080:480;
 wire[15:0]pixel,block_pixel;
 nfr_pattern_pixel calc(.x(x),.y(y),.mode1080(mode1080),.pixel(pixel));
 nfr_pattern_pixel txp(.x(bx),.y(by),.mode1080(mode1080),.pixel(block_pixel));
 wire[7:0]calc_byte=phase?pixel[7:0]:pixel[15:8];
 assign block_data=bphase?block_pixel[7:0]:block_pixel[15:8];
 assign block_valid=streaming;assign block_last=streaming&&index==1023;
 assign capture_ready=!calculating&&!capture_complete&&!capture_error;
 assign block_accept=block_request&&capture_complete&&!streaming&&!block_error&&block_offset==next_offset&&block_offset+1024<=total;
 function automatic[31:0]cb(input[31:0]c0,input[7:0]d);reg[31:0]c;integer i;begin c=c0^d;for(i=0;i<8;i=i+1)c=c[0]?(c>>1)^32'hedb88320:c>>1;cb=c;end endfunction
 always @(posedge clk)begin
  if(!rst_n||release_frame)begin
   calculating<=0;streaming<=0;mode1080<=0;phase<=0;bphase<=0;x<=0;y<=0;bx<=0;by<=0;index<=0;
   crc<=32'hffffffff;total<=0;next_offset<=0;capture_complete<=0;capture_error<=0;capture_crc<=0;block_error<=0;
  end else begin
   if(capture_request&&capture_ready)begin
    if(flags!=1||!((width==1920&&height==1080)||(width==640&&height==480)))capture_error<=1;
    else begin mode1080<=width==1920;calculating<=1;phase<=0;x<=0;y<=0;crc<=32'hffffffff;total<=width==1920?4147200:614400;next_offset<=0;bx<=0;by<=0;bphase<=0;end
   end
   if(calculating)begin
    crc<=cb(crc,calc_byte);phase<=!phase;
    if(phase)begin
     if(x==w-1)begin x<=0;if(y==h-1)begin calculating<=0;capture_complete<=1;capture_crc<=~cb(crc,calc_byte);end else y<=y+1'b1;end
     else x<=x+1'b1;
    end
   end
   if(block_request&&capture_complete&&!streaming&&!block_error)begin
    if(block_offset!=next_offset||block_offset+1024>total)block_error<=1;
    else begin streaming<=1;index<=0;end
   end
   if(streaming&&block_ready)begin
    bphase<=!bphase;
    if(bphase)begin if(bx==w-1)begin bx<=0;by<=by+1'b1;end else bx<=bx+1'b1;end
    if(index==1023)begin streaming<=0;next_offset<=next_offset+1024;end else index<=index+1'b1;
   end
  end
 end
endmodule
module nfr_pattern_pixel(input wire[11:0]x,y,input wire mode1080,output reg[15:0]pixel);
 wire[11:0]bar=mode1080?240:80,w=mode1080?1920:640,h=mode1080?1080:480,corner=mode1080?96:32,gradient=mode1080?960:416;
 always @*begin
  if(x<bar)pixel=16'hffff;else if(x<bar*2)pixel=16'hffe0;else if(x<bar*3)pixel=16'h07ff;else if(x<bar*4)pixel=16'h07e0;
  else if(x<bar*5)pixel=16'hf81f;else if(x<bar*6)pixel=16'hf800;else if(x<bar*7)pixel=16'h001f;else pixel=0;
  if(y>=gradient)pixel={x[10:6],y[9:4],x[5:1]};
  if(x[5:0]==0||y[5:0]==0)pixel=16'hffff;
  if(x<corner&&y<corner)pixel=16'hf800;if(x>=w-corner&&y<corner)pixel=16'h07e0;
  if(x<corner&&y>=h-corner)pixel=16'h001f;if(x>=w-corner&&y>=h-corner)pixel=16'hffe0;
  if(x==0||x==w-1||y==0||y==h-1)pixel=16'hffff;
 end
endmodule
