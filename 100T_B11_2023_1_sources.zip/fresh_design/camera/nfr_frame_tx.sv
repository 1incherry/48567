`timescale 1ns/1ps
// NFR1 frozen-source transmitter. Control packets have already passed nfr_packet_rx.
// Packet RAM is fully filled before MAC start: no mid-frame producer bubbles.
module nfr_frame_tx #(
 parameter integer ACK_TIMEOUT=12500000,CAPTURE_TIMEOUT=2000000000,RETRY_LIMIT=7,
 parameter[47:0]LOCAL_MAC=48'h025052583100,REMOTE_MAC=48'h025052587035
)(
 input wire clk,rst_n,
 input wire new_request_permit,output reg request_accepted,
 input wire control_valid,input wire[383:0]control_header,output reg control_release,
 output wire capture_request,input wire capture_ready,capture_complete,capture_error,
 output reg[31:0]session_id,frame_id,total_bytes,output reg[15:0]width,height,output reg[7:0]flags,
 input wire[31:0]capture_crc,output reg release_frame,
 output wire block_request,input wire block_accept,output reg[31:0]block_offset,
 input wire[7:0]block_data,input wire block_valid,block_last,block_error,output wire block_ready,
 output wire[7:0]m_axis_tdata,output wire m_axis_tvalid,m_axis_tlast,input wire m_axis_tready,
 input wire mac_underflow,
 output wire busy,output reg done,fault,output reg[31:0]retry_count,packets_sent,completed_frames
);
 localparam IDLE=0,CAP_REQ=1,CAP_WAIT=2,BLOCK_REQ=3,FILL=4,HEADER=5,PRIME=6,SEND=7,WAIT_ACK=8;
 reg[3:0]state;reg[31:0]frame_crc,payload_crc,crc_work,header_crc,timer;
 reg[3:0]retries;reg[10:0]fill_index,head_index,tx_index;
 reg[7:0]tx_data;reg seen_control,cancel_pending;
 (* ram_style="block" *)reg[7:0]packet_mem[0:2047];
 wire[7:0]kind=control_header[343:336];
 wire[31:0]c_session=control_header[319:288],c_frame=control_header[287:256],c_total=control_header[191:160],c_offset=control_header[159:128];
 wire[15:0]c_camera=control_header[255:240],c_width=control_header[239:224],c_height=control_header[223:208],c_length=control_header[127:112],c_seq=control_header[111:96];
 wire[7:0]c_format=control_header[207:200],c_flags=control_header[199:192];
 wire[31:0]c_full=control_header[63:32];
 wire request_ok=kind==1&&c_camera==0&&c_format==1&&(c_flags&8'hfe)==0&&c_length==0&&c_offset==0&&c_seq==0&&c_full==0&&
  (((c_width==1920)&&(c_height==1080)&&(c_total==4147200))||((c_width==640)&&(c_height==480)&&(c_total==614400)));
 wire same_contract=c_session==session_id&&c_frame==frame_id&&c_camera==0&&c_width==width&&c_height==height&&c_format==1&&c_flags==flags&&c_total==total_bytes&&c_length==0;
 wire final_block=block_offset+1024==total_bytes;
 assign busy=state!=IDLE;assign capture_request=state==CAP_REQ;
 assign block_request=state==BLOCK_REQ;assign block_ready=state==FILL;
 assign m_axis_tdata=tx_data;assign m_axis_tvalid=state==SEND;assign m_axis_tlast=state==SEND&&tx_index==1085;
 function automatic[31:0]crc_byte(input[31:0]c0,input[7:0]d);
 reg[31:0]c;integer i;begin c=c0^d;for(i=0;i<8;i=i+1)c=c[0]?(c>>1)^32'hedb88320:c>>1;crc_byte=c;end endfunction
 function automatic[7:0]hb(input integer i);
 reg[383:0]h;begin
  h={32'h4e465231,8'd1,8'd2,16'd48,session_id,frame_id,16'd0,width,height,8'd1,flags,total_bytes,block_offset,16'd1024,block_offset[25:10],payload_crc,frame_crc,32'd0};
  hb=h[383-i*8-:8];
 end endfunction
 wire[7:0]header_byte=hb(head_index-14);
 // A single explicit write port lets Vivado infer true block RAM. The
 // payload and header writers are mutually exclusive states, merged before RAM.
 reg packet_we;reg[10:0]packet_waddr;reg[7:0]packet_wdata;
 always @*begin
  packet_we=0;packet_waddr=0;packet_wdata=0;
  if(state==FILL&&block_valid)begin packet_we=1;packet_waddr=62+fill_index;packet_wdata=block_data;end
  else if(state==HEADER)begin
   packet_we=1;packet_waddr=head_index;
   if(head_index<6)packet_wdata=REMOTE_MAC[47-head_index*8-:8];
   else if(head_index<12)packet_wdata=LOCAL_MAC[47-(head_index-6)*8-:8];
   else if(head_index==12)packet_wdata=8'h88;
   else if(head_index==13)packet_wdata=8'hb5;
   else if(head_index<58)packet_wdata=header_byte;
   else packet_wdata=(~header_crc)>>(8*(61-head_index));
  end
 end
 wire packet_re=state==PRIME||(state==SEND&&m_axis_tready&&!m_axis_tlast);
 wire[10:0]packet_raddr=state==PRIME?11'd0:tx_index+11'd1;
 // One canonical registered read port; merge address mux before the RAM.
 always @(posedge clk)begin
  if(packet_we)packet_mem[packet_waddr]<=packet_wdata;
  if(packet_re)tx_data<=packet_mem[packet_raddr];
 end
 task automatic abort_transfer;begin state<=IDLE;release_frame<=1;fault<=1;cancel_pending<=0;end endtask
 task automatic retry_packet;begin
  if(retries>=RETRY_LIMIT)abort_transfer();
  else begin retries<=retries+1'b1;retry_count<=retry_count+1'b1;tx_index<=0;timer<=0;state<=PRIME;end
 end endtask
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;session_id<=0;frame_id<=0;total_bytes<=0;width<=0;height<=0;flags<=0;
   frame_crc<=0;payload_crc<=0;crc_work<=32'hffffffff;header_crc<=32'hffffffff;timer<=0;retries<=0;
   fill_index<=0;head_index<=0;tx_index<=0;seen_control<=0;cancel_pending<=0;control_release<=0;release_frame<=0;
   request_accepted<=0;done<=0;fault<=0;retry_count<=0;packets_sent<=0;completed_frames<=0;block_offset<=0;
  end else begin
   request_accepted<=0;release_frame<=0;control_release<=0;done<=0;
   if(!control_valid)seen_control<=0;
   if(busy)timer<=timer+1'b1;else timer<=0;
   case(state)
    IDLE:begin cancel_pending<=0;end
    CAP_REQ:if(capture_ready)begin timer<=0;state<=CAP_WAIT;end
    CAP_WAIT:if(capture_error)abort_transfer();else if(capture_complete)begin frame_crc<=capture_crc;block_offset<=0;timer<=0;state<=BLOCK_REQ;end
    BLOCK_REQ:if(block_error)abort_transfer();else if(block_accept)begin fill_index<=0;crc_work<=32'hffffffff;timer<=0;state<=FILL;end
    FILL:begin
     if(block_error)abort_transfer();
     else if(block_valid)begin
      timer<=0;crc_work<=crc_byte(crc_work,block_data);
      if(block_last!=(fill_index==1023))abort_transfer();
      else if(fill_index==1023)begin payload_crc<=~crc_byte(crc_work,block_data);head_index<=0;header_crc<=32'hffffffff;state<=HEADER;end
      else fill_index<=fill_index+1'b1;
     end
    end
    HEADER:begin
     if(head_index>=14&&head_index<58)header_crc<=crc_byte(header_crc,header_byte);
     if(head_index==61)begin tx_index<=0;state<=PRIME;end else head_index<=head_index+1'b1;
    end
    PRIME:begin tx_index<=0;state<=SEND;end
    SEND:if(m_axis_tready)begin
     timer<=0;
     if(m_axis_tlast)begin packets_sent<=packets_sent+1'b1;if(cancel_pending)abort_transfer();else state<=WAIT_ACK;end
     else tx_index<=tx_index+1'b1;
    end
    WAIT_ACK:if(timer>=ACK_TIMEOUT)retry_packet();
    default:abort_transfer();
   endcase
   // Producer timeouts never truncate a MAC frame already being transmitted.
   if(state!=IDLE&&state!=SEND&&state!=WAIT_ACK&&timer>=CAPTURE_TIMEOUT)abort_transfer();
   if(mac_underflow&&busy)begin if(state==SEND)cancel_pending<=1;else abort_transfer();end
   if(control_valid&&!seen_control)begin
    seen_control<=1;control_release<=1;
    if(state==IDLE&&request_ok&&new_request_permit)begin
     request_accepted<=1;
     session_id<=c_session;frame_id<=c_frame;total_bytes<=c_total;width<=c_width;height<=c_height;flags<=c_flags;
     block_offset<=0;retries<=0;timer<=0;fault<=0;state<=CAP_REQ;
    end else if(same_contract&&kind==6&&busy)begin if(state==SEND)cancel_pending<=1;else abort_transfer();end
    else if(state==WAIT_ACK&&same_contract)begin
     if(kind==4&&final_block&&c_offset==total_bytes&&c_full==frame_crc)begin
      state<=IDLE;release_frame<=1;done<=1;completed_frames<=completed_frames+1'b1;timer<=0;
     end else if(kind==3&&!final_block&&c_offset==block_offset+1024&&c_full==frame_crc)begin
      block_offset<=block_offset+1024;retries<=0;timer<=0;state<=BLOCK_REQ;
     end else if(kind==5&&c_offset==block_offset&&(c_full==0||c_full==frame_crc))retry_packet();
    end
   end
  end
 end
endmodule
