module nfr_phy_init #(parameter MDIO_SETTLE_CYCLES=25000000)(
 input wire clk,rst,phy_reset_done,md_busy,md_done,md_ack,input wire[15:0]md_rdata,
 output reg md_start,md_read,output reg[4:0]md_phy,md_reg,output reg[15:0]md_wdata,output reg configured,fault,
 output reg [127:0] debug_snapshot,output reg debug_valid
);
 reg[3:0]state;reg[2:0]op;reg[$clog2(MDIO_SETTLE_CYCLES+1)-1:0]settle;reg[15:0]delay_value;
 reg[31:0]ack_bitmap;
 reg[15:0]first_id1,first_id2,last_data;
 reg[4:0]first_phy,id2_phy;
 reg first_seen,id2_seen;
 reg[3:0]fault_cause;
 // Read-only observations: no signal in this block feeds the initialization FSM.
 // Source is immutable once terminal; destination waits a three-stage valid.
 always @(posedge clk) begin
  if(rst)begin ack_bitmap<=0;first_id1<=0;first_id2<=0;last_data<=0;first_phy<=0;id2_phy<=0;first_seen<=0;id2_seen<=0;fault_cause<=0;debug_snapshot<=0;debug_valid<=0;end
  else begin
   if(md_done)begin
    last_data<=md_rdata;
    if(state==2&&!md_ack)begin
     ack_bitmap[md_phy]<=1;
     if(!first_seen)begin first_seen<=1;first_id1<=md_rdata;first_phy<=md_phy;end
    end
    if(state==4&&!md_ack&&!id2_seen)begin id2_seen<=1;first_id2<=md_rdata;id2_phy<=md_phy;end
    if((state==2||state==4)&&md_phy==31&&(md_ack||(state==2?md_rdata!=16'h001c:md_rdata!=16'hc915)))
     fault_cause<=ack_bitmap==0&&!(state==2&&!md_ack)?4'd1:4'd2;
    if(state==6)begin
     if(md_ack)fault_cause<=3;
     else if(op==4&&(md_rdata&16'h3800)!=16'h2800)fault_cause<=4;
     else if(op==6&&md_rdata!=16'h001c)fault_cause<=5;
    end
   end
   if(state==15&&!debug_valid)begin
    debug_snapshot<={{fault_cause,state,op,md_phy,first_phy,id2_phy,md_ack,first_seen,id2_seen,configured,fault,1'b0},ack_bitmap,first_id1,first_id2,last_data,delay_value};
    debug_valid<=1;
   end
  end
 end
 task automatic launch(input readflag,input[4:0]r,input[15:0]v);begin md_start<=1;md_read<=readflag;md_reg<=r;md_wdata<=v;end endtask
 task automatic next_phy;begin if(md_phy==31)begin fault<=1;state<=15;end else begin md_phy<=md_phy+1'b1;state<=1;end end endtask
 always @(posedge clk)begin
  if(rst)begin state<=0;op<=0;settle<=0;delay_value<=0;md_start<=0;md_read<=1;md_phy<=0;md_reg<=2;md_wdata<=0;configured<=0;fault<=0;end
  else begin md_start<=0;
   case(state)
    0:if(phy_reset_done)begin if(settle==MDIO_SETTLE_CYCLES-1)state<=1;else settle<=settle+1'b1;end
    1:if(!md_busy)begin launch(1,2,0);state<=2;end
    2:if(md_done)begin if(md_ack||md_rdata!=16'h001c)next_phy();else state<=3;end
    3:if(!md_busy)begin launch(1,3,0);state<=4;end
    4:if(md_done)begin if(md_ack||md_rdata!=16'hc915)next_phy();else begin op<=0;state<=5;end end
    5:if(!md_busy)begin
     case(op)0:launch(0,31,7);1:launch(0,30,16'h00a4);2:launch(1,28,0);3:launch(0,28,delay_value);4:launch(1,28,0);5:launch(0,31,0);default:launch(1,2,0);endcase
     state<=6;
    end
    6:if(md_done)begin
     if(md_ack)begin fault<=1;state<=15;end
     else if(op==4&&(md_rdata&16'h3800)!=16'h2800)begin fault<=1;state<=15;end
     else if(op==6)begin configured<=md_rdata==16'h001c;fault<=md_rdata!=16'h001c;state<=15;end
     else begin if(op==2)delay_value<=(md_rdata&16'hc7ff)|16'h2800;op<=op+1'b1;state<=5;end
    end
    default:;
   endcase
  end
 end
endmodule
