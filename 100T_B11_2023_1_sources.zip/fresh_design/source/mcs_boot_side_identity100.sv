`timescale 1ns/1ps
// Exact100MHz identity of the trusted side transaction. Metadata is captured
// only on actual side-converter AW/W handshakes and held through host B and
// the complete retire-ACK roundtrip. CPU/epoch reset is not a port here.
module mcs_boot_side_identity100(input wire clk,board_reset_n,
 input wire aw_accepted,input wire[31:0]awaddr,
 input wire w_accepted,input wire[31:0]wdata,input wire[3:0]wstrb,
 input wire retire_complete,
 output reg seen_aw,seen_w,output reg[31:0]address,data,output reg[3:0]strb,
 output reg protocol_fault,output wire valid);
 assign valid=seen_aw&&seen_w&&!protocol_fault;
 always@(posedge clk or negedge board_reset_n)begin
 if(!board_reset_n)begin seen_aw<=0;seen_w<=0;address<=0;data<=0;strb<=0;protocol_fault<=0;end
 else begin
  if(retire_complete)begin seen_aw<=0;seen_w<=0;end
  // A new real handshake on the first available cycle takes precedence over
  // retiring the previous identity. Payload never resets on CPU/epoch loss.
  if(aw_accepted)begin
   if(seen_aw&&!retire_complete)protocol_fault<=1;
   seen_aw<=1;address<=awaddr;
  end
  if(w_accepted)begin
   if(seen_w&&!retire_complete)protocol_fault<=1;
   seen_w<=1;data<=wdata;strb<=wstrb;
  end
 end end
endmodule
