// Standalone candidate sequencing. Arithmetic is exclusively the attached
// real token core; this module contains no model answer or golden feedback.
module qwen_autoregressive_sequence_token_pause_r1(
 input wire clk,rst_n,ddr_ready,
 // Same-clock request; parks token launches only, NOT DDR or lease drain.
 input wire token_pause_request,output wire token_boundary_parked,
 input wire start_valid,output wire start_ready,
 input wire [9:0] start_position,input wire [7:0] max_new_tokens,
 input wire emit_logits,
 input wire prompt_valid,output wire prompt_ready,
 input wire [15:0] prompt_token,input wire prompt_last,
 output reg busy,done,error,
 output reg core_start,output reg [15:0] core_token,
 output reg [9:0] core_position,
 output reg core_output_head,output reg core_emit_logits,
 input wire core_busy,core_done,core_error,
 input wire [15:0] core_result_token,input wire [9:0] core_result_position,
 input wire core_result_valid,
 output wire result_valid,input wire result_ready,
 output wire [15:0] result_token,output wire [9:0] result_position,
 output wire [63:0] result_cycles,output wire result_last,
 output wire [8:0] result_count,
 output reg [7:0] generated_count,
 output reg [63:0] prefill_cycles,decode_cycles,fifo_wait_cycles,
 output reg [63:0] active_sequence_cycles,decode_wall_cycles
);
 localparam IDLE=0,PROMPT=1,RUN=2,PUSH=3,RESTART=4;
 reg [2:0] state=IDLE;
 reg last_input=0,started_decode=0,logits=0;
 reg [7:0] limit=0;
 reg [63:0] step_cycles=0,held_cycles=0;
 reg [15:0] held_token=0;
 reg [9:0] held_position=0;
 reg held_last=0;
 reg [7:0] read_index=0,write_index=0;
 reg [8:0] count=0;
 // 91 bits = token16 + position10 + cycles64 + last1; fits one RAMB36.
 // Payload is never reset/cleared. Count gates unread and unwritten entries.
 (* ram_style="block" *) reg [90:0] entries[0:255];
 reg [90:0] read_payload;
 reg read_pending=0,out_valid=0;
 wire pop=out_valid && result_ready;
 wire push=busy && ddr_ready && state==PUSH && count<256;
 assign result_count=count;
 assign result_valid=out_valid && rst_n;
 assign {result_last,result_cycles,result_position,result_token}=read_payload;
 wire boundary_state=(state==IDLE)||(state==PROMPT)||(state==RESTART);
 assign token_boundary_parked=rst_n && ddr_ready && !error && token_pause_request && boundary_state && !core_busy && !core_start;
 assign start_ready=rst_n && ddr_ready && !token_pause_request && !busy && !core_busy && count==0 && !out_valid && !read_pending;
 assign prompt_ready=rst_n && ddr_ready && !token_pause_request && busy && state==PROMPT && !core_busy;
 // Synchronous RAM read; payload held under output backpressure.
 always @(posedge clk)begin
  if(rst_n && !out_valid && !read_pending && count!=0)read_payload<=entries[read_index];
  if(push && rst_n)entries[write_index]<={held_last,held_cycles,held_position,held_token};
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;busy<=0;done<=0;error<=0;core_start<=0;core_token<=0;core_position<=0;core_output_head<=0;core_emit_logits<=0;
   last_input<=0;started_decode<=0;logits<=0;limit<=0;step_cycles<=0;held_cycles<=0;held_token<=0;held_position<=0;held_last<=0;
   read_index<=0;write_index<=0;count<=0;read_pending<=0;out_valid<=0;generated_count<=0;prefill_cycles<=0;decode_cycles<=0;fifo_wait_cycles<=0;active_sequence_cycles<=0;decode_wall_cycles<=0;
  end else begin
   core_start<=0;done<=0;
   // Wall counter includes PUSH/RESTART, RAM and output stalls. With FIFO256
   // and limit192 it never depends on UART/host result drain.
   if(busy)active_sequence_cycles<=active_sequence_cycles+1'b1;
   if(busy && generated_count!=0)decode_wall_cycles<=decode_wall_cycles+1'b1;
   if(!out_valid && !read_pending && count!=0)read_pending<=1;
   if(read_pending)begin read_pending<=0;out_valid<=1;end
   if(pop)begin out_valid<=0;read_index<=read_index+1'b1;end
   if(push)write_index<=write_index+1'b1;
   case({push,pop})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:begin end endcase
   if(start_valid && start_ready)begin
    error<=0;generated_count<=0;prefill_cycles<=0;decode_cycles<=0;fifo_wait_cycles<=0;active_sequence_cycles<=0;decode_wall_cycles<=0;started_decode<=0;
    if(start_position>=512 || max_new_tokens==0 || max_new_tokens>192)begin error<=1;done<=1;state<=IDLE;end
    else begin busy<=1;state<=PROMPT;core_position<=start_position;limit<=max_new_tokens;logits<=emit_logits;end
   end else if(busy && !ddr_ready)begin
    busy<=0;done<=1;error<=1;state<=IDLE;
   end else if(busy)begin
    case(state)
     PROMPT:if(prompt_valid && prompt_ready)begin
      if(prompt_token>=65535 || core_position>=512)begin busy<=0;done<=1;error<=1;state<=IDLE;end
      else begin
       core_token<=prompt_token;last_input<=prompt_last;core_output_head<=prompt_last;core_emit_logits<=prompt_last && logits;
       core_start<=1;step_cycles<=0;state<=RUN;
      end
     end
     RUN:begin
      step_cycles<=step_cycles+1'b1;
      if(core_done && !core_start)begin
       if(core_error || core_result_position!=core_position+1 || (last_input && (!core_result_valid || core_result_token>=65535)) || (!last_input && core_result_valid))begin
        busy<=0;done<=1;error<=1;state<=IDLE;
       end else if(!last_input)begin prefill_cycles<=prefill_cycles+step_cycles;core_position<=core_result_position;state<=PROMPT;end
       else begin
        if(started_decode)decode_cycles<=decode_cycles+step_cycles;else prefill_cycles<=prefill_cycles+step_cycles;
        held_token<=core_result_token;held_position<=core_result_position;held_cycles<=step_cycles;
        held_last<=core_result_token==32451 || core_result_token==32453 || generated_count+1>=limit || core_result_position>=512;
        state<=PUSH;
       end
      end
     end
     PUSH:if(push)begin
      generated_count<=generated_count+1'b1;
      if(held_last)begin busy<=0;done<=1;state<=IDLE;end
      else begin core_token<=held_token;core_position<=held_position;state<=RESTART;end
     end else fifo_wait_cycles<=fifo_wait_cycles+1'b1;
     RESTART:if(!core_busy && !token_pause_request)begin
      last_input<=1;started_decode<=1;core_output_head<=1;core_emit_logits<=logits;core_start<=1;step_cycles<=0;state<=RUN;
     end
     default:begin busy<=0;done<=1;error<=1;state<=IDLE;end
    endcase
   end
  end
 end
endmodule
