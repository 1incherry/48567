`timescale 1ns/1ps
// Read-only packet observation bank + explicit snapshot command. No inference,
// root authority, action, arbitrary DDR, or Qwen GO port is present here.
module ntr2_context_axil_shared_runtime_r8 #(parameter integer ENABLE_HISTORY=0,parameter integer ENABLE_HNA=0)(input wire clk,rst_n,
 input wire[31:0]reservation_status,input wire reservation_acquire_ready,reservation_release_ready,output reg reservation_acquire,reservation_release,
 input wire reservation_release_done,reservation_release_fault,
 input wire runtime_memory_epoch_n,
 input wire runtime_ack_on_50,runtime_ack_off_50,runtime_owner_50,runtime_idle_50,runtime_fault_50,
 output wire runtime_descriptor_valid,runtime_enable,
 input wire replay_consumed,output reg replay_armed,output reg[31:0]replay_expected_crc,replay_session,replay_frame,
 input wire report_valid,output wire report_ready,
 output wire report_read_enable,output wire[5:0]report_read_address,
 input wire[31:0]report_read_data,input wire report_read_valid,input wire transport_fault,
 input wire[11:0]s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire[31:0]s_wdata,input wire[3:0]s_wstrb,input wire s_wvalid,output wire s_wready,
 output reg[1:0]s_bresp,output reg s_bvalid,input wire s_bready,
 input wire[11:0]s_araddr,input wire s_arvalid,output wire s_arready,
 output reg[31:0]s_rdata,output reg[1:0]s_rresp,output reg s_rvalid,input wire s_rready,
 output reg tx_start,output reg[863:0]tx_payload,output reg[31:0]tx_sequence,tx_session,input wire tx_busy,tx_error,tx_done,
 input wire shared_boot_done,shared_boot_error,shared_boot_pending,shared_boot_epoch_ok,
 input wire shared_descriptor_valid,shared_runtime_enable,input wire[31:0]shared_boot_descriptor,shared_boot_status,
 output wire shared_boot_command,output wire[11:0]shared_boot_address,output wire[31:0]shared_boot_data,
 input wire shared_release_admit,output wire shared_release_candidate,shared_release_inflight,
 input wire release_qualify_ready,release_qualify_done,release_qualify_good,release_qualify_fault,output reg release_qualify_start,
 input wire main_runtime_fault,main_fence_ready,main_fence_qualified,main_fence_good,main_fence_fault,
 output reg main_fence_start,main_response_consumed,main_response_prepare,input wire main_response_closed_ack,
 output wire quiescent,output reg[31:0]reports_received
);

 // Two true BRAM banks. The CDC local assembly RAM holds all source words until
 // report_ready; one synchronous-read prime is added, no parallel 2048-bit bus.
 (* ram_style="block" *)reg[31:0]latest_words[0:63];
 (* ram_style="block" *)reg[31:0]frozen_words[0:63];
 reg[31:0]reply_completed;
 // History is passive, display-only and explicitly untrusted. No new RAM.
 reg history_armed,history_held;reg[2:0]capture_kind,latest_kind,frozen_kind;
 reg awhold,whold;reg[11:0]aw;reg[31:0]wd;reg[3:0]ws;
 reg release_pending,boot_response_pending,geometry_pending,main_pending,main_response_owned,main_response_wait,main_response_error;
 wire boot_done=shared_boot_done,boot_error=shared_boot_error,boot_pending=shared_boot_pending,boot_epoch_ok=shared_boot_epoch_ok;
 wire[31:0]boot_descriptor=shared_boot_descriptor,boot_status=shared_boot_status;
 assign runtime_descriptor_valid=shared_descriptor_valid;assign runtime_enable=shared_runtime_enable;
 wire boot_command=awhold&&whold&&!s_bvalid&&!boot_response_pending&&ws==15&&aw[1:0]==0&&(aw==12'h080||aw==12'h084||aw==12'h088);
 assign shared_boot_command=boot_command;assign shared_boot_address=aw;assign shared_boot_data=wd;
 assign shared_release_candidate=main_pending&&main_fence_qualified&&main_fence_good&&!main_fence_fault&&!main_runtime_fault&&reservation_release_ready;
 assign shared_release_inflight=geometry_pending||main_pending||release_pending||main_response_owned||main_response_wait;
 reg latest_valid,frozen_valid;reg[31:0]snapshot_number;
 reg capture_active,freeze_active,freeze_pending,body_read_pending,snapshot_fault;
 reg try_freeze_accepted;
 reg[5:0]capture_index,freeze_write_index;
 reg[6:0]capture_issued;reg capture_read_pending;
 reg[6:0]freeze_issued;
 reg[31:0]latest_q,frozen_q;
 wire record_fault=transport_fault||snapshot_fault;
 assign report_read_enable=rst_n&&capture_active&&capture_issued<64&&report_valid&&!record_fault;
 assign report_read_address=capture_issued[5:0];
 wire body_read_launch=s_arvalid&&s_arready&&s_araddr>=12'h100&&s_araddr<12'h200&&s_araddr[1:0]==0&&frozen_valid&&!record_fault;
 always @(posedge clk)begin
  if(rst_n&&capture_active&&report_valid&&report_read_valid&&!record_fault)latest_words[capture_index]<=report_read_data;
  if(rst_n&&freeze_active&&freeze_issued<64&&!record_fault)latest_q<=latest_words[freeze_issued[5:0]];
  if(rst_n&&freeze_pending&&!record_fault)frozen_words[freeze_write_index]<=latest_q;
  if(body_read_launch)frozen_q<=frozen_words[s_araddr[7:2]];
 end

 assign report_ready=rst_n&&capture_active&&capture_index==63&&(report_read_valid===1'b1)&&!record_fault;assign s_awready=rst_n&&!awhold&&!s_bvalid&&!freeze_active&&!release_pending&&!geometry_pending&&!main_pending&&!main_response_wait&&!boot_response_pending;assign s_wready=rst_n&&!whold&&!s_bvalid&&!freeze_active&&!release_pending&&!geometry_pending&&!main_pending&&!main_response_wait&&!boot_response_pending;
 assign s_arready=rst_n&&!s_rvalid&&!body_read_pending;
 assign quiescent=rst_n&&!geometry_pending&&!main_pending&&!main_pending&&!boot_response_pending&&!awhold&&!whold&&!s_bvalid&&!s_rvalid&&!s_awvalid&&!s_wvalid&&!s_arvalid&&!tx_start&&!tx_busy&&!capture_active&&!capture_read_pending&&!report_read_valid&&!freeze_active&&!body_read_pending;
 // Trusted JTAG-only replay authority, never an Ethernet command or model result.
 reg[31:0]last_replay_session,last_replay_frame;
 wire replay_configuration_safe=reservation_status[9]&&!reservation_status[8]&&(&reservation_status[7:0])&&!record_fault&&!tx_busy&&!tx_start;
 wire try_freeze_launch=awhold&&whold&&!s_bvalid&&ws==15&&aw==12'h010&&wd==2&&latest_valid&&!capture_active&&!record_fault;
 wire history_arm_launch=ENABLE_HISTORY!=0&&awhold&&whold&&!s_bvalid&&ws==15&&aw==12'h0a0&&wd==1&&!history_armed&&!history_held&&!freeze_active&&!record_fault;
 integer wordindex;
 always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin history_armed<=0;history_held<=0;capture_kind<=0;latest_kind<=0;frozen_kind<=0;main_response_wait<=0;main_response_error<=0;main_response_prepare<=0;main_pending<=0;main_response_owned<=0;main_fence_start<=0;main_response_consumed<=0;geometry_pending<=0;release_qualify_start<=0;boot_response_pending<=0;reply_completed<=0;release_pending<=0;replay_armed<=0;replay_expected_crc<=0;replay_session<=0;replay_frame<=0;last_replay_session<=0;last_replay_frame<=0;reservation_acquire<=0;reservation_release<=0;capture_active<=0;freeze_active<=0;freeze_pending<=0;body_read_pending<=0;snapshot_fault<=0;try_freeze_accepted<=0;capture_index<=0;capture_issued<=0;capture_read_pending<=0;freeze_write_index<=0;freeze_issued<=0;latest_valid<=0;frozen_valid<=0;snapshot_number<=0;awhold<=0;whold<=0;aw<=0;wd<=0;ws<=0;s_bresp<=0;s_bvalid<=0;s_rdata<=0;s_rresp<=0;s_rvalid<=0;tx_start<=0;tx_payload<=0;tx_sequence<=0;tx_session<=0;reports_received<=0;end
 else begin
 tx_start<=0;reservation_acquire<=0;reservation_release<=0;release_qualify_start<=0;main_fence_start<=0;main_response_consumed<=0;
  capture_read_pending<=report_read_enable;
 if(boot_response_pending&&!boot_epoch_ok)begin boot_response_pending<=0;s_bvalid<=1;s_bresp<=2'b10;end
 if(boot_response_pending&&boot_done)begin boot_response_pending<=0;s_bvalid<=1;s_bresp<=boot_error?2'b10:2'b00;end
 if(tx_done)reply_completed<=reply_completed+1'b1;
 //125MHz AW/W have already been accepted into board-owned storage before
  // requesting the100MHz root metadata. No WREADY dependency on firstW exists.
  // Qualifier reports completion only after its onehot ACK has returned to zero.
  if(geometry_pending&&release_qualify_done)begin
   geometry_pending<=0;
   if(release_qualify_good&&!release_qualify_fault&&reservation_release_ready&&shared_release_admit&&main_fence_ready)begin
    main_fence_start<=1;main_pending<=1;
   end else begin s_bvalid<=1;s_bresp<=2'b10;end
  end
  // MAIN100 qualification precedes the only serial-release commit. Its old
  // ACK cannot qualify a second job because main_fence_ready remains false
  // until exact100/50/125 retirements and ACK returnzero have completed.
  if(main_pending&&main_fence_qualified)begin
   main_pending<=0;main_response_owned<=1;
   if(main_fence_good&&!main_fence_fault&&!main_runtime_fault&&reservation_release_ready&&shared_release_admit)begin
    reservation_release<=1;release_pending<=1;
   end else begin main_response_wait<=1;main_response_error<=1;main_response_prepare<=1;end
  end
  // Only the admitted release's own pending state is omitted from quiescent.
 // All other AW/W/AR/R and report/freeze/TX activity still gate serial quiet.
 if(release_pending&&(reservation_release_done||reservation_release_fault||main_runtime_fault))begin
  release_pending<=0;main_response_wait<=1;main_response_error<=reservation_release_fault||main_runtime_fault;main_response_prepare<=1;
 end
 if(main_response_wait&&main_runtime_fault)main_response_error<=1;
  // B may become visible upstream earlier than this source consumes it.
  // First handshake the terminal decision to100MHz;only then expose B.
  if(main_response_wait&&main_response_closed_ack)begin
   main_response_wait<=0;s_bvalid<=1;s_bresp<=(main_response_error||main_runtime_fault)?2'b10:2'b00;
  end
  if(replay_consumed&&replay_armed)begin replay_armed<=0;last_replay_session<=replay_session;last_replay_frame<=replay_frame;end

 if(!capture_active&&!freeze_active&&!try_freeze_launch&&report_valid&&!record_fault&&!(ENABLE_HISTORY!=0&&history_held))begin capture_kind<=0;capture_active<=1;capture_index<=0;capture_issued<=0;latest_valid<=0;end
 if(capture_active&&!record_fault)begin
   if(!report_valid||(report_read_valid!==capture_read_pending))begin snapshot_fault<=1;capture_active<=0;latest_valid<=0;end
   else begin
    if(report_read_enable)capture_issued<=capture_issued+1'b1;
    if(report_read_valid)begin
     if(ENABLE_HISTORY!=0&&capture_index==0)begin
      case(report_read_data)
       32'h4e545232:capture_kind<=1;
       32'h4e415232:capture_kind<=2;
       32'h4e415233:capture_kind<=6;
       32'h48495331:capture_kind<=3;
       32'h484e4131:capture_kind<=ENABLE_HNA!=0?3:0;
       default:capture_kind<=0;
      endcase
     end
     if(capture_index==63)begin
      capture_active<=0;
      if(ENABLE_HISTORY!=0&&capture_kind==0)begin snapshot_fault<=1;latest_valid<=0;end
      else begin latest_valid<=1;latest_kind<=capture_kind;reports_received<=reports_received+1'b1;
       if(ENABLE_HISTORY!=0&&(history_armed||history_arm_launch)&&capture_kind==3)history_held<=1;
      end
     end else capture_index<=capture_index+1'b1;
    end
   end
  end
  if(freeze_active)begin
  freeze_pending<=freeze_issued<64;
  if(freeze_issued<64)begin freeze_write_index<=freeze_issued[5:0];freeze_issued<=freeze_issued+1'b1;end
  if(freeze_pending&&freeze_write_index==63)begin freeze_active<=0;freeze_pending<=0;frozen_valid<=1;s_bvalid<=1;s_bresp<=0;end
 end
 if(body_read_pending)begin body_read_pending<=0;s_rdata<=frozen_q;s_rresp<=0;s_rvalid<=1;end

 if(s_awvalid&&s_awready)begin aw<=s_awaddr;awhold<=1;end
 if(s_wvalid&&s_wready)begin wd<=s_wdata;ws<=s_wstrb;whold<=1;end
 if(s_bvalid&&s_bready)begin s_bvalid<=0;if(main_response_owned)begin main_response_owned<=0;main_response_consumed<=1;main_response_prepare<=0;end end
 if(awhold&&whold&&!s_bvalid)begin
 awhold<=0;whold<=0;s_bvalid<=1;s_bresp<=2'b10;
 if(ws==15&&aw[1:0]==0)begin
  if(ENABLE_HISTORY!=0&&aw==12'h0a0&&!record_fault&&!freeze_active)begin
   if(wd==1&&!history_armed&&!history_held)begin history_armed<=1;if(!capture_active&&latest_kind==3)latest_valid<=0;s_bresp<=0;end
   else if(wd==2&&history_armed&&!tx_busy&&!tx_start&&!capture_active)begin history_armed<=0;history_held<=0;if(latest_kind==3)latest_valid<=0;s_bresp<=0;end
   else if(wd==3&&history_armed&&history_held&&!tx_busy&&!tx_start&&!capture_active)begin history_held<=0;latest_valid<=0;s_bresp<=0;end
  end
  else if(!tx_busy&&!tx_start&&aw>=12'h300&&aw<12'h36c)begin
   tx_payload[(aw-12'h300)*8+:32]<=wd;s_bresp<=0;
  end
  else if(aw==12'h080||aw==12'h084||aw==12'h088)begin boot_response_pending<=1;s_bvalid<=0;end
  else if(aw==12'h040&&!replay_armed&&replay_configuration_safe)begin replay_expected_crc<=wd;s_bresp<=0;end
  else if(aw==12'h044&&!replay_armed&&replay_configuration_safe)begin replay_session<=wd;s_bresp<=0;end
  else if(aw==12'h048&&!replay_armed&&replay_configuration_safe)begin replay_frame<=wd;s_bresp<=0;end
  else if(aw==12'h04c&&wd==1&&!replay_armed&&replay_configuration_safe&&replay_session>last_replay_session&&replay_frame>last_replay_frame)begin replay_armed<=1;s_bresp<=0;end
  else if(aw==12'h04c&&wd==2&&replay_configuration_safe)begin replay_armed<=0;s_bresp<=0;end
  else if(aw==12'h034&&wd==1&&reservation_acquire_ready)begin reservation_acquire<=1;s_bresp<=0;end
  else if(aw==12'h034&&wd==2&&release_qualify_ready&&!release_qualify_fault)begin release_qualify_start<=1;geometry_pending<=1;s_bvalid<=0;s_bresp<=0;end
  else if(aw==12'h010&&wd==2&&!record_fault)begin
   s_bresp<=0;try_freeze_accepted<=try_freeze_launch;
   if(try_freeze_launch)begin freeze_active<=1;freeze_issued<=0;freeze_pending<=0;frozen_valid<=0;frozen_kind<=latest_kind;snapshot_number<=reports_received;s_bvalid<=0;end
  end
  else if(aw==12'h010&&wd==1&&latest_valid&&!capture_active&&!report_valid&&!record_fault)begin freeze_active<=1;freeze_issued<=0;freeze_pending<=0;frozen_valid<=0;frozen_kind<=latest_kind;snapshot_number<=reports_received;s_bvalid<=0;end
  else if(aw==12'h020&&wd==1&&!tx_busy&&!tx_error&&!record_fault)begin tx_start<=1;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw==12'h024)begin tx_sequence<=wd;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw==12'h028)begin tx_session<=wd;s_bresp<=0;end
 end
 end
 if(s_rvalid&&s_rready)s_rvalid<=0;
 if(s_arvalid&&s_arready)begin
 s_rvalid<=1;s_rdata<=0;s_rresp<=0;
 case(s_araddr)
 12'h080:s_rdata<=boot_descriptor;
 12'h084:s_rdata<={31'd0,boot_status[1]};
 12'h088:s_rdata<=boot_status;
 12'h014:s_rdata<=reply_completed;
 12'h000:s_rdata<=32'h4e545232;
 12'h004:s_rdata<={26'd0,record_fault,tx_error,tx_busy,1'b0,frozen_valid,latest_valid};
 12'h008:s_rdata<=reports_received;
 12'h00c:s_rdata<=snapshot_number;
 12'h018:s_rdata<={31'd0,try_freeze_accepted};
 12'h01c:if(ENABLE_HISTORY!=0&&frozen_valid&&!record_fault)s_rdata<={29'd0,frozen_kind};else s_rresp<=2'b10;
 12'h0a4:if(ENABLE_HISTORY!=0)s_rdata<=32'h48490000|{24'd0,frozen_kind,latest_kind,history_held,history_armed};else s_rresp<=2'b10;
 12'h030:s_rdata<=reservation_status;
 12'h040:s_rdata<=replay_expected_crc;
 12'h044:s_rdata<=replay_session;
 12'h048:s_rdata<=replay_frame;
 12'h04c:s_rdata<={30'd0,replay_configuration_safe,replay_armed};
 12'h050:s_rdata<=last_replay_session;
 12'h054:s_rdata<=last_replay_frame;
 12'h024:s_rdata<=tx_sequence;
 12'h028:s_rdata<=tx_session;
 default:if(body_read_launch)begin body_read_pending<=1;s_rvalid<=0;end else s_rresp<=2'b10;
 endcase
 end
 // A fault cannot make a partially copied record visible or acknowledge a
 // partial freeze. An existing AXI response remains held until real ready.
 if(record_fault)begin
  snapshot_fault<=1;capture_active<=0;freeze_active<=0;freeze_pending<=0;try_freeze_accepted<=0;
  latest_valid<=0;frozen_valid<=0;body_read_pending<=0;tx_start<=0;
  if(freeze_active)begin s_bvalid<=1;s_bresp<=2'b10;end
  if(body_read_pending&&!s_rvalid)begin s_rvalid<=1;s_rresp<=2'b10;s_rdata<=0;end
 end
 end end
endmodule
