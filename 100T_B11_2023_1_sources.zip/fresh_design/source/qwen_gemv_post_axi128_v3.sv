// Cacheless INT64 scratch -> live FP32 postprocess -> FP32 scratch executor.
// 32-row private buffers; burst splitting preserves AXI4 4KiB boundaries.
// Completion follows the final successful B response. Errors do not roll back
// previously committed chunks. Caller must abort/reset the model context.
module qwen_gemv_post_axi128_v3 #(
 parameter [31:0] DDR_BASE=32'h80000000,
 parameter [32:0] DDR_BYTES=33'h010000000
)(
 input wire clk,rst_n,cmd_valid,output wire cmd_ready,
 input wire [15:0] cmd_rows,cmd_seq,
 input wire [2:0] cmd_kind,
 input wire [31:0] cmd_input_base,cmd_output_base,cmd_coefficient_base,cmd_scale_fp32,
 input wire cmd_coefficient_enable,
 output wire rsp_valid,input wire rsp_ready,output reg [15:0] rsp_seq,
 output reg [7:0] rsp_error,output wire busy,output reg [31:0] cycle_count,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output reg [127:0] m_axi_wdata,output reg [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 localparam IDLE=0,RA=1,RD=2,STREAM=3,DRAIN=4,WA=5,WD=6,WB=7,RESPONSE=8,READ_BASE=9,READ_ADDR=10,READ_LIMIT=11,WRITE_BASE=12,WRITE_ADDR=13,WRITE_LIMIT=14,READ_FINISH=15;
 reg [3:0] state;
 // Own reset is a registered level; binary FSM bit skew cannot reset metadata.
 reg arithmetic_live;
 always @(posedge clk or negedge rst_n)
  if(!rst_n)arithmetic_live<=0;
  else arithmetic_live<=state!=IDLE&&state!=RESPONSE;
 // Address arithmetic, word offset, and page-burst limit occupy separate cycles.
 // Payload remains X until prepared; the state machine alone controls VALID.
 reg [31:0] read_start_registered,write_start_registered,read_address,write_address;
 reg [4:0] read_burst_registered;
 reg [3:0] write_burst_registered;
 reg [15:0] rows,rows_done;
 reg [15:0] post_expected_tag;
 reg [5:0] chunk_rows,send_index,seen;
 reg [31:0] input_base,output_base,coefficient_base,scale;
 wire [1:0] cmd_coefficient_lane_0=cmd_coefficient_base[3:2]+2'd0;
 reg signed [7:0] coefficient_delta_0;
 wire [1:0] cmd_coefficient_lane_1=cmd_coefficient_base[3:2]+2'd1;
 reg signed [7:0] coefficient_delta_1;
 wire [1:0] cmd_coefficient_lane_2=cmd_coefficient_base[3:2]+2'd2;
 reg signed [7:0] coefficient_delta_2;
 wire [1:0] cmd_coefficient_lane_3=cmd_coefficient_base[3:2]+2'd3;
 reg signed [7:0] coefficient_delta_3;
 // Domain checks use unwrapped lane j; bank payload uses wrapped lane.
 // Cache ONLY the unwrapped signed8 delta at the existing command capture.
 reg signed [7:0] coefficient_domain_delta_0;
 reg signed [7:0] coefficient_domain_delta_1;
 reg signed [7:0] coefficient_domain_delta_2;
 reg signed [7:0] coefficient_domain_delta_3;
 function automatic signed [7:0] coefficient_domain_index(input [4:0] word_index,input integer lane_index);
  begin
   case(lane_index)
    0:coefficient_domain_index=word_index*4+coefficient_domain_delta_0;
    1:coefficient_domain_index=word_index*4+coefficient_domain_delta_1;
    2:coefficient_domain_index=word_index*4+coefficient_domain_delta_2;
    3:coefficient_domain_index=word_index*4+coefficient_domain_delta_3;
    default:coefficient_domain_index=8'bx;
   endcase
  end
 endfunction
 // Upper bound is invariant throughout an existing 32-row chunk.
 reg [6:0] coefficient_domain_end;
 function automatic [5:0] clip_chunk_rows(input [31:0] count);
  begin clip_chunk_rows=count>=32?6'd32:count[5:0];end
 endfunction
 function automatic coefficient_in_domain(input [4:0] word_index,input integer lane_index);
  reg signed [7:0] original_index;
  reg [6:0] linear_index;
  begin
   original_index=coefficient_domain_index(word_index,lane_index);
   linear_index={word_index,lane_index[1:0]};
   case(^{word_index,chunk_rows,coefficient_base[3:2],original_index,coefficient_domain_end})
    1'b0,1'b1:coefficient_in_domain=linear_index>={5'd0,coefficient_base[3:2]}&&linear_index<coefficient_domain_end;
    default:coefficient_in_domain=original_index>=0&&original_index<chunk_rows;
   endcase
  end
 endfunction
 reg [2:0] kind;
 reg coefficient_enable,coefficient_phase,read_bad;
 reg [4:0] read_word,read_total,burst_received,burst_length;
 reg [4:0] burst_terminal;
 reg finish_read_fault,finish_read_more;
 function automatic burst_is_last(input [4:0] received,length,terminal);
  begin
   case(^{received,length,terminal})
    1'b0,1'b1:burst_is_last=(length!=0)?(received==terminal):(received+1==length);
    default:burst_is_last=(received+1==length);
   endcase
  end
 endfunction
 wire expected_read_last=burst_is_last(burst_received,burst_length,burst_terminal);
 reg [31:0] read_terminal;
 wire more_read_words=(read_total==0)?(read_word+1<read_total):({27'd0,read_word}<read_terminal);
 reg [3:0] write_word,write_total,write_stop;
 // Each bank has one write port; payload is intentionally not reset.
 reg [63:0] integers_b0[0:15],integers_b1[0:15];
 reg [31:0] coefficients_b0[0:7],coefficients_b1[0:7],coefficients_b2[0:7],coefficients_b3[0:7];
 reg [31:0] floats_b0[0:7],floats_b1[0:7],floats_b2[0:7],floats_b3[0:7];
 wire [63:0] integer_selected=send_index[0]?integers_b1[send_index[4:1]]:integers_b0[send_index[4:1]];
 wire [31:0] coefficient_selected=send_index[1:0]==0?coefficients_b0[send_index[4:2]]:
  send_index[1:0]==1?coefficients_b1[send_index[4:2]]:
  send_index[1:0]==2?coefficients_b2[send_index[4:2]]:coefficients_b3[send_index[4:2]];
 wire [31:0] float_view0=(float_write_pending&&float_index_pending[4:2]==write_word[2:0]&&float_index_pending[1:0]==0)?float_value_pending:floats_b0[write_word[2:0]];
 wire [31:0] float_view1=(float_write_pending&&float_index_pending[4:2]==write_word[2:0]&&float_index_pending[1:0]==1)?float_value_pending:floats_b1[write_word[2:0]];
 wire [31:0] float_view2=(float_write_pending&&float_index_pending[4:2]==write_word[2:0]&&float_index_pending[1:0]==2)?float_value_pending:floats_b2[write_word[2:0]];
 wire [31:0] float_view3=(float_write_pending&&float_index_pending[4:2]==write_word[2:0]&&float_index_pending[1:0]==3)?float_value_pending:floats_b3[write_word[2:0]];
 wire [127:0] float_word={float_view3,float_view2,float_view1,float_view0};
 wire [32:0] window_end={1'b0,DDR_BASE}+DDR_BYTES;
 wire [31:0] read_start=coefficient_phase?((coefficient_base+({16'b0,rows_done}<<2))&32'hfffffff0):input_base+({16'b0,rows_done}<<3);
 assign m_axi_araddr=read_address;
 wire [31:0] write_start=output_base+({16'b0,rows_done}<<2);
 assign m_axi_awaddr=write_address;
 wire [8:0] read_page=(13'd4096-{1'b0,m_axi_araddr[11:0]})>>4;
 wire [8:0] write_page=(13'd4096-{1'b0,m_axi_awaddr[11:0]})>>4;
 wire [4:0] read_remaining=read_total-read_word;
 wire [3:0] write_remaining=write_total-write_word;
 wire [4:0] read_burst=read_remaining<read_page?read_remaining:read_page[4:0];
 wire [3:0] write_burst=write_remaining<write_page?write_remaining:write_page[3:0];
 assign cmd_ready=state==IDLE&&rst_n;
 assign rsp_valid=state==RESPONSE&&rst_n;
 assign busy=state!=IDLE&&state!=RESPONSE;
 assign m_axi_arvalid=state==RA&&rst_n;
 assign m_axi_rready=state==RD&&rst_n;
 assign m_axi_arlen=read_burst_registered-1'b1;
 assign m_axi_arsize=4;assign m_axi_arburst=1;
 assign m_axi_awvalid=state==WA&&rst_n;
 assign m_axi_awlen=write_burst_registered-1'b1;
 assign m_axi_awsize=4;assign m_axi_awburst=1;
 assign m_axi_wvalid=state==WD&&rst_n;
 assign m_axi_wlast=write_word+1'b1==write_stop;
 assign m_axi_bready=state==WB&&rst_n;
 wire post_valid,post_ready,post_last,post_error;
 wire [31:0] post_value;wire [15:0] post_tag;
 wire in_valid=state==STREAM;
 wire out_ready=state==STREAM||state==DRAIN;
 qwen_gemv_post_fp32_stream #(.TAG_WIDTH(16)) arithmetic(.clk,.rst_n(rst_n&&arithmetic_live),
  .in_valid,.in_ready(post_ready),.value_i64(integer_selected),.in_kind(kind),.a_fp32(scale),
  .b_fp32(coefficient_enable?coefficient_selected:32'b0),.c_fp32(kind==1?32'h3e000000:32'b0),
  .in_last(send_index+1==chunk_rows),.in_tag(rows_done+send_index),
  .out_valid(post_valid),.out_ready,.result_fp32(post_value),.out_error(post_error),.out_last(post_last),.out_tag(post_tag));
 integer lane;
 reg signed [7:0] index;
 reg current_coefficient_bad;
 reg signed [7:0] ci;
 always @* begin
  current_coefficient_bad=0;
  for(integer j=0;j<4;j=j+1)begin
   ci=coefficient_domain_index(read_word,j);
   if(coefficient_phase&&coefficient_in_domain(read_word,j)&&
      (m_axi_rdata[j*32+23 +:8]==255||(m_axi_rdata[j*32+23 +:8]==0&&m_axi_rdata[j*32 +:23]!=0)))current_coefficient_bad=1;
  end
 end
 always @* begin
  m_axi_wdata=0;m_axi_wstrb=0;
  for(integer j=0;j<4;j=j+1)if(write_word*4+j<chunk_rows)begin
   m_axi_wdata[j*32 +:32]=float_word[j*32 +:32];m_axi_wstrb[j*4 +:4]=4'hf;
  end
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin coefficient_domain_end<=0;burst_terminal<=0;finish_read_fault<=0;finish_read_more<=0;coefficient_domain_delta_0<=8'd0;coefficient_domain_delta_1<=8'd1;coefficient_domain_delta_2<=8'd2;coefficient_domain_delta_3<=8'd3;coefficient_delta_0<=8'd0;coefficient_delta_1<=8'd1;coefficient_delta_2<=8'd2;coefficient_delta_3<=8'd3;state<=IDLE;rows<=0;rows_done<=0;post_expected_tag<=0;chunk_rows<=0;send_index<=0;seen<=0;input_base<=0;output_base<=0;coefficient_base<=0;scale<=0;kind<=0;coefficient_enable<=0;coefficient_phase<=0;read_bad<=0;read_word<=0;read_total<=0;read_terminal<=0;burst_received<=0;burst_length<=0;write_word<=0;write_total<=0;write_stop<=0;rsp_seq<=0;rsp_error<=0;cycle_count<=0;end
  else begin
   if(busy)cycle_count<=cycle_count+1;
   case(state)
    IDLE:if(cmd_valid&&cmd_ready)begin
     rows<=cmd_rows;rows_done<=0;chunk_rows<=cmd_rows>=32?32:cmd_rows;coefficient_domain_end<={1'b0,clip_chunk_rows(cmd_rows)}+{5'd0,cmd_coefficient_base[3:2]};
     input_base<=cmd_input_base;output_base<=cmd_output_base;coefficient_base<=cmd_coefficient_base;coefficient_domain_delta_0<=8'd0-{6'b0,cmd_coefficient_base[3:2]};coefficient_domain_delta_1<=8'd1-{6'b0,cmd_coefficient_base[3:2]};coefficient_domain_delta_2<=8'd2-{6'b0,cmd_coefficient_base[3:2]};coefficient_domain_delta_3<=8'd3-{6'b0,cmd_coefficient_base[3:2]};coefficient_delta_0<=cmd_coefficient_lane_0-cmd_coefficient_base[3:2];coefficient_delta_1<=cmd_coefficient_lane_1-cmd_coefficient_base[3:2];coefficient_delta_2<=cmd_coefficient_lane_2-cmd_coefficient_base[3:2];coefficient_delta_3<=cmd_coefficient_lane_3-cmd_coefficient_base[3:2];scale<=cmd_scale_fp32;kind<=cmd_kind;coefficient_enable<=cmd_coefficient_enable;
     rsp_seq<=cmd_seq;rsp_error<=0;cycle_count<=0;read_word<=0;coefficient_phase<=0;read_bad<=0;read_total<=cmd_rows>=32?16:(cmd_rows+1)>>1;
     if(cmd_rows==0||cmd_kind>3||(cmd_kind==1&&!cmd_coefficient_enable)||cmd_input_base[3:0]!=0||cmd_output_base[3:0]!=0||(cmd_coefficient_enable&&cmd_coefficient_base[1:0]!=0)||
        {1'b0,cmd_input_base}<{1'b0,DDR_BASE}||{1'b0,cmd_input_base}+({17'b0,cmd_rows}<<3)>window_end||
        {1'b0,cmd_output_base}<{1'b0,DDR_BASE}||{1'b0,cmd_output_base}+({17'b0,cmd_rows}<<2)>window_end||
        (cmd_coefficient_enable&&({1'b0,cmd_coefficient_base}<{1'b0,DDR_BASE}||{1'b0,cmd_coefficient_base}+({17'b0,cmd_rows}<<2)>window_end)))begin rsp_error<=1;state<=RESPONSE;end
     else if(cmd_scale_fp32[30:23]==255||(cmd_scale_fp32[30:23]==0&&cmd_scale_fp32[22:0]!=0))begin rsp_error<=7;state<=RESPONSE;end
     else state<=READ_BASE;
    end
    READ_BASE:begin read_start_registered<=read_start;state<=READ_ADDR;end
    READ_ADDR:begin read_address<=read_start_registered+({27'b0,read_word}<<4);state<=READ_LIMIT;end
    READ_LIMIT:begin read_terminal<={27'd0,read_total}-32'd1;read_burst_registered<=read_burst;state<=RA;end
    WRITE_BASE:begin write_start_registered<=write_start;state<=WRITE_ADDR;end
    WRITE_ADDR:begin write_address<=write_start_registered+({28'b0,write_word}<<4);state<=WRITE_LIMIT;end
    WRITE_LIMIT:begin write_burst_registered<=write_burst;state<=WA;end
    RA:if(m_axi_arvalid&&m_axi_arready)begin burst_length<=read_burst_registered;burst_terminal<=read_burst_registered-5'd1;burst_received<=0;state<=RD;end
    RD:if(m_axi_rvalid&&m_axi_rready)begin
     if(m_axi_rresp!=0)begin read_bad<=1;rsp_error<=2;end
     if(m_axi_rlast!=expected_read_last)begin read_bad<=1;rsp_error<=3;end
     if(!coefficient_phase)begin
      for(lane=0;lane<2;lane=lane+1)if(read_word*2+lane<chunk_rows)begin end // payload written by fixed banks below
     end else begin
      for(lane=0;lane<4;lane=lane+1)begin
       index=coefficient_domain_index(read_word,lane);
       if(coefficient_in_domain(read_word,lane))begin
        // Payload written by one fixed port per bank below.
        if(m_axi_rdata[lane*32+23 +:8]==255||(m_axi_rdata[lane*32+23 +:8]==0&&m_axi_rdata[lane*32 +:23]!=0))begin read_bad<=1;rsp_error<=7;end
       end
      end
     end
     read_word<=read_word+1;burst_received<=burst_received+1;
     if(m_axi_rlast)begin
      finish_read_fault<=read_bad||current_coefficient_bad||m_axi_rresp!=0||!expected_read_last;
      finish_read_more<=more_read_words;
      state<=READ_FINISH;
     end
    end
    READ_FINISH:begin
     if(finish_read_fault)state<=RESPONSE;
     else if(finish_read_more)state<=READ_BASE;
     else if(!coefficient_phase&&coefficient_enable)begin coefficient_phase<=1;read_word<=0;read_total<=(chunk_rows+coefficient_base[3:2]+3)>>2;state<=READ_BASE;end
     else begin send_index<=0;seen<=0;post_expected_tag<=rows_done+16'd0;state<=STREAM;end
    end
    STREAM:if(in_valid&&post_ready)begin send_index<=send_index+1;if(send_index+1==chunk_rows)state<=DRAIN;end
    DRAIN:begin end
    WA:if(m_axi_awvalid&&m_axi_awready)begin write_stop<=write_word+write_burst_registered;state<=WD;end
    WD:if(m_axi_wvalid&&m_axi_wready)begin write_word<=write_word+1;if(m_axi_wlast)state<=WB;end
    WB:if(m_axi_bvalid&&m_axi_bready)begin
     if(m_axi_bresp!=0)begin rsp_error<=4;state<=RESPONSE;end
     else if(write_word<write_total)state<=WRITE_BASE;
     else if(rows_done+chunk_rows>=rows)state<=RESPONSE;
     else begin rows_done<=rows_done+chunk_rows;chunk_rows<=rows-rows_done-chunk_rows>=32?32:rows-rows_done-chunk_rows;coefficient_domain_end<={1'b0,clip_chunk_rows(rows-rows_done-chunk_rows)}+{5'd0,coefficient_base[3:2]};read_total<=rows-rows_done-chunk_rows>=32?16:(rows-rows_done-chunk_rows+1)>>1;read_word<=0;coefficient_phase<=0;read_bad<=0;state<=READ_BASE;end
    end
    RESPONSE:if(rsp_ready)state<=IDLE;
    default:begin rsp_error<=255;state<=RESPONSE;end
   endcase
   if(post_valid&&out_ready)begin
    if(post_error||post_tag!=post_expected_tag||post_last!=(seen+1==chunk_rows)||seen>=chunk_rows)begin rsp_error<=5;state<=RESPONSE;end
    else begin
     seen<=seen+1;post_expected_tag<=post_expected_tag+16'd1; // payload written by fixed banks below
     if(post_last)begin write_word<=0;write_total<=(chunk_rows+3)>>2;state<=WRITE_BASE;end
    end
   end
  end
 end

 // Write conditions retain the original four-state IF semantics.
 reg float_write_pending;
 reg [4:0] float_index_pending;reg [31:0] float_value_pending;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)float_write_pending<=0;
  else begin
   float_write_pending<=0;
   if(post_valid&&out_ready)begin
    // Retain the original explicit if/else four-state guard behavior.
    if(post_error||post_tag!=post_expected_tag||post_last!=(seen+1==chunk_rows)||seen>=chunk_rows)begin end
    else begin float_write_pending<=1;float_index_pending<=seen;float_value_pending<=post_value;end
   end
  end
 end
 always @(posedge clk) if(rst_n&&state==RD&&m_axi_rvalid&&m_axi_rready&&!coefficient_phase)begin
  if(read_word*2<chunk_rows)integers_b0[read_word[3:0]]<=m_axi_rdata[0 +:64];
  if(read_word*2+1<chunk_rows)integers_b1[read_word[3:0]]<=m_axi_rdata[64 +:64];
 end

 wire [1:0] coefficient_lane_0=coefficient_base[3:2]+2'd0;
 wire signed [7:0] coefficient_index_0=read_word*4+coefficient_delta_0;
 always @(posedge clk)begin
  if(rst_n&&state==RD&&m_axi_rvalid&&m_axi_rready)begin
   if(!coefficient_phase)begin end else
   if(coefficient_index_0>=0&&coefficient_index_0<chunk_rows)
    coefficients_b0[coefficient_index_0[4:2]]<=m_axi_rdata[coefficient_lane_0*32 +:32];
  end
  if(rst_n&&float_write_pending&&float_index_pending[1:0]==2'd0)floats_b0[float_index_pending[4:2]]<=float_value_pending;
 end

 wire [1:0] coefficient_lane_1=coefficient_base[3:2]+2'd1;
 wire signed [7:0] coefficient_index_1=read_word*4+coefficient_delta_1;
 always @(posedge clk)begin
  if(rst_n&&state==RD&&m_axi_rvalid&&m_axi_rready)begin
   if(!coefficient_phase)begin end else
   if(coefficient_index_1>=0&&coefficient_index_1<chunk_rows)
    coefficients_b1[coefficient_index_1[4:2]]<=m_axi_rdata[coefficient_lane_1*32 +:32];
  end
  if(rst_n&&float_write_pending&&float_index_pending[1:0]==2'd1)floats_b1[float_index_pending[4:2]]<=float_value_pending;
 end

 wire [1:0] coefficient_lane_2=coefficient_base[3:2]+2'd2;
 wire signed [7:0] coefficient_index_2=read_word*4+coefficient_delta_2;
 always @(posedge clk)begin
  if(rst_n&&state==RD&&m_axi_rvalid&&m_axi_rready)begin
   if(!coefficient_phase)begin end else
   if(coefficient_index_2>=0&&coefficient_index_2<chunk_rows)
    coefficients_b2[coefficient_index_2[4:2]]<=m_axi_rdata[coefficient_lane_2*32 +:32];
  end
  if(rst_n&&float_write_pending&&float_index_pending[1:0]==2'd2)floats_b2[float_index_pending[4:2]]<=float_value_pending;
 end

 wire [1:0] coefficient_lane_3=coefficient_base[3:2]+2'd3;
 wire signed [7:0] coefficient_index_3=read_word*4+coefficient_delta_3;
 always @(posedge clk)begin
  if(rst_n&&state==RD&&m_axi_rvalid&&m_axi_rready)begin
   if(!coefficient_phase)begin end else
   if(coefficient_index_3>=0&&coefficient_index_3<chunk_rows)
    coefficients_b3[coefficient_index_3[4:2]]<=m_axi_rdata[coefficient_lane_3*32 +:32];
  end
  if(rst_n&&float_write_pending&&float_index_pending[1:0]==2'd3)floats_b3[float_index_pending[4:2]]<=float_value_pending;
 end
endmodule
