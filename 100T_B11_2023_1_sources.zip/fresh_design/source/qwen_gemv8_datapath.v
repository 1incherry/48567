`timescale 1ns/1ps
// Group streaming datapath, ready for an AXI/DMA controller.
// Group metadata is captured with the accepted final beat, so it stays
// associated with its dot product even if a following group is presented.
module qwen_gemv8_datapath (
    input wire clk, input wire rst,
    input wire mode_i16,
    input wire in_valid, output wire in_ready,
    input wire signed [15:0] activation,
    input wire [127:0] weight_data,
    input wire in_last,
    input wire [127:0] group_scales,
    input wire first_group, input wire last_group,
    output wire out_valid, input wire out_ready,
    output wire [511:0] output_acc,
    output wire error,
    output wire group_consumed
);
    wire group_valid,group_ready;
    wire [383:0] dots;
    assign group_consumed = group_valid && group_ready;
    (* EXTRACT_ENABLE="NO" *) reg [127:0] scale_metadata;
    reg first_metadata,last_metadata,mode_metadata;
    always @(posedge clk) begin
        if(rst) begin
            scale_metadata<=0; first_metadata<=0; last_metadata<=0; mode_metadata<=0;
        end else if(in_valid && in_ready && in_last) begin
            scale_metadata<=group_scales; first_metadata<=first_group;
            last_metadata<=last_group; mode_metadata<=mode_i16;
        end
    end
    qwen_mac8_pipeline_v1 mac(.clk(clk),.rst(rst),.mode_i16(mode_i16),
        .in_valid(in_valid),.in_ready(in_ready),.activation(activation),
        .weight_data(weight_data),.in_last(in_last),.out_valid(group_valid),
        .out_ready(group_ready),.group_acc(dots));
    qwen_scale_acc8_pipeline_v1 scale(.clk(clk),.rst(rst),.in_valid(group_valid),
        .in_ready(group_ready),.group_acc(dots),.scale_bits(scale_metadata),
        .first_group(first_metadata),.last_group(last_metadata),.bypass_scale(mode_metadata),
        .out_valid(out_valid),.out_ready(out_ready),.output_acc(output_acc),.error(error));
endmodule
