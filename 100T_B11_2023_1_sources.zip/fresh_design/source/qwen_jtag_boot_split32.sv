`timescale 1ns/1ps
// Trusted-JTAG FullAXI32 split only. CPU has no connection to this upstream.
// Persistent control uses board_reset_n only, never CPU/epoch reset.
// W-before-AW is supported by backpressure: READY remains0 until an AW route is held.
// Ordinary legal bursts/IDs are unchanged. Any burst touching the boot word range
// is either an exact legal single word or rejected locally with zero boot traffic.
module qwen_jtag_boot_split32(
 input wire clk,board_reset_n,
 input wire normal_aw_admit,normal_ar_admit,boot_aw_admit,boot_ar_admit,
 output wire wr_pending,rd_pending,quiescent,protocol_fault,
 output wire[31:0]wr_addr,
 output wire[7:0]wr_len,
 output wire wr_boot_disable,wr_boot,rd_boot,
 input wire h_awid,
 input wire[31:0] h_awaddr,
 input wire[7:0] h_awlen,
 input wire[2:0] h_awsize,
 input wire[1:0] h_awburst,
 input wire h_awlock,
 input wire[3:0] h_awcache,
 input wire[2:0] h_awprot,
 input wire[3:0] h_awqos,
 input wire h_awvalid,
 output reg h_awready,
 input wire[31:0] h_wdata,
 input wire[3:0] h_wstrb,
 input wire h_wlast,
 input wire h_wvalid,
 output reg h_wready,
 output reg h_bid,
 output reg[1:0] h_bresp,
 output reg h_bvalid,
 input wire h_bready,
 input wire h_arid,
 input wire[31:0] h_araddr,
 input wire[7:0] h_arlen,
 input wire[2:0] h_arsize,
 input wire[1:0] h_arburst,
 input wire h_arlock,
 input wire[3:0] h_arcache,
 input wire[2:0] h_arprot,
 input wire[3:0] h_arqos,
 input wire h_arvalid,
 output reg h_arready,
 output reg h_rid,
 output reg[31:0] h_rdata,
 output reg[1:0] h_rresp,
 output reg h_rlast,
 output reg h_rvalid,
 input wire h_rready,
 output reg n_awid,
 output reg[31:0] n_awaddr,
 output reg[7:0] n_awlen,
 output reg[2:0] n_awsize,
 output reg[1:0] n_awburst,
 output reg n_awlock,
 output reg[3:0] n_awcache,
 output reg[2:0] n_awprot,
 output reg[3:0] n_awqos,
 output reg n_awvalid,
 input wire n_awready,
 output reg[31:0] n_wdata,
 output reg[3:0] n_wstrb,
 output reg n_wlast,
 output reg n_wvalid,
 input wire n_wready,
 input wire n_bid,
 input wire[1:0] n_bresp,
 input wire n_bvalid,
 output reg n_bready,
 output reg n_arid,
 output reg[31:0] n_araddr,
 output reg[7:0] n_arlen,
 output reg[2:0] n_arsize,
 output reg[1:0] n_arburst,
 output reg n_arlock,
 output reg[3:0] n_arcache,
 output reg[2:0] n_arprot,
 output reg[3:0] n_arqos,
 output reg n_arvalid,
 input wire n_arready,
 input wire n_rid,
 input wire[31:0] n_rdata,
 input wire[1:0] n_rresp,
 input wire n_rlast,
 input wire n_rvalid,
 output reg n_rready,
 output reg[31:0] b_awaddr,
 output reg[2:0] b_awprot,
 output reg b_awvalid,
 input wire b_awready,
 output reg[31:0] b_wdata,
 output reg[3:0] b_wstrb,
 output reg b_wvalid,
 input wire b_wready,
 input wire[1:0] b_bresp,
 input wire b_bvalid,
 output reg b_bready,
 output reg[31:0] b_araddr,
 output reg[2:0] b_arprot,
 output reg b_arvalid,
 input wire b_arready,
 input wire[31:0] b_rdata,
 input wire[1:0] b_rresp,
 input wire b_rvalid,
 output reg b_rready);

 localparam RT_NORMAL=0,RT_BOOT=1,RT_REJECT=2;
 localparam W_IDLE=0,W_NORMAL=1,W_COLLECT=2,W_BOOT=3,W_REJECT=4,W_ERROR=5,W_STUCK=6;
 localparam R_IDLE=0,R_NORMAL=1,R_BOOT=2,R_ERROR=3;
 reg[2:0]ws;reg[1:0]rs;
 reg[31:0]wa,ra,bwd;reg wid,rid_q;
 reg[7:0]wl,rl;reg[2:0]wsize,rsize;reg[1:0]wburst,rburst;
 reg wlock,rlock;reg[3:0]wcache,rcache,wqos,rqos,bws;
 reg[2:0]wprot,rprot;
 reg[8:0]wc,rc;reg aw_sent,ar_sent,w_complete,baw_sent,bw_sent;
 reg wr_bad,rd_bad;
 function automatic[1:0] route_of(input[31:0]address,input[7:0]len,input[2:0]size,input[1:0]burst,input lockbit);
  reg[32:0]bytes,span,lo,hi,mask;
  reg malformed,touch,exact;
  begin
   bytes=33'd1<<size;span=({25'd0,len}+1'b1)<<size;mask=bytes-1'b1;
   malformed=(size>2)||(burst==3);
   lo={1'b0,address};hi=({1'b0,address}&~mask)+bytes-1'b1;
   if(burst==1)hi=({1'b0,address}&~mask)+span-1'b1;
   if(burst==2)begin
    malformed=malformed||!((len==1)||(len==3)||(len==7)||(len==15))||((address&mask)!=0);
    lo={1'b0,address}&~(span-1'b1);hi=lo+span-1'b1;
   end
   malformed=malformed||hi[32]||(lo[31:12]!=hi[31:12]);
   touch=(lo<=33'h04100008b)&&(hi>=33'h041000080);
   exact=((address==32'h41000080)||(address==32'h41000084)||(address==32'h41000088))&&
         (len==0)&&(size==2)&&((burst==0)||(burst==1))&&!lockbit;
   if(malformed)route_of=RT_REJECT;
   else if(touch)route_of=exact?RT_BOOT:RT_REJECT;
   else route_of=RT_NORMAL;
  end
 endfunction
 wire[1:0]awroute=route_of(h_awaddr,h_awlen,h_awsize,h_awburst,h_awlock);
 wire[1:0]arroute=route_of(h_araddr,h_arlen,h_arsize,h_arburst,h_arlock);
 assign wr_pending=ws!=W_IDLE;
 assign rd_pending=rs!=R_IDLE;
 assign protocol_fault=wr_bad||rd_bad;
 assign quiescent=!wr_pending&&!rd_pending&&!protocol_fault;
 assign wr_addr=wa;assign wr_len=wl;
 assign wr_boot=(ws==W_COLLECT)||(ws==W_BOOT);
 assign rd_boot=rs==R_BOOT;
 // Candidate identity only. Not proof of helper acceptance; full drain exception
 // also requires source-domain side-helper owner/command-accepted handshake.
 assign wr_boot_disable=(ws==W_BOOT)&&(wa==32'h41000084)&&(bwd==0)&&(bws==15);
 always @*begin
  h_awready=0;h_wready=0;h_bid=wid;h_bresp=0;h_bvalid=0;
  n_awid=wid;n_awaddr=wa;n_awlen=wl;n_awsize=wsize;n_awburst=wburst;n_awlock=wlock;
  n_awcache=wcache;n_awprot=wprot;n_awqos=wqos;n_awvalid=0;
  n_wdata=h_wdata;n_wstrb=h_wstrb;n_wlast=h_wlast;n_wvalid=0;n_bready=0;
  b_awaddr=wa;b_awprot=wprot;b_awvalid=0;b_wdata=bwd;b_wstrb=bws;b_wvalid=0;b_bready=0;
  if(ws==W_IDLE&&!protocol_fault)h_awready=(awroute==RT_NORMAL)?normal_aw_admit:boot_aw_admit;
  if(ws==W_NORMAL&&!wr_bad)begin
   n_awvalid=!aw_sent;
   n_wvalid=h_wvalid&&!w_complete;h_wready=n_wready&&!w_complete;
   if(aw_sent&&w_complete&&(n_bid==wid))begin h_bvalid=n_bvalid;h_bresp=n_bresp;n_bready=h_bready;end
  end
  if(ws==W_COLLECT&&!wr_bad)h_wready=1;
  if(ws==W_BOOT&&!wr_bad)begin
   b_awvalid=!baw_sent;b_wvalid=!bw_sent;
   if(baw_sent&&bw_sent)begin h_bvalid=b_bvalid;h_bresp=b_bresp;b_bready=h_bready;end
  end
  if(ws==W_REJECT&&!wr_bad)h_wready=1;
  if(ws==W_ERROR&&!wr_bad)begin h_bvalid=1;h_bresp=2'b10;end
  h_arready=0;h_rid=rid_q;h_rdata=0;h_rresp=0;h_rlast=0;h_rvalid=0;
  n_arid=rid_q;n_araddr=ra;n_arlen=rl;n_arsize=rsize;n_arburst=rburst;n_arlock=rlock;
  n_arcache=rcache;n_arprot=rprot;n_arqos=rqos;n_arvalid=0;n_rready=0;
  b_araddr=ra;b_arprot=rprot;b_arvalid=0;b_rready=0;
  if(rs==R_IDLE&&!protocol_fault)h_arready=(arroute==RT_NORMAL)?normal_ar_admit:boot_ar_admit;
  if(rs==R_NORMAL&&!rd_bad)begin
   n_arvalid=!ar_sent;
   if(ar_sent&&(n_rid==rid_q)&&(n_rlast==(rc=={1'b0,rl})))begin
    h_rvalid=n_rvalid;h_rdata=n_rdata;h_rresp=n_rresp;h_rlast=n_rlast;n_rready=h_rready;
   end
  end
  if(rs==R_BOOT&&!rd_bad)begin
   b_arvalid=!ar_sent;
   if(ar_sent)begin h_rvalid=b_rvalid;h_rdata=b_rdata;h_rresp=b_rresp;h_rlast=1;b_rready=h_rready;end
  end
  if(rs==R_ERROR&&!rd_bad)begin h_rvalid=1;h_rresp=2'b10;h_rlast=rc=={1'b0,rl};end
 end
 always @(posedge clk or negedge board_reset_n)begin
  if(!board_reset_n)begin
   ws<=W_IDLE;wa<=0;wid<=0;wl<=0;wsize<=0;wburst<=0;wlock<=0;wcache<=0;wprot<=0;wqos<=0;
   wc<=0;aw_sent<=0;w_complete<=0;baw_sent<=0;bw_sent<=0;bwd<=0;bws<=0;wr_bad<=0;
  end else begin
   if(h_awvalid&&h_awready)begin
    wa<=h_awaddr;wid<=h_awid;wl<=h_awlen;wsize<=h_awsize;wburst<=h_awburst;wlock<=h_awlock;
    wcache<=h_awcache;wprot<=h_awprot;wqos<=h_awqos;wc<=0;aw_sent<=0;w_complete<=0;baw_sent<=0;bw_sent<=0;
    case(awroute)RT_NORMAL:ws<=W_NORMAL;RT_BOOT:ws<=W_COLLECT;default:ws<=W_REJECT;endcase
   end
   if(ws==W_NORMAL&&!wr_bad)begin
    if(n_awvalid&&n_awready)aw_sent<=1;
    if(h_wvalid&&h_wready)begin
     if(h_wlast!=(wc=={1'b0,wl}))begin wr_bad<=1;end
     else if(wc=={1'b0,wl})w_complete<=1;
     wc<=wc+1'b1;
    end
    if(n_bvalid&&(!aw_sent||!w_complete||n_bid!=wid))wr_bad<=1;
    if(h_bvalid&&h_bready)ws<=W_IDLE;
   end
   if(ws==W_COLLECT&&!wr_bad&&h_wvalid&&h_wready)begin
    bwd<=h_wdata;bws<=h_wstrb;
    if(!h_wlast)begin wr_bad<=1;ws<=W_STUCK;end
    else if(h_wstrb!=15)ws<=W_ERROR;
    else ws<=W_BOOT;
   end
   if(ws==W_BOOT&&!wr_bad)begin
    if(b_awvalid&&b_awready)baw_sent<=1;
    if(b_wvalid&&b_wready)bw_sent<=1;
    if(b_bvalid&&(!baw_sent||!bw_sent))wr_bad<=1;
    if(h_bvalid&&h_bready)ws<=W_IDLE;
   end
   if(ws==W_REJECT&&!wr_bad&&h_wvalid&&h_wready)begin
    if(h_wlast!=(wc=={1'b0,wl}))begin wr_bad<=1;ws<=W_STUCK;end
    else if(wc=={1'b0,wl})ws<=W_ERROR;
    wc<=wc+1'b1;
   end
   if(ws==W_ERROR&&h_bvalid&&h_bready)ws<=W_IDLE;
  end
 end
 always @(posedge clk or negedge board_reset_n)begin
  if(!board_reset_n)begin
   rs<=R_IDLE;ra<=0;rid_q<=0;rl<=0;rsize<=0;rburst<=0;rlock<=0;rcache<=0;rprot<=0;rqos<=0;
   rc<=0;ar_sent<=0;rd_bad<=0;
  end else begin
   if(h_arvalid&&h_arready)begin
    ra<=h_araddr;rid_q<=h_arid;rl<=h_arlen;rsize<=h_arsize;rburst<=h_arburst;rlock<=h_arlock;
    rcache<=h_arcache;rprot<=h_arprot;rqos<=h_arqos;rc<=0;ar_sent<=0;
    case(arroute)RT_NORMAL:rs<=R_NORMAL;RT_BOOT:rs<=R_BOOT;default:rs<=R_ERROR;endcase
   end
   if(rs==R_NORMAL&&!rd_bad)begin
    if(n_arvalid&&n_arready)ar_sent<=1;
    if(n_rvalid&&(!ar_sent||n_rid!=rid_q||n_rlast!=(rc=={1'b0,rl})))rd_bad<=1;
    if(h_rvalid&&h_rready)begin if(h_rlast)rs<=R_IDLE;else rc<=rc+1'b1;end
   end
   if(rs==R_BOOT&&!rd_bad)begin
    if(b_arvalid&&b_arready)ar_sent<=1;
    if(b_rvalid&&!ar_sent)rd_bad<=1;
    if(h_rvalid&&h_rready)rs<=R_IDLE;
   end
   if(rs==R_ERROR&&h_rvalid&&h_rready)begin if(h_rlast)rs<=R_IDLE;else rc<=rc+1'b1;end
  end
 end
endmodule
