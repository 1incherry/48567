`timescale 1ns/1ps
// TX125 domain. One normal REQUEST per handover; existing ACK/CANCEL live.
module qwen_camera_window_gate_r1 #(
 parameter [31:0] REQUEST_WAIT_CYCLES=32'd125000000
)(
 input wire clk,board_reset_n,epoch_live,
 input wire window_request,owner_live,
 input wire request_accepted,sender_busy,sender_done,sender_fault,
 input wire source_ready,source_error,capture_request,block_request,
 input wire packet_quiet,mac_quiet,reply_busy,control_quiet,
 input wire bridge_quiet,shared_quiet,
 output wire new_request_permit,camera_sublease_active,
 output wire done,
 output reg frame_completed,fault,
 output wire draining
);
 localparam CLOSED=0,ADMIT=1,ACTIVE=2,DRAIN=3,DONE=4;
 reg[2:0]state;
 reg[31:0]age;
 reg[1:0]quiet_history;
 reg seen_busy;
 wire retired=source_ready&&!sender_busy&&!capture_request&&!block_request&&
  packet_quiet&&mac_quiet&&!reply_busy&&control_quiet&&bridge_quiet&&shared_quiet;
 assign new_request_permit=board_reset_n&&epoch_live&&owner_live&&!fault&&state==ADMIT&&window_request;
 assign camera_sublease_active=board_reset_n&&epoch_live&&
  (state==ADMIT||state==ACTIVE||state==DRAIN);
 assign draining=state==DRAIN;
 assign done=board_reset_n&&state==DONE;
 always @(posedge clk or negedge board_reset_n)begin
  if(!board_reset_n)begin state<=CLOSED;age<=0;quiet_history<=0;frame_completed<=0;fault<=0;seen_busy<=0;end
  else begin
   quiet_history<={quiet_history[0],retired};
   if(state!=CLOSED&&(!epoch_live||!owner_live))fault<=1;
   if(state==ACTIVE&&(source_error||sender_fault))fault<=1;
   case(state)
    CLOSED:begin
     age<=0;seen_busy<=0;
     if(window_request&&!fault&&epoch_live&&owner_live&&retired&&(&quiet_history))begin
      state<=ADMIT;frame_completed<=0;
     end
    end
    ADMIT:begin
     if(request_accepted)begin state<=ACTIVE;seen_busy<=sender_busy;age<=0;quiet_history<=0;end
     else if(!window_request||fault||age==REQUEST_WAIT_CYCLES-1)begin state<=DRAIN;quiet_history<=0;end
     else age<=age+1'b1;
    end
    ACTIVE:begin
     if(sender_busy)seen_busy<=1;
     if(sender_done)frame_completed<=1;
     // A withdrawn core request is an error, never permission to drop a tail.
     if(!window_request)fault<=1;
     if(seen_busy&&!sender_busy)begin state<=DRAIN;quiet_history<=0;end
    end
    DRAIN:if(retired&&(&quiet_history))state<=DONE;
    DONE:if(!window_request)begin state<=CLOSED;quiet_history<=0;end
    default:begin fault<=1;state<=DRAIN;quiet_history<=0;end
   endcase
  end
 end
endmodule
