`timescale 1ns/1ps
// Independent UTF8 question ingress; no physical UART/top or CPU is instantiated.
// Legacy owner is default. Explicit trusted mode_set selects runtime ingress.
// Wire format:7E, escaped(LE16 length + payload + LE16 CRC16-CCITT),7E.
// 7D escapes next byte with XOR20; CRC initialFFFF covers decoded length/payload.
module uart_utf8_frontend #(
 parameter integer MAX_BYTES=4096,FIFO_DEPTH=64,DEFAULT_RUNTIME_MODE=0
)(
 input wire clk,rst_n,
 input wire mode_set,mode_value,output reg runtime_mode,
 input wire [7:0]rx_byte,input wire rx_valid,rx_error,
 output wire [7:0]legacy_rx_byte,output wire legacy_rx_valid,legacy_rx_error,legacy_owner,
 input wire parse_enable,
 output reg question_valid,output reg[15:0]question_length,
 output reg data_valid,output reg[7:0]data,output reg data_last,input wire data_ready,
 output reg question_committed,question_rejected,output reg[6:0]reject_reason,
 output reg[31:0]accepted_count,rejected_count,overflow_count,mode_abort_count,
 output wire fifo_valid,output wire[15:0]fifo_level,output reg resync_wire,
 input wire admit_question
);
 localparam integer FW=FIFO_DEPTH<=1?1:$clog2(FIFO_DEPTH);
 localparam integer CW=$clog2(FIFO_DEPTH+1);
 localparam integer MW=MAX_BYTES<=1?1:$clog2(MAX_BYTES);
 localparam[6:0]FRAME=7'h01,LENGTH=7'h02,UTF8=7'h04,BUSY=7'h08,OVERFLOW=7'h10,UART=7'h20,MODE=7'h40;
 initial begin if(MAX_BYTES<1||MAX_BYTES>65535||FIFO_DEPTH<2||FIFO_DEPTH>65535)$error("BAD_FRONTEND_PARAMETERS");end
 assign legacy_owner=!runtime_mode;
 assign legacy_rx_byte=rx_byte;
 assign legacy_rx_valid=rx_valid&&!runtime_mode&&!mode_set;
 assign legacy_rx_error=rx_error&&!runtime_mode&&!mode_set;
 reg[7:0]fifo[0:FIFO_DEPTH-1];reg[FW-1:0]wp,rp;reg[CW-1:0]count;
 assign fifo_valid=count!=0;assign fifo_level=count;
 wire mode_change=mode_set&&(mode_value!=runtime_mode);
 wire pop=runtime_mode&&!mode_set&&!resync_wire&&parse_enable&&count!=0;
 wire overflow=runtime_mode&&!mode_set&&!resync_wire&&rx_valid&&count==FIFO_DEPTH&&!pop;
 wire push=runtime_mode&&!mode_set&&!resync_wire&&rx_valid&&(count<FIFO_DEPTH||pop);
 wire[7:0]head=fifo[rp];
 (* ram_style="block" *)reg[7:0]question_mem[0:MAX_BYTES-1];
 reg read_pending;reg[7:0]read_q;reg[MW-1:0]read_index;
 reg have_boundary,started,escape;
 reg[16:0]body_count;
 reg[15:0]payload_length,crc,received_crc;
 reg[6:0]bad;
 reg[2:0]utf_need;reg[7:0]utf_lower,utf_upper;
 wire[7:0]decoded=head^(escape?8'h20:8'h00);
 wire[16:0]payload_end={1'b0,payload_length}+17'd2;
 function[15:0]crc16(input[15:0]old,input[7:0]value);
  reg[15:0]c;integer k;
  begin c=old^{value,8'd0};for(k=0;k<8;k=k+1)c=c[15]?(c<<1)^16'h1021:c<<1;crc16=c;end
 endfunction
 // Memory has noreset loop. Visibility and read state gate all stale cells.
 always @(posedge clk)begin
  if(rst_n&&question_valid&&!data_valid&&!read_pending)read_q<=question_mem[read_index];
  if(rst_n&&pop&&head!=8'h7e&&(escape||head!=8'h7d)&&have_boundary&&started&&
    body_count>=2&&body_count<payload_end&&bad==0&&!question_valid&&!rx_error&&!overflow&&!mode_change)
   question_mem[body_count-2]<=decoded;
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   runtime_mode<=DEFAULT_RUNTIME_MODE!=0;wp<=0;rp<=0;count<=0;resync_wire<=0;
   question_valid<=0;question_length<=0;data_valid<=0;data<=0;data_last<=0;read_pending<=0;read_index<=0;
   have_boundary<=0;started<=0;escape<=0;body_count<=0;payload_length<=0;crc<=16'hffff;received_crc<=0;bad<=0;utf_need<=0;utf_lower<=8'h80;utf_upper<=8'hbf;
   question_committed<=0;question_rejected<=0;reject_reason<=0;accepted_count<=0;rejected_count<=0;overflow_count<=0;mode_abort_count<=0;
  end else begin
   question_committed<=0;question_rejected<=0;
   if(mode_set)runtime_mode<=mode_value;
   if(question_valid&&!data_valid&&!read_pending)read_pending<=1;
   else if(read_pending)begin data<=read_q;data_valid<=1;data_last<=read_index==question_length-1;read_pending<=0;end
   if(data_valid&&data_ready)begin
    data_valid<=0;
    if(data_last)begin question_valid<=0;question_length<=0;data_last<=0;read_index<=0;end
    else read_index<=read_index+1'b1;
   end
   if(mode_change)begin
    if(started||question_valid||count!=0)begin mode_abort_count<=mode_abort_count+1'b1;question_rejected<=1;reject_reason<=MODE;rejected_count<=rejected_count+1'b1;end
    wp<=0;rp<=0;count<=0;resync_wire<=0;have_boundary<=0;started<=0;escape<=0;body_count<=0;payload_length<=0;crc<=16'hffff;received_crc<=0;bad<=0;utf_need<=0;
    question_valid<=0;question_length<=0;data_valid<=0;data_last<=0;read_pending<=0;read_index<=0;
   end else if(runtime_mode)begin
    if(overflow||rx_error)begin
     // Detect overflow on the wire, flush queued earlier bytes and invalidate
     // only the private assembly. An existing committed question is untouched.
     wp<=0;rp<=0;count<=0;resync_wire<=!(rx_valid&&rx_byte==8'h7e);
     have_boundary<=rx_valid&&rx_byte==8'h7e;started<=0;escape<=0;body_count<=0;payload_length<=0;crc<=16'hffff;received_crc<=0;bad<=0;utf_need<=0;
     question_rejected<=1;reject_reason<=overflow?OVERFLOW:UART;rejected_count<=rejected_count+1'b1;
     if(overflow)overflow_count<=overflow_count+1'b1;
    end else if(resync_wire)begin
     if(rx_valid&&rx_byte==8'h7e)begin resync_wire<=0;have_boundary<=1;end
    end else begin
     if(push)begin fifo[wp]<=rx_byte;wp<=wp==FIFO_DEPTH-1?0:wp+1'b1;end
     if(pop)rp<=rp==FIFO_DEPTH-1?0:rp+1'b1;
     case({push,pop})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:begin end endcase
     if(pop)begin
      if(head==8'h7e)begin
       if(started||escape)begin
        if(bad==0&&!escape&&payload_length!=0&&payload_length<=MAX_BYTES&&body_count==payload_end+2&&utf_need==0&&crc==received_crc&&!question_valid)begin
         question_valid<=1;question_length<=payload_length;read_index<=0;data_valid<=0;data_last<=0;read_pending<=0;
         question_committed<=1;accepted_count<=accepted_count+1'b1;
        end else begin
         question_rejected<=1;rejected_count<=rejected_count+1'b1;
         reject_reason<=bad | ((escape||crc!=received_crc)?FRAME:0) |
           ((payload_length==0||payload_length>MAX_BYTES||body_count!=payload_end+2)?LENGTH:0) |
           ((utf_need!=0)?UTF8:0) | (question_valid?BUSY:0);
        end
       end
       have_boundary<=1;started<=0;escape<=0;body_count<=0;payload_length<=0;crc<=16'hffff;received_crc<=0;bad<=0;utf_need<=0;utf_lower<=8'h80;utf_upper<=8'hbf;
      end else if(have_boundary)begin
       if(!escape&&head==8'h7d)escape<=1;
       else begin
        escape<=0;
        if(!started)begin
         started<=1;body_count<=1;payload_length<={8'd0,decoded};crc<=crc16(16'hffff,decoded);bad<=(question_valid||(admit_question!==1'b1))?BUSY:0;
        end else begin
         if(body_count!=17'h1ffff)body_count<=body_count+1'b1;else bad<=bad|LENGTH;
         if(body_count==1)begin
          payload_length<={decoded,payload_length[7:0]};crc<=crc16(crc,decoded);
          if({decoded,payload_length[7:0]}==0||{decoded,payload_length[7:0]}>MAX_BYTES)bad<=bad|LENGTH;
         end else if(body_count>=2&&body_count<payload_end)begin
          crc<=crc16(crc,decoded);
          if(utf_need!=0)begin
           if(decoded<utf_lower||decoded>utf_upper)begin bad<=bad|UTF8;utf_need<=0;end
           else begin utf_need<=utf_need-1'b1;utf_lower<=8'h80;utf_upper<=8'hbf;end
          end else if(decoded<=8'h7f)begin end
          else if(decoded>=8'hc2&&decoded<=8'hdf)begin utf_need<=1;utf_lower<=8'h80;utf_upper<=8'hbf;end
          else if(decoded>=8'he0&&decoded<=8'hef)begin utf_need<=2;utf_lower<=decoded == 8'he0 ? 8'ha0 : 8'h80;utf_upper<=decoded == 8'hed ? 8'h9f : 8'hbf;end
          else if(decoded>=8'hf0&&decoded<=8'hf4)begin utf_need<=3;utf_lower<=decoded == 8'hf0 ? 8'h90 : 8'h80;utf_upper<=decoded == 8'hf4 ? 8'h8f : 8'hbf;end
          else bad<=bad|UTF8;
         end else if(body_count==payload_end)received_crc[7:0]<=decoded;
         else if(body_count==payload_end+1)received_crc[15:8]<=decoded;
         else bad<=bad|LENGTH;
        end
       end
      end
     end
    end
   end
  end
 end
endmodule
