// CPU-free auxiliary executor, candidate source only until integrated validation.
// Hold the accepted owner until its final response: no caller must keep cmd_op
// fixed after command acceptance. All four bus channels belong to that owner.
module qwen_auxiliary_axi128_executor_v14 #(parameter [31:0] DDR_BASE=32'h80000000)(
 input wire clk,rst_n,cmd_valid,output wire cmd_ready,
 input wire [3:0] cmd_op,input wire [15:0] cmd_rows,cmd_padding,cmd_seq,cmd_token,
 input wire [9:0] cmd_position,
 input wire [31:0] cmd_source_base,cmd_output_base,cmd_param_offset,cmd_matrix_offset,
 output wire [287:0] debug_nonlinear,
 output wire rsp_valid,input wire rsp_ready,output wire [15:0] rsp_seq,rsp_token,
 output wire [7:0] rsp_error,output wire [31:0] rsp_quant_scale,output wire busy,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 reg p_valid;
 reg [3:0] p_op;reg [15:0] p_rows,p_padding,p_seq,p_token;
 reg [9:0] p_position;
 reg [31:0] p_source_base,p_output_base,p_param_offset,p_matrix_offset;
 wire inner_ready;
 assign cmd_ready=rst_n&&!p_valid&&owner==NONE;
 // Payload is deliberately unreset; valid controls all use of unknown cells.
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)p_valid<=0;
  else begin
   if(cmd_valid&&cmd_ready)begin
    p_valid<=1;
    p_op<=cmd_op;
    p_rows<=cmd_rows;
    p_padding<=cmd_padding;
    p_seq<=cmd_seq;
    p_token<=cmd_token;
    p_position<=cmd_position;
    p_source_base<=cmd_source_base;
    p_output_base<=cmd_output_base;
    p_param_offset<=cmd_param_offset;
    p_matrix_offset<=cmd_matrix_offset;
   end
   else if(p_valid&&inner_ready)p_valid<=0;
  end
 end
 localparam NONE=0,EMBED=1,VECTOR=2,ARGMAX=3,BAD=4;
 reg [2:0] owner;reg [15:0] bad_seq;
 wire is_vector=(p_op==1||p_op==2||p_op==6||p_op==9||p_op==11||p_op==12)&&p_rows<=4864&&p_padding<=4864;
 wire [2:0] requested=p_op==0?EMBED:is_vector?VECTOR:p_op==14?ARGMAX:BAD;
 wire e_ready,v_ready,a_ready,e_rsp,v_rsp,a_rsp;
 wire [15:0] e_seq,v_seq,a_seq,a_token;
 wire [7:0] e_error,v_error,a_error;
 wire [31:0] v_scale,e_cycles,v_cycles,a_cycles;wire signed [63:0] a_value;
 wire e_busy,v_busy,a_busy;
 wire [31:0] auxiliary=p_op==6?DDR_BASE+32'h0e720000+({22'd0,p_position}<<8):
  p_op==11?DDR_BASE+32'h0e640000:p_op==12?DDR_BASE+32'h0e650000:DDR_BASE+p_param_offset;
 assign inner_ready=rst_n&&owner==NONE&&(requested==EMBED?e_ready:requested==VECTOR?v_ready:requested==ARGMAX?a_ready:1'b1);
 wire response_raw_valid=rst_n&&(owner==EMBED?e_rsp:owner==VECTOR?v_rsp:owner==ARGMAX?a_rsp:owner==BAD);
 wire [15:0] response_raw_seq=owner==EMBED?e_seq:owner==VECTOR?v_seq:owner==ARGMAX?a_seq:bad_seq;
 wire [15:0] response_raw_token=owner==ARGMAX?a_token:16'd0;
 wire [7:0] response_raw_error=owner==EMBED?e_error:owner==VECTOR?v_error:owner==ARGMAX?a_error:8'd1;
 wire [31:0] response_raw_scale=owner==VECTOR?v_scale:32'd0;
 reg response_pending;
 reg [15:0] response_seq,response_token;reg [7:0] response_error;reg [31:0] response_scale;
 wire response_capture_ready=rst_n&&!response_pending;
 assign rsp_valid=rst_n&&response_pending;assign rsp_seq=response_seq;assign rsp_token=response_token;
 assign rsp_error=response_error;assign rsp_quant_scale=response_scale;
 // One held response, with no payload reset or unknown-to-zero conversion.
 // Owner remains selected until the external consumer accepts this packet.
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)response_pending<=0;
  else begin
   if(response_raw_valid&&response_capture_ready)begin
    response_pending<=1;response_seq<=response_raw_seq;response_token<=response_raw_token;
    response_error<=response_raw_error;response_scale<=response_raw_scale;
   end else if(rsp_valid&&rsp_ready)response_pending<=0;
  end
 end
 assign busy=(owner!=NONE)||p_valid;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin owner<=NONE;bad_seq<=0;end
  else begin
   if(p_valid&&inner_ready)begin owner<=requested;bad_seq<=p_seq;end
   if(rsp_valid&&rsp_ready)owner<=NONE;
  end
 end
 wire [31:0] e_araddr;
 wire [7:0] e_arlen;
 wire [2:0] e_arsize;
 wire [1:0] e_arburst;
 wire e_arvalid;
 wire e_rready;
 wire [31:0] e_awaddr;
 wire [7:0] e_awlen;
 wire [2:0] e_awsize;
 wire [1:0] e_awburst;
 wire e_awvalid;
 wire [127:0] e_wdata;
 wire [15:0] e_wstrb;
 wire e_wlast;
 wire e_wvalid;
 wire e_bready;
 wire [31:0] v_araddr;
 wire [7:0] v_arlen;
 wire [2:0] v_arsize;
 wire [1:0] v_arburst;
 wire v_arvalid;
 wire v_rready;
 wire [31:0] v_awaddr;
 wire [7:0] v_awlen;
 wire [2:0] v_awsize;
 wire [1:0] v_awburst;
 wire v_awvalid;
 wire [127:0] v_wdata;
 wire [15:0] v_wstrb;
 wire v_wlast;
 wire v_wvalid;
 wire v_bready;
 wire [31:0] a_araddr;
 wire [7:0] a_arlen;
 wire [2:0] a_arsize;
 wire [1:0] a_arburst;
 wire a_arvalid;
 wire a_rready;
 wire [31:0] a_awaddr;
 wire [7:0] a_awlen;
 wire [2:0] a_awsize;
 wire [1:0] a_awburst;
 wire a_awvalid;
 wire [127:0] a_wdata;
 wire [15:0] a_wstrb;
 wire a_wlast;
 wire a_wvalid;
 wire a_bready;
 qwen_embedding_axi128_v6 #(.DDR_BASE(DDR_BASE)) embedding(
  .clk,.rst_n,.cmd_valid(p_valid&&inner_ready&&requested==EMBED),.cmd_ready(e_ready),
  .cmd_token(p_token),.cmd_seq(p_seq),.cmd_model_base(DDR_BASE+p_matrix_offset),.cmd_output_base(p_output_base),
  .rsp_valid(e_rsp),.rsp_ready(response_capture_ready&&owner==EMBED),.rsp_seq(e_seq),.rsp_error(e_error),.busy(e_busy),.cycle_count(e_cycles),
  .m_axi_araddr(e_araddr),
  .m_axi_arlen(e_arlen),
  .m_axi_arsize(e_arsize),
  .m_axi_arburst(e_arburst),
  .m_axi_arvalid(e_arvalid),
  .m_axi_arready((owner==EMBED&&m_axi_arready)),
  .m_axi_rdata(m_axi_rdata),
  .m_axi_rresp(m_axi_rresp),
  .m_axi_rlast(m_axi_rlast),
  .m_axi_rvalid((owner==EMBED&&m_axi_rvalid)),
  .m_axi_rready(e_rready),
  .m_axi_awaddr(e_awaddr),
  .m_axi_awlen(e_awlen),
  .m_axi_awsize(e_awsize),
  .m_axi_awburst(e_awburst),
  .m_axi_awvalid(e_awvalid),
  .m_axi_awready((owner==EMBED&&m_axi_awready)),
  .m_axi_wdata(e_wdata),
  .m_axi_wstrb(e_wstrb),
  .m_axi_wlast(e_wlast),
  .m_axi_wvalid(e_wvalid),
  .m_axi_wready((owner==EMBED&&m_axi_wready)),
  .m_axi_bresp(m_axi_bresp),
  .m_axi_bvalid((owner==EMBED&&m_axi_bvalid)),
  .m_axi_bready(e_bready));
 qwen_vector_fp32_axi128_executor_v9 #(.DDR_BASE(DDR_BASE)) vector(
  .diagnostic_state(debug_nonlinear),
  .clk,.rst_n,.cmd_valid(p_valid&&inner_ready&&requested==VECTOR),.cmd_ready(v_ready),
  .cmd_op(p_op),.cmd_rows(p_rows[12:0]),.cmd_padding(p_padding[12:0]),.cmd_seq(p_seq),
  .cmd_source_base(p_source_base),.cmd_auxiliary_base(auxiliary),.cmd_output_base(p_output_base),
  .rsp_valid(v_rsp),.rsp_ready(response_capture_ready&&owner==VECTOR),.rsp_seq(v_seq),.rsp_error(v_error),.rsp_quant_scale(v_scale),.busy(v_busy),.cycle_count(v_cycles),
  .m_axi_araddr(v_araddr),
  .m_axi_arlen(v_arlen),
  .m_axi_arsize(v_arsize),
  .m_axi_arburst(v_arburst),
  .m_axi_arvalid(v_arvalid),
  .m_axi_arready((owner==VECTOR&&m_axi_arready)),
  .m_axi_rdata(m_axi_rdata),
  .m_axi_rresp(m_axi_rresp),
  .m_axi_rlast(m_axi_rlast),
  .m_axi_rvalid((owner==VECTOR&&m_axi_rvalid)),
  .m_axi_rready(v_rready),
  .m_axi_awaddr(v_awaddr),
  .m_axi_awlen(v_awlen),
  .m_axi_awsize(v_awsize),
  .m_axi_awburst(v_awburst),
  .m_axi_awvalid(v_awvalid),
  .m_axi_awready((owner==VECTOR&&m_axi_awready)),
  .m_axi_wdata(v_wdata),
  .m_axi_wstrb(v_wstrb),
  .m_axi_wlast(v_wlast),
  .m_axi_wvalid(v_wvalid),
  .m_axi_wready((owner==VECTOR&&m_axi_wready)),
  .m_axi_bresp(m_axi_bresp),
  .m_axi_bvalid((owner==VECTOR&&m_axi_bvalid)),
  .m_axi_bready(v_bready));
 qwen_argmax_axi128_v2 #(.DDR_BASE(DDR_BASE)) argmax(
  .clk,.rst_n,.cmd_valid(p_valid&&inner_ready&&requested==ARGMAX),.cmd_ready(a_ready),
  .cmd_rows(p_rows),.cmd_seq(p_seq),.cmd_input_base(p_source_base),
  .rsp_valid(a_rsp),.rsp_ready(response_capture_ready&&owner==ARGMAX),.rsp_seq(a_seq),.rsp_token(a_token),.rsp_value(a_value),.rsp_error(a_error),.busy(a_busy),.cycle_count(a_cycles),
  .m_axi_araddr(a_araddr),
  .m_axi_arlen(a_arlen),
  .m_axi_arsize(a_arsize),
  .m_axi_arburst(a_arburst),
  .m_axi_arvalid(a_arvalid),
  .m_axi_arready((owner==ARGMAX&&m_axi_arready)),
  .m_axi_rdata(m_axi_rdata),
  .m_axi_rresp(m_axi_rresp),
  .m_axi_rlast(m_axi_rlast),
  .m_axi_rvalid((owner==ARGMAX&&m_axi_rvalid)),
  .m_axi_rready(a_rready));
 assign m_axi_araddr=owner==EMBED?e_araddr:owner==VECTOR?v_araddr:owner==ARGMAX?a_araddr:32'd0;
 assign m_axi_arlen=owner==EMBED?e_arlen:owner==VECTOR?v_arlen:owner==ARGMAX?a_arlen:8'd0;
 assign m_axi_arsize=owner==EMBED?e_arsize:owner==VECTOR?v_arsize:owner==ARGMAX?a_arsize:3'd0;
 assign m_axi_arburst=owner==EMBED?e_arburst:owner==VECTOR?v_arburst:owner==ARGMAX?a_arburst:2'd0;
 assign m_axi_arvalid=owner==EMBED?e_arvalid:owner==VECTOR?v_arvalid:owner==ARGMAX?a_arvalid:1'd0;
 assign m_axi_rready=owner==EMBED?e_rready:owner==VECTOR?v_rready:owner==ARGMAX?a_rready:1'd0;
 assign m_axi_awaddr=owner==EMBED?e_awaddr:owner==VECTOR?v_awaddr:32'd0;
 assign m_axi_awlen=owner==EMBED?e_awlen:owner==VECTOR?v_awlen:8'd0;
 assign m_axi_awsize=owner==EMBED?e_awsize:owner==VECTOR?v_awsize:3'd0;
 assign m_axi_awburst=owner==EMBED?e_awburst:owner==VECTOR?v_awburst:2'd0;
 assign m_axi_awvalid=owner==EMBED?e_awvalid:owner==VECTOR?v_awvalid:1'd0;
 assign m_axi_wdata=owner==EMBED?e_wdata:owner==VECTOR?v_wdata:128'd0;
 assign m_axi_wstrb=owner==EMBED?e_wstrb:owner==VECTOR?v_wstrb:16'd0;
 assign m_axi_wlast=owner==EMBED?e_wlast:owner==VECTOR?v_wlast:1'd0;
 assign m_axi_wvalid=owner==EMBED?e_wvalid:owner==VECTOR?v_wvalid:1'd0;
 assign m_axi_bready=owner==EMBED?e_bready:owner==VECTOR?v_bready:1'd0;
endmodule
