`timescale 1ns/1ps
// One shared DSP applies eight FP16 scales, then adds each group into INT64.
// For W4: output units are activation_integer * real_weight * 2^24.
// IEEE binary16 scales have an EXACT integer representation in units 2^-24.
// normal scale = (1024+fraction) * 2^(exponent-25).
// subnormal scale = fraction * 2^-24.
// For I16 attention: bypass_scale=1 accumulates raw signed 48-bit group dots.
// Input must mark first/last groups of an output-row tile. An invalid scale,
// out-of-range W4 dot, or arithmetic overflow sets sticky error for that tile.
module qwen_scale_acc8_pipeline_v1 (
    input wire clk,
    input wire rst,
    input wire in_valid,
    output wire in_ready,
    input wire [383:0] group_acc,
    input wire [127:0] scale_bits,
    input wire first_group,
    input wire last_group,
    input wire bypass_scale,
    output reg out_valid,
    input wire out_ready,
    output wire [511:0] output_acc,
    output reg error
);
    // Eight accepted lanes traverse operand -> DSP product -> shift -> sum.
    // No next group is accepted until all eight sums commit; row/group order is exact.
    reg active,issuing,is_last,raw_mode;reg [2:0] lane;
    (* EXTRACT_ENABLE="NO" *) reg [383:0] dots;
    (* EXTRACT_ENABLE="NO" *) reg [127:0] scales;
    reg signed [63:0] sums[0:7];
    wire signed [47:0] selected_dot=dots[lane*48+:48];
    wire [15:0] selected_scale=scales[lane*16+:16];
    wire [4:0] exponent=selected_scale[14:10];
    wire signed [24:0] dot25=selected_dot[24:0];
    wire signed [17:0] mant18={7'd0,exponent!=0,selected_scale[9:0]};
    reg p0_valid,p1_valid,p2_valid;
    reg [2:0] p0_lane,p1_lane,p2_lane;
    reg p0_raw,p1_raw,p2_raw,p0_bad;
    reg signed [24:0] p0_dot;reg signed [17:0] p0_mant;
    reg signed [47:0] p0_raw_dot,p1_raw_dot;
    reg [4:0] p0_shift,p1_shift,p2_shift;
    (* use_dsp="yes" *) reg signed [47:0] p1_product;
    reg signed [63:0] p2_product64,p2_term,p2_sum_base;
    wire signed [63:0] p1_product64={{16{p1_product[47]}},p1_product};
    wire signed [63:0] p1_raw64={{16{p1_raw_dot[47]}},p1_raw_dot};
    wire signed [63:0] shifted=p1_raw?p1_raw64:p1_product64<<<p1_shift;
    wire signed [63:0] sum=p2_sum_base+p2_term;
    // Sum payload is unchanged. A parallel carry-select sign shortens its guard.
    wire [32:0] guard_low={1'b0,p2_sum_base[31:0]}+{1'b0,p2_term[31:0]};
    wire [32:0] guard_high0={1'b0,p2_sum_base[63:32]}+{1'b0,p2_term[63:32]};
    wire [32:0] guard_high1={1'b0,p2_sum_base[63:32]}+{1'b0,p2_term[63:32]}+33'd1;
    reg guard_sum_sign;
    always @* begin
      case(^{p2_sum_base,p2_term})
       1'b0,1'b1:guard_sum_sign=guard_low[32]?guard_high1[31]:guard_high0[31];
       default:guard_sum_sign=sum[63];
      endcase
    end
    wire add_overflow=sums[p2_lane][63]==p2_term[63]&&guard_sum_sign!=p2_term[63];
    reg p2_shift_bad;
    function automatic shifted_overflow(input raw,input signed [47:0] product,input [4:0] amount,input signed [63:0] shifted_value,product64);
      reg [14:0] disagreement,mask;
      begin
       case(^{raw,product,amount})
        1'b0,1'b1:begin
         disagreement=product[46:32]^{15{product[47]}};
         mask=15'h7fff << (31-amount);
         shifted_overflow=!raw&&(amount>16)&&(|(disagreement&mask));
        end
        default:shifted_overflow=!raw&&((shifted_value>>>amount)!=product64);
       endcase
      end
    endfunction
    wire shift_overflow=p2_shift_bad;
    // Predict exactly the original ready from the same committed next states.
    // This breaks downstream state/ready fanout without changing enabled cycles.
    reg ready_without_reset;
    function predicted_ready;
      input old_active,old_out,out_take,in_valid_value,in_ready_value,last_valid;
      input [2:0] last_lane;
      input last_group_value;
      reg next_active,next_out;
      begin
        next_active=old_active;next_out=old_out;
        if(old_out&&out_take)next_out=0;
        if(in_valid_value&&in_ready_value)next_active=1;
        if(last_valid&&last_lane==7)begin
          next_active=0;if(last_group_value)next_out=1;
        end
        predicted_ready=!next_active&&!next_out;
      end
    endfunction
    always @(posedge clk)begin
      if(rst)ready_without_reset<=1;
      else ready_without_reset<=predicted_ready(active,out_valid,out_ready,in_valid,in_ready,p2_valid,p2_lane,is_last);
    end
    assign in_ready=!rst&&ready_without_reset;
    genvar i;generate for(i=0;i<8;i=i+1)begin:outputs
        assign output_acc[i*64+:64]=sums[i];
    end endgenerate
    integer n;
    always @(posedge clk)begin
        if(rst)begin
            active<=0;issuing<=0;is_last<=0;raw_mode<=0;lane<=0;
            dots<=0;scales<=0;out_valid<=0;error<=0;
            p0_valid<=0;p1_valid<=0;p2_valid<=0;
            p0_lane<=0;p1_lane<=0;p2_lane<=0;p0_raw<=0;p1_raw<=0;p2_raw<=0;p0_bad<=0;
            p0_dot<=0;p0_mant<=0;p0_raw_dot<=0;p1_raw_dot<=0;
            p0_shift<=0;p1_shift<=0;p2_shift<=0;p1_product<=0;p2_product64<=0;p2_term<=0;p2_sum_base<=0;p2_shift_bad<=0;
            for(n=0;n<8;n=n+1)sums[n]<=0;
        end else begin
            if(out_valid&&out_ready)out_valid<=0;
            p0_valid<=active&&issuing;p1_valid<=p0_valid;p2_valid<=p1_valid;
            if(in_valid&&in_ready)begin
                dots<=group_acc;scales<=scale_bits;is_last<=last_group;raw_mode<=bypass_scale;
                lane<=0;active<=1;issuing<=1;
                if(first_group)begin error<=0;for(n=0;n<8;n=n+1)sums[n]<=0;end
            end
            if(active&&issuing)begin
                p0_dot<=dot25;p0_mant<=mant18;p0_raw_dot<=selected_dot;p0_raw<=raw_mode;p0_lane<=lane;
                p0_shift<=exponent==0?0:exponent-1'b1;
                p0_bad<=!raw_mode&&(selected_scale[15]||exponent==31||selected_dot!={{23{dot25[24]}},dot25});
                if(lane==7)issuing<=0;else lane<=lane+1'b1;
            end
            if(p0_valid)begin
                p1_product<=p0_dot*p0_mant;p1_raw_dot<=p0_raw_dot;p1_raw<=p0_raw;
                p1_lane<=p0_lane;p1_shift<=p0_shift;
                if(p0_bad)error<=1;
            end
            if(p1_valid)begin
                // Distinct in-flight lanes and group retirement protect this
                // preceding-cycle sum read, including first-group clearing.
                p2_sum_base<=sums[p1_lane];p2_shift_bad<=shifted_overflow(p1_raw,p1_product,p1_shift,shifted,p1_product64);
                p2_term<=shifted;p2_product64<=p1_product64;p2_raw<=p1_raw;
                p2_lane<=p1_lane;p2_shift<=p1_shift;
            end
            if(p2_valid)begin
                sums[p2_lane]<=sum;
                if(add_overflow||shift_overflow)error<=1;
                if(p2_lane==7)begin active<=0;if(is_last)out_valid<=1;end
            end
        end
    end
endmodule
