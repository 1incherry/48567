`timescale 1ns/1ps
// Passive source-side AXI4 accounting, ID-less/in-order, no datapath mutation.
// Attach BEFORE qwen_axi128_boundary: retire only when the real core consumes
// RLAST/B, so two-slot request/response queues remain included in the lifetime.
// board_reset_n must be the common epoch reset, never CPU-only/soft-reset.
// epoch_valid/lower_queues_quiet/guard_fault must be same-clock qualified;
// preserve the existing sticky/asynchronous narrow-epoch-loss guard upstream.
module qwen_axi_quiet_witness_r2 #(
 parameter integer MAX_PENDING=8,
 parameter integer IW=$clog2(MAX_PENDING),CW=$clog2(MAX_PENDING+1)
)(
 input wire clk,board_reset_n,epoch_valid,guard_fault,
 input wire freeze_requested,token_boundary_parked,lower_queues_quiet,
 // OR of the five actual M-side channel VALID signals, same source clock.
 input wire boundary_downstream_valid,
 input wire arvalid,arready,input wire[7:0]arlen,
 input wire rvalid,rready,rlast,input wire[1:0]rresp,
 input wire awvalid,awready,input wire[7:0]awlen,
 input wire wvalid,wready,wlast,
 input wire bvalid,bready,input wire[1:0]bresp,
 output wire quiet_ack,output wire fault,
 output wire[CW-1:0]pending_reads,pending_write_addresses,pending_write_data,
 output wire[8:0]partial_write_beats,output reg[3:0]first_error
);
 // MAX_PENDING must be a power of two >=2. Overflow is fail-closed, not stall.
 reg[CW-1:0]rc,ac,dc;reg[IW-1:0]rh,rt,ah,at,dh,dt;
 reg[7:0]rlen_q[0:MAX_PENDING-1],alen_q[0:MAX_PENDING-1],dlen_q[0:MAX_PENDING-1];
 reg[7:0]rbeat;reg[8:0]wpartial;
 reg protocol_fault,engaged;reg[1:0]quiet_history;reg error_seen_this_cycle;
 wire af=arvalid&&arready,rf=rvalid&&rready,rpop=rf&&rlast;
 wire wf=wvalid&&wready,dpush=wf&&wlast,awf=awvalid&&awready,bf=bvalid&&bready;
 wire have_r=rc!=0||af,have_a=ac!=0||awf,have_d=dc!=0||dpush;
 wire[7:0]expected_r_len=rc!=0?rlen_q[rh]:arlen;
 wire[7:0]expected_w_len=ac!=0?alen_q[ah]:awlen;
 wire[7:0]completed_w_len=dc!=0?dlen_q[dh]:wpartial[7:0];
 assign pending_reads=rc;assign pending_write_addresses=ac;assign pending_write_data=dc;assign partial_write_beats=wpartial;
 assign fault=protocol_fault||guard_fault;
 wire empty=rc==0&&ac==0&&dc==0&&wpartial==0;
 wire no_offer=!(arvalid||awvalid||wvalid||rvalid||bvalid);
 wire raw_quiet=board_reset_n&&epoch_valid&&!fault&&freeze_requested&&token_boundary_parked&&lower_queues_quiet&&empty&&no_offer&&!boundary_downstream_valid;
 // Any new offer, epoch/fault/permit loss revokes ACK without waiting a clock.
 assign quiet_ack=raw_quiet&&(&quiet_history);
 task automatic bad(input[3:0]code);begin if(!protocol_fault&&!error_seen_this_cycle)begin error_seen_this_cycle=1;protocol_fault<=1;first_error<=code;end end endtask
 initial begin if(MAX_PENDING<2||(MAX_PENDING&(MAX_PENDING-1))!=0)$error("MAX_PENDING_POWER_OF_TWO_AT_LEAST_TWO_REQUIRED");end
 always @(posedge clk or negedge board_reset_n)begin
  if(!board_reset_n)begin
   rc<=0;ac<=0;dc<=0;rh<=0;rt<=0;ah<=0;at<=0;dh<=0;dt<=0;rbeat<=0;wpartial<=0;protocol_fault<=0;first_error<=0;engaged<=0;quiet_history<=0;error_seen_this_cycle=0;
  end else begin
   error_seen_this_cycle=0;
   quiet_history<={quiet_history[0],raw_quiet};
   if(af||rf||awf||wf||bf||freeze_requested)engaged<=1;
   if(engaged&&!epoch_valid)bad(4'd1);
   if(guard_fault)bad(4'd2);
   if(af)begin
    if(rc==MAX_PENDING&&!rpop)bad(4'd3);
    else begin rlen_q[rt]<=arlen;rt<=rt+1'b1;end
   end
   if(rvalid&&!have_r)bad(4'd4);
   if(rf)begin
    if(!have_r)bad(4'd4);
    else begin
     if(rresp!=0)bad(4'd5);
     if(rlast!==(rbeat==expected_r_len))bad(4'd6);
     if(rlast)begin rh<=rh+1'b1;rbeat<=0;end
     else if(rbeat==255)bad(4'd6);else rbeat<=rbeat+1'b1;
    end
   end
   case({af,rpop})
    2'b10:if(rc<MAX_PENDING)rc<=rc+1'b1;
    2'b01:if(rc!=0)rc<=rc-1'b1;else bad(4'd4);
    default:begin end
   endcase
   // W may precede AW. Even one accepted nonlast W beat prevents quiet.
   if(wf)begin
    if(wlast)begin
     if(wpartial>255)bad(4'd7);
     if(dc==MAX_PENDING&&!bf)bad(4'd8);
     else begin dlen_q[dt]<=wpartial[7:0];dt<=dt+1'b1;end
     wpartial<=0;
    end else if(wpartial>=255)begin wpartial<=256;bad(4'd7);end
    else wpartial<=wpartial+1'b1;
   end
   if(awf)begin
    if(ac==MAX_PENDING&&!bf)bad(4'd9);
    else begin alen_q[at]<=awlen;at<=at+1'b1;end
   end
   if(bvalid&&(!have_a||!have_d))bad(4'd10);
   if(bf)begin
    if(!have_a||!have_d)bad(4'd10);
    else begin
     if(expected_w_len!==completed_w_len)bad(4'd11);
     if(bresp!=0)bad(4'd12);
     ah<=ah+1'b1;dh<=dh+1'b1;
    end
   end
   case({awf,bf})
    2'b10:if(ac<MAX_PENDING)ac<=ac+1'b1;
    2'b01:if(ac!=0)ac<=ac-1'b1;else bad(4'd10);
    default:begin end
   endcase
   case({dpush,bf})
    2'b10:if(dc<MAX_PENDING)dc<=dc+1'b1;
    2'b01:if(dc!=0)dc<=dc-1'b1;else bad(4'd10);
    default:begin end
   endcase
  end
 end
endmodule
