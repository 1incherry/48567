// Candidate full arithmetic wiring. Dynamic whole-token qualification pending.
// No MicroBlaze, host executor, software scheduler or fixed-response input.
// Model and bound RoPE coefficient table must already occupy the candidate RAM.
module qwen_cpu_free_token_axi128_v26 #(parameter [31:0] DDR_BASE=32'h80000000,parameter ENABLE_CHECKPOINT=0)(
 input wire checkpoint_enable,checkpoint_resume,input wire [15:0] checkpoint_seq,
 output wire checkpoint_paused,
 output wire [31:0] checkpoint_scale,
 input wire clk,rst_n,start,input wire [15:0] start_token,input wire [9:0] start_position,
 input wire start_output_head,start_emit_logits,
 output wire busy,done,error,output wire [9:0] result_position,
 output wire [15:0] result_token,output wire result_token_valid,
 output wire [287:0] debug_nonlinear,
 output wire [31:0] debug_control,debug_sequence,
 output wire [287:0] debug_gemv_profile,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 wire ext_cmd_valid,ext_cmd_ready,ext_rsp_valid,ext_rsp_ready,ext_busy;
 wire [15:0] cmd_seq,cmd_token,cmd_rows,cmd_cols,cmd_stride_groups,cmd_padding,cmd_vector_offset,ext_rsp_seq,ext_rsp_token;
 wire [9:0] cmd_position;wire [5:0] cmd_stage;wire [4:0] cmd_layer;
 wire [3:0] cmd_head,cmd_op,cmd_src,cmd_dst;
 wire [31:0] cmd_matrix_offset,cmd_param_offset,cmd_source_address,cmd_destination_address,ext_quant_scale_fp32;
 wire [31:0] cmd_aux_source_address,cmd_aux_destination_address;
 wire [7:0] ext_rsp_error;
 wire [31:0] original_debug_control;
 wire diagnostic_matrix_rsp_valid,diagnostic_matrix_rsp_ready;
 wire [15:0] diagnostic_matrix_rsp_seq;
 wire [7:0] diagnostic_matrix_rsp_error;
 // The internal matrix path does not use auxiliary ext_rsp. Observe its accepted response too.
 qwen_response_fault_latch_v1596 response_diagnostic(
  .clk,.rst_n,.start,.response_valid(diagnostic_matrix_rsp_valid||ext_rsp_valid),
  .response_ready(diagnostic_matrix_rsp_valid?diagnostic_matrix_rsp_ready:ext_rsp_ready),
  .response_error(diagnostic_matrix_rsp_valid?diagnostic_matrix_rsp_error:ext_rsp_error),
  .response_seq(diagnostic_matrix_rsp_valid?diagnostic_matrix_rsp_seq:ext_rsp_seq),.expected_seq(debug_sequence[15:0]),
  .response_token(diagnostic_matrix_rsp_valid?16'b0:ext_rsp_token),.stage(cmd_stage),.original_debug(original_debug_control[22:0]),
  .diagnostic_debug(debug_control));

 wire [31:0] aux_araddr;
 wire [7:0] aux_arlen;
 wire [2:0] aux_arsize;
 wire [1:0] aux_arburst;
 wire aux_arvalid;
 wire aux_arready;
 wire [127:0] aux_rdata;
 wire [1:0] aux_rresp;
 wire aux_rlast;
 wire aux_rvalid;
 wire aux_rready;
 wire [31:0] aux_awaddr;
 wire [7:0] aux_awlen;
 wire [2:0] aux_awsize;
 wire [1:0] aux_awburst;
 wire aux_awvalid;
 wire aux_awready;
 wire [127:0] aux_wdata;
 wire [15:0] aux_wstrb;
 wire aux_wlast;
 wire aux_wvalid;
 wire aux_wready;
 wire [1:0] aux_bresp;
 wire aux_bvalid;
 wire aux_bready;
 qwen_token_matrix_kv_dispatch_v11 #(.DDR_BASE(DDR_BASE),.ENABLE_CHECKPOINT(ENABLE_CHECKPOINT)) scheduler(
  .checkpoint_enable,.checkpoint_resume,.checkpoint_seq,.checkpoint_paused,.checkpoint_scale,
  .clk,.rst_n,.start,.start_token,.start_position,.start_output_head,.start_emit_logits,
  .busy,.done,.error,.result_position,.result_token,.result_token_valid,.debug_control(original_debug_control),.debug_sequence,
  .diagnostic_matrix_rsp_valid,.diagnostic_matrix_rsp_ready,.diagnostic_matrix_rsp_seq,.diagnostic_matrix_rsp_error,.debug_gemv_profile,
  .ext_cmd_valid,.ext_cmd_ready,.ext_quant_scale_fp32,
  .ext_rsp_valid,.ext_rsp_ready,.ext_rsp_seq,.ext_rsp_token,.ext_rsp_error(ext_rsp_error!=0),
  .cmd_seq,
  .cmd_token,
  .cmd_position,
  .cmd_stage,
  .cmd_layer,
  .cmd_head,
  .cmd_op,
  .cmd_src,
  .cmd_dst,
  .cmd_rows,
  .cmd_cols,
  .cmd_stride_groups,
  .cmd_padding,
  .cmd_vector_offset,
  .cmd_matrix_offset,
  .cmd_param_offset,
  .cmd_source_address,
  .cmd_destination_address,.cmd_aux_source_address,.cmd_aux_destination_address,
  .m_axi_araddr,
  .m_axi_arlen,
  .m_axi_arsize,
  .m_axi_arburst,
  .m_axi_arvalid,
  .m_axi_arready,
  .m_axi_rdata,
  .m_axi_rresp,
  .m_axi_rlast,
  .m_axi_rvalid,
  .m_axi_rready,
  .m_axi_awaddr,
  .m_axi_awlen,
  .m_axi_awsize,
  .m_axi_awburst,
  .m_axi_awvalid,
  .m_axi_awready,
  .m_axi_wdata,
  .m_axi_wstrb,
  .m_axi_wlast,
  .m_axi_wvalid,
  .m_axi_wready,
  .m_axi_bresp,
  .m_axi_bvalid,
  .m_axi_bready,
  .aux_araddr,
  .aux_arlen,
  .aux_arsize,
  .aux_arburst,
  .aux_arvalid,
  .aux_arready,
  .aux_rdata,
  .aux_rresp,
  .aux_rlast,
  .aux_rvalid,
  .aux_rready,
  .aux_awaddr,
  .aux_awlen,
  .aux_awsize,
  .aux_awburst,
  .aux_awvalid,
  .aux_awready,
  .aux_wdata,
  .aux_wstrb,
  .aux_wlast,
  .aux_wvalid,
  .aux_wready,
  .aux_bresp,
  .aux_bvalid,
  .aux_bready);
 qwen_auxiliary_axi128_executor_v14 #(.DDR_BASE(DDR_BASE)) auxiliary(
  .debug_nonlinear,
  .clk,.rst_n,.cmd_valid(ext_cmd_valid),.cmd_ready(ext_cmd_ready),.cmd_op,.cmd_rows,.cmd_padding,.cmd_seq,.cmd_token,.cmd_position,
  .cmd_source_base(cmd_aux_source_address),.cmd_output_base(cmd_aux_destination_address),.cmd_param_offset,.cmd_matrix_offset,
  .rsp_valid(ext_rsp_valid),.rsp_ready(ext_rsp_ready),.rsp_seq(ext_rsp_seq),.rsp_token(ext_rsp_token),.rsp_error(ext_rsp_error),.rsp_quant_scale(ext_quant_scale_fp32),.busy(ext_busy),
  .m_axi_araddr(aux_araddr),
  .m_axi_arlen(aux_arlen),
  .m_axi_arsize(aux_arsize),
  .m_axi_arburst(aux_arburst),
  .m_axi_arvalid(aux_arvalid),
  .m_axi_arready(aux_arready),
  .m_axi_rdata(aux_rdata),
  .m_axi_rresp(aux_rresp),
  .m_axi_rlast(aux_rlast),
  .m_axi_rvalid(aux_rvalid),
  .m_axi_rready(aux_rready),
  .m_axi_awaddr(aux_awaddr),
  .m_axi_awlen(aux_awlen),
  .m_axi_awsize(aux_awsize),
  .m_axi_awburst(aux_awburst),
  .m_axi_awvalid(aux_awvalid),
  .m_axi_awready(aux_awready),
  .m_axi_wdata(aux_wdata),
  .m_axi_wstrb(aux_wstrb),
  .m_axi_wlast(aux_wlast),
  .m_axi_wvalid(aux_wvalid),
  .m_axi_wready(aux_wready),
  .m_axi_bresp(aux_bresp),
  .m_axi_bvalid(aux_bvalid),
  .m_axi_bready(aux_bready));
endmodule
