`timescale 1ns/1ps
//125MHz accepts and stores the AXIL034/2/F command BEFORE source_start.
// No side effect or B is allowed before source_done.100MHz root owner remains
// busy because that B has not yet been issued. Only board reset is permitted.
module mcs_release_geometry_qualifier_r2(input wire source_clk,host_clk,board_reset_n,source_reset_n,
 input wire source_start,output wire source_ready,output reg source_done,source_good,source_fault,
 input wire wr_busy,wr_first_seen,wr_protocol_fault,wr_lock,
 input wire[31:0]wr_addr,wr_first_data,input wire[7:0]wr_len,
 input wire[2:0]wr_size,input wire[1:0]wr_burst,input wire[3:0]wr_first_strb,input wire wr_first_last,
 output wire request_debug,good_ack_debug,bad_ack_debug);
 localparam IDLE=0,WAIT_ACK=1,WAIT_ZERO=2;
 reg[1:0]ss;reg request_reg,good_reg,bad_reg,decision,zero_seen;
 (* ASYNC_REG="TRUE" *)reg[2:0]request_sync,good_sync,bad_sync;
 always@(posedge host_clk or negedge board_reset_n)
 if(!board_reset_n)request_sync<=0;else request_sync<={request_sync[1:0],request_reg};
 always@(posedge source_clk or negedge source_reset_n)
 if(!source_reset_n)begin good_sync<=0;bad_sync<=0;end
 else begin good_sync<={good_sync[1:0],good_reg};bad_sync<={bad_sync[1:0],bad_reg};end
 wire exact_release=wr_busy&&wr_first_seen&&!wr_protocol_fault&&!wr_lock&&wr_addr==32'h41000034&&wr_len==0&&wr_size==2&&(wr_burst==0||wr_burst==1)&&wr_first_data==2&&wr_first_strb==15&&wr_first_last;
 assign source_ready=ss==IDLE&&!source_fault&&!good_sync[2]&&!bad_sync[2];
 assign request_debug=request_reg;assign good_ack_debug=good_reg;assign bad_ack_debug=bad_reg;
 always@(posedge host_clk or negedge board_reset_n)begin
 if(!board_reset_n)begin good_reg<=0;bad_reg<=0;end
 else if(!request_sync[2])begin good_reg<=0;bad_reg<=0;end
 else if(!good_reg&&!bad_reg)begin
  if(!wr_busy||wr_protocol_fault)bad_reg<=1;
  else if(wr_first_seen)begin good_reg<=exact_release;bad_reg<=!exact_release;end
 end
 end
 always@(posedge source_clk or negedge source_reset_n)begin
 if(!source_reset_n)begin ss<=IDLE;request_reg<=0;source_done<=0;source_good<=0;source_fault<=0;decision<=0;zero_seen<=0;end
 else begin
  source_done<=0;
  if(source_start&&!source_ready)source_fault<=1;
  case(ss)
   IDLE:begin
    request_reg<=0;source_good<=0;zero_seen<=0;
    if(good_sync[2]||bad_sync[2])source_fault<=1;
    if(source_start&&source_ready)begin request_reg<=1;ss<=WAIT_ACK;end
   end
   WAIT_ACK:begin
    if(good_sync[2]||bad_sync[2])begin
     decision<=good_sync[2]&&!bad_sync[2]&&!source_fault;
     if(good_sync[2]&&bad_sync[2])source_fault<=1;
     request_reg<=0;zero_seen<=0;ss<=WAIT_ZERO;
    end
   end
   WAIT_ZERO:begin
    if(!good_sync[2]&&!bad_sync[2])begin
     if(zero_seen)begin source_done<=1;source_good<=decision&&!source_fault&&!source_start;ss<=IDLE;end
     else zero_seen<=1;
    end else zero_seen<=0;
   end
   default:begin source_fault<=1;request_reg<=0;ss<=WAIT_ZERO;decision<=0;end
  endcase
 end end
endmodule
