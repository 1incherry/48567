`timescale 1ns/1ps
// 32 lanes, 128-bit AXI, independent read/compute FSMs, eight group buffers.
// W4: 512 column-major weight bytes + 64 FP16 scale bytes per group.
// I16: 2048 column-major weight bytes per group. Eight rotating prefetch buffers.
module qwen_axi_engine_prefetch8_v1518 #(parameter MAX_COLS=4864, parameter TILE_STEP=1) (
    input wire clk,input wire rst,input wire cmd_valid,output wire cmd_ready,
    input wire cmd_mode_i16,
    input wire [31:0] cmd_weight_base,cmd_activation_base,cmd_output_base,
    input wire [15:0] cmd_rows,cmd_cols,cmd_stride_groups,
    output wire busy,output reg done,output reg [7:0] error_code,
    output reg [31:0] cycle_count,mac_cycles,weight_wait_cycles,read_stall_cycles,
    output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
    output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
    output wire m_axi_arvalid,input wire m_axi_arready,
    input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
    input wire m_axi_rlast,input wire m_axi_rvalid,output wire m_axi_rready,
    output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
    output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
    output wire m_axi_awvalid,input wire m_axi_awready,
    output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
    output wire m_axi_wlast,output wire m_axi_wvalid,input wire m_axi_wready,
    input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
    // The registered target is eleven bits: explicitly form 36*x in fabric.
 function automatic [10:0] partial_w4_words(input [15:0] remaining_groups);
  begin
   case(^remaining_groups)
    1'b0,1'b1:partial_w4_words={remaining_groups[5:0],5'b0}+{remaining_groups[8:0],2'b0};
    default:partial_w4_words=16'd36*remaining_groups;
   endcase
  end
 endfunction
 localparam IDLE=0,X_WAIT=1,G_WAIT=2,FETCH=3,EXEC=4,MAC_WAIT=5,
               RESULT=6,Y_AW=7,Y_W=8,Y_B=9,ERROR_WAIT=10;
    localparam R_IDLE=0,R_AR=1,R_DATA=2,R_PREP=3;
    reg [3:0] state;reg [1:0] rstate;
    reg mode,abort_cmd,x_loaded,r_x,read_all_done;
    reg [3:0] load_bank,compute_bank;
    reg [15:0] buffer_valid;
    reg [15:0] rows,cols,groups,row_start,group_index,load_row,load_group;
    reg [31:0] matrix_base,tile_stride,load_address,x_base,r_base;
    (* MAX_FANOUT=16 *) reg [31:0] y_base;
    reg [31:0] y_after_burst,y_after_tile;reg last_output_tile;
    reg [7:0] aw_descriptor_beats; // Unknown until an actual output descriptor is prepared.
    reg [15:0] x_word;
    reg [10:0] r_word;reg [10:0] burst_beats,received;
    // Unknown descriptor payload is owned by R_AR, never reset to fabricate data.
    reg [31:0] ar_descriptor_address;reg [8:0] ar_descriptor_beats;
    reg [4:0] prefetch_groups;reg [3:0] load_subbank;reg [7:0] load_word;
    reg [10:0] read_target_words;
    reg r_bad,r_fault;reg [7:0] r_fault_code;
    reg [4:0] column,write_index,write_stop,aw_beats;
    reg [5:0] output_rows;reg [4:0] output_beats;
    reg [15:0] xr[0:7];reg [2:0] x_lane;
    (* ram_style="block" *) reg [127:0] w0[0:511];
    (* ram_style="block" *) reg [127:0] w1[0:255],w2[0:255],w3[0:255];
    (* ram_style="block" *) reg [127:0] scale0[0:15],scale1[0:15],scale2[0:15],scale3[0:15];
    reg [127:0] scale_q0,scale_q1,scale_q2,scale_q3;
    wire [511:0] scales_q={scale_q3,scale_q2,scale_q1,scale_q0};
    wire kernel_ready,kernel_valid,kernel_error,group_consumed;
    wire [2047:0] kernel_output;
    wire [31:0] group_bytes=mode?32'd2048:32'd576;
    wire [7:0] group_words=mode?8'd128:8'd36;
    // Constant descriptor map avoids a variable multiplier in the address path.
    // All 64 known mode/count combinations retain full 32-bit wrapping;
    // ambiguous input combinations retain the original four-state multiplication.
    function [31:0] prefetch_byte_count(input is_i16,input [4:0] count);
        begin case({is_i16,count})
            6'd0: prefetch_byte_count=32'd0;
            6'd1: prefetch_byte_count=32'd576;
            6'd2: prefetch_byte_count=32'd1152;
            6'd3: prefetch_byte_count=32'd1728;
            6'd4: prefetch_byte_count=32'd2304;
            6'd5: prefetch_byte_count=32'd2880;
            6'd6: prefetch_byte_count=32'd3456;
            6'd7: prefetch_byte_count=32'd4032;
            6'd8: prefetch_byte_count=32'd4608;
            6'd9: prefetch_byte_count=32'd5184;
            6'd10: prefetch_byte_count=32'd5760;
            6'd11: prefetch_byte_count=32'd6336;
            6'd12: prefetch_byte_count=32'd6912;
            6'd13: prefetch_byte_count=32'd7488;
            6'd14: prefetch_byte_count=32'd8064;
            6'd15: prefetch_byte_count=32'd8640;
            6'd16: prefetch_byte_count=32'd9216;
            6'd17: prefetch_byte_count=32'd9792;
            6'd18: prefetch_byte_count=32'd10368;
            6'd19: prefetch_byte_count=32'd10944;
            6'd20: prefetch_byte_count=32'd11520;
            6'd21: prefetch_byte_count=32'd12096;
            6'd22: prefetch_byte_count=32'd12672;
            6'd23: prefetch_byte_count=32'd13248;
            6'd24: prefetch_byte_count=32'd13824;
            6'd25: prefetch_byte_count=32'd14400;
            6'd26: prefetch_byte_count=32'd14976;
            6'd27: prefetch_byte_count=32'd15552;
            6'd28: prefetch_byte_count=32'd16128;
            6'd29: prefetch_byte_count=32'd16704;
            6'd30: prefetch_byte_count=32'd17280;
            6'd31: prefetch_byte_count=32'd17856;
            6'd32: prefetch_byte_count=32'd0;
            6'd33: prefetch_byte_count=32'd2048;
            6'd34: prefetch_byte_count=32'd4096;
            6'd35: prefetch_byte_count=32'd6144;
            6'd36: prefetch_byte_count=32'd8192;
            6'd37: prefetch_byte_count=32'd10240;
            6'd38: prefetch_byte_count=32'd12288;
            6'd39: prefetch_byte_count=32'd14336;
            6'd40: prefetch_byte_count=32'd16384;
            6'd41: prefetch_byte_count=32'd18432;
            6'd42: prefetch_byte_count=32'd20480;
            6'd43: prefetch_byte_count=32'd22528;
            6'd44: prefetch_byte_count=32'd24576;
            6'd45: prefetch_byte_count=32'd26624;
            6'd46: prefetch_byte_count=32'd28672;
            6'd47: prefetch_byte_count=32'd30720;
            6'd48: prefetch_byte_count=32'd32768;
            6'd49: prefetch_byte_count=32'd34816;
            6'd50: prefetch_byte_count=32'd36864;
            6'd51: prefetch_byte_count=32'd38912;
            6'd52: prefetch_byte_count=32'd40960;
            6'd53: prefetch_byte_count=32'd43008;
            6'd54: prefetch_byte_count=32'd45056;
            6'd55: prefetch_byte_count=32'd47104;
            6'd56: prefetch_byte_count=32'd49152;
            6'd57: prefetch_byte_count=32'd51200;
            6'd58: prefetch_byte_count=32'd53248;
            6'd59: prefetch_byte_count=32'd55296;
            6'd60: prefetch_byte_count=32'd57344;
            6'd61: prefetch_byte_count=32'd59392;
            6'd62: prefetch_byte_count=32'd61440;
            6'd63: prefetch_byte_count=32'd63488;
            default:prefetch_byte_count=(is_i16?32'd2048:32'd576)*count;
        endcase end
    endfunction
    wire [15:0] remaining=r_x ? (cols>>3)-x_word : read_target_words-r_word;
    function [8:0] choose_burst;
        input [31:0] address;input [15:0] remain;
        reg [8:0] page_beats;reg [15:0] n;
        begin
            page_beats=(13'd4096-{1'b0,address[11:0]})>>4;
            // AXI4 allows up to 256 beats (ARLEN=255). The read
            // descriptor counts use nine bits, so 256 encodes as ARLEN=255.
            n=remain>256?256:remain;
            if(n>page_beats)n=page_beats;
            choose_burst=n[8:0];
        end
    endfunction
    wire [31:0] read_address=r_x ? x_base+({16'd0,x_word}<<4) : r_base+({21'd0,r_word}<<4);
    // Mode-qualified ring: W4 sixteen slots, I16 original eight.
    // Ternary merge preserves ambiguous mode bits instead of forcing zeros.
    function [3:0] bank_step(input [3:0] bank,input [3:0] step);
        begin bank_step=(bank+step)&(mode?4'd7:4'd15);end
    endfunction
    wire [3:0] load_bank1=bank_step(load_bank,4'd1);
    wire [3:0] load_bank2=bank_step(load_bank,4'd2);
    wire [3:0] load_bank3=bank_step(load_bank,4'd3);
    wire [3:0] load_bank4=bank_step(load_bank,4'd4);
    wire [3:0] load_bank5=bank_step(load_bank,4'd5);
    wire [3:0] load_bank6=bank_step(load_bank,4'd6);
    wire [3:0] load_bank7=bank_step(load_bank,4'd7);
    wire [8:0] next_burst=choose_burst(read_address,remaining);
    wire span_cmd_ready,span_busy,span_done,span_valid,span_last,span_fault_event;
    // Never overwrite a published ring slot. Activation reads use their own RAM.
    wire span_consumer_ready=(rstate==R_DATA)&&(r_x || !buffer_valid[load_subbank]);
    wire span_transfer=span_valid&&span_consumer_ready;
    wire abort_request=r_fault || (state==RESULT && kernel_valid && kernel_error) ||
        (state==Y_B && m_axi_bvalid && m_axi_bresp!=0);
    assign busy=state!=IDLE;
    assign cmd_ready=state==IDLE && rstate==R_IDLE && !span_busy && !rst;
    wire [127:0] span_data;wire [1:0] span_resp,span_outstanding;
    wire [7:0] span_error,span_fault_code;
    qwen_axi_read_span2_v1 #(.WINDOW(2)) ordered_reads(
      .clk(clk),.rst(rst),.cmd_valid(rstate==R_PREP && !abort_cmd && !abort_request),
      .abort(abort_cmd || abort_request),.cmd_ready(span_cmd_ready),.busy(span_busy),.done(span_done),.error_code(span_error),
      .cmd_address(read_address),.cmd_words(remaining[10:0]),
      .m_axi_araddr(m_axi_araddr),.m_axi_arlen(m_axi_arlen),.m_axi_arsize(m_axi_arsize),.m_axi_arburst(m_axi_arburst),
      .m_axi_arvalid(m_axi_arvalid),.m_axi_arready(m_axi_arready),.m_axi_rdata(m_axi_rdata),.m_axi_rresp(m_axi_rresp),
      .m_axi_rlast(m_axi_rlast),.m_axi_rvalid(m_axi_rvalid),.m_axi_rready(m_axi_rready),
      .out_valid(span_valid),.out_ready(span_consumer_ready),.out_data(span_data),.out_resp(span_resp),.out_last(span_last),
      .fault_event(span_fault_event),.fault_event_code(span_fault_code),.outstanding(span_outstanding));
    assign m_axi_awaddr=y_base;
    wire [7:0] next_write=choose_burst(y_base,{11'd0,output_beats-write_index});
    wire [4:0] result_output_beats=rows-row_start>=32?16:(rows-row_start+1'b1)>>1;
    assign m_axi_awlen=aw_descriptor_beats-1'b1;assign m_axi_awsize=4;assign m_axi_awburst=1;
    assign m_axi_awvalid=state==Y_AW;
    assign m_axi_wdata=kernel_output[{write_index[3:0],7'd0}+:128];
    assign m_axi_wstrb=({write_index,1'b0}+1'b1<output_rows)?16'hffff:16'h00ff;
    assign m_axi_wlast=write_index+1'b1==write_stop;
    assign m_axi_wvalid=state==Y_W;assign m_axi_bready=state==Y_B;
    wire kernel_out_ready=(state==Y_B && m_axi_bvalid &&
        (m_axi_bresp!=0 || write_index==output_beats)) ||
        (state==RESULT && kernel_valid && kernel_error);
    wire [15:0] absolute_col=(group_index<<5)+{11'd0,column};
    function [15:0] next_absolute_column(input [15:0] v);
        begin case(^v)
            1'b0,1'b1:begin
                next_absolute_column[0]=~v[0];
                next_absolute_column[1]=v[1] ^ (&v[0:0]);
                next_absolute_column[2]=v[2] ^ (&v[1:0]);
                next_absolute_column[3]=v[3] ^ (&v[2:0]);
                next_absolute_column[4]=v[4] ^ (&v[3:0]);
                next_absolute_column[5]=v[5] ^ (&v[4:0]);
                next_absolute_column[6]=v[6] ^ (&v[5:0]);
                next_absolute_column[7]=v[7] ^ (&v[6:0]);
                next_absolute_column[8]=v[8] ^ (&v[7:0]);
                next_absolute_column[9]=v[9] ^ (&v[8:0]);
                next_absolute_column[10]=v[10] ^ (&v[9:0]);
                next_absolute_column[11]=v[11] ^ (&v[10:0]);
                next_absolute_column[12]=v[12] ^ (&v[11:0]);
                next_absolute_column[13]=v[13] ^ (&v[12:0]);
                next_absolute_column[14]=v[14] ^ (&v[13:0]);
                next_absolute_column[15]=v[15] ^ (&v[14:0]);
            end
            default:next_absolute_column=16'bx;
        endcase end
    endfunction
    reg [15:0] read_col;
    always @* begin
        case(state==EXEC && kernel_ready && column!=31)
            1'b0:read_col=absolute_col;
            1'b1:read_col=next_absolute_column(absolute_col);
            default:read_col=16'bx;
        endcase
    end

    wire [15:0] x_read_word=read_col>>3;
    wire [8:0] windex={compute_bank,column};
    // Synchronous dual-port weight RAM. Existing FETCH primes column zero.
    // The read address follows the same accepted-beat lookahead as activation RAM.
    // No reset/zeroing of payload; unwritten data retains X in simulation.
    reg [127:0] weight_q0,weight_q1,weight_q2,weight_q3;
    // Select a precomputed increment, keeping ready/state off the carry input.
    // absolute_col preserves the original four-state group/column arithmetic.
    wire [4:0] weight_column_increment={
        absolute_col[4] ^ (&absolute_col[3:0]),
        absolute_col[3] ^ (&absolute_col[2:0]),
        absolute_col[2] ^ (&absolute_col[1:0]),
        absolute_col[1] ^ absolute_col[0], ~absolute_col[0]};
    wire weight_advance=(state==EXEC && kernel_ready && column!=31);
    reg [4:0] weight_column_mux;
    always @* begin
        case(weight_advance)
            1'b0: weight_column_mux=absolute_col[4:0];
            1'b1: weight_column_mux=weight_column_increment;
            default: weight_column_mux=5'bxxxxx; // Original + unknown -> unknown.
        endcase
    end
    wire [8:0] weight_read_index={compute_bank,weight_column_mux};
    wire [7:0] weight_i16_read_index={compute_bank[2:0],weight_column_mux};
    always @(posedge clk)begin
        weight_q0<=w0[weight_read_index];weight_q1<=w1[weight_i16_read_index];
        weight_q2<=w2[weight_i16_read_index];weight_q3<=w3[weight_i16_read_index];
        scale_q0<=scale0[compute_bank];scale_q1<=scale1[compute_bank];
        scale_q2<=scale2[compute_bank];scale_q3<=scale3[compute_bank];
    end
    wire [511:0] weights=mode?{weight_q3,weight_q2,weight_q1,weight_q0}:{384'd0,weight_q0};
    genvar b;
    generate for(b=0;b<8;b=b+1)begin: activations
        (* ram_style="block" *) reg [15:0] xmem[0:MAX_COLS/8-1];
        always @(posedge clk)begin
            xr[b]<=xmem[x_read_word];
            if(rstate==R_DATA && span_transfer && !span_fault_event && r_x)xmem[x_word]<=span_data[b*16+:16];
        end
    end endgenerate
    always @(posedge clk)begin
        x_lane<=read_col[2:0];
        if(rstate==R_DATA && span_transfer && !span_fault_event && !r_x)begin
            // One physical write port/address for W4 and I16 plane zero.
            // Separate syntactic writes infer extra RAM ports even when mutually exclusive.
            if((mode && load_word[1:0]==0) || (!mode && load_word<32))
                w0[mode?{1'b0,load_subbank[2:0],load_word[6:2]}:{load_subbank,load_word[4:0]}]<=span_data;
            if(mode)begin
                case(load_word[1:0])
                    1:w1[{load_subbank[2:0],load_word[6:2]}]<=span_data;
                    2:w2[{load_subbank[2:0],load_word[6:2]}]<=span_data;
                    3:w3[{load_subbank[2:0],load_word[6:2]}]<=span_data;
                endcase
            end else if(load_word>=32)begin
                case(load_word[1:0])
                    0:scale0[load_subbank]<=span_data;
                    1:scale1[load_subbank]<=span_data;
                    2:scale2[load_subbank]<=span_data;
                    3:scale3[load_subbank]<=span_data;
                endcase
            end
        end
    end
    qwen_gemv32_datapath kernel(.clk(clk),.rst(rst || (cmd_valid && cmd_ready)),
        .mode_i16(mode),.in_valid(state==EXEC),.in_ready(kernel_ready),.activation(xr[x_lane]),
        .weight_data(weights),.in_last(column==31),.group_scales(scales_q),
        .first_group(group_index==0),.last_group(group_index+1'b1==groups),
        .out_valid(kernel_valid),.out_ready(kernel_out_ready),.output_acc(kernel_output),
        .error(kernel_error),.group_consumed(group_consumed));
    always @(posedge clk)begin
        if(rst)begin
            state<=IDLE;rstate<=R_IDLE;done<=0;error_code<=0;cycle_count<=0;
            mac_cycles<=0;weight_wait_cycles<=0;read_stall_cycles<=0;
            mode<=0;abort_cmd<=0;x_loaded<=0;r_x<=0;load_bank<=0;compute_bank<=0;
            read_all_done<=0;buffer_valid<=0;rows<=0;cols<=0;groups<=0;
            row_start<=0;group_index<=0;load_row<=0;load_group<=0;
            matrix_base<=0;tile_stride<=0;load_address<=0;x_base<=0;y_base<=0;r_base<=0;y_after_burst<=0;y_after_tile<=0;last_output_tile<=0;
            x_word<=0;r_word<=0;burst_beats<=0;received<=0;r_bad<=0;r_fault<=0;r_fault_code<=0;
            prefetch_groups<=1;load_subbank<=0;load_word<=0;read_target_words<=0;
            column<=0;write_index<=0;write_stop<=0;aw_beats<=0;output_rows<=0;output_beats<=0;
        end else begin
            done<=0;r_fault<=0;
            if(busy)begin
                cycle_count<=cycle_count+1'b1;
                if(state==EXEC && kernel_ready)mac_cycles<=mac_cycles+1'b1;
                if(state==G_WAIT && !buffer_valid[compute_bank])weight_wait_cycles<=weight_wait_cycles+1'b1;
                if(rstate==R_DATA && !span_transfer)read_stall_cycles<=read_stall_cycles+1'b1;
            end
            case(rstate)
                R_IDLE:if(busy && !span_busy && !abort_cmd && !abort_request)begin
                    if(!x_loaded)begin r_x<=1;r_word<=0;read_target_words<=cols>>3;r_bad<=0;rstate<=R_PREP;end
                    else if(!read_all_done && !buffer_valid[load_bank])begin
                        r_x<=0;r_base<=load_address;r_word<=0;load_subbank<=load_bank;load_word<=0;r_bad<=0;
                        if(!mode)begin
                            // A whole bounded span streams through16 slots. Slots
                            // may be recycled only after the MAC releases them.
                            if(groups-load_group>=16'd28)begin
                                prefetch_groups<=28;read_target_words<=11'd1008;
                            end else begin
                                prefetch_groups<=groups-load_group;
                                read_target_words<=partial_w4_words(groups-load_group);
                            end
                        end else if(groups-load_group>=16'd8 && !buffer_valid[load_bank1] &&
                           !buffer_valid[load_bank2] && !buffer_valid[load_bank3] && !buffer_valid[load_bank4] &&
                           !buffer_valid[load_bank5] && !buffer_valid[load_bank6] && !buffer_valid[load_bank7])begin
                            prefetch_groups<=8;read_target_words<=group_words*8;
                        end else if(groups-load_group>=16'd7 && !buffer_valid[load_bank1] &&
                           !buffer_valid[load_bank2] && !buffer_valid[load_bank3] && !buffer_valid[load_bank4] &&
                           !buffer_valid[load_bank5] && !buffer_valid[load_bank6])begin
                            prefetch_groups<=7;read_target_words<=group_words*7;
                        end else if(groups-load_group>=16'd6 && !buffer_valid[load_bank1] &&
                           !buffer_valid[load_bank2] && !buffer_valid[load_bank3] && !buffer_valid[load_bank4] &&
                           !buffer_valid[load_bank5])begin
                            prefetch_groups<=6;read_target_words<=group_words*6;
                        end else if(groups-load_group>=16'd5 && !buffer_valid[load_bank1] &&
                           !buffer_valid[load_bank2] && !buffer_valid[load_bank3] && !buffer_valid[load_bank4])begin
                            prefetch_groups<=5;read_target_words<=group_words*5;
                        end else if(groups-load_group>=16'd4 && !buffer_valid[load_bank1] &&
                           !buffer_valid[load_bank2] && !buffer_valid[load_bank3])begin
                            prefetch_groups<=4;read_target_words<=group_words*4;
                        end else if(groups-load_group>=16'd3 && !buffer_valid[load_bank1] &&
                                     !buffer_valid[load_bank2])begin
                            prefetch_groups<=3;read_target_words<=group_words*3;
                        end else if(groups-load_group>=16'd2 && !buffer_valid[load_bank1])begin
                            prefetch_groups<=2;read_target_words<=group_words*2;
                        end else begin
                            prefetch_groups<=1;read_target_words<=group_words;
                        end
                        rstate<=R_PREP;
                    end
                end
                R_PREP:begin
                    if(abort_cmd || abort_request)rstate<=R_IDLE;
                    else if(span_cmd_ready)begin burst_beats<=remaining[10:0];received<=0;rstate<=R_DATA;end
                end
                R_DATA:if(span_transfer)begin
                    if(span_resp!=0)begin r_bad<=1;r_fault_code<=2;end
                    if(span_last!=(received==burst_beats-1'b1))begin r_bad<=1;r_fault_code<=3;end
                    received<=received+1'b1;
                    if(r_x)x_word<=x_word+1'b1;
                    else begin
                        r_word<=r_word+1'b1;
                        if(load_word+1'b1==group_words)begin
                            // A complete bank is usable while later banks are still
                            // arriving. Never expose a partial/faulted group. The
                            // original transaction error/drain gates still abort.
                            if(!r_bad && !span_fault_event && span_resp==0 &&
                               span_last==(received==burst_beats-1'b1))
                                buffer_valid[load_subbank]<=1;
                            load_word<=0;load_subbank<=bank_step(load_subbank,4'd1);
                        end
                        else load_word<=load_word+1'b1;
                    end
                    if(span_last)begin
                        if(r_bad || span_resp!=0 || received!=burst_beats-1'b1)begin
                            r_fault<=1;rstate<=R_IDLE;
                            if(received!=burst_beats-1'b1)r_fault_code<=3;
                            else if(span_resp!=0)r_fault_code<=2;
                        end else if(abort_cmd || abort_request)rstate<=R_IDLE;
                        else if(r_x)begin
                            if(x_word+1'b1==(cols>>3))begin x_loaded<=1;rstate<=R_IDLE;end
                            else rstate<=R_PREP;
                        end else if(r_word+1'b1 < read_target_words)begin
                            // Continue a combined prefetch across a page-split
                            // AXI burst; commit buffers only at target end.
                            rstate<=R_PREP;
                        end else begin
                            // Each completed group was committed once above.
                            load_bank<=bank_step(load_bank,prefetch_groups[3:0]);rstate<=R_IDLE;
                            if(load_group+prefetch_groups>=groups)begin
                                load_group<=0;load_row<=load_row+32;
                                matrix_base<=matrix_base+tile_stride;load_address<=matrix_base+tile_stride;
                                if(load_row+32>=rows)read_all_done<=1;
                            end else begin load_group<=load_group+prefetch_groups;
                                load_address<=load_address+prefetch_byte_count(mode,prefetch_groups);end
                        end
                    end
                end
                default:rstate<=R_IDLE;
            endcase
            // Raw per-burst RLAST/RRESP checks live in ordered_reads.  A raw
            // fault is raised before a group can publish; accepted ARs drain
            // even after the compute FSM enters ERROR_WAIT.
            // The transport owns cancellation draining; no normalized out_valid
            // is produced after abort. Retire the consumer FSM independently,
            // while ERROR_WAIT still waits for every accepted/held AR to drain.
            if((abort_cmd || abort_request) && rstate==R_DATA)rstate<=R_IDLE;
            if(span_fault_event)begin r_fault<=1;r_fault_code<=span_fault_code;rstate<=R_IDLE;end
            if(span_done && span_error!=0 && !abort_cmd && !abort_request)begin
                r_fault<=1;r_fault_code<=span_error;rstate<=R_IDLE;
            end
            case(state)
                IDLE:if(cmd_valid && cmd_ready)begin
                    error_code<=0;cycle_count<=0;mac_cycles<=0;weight_wait_cycles<=0;read_stall_cycles<=0;
                    if(cmd_rows==0 || cmd_cols==0 || cmd_cols>MAX_COLS || cmd_cols[4:0]!=0 ||
                       cmd_stride_groups<(cmd_cols>>5) || cmd_weight_base[3:0]!=0 ||
                       cmd_activation_base[3:0]!=0 || cmd_output_base[3:0]!=0)begin error_code<=1;done<=1;end
                    else begin
                        mode<=cmd_mode_i16;rows<=cmd_rows;cols<=cmd_cols;groups<=cmd_cols>>5;
                        matrix_base<=cmd_weight_base;load_address<=cmd_weight_base;
                        tile_stride<=TILE_STEP*(cmd_mode_i16?({16'd0,cmd_stride_groups}<<11):
                            ({16'd0,cmd_stride_groups}<<9)+({16'd0,cmd_stride_groups}<<6));
                        x_base<=cmd_activation_base;y_base<=cmd_output_base;
                        x_word<=0;group_index<=0;row_start<=0;column<=0;load_row<=0;load_group<=0;
                        load_bank<=0;compute_bank<=0;buffer_valid<=0;read_all_done<=0;
                        x_loaded<=0;abort_cmd<=0;r_bad<=0;state<=X_WAIT;
                    end
                end
                X_WAIT:if(x_loaded)state<=G_WAIT;
                G_WAIT:if(buffer_valid[compute_bank])begin column<=0;state<=FETCH;end
                FETCH:state<=EXEC;
                EXEC:if(kernel_ready)begin
                    if(column==31)begin buffer_valid[compute_bank]<=0;state<=MAC_WAIT;end
                    else column<=column+1'b1;
                end
                MAC_WAIT:if(group_consumed)begin
                    compute_bank<=bank_step(compute_bank,4'd1);
                    if(group_index+1'b1==groups)state<=RESULT;
                    else begin group_index<=group_index+1'b1;state<=G_WAIT;end
                end
                RESULT:if(kernel_valid)begin
                    if(kernel_error)begin error_code<=5;abort_cmd<=1;state<=ERROR_WAIT;end
                    else begin
                        output_rows<=rows-row_start>=32?32:rows-row_start;
                        output_beats<=result_output_beats;last_output_tile<=(row_start+32>=rows);
                        write_index<=0;aw_descriptor_beats<=choose_burst(y_base,{11'd0,result_output_beats});state<=Y_AW;
                    end
                end
                Y_AW:if(m_axi_awready)begin aw_beats<=aw_descriptor_beats[4:0];y_after_burst<=y_base+({27'd0,aw_descriptor_beats[4:0]}<<4);write_stop<=write_index+aw_descriptor_beats[4:0];state<=Y_W;end
                Y_W:begin y_after_tile<=y_after_burst+(TILE_STEP-1)*256;
                    if(m_axi_wready)begin write_index<=write_index+1'b1;if(write_index+1'b1==write_stop)state<=Y_B;end
                end
                Y_B:if(m_axi_bvalid)begin
                    if(m_axi_bresp!=0 || abort_cmd || r_fault)begin
                        if(m_axi_bresp!=0)error_code<=4;
                        abort_cmd<=1;state<=ERROR_WAIT;
                    end
                    else if(write_index<output_beats)begin y_base<=y_after_burst;aw_descriptor_beats<=choose_burst(y_after_burst,{11'd0,output_beats-write_index});state<=Y_AW;end
                    else if(last_output_tile)begin done<=1;state<=IDLE;end
                    else begin
                        row_start<=row_start+32;group_index<=0;
                        y_base<=y_after_tile;state<=G_WAIT;
                    end
                end
                ERROR_WAIT:if(rstate==R_IDLE && !span_busy)begin done<=1;state<=IDLE;end
                default:begin error_code<=8'hff;abort_cmd<=1;state<=ERROR_WAIT;end
            endcase
            if(r_fault)begin
                error_code<=r_fault_code;abort_cmd<=1;
                // Drain an already presented/accepted write before reporting failure.
                if(state!=Y_AW && state!=Y_W && state!=Y_B)state<=ERROR_WAIT;
            end
        end
    end
endmodule

`timescale 1ns/1ps
// Ordered, ID-less read-span transport.  WINDOW=1/2, 1..1024 128-bit words.
// Descriptor payload and response data are never reset or replaced with zero.
module qwen_axi_read_span2_v1 #(parameter WINDOW=2)(
 input wire clk,rst,cmd_valid,abort,
 output wire cmd_ready,output reg busy,done,output reg [7:0] error_code,
 input wire [31:0] cmd_address,input wire [10:0] cmd_words,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire out_valid,input wire out_ready,output wire [127:0] out_data,
 output wire [1:0] out_resp,output wire out_last,
 output wire fault_event,output wire [7:0] fault_event_code,
 output wire [1:0] outstanding
);
 reg ar_pending,fault;
 reg [31:0] issue_address,ar_address;
 reg [10:0] issue_left,total_words,delivered;
 reg [8:0] ar_beats,q_head,q_tail,received;
 reg [1:0] q_count;
 function [8:0] burst_words;
  input [31:0] address;input [10:0] remaining;
  reg [8:0] page;reg [10:0] n;
  begin
   page=(13'd4096-{1'b0,address[11:0]})>>4;
   n=remaining>256?256:remaining;
   if(n>page)n=page;
   burst_words=n[8:0];
  end
 endfunction
 assign cmd_ready=!busy;
 assign m_axi_araddr=ar_address;
 assign m_axi_arlen=ar_beats-1'b1;
 assign m_axi_arsize=3'd4;
 assign m_axi_arburst=2'b01;
 assign m_axi_arvalid=ar_pending;
 assign out_data=m_axi_rdata;
 assign out_resp=m_axi_rresp;
 assign out_valid=busy&&(q_count!=0)&&m_axi_rvalid&&!fault&&!abort;
 assign out_last=(delivered+1'b1==total_words);
 assign m_axi_rready=busy&&(q_count!=0)&&(fault||abort||out_ready);
 assign outstanding=q_count;
 wire push=ar_pending&&m_axi_arready;
 wire take=m_axi_rvalid&&m_axi_rready;
 wire expected_last=(received+1'b1==q_head);
 wire pop=take&&m_axi_rlast;
 assign fault_event=take&&((m_axi_rlast!=expected_last)||(m_axi_rresp!=0));
 assign fault_event_code=(m_axi_rlast!=expected_last)?8'd3:8'd2;
 always @(posedge clk)begin
  if(rst)begin
   busy<=0;done<=0;error_code<=0;ar_pending<=0;fault<=0;
   q_count<=0;received<=0;issue_left<=0;delivered<=0;
  end else begin
   done<=0;
   if(!busy)begin
    if(cmd_valid)begin
     error_code<=0;fault<=0;q_count<=0;received<=0;delivered<=0;ar_pending<=0;
     if(cmd_words==0||cmd_words>1024||cmd_address[3:0]!=0)begin
      error_code<=1;done<=1;
     end else begin
      busy<=1;issue_address<=cmd_address;issue_left<=cmd_words;total_words<=cmd_words;
     end
    end
   end else begin
    if(abort)begin fault<=1;if(!fault)error_code<=6;end
    // A pending AR is held until accepted, including after an abort/error.
    // No new descriptor is prepared after failure; all accepted responses drain.
    if(!ar_pending&&!fault&&!abort&&q_count<WINDOW)begin
     if(issue_left==0)begin end
     else begin
      ar_address<=issue_address;ar_beats<=burst_words(issue_address,issue_left);ar_pending<=1;
     end
    end
    if(push)begin
     ar_pending<=0;issue_address<=issue_address+({23'd0,ar_beats}<<4);
     issue_left<=issue_left-{2'd0,ar_beats};
    end
    case({push,pop})
     2'b10:begin
      if(q_count==0)q_head<=ar_beats;else q_tail<=ar_beats;
      q_count<=q_count+1'b1;
     end
     2'b01:begin
      if(q_count==2)q_head<=q_tail;
      q_count<=q_count-1'b1;
     end
     2'b11:begin
      if(q_count==1)q_head<=ar_beats;
      else begin q_head<=q_tail;q_tail<=ar_beats;end
     end
     default:begin end
    endcase
    if(take)begin
     received<=pop?9'd0:received+1'b1;
     delivered<=delivered+1'b1;
     // Length faults retain priority over a preceding response/abort fault.
     if(m_axi_rlast!=expected_last)begin fault<=1;error_code<=3;end
     else if(m_axi_rresp!=0)begin fault<=1;if(error_code!=3)error_code<=2;end
    end
    if(q_count==0&&!ar_pending&&(fault||issue_left==0))begin
     busy<=0;done<=1;
    end
   end
  end
 end
endmodule
