// Shared exact-order original-C arithmetic lane. No fused multiply/add.
// 0: x+a; 1: x*a; 2: (x*a)+b; 3: ((x*a)*b)*c.
// All opcodes have 35 enabled-cycle latency, II1; common CE freezes IP/data/tags.
// Finite normal/zero model trace qualification; full IEEE domain pending.
module qwen_postprocess_fp32_stream #(parameter TAG_WIDTH=20)(
 input wire clk,rst_n,in_valid,
 output wire in_ready,
 input wire [2:0] in_mode,
 input wire [31:0] x_fp32,a_fp32,b_fp32,c_fp32,
 input wire in_last,
 input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,
 input wire out_ready,
 output wire [31:0] result_fp32,
 output wire out_error,out_last,
 output wire [TAG_WIDTH-1:0] out_tag
);
 wire ce=out_ready||!out_valid;
 assign in_ready=ce&&rst_n;
 wire accepted=in_valid&&rst_n;
 wire v1,v2,v3,va;
 wire [31:0] m1,m2,m3,added,b8,c16,x24,a24,b24,m1_24,m1_35,m3_35;
 wire [2:0] mode24,mode35;
 qwen_fp_mul mul1(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(accepted),.s_axis_a_tdata(x_fp32),.s_axis_b_tvalid(accepted),.s_axis_b_tdata(a_fp32),.m_axis_result_tvalid(v1),.m_axis_result_tdata(m1));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(8)) delay_b8(.clk,.rst_n,.ce,.din(b_fp32),.dout(b8));
 qwen_fp_mul mul2(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(v1),.s_axis_a_tdata(m1),.s_axis_b_tvalid(v1),.s_axis_b_tdata(b8),.m_axis_result_tvalid(v2),.m_axis_result_tdata(m2));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(16)) delay_c16(.clk,.rst_n,.ce,.din(c_fp32),.dout(c16));
 qwen_fp_mul mul3(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(v2),.s_axis_a_tdata(m2),.s_axis_b_tvalid(v2),.s_axis_b_tdata(c16),.m_axis_result_tvalid(v3),.m_axis_result_tdata(m3));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(24)) delay_x24(.clk,.rst_n,.ce,.din(x_fp32),.dout(x24));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(24)) delay_a24(.clk,.rst_n,.ce,.din(a_fp32),.dout(a24));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(24)) delay_b24(.clk,.rst_n,.ce,.din(b_fp32),.dout(b24));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(16)) delay_m1_24(.clk,.rst_n,.ce,.din(m1),.dout(m1_24));
 qwen_ce_delay #(.WIDTH(3),.DEPTH(24)) delay_mode24(.clk,.rst_n,.ce,.din(in_mode),.dout(mode24));
 qwen_fp_add add1(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(v3),.s_axis_a_tdata(mode24==0?x24:m1_24),.s_axis_b_tvalid(v3),.s_axis_b_tdata(mode24==0?a24:b24),.m_axis_result_tvalid(va),.m_axis_result_tdata(added));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(27)) delay_m1_35(.clk,.rst_n,.ce,.din(m1),.dout(m1_35));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(11)) delay_m3_35(.clk,.rst_n,.ce,.din(m3),.dout(m3_35));
 qwen_ce_delay #(.WIDTH(TAG_WIDTH+5),.DEPTH(35)) sideband(.clk,.rst_n,.ce,
  .din({accepted,in_mode,in_last,in_tag}),.dout({out_valid,mode35,out_last,out_tag}));
 assign result_fp32=mode35==1?m1_35:mode35==3?m3_35:added;
 assign out_error=mode35>3;
endmodule
