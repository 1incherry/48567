// Actual finite-normal model scope: original max/32767, 1/scale,
// x*inverse then explicit nearest-even INT16. Reject unsupported underflow/
// nonfinite arithmetic rather than silently masking it as a valid result.
// Whole IEEE subnormal divide fallback remains a separate qualification.
module qwen_quant_fp32_frame_bram_v3 #(
 parameter MAX_ELEMENTS=4864,TAG_WIDTH=16,MUL_LAT=8
 )(
 input wire clk,rst_n,in_valid,
 output wire in_ready,
 input wire [31:0] x_fp32,
 input wire [12:0] in_length,in_padding,
 input wire in_last,
 input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,
 input wire out_ready,
 output wire signed [15:0] result_i16,
 output wire out_last,
 output wire [TAG_WIDTH-1:0] out_tag,
 output wire [31:0] scale_fp32,
 output reg protocol_error,
 output reg domain_error
);
 localparam CAPTURE=0,SCALE=1,INVERSE=2,EMIT=3,DRAIN=4,REJECT=5;
 reg [2:0] state;
 integer input_index,emit_index;
 // Original integer + unsized1 is signed32, including wrap and all-X
 // arithmetic. Precompute its known-bit prefix independently of ready/CE.
 function automatic signed [31:0] after_one(input signed [31:0] v);
  integer k;
  begin
   case(^v)
    1'b0,1'b1:begin
     after_one[0]=~v[0];
     after_one[1]=v[1] ^ (&v[0:0]);
     after_one[2]=v[2] ^ (&v[1:0]);
     after_one[3]=v[3] ^ (&v[2:0]);
     after_one[4]=v[4] ^ (&v[3:0]);
     after_one[5]=v[5] ^ (&v[4:0]);
     after_one[6]=v[6] ^ (&v[5:0]);
     after_one[7]=v[7] ^ (&v[6:0]);
     after_one[8]=v[8] ^ (&v[7:0]);
     after_one[9]=v[9] ^ (&v[8:0]);
     after_one[10]=v[10] ^ (&v[9:0]);
     after_one[11]=v[11] ^ (&v[10:0]);
     after_one[12]=v[12] ^ (&v[11:0]);
     after_one[13]=v[13] ^ (&v[12:0]);
     after_one[14]=v[14] ^ (&v[13:0]);
     after_one[15]=v[15] ^ (&v[14:0]);
     after_one[16]=v[16] ^ (&v[15:0]);
     after_one[17]=v[17] ^ (&v[16:0]);
     after_one[18]=v[18] ^ (&v[17:0]);
     after_one[19]=v[19] ^ (&v[18:0]);
     after_one[20]=v[20] ^ (&v[19:0]);
     after_one[21]=v[21] ^ (&v[20:0]);
     after_one[22]=v[22] ^ (&v[21:0]);
     after_one[23]=v[23] ^ (&v[22:0]);
     after_one[24]=v[24] ^ (&v[23:0]);
     after_one[25]=v[25] ^ (&v[24:0]);
     after_one[26]=v[26] ^ (&v[25:0]);
     after_one[27]=v[27] ^ (&v[26:0]);
     after_one[28]=v[28] ^ (&v[27:0]);
     after_one[29]=v[29] ^ (&v[28:0]);
     after_one[30]=v[30] ^ (&v[29:0]);
     after_one[31]=v[31] ^ (&v[30:0]);
    end
    default:after_one=32'bx;
   endcase
  end
 endfunction
 wire signed [31:0] input_index_next=after_one(input_index),emit_index_next=after_one(emit_index);

 reg [12:0] length,padding;
 reg [TAG_WIDTH-1:0] frame_tag;
 reg [31:0] maximum,scale,inverse,x_rd;
 reg pending,read_valid,read_last,read_padding;
 (* ram_style="block" *) reg [31:0] input_mem[0:MAX_ELEMENTS-1];
 wire ce=out_ready||!out_valid;
 reg captured_valid,captured_last;
 reg [31:0] captured_x;
 reg [12:0] captured_length,captured_padding;
 // Payload captured with length, before it participates in ready feedback.
 // Equality is unsigned-bit equality; length0 retains signed32 -1 wrap.
 reg [31:0] captured_terminal_index;
 reg capture_index_matches;
 always @* begin
  case(^input_index)
   1'b0,1'b1:begin
    case(^captured_length)
     1'b0,1'b1:capture_index_matches=(input_index==captured_terminal_index);
     default:capture_index_matches=(input_index_next==captured_length);
    endcase
   end
   default:capture_index_matches=1'bx;
  endcase
 end

 reg [TAG_WIDTH-1:0] captured_tag;
 wire captured_bad_domain=captured_x[30:23]==255||(captured_x[30:23]==0&&captured_x[22:0]!=0);
 wire capture_terminal=captured_valid&&(captured_last||captured_bad_domain||capture_index_matches);
 assign in_ready=rst_n&&ce&&state==CAPTURE&&!capture_terminal;
 wire capture_accept=in_valid&&in_ready;
 wire accept=captured_valid&&ce&&state==CAPTURE;
 always @(posedge clk)if(capture_accept)begin
  captured_terminal_index<={19'b0,in_length}-32'd1;
  captured_x<=x_fp32;captured_length<=in_length;captured_padding<=in_padding;captured_tag<=in_tag;captured_last<=in_last;
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)captured_valid<=0;
  else if(ce)captured_valid<=capture_accept;
 end
 wire [31:0] next_max=maximum<{1'b0,captured_x[30:0]}?{1'b0,captured_x[30:0]}:maximum;
 wire div_issue=(state==SCALE||state==INVERSE)&&!pending;
 wire div_valid;wire [31:0] divided;
 qwen_fp_div divider(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(div_issue),.s_axis_a_tdata(state==SCALE?maximum:32'h3f800000),
  .s_axis_b_tvalid(div_issue),.s_axis_b_tdata(state==SCALE?32'h46fffe00:scale),
  .m_axis_result_tvalid(div_valid),.m_axis_result_tdata(divided));
 wire mul_valid;wire [31:0] multiplied;
 qwen_fp_mul multiply(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(read_valid),.s_axis_a_tdata(x_rd),
  .s_axis_b_tvalid(read_valid),.s_axis_b_tdata(inverse),
  .m_axis_result_tvalid(mul_valid),.m_axis_result_tdata(multiplied));
 wire signed [15:0] rounded;wire round_error;
 qwen_fp32_round_i16_pipeline convert(.clk,.rst_n,.ce,.in_valid(mul_valid),
  .value_fp32(multiplied),.out_valid,.value_i16(rounded),.nonfinite_error(round_error));
 wire is_padding;
 qwen_ce_delay #(.WIDTH(2),.DEPTH(MUL_LAT+2)) metadata(
  .clk,.rst_n,.ce,.din({read_last,read_padding}),.dout({out_last,is_padding}));
 assign result_i16=is_padding?16'd0:rounded;
 assign out_tag=frame_tag;assign scale_fp32=scale;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=CAPTURE;input_index<=0;emit_index<=0;length<=0;padding<=0;
   frame_tag<=0;maximum<=0;scale<=0;inverse<=0;
   pending<=0;read_valid<=0;read_last<=0;read_padding<=0;
   protocol_error<=0;domain_error<=0;
  end else if(ce)begin
   read_valid<=0;read_last<=0;read_padding<=0;
   if(round_error)domain_error<=1;
   if(accept)begin
    maximum<=next_max;
    if(input_index==0)begin
     length<=captured_length;padding<=captured_padding;frame_tag<=captured_tag;
     if(captured_length==0||captured_length>MAX_ELEMENTS||captured_padding<captured_length||captured_padding>MAX_ELEMENTS)protocol_error<=1;
    end else if(captured_length!==length||captured_padding!==padding||captured_tag!==frame_tag)protocol_error<=1;
    if(captured_last!==capture_index_matches)protocol_error<=1;
    if(captured_x[30:23]==255||(captured_x[30:23]==0&&captured_x[22:0]!=0))begin
     domain_error<=1;state<=REJECT;
    end else if(capture_index_matches)begin
     input_index<=0;
     if(maximum==0 && captured_x[30:0]==0)begin scale<=32'h3f800000;inverse<=32'h3f800000;state<=EMIT;emit_index<=0;end
     else state<=SCALE;
    end else input_index<=input_index_next;
   end
   case(state)
    SCALE:begin
     if(div_issue)pending<=1;
     if(div_valid)begin
      pending<=0;
      if(divided[30:23]==0||divided[30:23]==255)begin domain_error<=1;state<=REJECT;end
      else begin scale<=divided;state<=INVERSE;end
     end
    end
    INVERSE:begin
     if(div_issue)pending<=1;
     if(div_valid)begin
      pending<=0;
      if(divided[30:23]==255)begin domain_error<=1;state<=REJECT;end
      else begin inverse<=divided;state<=EMIT;emit_index<=0;end
     end
    end
    EMIT:begin

     read_valid<=1;read_last<=emit_index_next==padding;read_padding<=emit_index>=length;
     if(emit_index_next==padding)state<=DRAIN;
     else emit_index<=emit_index_next;
    end
    DRAIN:if(out_valid&&out_ready&&out_last)begin
     state<=CAPTURE;input_index<=0;maximum<=0;pending<=0;
    end
    default:begin end
   endcase
  end
 end
 always @(posedge clk)begin
  if(rst_n&&accept)input_mem[input_index]<=captured_x;
  if(rst_n&&ce&&state==EMIT)x_rd<=emit_index<length?input_mem[emit_index]:32'd0;
 end
endmodule
