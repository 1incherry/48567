`default_nettype none
// Registered READ_FIRST true-dual-port BRAM template. No RAM reset or X masking.
module qwen_tdp32_bram_v1 #(parameter WORDS=608,AW=$clog2(WORDS))(
 input wire clk,ena,wea,input wire [AW-1:0] aa,input wire [31:0] da,output reg [31:0] qa,
 input wire enb,web,input wire [AW-1:0] ab,input wire [31:0] db,output reg [31:0] qb);
 (* ram_style="block" *) reg [31:0] ram[0:WORDS-1];
 always @(posedge clk)if(ena)begin if(wea)ram[aa]<=da;qa<=ram[aa];end
 always @(posedge clk)if(enb)begin if(web)ram[ab]<=db;qb<=ram[ab];end
endmodule
`default_nettype wire
