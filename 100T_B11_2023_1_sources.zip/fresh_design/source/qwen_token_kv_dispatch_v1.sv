// Actual controller/KV AXI store assembly. Other operation executors are external.
// Quantization executor must preserve KV_TEMP data/scale until kv_start handshake.
module qwen_token_kv_dispatch_v1 #(parameter [31:0] DDR_BASE=32'h80000000,parameter ENABLE_CHECKPOINT=0)(
 input wire checkpoint_enable,checkpoint_resume,input wire [15:0] checkpoint_seq,
 output wire checkpoint_paused,
 input wire clk,rst_n,start,
 input wire [15:0] start_token,input wire [9:0] start_position,
 input wire start_output_head,start_emit_logits,
 output wire busy,done,error,output wire [9:0] result_position,
 output wire [15:0] result_token,output wire result_token_valid,
 output wire [31:0] debug_control,debug_sequence,
 output wire ext_cmd_valid,input wire ext_cmd_ready,
 output wire [15:0] cmd_seq,cmd_token,output wire [9:0] cmd_position,
 output wire [5:0] cmd_stage,output wire [4:0] cmd_layer,
 output wire [3:0] cmd_head,cmd_op,cmd_src,cmd_dst,
 output wire [15:0] cmd_rows,cmd_cols,cmd_stride_groups,cmd_padding,cmd_vector_offset,
 output wire [31:0] cmd_matrix_offset,cmd_param_offset,
 input wire ext_rsp_valid,output wire ext_rsp_ready,
 input wire [15:0] ext_rsp_seq,ext_rsp_token,input wire ext_rsp_error,
 output wire kv_start,
 input wire [31:0] kv_scale_fp32,
 input wire kv_data_valid,output wire kv_data_ready,
 input wire [15:0] kv_data,input wire kv_data_last,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 wire cc_valid,cc_ready,cc_rsp_valid,cc_rsp_ready,cc_rsp_error;
 wire [15:0] cc_rsp_seq,cc_rsp_token;
 // Single exact case of the immutable controller stage, bypassing
 // stage -> command opcode/destination -> owner decode. Unknown stage
 // follows controller default opcode15, hence all internal owners false.
 function automatic [2:0] stage_owner_flags(input [5:0] s);
  case(s)
   3,5,7,23,28,30,34,39,4,6,8,24,29,31,35,16,20,17,21,40:stage_owner_flags=3'b100;
   12,14:stage_owner_flags=3'b010;
   11,13:stage_owner_flags=3'b001;
   default:stage_owner_flags=3'b000;
  endcase
 endfunction
 (* MAX_FANOUT=16 *) wire [2:0] stage_owners=stage_owner_flags(cmd_stage);
 wire is_kv=stage_owners[1];
 wire kv_cmd_ready,kv_rsp_valid,kv_rsp_ready,kv_busy;
 wire [7:0] kv_error;wire [15:0] kv_rsp_seq;
 assign ext_cmd_valid=cc_valid&&!is_kv;
 assign cc_ready=is_kv?kv_cmd_ready:ext_cmd_ready;
 assign cc_rsp_valid=is_kv?kv_rsp_valid:ext_rsp_valid;
 assign cc_rsp_error=is_kv?(kv_error!=0):ext_rsp_error;
 assign cc_rsp_seq=is_kv?kv_rsp_seq:ext_rsp_seq;
 assign cc_rsp_token=is_kv?16'b0:ext_rsp_token;
 assign kv_rsp_ready=cc_rsp_ready&&is_kv;
 assign ext_rsp_ready=cc_rsp_ready&&!is_kv;
 assign kv_start=cc_valid&&is_kv&&kv_cmd_ready;
 qwen_token_controller_v1 #(.ENABLE_CHECKPOINT(ENABLE_CHECKPOINT)) controller(.checkpoint_enable,.checkpoint_resume,.checkpoint_seq,.checkpoint_paused,.clk,.rst_n,.start,.start_token,.start_position,
  .start_output_head,.start_emit_logits,.busy,.done,.error,.result_position,.result_token,.result_token_valid,.debug_control,.debug_sequence,
  .cmd_valid(cc_valid),.cmd_ready(cc_ready),.cmd_seq,.cmd_token,.cmd_position,.cmd_stage,.cmd_layer,.cmd_head,.cmd_op,.cmd_src,.cmd_dst,
  .cmd_rows,.cmd_cols,.cmd_stride_groups,.cmd_padding,.cmd_vector_offset,.cmd_matrix_offset,.cmd_param_offset,
  .rsp_valid(cc_rsp_valid),.rsp_ready(cc_rsp_ready),.rsp_seq(cc_rsp_seq),.rsp_token(cc_rsp_token),.rsp_error(cc_rsp_error));
 qwen_kv_store_axi128_v2 #(.DDR_BASE(DDR_BASE)) kv_store(.clk,.rst_n,
  .cmd_valid(cc_valid&&is_kv),.cmd_ready(kv_cmd_ready),.cmd_value_layout(cmd_stage==14),
  .cmd_position,.cmd_matrix_base(DDR_BASE+cmd_matrix_offset),.cmd_scale_addr(DDR_BASE+cmd_param_offset),.cmd_scale_fp32(kv_scale_fp32),.cmd_seq,
  .s_valid(kv_data_valid),.s_ready(kv_data_ready),.s_data(kv_data),.s_last(kv_data_last),
  .rsp_valid(kv_rsp_valid),.rsp_ready(kv_rsp_ready),.rsp_error(kv_error),.rsp_seq(kv_rsp_seq),.busy(kv_busy),
  .m_axi_awaddr,.m_axi_awlen,.m_axi_awsize,.m_axi_awburst,.m_axi_awvalid,.m_axi_awready,
  .m_axi_wdata,.m_axi_wstrb,.m_axi_wlast,.m_axi_wvalid,.m_axi_wready,.m_axi_bresp,.m_axi_bvalid,.m_axi_bready);
endmodule
