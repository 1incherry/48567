// Signed INT64 -> binary32 nearest ties-even, including INT64_MIN.
// Five enabled stages: absolute, leading-bit metadata, align, guard/sticky, round.
// II1; clock_enable freezes values and tags atomically.
module qwen_i64_fp32_pipeline_ce #(parameter TAG_WIDTH=16)(
 input wire clk,rst_n,in_valid,clock_enable,
 output wire in_ready,
 input wire signed [63:0] value_i64,
 input wire in_last,input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,output wire [31:0] result_fp32,
 output wire out_last,output wire [TAG_WIDTH-1:0] out_tag
);
 reg v1,v2,v3,v4,v5,sign1,sign2,sign3,sign4,zero2,zero3,zero4;
 reg [63:0] magnitude,magnitude2;
 reg [6:0] leading2,exponent3,exponent4;
 reg [23:0] significand,significand4;
 reg [63:0] tail3;
 reg round_up;reg [31:0] result;
 reg [TAG_WIDTH:0] meta1,meta2,meta3,meta4,meta5;
 wire ce=clock_enable;
 assign in_ready=rst_n&&ce;assign out_valid=v5;
 assign result_fp32=result;assign {out_last,out_tag}=meta5;
 integer k,p,shift;reg [23:0] sig;reg [63:0] aligned_tail;
 reg [24:0] rounded;reg [7:0] result_exponent;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   v1<=0;v2<=0;v3<=0;v4<=0;v5<=0;sign1<=0;sign2<=0;sign3<=0;sign4<=0;zero2<=0;zero3<=0;zero4<=0;
   magnitude<=0;magnitude2<=0;leading2<=0;exponent3<=0;exponent4<=0;significand<=0;significand4<=0;tail3<=0;
   round_up<=0;result<=0;meta1<=0;meta2<=0;meta3<=0;meta4<=0;meta5<=0;
  end else if(ce)begin
   v1<=in_valid;sign1<=value_i64[63];magnitude<=value_i64[63]?(64'd0-value_i64):value_i64;meta1<={in_last,in_tag};
   v2<=v1;sign2<=sign1;zero2<=magnitude==0;magnitude2<=magnitude;meta2<=meta1;
   p=0;for(k=0;k<64;k=k+1)if(magnitude[k])p=k;leading2<=p;
   v3<=v2;sign3<=sign2;zero3<=zero2;exponent3<=leading2;meta3<=meta2;
   if(leading2<=23)begin significand<=magnitude2<<(23-leading2);tail3<=0;end
   else begin
    shift=leading2-23;sig=magnitude2>>shift;aligned_tail=magnitude2<<(64-shift);
    significand<=sig;tail3<=aligned_tail;
   end
   v4<=v3;meta4<=meta3;sign4<=sign3;zero4<=zero3;exponent4<=exponent3;significand4<=significand;
   round_up<=tail3[63]&&((|tail3[62:0])||significand[0]);
   v5<=v4;meta5<=meta4;rounded={1'b0,significand4}+round_up;result_exponent=exponent4+127;
   if(rounded[24])begin rounded=rounded>>1;result_exponent=result_exponent+1;end
   result<=zero4?32'd0:{sign4,result_exponent,rounded[22:0]};
  end
 end
endmodule
