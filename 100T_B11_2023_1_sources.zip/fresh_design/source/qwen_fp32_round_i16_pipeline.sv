// Binary32 -> symmetric signed INT16, nearest ties to even and saturation.
// Mirrors original round16() in the finite supported C domain.
// Two enabled-clock stages, II1; no floating point IP or C fallback.
module qwen_fp32_round_i16_pipeline(
 input wire clk,rst_n,ce,in_valid,
 input wire [31:0] value_fp32,
 output reg out_valid,
 output reg signed [15:0] value_i16,
 output reg nonfinite_error
);
 reg stage_valid,stage_sign,stage_round,stage_nonfinite;
 reg [15:0] stage_whole;
 reg [15:0] whole;
 reg round_up;
 reg [23:0] significand,rest;
 reg [23:0] halfway;
 integer shift;
 always @*begin
  whole=0;round_up=0;rest=0;halfway=0;
  significand={1'b1,value_fp32[22:0]};shift=0;
  // Constant shifts eliminate exponent subtract/variable mask/shift carry chains.
  // Keep the original relational/equality four-state operations for rounding.
  case(value_fp32[30:23])
   8'd126:begin whole=significand>>24;rest=significand&24'hffffff;halfway=24'h800000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd127:begin whole=significand>>23;rest=significand&24'h7fffff;halfway=24'h400000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd128:begin whole=significand>>22;rest=significand&24'h3fffff;halfway=24'h200000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd129:begin whole=significand>>21;rest=significand&24'h1fffff;halfway=24'h100000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd130:begin whole=significand>>20;rest=significand&24'h0fffff;halfway=24'h080000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd131:begin whole=significand>>19;rest=significand&24'h07ffff;halfway=24'h040000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd132:begin whole=significand>>18;rest=significand&24'h03ffff;halfway=24'h020000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd133:begin whole=significand>>17;rest=significand&24'h01ffff;halfway=24'h010000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd134:begin whole=significand>>16;rest=significand&24'h00ffff;halfway=24'h008000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd135:begin whole=significand>>15;rest=significand&24'h007fff;halfway=24'h004000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd136:begin whole=significand>>14;rest=significand&24'h003fff;halfway=24'h002000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd137:begin whole=significand>>13;rest=significand&24'h001fff;halfway=24'h001000;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd138:begin whole=significand>>12;rest=significand&24'h000fff;halfway=24'h000800;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd139:begin whole=significand>>11;rest=significand&24'h0007ff;halfway=24'h000400;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd140:begin whole=significand>>10;rest=significand&24'h0003ff;halfway=24'h000200;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   8'd141:begin whole=significand>>9;rest=significand&24'h0001ff;halfway=24'h000100;round_up=(rest>halfway)||((rest==halfway)&&whole[0]);end
   default:begin if(value_fp32[30:23]>=142)whole=32767;end
  endcase
 end
 wire [16:0] rounded={1'b0,stage_whole}+stage_round;
 wire [15:0] magnitude=rounded>32767?16'd32767:rounded[15:0];
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   stage_valid<=0;stage_sign<=0;stage_round<=0;stage_nonfinite<=0;stage_whole<=0;
   out_valid<=0;value_i16<=0;nonfinite_error<=0;
  end else if(ce)begin
   stage_valid<=in_valid;stage_sign<=value_fp32[31];stage_round<=round_up;
   stage_nonfinite<=value_fp32[30:23]==255;stage_whole<=whole;
   out_valid<=stage_valid;
   nonfinite_error<=stage_valid&&stage_nonfinite;
   value_i16<=stage_sign?-$signed(magnitude):$signed(magnitude);
  end
 end
endmodule
