`timescale 1ns/1ps
// Connect ONLY the actual trusted JTAG H port before the FullAXI splitter.
// This is an out-of-band conservative STOP,not AXI acceptance or completion.
// Complete stable VALID intent must be present for two100MHz sampling edges.
module mcs_trusted_stop_intent100(input wire clk,board_reset_n,main_fence_active,
 input wire h_awid,input wire[31:0]h_awaddr,input wire[7:0]h_awlen,
 input wire[2:0]h_awsize,input wire[1:0]h_awburst,input wire h_awlock,
 input wire[3:0]h_awcache,input wire[2:0]h_awprot,input wire[3:0]h_awqos,
 input wire h_awvalid,h_awready,input wire[31:0]h_wdata,input wire[3:0]h_wstrb,
 input wire h_wlast,h_wvalid,h_wready,output reg stop_latched);
 reg candidate;reg[12:0]free_fields;
 wire[12:0]current_free={h_awid,h_awburst[0],h_awcache,h_awprot,h_awqos};
 wire match=main_fence_active&&h_awvalid&&h_wvalid&&!h_awready&&!h_wready&&
 h_awaddr==32'h41000084&&h_awlen==0&&h_awsize==2&&(h_awburst==0||h_awburst==1)&&!h_awlock&&h_wdata==0&&h_wstrb==15&&h_wlast;
 always@(posedge clk or negedge board_reset_n)begin
 if(!board_reset_n)begin candidate<=0;free_fields<=0;stop_latched<=0;end
 else begin
  candidate<=match;
  if(match)begin
   free_fields<=current_free;
   if(candidate&&free_fields==current_free)stop_latched<=1;
  end
 end end
endmodule
