// Retimed original C embedding codec. Payload registers intentionally unreset.
// sample is asserted by the embedding FSM only after its selected input stage.
module qwen_embedding_w4_half_fp32_pipeline_v1(
 input wire clk,sample,input wire signed [3:0] weight_i4,
 input wire [15:0] scale_half,output reg [31:0] result_fp32
);
 wire [3:0] magnitude=weight_i4[3]?(~weight_i4+4'd1):weight_i4;
 wire [10:0] significand=scale_half[14:10]==0?{1'b0,scale_half[9:0]}:{1'b1,scale_half[9:0]};
 reg [14:0] product;reg sign_product;reg [7:0] exponent_base;
 reg [7:0] exponent;reg [23:0] normalized;integer highest,bit_index;
 always @(posedge clk)if(sample)begin
  product<=magnitude*significand;
  sign_product<=weight_i4[3];
  exponent_base<=scale_half[14:10]==0?103:102+scale_half[14:10];
 end
 always @* begin
  highest=0;
  for(bit_index=0;bit_index<15;bit_index=bit_index+1)
   if(product[bit_index])highest=bit_index;
  exponent=exponent_base+highest;
  normalized={9'b0,product}<<(23-highest);
  result_fp32=product==0?{sign_product,31'd0}:{sign_product,exponent,normalized[22:0]};
 end
endmodule
