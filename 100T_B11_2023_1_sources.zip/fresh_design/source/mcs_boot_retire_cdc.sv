`timescale 1ns/1ps
// Real100MHz host B-consumption ->125MHz source retire handshake.
// The100MHz AW/W inputs are actual independent boot-converter handshakes.
// No CPU/epoch reset is permitted here;one board reset covers both domains.
module mcs_boot_retire_cdc(input wire host_clk,source_clk,board_reset_n,
 input wire side_aw_accepted,side_w_accepted,host_b_consumed,
 input wire source_retire_ack,output wire source_retire_req,
 output wire new_boot_write_admit,output wire pending,
 output reg completed,protocol_fault,output wire[1:0]host_state);
 localparam IDLE=0,WAIT_B=1,RETIRE=2,ACK_LOW=3;
 reg[1:0]state;reg aw_seen,w_seen,request_reg;
 (* ASYNC_REG="TRUE" *)reg[2:0]ack_sync,request_sync;
 always@(posedge host_clk or negedge board_reset_n)
 if(!board_reset_n)ack_sync<=0;else ack_sync<={ack_sync[1:0],source_retire_ack};
 always@(posedge source_clk or negedge board_reset_n)
 if(!board_reset_n)request_sync<=0;else request_sync<={request_sync[1:0],request_reg};
 assign source_retire_req=request_sync[2];
 assign new_boot_write_admit=state==IDLE&&!protocol_fault&&!ack_sync[2];
 assign pending=state!=IDLE;assign host_state=state;
 always@(posedge host_clk or negedge board_reset_n)begin
 if(!board_reset_n)begin state<=IDLE;aw_seen<=0;w_seen<=0;request_reg<=0;completed<=0;protocol_fault<=0;end
 else begin
  completed<=0;
  case(state)
   IDLE:begin
    request_reg<=0;
    if(ack_sync[2])protocol_fault<=1;
    if(side_aw_accepted||side_w_accepted)begin
     aw_seen<=side_aw_accepted;w_seen<=side_w_accepted;state<=WAIT_B;
     if(host_b_consumed)begin
      if(side_aw_accepted&&side_w_accepted)begin state<=RETIRE;request_reg<=1;end
      else protocol_fault<=1;
     end
    end else if(host_b_consumed)protocol_fault<=1;
   end
   WAIT_B:begin
    if(side_aw_accepted)begin if(aw_seen)protocol_fault<=1;aw_seen<=1;end
    if(side_w_accepted)begin if(w_seen)protocol_fault<=1;w_seen<=1;end
    if(host_b_consumed)begin
     if((aw_seen||side_aw_accepted)&&(w_seen||side_w_accepted)&&!protocol_fault&&!(side_aw_accepted&&aw_seen)&&!(side_w_accepted&&w_seen))begin state<=RETIRE;request_reg<=1;end
     else protocol_fault<=1;
    end
   end
   RETIRE:begin
    if(side_aw_accepted||side_w_accepted||host_b_consumed)protocol_fault<=1;
    if(ack_sync[2])begin request_reg<=0;state<=ACK_LOW;end
   end
   ACK_LOW:begin
    if(side_aw_accepted||side_w_accepted||host_b_consumed)protocol_fault<=1;
    if(!ack_sync[2])begin state<=IDLE;aw_seen<=0;w_seen<=0;completed<=1;end
   end
  endcase
 end end
endmodule
