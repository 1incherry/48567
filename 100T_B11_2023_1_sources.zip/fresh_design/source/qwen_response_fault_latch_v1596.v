// Diagnostic only: does not drive arithmetic, reset, AXI or command control.
module qwen_response_fault_latch_v1596(
 input wire clk,rst_n,start,response_valid,response_ready,
 input wire [7:0] response_error,input wire [15:0] response_seq,expected_seq,response_token,
 input wire [5:0] stage,input wire [22:0] original_debug,
 output wire [31:0] diagnostic_debug
);
reg fault_valid;reg [7:0] fault_code;
reg pending_valid;reg [7:0] captured_error;
reg [15:0] captured_seq,captured_expected,captured_token;reg [5:0] captured_stage;
assign diagnostic_debug={fault_code,fault_valid,original_debug};
always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin pending_valid<=0;fault_valid<=0;fault_code<=0;end
 else if(start)begin pending_valid<=0;fault_valid<=0;fault_code<=0;end
 else begin
  // Observe the accepted packet once. Raw payload has no reset and retains X/Z.
  // No diagnostic output feeds arithmetic, reset, AXI, or command control.
  pending_valid<=!fault_valid&&response_valid&&response_ready;
  if(!fault_valid&&response_valid&&response_ready)begin
   captured_error<=response_error;captured_seq<=response_seq;
   captured_expected<=expected_seq;captured_token<=response_token;captured_stage<=stage;
  end
  if(!fault_valid&&pending_valid)begin
   if(captured_error!=0)begin fault_valid<=1;fault_code<=captured_error;end
   else if(captured_seq!=captured_expected)begin fault_valid<=1;fault_code<=8'd6;end
   else if(captured_stage==6'd41&&captured_token>=16'd65535)begin fault_valid<=1;fault_code<=8'd254;end
  end
 end
end
endmodule
