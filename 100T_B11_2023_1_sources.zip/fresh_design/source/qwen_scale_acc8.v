`timescale 1ns/1ps
// One shared DSP applies eight FP16 scales, then adds each group into INT64.
// For W4: output units are activation_integer * real_weight * 2^24.
// IEEE binary16 scales have an EXACT integer representation in units 2^-24.
// normal scale = (1024+fraction) * 2^(exponent-25).
// subnormal scale = fraction * 2^-24.
// For I16 attention: bypass_scale=1 accumulates raw signed 48-bit group dots.
// Input must mark first/last groups of an output-row tile. An invalid scale,
// out-of-range W4 dot, or arithmetic overflow sets sticky error for that tile.
module qwen_scale_acc8 (
    input wire clk,
    input wire rst,
    input wire in_valid,
    output wire in_ready,
    input wire [383:0] group_acc,
    input wire [127:0] scale_bits,
    input wire first_group,
    input wire last_group,
    input wire bypass_scale,
    output reg out_valid,
    input wire out_ready,
    output wire [511:0] output_acc,
    output reg error
);
    localparam IDLE=0, MUL=1, ADD=2;
    reg [1:0] state;
    reg [2:0] lane;
    reg [383:0] dots;
    reg [127:0] scales;
    reg is_last, raw_mode;
    reg signed [63:0] sums [0:7];
    (* use_dsp="yes" *) reg signed [47:0] product;
    reg [4:0] shift;
    reg signed [47:0] raw_dot;
    wire signed [47:0] selected_dot = dots[lane*48 +: 48];
    wire [15:0] selected_scale = scales[lane*16 +: 16];
    wire [4:0] exponent = selected_scale[14:10];
    wire [10:0] mantissa = {exponent!=0,selected_scale[9:0]};
    wire signed [24:0] dot25 = selected_dot[24:0];
    wire signed [17:0] mant18 = {7'd0,mantissa};
    wire signed [63:0] product64 = {{16{product[47]}},product};
    wire signed [63:0] raw64 = {{16{raw_dot[47]}},raw_dot};
    wire signed [63:0] term = raw_mode ? raw64 : product64 <<< shift;
    wire signed [63:0] sum = sums[lane] + term;
    wire add_overflow = sums[lane][63]==term[63] && sum[63]!=term[63];
    wire shift_overflow = !raw_mode && (term >>> shift)!=product64;
    assign in_ready = state==IDLE && !out_valid && !rst;
    genvar i;
    generate for(i=0;i<8;i=i+1) begin: outputs
        assign output_acc[i*64 +: 64] = sums[i];
    end endgenerate
    integer n;
    always @(posedge clk) begin
        if(rst) begin
            state<=IDLE; out_valid<=0; error<=0; lane<=0;
            dots<=0; scales<=0; is_last<=0; raw_mode<=0;
            product<=0; shift<=0; raw_dot<=0;
            for(n=0;n<8;n=n+1) sums[n]<=0;
        end else begin
            if(out_valid && out_ready) out_valid<=0;
            case(state)
                IDLE: if(in_valid && in_ready) begin
                    dots<=group_acc; scales<=scale_bits;
                    is_last<=last_group; raw_mode<=bypass_scale; lane<=0;
                    if(first_group) begin
                        error<=0;
                        for(n=0;n<8;n=n+1) sums[n]<=0;
                    end
                    state<=MUL;
                end
                MUL: begin
                    product<=dot25 * mant18;
                    shift<=exponent==0 ? 0 : exponent-1'b1;
                    raw_dot<=selected_dot;
                    if(!raw_mode && (selected_scale[15] || exponent==31 ||
                        selected_dot!={{23{dot25[24]}},dot25})) error<=1;
                    state<=ADD;
                end
                ADD: begin
                    sums[lane]<=sum;
                    if(add_overflow || shift_overflow) error<=1;
                    if(lane==7) begin
                        state<=IDLE;
                        if(is_last) out_valid<=1;
                    end else begin
                        lane<=lane+1'b1; state<=MUL;
                    end
                end
                default: state<=IDLE;
            endcase
        end
    end
endmodule
