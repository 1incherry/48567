`timescale 1ns/1ps
// Private125MHz source component,not a whole-board qualified design.
// Persistent transport state is reset only by the board-domain reset.
// side_retire_req comes from a real host-B-consumed four-phase CDC handshake.
module mcs_runtime_boot_side_adapter(
 input wire clk,board_reset_n,memory_epoch_n,
 input wire[31:0]reservation_status,input wire transport_fault,
 input wire ack_on_50,ack_off_50,owner_50,idle_50,fault_50,
 input wire normal_command,input wire[11:0]normal_address,input wire[31:0]normal_data,
 output reg normal_done,normal_error,
 input wire release_candidate,release_inflight,output wire release_admit,release_reject,
 input wire[11:0]s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire[31:0]s_wdata,input wire[3:0]s_wstrb,input wire s_wvalid,output wire s_wready,
 output reg[1:0]s_bresp,output reg s_bvalid,input wire s_bready,
 input wire[11:0]s_araddr,input wire s_arvalid,output wire s_arready,
 output reg[31:0]s_rdata,output reg[1:0]s_rresp,output reg s_rvalid,input wire s_rready,
 input wire side_retire_req,output reg side_retire_ack,
 input wire drain_ack,drain_fault,output reg freeze_precommit,freeze_disable,
 output wire descriptor_valid,runtime_enable,output wire[31:0]descriptor_read,status_read,
 output reg emergency_off,barrier_fault,
 output reg side_job_active,side_disable_committed,output wire quiescent,
 output wire helper_pending,helper_epoch_ok
);
 localparam NONE=0,NORMAL=1,SIDE=2;
 reg[1:0]owner;
 localparam P_NONE=0,P_PRE=1,P_HELPER=2,P_POST=3,P_RESPONSE=4;
 reg[2:0]side_phase;
 reg awhold,whold,b_consumed;reg[11:0]aw;reg[31:0]wd;reg[3:0]ws;
 wire helper_done,helper_error,helper_descriptor,helper_enable;
 wire[31:0]helper_status;
 wire side_request=awhold&&whold&&!s_bvalid&&!side_job_active&&!side_retire_ack;
 wire side_address_ok=(aw==12'h080||aw==12'h084||aw==12'h088)&&ws==15;
 wire side_is_disable=side_address_ok&&aw==12'h084&&wd==0;
 wire normal_slot=owner==NONE&&!side_job_active&&!side_request&&!side_retire_ack&&!release_inflight&&!barrier_fault;
 wire side_slot=owner==NONE&&!release_inflight&&!barrier_fault;
 wire side_free_owner=helper_status[8]&&!reservation_status[0]&&!reservation_status[1]&&!helper_enable&&helper_status[4]&&!helper_status[5];
 wire side_prevalid=(aw==12'h080&&wd==32'h51574d31&&side_free_owner)||(aw==12'h084&&wd==1&&side_free_owner&&helper_status[0]);
 wire helper_side=helper_epoch_ok&&!drain_fault&&((side_request&&side_is_disable&&side_slot)||(side_phase==P_PRE&&drain_ack&&side_slot));
 wire helper_command=helper_side||(helper_epoch_ok&&normal_command&&normal_slot);
 wire[11:0]helper_address=helper_side?aw:normal_address;
 wire[31:0]helper_data=helper_side?wd:normal_data;
 assign descriptor_valid=helper_descriptor&&!emergency_off;
 // This output is solely an immediate revoke clamp to the50MHz async-revoke
 // entry/CPU reset. Local business predicates use synchronized final stages.
 assign runtime_enable=helper_enable&&!emergency_off&&memory_epoch_n;
 assign status_read={helper_status[31:9],(helper_status[8]&&!barrier_fault),helper_status[7:2],(helper_enable&&!emergency_off),helper_status[0]};
 assign release_admit=!side_request&&!side_job_active&&!side_retire_ack&&owner==NONE&&!helper_pending&&!barrier_fault;
 assign release_reject=release_candidate&&!release_admit;
 assign s_awready=board_reset_n&&!awhold&&!side_job_active&&!side_retire_ack&&!s_bvalid;
 assign s_wready=board_reset_n&&!whold&&!side_job_active&&!side_retire_ack&&!s_bvalid;
 assign s_arready=board_reset_n&&!s_rvalid;
 assign quiescent=board_reset_n&&!awhold&&!whold&&!s_bvalid&&!s_rvalid&&!s_awvalid&&!s_wvalid&&!s_arvalid&&!side_job_active&&!side_retire_ack&&owner==NONE&&!helper_pending&&!freeze_precommit&&!freeze_disable&&!drain_ack;
 mcs_runtime_boot_control helper(.clk(clk),.rst_n(board_reset_n),.memory_epoch_n(memory_epoch_n),
 .reservation_status(reservation_status),.transport_fault(transport_fault||barrier_fault),
 .command(helper_command),.address(helper_address),.data(helper_data),
 .ack_on_50(ack_on_50),.ack_off_50(ack_off_50),.owner_50(owner_50),.idle_50(idle_50),.fault_50(fault_50),
 .descriptor_valid(helper_descriptor),.runtime_enable(helper_enable),.descriptor_read(descriptor_read),.status_read(helper_status),
 .done(helper_done),.error(helper_error),.pending(helper_pending),.epoch_ok(helper_epoch_ok));
 always@(posedge clk or negedge board_reset_n)begin
 if(!board_reset_n)begin
  owner<=NONE;awhold<=0;whold<=0;aw<=0;wd<=0;ws<=0;b_consumed<=0;
  s_bvalid<=0;s_bresp<=0;s_rvalid<=0;s_rresp<=0;s_rdata<=0;
  normal_done<=0;normal_error<=0;side_retire_ack<=0;side_phase<=P_NONE;freeze_precommit<=0;freeze_disable<=0;side_job_active<=0;side_disable_committed<=0;emergency_off<=0;barrier_fault<=0;
 end else begin
  normal_done<=0;normal_error<=0;
  if(s_awvalid&&s_awready)begin aw<=s_awaddr;awhold<=1;end
  if(s_wvalid&&s_wready)begin wd<=s_wdata;ws<=s_wstrb;whold<=1;end
  if(s_bvalid&&s_bready)begin s_bvalid<=0;b_consumed<=1;end
  if(s_rvalid&&s_rready)s_rvalid<=0;
  if(s_arvalid&&s_arready)begin
   s_rvalid<=1;s_rresp<=0;s_rdata<=0;
   case(s_araddr)
    12'h080:s_rdata<=descriptor_read;
    12'h084:s_rdata<={31'd0,(helper_enable&&!emergency_off)};
    12'h088:s_rdata<=status_read;
    default:s_rresp<=2;
   endcase
  end
  // One and only one source-clock commit point. A new side command has
  // deterministic priority over a not-yet-committed normal/release command.
  if(side_request)begin
   awhold<=0;whold<=0;side_job_active<=1;b_consumed<=0;
   if(side_is_disable&&helper_command&&helper_side)begin
    owner<=SIDE;side_disable_committed<=1;side_phase<=P_HELPER;
   end else if(side_address_ok&&side_slot&&helper_epoch_ok&&!drain_fault&&side_prevalid)begin
    // OFF/free-owner is checked before holding the trusted side request.
    // The100MHz freeze ACK is a PRE-ENABLE qualification only.
    freeze_precommit<=1;side_phase<=P_PRE;
   end else begin
    s_bvalid<=1;s_bresp<=2;side_phase<=P_RESPONSE;
    if(side_is_disable)begin emergency_off<=1;barrier_fault<=1;end
   end
  end
  if(side_phase==P_PRE)begin
   if(!helper_epoch_ok||drain_fault||release_inflight||barrier_fault)begin
    s_bvalid<=1;s_bresp<=2;side_phase<=P_RESPONSE;freeze_precommit<=0;
    emergency_off<=1;barrier_fault<=1;
   end else if(helper_command&&helper_side)begin
    // Do not retain/reuse this ACK as post-enable quiescence. The CPU may
    // subsequently issue real I/O after the50MHz owner starts it.
    owner<=SIDE;side_phase<=P_HELPER;freeze_precommit<=0;
   end
  end
  if(normal_command)begin
   if(helper_command&&!helper_side)owner<=NORMAL;
   else begin normal_done<=1;normal_error<=1;end
  end
  // Neither an epoch pulse nor CPU reset erases accepted AXI ownership.
  // Loss of the helper epoch produces a real error response,never OKAY.
  if(owner!=NONE&&(helper_done||!helper_epoch_ok))begin
   if(owner==SIDE)begin
    if(helper_error||!helper_epoch_ok||barrier_fault||drain_fault)begin
     s_bvalid<=1;s_bresp<=2;side_phase<=P_RESPONSE;
    end else if(side_disable_committed)begin
     // Latch the real helper OFF/all-I/O/PHY completion. Only now can the
     //100MHz global drain barrier start;late accepted CPU converter requests
     //have already drained through the actual50MHz all-I/O owner.
     freeze_disable<=1;side_phase<=P_POST;
    end else begin s_bvalid<=1;s_bresp<=0;side_phase<=P_RESPONSE;end
   end else begin normal_done<=1;normal_error<=helper_error||!helper_epoch_ok||barrier_fault;end
   owner<=NONE;
  end
  if(side_phase==P_POST)begin
   if(!helper_epoch_ok||drain_fault||barrier_fault)begin
    s_bvalid<=1;s_bresp<=2;side_phase<=P_RESPONSE;emergency_off<=1;barrier_fault<=1;
   end else if(drain_ack)begin s_bvalid<=1;s_bresp<=0;side_phase<=P_RESPONSE;end
  end
  // Retire is NOT the local converter B handshake. A held request can only
  // receive ACK after the source has really produced/consumed its B response.
  if(side_retire_req&&side_job_active&&b_consumed&&owner==NONE&&!s_bvalid)begin
   freeze_precommit<=0;freeze_disable<=0;
   if(!drain_ack)side_retire_ack<=1;
  end
  if(side_retire_ack&&!side_retire_req)begin side_retire_ack<=0;side_job_active<=0;side_disable_committed<=0;b_consumed<=0;side_phase<=P_NONE;end
 end end
endmodule
