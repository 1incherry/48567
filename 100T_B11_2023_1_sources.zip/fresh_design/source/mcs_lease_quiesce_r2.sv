`timescale 1ns/1ps
// Private component only. All lease sources must use release_request, not bypass.
// io_ddr_idle means no CPU DDR request queued/issued and all real R/B consumed,
// including downstream clock-converter state. Control release itself is excluded.
module mcs_lease_quiesce_r2(
 input wire source_clk,source_rst_n,source_epoch_n,
 input wire serial_held,serial_granted,serial_live,serial_release_ready,
 input wire release_request,output wire release_request_ready,
 output wire serial_release_valid,output reg release_done,
 output reg source_fault,output wire freeze_to_io,
 input wire io_clk,io_rst_n,io_acquire_confirmed,io_ddr_idle,
 output wire io_ddr_admit,output wire io_quiesce_ack,
 output reg io_fault,output wire[2:0]source_state,output wire[1:0]io_state
);
 localparam S_IDLE=0,S_ACK=1,S_DROP=2,S_ACKLOW=3,S_FAULT=4;
 localparam D_IDLE=0,D_ACTIVE=1,D_DRAIN=2,D_ACK=3;
 reg[2:0]ss;reg[1:0]ds;
 reg freeze_reg,ack_reg,io_engaged;
 (* ASYNC_REG="TRUE" *)reg[2:0]ack_sync,io_fault_sync,io_alive_sync;
 (* ASYNC_REG="TRUE" *)reg[2:0]freeze_sync,epoch_sync,live_sync;
 reg[2:0]io_up;reg io_was_alive;
 (* ASYNC_REG="TRUE" *)reg[2:0]source_epoch_sync,freeze_allow_sync;
 always @(posedge source_clk or negedge source_rst_n or negedge source_epoch_n)
  if(!source_rst_n||!source_epoch_n)source_epoch_sync<=0;
  else source_epoch_sync<={source_epoch_sync[1:0],1'b1};
 // Falling permit is remembered asynchronously even while IO clock is stopped.
 // Source business recovery and the IO state machine only use local final FFs.
 always @(posedge io_clk or negedge io_rst_n or posedge freeze_to_io)
  if(!io_rst_n||freeze_to_io)freeze_allow_sync<=0;
  else freeze_allow_sync<={freeze_allow_sync[1:0],1'b1};
 wire source_epoch_live=source_epoch_sync[2];
 wire src_epoch=source_rst_n&&source_epoch_n;
 // Raw permit is only revoked asynchronously. Re-grant waits synchronized health.
 assign freeze_to_io=freeze_reg||!src_epoch||source_fault;
 assign io_ddr_admit=io_rst_n&&epoch_sync[2]&&live_sync[2]&&freeze_allow_sync[2]&&
                     ds==D_ACTIVE&&!io_fault;
 assign io_quiesce_ack=ack_reg&&io_rst_n;
 assign release_request_ready=ss==S_IDLE&&!source_fault&&source_epoch_live&&
      io_alive_sync[2]&&!ack_sync[2]&&serial_held&&serial_granted&&serial_live;
 assign serial_release_valid=ss==S_ACK&&ack_sync[2]&&io_alive_sync[2]&&
      !io_fault_sync[2]&&!source_fault&&source_epoch_live&&serial_release_ready;
 assign source_state=ss;assign io_state=ds;
 always @(posedge io_clk or negedge io_rst_n)
  if(!io_rst_n)io_up<=0;else io_up<={io_up[1:0],1'b1};
 always @(posedge source_clk or negedge source_rst_n or negedge io_rst_n)
  if(!source_rst_n||!io_rst_n)begin ack_sync<=0;io_fault_sync<=0;io_alive_sync<=0;end
  else begin ack_sync<={ack_sync[1:0],io_quiesce_ack};
   io_fault_sync<={io_fault_sync[1:0],io_fault};io_alive_sync<={io_alive_sync[1:0],io_up[2]};end
 always @(posedge io_clk or negedge io_rst_n)
  if(!io_rst_n)freeze_sync<=0;else freeze_sync<={freeze_sync[1:0],freeze_to_io};
 always @(posedge io_clk or negedge io_rst_n or negedge src_epoch)
  if(!io_rst_n||!src_epoch)epoch_sync<=0;else epoch_sync<={epoch_sync[1:0],1'b1};
 always @(posedge io_clk or negedge io_rst_n or negedge serial_live)
  if(!io_rst_n||!serial_live)live_sync<=0;else live_sync<={live_sync[1:0],1'b1};
 always @(posedge source_clk or negedge source_rst_n)begin
  if(!source_rst_n)begin ss<=S_IDLE;freeze_reg<=0;release_done<=0;source_fault<=0;io_was_alive<=0;end
  else begin
   release_done<=0;
   if(io_alive_sync[2])io_was_alive<=1;
   if((ss!=S_IDLE&&(!source_epoch_live||!io_alive_sync[2]))||io_fault_sync[2]||
      (io_was_alive&&serial_held&&serial_granted&&!io_alive_sync[2]))begin
    source_fault<=1;freeze_reg<=1;ss<=S_FAULT;
   end else case(ss)
    S_IDLE:if(release_request&&release_request_ready)begin freeze_reg<=1;ss<=S_ACK;end
    S_ACK:if(serial_release_valid)ss<=S_DROP;
    S_DROP:if(!serial_held&&!serial_granted)begin freeze_reg<=0;ss<=S_ACKLOW;end
    S_ACKLOW:if(!ack_sync[2])begin release_done<=1;ss<=S_IDLE;end
    S_FAULT:begin freeze_reg<=1;source_fault<=1;end
    default:begin source_fault<=1;freeze_reg<=1;ss<=S_FAULT;end
   endcase
  end
 end
 always @(posedge io_clk or negedge io_rst_n)begin
  if(!io_rst_n)begin ds<=D_IDLE;ack_reg<=0;io_fault<=0;io_engaged<=0;end
  else begin
   // Narrow source reset survives in asynchronously cleared epoch_sync even if
   // the IO clock stopped. An engaged question cannot silently resume an epoch.
   if(io_engaged&&!epoch_sync[2])begin io_fault<=1;ack_reg<=0;end
   if(io_fault)begin ack_reg<=0;end
   else case(ds)
    D_IDLE:begin
     ack_reg<=0;
     if(freeze_sync[2]&&epoch_sync[2])ds<=D_DRAIN;
     else if(io_acquire_confirmed)begin
      if(epoch_sync[2]&&live_sync[2]&&freeze_allow_sync[2])begin ds<=D_ACTIVE;io_engaged<=1;end
      else io_fault<=1;
     end
    end
    D_ACTIVE:begin
     if(freeze_sync[2])ds<=D_DRAIN;
     else if(!live_sync[2]&&freeze_allow_sync[2])io_fault<=1;
     if(io_acquire_confirmed)io_fault<=1;
    end
    D_DRAIN:begin
     // No new DDR launch is possible once the registered source freeze asserts.
     if(freeze_allow_sync[2]||!freeze_sync[2])begin io_fault<=1;ack_reg<=0;end
     else if(io_ddr_idle&&epoch_sync[2])begin ack_reg<=1;ds<=D_ACK;end
    end
    D_ACK:begin
     if(!io_ddr_idle)begin io_fault<=1;ack_reg<=0;end
     else if(!freeze_sync[2])begin
      ack_reg<=0;io_engaged<=0;ds<=D_IDLE;
     end
    end
   endcase
  end
 end
endmodule
