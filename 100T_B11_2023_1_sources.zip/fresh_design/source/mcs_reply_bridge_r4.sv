`timescale 1ns/1ps
// Private strict candidate only; no board integration or qualification.
// MCS IO pulses are single-cycle; one outstanding command, no speculative ACK.
module mcs_reply_bridge_r4(
 input wire clk,rst_n,input wire ddr_admit,ddr_epoch_live,
 output wire ddr_idle,output reg acquire_confirmed,
 input wire io_addr_strobe,io_read_strobe,io_write_strobe,
 input wire[31:0]io_address,io_write_data,input wire[3:0]io_byte_enable,
 output reg[31:0]io_read_data,output reg io_ready,
 output reg fault,output reg[7:0]fault_cause,output reg[31:0]fault_address,
 output reg[31:0]m_awaddr,output reg m_awvalid,input wire m_awready,
 output reg[31:0]m_wdata,output reg[3:0]m_wstrb,output reg m_wvalid,input wire m_wready,
 input wire[1:0]m_bresp,input wire m_bvalid,output wire m_bready,
 output reg[31:0]m_araddr,output reg m_arvalid,input wire m_arready,
 input wire[31:0]m_rdata,input wire[1:0]m_rresp,input wire m_rvalid,output wire m_rready
);
 localparam IDLE=0,WRITE=1,BWAIT=2,READ=3,RWAIT=4;
 reg[2:0]state;reg active_ddr;reg acquire_pending;reg[31:0]active_address,completed;
 wire awdone=!m_awvalid||m_awready,wdone=!m_wvalid||m_wready;
 assign m_bready=state==BWAIT;assign m_rready=state==RWAIT;
 wire core=io_address[31:8]==24'hc00000;
 wire eth=io_address>=32'hc1000000&&io_address<32'hc1000400;
 wire core_ro=io_address==32'hc0000000||io_address==32'hc0000004||
   io_address==32'hc000003c||io_address==32'hc0000040||
   io_address==32'hc0000058||io_address==32'hc00000e0;
 wire eth_ro=io_address==32'hc1000030||io_address==32'hc1000000||
   io_address==32'hc1000004||io_address==32'hc100000c||io_address==32'hc1000014||io_address==32'hc1000018||
   (io_address>=32'hc1000100&&io_address<32'hc1000200&&io_address[1:0]==0);
 // Exact root try-freeze ABI: RO metadata/body and only010=2; no legacy/replay.
 wire core_wo=(io_address==32'hc0000010&&io_write_data==0)||
   (io_address==32'hc0000014&&io_write_data==1)||
   (io_address==32'hc0000030&&io_write_data>=1&&io_write_data<=192)||
   (io_address==32'hc0000034&&io_write_data==1)||
   (io_address==32'hc0000038&&io_write_data[31:17]==0&&io_write_data[15:0]!=16'hffff)||
   (io_address==32'hc0000044&&io_write_data==1);
 wire reply_wo=(io_address==32'hc1000024||io_address==32'hc1000028)||
   (io_address>=32'hc1000300&&io_address<=32'hc1000368&&io_address[1:0]==0)||
   (io_address==32'hc1000020&&io_write_data==1);
 wire eth_wo=reply_wo||(io_address==32'hc1000034&&(io_write_data==1||io_write_data==2))||
   (io_address==32'hc1000010&&io_write_data==2);
 wire control_allowed=io_address[1:0]==0&&io_byte_enable==15&&
   ((io_read_strobe&&(core_ro||eth_ro))||(io_write_strobe&&(core_wo||eth_wo)));
 wire ctrl=core||eth;
 wire kv=io_address>=32'hce000000&&io_address<32'hce630000;
 wire pool=io_address>=32'hce740000&&io_address<32'hcf000000;
 wire localcsr=io_address>=32'hc2000000&&io_address<32'hc2000014;
 wire[31:0]mapped=ctrl?(io_address-32'h80000000):(io_address-32'h40000000);
 assign ddr_idle=!(state!=IDLE&&active_ddr);
 task mark_fault(input[7:0]cause,input[31:0]address);
 begin if(!fault)begin fault<=1;fault_cause<=cause;fault_address<=address;end end
 endtask
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=IDLE;active_ddr<=0;active_address<=0;completed<=0;
   io_read_data<=0;io_ready<=0;acquire_confirmed<=0;acquire_pending<=0;fault<=0;fault_cause<=0;fault_address<=0;
   m_awaddr<=0;m_awvalid<=0;m_wdata<=0;m_wstrb<=0;m_wvalid<=0;m_araddr<=0;m_arvalid<=0;
  end else begin
   io_ready<=0;acquire_confirmed<=0;
   if(state!=IDLE&&io_addr_strobe)mark_fault(8'h06,io_address);
   if(state!=IDLE&&active_ddr&&!ddr_epoch_live)mark_fault(8'h07,active_address);
   case(state)
   IDLE:if(io_addr_strobe)begin
    active_address<=io_address;
    if(localcsr&&io_read_strobe&&!io_write_strobe&&io_address[1:0]==0&&io_byte_enable==15)begin
     io_ready<=1;
     case(io_address[4:0])
      0:io_read_data<={31'd0,fault};
      4:io_read_data<={24'd0,fault_cause};
      8:io_read_data<=fault_address;
      12:io_read_data<=32'h4d435334;
      16:io_read_data<=completed;
      default:begin io_read_data<=32'hdead0001;mark_fault(8'h01,io_address);end
     endcase
    end else if(fault)begin io_ready<=1;io_read_data<=32'hdead00ff;end
    else if(io_read_strobe==io_write_strobe||io_byte_enable==0)begin io_ready<=1;io_read_data<=32'hdead0002;mark_fault(8'h02,io_address);end
    else if(!(ctrl||kv||pool)|| (ctrl&&!control_allowed))begin io_ready<=1;io_read_data<=32'hdead0001;mark_fault(8'h01,io_address);end
    else if(((kv||pool)||(io_write_strobe&&core_wo)||
       (io_write_strobe&&reply_wo)||
       (io_write_strobe&&io_address==32'hc1000034&&io_write_data==2))&&!ddr_admit)begin io_ready<=1;io_read_data<=32'hdead0003;mark_fault(8'h03,io_address);end
    else begin
     active_ddr<=kv||pool;
     if(io_write_strobe)begin
      m_awaddr<={mapped[31:2],2'b00};m_awvalid<=1;
      m_wdata<=io_write_data;m_wstrb<=io_byte_enable;m_wvalid<=1;state<=WRITE;
     end else begin m_araddr<={mapped[31:2],2'b00};m_arvalid<=1;state<=READ;end
    end
   end
   WRITE:begin
    if(m_awvalid&&m_awready)m_awvalid<=0;
    if(m_wvalid&&m_wready)m_wvalid<=0;
    if(awdone&&wdone)state<=BWAIT;
   end
   BWAIT:if(m_bvalid)begin
    io_ready<=1;io_read_data<=0;completed<=completed+1'b1;state<=IDLE;
    if(m_bresp==0&&active_address==32'hc1000034&&m_wdata==1)acquire_pending<=1;
    if(m_bresp!=0)begin io_read_data<=32'hdead0004;mark_fault(8'h04,active_address);end
   end
   READ:if(m_arready)begin m_arvalid<=0;state<=RWAIT;end
   RWAIT:if(m_rvalid)begin
    io_ready<=1;io_read_data<=m_rdata;completed<=completed+1'b1;state<=IDLE;
    if(m_rresp==0&&active_address==32'hc1000030&&acquire_pending&&
       (m_rdata&32'h00000307)==32'h00000207)begin acquire_confirmed<=1;acquire_pending<=0;end
    if(m_rresp!=0)begin io_read_data<=32'hdead0005;mark_fault(8'h05,active_address);end
   end
   default:begin state<=IDLE;mark_fault(8'h08,active_address);end
   endcase
  end
 end
endmodule
