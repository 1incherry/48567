// Capture a full64-FP32 frame before feeding the selected KV quantizer.
// Errors drain the accepted AXI burst; unknown payload is rejected, never zeroed.
module qwen_fp32_frame64_axi128_reader_v2 #(
 parameter [31:0] DDR_BASE=32'h80000000,parameter [32:0] DDR_BYTES=33'h010000000
)(
 input wire clk,rst_n,cmd_valid,output wire cmd_ready,
 input wire [31:0] cmd_source_base,input wire [15:0] cmd_seq,
 output wire out_valid,input wire out_ready,output wire [31:0] out_fp32,
 output wire out_last,output wire [15:0] out_seq,
 output wire rsp_valid,input wire rsp_ready,output reg [7:0] rsp_error,
 output wire [15:0] rsp_seq,output wire busy,output reg [31:0] cycle_count,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready
);
 localparam IDLE=0,RA=1,RD=2,SEND=3,RESPONSE=4,PRIME=5,CHECK=6,ADDRESS=7,LIMIT=8;
 reg [3:0] state;
 reg [31:0] read_address;reg [4:0] burst_registered;reg [31:0] base;reg [15:0] seq;
 reg [4:0] read_word,burst_count,burst_length;reg [5:0] send_index;
 wire [31:0] output_word;
 reg read_bad;
 // One complete AXI128 beat per write, one synchronous wholebeat read.
 // Lane selection is captured on the same original PRIME/SEND read edge.
 (* ram_style="block" *) reg [127:0] frame[0:15];
 reg [127:0] frame_read_word;
 reg [1:0] frame_read_lane;
 reg output_primed;
 wire [5:0] frame_prefetch_index=(state==PRIME)?6'd0:(send_index+6'd1);
 wire frame_prefetch=rst_n&&(state==PRIME||(state==SEND&&out_valid&&out_ready&&!out_last));
 always @(posedge clk)if(rst_n&&state==RD&&m_axi_rvalid&&m_axi_rready&&read_word<16)
  frame[read_word[3:0]]<=m_axi_rdata;
 always @(posedge clk)if(frame_prefetch)begin
  frame_read_word<=frame[frame_prefetch_index[5:2]];
  frame_read_lane<=frame_prefetch_index[1:0];
 end
 always @(posedge clk or negedge rst_n)
  if(!rst_n)output_primed<=0;
  else if(frame_prefetch)output_primed<=1;
 // Async reset remains immediately observable as0. Unknown BRAM data cannot
 // escape before a complete accepted frame reaches original PRIME edge.
 assign output_word=output_primed?frame_read_word[frame_read_lane*32 +:32]:32'd0;
 wire [32:0] window_end={1'b0,DDR_BASE}+DDR_BYTES;
 assign cmd_ready=rst_n&&state==IDLE;assign rsp_valid=rst_n&&state==RESPONSE;
 assign rsp_seq=seq;assign busy=state!=IDLE&&state!=RESPONSE;
 assign out_valid=rst_n&&state==SEND;assign out_fp32=output_word;assign out_last=send_index==63;assign out_seq=seq;
 assign m_axi_araddr=read_address;
 wire [8:0] page=(13'd4096-{1'b0,m_axi_araddr[11:0]})>>4;
 wire [4:0] left=16-read_word;
 wire [4:0] burst=left<page?left:page[4:0];
 assign m_axi_arvalid=rst_n&&state==RA;assign m_axi_arlen=burst_registered-1;
 assign m_axi_arsize=4;assign m_axi_arburst=1;assign m_axi_rready=rst_n&&state==RD;
 wire unknown_payload=(^m_axi_rdata)===1'bx;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;base<=0;seq<=0;read_word<=0;burst_count<=0;burst_length<=0;send_index<=0;read_bad<=0;rsp_error<=0;cycle_count<=0;end
  else begin
   if(busy)cycle_count<=cycle_count+1;
   case(state)
    IDLE:if(cmd_valid&&cmd_ready)begin
     base<=cmd_source_base;seq<=cmd_seq;read_word<=0;send_index<=0;read_bad<=0;rsp_error<=0;cycle_count<=0;
     state<=CHECK;
    end
    CHECK:begin
     if(base[3:0]!=0||{1'b0,base}<{1'b0,DDR_BASE}||{1'b0,base}+33'd256>window_end)
      begin rsp_error<=1;state<=RESPONSE;end
     else state<=ADDRESS;
    end
    ADDRESS:begin read_address<=base+({27'd0,read_word}<<4);state<=LIMIT;end
    LIMIT:begin burst_registered<=burst;state<=RA;end
    RA:if(m_axi_arvalid&&m_axi_arready)begin burst_length<=burst_registered;burst_count<=0;state<=RD;end
    RD:if(m_axi_rvalid&&m_axi_rready)begin
     if(m_axi_rresp!==2'b00)begin read_bad<=1;rsp_error<=2;end
     if(m_axi_rlast!==(burst_count+1==burst_length))begin read_bad<=1;rsp_error<=3;end
     if(unknown_payload)begin read_bad<=1;rsp_error<=5;end
     // Storage write is in the separate no-reset synchronous process.
     read_word<=read_word+1;burst_count<=burst_count+1;
     if(m_axi_rlast===1'b1)begin
      if(read_bad||unknown_payload||m_axi_rresp!==2'b00||burst_count+1!=burst_length)state<=RESPONSE;
      else if(read_word==15)begin send_index<=0;state<=PRIME;end
      else state<=ADDRESS;
     end
    end
    PRIME:begin state<=SEND;end
    SEND:if(out_valid&&out_ready)begin if(out_last)state<=RESPONSE;else begin send_index<=send_index+1;end end
    RESPONSE:if(rsp_ready)state<=IDLE;
    default:begin rsp_error<=255;state<=RESPONSE;end
   endcase
  end
 end
endmodule
