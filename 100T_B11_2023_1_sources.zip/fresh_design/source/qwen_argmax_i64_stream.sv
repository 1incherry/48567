`timescale 1ns/1ps
// Streaming signed INT64 argmax. Ties keep the lowest index, matching C/Python.
module qwen_argmax_i64_stream #(
  parameter INDEX_W = 16
) (
  input  logic clk,
  input  logic rst_n,
  input  logic frame_start,
  input  logic in_valid,
  input  logic in_last,
  input  logic signed [63:0] value_i64,
  output logic result_valid,
  output logic [INDEX_W-1:0] argmax_index,
  output logic signed [63:0] argmax_value
);
  logic [INDEX_W-1:0] index_q;
  logic have_q;
  logic [INDEX_W-1:0] best_index_q;
  logic signed [63:0] best_value_q;
  always_ff @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      result_valid <= 1'b0; index_q <= '0; have_q <= 1'b0;
      best_index_q <= '0; best_value_q <= '0;
      argmax_index <= '0; argmax_value <= '0;
    end else begin
      result_valid <= 1'b0;
      if (frame_start) begin
        index_q <= '0; have_q <= 1'b0;
      end
      if (in_valid) begin
        if (!have_q || value_i64 > best_value_q) begin
          best_value_q <= value_i64;
          best_index_q <= index_q;
          have_q <= 1'b1;
        end
        if (in_last) begin
          result_valid <= 1'b1;
          if (!have_q || value_i64 > best_value_q) begin
            argmax_value <= value_i64;
            argmax_index <= index_q;
          end else begin
            argmax_value <= best_value_q;
            argmax_index <= best_index_q;
          end
          index_q <= '0;
          have_q <= 1'b0;
        end else begin
          index_q <= index_q + 1'b1;
        end
      end
    end
  end
endmodule
