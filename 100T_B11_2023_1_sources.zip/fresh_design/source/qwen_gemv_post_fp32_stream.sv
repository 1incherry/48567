// Live GEMV integer output -> original C FP32 postprocess, no recorded-result ROM.
// kind0: float(i64)*(sx*2^-24)+bias; kind1: ((float(i64)*sq)*ks)*0.125.
// kind2: float(i64)*sa; kind3: float(i64)*(sx*2^-24), without bias addition.
// 43 common enabled cycles, II1. Invalid kind is returned as out_error.
module qwen_gemv_post_fp32_stream #(parameter TAG_WIDTH=20)(
 input wire clk,rst_n,in_valid,
 output wire in_ready,
 input wire signed [63:0] value_i64,
 input wire [2:0] in_kind,
 input wire [31:0] a_fp32,b_fp32,c_fp32,
 input wire in_last,
 input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,
 input wire out_ready,
 output wire [31:0] result_fp32,
 output wire out_error,out_last,
 output wire [TAG_WIDTH-1:0] out_tag
);
 wire ce=out_ready||!out_valid;
 assign in_ready=ce&&rst_n;
 wire accepted=in_valid&&rst_n;
 wire conv_valid,conv_ready,conv_last;wire [31:0] conv_fp32;
 wire [TAG_WIDTH-1:0] conv_tag;
 qwen_i64_fp32_pipeline_ce #(.TAG_WIDTH(TAG_WIDTH)) converter(
  .clk,.rst_n,.clock_enable(ce),.in_valid(accepted),.in_ready(conv_ready),.value_i64,
  .in_last,.in_tag,.out_valid(conv_valid),.result_fp32(conv_fp32),.out_last(conv_last),.out_tag(conv_tag));
 wire [31:0] x8,a8,b8,c8,scale8;wire scale_valid;
 wire [TAG_WIDTH-1:0] tag8;wire valid8,last8;wire [2:0] kind8;
 qwen_ce_delay #(.WIDTH(32),.DEPTH(3)) delay_x(.clk,.rst_n,.ce,.din(conv_fp32),.dout(x8));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(8)) delay_a(.clk,.rst_n,.ce,.din(a_fp32),.dout(a8));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(8)) delay_b(.clk,.rst_n,.ce,.din(b_fp32),.dout(b8));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(8)) delay_c(.clk,.rst_n,.ce,.din(c_fp32),.dout(c8));
 qwen_fp_mul scale(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(accepted),.s_axis_a_tdata(a_fp32),.s_axis_b_tvalid(accepted),.s_axis_b_tdata(32'h33800000),.m_axis_result_tvalid(scale_valid),.m_axis_result_tdata(scale8));
 qwen_ce_delay #(.WIDTH(TAG_WIDTH+5),.DEPTH(8)) metadata(.clk,.rst_n,.ce,
  .din({accepted,in_kind,in_last,in_tag}),.dout({valid8,kind8,last8,tag8}));
 wire [2:0] post_mode=kind8==0?3'd2:kind8==1?3'd3:kind8==2||kind8==3?3'd1:3'd4;
 wire post_ready;
 qwen_postprocess_fp32_stream #(.TAG_WIDTH(TAG_WIDTH)) postprocessor(
  .clk,.rst_n,.in_valid(valid8),.in_ready(post_ready),.in_mode(post_mode),.x_fp32(x8),
  .a_fp32(kind8==0||kind8==3?scale8:a8),.b_fp32(b8),.c_fp32(c8),
  .in_last(last8),.in_tag(tag8),.out_valid,.out_ready,.result_fp32,.out_error,.out_last,.out_tag);
endmodule
