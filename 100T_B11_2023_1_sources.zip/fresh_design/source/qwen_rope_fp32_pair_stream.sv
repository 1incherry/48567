// Original C FP32 RoPE pair: (a*cos - b*sin, b*cos + a*sin).
// Four multiply8 pipelines, two add11 pipelines; 19 enabled cycles, II1.
// Explicit sign inversion preserves subtraction without fused arithmetic.
// Selected normal/zero model traces; whole IEEE subnormal scope is pending.
module qwen_rope_fp32_pair_stream #(parameter TAG_WIDTH=16)(
 input wire clk,rst_n,in_valid,
 output wire in_ready,
 input wire [31:0] a_fp32,b_fp32,cos_fp32,sin_fp32,
 input wire in_last,
 input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,
 input wire out_ready,
 output wire [31:0] result_a_fp32,result_b_fp32,
 output wire out_last,
 output wire [TAG_WIDTH-1:0] out_tag
);
 wire ce=out_ready||!out_valid;
 assign in_ready=ce&&rst_n;
 wire accepted=in_valid&&rst_n;
 wire va,vb,vc,vd;wire [31:0] ac,bs,bc,asine;
 qwen_fp_mul mul_ac(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(accepted),.s_axis_a_tdata(a_fp32),.s_axis_b_tvalid(accepted),.s_axis_b_tdata(cos_fp32),.m_axis_result_tvalid(va),.m_axis_result_tdata(ac));
 qwen_fp_mul mul_bs(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(accepted),.s_axis_a_tdata(b_fp32),.s_axis_b_tvalid(accepted),.s_axis_b_tdata(sin_fp32),.m_axis_result_tvalid(vb),.m_axis_result_tdata(bs));
 qwen_fp_mul mul_bc(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(accepted),.s_axis_a_tdata(b_fp32),.s_axis_b_tvalid(accepted),.s_axis_b_tdata(cos_fp32),.m_axis_result_tvalid(vc),.m_axis_result_tdata(bc));
 qwen_fp_mul mul_as(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(accepted),.s_axis_a_tdata(a_fp32),.s_axis_b_tvalid(accepted),.s_axis_b_tdata(sin_fp32),.m_axis_result_tvalid(vd),.m_axis_result_tdata(asine));
 qwen_fp_add rotate_a(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(va),.s_axis_a_tdata(ac),.s_axis_b_tvalid(vb),.s_axis_b_tdata({!bs[31],bs[30:0]}),.m_axis_result_tvalid(out_valid),.m_axis_result_tdata(result_a_fp32));
 wire out_b_valid;
 qwen_fp_add rotate_b(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(vc),.s_axis_a_tdata(bc),.s_axis_b_tvalid(vd),.s_axis_b_tdata(asine),.m_axis_result_tvalid(out_b_valid),.m_axis_result_tdata(result_b_fp32));
 qwen_ce_delay #(.WIDTH(TAG_WIDTH+1),.DEPTH(19)) sideband(.clk,.rst_n,.ce,.din({in_last,in_tag}),.dout({out_last,out_tag}));
endmodule
