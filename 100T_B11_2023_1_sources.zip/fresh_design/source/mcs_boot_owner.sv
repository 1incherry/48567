`timescale 1ns/1ps
// Source request/descriptor are held registered flags from loader-only CSR.
// Descriptor means only layout ABI commit, never weight hash authentication.
module mcs_boot_owner(input wire clk,board_reset_n,source_epoch_n,
 input wire descriptor_source,enable_source,io_idle,phy_quiet,subsystem_fault,
 input wire runtime_mode,output wire trusted_mode_set,trusted_mode_value,
 output wire cpu_reset_n,output reg ack_on,ack_off,output reg fault,
 output wire[2:0]state_debug);
 localparam OFF=0,OWNER=1,RELEASE=2,RUN=3,DRAIN_OFF=4,FAILED=5;
 reg[2:0]state,release_pipe;reg ever_started;
 (* ASYNC_REG="TRUE" *)reg[2:0]request_sync,descriptor_sync,epoch_sync;
 wire local_enable=epoch_sync[2]&&descriptor_sync[2]&&request_sync[2];
 always@(posedge clk or negedge board_reset_n or negedge source_epoch_n)
  if(!board_reset_n||!source_epoch_n)epoch_sync<=0;else epoch_sync<={epoch_sync[1:0],1'b1};
 always@(posedge clk or negedge board_reset_n or negedge enable_source)
  if(!board_reset_n||!enable_source)request_sync<=0;else request_sync<={request_sync[1:0],1'b1};
 always@(posedge clk or negedge board_reset_n or negedge descriptor_source)
  if(!board_reset_n||!descriptor_source)descriptor_sync<=0;else descriptor_sync<={descriptor_sync[1:0],1'b1};
 assign cpu_reset_n=board_reset_n&&source_epoch_n&&descriptor_source&&enable_source&&epoch_sync[2]&&state==RUN;
 // Replies to the source are locally registered facts,not raw epoch predicates.
 always@(posedge clk or negedge board_reset_n)
  if(!board_reset_n)begin ack_on<=0;ack_off<=0;end
  else begin
   ack_on<=state==RUN&&local_enable&&runtime_mode;
   ack_off<=state==OFF&&!runtime_mode&&io_idle&&phy_quiet;
  end
 assign trusted_mode_value=state!=DRAIN_OFF;
 assign trusted_mode_set=board_reset_n&&io_idle&&phy_quiet&&
  ((state==OWNER&&local_enable&&!runtime_mode)||
   (state==DRAIN_OFF&&runtime_mode));
 assign state_debug=state;
 always@(posedge clk or negedge board_reset_n)begin
  if(!board_reset_n)begin state<=OFF;release_pipe<=0;ever_started<=0;fault<=0;end
  else begin
   // A short epoch loss is remembered by async-cleared epoch_sync even if
   // the50M clock stopped. Never restore a CPU to empty/reinitialized DDR.
   if(ever_started&&!epoch_sync[2])begin state<=FAILED;release_pipe<=0;fault<=1;end
   else case(state)
    OFF:begin release_pipe<=0;
     if(request_sync[2]&&descriptor_sync[2]&&epoch_sync[2]&&!subsystem_fault&&!fault)state<=OWNER;
    end
    OWNER:begin
     if(!request_sync[2]||!descriptor_sync[2])state<=DRAIN_OFF;
     else if(subsystem_fault)begin fault<=1;state<=FAILED;end
     else if(runtime_mode&&io_idle&&phy_quiet)begin release_pipe<=0;state<=RELEASE;end
    end
    RELEASE:begin
     if(!request_sync[2]||!descriptor_sync[2])begin state<=DRAIN_OFF;release_pipe<=0;end
     else if(subsystem_fault)begin fault<=1;state<=FAILED;end
     else if(!io_idle||!phy_quiet||!runtime_mode)begin state<=OWNER;release_pipe<=0;end
     else begin release_pipe<={release_pipe[1:0],1'b1};if(&release_pipe)begin state<=RUN;ever_started<=1;end end
    end
    RUN:begin
     // Known checked-bus faults deny new DDR/GO in hardware but leave the CPU
     // alive to send a typed local UART fault if that transport is still safe.
     if(subsystem_fault)fault<=1;
     if(!request_sync[2])state<=DRAIN_OFF;
     else if(!descriptor_sync[2]||!runtime_mode)begin fault<=1;state<=FAILED;end
    end
    DRAIN_OFF:begin
     release_pipe<=0;
     if(io_idle&&phy_quiet&&!runtime_mode)state<=OFF;
    end
    FAILED:begin release_pipe<=0;fault<=1;end
    default:begin state<=FAILED;fault<=1;release_pipe<=0;end
   endcase
  end
 end
endmodule
