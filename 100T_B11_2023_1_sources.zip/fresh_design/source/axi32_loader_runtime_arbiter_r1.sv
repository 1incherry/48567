`timescale 1ns/1ps
// Pure100MHz transport. CPU/epoch loss NEVER resets accepted owners.
// board_reset_n must be the actual board-domain reset, not runtime admission.
// One whole write and one whole read outstanding, independently owned.
// W may precede AWVALID; backpressure until an address owner is known is legal.
// After accepting an address, admission changes never withdraw VALID or drain.
module axi32_loader_runtime_arbiter_r1(
input wire clk,board_reset_n,
input wire h_new_aw_admit,h_new_ar_admit,c_new_aw_admit,c_new_ar_admit,
input wire h_awid,
input wire [31:0] h_awaddr,
input wire [7:0] h_awlen,
input wire [2:0] h_awsize,
input wire [1:0] h_awburst,
input wire h_awlock,
input wire [3:0] h_awcache,
input wire [2:0] h_awprot,
input wire [3:0] h_awqos,
input wire h_awvalid,
output wire h_awready,
input wire h_arid,
input wire [31:0] h_araddr,
input wire [7:0] h_arlen,
input wire [2:0] h_arsize,
input wire [1:0] h_arburst,
input wire h_arlock,
input wire [3:0] h_arcache,
input wire [2:0] h_arprot,
input wire [3:0] h_arqos,
input wire h_arvalid,
output wire h_arready,
input wire [31:0] h_wdata,
input wire [3:0] h_wstrb,
input wire h_wlast,
input wire h_wvalid,
output wire h_wready,
output wire h_bid,
output wire [1:0] h_bresp,
output wire h_bvalid,
input wire h_bready,
output wire h_rid,
output wire [31:0] h_rdata,
output wire [1:0] h_rresp,
output wire h_rlast,
output wire h_rvalid,
input wire h_rready,
input wire [31:0] c_awaddr,
input wire [2:0] c_awprot,
input wire c_awvalid,
output wire c_awready,
input wire [31:0] c_araddr,
input wire [2:0] c_arprot,
input wire c_arvalid,
output wire c_arready,
input wire [31:0] c_wdata,
input wire [3:0] c_wstrb,
input wire c_wvalid,
output wire c_wready,
output wire [1:0] c_bresp,
output wire c_bvalid,
input wire c_bready,
output wire [31:0] c_rdata,
output wire [1:0] c_rresp,
output wire c_rvalid,
input wire c_rready,
output wire m_awid,
output wire [31:0] m_awaddr,
output wire [7:0] m_awlen,
output wire [2:0] m_awsize,
output wire [1:0] m_awburst,
output wire m_awlock,
output wire [3:0] m_awcache,
output wire [2:0] m_awprot,
output wire [3:0] m_awqos,
output wire m_awvalid,
input wire m_awready,
output wire m_arid,
output wire [31:0] m_araddr,
output wire [7:0] m_arlen,
output wire [2:0] m_arsize,
output wire [1:0] m_arburst,
output wire m_arlock,
output wire [3:0] m_arcache,
output wire [2:0] m_arprot,
output wire [3:0] m_arqos,
output wire m_arvalid,
input wire m_arready,
output wire [31:0] m_wdata,
output wire [3:0] m_wstrb,
output wire m_wlast,
output wire m_wvalid,
input wire m_wready,
input wire m_bid,
input wire [1:0] m_bresp,
input wire m_bvalid,
output wire m_bready,
input wire m_rid,
input wire [31:0] m_rdata,
input wire [1:0] m_rresp,
input wire m_rlast,
input wire m_rvalid,
output wire m_rready,
output reg wr_busy,rd_busy,wr_owner,rd_owner,
output reg [31:0] wr_addr,rd_addr,
output reg [7:0] wr_len,rd_len,
output reg wr_id,rd_id,
output reg [2:0] wr_size,
output reg [1:0] wr_burst,
output reg wr_first_seen,
output reg [31:0] wr_first_data,
output reg [3:0] wr_first_strb,
output reg wr_first_last,
output reg wr_done,rd_done,protocol_fault,
output wire wr_is_034_candidate,wr_is_release,quiescent
);
reg prefer_h_w,prefer_h_r;
reg aw_pending,ar_pending,w_complete;
reg [7:0] w_index,r_index;
reg wr_lock,rd_lock;
reg [3:0] wr_cache,rd_cache,wr_qos,rd_qos;
reg [2:0] wr_prot,rd_prot,rd_size;
reg [1:0] rd_burst;
wire choose_h_w=h_awvalid&&h_new_aw_admit&&(!c_awvalid||!c_new_aw_admit||prefer_h_w);
wire choose_c_w=c_awvalid&&c_new_aw_admit&&(!h_awvalid||!h_new_aw_admit||!prefer_h_w);
wire choose_h_r=h_arvalid&&h_new_ar_admit&&(!c_arvalid||!c_new_ar_admit||prefer_h_r);
wire choose_c_r=c_arvalid&&c_new_ar_admit&&(!h_arvalid||!h_new_ar_admit||!prefer_h_r);
assign h_awready=board_reset_n&&!protocol_fault&&!wr_busy&&choose_h_w;
assign c_awready=board_reset_n&&!protocol_fault&&!wr_busy&&choose_c_w;
assign h_arready=board_reset_n&&!protocol_fault&&!rd_busy&&choose_h_r;
assign c_arready=board_reset_n&&!protocol_fault&&!rd_busy&&choose_c_r;
assign m_awvalid=board_reset_n&&wr_busy&&aw_pending;
assign m_arvalid=board_reset_n&&rd_busy&&ar_pending;
wire selected_wvalid=wr_owner?c_wvalid:h_wvalid;
wire selected_wlast=wr_owner?1'b1:h_wlast;
wire w_last_ok=(selected_wlast==(w_index==wr_len));
assign m_wvalid=board_reset_n&&wr_busy&&!w_complete&&selected_wvalid&&w_last_ok;
assign m_wdata=wr_owner?c_wdata:h_wdata;
assign m_wstrb=wr_owner?c_wstrb:h_wstrb;
assign m_wlast=selected_wlast;
assign h_wready=board_reset_n&&wr_busy&&!wr_owner&&!w_complete&&w_last_ok&&m_wready;
assign c_wready=board_reset_n&&wr_busy&&wr_owner&&!w_complete&&w_last_ok&&m_wready;
wire b_ok=wr_busy&&!aw_pending&&w_complete&&(m_bid==wr_id);
assign h_bvalid=board_reset_n&&b_ok&&!wr_owner&&m_bvalid;
assign c_bvalid=board_reset_n&&b_ok&&wr_owner&&m_bvalid;
assign h_bid=m_bid;assign h_bresp=m_bresp;assign c_bresp=m_bresp;
assign m_bready=board_reset_n&&b_ok&&(wr_owner?c_bready:h_bready);
wire r_ok=rd_busy&&!ar_pending&&(m_rid==rd_id)&&(m_rlast==(r_index==rd_len));
assign h_rvalid=board_reset_n&&r_ok&&!rd_owner&&m_rvalid;
assign c_rvalid=board_reset_n&&r_ok&&rd_owner&&m_rvalid;
assign h_rid=m_rid;assign h_rdata=m_rdata;assign h_rresp=m_rresp;assign h_rlast=m_rlast;
assign c_rdata=m_rdata;assign c_rresp=m_rresp;
assign m_rready=board_reset_n&&r_ok&&(rd_owner?c_rready:h_rready);
assign wr_is_034_candidate=wr_busy&&wr_owner&&wr_addr==32'h41000034&&wr_len==0&&wr_size==2&&wr_burst==1;
assign wr_is_release=wr_is_034_candidate&&wr_first_seen&&wr_first_data==2&&wr_first_strb==4'hf&&wr_first_last;
assign quiescent=board_reset_n&&!protocol_fault&&!wr_busy&&!rd_busy;
assign m_awid=wr_id;
assign m_awaddr=wr_addr;
assign m_awlen=wr_len;
assign m_awsize=wr_size;
assign m_awburst=wr_burst;
assign m_awlock=wr_lock;
assign m_awcache=wr_cache;
assign m_awprot=wr_prot;
assign m_awqos=wr_qos;
assign m_arid=rd_id;
assign m_araddr=rd_addr;
assign m_arlen=rd_len;
assign m_arsize=rd_size;
assign m_arburst=rd_burst;
assign m_arlock=rd_lock;
assign m_arcache=rd_cache;
assign m_arprot=rd_prot;
assign m_arqos=rd_qos;
always @(posedge clk or negedge board_reset_n)begin
 if(!board_reset_n)begin
  wr_busy<=0;rd_busy<=0;wr_owner<=0;rd_owner<=0;
  wr_addr<=0;rd_addr<=0;wr_len<=0;rd_len<=0;wr_id<=0;rd_id<=0;
  wr_size<=0;wr_burst<=0;wr_prot<=0;wr_lock<=0;wr_cache<=0;wr_qos<=0;
  rd_size<=0;rd_burst<=0;rd_prot<=0;rd_lock<=0;rd_cache<=0;rd_qos<=0;
  aw_pending<=0;ar_pending<=0;w_complete<=0;w_index<=0;r_index<=0;
  wr_first_seen<=0;wr_first_data<=0;wr_first_strb<=0;wr_first_last<=0;
  prefer_h_w<=1;prefer_h_r<=1;wr_done<=0;rd_done<=0;protocol_fault<=0;
 end else begin
  wr_done<=0;rd_done<=0;
  if(h_awvalid&&h_awready||c_awvalid&&c_awready)begin
   wr_busy<=1;wr_owner<=choose_c_w;aw_pending<=1;w_complete<=0;w_index<=0;
   wr_first_seen<=0;wr_first_data<=0;wr_first_strb<=0;wr_first_last<=0;
   wr_id<=choose_c_w?1'b0:h_awid;
   wr_addr<=choose_c_w?c_awaddr:h_awaddr;
   wr_len<=choose_c_w?8'd0:h_awlen;
   wr_size<=choose_c_w?3'd2:h_awsize;
   wr_burst<=choose_c_w?2'd1:h_awburst;
   wr_lock<=choose_c_w?1'b0:h_awlock;
   wr_cache<=choose_c_w?4'd0:h_awcache;
   wr_prot<=choose_c_w?c_awprot:h_awprot;
   wr_qos<=choose_c_w?4'd0:h_awqos;
  end
  if(m_awvalid&&m_awready)aw_pending<=0;
  if(m_wvalid&&m_wready)begin
   if(!wr_first_seen)begin wr_first_seen<=1;wr_first_data<=m_wdata;wr_first_strb<=m_wstrb;wr_first_last<=m_wlast;end
   if(m_wlast)w_complete<=1;else w_index<=w_index+1'b1;
  end
  if(m_bvalid&&m_bready)begin wr_busy<=0;wr_done<=1;prefer_h_w<=wr_owner;end
  if(h_arvalid&&h_arready||c_arvalid&&c_arready)begin
   rd_busy<=1;rd_owner<=choose_c_r;ar_pending<=1;r_index<=0;
   rd_id<=choose_c_r?1'b0:h_arid;
   rd_addr<=choose_c_r?c_araddr:h_araddr;
   rd_len<=choose_c_r?8'd0:h_arlen;
   rd_size<=choose_c_r?3'd2:h_arsize;
   rd_burst<=choose_c_r?2'd1:h_arburst;
   rd_lock<=choose_c_r?1'b0:h_arlock;
   rd_cache<=choose_c_r?4'd0:h_arcache;
   rd_prot<=choose_c_r?c_arprot:h_arprot;
   rd_qos<=choose_c_r?4'd0:h_arqos;
  end
  if(m_arvalid&&m_arready)ar_pending<=0;
  if(m_rvalid&&m_rready)begin
   if(m_rlast)begin rd_busy<=0;rd_done<=1;prefer_h_r<=rd_owner;end
   else r_index<=r_index+1'b1;
  end
  // Never consume a wrong ID/LAST or unmatched response as completion.
  // Sticky fault blocks all NEW addresses and keeps quiescent low. Already
  // valid owned traffic can still drain; fault recovery needs board reset.
  if(wr_busy&&!w_complete&&selected_wvalid&&!w_last_ok)protocol_fault<=1;
  if(m_bvalid&&!b_ok)protocol_fault<=1;
  if(m_rvalid&&!r_ok)protocol_fault<=1;
 end
end
endmodule
