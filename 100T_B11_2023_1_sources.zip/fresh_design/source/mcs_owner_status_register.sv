`timescale 1ns/1ps
// Local50MHz predicates registered before the source three-FF synchronizers.
// This is not a drain detector: idle_now must come from actual pending trackers.
module mcs_owner_status_register(input wire clk,board_reset_n,idle_now,fault_now,
 output reg idle_held,fault_held);
 always @(posedge clk or negedge board_reset_n)
  if(!board_reset_n)begin idle_held<=0;fault_held<=0;end
  else begin idle_held<=idle_now;fault_held<=fault_held||fault_now;end
endmodule
