`timescale 1ns/1ps
// No datapath reset, no synthetic AXI/packet completion. Same core clock.
module qwen_token_camera_handover_r1 #(
 parameter integer CORE_HZ=125000000,
 parameter [31:0] CADENCE_CYCLES=CORE_HZ,
 parameter [31:0] PARK_TIMEOUT_CYCLES=$unsigned(CORE_HZ)*32'd30,
 parameter [31:0] WINDOW_TIMEOUT_CYCLES=$unsigned(CORE_HZ)*32'd30
)(
 input wire clk,board_reset_n,epoch_valid,guard_fault,
 input wire enable,cpu_park_requested,cpu_parked,cpu_ddr_allowed,inference_active,
 input wire cpu_unpark_request,
 input wire qwen_quiet_ack,qwen_source_quiet,
 // Four-phase level request/done; done held until camera_request drops.
 input wire camera_done,camera_frame_completed,camera_fault,
 output wire pause_pending,token_pause_request,camera_request,cpu_unpark_allow,
 output wire [2:0] state_debug,
 output reg fault,
 output reg [31:0] completed_windows,
 output wire [31:0] cadence_cycles
);
 localparam RUN=0,PARK=1,WINDOW=2,ACKLOW=3,FAILED=4;
 reg[2:0]state;
 reg[31:0]cadence,age;
 reg engaged;
 wire want=enable&&cpu_park_requested;
 assign state_debug=state;
 assign cadence_cycles=CADENCE_CYCLES;
 assign pause_pending=board_reset_n&&(state!=RUN||fault);
 assign token_pause_request=board_reset_n&&((state==PARK&&cpu_parked&&cpu_park_requested)||state==WINDOW||state==ACKLOW||fault);
 assign camera_request=board_reset_n&&state==WINDOW&&!fault&&epoch_valid;
 // Physical MCS bridge keeps its park latch until this explicit safe return.
 // Revocation of ENABLE is an intent, never an early ACK or lost tail.
 assign cpu_unpark_allow=board_reset_n&&epoch_valid&&!fault&&
                         state==RUN&&
                         !cpu_park_requested&&!camera_done&&!camera_request;
 initial begin
  if(CADENCE_CYCLES<1||PARK_TIMEOUT_CYCLES<2||WINDOW_TIMEOUT_CYCLES<2)
   $error("HANDOVER_POSITIVE_BOUNDED_CLOCK_PARAMETERS_REQUIRED");
 end
 always @(posedge clk or negedge board_reset_n)begin
  if(!board_reset_n)begin state<=RUN;cadence<=0;age<=0;fault<=0;completed_windows<=0;engaged<=0;end
  else begin
   if(want||state!=RUN)engaged<=1;
   if(guard_fault||camera_fault||(engaged&&!epoch_valid))begin fault<=1;state<=FAILED;end
   else if(fault)state<=FAILED;
   else case(state)
    RUN:begin
     age<=0;
     // Cadence applies during the explicitly parked Qwen inference interval.
     // Do not leave a due pause pending during DDR tokenizer/answer transport,
     // which could otherwise reject the next normal sequence START.
     if(!enable||!inference_active||!cpu_park_requested||cpu_unpark_request)cadence<=0;
     else if(cpu_parked&&!cpu_ddr_allowed&&epoch_valid)begin
      if(cadence==CADENCE_CYCLES-1)begin cadence<=0;state<=PARK;end
      else cadence<=cadence+1'b1;
     end
    end
    PARK:begin
     // Before camera admission, an unpark intent may cancel this attempt.
     if(!enable||!inference_active||cpu_unpark_request)begin state<=RUN;age<=0;cadence<=0;end
     // Late CPU safe-point is allowed. A due window never queues another one.
     else if(!cpu_park_requested||!cpu_parked)age<=0;
     else if(cpu_ddr_allowed)begin fault<=1;state<=FAILED;end
     else if(qwen_quiet_ack&&!camera_done)begin state<=WINDOW;age<=0;end
     else if(age==PARK_TIMEOUT_CYCLES-1)begin fault<=1;state<=FAILED;end
     else age<=age+1'b1;
    end
    WINDOW:begin
     // Camera legitimately makes global MIG nonquiet. Only Qwen source-side
     // outstanding/offer accounting must remain quiet while it owns memory.
     if(!cpu_parked||cpu_ddr_allowed||!qwen_source_quiet)begin fault<=1;state<=FAILED;end
     else if(camera_done)begin
      if(camera_frame_completed)begin
       if(completed_windows==32'hffffffff)begin fault<=1;state<=FAILED;end
       else begin completed_windows<=completed_windows+1'b1;state<=ACKLOW;end
      end else state<=ACKLOW;
      age<=0;
     end else if(age==WINDOW_TIMEOUT_CYCLES-1)begin fault<=1;state<=FAILED;end
     else age<=age+1'b1;
    end
    ACKLOW:begin
     // Always complete the reverse handshake before token/CPU resumption.
     if(!cpu_parked||cpu_ddr_allowed||!qwen_source_quiet)begin fault<=1;state<=FAILED;end
     else if(!camera_done)begin state<=RUN;age<=0;cadence<=0;end
     else if(age==WINDOW_TIMEOUT_CYCLES-1)begin fault<=1;state<=FAILED;end
     else age<=age+1'b1;
    end
    FAILED:begin fault<=1;end
    default:begin state<=FAILED;fault<=1;end
   endcase
  end
 end
endmodule
