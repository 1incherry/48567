`timescale 1ns/1ps
// Component resource candidate: actual64K MCS + exact UART frontend + strict IO.
// Official MCS64 IP; production firmware ELF binding is mandatory before bit qualification.
module mcs_uart_subsystem #(parameter integer ENABLE_NTH4=0)(input clk,rst_n,cpu_reset_n,lease_admit,lease_health,
 input trusted_mode_set,trusted_mode_value,
 input token_unpark_allow,output token_cpu_parked,token_cpu_ddr_allowed,token_cpu_park_ack,
 input[7:0]phy_rx_byte,input phy_rx_valid,phy_rx_error,
 output[7:0]phy_tx_byte,output phy_tx_valid,input phy_tx_ready,
 input[7:0]legacy_tx_byte,input legacy_tx_valid,output legacy_tx_ready,
 output[7:0]legacy_rx_byte,output legacy_rx_valid,legacy_rx_error,
 output runtime_mode,mode_accepted,output io_idle,output fault,
 output[31:0]m_awaddr,output m_awvalid,input m_awready,
 output[31:0]m_wdata,output[3:0]m_wstrb,output m_wvalid,input m_wready,
 input[1:0]m_bresp,input m_bvalid,output m_bready,
 output[31:0]m_araddr,output m_arvalid,input m_arready,
 input[31:0]m_rdata,input[1:0]m_rresp,input m_rvalid,output m_rready,
 output ddr_idle,acquire_confirmed,release_quiet,release_owned,release_completion_toggle);
wire native_idle;wire ios,iors,iows,iordy;wire[31:0]ioa,iowd,iord;wire[3:0]iobe;
wire bs,us,brdy,urdy,dispatch_fault,bridge_fault,uart_fault;
wire[31:0]bdata,udata;wire[7:0]bridge_cause,uart_cause;wire[31:0]bridge_address;
assign fault=dispatch_fault||bridge_fault||uart_fault;

mcs_runtime cpu(.Clk(clk),.Reset(!cpu_reset_n),.IO_addr_strobe(ios),.IO_address(ioa),.IO_byte_enable(iobe),.IO_read_data(iord),.IO_read_strobe(iors),.IO_ready(iordy),.IO_write_data(iowd),.IO_write_strobe(iows));

mcs_io_dispatch dispatch(clk,rst_n,cpu_reset_n,ios,ioa,bdata,udata,brdy,urdy,bs,us,iordy,iord,native_idle,dispatch_fault);
mcs_all_io_quiescent_release_r2 all_io(.clk(clk),.board_reset_n(rst_n),.native_idle(native_idle),
 .bridge_strobe(bs),.uart_strobe(us),.read_strobe(iors),.write_strobe(iows),.address(ioa),.data(iowd),.byte_enable(iobe),
 .bridge_ready(brdy),.uart_ready(urdy),.all_idle(io_idle),.release_quiet(release_quiet),.release_owned(release_owned),.release_completion_toggle(release_completion_toggle));
mcs_reply_bridge_r5 #(.ENABLE_NTH4(ENABLE_NTH4)) bridge(clk,rst_n,lease_admit&&!dispatch_fault&&!uart_fault,lease_health&&!dispatch_fault&&!uart_fault,
 token_unpark_allow,token_cpu_parked,token_cpu_ddr_allowed,token_cpu_park_ack,
 ddr_idle,acquire_confirmed,bs,iors,iows,ioa,iowd,iobe,bdata,brdy,bridge_fault,bridge_cause,bridge_address,
 m_awaddr,m_awvalid,m_awready,m_wdata,m_wstrb,m_wvalid,m_wready,m_bresp,m_bvalid,m_bready,
 m_araddr,m_arvalid,m_arready,m_rdata,m_rresp,m_rvalid,m_rready);
mcs_uart_utf8_mmio #(.CLOCK_HZ(50000000)) uart(.clk(clk),.rst_n(rst_n),.trusted_mode_set(trusted_mode_set),.trusted_mode_value(trusted_mode_value),
 .phy_rx_byte(phy_rx_byte),.phy_rx_valid(phy_rx_valid),.phy_rx_error(phy_rx_error),.phy_tx_byte(phy_tx_byte),.phy_tx_valid(phy_tx_valid),.phy_tx_ready(phy_tx_ready),
 .legacy_tx_byte(legacy_tx_byte),.legacy_tx_valid(legacy_tx_valid),.legacy_tx_ready(legacy_tx_ready),.legacy_rx_byte(legacy_rx_byte),.legacy_rx_valid(legacy_rx_valid),.legacy_rx_error(legacy_rx_error),
 .io_addr_strobe(us),.io_read_strobe(iors),.io_write_strobe(iows),.io_address(ioa),.io_write_data(iowd),.io_byte_enable(iobe),
 .selected(),.io_ready(urdy),.io_read_data(udata),.runtime_mode(runtime_mode),.mmio_fault(uart_fault),.fault_code(uart_cause),.mode_accepted(mode_accepted));
endmodule

