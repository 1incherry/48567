// Candidate exact-operation-order binary32 SiLU(gate)*up stream.
// SHA-bound exp table coefficients are generated from the original C header.
// Generated official FP32 IP latencies: mul8, add11, div28. II1.
// Common CE stalls all arithmetic, ROM data and metadata together.
// Actual finite activation domain is the first validation scope; whole-model
// equivalence, synthesis/route and board speed require separate qualification.
module qwen_silu_fp32_stream #(
 parameter EXP_ROM_FILE="exp_coefficients.hex",
 parameter TAG_WIDTH=16
)(
 input wire clk,rst_n,
 input wire in_valid,
 output wire in_ready,
 input wire [31:0] gate_fp32,up_fp32,
 input wire in_last,
 input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,
 input wire out_ready,
 output wire [31:0] result_fp32,
 output wire out_last,
 output wire [TAG_WIDTH-1:0] out_tag
);
 localparam MUL=8,ADD=11,DIV=28,EXP=3+1+MUL+ADD,TOTAL=EXP+ADD+DIV+MUL;
 wire ce=out_ready||!out_valid;
 assign in_ready=ce&&rst_n;
 wire decoded_valid,above32,nonfinite;wire [12:0] index;wire [31:0] fraction;
 qwen_exp_fp32_decode_pipeline decode(.clk,.rst_n,.ce,.in_valid(in_valid&&rst_n),.x_fp32(gate_fp32),.out_valid(decoded_valid),.index,.fraction_fp32(fraction),.above32,.nonfinite);
 // Upper word is pre-rounded table[i+1]-table[i], lower is table[i].
 (* rom_style="block" *) reg [63:0] coefficients[0:4096];
 reg [63:0] coeff;reg [31:0] frac;reg rom_valid,rom_zero;
 initial $readmemh(EXP_ROM_FILE,coefficients);
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin coeff<=0;frac<=0;rom_valid<=0;rom_zero<=0;end
  else if(ce)begin coeff<=coefficients[index];frac<=fraction;rom_valid<=decoded_valid;rom_zero<=above32;end
 end
 wire product_valid,exp_valid;wire [31:0] product,base_delayed,interpolated;
 qwen_fp_mul interpolate_mul(.aclk(clk),.aclken(ce),.aresetn(rst_n),.s_axis_a_tvalid(rom_valid),.s_axis_a_tdata(frac),.s_axis_b_tvalid(rom_valid),.s_axis_b_tdata(coeff[63:32]),.m_axis_result_tvalid(product_valid),.m_axis_result_tdata(product));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(MUL)) base_delay(.clk,.rst_n,.ce,.din(coeff[31:0]),.dout(base_delayed));
 qwen_fp_add interpolate_add(.aclk(clk),.aclken(ce),.aresetn(rst_n),.s_axis_a_tvalid(product_valid),.s_axis_a_tdata(base_delayed),.s_axis_b_tvalid(product_valid),.s_axis_b_tdata(product),.m_axis_result_tvalid(exp_valid),.m_axis_result_tdata(interpolated));
 wire exp_zero;wire [31:0] exp_value,gate_delayed,up_delayed;
 qwen_ce_delay #(.WIDTH(1),.DEPTH(MUL+ADD)) zero_delay(.clk,.rst_n,.ce,.din(rom_zero),.dout(exp_zero));
 assign exp_value=exp_zero?32'd0:interpolated;
 qwen_ce_delay #(.WIDTH(32),.DEPTH(EXP)) gate_delay(.clk,.rst_n,.ce,.din(gate_fp32),.dout(gate_delayed));
 // Both branches preserve the original multiply/divide/multiply order.
 wire num_valid,den_valid,div_valid;wire [31:0] numerator,numerator_aligned,denominator,divided;
 qwen_fp_mul numerator_mul(.aclk(clk),.aclken(ce),.aresetn(rst_n),.s_axis_a_tvalid(exp_valid),.s_axis_a_tdata(gate_delayed),.s_axis_b_tvalid(exp_valid),.s_axis_b_tdata(gate_delayed[31]?exp_value:32'h3f800000),.m_axis_result_tvalid(num_valid),.m_axis_result_tdata(numerator));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(ADD-MUL)) num_align(.clk,.rst_n,.ce,.din(numerator),.dout(numerator_aligned));
 qwen_fp_add denominator_add(.aclk(clk),.aclken(ce),.aresetn(rst_n),.s_axis_a_tvalid(exp_valid),.s_axis_a_tdata(32'h3f800000),.s_axis_b_tvalid(exp_valid),.s_axis_b_tdata(exp_value),.m_axis_result_tvalid(den_valid),.m_axis_result_tdata(denominator));
 qwen_fp_div divide(.aclk(clk),.aclken(ce),.aresetn(rst_n),.s_axis_a_tvalid(den_valid),.s_axis_a_tdata(numerator_aligned),.s_axis_b_tvalid(den_valid),.s_axis_b_tdata(denominator),.m_axis_result_tvalid(div_valid),.m_axis_result_tdata(divided));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(EXP+ADD+DIV)) up_delay(.clk,.rst_n,.ce,.din(up_fp32),.dout(up_delayed));
 qwen_fp_mul output_mul(.aclk(clk),.aclken(ce),.aresetn(rst_n),.s_axis_a_tvalid(div_valid),.s_axis_a_tdata(divided),.s_axis_b_tvalid(div_valid),.s_axis_b_tdata(up_delayed),.m_axis_result_tvalid(out_valid),.m_axis_result_tdata(result_fp32));
 qwen_ce_delay #(.WIDTH(TAG_WIDTH+1),.DEPTH(TOTAL)) sideband(.clk,.rst_n,.ce,.din({in_last,in_tag}),.dout({out_last,out_tag}));
endmodule
