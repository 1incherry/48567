// Tagged cacheless executor for controller GEMV and postprocess commands.
// Run either operation separately or both in dependency order. No CPU or AXI
// Lite programming. Integer and FP32 results are committed in DDR scratch.
module qwen_matrix_fp32_axi128_executor_v5 #(
 parameter [31:0] DDR_BASE=32'h80000000,
 parameter [32:0] DDR_BYTES=33'h010000000
)(
 input wire clk,rst_n,cmd_valid,output wire cmd_ready,
 input wire cmd_run_gemv,cmd_run_post,cmd_mode_i16,cmd_coefficient_enable,
 input wire [15:0] cmd_rows,cmd_cols,cmd_stride_groups,cmd_seq,
 input wire [2:0] cmd_kind,
 input wire [31:0] cmd_weight_base,cmd_activation_base,cmd_integer_base,cmd_float_base,cmd_coefficient_base,cmd_scale_fp32,
 output wire rsp_valid,input wire rsp_ready,output reg [15:0] rsp_seq,
 output reg [7:0] rsp_error,output wire busy,
 output wire [31:0] gemv_cycles,gemv_mac_cycles,gemv_weight_wait_cycles,gemv_read_stall_cycles,post_cycles,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 localparam IDLE=0,G_START=1,G_WAIT=2,P_START=3,P_WAIT=4,RESPONSE=5,
  CHECK_GROUPS=6,CHECK_TILES=7,CHECK_BYTES=8,CHECK_BOUNDS=9,VALIDATE=10;
 reg [3:0] state;
 // Release well before P_START; global reset remains asynchronous.
 reg post_live;
 always @(posedge clk or negedge rst_n)
  if(!rst_n)post_live<=0;
  else post_live<=state!=IDLE;
 reg run_gemv,run_post,mode,co_enable;
 reg [11:0] group_count;reg [27:0] tile_count;
 reg [63:0] required_weights,weight_end;
 reg [32:0] integer_end,activation_end;
 reg [15:0] rows,cols,stride;
 reg [2:0] kind;
 reg [31:0] weight_base,activation_base,integer_base,float_base,coefficient_base,scale;
 wire use_g=state==G_START||state==G_WAIT;
 wire use_p=state==P_START||state==P_WAIT;
 wire g_ready,g_busy,g_done,p_ready,p_valid,p_busy;wire [7:0] g_error,p_error;wire [15:0] p_seq;
 wire [32:0] window_end={1'b0,DDR_BASE}+DDR_BYTES;
 assign cmd_ready=state==IDLE&&rst_n;
 assign rsp_valid=state==RESPONSE&&rst_n;
 assign busy=state!=IDLE&&state!=RESPONSE;
 wire [31:0] g_araddr,g_awaddr,p_araddr,p_awaddr;
 wire [7:0] g_arlen,g_awlen,p_arlen,p_awlen;
 wire [2:0] g_arsize,g_awsize,p_arsize,p_awsize;
 wire [1:0] g_arburst,g_awburst,p_arburst,p_awburst;
 wire g_arvalid,g_rready,g_awvalid,g_wlast,g_wvalid,g_bready,p_arvalid,p_rready,p_awvalid,p_wlast,p_wvalid,p_bready;
 wire [127:0] g_wdata,p_wdata;wire [15:0] g_wstrb,p_wstrb;
 assign m_axi_araddr=use_g?g_araddr:p_araddr;assign m_axi_arlen=use_g?g_arlen:p_arlen;
 assign m_axi_arsize=4;assign m_axi_arburst=1;
 assign m_axi_arvalid=use_g?g_arvalid:use_p?p_arvalid:0;
 assign m_axi_rready=use_g?g_rready:use_p?p_rready:0;
 assign m_axi_awaddr=use_g?g_awaddr:p_awaddr;assign m_axi_awlen=use_g?g_awlen:p_awlen;
 assign m_axi_awsize=4;assign m_axi_awburst=1;
 assign m_axi_awvalid=use_g?g_awvalid:use_p?p_awvalid:0;
 assign m_axi_wdata=use_g?g_wdata:p_wdata;assign m_axi_wstrb=use_g?g_wstrb:p_wstrb;
 assign m_axi_wvalid=use_g?g_wvalid:use_p?p_wvalid:0;
 assign m_axi_wlast=use_g?g_wlast:p_wlast;
 assign m_axi_bready=use_g?g_bready:use_p?p_bready:0;
 qwen_axi_engine_prefetch8_v1518 gemv(.clk,.rst(!rst_n||state==IDLE),.cmd_valid(state==G_START),.cmd_ready(g_ready),.cmd_mode_i16(mode),
  .cmd_weight_base(weight_base),.cmd_activation_base(activation_base),.cmd_output_base(integer_base),.cmd_rows(rows),.cmd_cols(cols),.cmd_stride_groups(stride),
  .busy(g_busy),.done(g_done),.error_code(g_error),.cycle_count(gemv_cycles),.mac_cycles(gemv_mac_cycles),.weight_wait_cycles(gemv_weight_wait_cycles),.read_stall_cycles(gemv_read_stall_cycles),
  .m_axi_araddr(g_araddr),.m_axi_arlen(g_arlen),.m_axi_arsize(g_arsize),.m_axi_arburst(g_arburst),.m_axi_arvalid(g_arvalid),.m_axi_arready(use_g&&m_axi_arready),
  .m_axi_rdata,.m_axi_rresp,.m_axi_rlast,.m_axi_rvalid(use_g&&m_axi_rvalid),.m_axi_rready(g_rready),
  .m_axi_awaddr(g_awaddr),.m_axi_awlen(g_awlen),.m_axi_awsize(g_awsize),.m_axi_awburst(g_awburst),.m_axi_awvalid(g_awvalid),.m_axi_awready(use_g&&m_axi_awready),
  .m_axi_wdata(g_wdata),.m_axi_wstrb(g_wstrb),.m_axi_wlast(g_wlast),.m_axi_wvalid(g_wvalid),.m_axi_wready(use_g&&m_axi_wready),.m_axi_bresp,.m_axi_bvalid(use_g&&m_axi_bvalid),.m_axi_bready(g_bready));
 qwen_gemv_post_axi128_v3 #(.DDR_BASE(DDR_BASE),.DDR_BYTES(DDR_BYTES)) post(.clk,.rst_n(rst_n&&post_live),.cmd_valid(state==P_START),.cmd_ready(p_ready),
  .cmd_rows(rows),.cmd_seq(rsp_seq),.cmd_kind(kind),.cmd_input_base(integer_base),.cmd_output_base(float_base),.cmd_coefficient_base(coefficient_base),.cmd_scale_fp32(scale),.cmd_coefficient_enable(co_enable),
  .rsp_valid(p_valid),.rsp_ready(state==P_WAIT),.rsp_seq(p_seq),.rsp_error(p_error),.busy(p_busy),.cycle_count(post_cycles),
  .m_axi_araddr(p_araddr),.m_axi_arlen(p_arlen),.m_axi_arsize(p_arsize),.m_axi_arburst(p_arburst),.m_axi_arvalid(p_arvalid),.m_axi_arready(use_p&&m_axi_arready),
  .m_axi_rdata,.m_axi_rresp,.m_axi_rlast,.m_axi_rvalid(use_p&&m_axi_rvalid),.m_axi_rready(p_rready),
  .m_axi_awaddr(p_awaddr),.m_axi_awlen(p_awlen),.m_axi_awsize(p_awsize),.m_axi_awburst(p_awburst),.m_axi_awvalid(p_awvalid),.m_axi_awready(use_p&&m_axi_awready),
  .m_axi_wdata(p_wdata),.m_axi_wstrb(p_wstrb),.m_axi_wlast(p_wlast),.m_axi_wvalid(p_wvalid),.m_axi_wready(use_p&&m_axi_wready),.m_axi_bresp,.m_axi_bvalid(use_p&&m_axi_bvalid),.m_axi_bready(p_bready));
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;run_gemv<=0;group_count<=0;tile_count<=0;required_weights<=0;weight_end<=0;integer_end<=0;activation_end<=0;run_post<=0;mode<=0;co_enable<=0;rows<=0;cols<=0;stride<=0;kind<=0;weight_base<=0;activation_base<=0;integer_base<=0;float_base<=0;coefficient_base<=0;scale<=0;rsp_seq<=0;rsp_error<=0;end
  else case(state)
   IDLE:if(cmd_valid&&cmd_ready)begin
    run_gemv<=cmd_run_gemv;run_post<=cmd_run_post;mode<=cmd_mode_i16;co_enable<=cmd_coefficient_enable;rows<=cmd_rows;cols<=cmd_cols;stride<=cmd_stride_groups;kind<=cmd_kind;
    weight_base<=cmd_weight_base;activation_base<=cmd_activation_base;integer_base<=cmd_integer_base;float_base<=cmd_float_base;coefficient_base<=cmd_coefficient_base;scale<=cmd_scale_fp32;rsp_seq<=cmd_seq;rsp_error<=0;
    state<=CHECK_GROUPS;
   end
   CHECK_GROUPS:begin group_count<=({1'b0,rows}+17'd31)>>5;state<=CHECK_TILES;end
   CHECK_TILES:begin tile_count<=group_count*stride;state<=CHECK_BYTES;end
   CHECK_BYTES:begin
    required_weights<=mode?({36'b0,tile_count}<<11):
      (({36'b0,tile_count}<<9)+({36'b0,tile_count}<<6));
    state<=CHECK_BOUNDS;
   end
   CHECK_BOUNDS:begin
    weight_end<={32'b0,weight_base}+required_weights;
    integer_end<={1'b0,integer_base}+({17'b0,rows}<<3);
    activation_end<={1'b0,activation_base}+({17'b0,cols}<<1);
    state<=VALIDATE;
   end
   VALIDATE:begin
    if((!run_gemv&&!run_post)||rows==0||rows>65535||integer_base[3:0]!=0||
      {1'b0,integer_base}<{1'b0,DDR_BASE}||integer_end>window_end||
      (run_gemv&&(cols==0||cols>4864||cols[4:0]!=0||stride<(cols>>5)||weight_base[3:0]!=0||activation_base[3:0]!=0||
      {1'b0,weight_base}<{1'b0,DDR_BASE}||weight_end>{31'b0,window_end}||
      {1'b0,activation_base}<{1'b0,DDR_BASE}||activation_end>window_end)))begin rsp_error<=1;state<=RESPONSE;end
    else state<=run_gemv?G_START:P_START;
   end
   G_START:if(g_ready)state<=G_WAIT;
   G_WAIT:if(g_done)begin if(g_error!=0)begin rsp_error<=g_error;state<=RESPONSE;end else state<=run_post?P_START:RESPONSE;end
   P_START:if(p_ready)state<=P_WAIT;
   P_WAIT:if(p_valid)begin rsp_error<=p_seq==rsp_seq?p_error:8'd6;state<=RESPONSE;end
   RESPONSE:if(rsp_ready)state<=IDLE;
   default:begin rsp_error<=255;state<=RESPONSE;end
  endcase
 end
endmodule
