`timescale 1ns/1ps
// Registered accepted operands split BRAM/mux routing from DSP MAC input.
// One accepted beat per cycle; final pending beat blocks the next group.
module qwen_mac8_pipeline_v1 (
 input wire clk,input wire rst,input wire mode_i16,
 input wire in_valid,output wire in_ready,
 input wire signed [15:0] activation,input wire [127:0] weight_data,
 input wire in_last,output reg out_valid,input wire out_ready,
 output wire [383:0] group_acc
);
 reg pipe_valid,pipe_last;
 (* EXTRACT_ENABLE="NO" *) reg signed [24:0] activation_reg;
 // Cached next-state predicate equals the original ready after every edge.
 // Keep the immediate reset gate; do not add a transaction/pipeline cycle.
 reg ready_without_reset;
 wire accept=in_valid && in_ready;
 wire retire=out_valid && out_ready;

 function predicted_ready;
 input old_out,old_last,old_valid,accepting,last,retiring;
 reg next_out,next_last;
 begin
  next_out=old_out;next_last=old_last;
  if(accepting)next_last=last;
  if(retiring)next_out=0;
  if(old_valid&&old_last)next_out=1;
  predicted_ready=!next_out&&!(accepting&&next_last);
 end endfunction
 always @(posedge clk)begin
  if(rst)ready_without_reset<=1;
  else ready_without_reset<=predicted_ready(out_valid,pipe_last,pipe_valid,accept,in_last,retire);
 end
 assign in_ready=!rst && ready_without_reset;
 always @(posedge clk) begin
  if(rst) begin pipe_valid<=0;pipe_last<=0;out_valid<=0;end
  else begin
   pipe_valid<=accept;
   if(accept) begin
    activation_reg<={{9{activation[15]}},activation};
    pipe_last<=in_last;
   end
   if(retire) out_valid<=0;
   if(pipe_valid && pipe_last) out_valid<=1;
  end
 end
 genvar lane;
 generate for(lane=0;lane<8;lane=lane+1) begin: pe
  wire signed [3:0] w4=weight_data[lane*4+:4];
  wire signed [15:0] w16=weight_data[lane*16+:16];
  (* EXTRACT_ENABLE="NO" *) reg signed [17:0] weight_reg;
  (* use_dsp="yes" *) reg signed [47:0] acc;
  always @(posedge clk) begin
   if(accept) weight_reg<=mode_i16 ? {{2{w16[15]}},w16} : {{14{w4[3]}},w4};
   if(rst || retire) acc<=48'sd0;
   else if(pipe_valid) acc<=acc+activation_reg*weight_reg;
  end
  assign group_acc[lane*48+:48]=acc;
 end endgenerate
endmodule
