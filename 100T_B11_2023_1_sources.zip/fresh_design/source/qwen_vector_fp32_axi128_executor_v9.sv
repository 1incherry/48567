`default_nettype none
// Candidate cacheless AXI frame executor for the six selected FP32 operators.
// Full input capture permits in-place output and ordered FP32 reductions.
// Uses the unchanged qualified operator bodies; this wrapper needs independent
// integration qualification before it can count as model or speed evidence.
module qwen_vector_fp32_axi128_executor_v9 #(
 parameter [31:0] DDR_BASE=32'h80000000,
 parameter [32:0] DDR_BYTES=33'h010000000,
 parameter MAX_ELEMENTS=4864
)(
 input wire clk,rst_n,cmd_valid,output wire cmd_ready,
 input wire [3:0] cmd_op,input wire [12:0] cmd_rows,cmd_padding,
 input wire [15:0] cmd_seq,
 input wire [31:0] cmd_source_base,cmd_auxiliary_base,cmd_output_base,
 output wire rsp_valid,input wire rsp_ready,output reg [15:0] rsp_seq,
 output reg [7:0] rsp_error,output reg [31:0] rsp_quant_scale,
 output wire [287:0] diagnostic_state,
 output wire busy,output reg [31:0] cycle_count,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output reg [127:0] m_axi_wdata,output reg [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 localparam IDLE=0,RA=1,RD=2,FEED=3,DRAIN=4,WA=5,WD=6,WB=7,RESPONSE=8,WARM=9,FETCH=10,WRITE_FETCH=11,READ_ADDR=12,READ_LIMIT=13,WRITE_ADDR=14,WRITE_LIMIT=15,CAPTURE=16,READ_FINISH=17,VALIDATE=18;
 localparam NORM=1,QUANT=2,ROPE=6,SOFTMAX=9,RESIDUAL=11,SILU=12;
 reg [4:0] state;(* MAX_FANOUT=16 *) reg [3:0] op;
 reg decoded_norm,decoded_quant,decoded_rope,decoded_softmax,decoded_residual,decoded_silu;
 reg [2:0] warm_cycles;
 reg [12:0] rows,padding,auxiliary_rows,read_word,read_total,feed_index,seen,write_word,write_total,write_stop;
 reg [8:0] burst_length,burst_received;
 reg [8:0] burst_terminal;
 reg finish_read_fault,finish_read_more;
 reg command_basic_bad;
 reg [32:0] accepted_source_end,accepted_float_end,accepted_quant_end;
 reg [32:0] accepted_auxiliary_end,accepted_rope_end;
 reg [32:0] accepted_output_fallback,accepted_auxiliary_fallback;
 reg [32:0] validation_output_end,validation_auxiliary_end;
 always @* begin
  case(op==QUANT)
   1'b0:validation_output_end=accepted_float_end;
   1'b1:validation_output_end=accepted_quant_end;
   default:validation_output_end=accepted_output_fallback;
  endcase
  case(op==ROPE)
   1'b0:validation_auxiliary_end=accepted_auxiliary_end;
   1'b1:validation_auxiliary_end=accepted_rope_end;
   default:validation_auxiliary_end=accepted_auxiliary_fallback;
  endcase
 end
 // No add/compare cascade in the accepted RLAST -> progress path.
 function automatic burst_is_last(input [8:0] received,length,terminal);
  begin
   case(^{received,length,terminal})
    1'b0,1'b1:burst_is_last=(length!=0)?(received==terminal):(received+1==length);
    default:burst_is_last=(received+1==length);
   endcase
  end
 endfunction
 wire expected_read_last=burst_is_last(burst_received,burst_length,burst_terminal);
 reg [15:0] prepared_write_strobe;
 function automatic [12:0] advance_output(input [12:0] v,step);
  reg [12:0] result;
  begin
   case(^{v,step})
    1'b0,1'b1:begin
     case(step)
      13'd1:begin
       result[0]=~v[0];
       for(integer k=1;k<13;k=k+1)result[k]=v[k] ^ ((v & ((13'd1<<k)-1))==((13'd1<<k)-1));
       advance_output=result;
      end
      13'd2:begin
       result[0]=v[0];result[1]=~v[1];
       for(integer k=2;k<13;k=k+1)result[k]=v[k] ^ ((v[12:1] & ((12'd1<<(k-1))-1))==((12'd1<<(k-1))-1));
       advance_output=result;
      end
      default:advance_output=v+step;
     endcase
    end
    default:advance_output=v+step;
   endcase
  end
 endfunction
 // Known binary controls use a flat priority mask. Unknown controls/values
 // retain the original ternary merge, including all X/Z cases.
 function automatic choose_bool(input [4:0] d,input [5:0] v);
  reg [5:0] pick;
  begin
   case(^{d,v})
    1'b0,1'b1:begin
     pick[0]=d[0];pick[1]=!d[0]&&d[1];pick[2]=!(|d[1:0])&&d[2];
     pick[3]=!(|d[2:0])&&d[3];pick[4]=!(|d[3:0])&&d[4];pick[5]=!(|d);
     choose_bool=|(pick&v);
    end
    default:choose_bool=d[0]?v[0]:d[1]?v[1]:d[2]?v[2]:d[3]?v[3]:d[4]?v[4]:v[5];
   endcase
  end
 endfunction
 // Command-invariant priority terms are captured on the original accept edge.
 reg [5:0] operator_pick,error_pick;
 function automatic [5:0] priority_pick(input [4:0] d);
  begin
   priority_pick[0]=d[0];priority_pick[1]=!d[0]&&d[1];
   priority_pick[2]=!(|d[1:0])&&d[2];priority_pick[3]=!(|d[2:0])&&d[3];
   priority_pick[4]=!(|d[3:0])&&d[4];priority_pick[5]=!(|d);
  end
 endfunction
 function automatic choose_cached_bool(input [4:0] d,input [5:0] v,pick);
  begin
   case(^{d,v,pick})
    1'b0,1'b1:choose_cached_bool=|(pick&v);
    default:choose_cached_bool=choose_bool(d,v);
   endcase
  end
 endfunction
 wire [4:0] control_priority={decoded_residual,decoded_softmax,decoded_rope,decoded_quant,decoded_norm};
 reg [31:0] source_base,auxiliary_base,output_base;
 // Address and burst payload registers stay unknown until prepared.
 // VALID is asserted only after both stages, including under AXI stalls.
 reg [31:0] read_address,write_address;
 reg [8:0] read_burst_registered,write_burst_registered;
 reg auxiliary_phase,read_bad;
 wire needs_auxiliary=op!=QUANT;
 wire [32:0] window_end={1'b0,DDR_BASE}+DDR_BYTES;
 wire [31:0] read_base=auxiliary_phase?auxiliary_base:source_base;
 wire [12:0] read_elements=auxiliary_phase?auxiliary_rows:rows;
 wire [12:0] feed_length=decoded_rope?(rows>>1):rows;
 // These command-invariant decoded operands avoid an opcode mux on every result.
 reg [12:0] output_length,output_step;
 reg [12:0] output_next_index;
 // The original + unsized 1 produces 32 bits, including 8191 -> 8192.
 // Preserve that width and all-unknown arithmetic while keeping the carry
 // independent of the result guard feeding the write counter data mux.
 function automatic [31:0] next_word(input [12:0] v);
  begin
   case(^v)
    1'b0,1'b1: begin
     next_word[31:14]=0;
     next_word[13]=&v;
     next_word[0]=~v[0];
     next_word[1]=v[1] ^ (&v[0:0]);
     next_word[2]=v[2] ^ (&v[1:0]);
     next_word[3]=v[3] ^ (&v[2:0]);
     next_word[4]=v[4] ^ (&v[3:0]);
     next_word[5]=v[5] ^ (&v[4:0]);
     next_word[6]=v[6] ^ (&v[5:0]);
     next_word[7]=v[7] ^ (&v[6:0]);
     next_word[8]=v[8] ^ (&v[7:0]);
     next_word[9]=v[9] ^ (&v[8:0]);
     next_word[10]=v[10] ^ (&v[9:0]);
     next_word[11]=v[11] ^ (&v[10:0]);
     next_word[12]=v[12] ^ (&v[11:0]);
    end
    default: next_word=32'bx;
   endcase
  end
 endfunction
 wire [31:0] read_word_next=next_word(read_word),write_word_next=next_word(write_word);
 reg [12:0] auxiliary_read_total,output_word_total;

 wire [12:0] read_remaining=read_total-read_word,write_remaining=write_total-write_word;
 assign m_axi_araddr=read_address;
 assign m_axi_awaddr=write_address;
 wire [8:0] read_page=(13'd4096-{1'b0,m_axi_araddr[11:0]})>>4;
 wire [8:0] write_page=(13'd4096-{1'b0,m_axi_awaddr[11:0]})>>4;
 wire [8:0] read_burst=read_remaining>255?(read_page<255?read_page:9'd255):(read_remaining<read_page?read_remaining[8:0]:read_page);
 wire [8:0] write_burst=write_remaining>255?(write_page<255?write_page:9'd255):(write_remaining<write_page?write_remaining[8:0]:write_page);
 assign cmd_ready=rst_n&&state==IDLE;assign rsp_valid=rst_n&&state==RESPONSE;
 assign busy=state!=IDLE&&state!=RESPONSE;
 assign m_axi_arvalid=rst_n&&state==RA;assign m_axi_rready=rst_n&&state==RD;
 assign m_axi_arlen=read_burst_registered-1;assign m_axi_arsize=4;assign m_axi_arburst=1;
 assign m_axi_awvalid=rst_n&&state==WA;assign m_axi_awlen=write_burst_registered-1;
 assign m_axi_awsize=4;assign m_axi_awburst=1;
 assign m_axi_wvalid=rst_n&&state==WD;assign m_axi_wlast=write_word_next==write_stop;
 assign m_axi_bready=rst_n&&state==WB;
 wire active=rst_n&&(state==FETCH||state==CAPTURE||state==FEED||state==DRAIN);
 // Release vendor synchronous resets before asserting any operand valid.
 // Each operator reset comes directly from a clocked register. The global
 // reset asserts asynchronously; opcode/state changes are sampled on clk.
 // WARM still provides four clocks before any operand VALID is asserted.
 reg [5:0] operator_resetn_reg;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)operator_resetn_reg<=6'b0;
  else operator_resetn_reg<={
   (state!=IDLE&&state!=RESPONSE&&decoded_silu),
   (state!=IDLE&&state!=RESPONSE&&decoded_residual),
   (state!=IDLE&&state!=RESPONSE&&decoded_softmax),
   (state!=IDLE&&state!=RESPONSE&&decoded_rope),
   (state!=IDLE&&state!=RESPONSE&&decoded_quant),
   (state!=IDLE&&state!=RESPONSE&&decoded_norm)};
 end
 wire input_valid=state==FEED;
 wire input_last=feed_index+1==feed_length;
 wire [12:0] rope_input_index={feed_index[12:5],6'b0}+{8'b0,feed_index[4:0]};
 wire [12:0] rope_output_index={seen[12:6],6'b0}+{8'b0,seen[5:1]};
 reg [31:0] x_feed,x_rope_b,b_feed,b_rope_s;
 wire [31:0] x_raw,xb_raw,b_raw,bs_raw;
 wire [31:0] result_read[0:7];wire [12:0] output_first;
 wire [223:0] norm_diagnostic_state;
 wire nr,nv,nlast,nerror;wire [31:0] ny;wire [15:0] ntag;
 qwen_rmsnorm_fp32_frame_bram_v2 norm(.clk,.rst_n(operator_resetn_reg[0]),
  .in_valid(input_valid&&decoded_norm),.in_ready(nr),.x_fp32(x_feed),.gamma_fp32(b_feed),
  .in_last(input_last),.in_tag(rsp_seq),.out_valid(nv),.out_ready(1'b1),.result_fp32(ny),.out_last(nlast),.out_tag(ntag),.protocol_error(nerror),.diagnostic_state(norm_diagnostic_state));
 assign diagnostic_state[31:0]={12'd0,state[4],operator_resetn_reg,warm_cycles,auxiliary_phase,read_bad,op,state[3:0]};
 assign diagnostic_state[63:32]={3'd0,seen,3'd0,feed_index};
 assign diagnostic_state[287:64]=norm_diagnostic_state;
 wire qr,qv,qlast,qprotocol,qdomain;wire signed [15:0] qy;wire [15:0] qtag;wire [31:0] qscale;
 qwen_quant_fp32_frame_bram_v3 #(.MAX_ELEMENTS(MAX_ELEMENTS)) quant(.clk,.rst_n(operator_resetn_reg[1]),
  .in_valid(input_valid&&decoded_quant),.in_ready(qr),.x_fp32(x_feed),.in_length(rows),.in_padding(padding),
  .in_last(input_last),.in_tag(rsp_seq),.out_valid(qv),.out_ready(1'b1),.result_i16(qy),.out_last(qlast),.out_tag(qtag),.scale_fp32(qscale),.protocol_error(qprotocol),.domain_error(qdomain));
 wire rr,rv,rlast;wire [31:0] rya,ryb;wire [15:0] rtag;
 qwen_rope_fp32_pair_stream rope(.clk,.rst_n(operator_resetn_reg[2]),
  .in_valid(input_valid&&decoded_rope),.in_ready(rr),.a_fp32(x_feed),.b_fp32(x_rope_b),
  .cos_fp32(b_feed),.sin_fp32(b_rope_s),
  .in_last(input_last),.in_tag(rsp_seq),.out_valid(rv),.out_ready(1'b1),.result_a_fp32(rya),.result_b_fp32(ryb),.out_last(rlast),.out_tag(rtag));
 wire sr,sv,slast,sprotocol,sdomain;wire [31:0] sy;wire [15:0] stag;
 qwen_softmax_fp32_frame_bram_v2 softmax(.clk,.rst_n(operator_resetn_reg[3]),
  .in_valid(input_valid&&decoded_softmax),.in_ready(sr),.score_fp32(x_feed),.value_scale_fp32(b_feed),.in_length(rows[9:0]),
  .in_last(input_last),.in_tag(rsp_seq),.out_valid(sv),.out_ready(1'b1),.result_fp32(sy),.out_last(slast),.out_tag(stag),.protocol_error(sprotocol),.domain_error(sdomain));
 wire ar,av,alast,aerror;wire [31:0] ay;wire [15:0] atag;
 qwen_postprocess_fp32_stream #(.TAG_WIDTH(16)) residual(.clk,.rst_n(operator_resetn_reg[4]),
  .in_valid(input_valid&&decoded_residual),.in_ready(ar),.in_mode(3'd0),.x_fp32(x_feed),.a_fp32(b_feed),.b_fp32(32'd0),.c_fp32(32'd0),
  .in_last(input_last),.in_tag(rsp_seq),.out_valid(av),.out_ready(1'b1),.result_fp32(ay),.out_last(alast),.out_tag(atag),.out_error(aerror));
 wire lr,lv,llast;wire [31:0] ly;wire [15:0] ltag;
 qwen_silu_fp32_stream silu(.clk,.rst_n(operator_resetn_reg[5]),
  .in_valid(input_valid&&decoded_silu),.in_ready(lr),.gate_fp32(x_feed),.up_fp32(b_feed),
  .in_last(input_last),.in_tag(rsp_seq),.out_valid(lv),.out_ready(1'b1),.result_fp32(ly),.out_last(llast),.out_tag(ltag));
 wire selected_ready=choose_cached_bool(control_priority,{lr,ar,sr,rr,qr,nr},operator_pick);
 wire selected_valid=choose_cached_bool(control_priority,{lv,av,sv,rv,qv,nv},operator_pick);
 wire selected_last=choose_cached_bool(control_priority,{llast,alast,slast,rlast,qlast,nlast},operator_pick);
 wire [15:0] selected_tag=decoded_norm?ntag:decoded_quant?qtag:decoded_rope?rtag:decoded_softmax?stag:decoded_residual?atag:ltag;
 wire [31:0] selected_value=decoded_norm?ny:decoded_quant?{16'd0,qy}:decoded_rope?rya:decoded_softmax?sy:decoded_residual?ay:ly;
 wire selected_error=choose_cached_bool({decoded_residual,decoded_softmax,1'b0,decoded_quant,decoded_norm},{1'b0,aerror,(sprotocol||sdomain),1'b0,(qprotocol||qdomain),nerror},error_pick);

 reg current_bad;integer lane,index;
 always @* begin
  current_bad=0;
  for(integer j=0;j<4;j=j+1)
   if(read_word*4+j<read_elements&&(m_axi_rdata[j*32+23 +:8]==255||(m_axi_rdata[j*32+23 +:8]==0&&m_axi_rdata[j*32 +:23]!=0)))current_bad=1;
 end
 always @* begin
  m_axi_wdata=0;m_axi_wstrb=0;
  if(decoded_quant)begin
   for(integer j=0;j<8;j=j+1)if(prepared_write_strobe[j*2 +:2]==2'b11)begin
    m_axi_wdata[j*16 +:16]=result_read[j][15:0];m_axi_wstrb[j*2 +:2]=2'b11;
   end
  end else begin
   for(integer j=0;j<4;j=j+1)if(prepared_write_strobe[j*4 +:4]==4'hf)begin
    m_axi_wdata[j*32 +:32]=result_read[(output_first+j)&7];m_axi_wstrb[j*4 +:4]=4'hf;
   end
  end
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   burst_terminal<=0;finish_read_fault<=0;finish_read_more<=0;command_basic_bad<=0;
   accepted_output_fallback<=0;accepted_auxiliary_fallback<=0;accepted_source_end<=0;accepted_float_end<=0;accepted_quant_end<=0;accepted_auxiliary_end<=0;accepted_rope_end<=0;prepared_write_strobe<=0;
   output_length<=0;output_step<=1;output_next_index<=1;auxiliary_read_total<=0;output_word_total<=0;
   operator_pick<=6'b100000;error_pick<=6'b100000;state<=IDLE;warm_cycles<=0;op<=0;decoded_norm<=(4'd0==NORM);decoded_quant<=(4'd0==QUANT);decoded_rope<=(4'd0==ROPE);decoded_softmax<=(4'd0==SOFTMAX);decoded_residual<=(4'd0==RESIDUAL);decoded_silu<=(4'd0==SILU);rows<=0;padding<=0;auxiliary_rows<=0;source_base<=0;auxiliary_base<=0;output_base<=0;
   rsp_seq<=0;rsp_error<=0;rsp_quant_scale<=0;cycle_count<=0;auxiliary_phase<=0;read_bad<=0;
   read_word<=0;read_total<=0;burst_length<=0;burst_received<=0;feed_index<=0;seen<=0;write_word<=0;write_total<=0;write_stop<=0;
  end else begin
   if(busy)cycle_count<=cycle_count+1;
   case(state)
    IDLE:if(cmd_valid&&cmd_ready)begin
     output_length<=cmd_op==QUANT?cmd_padding:cmd_rows;
     auxiliary_read_total<=((cmd_op==ROPE?13'd64:cmd_rows)+3)>>2;
     output_word_total<=cmd_op==QUANT?(cmd_padding+7)>>3:(cmd_rows+3)>>2;
     output_step<=cmd_op==ROPE?13'd2:13'd1;
     operator_pick<=priority_pick({cmd_op==RESIDUAL,cmd_op==SOFTMAX,cmd_op==ROPE,cmd_op==QUANT,cmd_op==NORM});error_pick<=priority_pick({cmd_op==RESIDUAL,cmd_op==SOFTMAX,1'b0,cmd_op==QUANT,cmd_op==NORM});op<=cmd_op;decoded_norm<=(cmd_op==NORM);decoded_quant<=(cmd_op==QUANT);decoded_rope<=(cmd_op==ROPE);decoded_softmax<=(cmd_op==SOFTMAX);decoded_residual<=(cmd_op==RESIDUAL);decoded_silu<=(cmd_op==SILU);rows<=cmd_rows;padding<=cmd_padding;auxiliary_rows<=cmd_op==ROPE?13'd64:cmd_rows;
     source_base<=cmd_source_base;auxiliary_base<=cmd_auxiliary_base;output_base<=cmd_output_base;
     rsp_seq<=cmd_seq;rsp_error<=0;rsp_quant_scale<=0;cycle_count<=0;auxiliary_phase<=0;read_bad<=0;read_word<=0;read_total<=(cmd_rows+3)>>2;
     command_basic_bad<=((cmd_op!=NORM&&cmd_op!=QUANT&&cmd_op!=ROPE&&cmd_op!=SOFTMAX&&cmd_op!=RESIDUAL&&cmd_op!=SILU)||
       cmd_rows==0||cmd_rows>MAX_ELEMENTS||(cmd_op==NORM&&cmd_rows!=896)||(cmd_op==ROPE&&cmd_rows[5:0]!=0)||
       (cmd_op==SOFTMAX&&cmd_rows>512)||(cmd_op==QUANT&&(cmd_padding<cmd_rows||cmd_padding>MAX_ELEMENTS))||
       cmd_source_base[3:0]!=0||cmd_output_base[3:0]!=0||(cmd_op!=QUANT&&cmd_auxiliary_base[3:0]!=0));
     accepted_output_fallback<={1'b0,cmd_output_base}+(cmd_op==QUANT?({20'd0,cmd_padding}<<1):({20'd0,cmd_rows}<<2));
     accepted_auxiliary_fallback<={1'b0,cmd_auxiliary_base}+(cmd_op==ROPE?33'd256:({20'd0,cmd_rows}<<2));
     accepted_source_end<={1'b0,cmd_source_base}+({20'd0,cmd_rows}<<2);
     accepted_float_end<={1'b0,cmd_output_base}+({20'd0,cmd_rows}<<2);
     accepted_quant_end<={1'b0,cmd_output_base}+({20'd0,cmd_padding}<<1);
     accepted_auxiliary_end<={1'b0,cmd_auxiliary_base}+({20'd0,cmd_rows}<<2);
     accepted_rope_end<={1'b0,cmd_auxiliary_base}+33'd256;
     state<=VALIDATE;
    end
    VALIDATE:begin
     if(command_basic_bad||
       {1'b0,source_base}<{1'b0,DDR_BASE}||accepted_source_end>window_end||
       {1'b0,output_base}<{1'b0,DDR_BASE}||validation_output_end>window_end||
       (op!=QUANT&&({1'b0,auxiliary_base}<{1'b0,DDR_BASE}||validation_auxiliary_end>window_end)))
      begin rsp_error<=1;state<=RESPONSE;end
     else state<=READ_ADDR;
    end
    READ_ADDR:begin read_address<=read_base+({19'b0,read_word}<<4);state<=READ_LIMIT;end
    READ_LIMIT:begin read_burst_registered<=read_burst;state<=RA;end
    WRITE_ADDR:begin write_address<=output_base+({19'b0,write_word}<<4);state<=WRITE_LIMIT;end
    WRITE_LIMIT:begin write_burst_registered<=write_burst;state<=WA;end
    RA:if(m_axi_arvalid&&m_axi_arready)begin burst_length<=read_burst_registered;burst_terminal<=read_burst_registered-9'd1;burst_received<=0;state<=RD;end
    RD:if(m_axi_rvalid&&m_axi_rready)begin
     if(m_axi_rresp!=0)begin read_bad<=1;rsp_error<=2;end
     if(m_axi_rlast!=expected_read_last)begin read_bad<=1;rsp_error<=3;end
     if(current_bad)begin read_bad<=1;rsp_error<=7;end
     read_word<=read_word_next;burst_received<=burst_received+1;
     if(m_axi_rlast)begin
      finish_read_fault<=read_bad||current_bad||m_axi_rresp!=0||!expected_read_last;
      finish_read_more<=(read_word_next<read_total);
      state<=READ_FINISH;
     end
    end
    READ_FINISH:begin
     if(finish_read_fault)state<=RESPONSE;
     else if(finish_read_more)state<=READ_ADDR;
     else if(!auxiliary_phase&&needs_auxiliary)begin auxiliary_phase<=1;read_word<=0;read_total<=auxiliary_read_total;state<=READ_ADDR;end
     else begin feed_index<=0;seen<=0;output_next_index<=13'd0+output_step;warm_cycles<=0;state<=WARM;end
    end
    WARM:begin if(warm_cycles==3)state<=FETCH;else warm_cycles<=warm_cycles+1;end
    FETCH:state<=CAPTURE;
    CAPTURE:state<=FEED;
    FEED:if(input_valid&&selected_ready)begin feed_index<=feed_index+1;if(input_last)state<=DRAIN;else state<=FETCH;end
    DRAIN:begin end
    WA:if(m_axi_awvalid&&m_axi_awready)begin write_stop<=write_word+write_burst_registered;state<=WRITE_FETCH;end
    WRITE_FETCH:begin
     prepared_write_strobe<=0;
     if(decoded_quant)begin
      for(integer j=0;j<8;j=j+1)if(write_word*8+j<output_length)prepared_write_strobe[j*2 +:2]<=2'b11;
     end else begin
      for(integer j=0;j<4;j=j+1)if(write_word*4+j<output_length)prepared_write_strobe[j*4 +:4]<=4'hf;
     end
     state<=WD;
    end
    WD:if(m_axi_wvalid&&m_axi_wready)begin write_word<=write_word_next;if(m_axi_wlast)state<=WB;else state<=WRITE_FETCH;end
    WB:if(m_axi_bvalid&&m_axi_bready)begin
     if(m_axi_bresp!=0)begin rsp_error<=4;state<=RESPONSE;end
     else if(write_word<write_total)state<=WRITE_ADDR;else state<=RESPONSE;
    end
    RESPONSE:if(rsp_ready)state<=IDLE;
    default:begin rsp_error<=255;state<=RESPONSE;end
   endcase
   if(active&&selected_error)begin rsp_error<=7;state<=RESPONSE;end
   else if(active&&selected_valid)begin
    if(seen>=output_length||selected_tag!=rsp_seq||selected_last!=(output_next_index==output_length))begin rsp_error<=5;state<=RESPONSE;end
    else begin
     seen<=output_next_index;output_next_index<=advance_output(output_next_index,output_step);
     if(decoded_quant)rsp_quant_scale<=qscale;
     if(selected_last)begin write_word<=0;write_total<=output_word_total;state<=WRITE_ADDR;end
    end
   end
  end
 end

 // Four lane banks preserve 128-bit capture. Registered dual-port reads
 // provide both RoPE halves without asynchronous RAM or four write ports.
 wire [12:0] xa=decoded_rope?rope_input_index:feed_index;
 wire [12:0] xb=rope_input_index+13'd32;
 wire [12:0] ba=decoded_rope?{7'd0,feed_index[4:0],1'b0}:feed_index;
 wire [12:0] bb={7'd0,feed_index[4:0],1'b0}+13'd1;
 wire [31:0] xr_a[0:3],xr_b[0:3],br_a[0:3],br_b[0:3];
 assign x_raw=xr_a[xa[1:0]];assign xb_raw=xr_b[xb[1:0]];
 assign b_raw=br_a[ba[1:0]];assign bs_raw=br_b[bb[1:0]];
 // Valid follows FETCH then this mux capture; stalled FEED keeps all operands.
 // Payload has no reset and stays X until an actual capture.
 always @(posedge clk)if(rst_n&&state==CAPTURE)begin
  x_feed<=x_raw;x_rope_b<=xb_raw;b_feed<=b_raw;b_rope_s<=bs_raw;
 end
 reg input_write_pending,input_aux_pending;
 reg [12:0] input_word_pending,input_elements_pending;
 reg [127:0] input_data_pending;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)input_write_pending<=0;
  else input_write_pending<=state==RD&&m_axi_rvalid&&m_axi_rready;
 end
 always @(posedge clk)if(rst_n&&state==RD&&m_axi_rvalid&&m_axi_rready)begin
  input_aux_pending<=auxiliary_phase;input_word_pending<=read_word;
  input_elements_pending<=read_elements;input_data_pending<=m_axi_rdata;
 end
 genvar ib;
 generate for(ib=0;ib<4;ib=ib+1)begin:input_banks
  wire xw=rst_n&&input_write_pending&&!input_aux_pending&&input_word_pending*4+ib<input_elements_pending;
  wire bw=rst_n&&input_write_pending&&input_aux_pending&&input_word_pending*4+ib<input_elements_pending;
  wire fetch=rst_n&&state==FETCH;
  qwen_tdp32_bram_v1 #(.WORDS((MAX_ELEMENTS+3)/4)) xb_ram(.clk,.ena(fetch),.wea(1'b0),.aa(xa>>2),.da(32'd0),.qa(xr_a[ib]),.enb(xw||fetch),.web(xw),.ab(xw?input_word_pending:xb>>2),.db(input_data_pending[ib*32+:32]),.qb(xr_b[ib]));
  qwen_tdp32_bram_v1 #(.WORDS((MAX_ELEMENTS+3)/4)) bb_ram(.clk,.ena(fetch),.wea(1'b0),.aa(ba>>2),.da(32'd0),.qa(br_a[ib]),.enb(bw||fetch),.web(bw),.ab(bw?input_word_pending:bb>>2),.db(input_data_pending[ib*32+:32]),.qb(br_b[ib]));
 end endgenerate
 // Eight output banks serve an I16 packed AXI beat, or four FP32 lanes.
 // RoPE writes two separated addresses in the same bank using both ports.
 wire result_store=active&&!selected_error&&selected_valid&&seen<output_length&&selected_tag==rsp_seq&&selected_last==(output_next_index==output_length);
 wire [12:0] result_a=decoded_rope?rope_output_index:seen;
 wire [12:0] result_b=rope_output_index+13'd32;
 // Capture the complete accepted output write before driving bank enables.
 // Only the valid bits reset. Payloads remain X until an actual operator output.
 reg result_pending,result_rope_pending;
 reg [12:0] result_a_pending,result_b_pending;
 reg [31:0] result_value_pending,result_pair_pending;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin result_pending<=0;result_rope_pending<=0;end
  else begin
   result_pending<=result_store;
   result_rope_pending<=result_store&&decoded_rope;
   if(result_store)begin
    result_a_pending<=result_a;result_b_pending<=result_b;
    result_value_pending<=selected_value;result_pair_pending<=ryb;
   end
  end
 end
 assign output_first=decoded_quant?(write_word<<3):(write_word<<2);
 genvar ob;
 generate for(ob=0;ob<8;ob=ob+1)begin:output_banks
  wire awrite=rst_n&&result_pending&&result_a_pending[2:0]==ob;
  wire bread=rst_n&&state==WRITE_FETCH;
  wire bwrite=rst_n&&result_rope_pending&&result_b_pending[2:0]==ob;
  wire [31:0] ignored_b;
  qwen_tdp32_bram_v1 #(.WORDS((MAX_ELEMENTS+7)/8)) yb_ram(.clk,.ena(awrite||bread),.wea(awrite),.aa(bread?output_first>>3:result_a_pending>>3),.da(result_value_pending),.qa(result_read[ob]),.enb(bwrite),.web(bwrite), .ab(result_b_pending>>3),.db(result_pair_pending),.qb(ignored_b));
 end endgenerate
endmodule

`default_nettype wire
