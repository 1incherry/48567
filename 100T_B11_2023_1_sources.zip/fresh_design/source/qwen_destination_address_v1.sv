// Two registered stages isolate scheduler decode from destination addition.
// offer stays asserted until take; ready marks a held, stable destination.
module qwen_destination_address_v1(input wire clk,rst_n,offer,take,
 input wire [31:0] base,offset,output wire ready,output reg [31:0] address);
 reg [1:0] state;reg [31:0] held_base,held_offset;
 assign ready=rst_n&&state==2;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=0;held_base<=0;held_offset<=0;address<=0;end
  else case(state)
   0:if(offer)begin held_base<=base;held_offset<=offset;state<=1;end
   1:begin address<=held_base+held_offset;state<=2;end
   2:if(take)state<=0;
   default:state<=0;
  endcase
 end
endmodule
