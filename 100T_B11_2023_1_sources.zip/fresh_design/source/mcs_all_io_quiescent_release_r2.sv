`timescale 1ns/1ps
// Track exact native requests until the selected peripheral's real IOReady.
// This state survives CPU-only reset; board reset is the only clearing reset.
// bridge_ready is emitted only after true downstream R/B consumption, so this
// includes the official converter/fabric queue lifetime for every control/DDR.
module mcs_all_io_quiescent_release_r2(input wire clk,board_reset_n,native_idle,
 input wire bridge_strobe,uart_strobe,read_strobe,write_strobe,
 input wire[31:0]address,data,input wire[3:0]byte_enable,
 input wire bridge_ready,uart_ready,
 output wire all_idle,release_quiet,release_owned,output reg release_completion_toggle);
 reg bridge_active,uart_active,release_self;
 // release_self is already a registered identity,not a live address decode.
 // Invariant:release_self -> bridge_active (identical reset/ready/strobe updates).
 // This flag therefore spans the entire real bridge/converter R/B lifetime.
 assign release_owned=release_self;
 wire current_release=address==32'hc1000034&&write_strobe&&!read_strobe&&data==2&&byte_enable==15;
 assign all_idle=board_reset_n&&native_idle&&!bridge_active&&!uart_active&&!bridge_strobe&&!uart_strobe&&!bridge_ready&&!uart_ready;
 assign release_quiet=all_idle||(board_reset_n&&bridge_active&&release_self&&!uart_active&&!uart_ready&&!uart_strobe&&!bridge_strobe);
 always@(posedge clk or negedge board_reset_n)
 if(!board_reset_n)begin release_completion_toggle<=0;bridge_active<=0;uart_active<=0;release_self<=0;end
 else begin
  if(bridge_ready)begin if(release_self)release_completion_toggle<=!release_completion_toggle;bridge_active<=0;release_self<=0;end
  if(uart_ready)uart_active<=0;
  if(bridge_strobe)begin bridge_active<=1;release_self<=current_release;end
  if(uart_strobe)uart_active<=1;
 end
endmodule
