// Original C: maximum, exp(score-maximum), ordered FP32 sum,
// then (exp/denominator)*per-token KV scale. Do not reorder reduction.
// Finite model trace qualification; complete IEEE subnormal domain is pending.
module qwen_softmax_fp32_frame_bram_v2 #(parameter MAX_LENGTH=512,TAG_WIDTH=16)(
 input wire clk,rst_n,in_valid,
 output wire in_ready,
 input wire [31:0] score_fp32,value_scale_fp32,
 input wire [9:0] in_length,
 input wire in_last,
 input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,
 input wire out_ready,
 output wire [31:0] result_fp32,
 output wire out_last,
 output wire [TAG_WIDTH-1:0] out_tag,
 output reg protocol_error,domain_error
);
 localparam CAPTURE=0,EXP_FEED=1,EXP_DRAIN=2,SUM=3,EMIT=4,DRAIN=5,REJECT=6;
 reg [2:0] state;
 integer input_count,length,feed_index,exp_count,sum_index,emit_index;
 reg [TAG_WIDTH-1:0] frame_tag;
 reg [31:0] maximum,denominator;
 (* ram_style="block" *) reg [31:0] score_mem[0:MAX_LENGTH-1];
 (* ram_style="block" *) reg [31:0] scale_mem[0:MAX_LENGTH-1];
 (* ram_style="block" *) reg [31:0] exp_mem[0:MAX_LENGTH-1];
 reg [31:0] score_rd,exp_rd,scale_rd;
 reg feed_valid,emit_valid,emit_last,sum_read,pending;
 wire ce=out_ready||!out_valid;
 // Payload registers are intentionally unreset. Validity masks all unwritten X.
 reg [31:0] captured_score,captured_scale;
 reg [9:0] captured_length;
 reg captured_last,captured_valid;
 reg [TAG_WIDTH-1:0] captured_tag;
 wire captured_bad_domain=captured_score[30:23]==255||captured_scale[30:23]==255||
   (captured_score[30:23]==0&&captured_score[22:0]!=0)||
   (captured_scale[30:23]==0&&captured_scale[22:0]!=0);
 wire capture_terminal=captured_valid&&(captured_last||captured_bad_domain||captured_length<1||captured_length>MAX_LENGTH);
 assign in_ready=rst_n&&ce&&state==CAPTURE&&!capture_terminal;
 wire capture_accept=in_valid&&in_ready;
 wire accept=captured_valid&&ce&&state==CAPTURE;
 always @(posedge clk)if(capture_accept)begin
  captured_score<=score_fp32;captured_scale<=value_scale_fp32;
  captured_length<=in_length;captured_last<=in_last;captured_tag<=in_tag;
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)captured_valid<=0;
  else if(ce)captured_valid<=capture_accept;
 end
 function automatic greater(input [31:0] a,b);
  begin
   if(a[30:0]==0&&b[30:0]==0)greater=0;
   else if(a[31]!=b[31])greater=!a[31];
   else greater=a[31]?(a[30:0]<b[30:0]):(a[30:0]>b[30:0]);
  end
 endfunction
 wire sub_valid;wire [31:0] sub_result;
 qwen_fp_add subtract_max(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(feed_valid),.s_axis_a_tdata(score_rd),
  .s_axis_b_tvalid(feed_valid),.s_axis_b_tdata({!maximum[31],maximum[30:0]}),
  .m_axis_result_tvalid(sub_valid),.m_axis_result_tdata(sub_result));
 wire exp_valid;wire [31:0] exp_result;
 qwen_exp_fp32_pipeline exp_pipeline(.clk,.rst_n,.ce,.in_valid(sub_valid),
  .x_fp32(sub_result),.out_valid(exp_valid),.result_fp32(exp_result));
 wire sum_issue=state==SUM&&sum_read&&!pending;
 wire sum_valid;wire [31:0] sum_result;
 qwen_fp_add ordered_sum(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(sum_issue),.s_axis_a_tdata(denominator),
  .s_axis_b_tvalid(sum_issue),.s_axis_b_tdata(exp_rd),
  .m_axis_result_tvalid(sum_valid),.m_axis_result_tdata(sum_result));
 wire div_valid;wire [31:0] div_result,scale_aligned;
 qwen_fp_div probability_divide(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(emit_valid),.s_axis_a_tdata(exp_rd),
  .s_axis_b_tvalid(emit_valid),.s_axis_b_tdata(denominator),
  .m_axis_result_tvalid(div_valid),.m_axis_result_tdata(div_result));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(28)) scale_delay(.clk,.rst_n,.ce,.din(scale_rd),.dout(scale_aligned));
 qwen_fp_mul scale_probability(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(div_valid),.s_axis_a_tdata(div_result),
  .s_axis_b_tvalid(div_valid),.s_axis_b_tdata(scale_aligned),
  .m_axis_result_tvalid(out_valid),.m_axis_result_tdata(result_fp32));
 qwen_ce_delay #(.WIDTH(1),.DEPTH(36)) last_delay(.clk,.rst_n,.ce,.din(emit_last),.dout(out_last));
 assign out_tag=frame_tag;
 // Separate synchronous RAM ports preserve the original edge/enable schedule.
 // Unwritten RAM/read registers remain X; only resettable validity controls are reset.
 always @(posedge clk)begin
  if(rst_n&&accept)begin score_mem[input_count]<=captured_score;scale_mem[input_count]<=captured_scale;end
  if(rst_n&&ce&&exp_valid)exp_mem[exp_count]<=exp_result;
  if(rst_n&&ce&&state==EXP_FEED)score_rd<=score_mem[feed_index];
  if(rst_n&&ce&&((state==SUM&&!sum_read&&!pending)||state==EMIT))
   exp_rd<=exp_mem[state==SUM?sum_index:emit_index];
  if(rst_n&&ce&&state==EMIT)scale_rd<=scale_mem[emit_index];
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=CAPTURE;input_count<=0;length<=0;feed_index<=0;exp_count<=0;sum_index<=0;emit_index<=0;
   frame_tag<=0;maximum<=0;denominator<=0;
   feed_valid<=0;emit_valid<=0;emit_last<=0;sum_read<=0;pending<=0;protocol_error<=0;domain_error<=0;
  end else if(ce)begin
   feed_valid<=0;emit_valid<=0;emit_last<=0;
   if(accept)begin
    if(input_count==0)begin
     length<=captured_length;frame_tag<=captured_tag;maximum<=captured_score;
     if(captured_length<1||captured_length>MAX_LENGTH)begin protocol_error<=1;state<=REJECT;end
    end else begin
     if(greater(captured_score,maximum))maximum<=captured_score;
     if(captured_length!=length||captured_tag!==frame_tag)protocol_error<=1;
    end
    if(captured_last!==(input_count==(input_count==0?captured_length:length)-1))protocol_error<=1;
    if(captured_score[30:23]==255||captured_scale[30:23]==255||
       (captured_score[30:23]==0&&captured_score[22:0]!=0)||
       (captured_scale[30:23]==0&&captured_scale[22:0]!=0))begin domain_error<=1;state<=REJECT;end
    else if(captured_last&&captured_length>=1&&captured_length<=MAX_LENGTH)begin
     state<=EXP_FEED;feed_index<=0;exp_count<=0;input_count<=0;
    end else input_count<=input_count+1;
   end
   if(exp_valid)begin
    if(exp_count==length-1)begin state<=SUM;denominator<=0;sum_index<=0;sum_read<=0;pending<=0;end
    else exp_count<=exp_count+1;
   end
   case(state)
    EXP_FEED:begin
     feed_valid<=1;
     if(feed_index==length-1)state<=EXP_DRAIN;
     else feed_index<=feed_index+1;
    end
    SUM:begin
     if(!sum_read&&!pending)begin sum_read<=1;end
     if(sum_issue)begin pending<=1;sum_read<=0;end
     if(sum_valid)begin
      denominator<=sum_result;pending<=0;
      if(sum_index==length-1)begin state<=EMIT;emit_index<=0;end
      else sum_index<=sum_index+1;
     end
    end
    EMIT:begin
     emit_valid<=1;emit_last<=emit_index==length-1;
     if(emit_index==length-1)state<=DRAIN;
     else emit_index<=emit_index+1;
    end
    DRAIN:if(out_valid&&out_ready&&out_last)begin state<=CAPTURE;input_count<=0;end
    default:begin end
   endcase
  end
 end
endmodule
