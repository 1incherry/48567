// Delay sidebands and operands by exactly the arithmetic pipeline's enabled clocks.
module qwen_ce_delay #(parameter WIDTH=32,DEPTH=1)(
 input wire clk,rst_n,ce,
 input wire [WIDTH-1:0] din,
 output wire [WIDTH-1:0] dout
);
 reg [WIDTH-1:0] data [0:DEPTH-1];integer i;
 assign dout=data[DEPTH-1];
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)for(i=0;i<DEPTH;i=i+1)data[i]<=0;
  else if(ce)begin
   data[0]<=din;for(i=1;i<DEPTH;i=i+1)data[i]<=data[i-1];
  end
 end
endmodule
