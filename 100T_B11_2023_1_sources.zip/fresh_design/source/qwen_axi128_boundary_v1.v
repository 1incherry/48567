// Registered two-slot AXI4 boundary; preserves payload X/Z and independent channel order.
module qwen_axi128_boundary_v1 #(parameter READY_CONTAINS_ARESETN=0)(
 (* X_INTERFACE_INFO="xilinx.com:signal:clock:1.0 aclk CLK", X_INTERFACE_PARAMETER="XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF S_AXI:M_AXI, ASSOCIATED_RESET aresetn, FREQ_HZ 125000000" *) input wire aclk,
 (* X_INTERFACE_INFO="xilinx.com:signal:reset:1.0 aresetn RST", X_INTERFACE_PARAMETER="XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW" *) input wire aresetn,
 input wire engine_ready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWADDR", X_INTERFACE_PARAMETER="XIL_INTERFACENAME S_AXI, PROTOCOL AXI4, DATA_WIDTH 128, ADDR_WIDTH 32, ID_WIDTH 0, HAS_BURST 1, HAS_RRESP 1, HAS_BRESP 1" *) input wire [31:0] s_axi_awaddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWLEN" *) input wire [7:0] s_axi_awlen,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWSIZE" *) input wire [2:0] s_axi_awsize,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWBURST" *) input wire [1:0] s_axi_awburst,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWVALID" *) input wire s_axi_awvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWREADY" *) output wire s_axi_awready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WDATA" *) input wire [127:0] s_axi_wdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WSTRB" *) input wire [15:0] s_axi_wstrb,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WLAST" *) input wire s_axi_wlast,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WVALID" *) input wire s_axi_wvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WREADY" *) output wire s_axi_wready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARADDR" *) input wire [31:0] s_axi_araddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARLEN" *) input wire [7:0] s_axi_arlen,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARSIZE" *) input wire [2:0] s_axi_arsize,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARBURST" *) input wire [1:0] s_axi_arburst,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARVALID" *) input wire s_axi_arvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARREADY" *) output wire s_axi_arready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RDATA" *) output wire [127:0] s_axi_rdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RRESP" *) output wire [1:0] s_axi_rresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RLAST" *) output wire s_axi_rlast,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RVALID" *) output wire s_axi_rvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RREADY" *) input wire s_axi_rready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI BRESP" *) output wire [1:0] s_axi_bresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI BVALID" *) output wire s_axi_bvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI BREADY" *) input wire s_axi_bready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWADDR", X_INTERFACE_PARAMETER="XIL_INTERFACENAME M_AXI, PROTOCOL AXI4, DATA_WIDTH 128, ADDR_WIDTH 32, ID_WIDTH 0, HAS_BURST 1, HAS_RRESP 1, HAS_BRESP 1" *) output wire [31:0] m_axi_awaddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWLEN" *) output wire [7:0] m_axi_awlen,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWSIZE" *) output wire [2:0] m_axi_awsize,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWBURST" *) output wire [1:0] m_axi_awburst,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWVALID" *) output wire m_axi_awvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWREADY" *) input wire m_axi_awready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WDATA" *) output wire [127:0] m_axi_wdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WSTRB" *) output wire [15:0] m_axi_wstrb,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WLAST" *) output wire m_axi_wlast,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WVALID" *) output wire m_axi_wvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WREADY" *) input wire m_axi_wready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARADDR" *) output wire [31:0] m_axi_araddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARLEN" *) output wire [7:0] m_axi_arlen,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARSIZE" *) output wire [2:0] m_axi_arsize,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARBURST" *) output wire [1:0] m_axi_arburst,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARVALID" *) output wire m_axi_arvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARREADY" *) input wire m_axi_arready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RDATA" *) input wire [127:0] m_axi_rdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RRESP" *) input wire [1:0] m_axi_rresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RLAST" *) input wire m_axi_rlast,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RVALID" *) input wire m_axi_rvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RREADY" *) output wire m_axi_rready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BRESP" *) input wire [1:0] m_axi_bresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BVALID" *) input wire m_axi_bvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BREADY" *) output wire m_axi_bready
);
wire resetn=READY_CONTAINS_ARESETN ? engine_ready : (aresetn && engine_ready);
qwen_channel_2slot_v1 #(.WIDTH(45)) channel_AW(.clk(aclk),.rst_n(resetn),.s_valid(s_axi_awvalid),.s_ready(s_axi_awready),.s_data({s_axi_awaddr,s_axi_awlen,s_axi_awsize,s_axi_awburst}),.m_valid(m_axi_awvalid),.m_ready(m_axi_awready),.m_data({m_axi_awaddr,m_axi_awlen,m_axi_awsize,m_axi_awburst}));
qwen_channel_2slot_v1 #(.WIDTH(145)) channel_W(.clk(aclk),.rst_n(resetn),.s_valid(s_axi_wvalid),.s_ready(s_axi_wready),.s_data({s_axi_wdata,s_axi_wstrb,s_axi_wlast}),.m_valid(m_axi_wvalid),.m_ready(m_axi_wready),.m_data({m_axi_wdata,m_axi_wstrb,m_axi_wlast}));
qwen_channel_2slot_v1 #(.WIDTH(45)) channel_AR(.clk(aclk),.rst_n(resetn),.s_valid(s_axi_arvalid),.s_ready(s_axi_arready),.s_data({s_axi_araddr,s_axi_arlen,s_axi_arsize,s_axi_arburst}),.m_valid(m_axi_arvalid),.m_ready(m_axi_arready),.m_data({m_axi_araddr,m_axi_arlen,m_axi_arsize,m_axi_arburst}));
qwen_channel_2slot_registered_head #(.WIDTH(131)) channel_R(.clk(aclk),.rst_n(resetn),.s_valid(m_axi_rvalid),.s_ready(m_axi_rready),.s_data({m_axi_rdata,m_axi_rresp,m_axi_rlast}),.m_valid(s_axi_rvalid),.m_ready(s_axi_rready),.m_data({s_axi_rdata,s_axi_rresp,s_axi_rlast}));
qwen_channel_2slot_v1 #(.WIDTH(2)) channel_B(.clk(aclk),.rst_n(resetn),.s_valid(m_axi_bvalid),.s_ready(m_axi_bready),.s_data({m_axi_bresp}),.m_valid(s_axi_bvalid),.m_ready(s_axi_bready),.m_data({s_axi_bresp}));
endmodule
module qwen_channel_2slot_v1 #(parameter WIDTH=32)(
 input wire clk,rst_n,s_valid,output wire s_ready,input wire [WIDTH-1:0] s_data,
 output wire m_valid,input wire m_ready,output wire [WIDTH-1:0] m_data
);
 // Payload has no reset or initialization. Only ownership metadata is reset.
 reg [WIDTH-1:0] payload[0:1];reg rd_ptr,wr_ptr;reg [1:0] count;
 assign s_ready=rst_n && count!=2;
 assign m_valid=rst_n && count!=0;
 assign m_data=payload[rd_ptr];
 wire push=s_valid && s_ready,pop=m_valid && m_ready;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin rd_ptr<=0;wr_ptr<=0;count<=0;end
  else begin
   if(push)begin payload[wr_ptr]<=s_data;wr_ptr<=!wr_ptr;end
   if(pop)rd_ptr<=!rd_ptr;
   case({push,pop})2'b10:count<=count+1;2'b01:count<=count-1;default:count<=count;endcase
  end
 end
endmodule

// Two slots with a fixed output register. No payload reset or X/Z coercion.
module qwen_channel_2slot_registered_head #(parameter WIDTH=32)(
 input wire clk,rst_n,s_valid,output wire s_ready,input wire [WIDTH-1:0] s_data,
 output wire m_valid,input wire m_ready,output wire [WIDTH-1:0] m_data
);
 (* EXTRACT_ENABLE="NO" *) reg [WIDTH-1:0] output_payload,spare_payload;
 reg [1:0] count;
 assign s_ready=rst_n&&count!=2;
 assign m_valid=rst_n&&count!=0;
 assign m_data=output_payload;
 wire push=s_valid&&s_ready,pop=m_valid&&m_ready;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)count<=0;
  else case({push,pop})
   2'b10:begin
    if(count==0)output_payload<=s_data;else spare_payload<=s_data;
    count<=count+1'b1;
   end
   2'b01:begin
    if(count==2)output_payload<=spare_payload;
    count<=count-1'b1;
   end
   2'b11:begin output_payload<=s_data;end
   default:begin end
  endcase
 end
endmodule
