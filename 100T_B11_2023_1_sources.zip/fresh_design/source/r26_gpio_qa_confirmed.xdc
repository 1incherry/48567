# R26 root-selectedGPIO QA candidate. Root reports actualJ9 Bank35=3.3V confirmed.
# Schematic FPGA_BANK34_35: H9=GPIO0=J7pin1, J8=GPIO1=J7pin2; GND=J7pin37/38.
# C3GPIO4TX -> H9RX; C3GPIO5RX <- J8TX. Never confuse J7pin5(GPIO4) withP3pin5GND.
set_property PACKAGE_PIN H9 [get_ports gpio_qa_rx]
set_property PACKAGE_PIN J8 [get_ports gpio_qa_tx]
set_property IOSTANDARD LVCMOS33 [get_ports {gpio_qa_rx gpio_qa_tx}]
