`timescale 1ns/1ps
module qwen_cpu_free_board_top #(parameter integer ENABLE_NTH4=0)(
 input wire clk50,input wire rst_n,input wire uart_rx,output wire uart_tx,
 inout wire [15:0] ddr3_dq,inout wire [1:0] ddr3_dqs_p,ddr3_dqs_n,
 output wire [13:0] ddr3_addr,output wire [2:0] ddr3_ba,
 output wire ddr3_ras_n,ddr3_cas_n,ddr3_we_n,ddr3_reset_n,
 output wire [0:0] ddr3_ck_p,ddr3_ck_n,ddr3_cke,ddr3_odt,
 output wire [1:0] ddr3_dm,
 input wire eth_rxc,input wire [3:0] eth_rxd,input wire eth_rx_ctl,
 output wire eth_txc,output wire [3:0] eth_txd,output wire eth_tx_ctl,
 output wire eth_rst_n,inout wire eth_mdio,output wire eth_mdc,
 output wire [2:0] status_led,
 input wire camera_pclk,camera_href,camera_vsync,input wire[7:0]camera_data,
 output wire cam_resetb,camera_pwdn,inout wire i2c_scl_ov5640,i2c_sda_ov5640
`ifdef QW_GPIO_QA_PROFILE
 ,input wire gpio_qa_rx,output wire gpio_qa_tx
`endif
);
wire clock50_buffered,sys100,core125,ref200,ref_locked,ui_clk,ui_reset,mig_locked,calibrated;
IBUF input_buffer(.I(clk50),.O(clock50_buffered));
qwen_board_clock reference_clock(.clk_in1(clock50_buffered),.reset(~rst_n),.clk_out1(sys100),.clk_out2(ref200),.clk_out3(core125),.locked(ref_locked));
wire mig_reset_n=rst_n && ref_locked;
wire core_release_condition=rst_n && ref_locked;
(* ASYNC_REG="TRUE" *) reg [31:0] core_release=0;
always @(posedge core125 or negedge core_release_condition)
 if(!core_release_condition)core_release<=0;else core_release<={core_release[30:0],1'b1};
wire core_resetn=core_release[31];
wire axi_release_condition=rst_n && ref_locked && !ui_reset;
(* ASYNC_REG="TRUE" *) reg [31:0] axi_release=0;
always @(posedge ui_clk or negedge axi_release_condition)
 if(!axi_release_condition)axi_release<=0;else axi_release<={axi_release[30:0],1'b1};
wire mig_axi_reset_n=axi_release[31];
wire eth_clk125,eth_control_clk125,eth_resetn;wire qwen_uart_tx;
wire transport_reset_condition=rst_n;
(* ASYNC_REG="TRUE" *)reg[2:0]transport_release100=0;
always@(posedge ui_clk or negedge transport_reset_condition)
 if(!transport_reset_condition)transport_release100<=0;else transport_release100<={transport_release100[1:0],1'b1};
wire transport_resetn100=transport_release100[2];
// All accepted transport credits are POR-only;clock/DDR/PHY health only revoke.
(* ASYNC_REG="TRUE" *)reg[2:0]runtime_board_release50=0,runtime_board_release125=0;
always@(posedge clock50_buffered or negedge rst_n)
 if(!rst_n)runtime_board_release50<=0;else runtime_board_release50<={runtime_board_release50[1:0],1'b1};
always@(posedge eth_control_clk125 or negedge rst_n)
 if(!rst_n)runtime_board_release125<=0;else runtime_board_release125<={runtime_board_release125[1:0],1'b1};
wire runtime_board_reset50=runtime_board_release50[2],runtime_board_reset125=runtime_board_release125[2];

wire runtime_release_owned50,runtime_release_completion_toggle50;
wire runtime_transport_fault100;
wire ready_sync;
qwen_ddr_ready_cdc_v1 ready_crossing(.ui_clk(ui_clk),.core_clk(core125),.core_resetn(core_resetn),.calibrated(calibrated),.mig_locked(mig_locked),.mig_axi_reset_n(mig_axi_reset_n),.engine_ready(ready_sync));
wire [31:0] cpu_araddr;
wire [1:0] cpu_arburst;
wire [3:0] cpu_arcache;
wire [7:0] cpu_arlen;
wire [0:0] cpu_arlock;
wire [2:0] cpu_arprot;
wire [3:0] cpu_arqos;
wire  cpu_arready;
wire [2:0] cpu_arsize;
wire  cpu_arvalid;
wire [31:0] cpu_awaddr;
wire [1:0] cpu_awburst;
wire [3:0] cpu_awcache;
wire [7:0] cpu_awlen;
wire [0:0] cpu_awlock;
wire [2:0] cpu_awprot;
wire [3:0] cpu_awqos;
wire  cpu_awready;
wire [2:0] cpu_awsize;
wire  cpu_awvalid;
wire  cpu_bready;
wire [1:0] cpu_bresp;
wire  cpu_bvalid;
wire [127:0] cpu_rdata;
wire  cpu_rlast;
wire  cpu_rready;
wire [1:0] cpu_rresp;
wire  cpu_rvalid;
wire [127:0] cpu_wdata;
wire  cpu_wlast;
wire  cpu_wready;
wire [15:0] cpu_wstrb;
wire  cpu_wvalid;

wire [31:0] eth_axi_awaddr;
wire [2:0] eth_axi_awprot;
wire  eth_axi_awvalid;
wire  eth_axi_awready;
wire [31:0] eth_axi_wdata;
wire [3:0] eth_axi_wstrb;
wire  eth_axi_wvalid;
wire  eth_axi_wready;
wire [1:0] eth_axi_bresp;
wire  eth_axi_bvalid;
wire  eth_axi_bready;
wire [31:0] eth_axi_araddr;
wire [2:0] eth_axi_arprot;
wire  eth_axi_arvalid;
wire  eth_axi_arready;
wire [31:0] eth_axi_rdata;
wire [1:0] eth_axi_rresp;
wire  eth_axi_rvalid;
wire  eth_axi_rready;
wire [31:0] runtime_awaddr,runtime_wdata,runtime_araddr,runtime_rdata;
wire [3:0] runtime_wstrb;wire [1:0]runtime_bresp,runtime_rresp;
wire runtime_awvalid,runtime_awready,runtime_wvalid,runtime_wready,runtime_bvalid,runtime_bready;
wire runtime_arvalid,runtime_arready,runtime_rvalid,runtime_rready;
wire runtime_cpu_resetn,runtime_mode,runtime_io_idle,runtime_release_quiet,runtime_ddr_idle,runtime_acquire_confirmed;
wire runtime_subsystem_fault,runtime_guard_fault,runtime_owner_fault,runtime_mode_accepted;
wire runtime_descriptor_valid,runtime_enable,runtime_epoch_n,runtime_ddr_admit,runtime_lease_health;
wire runtime_mode_set,runtime_mode_value,runtime_ack_on,runtime_ack_off;
wire[7:0]runtime_phy_tx_byte,runtime_legacy_rx_byte;wire runtime_phy_tx_valid,runtime_legacy_tx_ready,runtime_legacy_rx_valid,runtime_legacy_rx_error;
wire sct_freeze_precommit;
wire sct_freeze_disable;
wire sct_side_retire_ack;
wire sct_side_retire_req;
wire sct_main_start;
wire sct_main_prepare;
wire sct_main_response_consumed;
wire sct_main_ready;
wire sct_main_qualified;
wire sct_main_good;
wire sct_main_fault;
wire sct_main_closed_ack;
wire sct_main_active;
wire sct_qualify_start;
wire sct_qualify_ready;
wire sct_qualify_done;
wire sct_qualify_good;
wire sct_qualify_fault;
wire sct_release_owned125;
wire sct_trusted_stop100;
wire sct_trusted_stop125;
wire sct_drain_ack125;
wire sct_drain_fault125;
wire sct_release_permit125;
wire [31:0] boot_side_axi_awaddr;
wire [2:0] boot_side_axi_awprot;
wire boot_side_axi_awvalid;
wire boot_side_axi_awready;
wire [31:0] boot_side_axi_wdata;
wire [3:0] boot_side_axi_wstrb;
wire boot_side_axi_wvalid;
wire boot_side_axi_wready;
wire [1:0] boot_side_axi_bresp;
wire boot_side_axi_bvalid;
wire boot_side_axi_bready;
wire [31:0] boot_side_axi_araddr;
wire [2:0] boot_side_axi_arprot;
wire boot_side_axi_arvalid;
wire boot_side_axi_arready;
wire [31:0] boot_side_axi_rdata;
wire [1:0] boot_side_axi_rresp;
wire boot_side_axi_rvalid;
wire boot_side_axi_rready;
wire camera_bridge_quiet,shared_memory_quiet,shared_memory_fault;
wire token_cpu_parked,token_cpu_park_ack,token_cpu_ddr_allowed,token_unpark_allow,token_camera_request,token_camera_done,token_camera_completed,token_camera_fault,token_camera_owner_live;
wire camera_bridge_fault;wire clk_50m=clock50_buffered;
qwen_fabric_wrapper fabric(.token_board_resetn(rst_n),.token_cpu_parked(token_cpu_parked),.token_cpu_park_ack(token_cpu_park_ack),.token_cpu_ddr_allowed(token_cpu_ddr_allowed),.token_cpu_ddr_idle(runtime_ddr_idle),
 .token_bridge_quiet(camera_bridge_quiet),.token_shared_quiet(shared_memory_quiet),.token_camera_done(token_camera_done),.token_camera_completed(token_camera_completed),.token_camera_fault(token_camera_fault),.token_camera_owner_live(token_camera_owner_live),
 .token_guard_fault(runtime_guard_fault||shared_memory_fault||camera_bridge_fault||runtime_transport_fault100),.token_camera_request(token_camera_request),.token_unpark_allow(token_unpark_allow),.transport_resetn(transport_resetn100),.sct_freeze_precommit(sct_freeze_precommit),.sct_freeze_disable(sct_freeze_disable),.sct_side_retire_ack(sct_side_retire_ack),.sct_side_retire_req(sct_side_retire_req),.sct_main_start(sct_main_start),.sct_main_prepare(sct_main_prepare),.sct_main_response_consumed(sct_main_response_consumed),.sct_main_ready(sct_main_ready),.sct_main_qualified(sct_main_qualified),.sct_main_good(sct_main_good),.sct_main_fault(sct_main_fault),.sct_main_closed_ack(sct_main_closed_ack),.sct_main_active(sct_main_active),.sct_qualify_start(sct_qualify_start),.sct_qualify_ready(sct_qualify_ready),.sct_qualify_done(sct_qualify_done),.sct_qualify_good(sct_qualify_good),.sct_qualify_fault(sct_qualify_fault),.sct_independent_fault100(shared_memory_fault||camera_bridge_fault),.sct_other_quiet100(1'b1),.sct_release_completion_toggle50(runtime_release_completion_toggle50),.sct_release_owned50(runtime_release_owned50),.sct_release_owned125(sct_release_owned125),.sct_trusted_stop100(sct_trusted_stop100),.sct_trusted_stop125(sct_trusted_stop125),.sct_drain_ack125(sct_drain_ack125),.sct_drain_fault125(sct_drain_fault125),.sct_release_permit125(sct_release_permit125),.sct_transport_fault100(runtime_transport_fault100),.BOOT_SIDE_AXI_awaddr(boot_side_axi_awaddr),.BOOT_SIDE_AXI_awprot(boot_side_axi_awprot),.BOOT_SIDE_AXI_awvalid(boot_side_axi_awvalid),.BOOT_SIDE_AXI_awready(boot_side_axi_awready),.BOOT_SIDE_AXI_wdata(boot_side_axi_wdata),.BOOT_SIDE_AXI_wstrb(boot_side_axi_wstrb),.BOOT_SIDE_AXI_wvalid(boot_side_axi_wvalid),.BOOT_SIDE_AXI_wready(boot_side_axi_wready),.BOOT_SIDE_AXI_bresp(boot_side_axi_bresp),.BOOT_SIDE_AXI_bvalid(boot_side_axi_bvalid),.BOOT_SIDE_AXI_bready(boot_side_axi_bready),.BOOT_SIDE_AXI_araddr(boot_side_axi_araddr),.BOOT_SIDE_AXI_arprot(boot_side_axi_arprot),.BOOT_SIDE_AXI_arvalid(boot_side_axi_arvalid),.BOOT_SIDE_AXI_arready(boot_side_axi_arready),.BOOT_SIDE_AXI_rdata(boot_side_axi_rdata),.BOOT_SIDE_AXI_rresp(boot_side_axi_rresp),.BOOT_SIDE_AXI_rvalid(boot_side_axi_rvalid),.BOOT_SIDE_AXI_rready(boot_side_axi_rready),.runtime_clk50(clk_50m),.runtime_resetn(runtime_board_reset50),
.RUNTIME_AXI_awaddr(runtime_awaddr),.RUNTIME_AXI_awprot(3'd0),.RUNTIME_AXI_awvalid(runtime_awvalid),.RUNTIME_AXI_awready(runtime_awready),
.RUNTIME_AXI_wdata(runtime_wdata),.RUNTIME_AXI_wstrb(runtime_wstrb),.RUNTIME_AXI_wvalid(runtime_wvalid),.RUNTIME_AXI_wready(runtime_wready),
.RUNTIME_AXI_bresp(runtime_bresp),.RUNTIME_AXI_bvalid(runtime_bvalid),.RUNTIME_AXI_bready(runtime_bready),
.RUNTIME_AXI_araddr(runtime_araddr),.RUNTIME_AXI_arprot(3'd0),.RUNTIME_AXI_arvalid(runtime_arvalid),.RUNTIME_AXI_arready(runtime_arready),
.RUNTIME_AXI_rdata(runtime_rdata),.RUNTIME_AXI_rresp(runtime_rresp),.RUNTIME_AXI_rvalid(runtime_rvalid),.RUNTIME_AXI_rready(runtime_rready),.eth_clk125(eth_control_clk125),.eth_resetn(runtime_board_reset125),.ETH_AXI_awaddr(eth_axi_awaddr),.ETH_AXI_awprot(eth_axi_awprot),.ETH_AXI_awvalid(eth_axi_awvalid),.ETH_AXI_awready(eth_axi_awready),.ETH_AXI_wdata(eth_axi_wdata),.ETH_AXI_wstrb(eth_axi_wstrb),.ETH_AXI_wvalid(eth_axi_wvalid),.ETH_AXI_wready(eth_axi_wready),.ETH_AXI_bresp(eth_axi_bresp),.ETH_AXI_bvalid(eth_axi_bvalid),.ETH_AXI_bready(eth_axi_bready),.ETH_AXI_araddr(eth_axi_araddr),.ETH_AXI_arprot(eth_axi_arprot),.ETH_AXI_arvalid(eth_axi_arvalid),.ETH_AXI_arready(eth_axi_arready),.ETH_AXI_rdata(eth_axi_rdata),.ETH_AXI_rresp(eth_axi_rresp),.ETH_AXI_rvalid(eth_axi_rvalid),.ETH_AXI_rready(eth_axi_rready),.DDR_AXI_araddr(cpu_araddr),.DDR_AXI_arburst(cpu_arburst),.DDR_AXI_arcache(cpu_arcache),.DDR_AXI_arlen(cpu_arlen),.DDR_AXI_arlock(cpu_arlock),.DDR_AXI_arprot(cpu_arprot),.DDR_AXI_arqos(cpu_arqos),.DDR_AXI_arready(cpu_arready),.DDR_AXI_arsize(cpu_arsize),.DDR_AXI_arvalid(cpu_arvalid),.DDR_AXI_awaddr(cpu_awaddr),.DDR_AXI_awburst(cpu_awburst),.DDR_AXI_awcache(cpu_awcache),.DDR_AXI_awlen(cpu_awlen),.DDR_AXI_awlock(cpu_awlock),.DDR_AXI_awprot(cpu_awprot),.DDR_AXI_awqos(cpu_awqos),.DDR_AXI_awready(cpu_awready),.DDR_AXI_awsize(cpu_awsize),.DDR_AXI_awvalid(cpu_awvalid),.DDR_AXI_bready(cpu_bready),.DDR_AXI_bresp(cpu_bresp),.DDR_AXI_bvalid(cpu_bvalid),.DDR_AXI_rdata(cpu_rdata),.DDR_AXI_rlast(cpu_rlast),.DDR_AXI_rready(cpu_rready),.DDR_AXI_rresp(cpu_rresp),.DDR_AXI_rvalid(cpu_rvalid),.DDR_AXI_wdata(cpu_wdata),.DDR_AXI_wlast(cpu_wlast),.DDR_AXI_wready(cpu_wready),.DDR_AXI_wstrb(cpu_wstrb),.DDR_AXI_wvalid(cpu_wvalid),.core_clk(core125),.core_resetn(core_resetn),.ddr_clk(ui_clk),.ddr_resetn(mig_axi_reset_n),.engine_ready(ready_sync),.uart_rx(uart_rx),.uart_tx(qwen_uart_tx));
wire [31:0] mem_awaddr,cam_awaddr;
wire [7:0] mem_awlen,cam_awlen;
wire [2:0] mem_awsize,cam_awsize;
wire [1:0] mem_awburst,cam_awburst;
wire mem_awvalid,cam_awvalid;
wire mem_awready,cam_awready;
wire [127:0] mem_wdata,cam_wdata;
wire [15:0] mem_wstrb,cam_wstrb;
wire mem_wlast,cam_wlast;
wire mem_wvalid,cam_wvalid;
wire mem_wready,cam_wready;
wire [1:0] mem_bresp,cam_bresp;
wire mem_bvalid,cam_bvalid;
wire mem_bready,cam_bready;
wire [31:0] mem_araddr,cam_araddr;
wire [7:0] mem_arlen,cam_arlen;
wire [2:0] mem_arsize,cam_arsize;
wire [1:0] mem_arburst,cam_arburst;
wire mem_arvalid,cam_arvalid;
wire mem_arready,cam_arready;
wire [127:0] mem_rdata,cam_rdata;
wire [1:0] mem_rresp,cam_rresp;
wire mem_rlast,cam_rlast;
wire mem_rvalid,cam_rvalid;
wire mem_rready,cam_rready;
wire[3:0]mem_awcache=4'b0011,mem_arcache=4'b0011,mem_awqos=0,mem_arqos=0;
 wire[2:0]mem_awprot=0,mem_arprot=0;wire mem_awlock=0,mem_arlock=0;
 wire[26:0]app_addr;wire[2:0]app_cmd;wire app_en,app_rdy,app_wdf_end,app_wdf_wren,app_wdf_rdy,app_rd_data_end,app_rd_data_valid;
 wire[127:0]app_wdf_data,app_rd_data;wire[15:0]app_wdf_mask;
 
 wire camera_pic_clk;BUFG camera_pixel_buffer(.I(camera_pclk),.O(camera_pic_clk));
 (* ASYNC_REG="TRUE" *)reg[2:0]camera_control_release=0;
 wire camera_control_reset=rst_n&&ref_locked;
 always @(posedge clk_50m or negedge camera_control_reset)if(!camera_control_reset)camera_control_release<=0;else camera_control_release<={camera_control_release[1:0],1'b1};
 wire rst_n_50m=camera_control_release[2];
 (* ASYNC_REG="TRUE" *)reg[2:0]cam_reset_sync=0;
 always @(posedge camera_pic_clk or negedge rst_n_50m)if(!rst_n_50m)cam_reset_sync<=0;else cam_reset_sync<={cam_reset_sync[1:0],1'b1};
 wire[15:0]eth_status;wire[127:0]phy_debug_snapshot;wire phy_debug_valid;
 wire[7:0]uart_rxd_data,rxd_data,txd_data;wire uart_rxd_done,rxd_done,txd_start,tx_done,uart_busy;
 wire shared_uart_rx,shared_uart_tx,qa_owner_rx_abort;
 wire[8:0]vio_command;reg vio_prev=0;
 always @(posedge clk_50m)if(!rst_n_50m)vio_prev<=0;else vio_prev<=vio_command[8];
 assign rxd_data=(vio_command[8]!=vio_prev)?vio_command[7:0]:runtime_legacy_rx_byte;
 assign rxd_done=!runtime_mode&&((vio_command[8]!=vio_prev)||runtime_legacy_rx_valid);
 wire camera_pwup,ov5640_reg_done;reg declared1080=0;
 assign camera_pwdn=!camera_pwup;

ddr3_intf memory_controller(.ddr3_dq(ddr3_dq),
.ddr3_dqs_p(ddr3_dqs_p),
.ddr3_dqs_n(ddr3_dqs_n),
.ddr3_addr(ddr3_addr),
.ddr3_ba(ddr3_ba),
.ddr3_ras_n(ddr3_ras_n),
.ddr3_cas_n(ddr3_cas_n),
.ddr3_we_n(ddr3_we_n),
.ddr3_reset_n(ddr3_reset_n),
.ddr3_ck_p(ddr3_ck_p),
.ddr3_ck_n(ddr3_ck_n),
.ddr3_cke(ddr3_cke),
.ddr3_odt(ddr3_odt),
.ddr3_dm(ddr3_dm),
.sys_clk_i(sys100),
.clk_ref_i(ref200),
.sys_rst(mig_reset_n),
.ui_clk(ui_clk),
.ui_clk_sync_rst(ui_reset),
.mmcm_locked(mig_locked),
.init_calib_complete(calibrated),
.aresetn(mig_axi_reset_n),
.app_sr_req(1'b0),
.app_ref_req(1'b0),
.app_zq_req(1'b0),
.s_axi_awid(4'b0),
.s_axi_arid(4'b0),
.s_axi_araddr(mem_araddr[27:0]),
.s_axi_arburst(mem_arburst),
.s_axi_arcache(mem_arcache),
.s_axi_arlen(mem_arlen),
.s_axi_arlock(mem_arlock),
.s_axi_arprot(mem_arprot),
.s_axi_arqos(mem_arqos),
.s_axi_arready(mem_arready),
.s_axi_arsize(mem_arsize),
.s_axi_arvalid(mem_arvalid),
.s_axi_awaddr(mem_awaddr[27:0]),
.s_axi_awburst(mem_awburst),
.s_axi_awcache(mem_awcache),
.s_axi_awlen(mem_awlen),
.s_axi_awlock(mem_awlock),
.s_axi_awprot(mem_awprot),
.s_axi_awqos(mem_awqos),
.s_axi_awready(mem_awready),
.s_axi_awsize(mem_awsize),
.s_axi_awvalid(mem_awvalid),
.s_axi_bready(mem_bready),
.s_axi_bresp(mem_bresp),
.s_axi_bvalid(mem_bvalid),
.s_axi_rdata(mem_rdata),
.s_axi_rlast(mem_rlast),
.s_axi_rready(mem_rready),
.s_axi_rresp(mem_rresp),
.s_axi_rvalid(mem_rvalid),
.s_axi_wdata(mem_wdata),
.s_axi_wlast(mem_wlast),
.s_axi_wready(mem_wready),
.s_axi_wstrb(mem_wstrb),
.s_axi_wvalid(mem_wvalid));
qwen_camera_endpoint #(.ENABLE_NTH4(ENABLE_NTH4)) ethernet(.token_camera_request(token_camera_request),.token_camera_done(token_camera_done),.token_camera_frame_completed(token_camera_completed),.token_camera_fault(token_camera_fault),.token_camera_owner_live(token_camera_owner_live),.control_clk125(eth_control_clk125),.sct_main_ready(sct_main_ready),.sct_main_qualified(sct_main_qualified),.sct_main_good(sct_main_good),.sct_main_fault(sct_main_fault),.sct_main_closed_ack(sct_main_closed_ack),.sct_main_active(sct_main_active),.sct_main_start(sct_main_start),.sct_main_prepare(sct_main_prepare),.sct_main_response_consumed(sct_main_response_consumed),.sct_qualify_ready(sct_qualify_ready),.sct_qualify_done(sct_qualify_done),.sct_qualify_good(sct_qualify_good),.sct_qualify_fault(sct_qualify_fault),.sct_qualify_start(sct_qualify_start),.sct_side_retire_req(sct_side_retire_req),.sct_side_retire_ack(sct_side_retire_ack),.sct_freeze_precommit(sct_freeze_precommit),.sct_freeze_disable(sct_freeze_disable),.sct_release_owned125(sct_release_owned125),.sct_trusted_stop100(sct_trusted_stop100),.sct_trusted_stop125(sct_trusted_stop125),.sct_drain_ack125(sct_drain_ack125),.sct_drain_fault125(sct_drain_fault125),.sct_release_permit125(sct_release_permit125),.b_awaddr(boot_side_axi_awaddr),.b_awvalid(boot_side_axi_awvalid),.b_awready(boot_side_axi_awready),.b_wdata(boot_side_axi_wdata),.b_wstrb(boot_side_axi_wstrb),.b_wvalid(boot_side_axi_wvalid),.b_wready(boot_side_axi_wready),.b_bresp(boot_side_axi_bresp),.b_bvalid(boot_side_axi_bvalid),.b_bready(boot_side_axi_bready),.b_araddr(boot_side_axi_araddr),.b_arvalid(boot_side_axi_arvalid),.b_arready(boot_side_axi_arready),.b_rdata(boot_side_axi_rdata),.b_rresp(boot_side_axi_rresp),.b_rvalid(boot_side_axi_rvalid),.b_rready(boot_side_axi_rready),.runtime_io_resetn(runtime_board_reset50),.runtime_source_resetn(runtime_board_reset125),.runtime_ddr_idle(runtime_release_quiet),.runtime_acquire_confirmed(runtime_acquire_confirmed),
.runtime_ack_on_50(runtime_ack_on),.runtime_ack_off_50(runtime_ack_off),.runtime_owner_50(runtime_mode),.runtime_idle_50(runtime_io_idle&&runtime_ddr_idle),
.runtime_fault_50(runtime_owner_fault||runtime_subsystem_fault||runtime_guard_fault),.runtime_descriptor_valid(runtime_descriptor_valid),.runtime_enable(runtime_enable),
.runtime_epoch_n(runtime_epoch_n),.runtime_ddr_admit(runtime_ddr_admit),.runtime_lease_health(runtime_lease_health),.runtime_guard_fault(runtime_guard_fault),.sys_clk_50m(clock50_buffered),.sys_rst_n(rst_n),.bus_clk125(eth_clk125),.bus_resetn(eth_resetn),
.refclk_200m(ref200),.ui_clk(ui_clk),.ui_rst_n(mig_axi_reset_n),.camera_bridge_quiescent_ui(camera_bridge_quiet),.shared_memory_quiescent_ui(shared_memory_quiet),.camera_clk(camera_pic_clk),.camera_rst_n(cam_reset_sync[2]),.calibrated(calibrated&&!camera_bridge_fault&&!shared_memory_fault&&ref_locked),
 .camera_data(camera_data),.camera_href(camera_href),.camera_vsync(camera_vsync),.camera_configured(ov5640_reg_done),.configured_width(declared1080?16'd1920:16'd640),.configured_height(declared1080?16'd1080:16'd480),
 .app_addr(app_addr),.app_cmd(app_cmd),.app_en(app_en),.app_rdy(app_rdy),.app_wdf_data(app_wdf_data),.app_wdf_mask(app_wdf_mask),.app_wdf_end(app_wdf_end),.app_wdf_wren(app_wdf_wren),.app_wdf_rdy(app_wdf_rdy),.app_rd_data(app_rd_data),.app_rd_data_valid(app_rd_data_valid),.app_rd_data_end(app_rd_data_end),.phy_debug_snapshot(phy_debug_snapshot),.phy_debug_valid(phy_debug_valid),.debug_status(eth_status),
.eth_rxc(eth_rxc),.eth_rxd(eth_rxd),.eth_rx_ctl(eth_rx_ctl),.eth_txc(eth_txc),.eth_txd(eth_txd),.eth_tx_ctl(eth_tx_ctl),.eth_rst_n(eth_rst_n),.eth_mdio(eth_mdio),.eth_mdc(eth_mdc),
.c_awaddr(eth_axi_awaddr),
.c_awvalid(eth_axi_awvalid),
.c_awready(eth_axi_awready),
.c_wdata(eth_axi_wdata),
.c_wstrb(eth_axi_wstrb),
.c_wvalid(eth_axi_wvalid),
.c_wready(eth_axi_wready),
.c_bresp(eth_axi_bresp),
.c_bvalid(eth_axi_bvalid),
.c_bready(eth_axi_bready),
.c_araddr(eth_axi_araddr),
.c_arvalid(eth_axi_arvalid),
.c_arready(eth_axi_arready),
.c_rdata(eth_axi_rdata),
.c_rresp(eth_axi_rresp),
.c_rvalid(eth_axi_rvalid),
.c_rready(eth_axi_rready));
camera_native_axi128 bridge(.clk(ui_clk),.rst_n(mig_axi_reset_n),.app_addr(app_addr),.app_cmd(app_cmd),.app_en(app_en),.app_rdy(app_rdy),.app_wdf_data(app_wdf_data),.app_wdf_mask(app_wdf_mask),.app_wdf_end(app_wdf_end),.app_wdf_wren(app_wdf_wren),.app_wdf_rdy(app_wdf_rdy),.app_rd_data(app_rd_data),.app_rd_data_valid(app_rd_data_valid),.app_rd_data_end(app_rd_data_end),.m_awaddr(cam_awaddr),.m_awlen(cam_awlen),.m_awsize(cam_awsize),.m_awburst(cam_awburst),.m_awvalid(cam_awvalid),.m_awready(cam_awready),.m_wdata(cam_wdata),.m_wstrb(cam_wstrb),.m_wlast(cam_wlast),.m_wvalid(cam_wvalid),.m_wready(cam_wready),.m_bresp(cam_bresp),.m_bvalid(cam_bvalid),.m_bready(cam_bready),.m_araddr(cam_araddr),.m_arlen(cam_arlen),.m_arsize(cam_arsize),.m_arburst(cam_arburst),.m_arvalid(cam_arvalid),.m_arready(cam_arready),.m_rdata(cam_rdata),.m_rresp(cam_rresp),.m_rlast(cam_rlast),.m_rvalid(cam_rvalid),.m_rready(cam_rready),.quiescent(camera_bridge_quiet),.fault(camera_bridge_fault));
shared_axi128_2to1 memory_arbiter(.clk(ui_clk),.rst_n(mig_axi_reset_n),.s_awaddr({cam_awaddr,cpu_awaddr}),.s_awlen({cam_awlen,cpu_awlen}),.s_awsize({cam_awsize,cpu_awsize}),.s_awburst({cam_awburst,cpu_awburst}),.s_awvalid({cam_awvalid,cpu_awvalid}),.s_awready({cam_awready,cpu_awready}),.s_wdata({cam_wdata,cpu_wdata}),.s_wstrb({cam_wstrb,cpu_wstrb}),.s_wlast({cam_wlast,cpu_wlast}),.s_wvalid({cam_wvalid,cpu_wvalid}),.s_wready({cam_wready,cpu_wready}),.s_bresp({cam_bresp,cpu_bresp}),.s_bvalid({cam_bvalid,cpu_bvalid}),.s_bready({cam_bready,cpu_bready}),.s_araddr({cam_araddr,cpu_araddr}),.s_arlen({cam_arlen,cpu_arlen}),.s_arsize({cam_arsize,cpu_arsize}),.s_arburst({cam_arburst,cpu_arburst}),.s_arvalid({cam_arvalid,cpu_arvalid}),.s_arready({cam_arready,cpu_arready}),.s_rdata({cam_rdata,cpu_rdata}),.s_rresp({cam_rresp,cpu_rresp}),.s_rlast({cam_rlast,cpu_rlast}),.s_rvalid({cam_rvalid,cpu_rvalid}),.s_rready({cam_rready,cpu_rready}),.m_awaddr(mem_awaddr),.m_awlen(mem_awlen),.m_awsize(mem_awsize),.m_awburst(mem_awburst),.m_awvalid(mem_awvalid),.m_awready(mem_awready),.m_wdata(mem_wdata),.m_wstrb(mem_wstrb),.m_wlast(mem_wlast),.m_wvalid(mem_wvalid),.m_wready(mem_wready),.m_bresp(mem_bresp),.m_bvalid(mem_bvalid),.m_bready(mem_bready),.m_araddr(mem_araddr),.m_arlen(mem_arlen),.m_arsize(mem_arsize),.m_arburst(mem_arburst),.m_arvalid(mem_arvalid),.m_arready(mem_arready),.m_rdata(mem_rdata),.m_rresp(mem_rresp),.m_rlast(mem_rlast),.m_rvalid(mem_rvalid),.m_rready(mem_rready),.quiescent(shared_memory_quiet),.fault(shared_memory_fault));
mcs_boot_owner runtime_boot(.clk(clk_50m),.board_reset_n(runtime_board_reset50),.source_epoch_n(runtime_epoch_n),
 .descriptor_source(runtime_descriptor_valid),.enable_source(runtime_enable),.io_idle(runtime_io_idle&&runtime_ddr_idle),
 .phy_quiet(!uart_busy&&!runtime_phy_tx_valid&&!txd_start),.subsystem_fault(runtime_subsystem_fault||runtime_guard_fault),
 .runtime_mode(runtime_mode),.trusted_mode_set(runtime_mode_set),.trusted_mode_value(runtime_mode_value),.cpu_reset_n(runtime_cpu_resetn),
 .ack_on(runtime_ack_on),.ack_off(runtime_ack_off),.fault(runtime_owner_fault),.state_debug());
mcs_uart_subsystem #(.ENABLE_NTH4(ENABLE_NTH4)) runtime_cpu(.token_unpark_allow(token_unpark_allow),.token_cpu_parked(token_cpu_parked),.token_cpu_park_ack(token_cpu_park_ack),.token_cpu_ddr_allowed(token_cpu_ddr_allowed),.clk(clk_50m),.rst_n(runtime_board_reset50),.cpu_reset_n(runtime_cpu_resetn),
 .lease_admit(runtime_ddr_admit),.lease_health(runtime_lease_health),.trusted_mode_set(runtime_mode_set),.trusted_mode_value(runtime_mode_value),
 .phy_rx_byte(uart_rxd_data),.phy_rx_valid(uart_rxd_done&&!qa_owner_rx_abort),.phy_rx_error(1'b0),
 .phy_tx_byte(runtime_phy_tx_byte),.phy_tx_valid(runtime_phy_tx_valid),.phy_tx_ready(!uart_busy),
 .legacy_tx_byte(txd_data),.legacy_tx_valid(txd_start),.legacy_tx_ready(runtime_legacy_tx_ready),
 .legacy_rx_byte(runtime_legacy_rx_byte),.legacy_rx_valid(runtime_legacy_rx_valid),.legacy_rx_error(runtime_legacy_rx_error),
 .runtime_mode(runtime_mode),.mode_accepted(runtime_mode_accepted),.io_idle(runtime_io_idle),.fault(runtime_subsystem_fault),
 .m_awaddr(runtime_awaddr),.m_awvalid(runtime_awvalid),.m_awready(runtime_awready),.m_wdata(runtime_wdata),.m_wstrb(runtime_wstrb),.m_wvalid(runtime_wvalid),.m_wready(runtime_wready),
 .m_bresp(runtime_bresp),.m_bvalid(runtime_bvalid),.m_bready(runtime_bready),.m_araddr(runtime_araddr),.m_arvalid(runtime_arvalid),.m_arready(runtime_arready),
 .m_rdata(runtime_rdata),.m_rresp(runtime_rresp),.m_rvalid(runtime_rvalid),.m_rready(runtime_rready),.ddr_idle(runtime_ddr_idle),.acquire_confirmed(runtime_acquire_confirmed),.release_quiet(runtime_release_quiet),.release_owned(runtime_release_owned50),.release_completion_toggle(runtime_release_completion_toggle50));

`ifdef QW_GPIO_QA_PROFILE
qwen_uart_pin_profile #(.USE_GPIO_QA(1)) qa_serial_pins(.clk(clk_50m),.board_reset_n(runtime_board_reset50),.runtime_mode(runtime_mode),.usb_rx(uart_rx),.gpio_rx(gpio_qa_rx),.shared_tx(shared_uart_tx),.shared_rx(shared_uart_rx),.usb_tx(uart_tx),.gpio_tx(gpio_qa_tx),.owner_rx_abort(qa_owner_rx_abort));
`else
qwen_uart_pin_profile #(.USE_GPIO_QA(0)) qa_serial_pins(.clk(clk_50m),.board_reset_n(runtime_board_reset50),.runtime_mode(runtime_mode),.usb_rx(uart_rx),.gpio_rx(1'b1),.shared_tx(shared_uart_tx),.shared_rx(shared_uart_rx),.usb_tx(uart_tx),.gpio_tx(),.owner_rx_abort(qa_owner_rx_abort));
`endif
`ifdef QW_GPIO_QA_PROFILE
uart_transceiver_owner_rx camera_uart(.sys_clk(clk_50m),.uart_rx(shared_uart_rx),.uart_tx(shared_uart_tx),.divisor(55),.rx_data(uart_rxd_data),.rx_done(uart_rxd_done),.rx_eop(),.tx_data(runtime_phy_tx_byte),.tx_wr(runtime_phy_tx_valid&&!uart_busy),.tx_done(tx_done),.tx_busy(uart_busy),.test_pin(),.sys_rst(!runtime_board_reset50),.rx_owner_abort(qa_owner_rx_abort));
`else
uart_transceiver camera_uart(.sys_clk(clk_50m),.uart_rx(shared_uart_rx),.uart_tx(shared_uart_tx),.divisor(55),.rx_data(uart_rxd_data),.rx_done(uart_rxd_done),.rx_eop(),.tx_data(runtime_phy_tx_byte),.tx_wr(runtime_phy_tx_valid&&!uart_busy),.tx_done(tx_done),.tx_busy(uart_busy),.test_pin(),.sys_rst(!runtime_board_reset50));
`endif
 ov5640_ctrl ov5640_reg_ctrl(.clk_50m(clk_50m),.cam_resetb(cam_resetb),.camera_pwup(camera_pwup),.i2c_scl(i2c_scl_ov5640),.i2c_sda(i2c_sda_ov5640),.reg_conf_done(ov5640_reg_done),.flash_switch(1'b0),.rxd_data(rxd_data),.rxd_done(rxd_done),.txd_data(txd_data),.txd_start(txd_start),.tx_done(tx_done&&!runtime_mode),.rst_n(rst_n_50m));
 always @(posedge clk_50m)if(!rst_n_50m)declared1080<=0;else if(rxd_done&&!eth_status[2])begin if(rxd_data==8'hf8)declared1080<=0;if(rxd_data==8'hf9)declared1080<=1;end
 // One-shot/debug mailboxes only; counters do not drive computation.
 (* ASYNC_REG="TRUE" *)reg[2:0]phy_debug_valid_sync=0,mig_cal_sync=0;(* DONT_TOUCH="TRUE" *)reg[127:0]phy_debug_local=0;reg phy_debug_captured=0;
 always @(posedge clk_50m)begin
 if(!rst_n_50m)begin phy_debug_valid_sync<=0;mig_cal_sync<=0;phy_debug_local<=0;phy_debug_captured<=0;end
 else begin phy_debug_valid_sync<={phy_debug_valid_sync[1:0],phy_debug_valid};mig_cal_sync<={mig_cal_sync[1:0],calibrated};if(phy_debug_valid_sync[2]&&!phy_debug_captured)begin phy_debug_local<=phy_debug_snapshot;phy_debug_captured<=1;end end end
 reg[31:0]pclk_counter=0,pclk_gray=0,wr_counter=0,wr_gray=0,rd_counter=0,rd_gray=0;
 always @(posedge camera_pic_clk)begin pclk_counter<=pclk_counter+1'b1;pclk_gray<=(pclk_counter+1'b1)^((pclk_counter+1'b1)>>1);end
 always @(posedge ui_clk)begin
 if(app_wdf_wren&&app_wdf_rdy)begin wr_counter<=wr_counter+1'b1;wr_gray<=(wr_counter+1'b1)^((wr_counter+1'b1)>>1);end
 if(app_rd_data_valid)begin rd_counter<=rd_counter+1'b1;rd_gray<=(rd_counter+1'b1)^((rd_counter+1'b1)>>1);end end
 (* ASYNC_REG="TRUE" *)reg[31:0]p1=0,p2=0,w1=0,w2=0,r1=0,r2=0;
 always @(posedge clk_50m)begin p1<=pclk_gray;p2<=p1;w1<=wr_gray;w2<=w1;r1<=rd_gray;r2<=r1;end
 wire[95:0]raw_crc;
 frame_crc_cdc input_crc(.src_clk(camera_pic_clk),.src_rst_n(cam_reset_sync[2]),.frame_sync(camera_vsync),.valid(camera_href),.data({8'd0,camera_data}),.dst_clk(clk_50m),.dst_rst_n(rst_n_50m),.snapshot(raw_crc));
 reg[7:0]raw_rx_seq=0,raw_rx_last=0,legacy_tx_seq=0,legacy_tx_last=0;reg[15:0]clock_ticks=0;
 always @(posedge clk_50m)begin clock_ticks<=clock_ticks+1'b1;if(uart_rxd_done)begin raw_rx_seq<=raw_rx_seq+1'b1;raw_rx_last<=uart_rxd_data;end if(txd_start)begin legacy_tx_seq<=legacy_tx_seq+1'b1;legacy_tx_last<=txd_data;end end
 wire[31:0]phy_debug_flags={16'h4e46,10'd0,phy_debug_captured,mig_cal_sync[2],ov5640_reg_done,declared1080,eth_status[1:0]};
 camera_vio camera_debug(.clk(clk_50m),.probe_out0(vio_command),.probe_in0(raw_crc),.probe_in1({w2,r2,eth_status,clock_ticks}),.probe_in2({p2,w2,r2}),.probe_in3(phy_debug_local[95:0]),.probe_in4({phy_debug_local[127:96],phy_debug_flags,p2}),.probe_in5({p2,raw_rx_seq,raw_rx_last,legacy_tx_seq,legacy_tx_last,eth_status,clock_ticks}));
 assign status_led={shared_memory_fault||camera_bridge_fault||runtime_transport_fault100,eth_status[0],calibrated};

endmodule
