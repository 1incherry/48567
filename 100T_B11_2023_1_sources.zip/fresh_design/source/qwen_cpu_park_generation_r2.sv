`timescale 1ns/1ps
// Real CORE125 half of the 50/125MHz four-phase park return handshake.
// All inputs except board_reset_n are already synchronized to this clock.
module qwen_cpu_park_generation_r2(
 input wire clk,board_reset_n,
 input wire park_command,unpark_requested,handover_unpark_allow,
 input wire physical_parked,physical_ddr_allowed,fresh_park_ack,
 output wire unpark_allow,cpu_ddr_allowed,
 output reg engaged,ack_seen
);
 assign unpark_allow=handover_unpark_allow&&(!engaged||ack_seen);
 // A stale pre-park positive permission can never satisfy a new generation.
 assign cpu_ddr_allowed=physical_ddr_allowed&&!engaged;
 always @(posedge clk or negedge board_reset_n)begin
  if(!board_reset_n)begin engaged<=0;ack_seen<=0;end
  else begin
   if(engaged&&fresh_park_ack)ack_seen<=1;
   if(engaged&&ack_seen&&unpark_requested&&handover_unpark_allow&&
      !physical_parked&&physical_ddr_allowed)begin engaged<=0;ack_seen<=0;end
   // Same-edge new park always takes precedence over an old completion.
   if(park_command)begin engaged<=1;ack_seen<=0;end
  end
 end
endmodule
