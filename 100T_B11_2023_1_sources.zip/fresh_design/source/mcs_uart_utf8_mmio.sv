`timescale 1ns/1ps
// Independent native-MCS IO peripheral and exclusive UART owner mux.
// No connection to the frozen camera parser or existing board top.
module mcs_uart_utf8_mmio #(
 parameter[31:0]BASE=32'hc2001000,parameter integer MAX_BYTES=4096,FIFO_DEPTH=64,CLOCK_HZ=50000000
)(
 input wire clk,rst_n,input wire trusted_mode_set,trusted_mode_value,
 input wire[7:0]phy_rx_byte,input wire phy_rx_valid,phy_rx_error,
 output wire[7:0]phy_tx_byte,output wire phy_tx_valid,input wire phy_tx_ready,
 input wire[7:0]legacy_tx_byte,input wire legacy_tx_valid,output wire legacy_tx_ready,
 output wire[7:0]legacy_rx_byte,output wire legacy_rx_valid,legacy_rx_error,
 input wire io_addr_strobe,io_read_strobe,io_write_strobe,
 input wire[31:0]io_address,io_write_data,input wire[3:0]io_byte_enable,
 output wire selected,output reg io_ready,output reg[31:0]io_read_data,
 output wire runtime_mode,output reg mmio_fault,output reg[7:0]fault_code,
 output reg mode_accepted
);
 localparam integer MS_DIV=CLOCK_HZ/1000;
 localparam integer TW=MS_DIV<=1?1:$clog2(MS_DIV);
 initial begin if(CLOCK_HZ<1000||CLOCK_HZ%1000!=0)$error("CLOCK_HZ_NOT_INTEGER_KHZ");end
 reg[TW-1:0]tick_div;reg[31:0]ms_tick;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin tick_div<=0;ms_tick<=0;end
  else if(tick_div==MS_DIV-1)begin tick_div<=0;ms_tick<=ms_tick+1'b1;end
  else tick_div<=tick_div+1'b1;
 end
 reg admission,tx_pending;reg[7:0]tx_byte;reg[15:0]events;
 wire transition=trusted_mode_set&&(trusted_mode_value!=runtime_mode);
 wire owner_quiet=phy_tx_ready&&!tx_pending&&!legacy_tx_valid;
 wire change_owner=transition&&owner_quiet;
 wire owner_denied=transition&&!owner_quiet;
 assign selected=(io_address[31:8]==BASE[31:8]);
 assign phy_tx_byte=runtime_mode?tx_byte:legacy_tx_byte;
 assign phy_tx_valid=runtime_mode?tx_pending:(legacy_tx_valid&&!change_owner);
 assign legacy_tx_ready=!runtime_mode&&phy_tx_ready&&!change_owner;
 wire qvalid,dvalid,dlast,committed,rejected,fifovalid,resync,legacyowner;
 wire[7:0]qdata;wire[15:0]qlen,fifolevel;wire[6:0]reason;
 wire[31:0]accepted_count,rejected_count,overflow_count,mode_abort_count;
 wire request=selected&&io_addr_strobe;
 wire good_read=request&&io_read_strobe&&!io_write_strobe&&io_byte_enable==15&&io_address[1:0]==0;
 wire pop=good_read&&io_address[7:0]==8'h0c&&!mmio_fault&&!tx_pending&&!change_owner&&runtime_mode&&dvalid;
 wire clear_req=request&&io_write_strobe&&!io_read_strobe&&io_address[7:0]==8'h18&&io_address[1:0]==0&&io_byte_enable==15&&io_write_data[31:16]==0&&!mmio_fault&&!tx_pending&&!change_owner;
 wire[15:0]new_events=(rejected?{9'd0,reason}:16'd0)|(owner_denied?16'h0080:16'd0);
 uart_utf8_frontend #(.MAX_BYTES(MAX_BYTES),.FIFO_DEPTH(FIFO_DEPTH)) ingress(
  .clk(clk),.rst_n(rst_n),.mode_set(change_owner),.mode_value(trusted_mode_value),.runtime_mode(runtime_mode),
  .rx_byte(phy_rx_byte),.rx_valid(phy_rx_valid),.rx_error(phy_rx_error),
  .legacy_rx_byte(legacy_rx_byte),.legacy_rx_valid(legacy_rx_valid),.legacy_rx_error(legacy_rx_error),.legacy_owner(legacyowner),
  .parse_enable(1'b1),.question_valid(qvalid),.question_length(qlen),.data_valid(dvalid),.data(qdata),.data_last(dlast),.data_ready(pop),
  .question_committed(committed),.question_rejected(rejected),.reject_reason(reason),.accepted_count(accepted_count),.rejected_count(rejected_count),
  .overflow_count(overflow_count),.mode_abort_count(mode_abort_count),.fifo_valid(fifovalid),.fifo_level(fifolevel),.resync_wire(resync),.admit_question(admission&&!mmio_fault)
 );
 task fail(input[7:0]code);
 begin if(!mmio_fault)begin mmio_fault<=1;fault_code<=code;end io_ready<=1;io_read_data<=32'hdead5500|code;end
 endtask
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   admission<=0;tx_pending<=0;tx_byte<=0;events<=0;io_ready<=0;io_read_data<=0;mmio_fault<=0;fault_code<=0;mode_accepted<=0;
  end else begin
   io_ready<=0;mode_accepted<=change_owner;
   if(change_owner)admission<=0;
   events<=(events&~(clear_req?io_write_data[15:0]:16'd0))|new_events;
   // An accepted byte is acknowledged only at the physical UART handshake.
   if(tx_pending&&runtime_mode&&phy_tx_ready)begin tx_pending<=0;io_ready<=1;io_read_data<=0;end
   if(request)begin
    if(tx_pending)begin if(!mmio_fault)begin mmio_fault<=1;fault_code<=8'h04;end end
    else if(!good_read&&!(io_write_strobe&&!io_read_strobe&&io_address[1:0]==0&&(io_byte_enable==15||io_byte_enable==1)))fail(8'h01);
    else if(good_read&&(io_address[7:0]==0||io_address[7:0]==4||io_address[7:0]==8'h18))begin
     io_ready<=1;
     case(io_address[7:0])
      0:io_read_data<=32'h51555232;
      4:io_read_data<={mmio_fault,15'd0,fault_code,2'd0,resync,admission,phy_tx_ready,dvalid,qvalid,runtime_mode};
      8'h18:io_read_data<={16'd0,events};
     endcase
    end else if(mmio_fault)fail(8'hff);
    else if(change_owner)fail(8'h05);
    else if(good_read)begin
     io_ready<=1;
     case(io_address[7:0])
      8'h08:io_read_data<={16'd0,qlen};
      8'h0c:io_read_data<=runtime_mode&&dvalid?{22'd0,dlast,1'b1,qdata}:0;
      8'h14:io_read_data<={31'd0,admission};
      8'h1c:io_read_data<=accepted_count;
      8'h20:io_read_data<=rejected_count;
      8'h24:io_read_data<=overflow_count;
      8'h28:io_read_data<=mode_abort_count;
      8'h2c:io_read_data<={16'd0,fifolevel};
      8'h30:io_read_data<=ms_tick;
      8'h34:io_read_data<=CLOCK_HZ;
      default:fail(8'h02);
     endcase
    end else begin
     case(io_address[7:0])
      8'h10:if(!runtime_mode||(io_byte_enable==15&&io_write_data[31:8]!=0))fail(8'h03);
             else begin tx_pending<=1;tx_byte<=io_write_data[7:0];end
      8'h14:if((io_byte_enable==15&&io_write_data[31:1]!=0)||(io_byte_enable==1&&io_write_data[7:1]!=0))fail(8'h03);
             else begin admission<=io_write_data[0];io_ready<=1;io_read_data<=0;end
      8'h18:if(io_byte_enable!=15||io_write_data[31:16]!=0)fail(8'h03);
             else begin io_ready<=1;io_read_data<=0;end
      default:fail(8'h02);
     endcase
    end
   end
  end
 end
endmodule
