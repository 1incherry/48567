// CPU-free greedy selection from actual signed INT64 DDR scratch.
// One 128-bit read beat is consumed as two ordered 64-bit elements. Lowest
// index wins ties. No softmax, UART or character conversion is involved here.
module qwen_argmax_axi128_v2 #(
 parameter [31:0] DDR_BASE=32'h80000000,
 parameter [32:0] DDR_BYTES=33'h010000000
)(
 input wire clk,rst_n,cmd_valid,output wire cmd_ready,
 input wire [15:0] cmd_rows,cmd_seq,input wire [31:0] cmd_input_base,
 output wire rsp_valid,input wire rsp_ready,output reg [15:0] rsp_seq,rsp_token,
 output reg signed [63:0] rsp_value,output reg [7:0] rsp_error,
 output wire busy,output reg [31:0] cycle_count,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready
);
 localparam IDLE=0,RA=1,RD=2,LOW=3,HIGH=4,FINISH=5,RESPONSE=6,READ_ADDRESS=7,READ_LIMIT=8;
 reg [3:0] state;
 // Unreset payload is invalid until its preparation state completes.
 reg [31:0] read_address;
 reg [8:0] read_burst_registered;
 reg [15:0] rows,index,read_word,total_words;
 reg [8:0] burst_length,burst_received;
 reg [31:0] input_base;
 reg [127:0] read_data;
 // Select the next scalar when its preceding beat/state commits, removing
 // the state-controlled64-bit mux before the signed comparator. No new cycles.
 reg signed [63:0] scalar_data;
 reg read_last,read_bad;
 wire [32:0] window_end={1'b0,DDR_BASE}+DDR_BYTES;
 wire [15:0] remaining=total_words-read_word;
 assign m_axi_araddr=read_address;
 wire [8:0] page=(13'd4096-{1'b0,m_axi_araddr[11:0]})>>4;
 wire [8:0] next_burst=remaining>255?(page<255?page:9'd255):(remaining<page?remaining[8:0]:page);
 assign cmd_ready=state==IDLE&&rst_n;assign rsp_valid=state==RESPONSE&&rst_n;
 assign busy=state!=IDLE&&state!=RESPONSE;
 assign m_axi_arvalid=state==RA&&rst_n;assign m_axi_rready=state==RD&&rst_n;
 assign m_axi_arlen=read_burst_registered-1;assign m_axi_arsize=4;assign m_axi_arburst=1;
 wire scalar_valid=(state==LOW||state==HIGH)&&!read_bad;
 wire scalar_last=index+1==rows;
 wire scalar_result_valid;wire [15:0] scalar_token;wire signed [63:0] scalar_value;
 qwen_argmax_i64_stream argmax(.clk,.rst_n,
  .frame_start(cmd_valid&&cmd_ready),.in_valid(scalar_valid),.in_last(scalar_last),
  .value_i64(scalar_data),
  .result_valid(scalar_result_valid),.argmax_index(scalar_token),.argmax_value(scalar_value));
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;rows<=0;index<=0;read_word<=0;total_words<=0;burst_length<=0;burst_received<=0;input_base<=0;read_data<=0;read_last<=0;read_bad<=0;rsp_seq<=0;rsp_token<=0;rsp_value<=0;rsp_error<=0;cycle_count<=0;end
  else begin
   if(busy)cycle_count<=cycle_count+1;
   case(state)
    IDLE:if(cmd_valid&&cmd_ready)begin
     rows<=cmd_rows;index<=0;read_word<=0;total_words<=({1'b0,cmd_rows}+1)>>1;input_base<=cmd_input_base;
     read_bad<=0;rsp_seq<=cmd_seq;rsp_token<=0;rsp_value<=0;rsp_error<=0;cycle_count<=0;
     if(cmd_rows==0||cmd_rows>65535||cmd_input_base[3:0]!=0||{1'b0,cmd_input_base}<{1'b0,DDR_BASE}||{1'b0,cmd_input_base}+({17'b0,cmd_rows}<<3)>window_end)
      begin rsp_error<=1;state<=RESPONSE;end
     else state<=READ_ADDRESS;
    end
    READ_ADDRESS:begin read_address<=input_base+({16'b0,read_word}<<4);state<=READ_LIMIT;end
    READ_LIMIT:begin read_burst_registered<=next_burst;state<=RA;end
    RA:if(m_axi_arvalid&&m_axi_arready)begin burst_length<=read_burst_registered;burst_received<=0;state<=RD;end
    RD:if(m_axi_rvalid&&m_axi_rready)begin
     scalar_data<=m_axi_rdata[63:0];
     read_data<=m_axi_rdata;read_last<=m_axi_rlast;read_word<=read_word+1;burst_received<=burst_received+1;
     if(m_axi_rresp!=0)begin read_bad<=1;rsp_error<=2;end
     if(m_axi_rlast!=(burst_received+1==burst_length))begin read_bad<=1;rsp_error<=3;end
     if(read_bad||m_axi_rresp!=0||m_axi_rlast!=(burst_received+1==burst_length))begin
      if(m_axi_rlast)state<=RESPONSE;
     end else state<=LOW;
    end
    LOW:begin
     scalar_data<=read_data[127:64];
     index<=index+1;
     if(scalar_last)state<=FINISH;else state<=HIGH;
    end
    HIGH:begin
     index<=index+1;
     if(scalar_last)state<=FINISH;
     else if(read_last)state<=READ_ADDRESS;else state<=RD;
    end
    FINISH:if(scalar_result_valid)begin
     rsp_token<=scalar_token;rsp_value<=scalar_value;
     if(!read_last||read_word!=total_words)rsp_error<=3;
     state<=RESPONSE;
    end
    RESPONSE:if(rsp_ready)state<=IDLE;
    default:begin rsp_error<=255;state<=RESPONSE;end
   endcase
  end
 end
endmodule
