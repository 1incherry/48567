// CPU-free KV path: real FP32 quantization -> private 64-word buffer -> AXI store.
// All non-KV quantization/arithmetic executors remain external.
// Invalid quantization input aborts the token and requires context reset.
module qwen_token_quant_kv_dispatch_v3 #(parameter [31:0] DDR_BASE=32'h80000000,parameter ENABLE_CHECKPOINT=0)(
 input wire checkpoint_enable,checkpoint_resume,input wire [15:0] checkpoint_seq,
 output wire checkpoint_paused,
 output wire [31:0] checkpoint_scale,
 input wire clk,rst_n,start,
 input wire [15:0] start_token,input wire [9:0] start_position,
 input wire start_output_head,start_emit_logits,
 output wire busy,done,error,output wire [9:0] result_position,
 output wire [15:0] result_token,output wire result_token_valid,
 output wire [31:0] debug_control,debug_sequence,
 output wire ext_cmd_valid,input wire ext_cmd_ready,
 output wire [15:0] cmd_seq,cmd_token,output wire [9:0] cmd_position,
 output wire [5:0] cmd_stage,output wire [4:0] cmd_layer,
 output wire [3:0] cmd_head,cmd_op,cmd_src,cmd_dst,
 output wire [15:0] cmd_rows,cmd_cols,cmd_stride_groups,cmd_padding,cmd_vector_offset,
 output wire [31:0] cmd_matrix_offset,cmd_param_offset,
 input wire ext_rsp_valid,output wire ext_rsp_ready,
 input wire [15:0] ext_rsp_seq,ext_rsp_token,input wire ext_rsp_error,
 output wire quant_start,
 input wire quant_input_valid,quant_input_error,output wire quant_input_ready,
 input wire [31:0] quant_input_fp32,input wire quant_input_last,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 assign checkpoint_scale=quant_scale;
 wire base_cmd_valid,base_cmd_ready,base_rsp_valid,base_rsp_ready,base_rsp_error;
 wire [15:0] base_rsp_seq,base_rsp_token;
 // Single exact case of the immutable controller stage, bypassing
 // stage -> command opcode/destination -> owner decode. Unknown stage
 // follows controller default opcode15, hence all internal owners false.
 function automatic [2:0] stage_owner_flags(input [5:0] s);
  case(s)
   3,5,7,23,28,30,34,39,4,6,8,24,29,31,35,16,20,17,21,40:stage_owner_flags=3'b100;
   12,14:stage_owner_flags=3'b010;
   11,13:stage_owner_flags=3'b001;
   default:stage_owner_flags=3'b000;
  endcase
 endfunction
 (* MAX_FANOUT=16 *) wire [2:0] stage_owners=stage_owner_flags(cmd_stage);
 wire is_quant=stage_owners[0];
 reg quant_pending,quant_complete,quant_bad;
 reg [15:0] quant_seq;
 reg [6:0] quant_count;
 (* ram_style="block" *) reg [15:0] quant_words[0:63];
 reg [15:0] kv_read_word;
 reg [31:0] quant_scale;
 reg kv_feed;
 reg [5:0] kv_index;
 wire kv_start,kv_ready;
 wire kv_valid=kv_feed;
 assign ext_cmd_valid=base_cmd_valid&&!is_quant;
 assign base_cmd_ready=is_quant?!quant_pending:ext_cmd_ready;
 assign quant_start=base_cmd_valid&&base_cmd_ready&&is_quant;
 wire quant_ir,quant_out_valid,quant_out_last,quant_protocol_error,quant_domain_error;
 wire [15:0] quant_y,quant_tag;wire [31:0] quant_scale_out;
 wire quant_out_ready=quant_pending&&!quant_complete;
 assign quant_input_ready=quant_ir&&quant_pending&&!quant_complete;
 wire quant_rsp_valid=quant_pending&&(quant_complete||quant_bad||quant_protocol_error||quant_domain_error);
 assign base_rsp_valid=is_quant?quant_rsp_valid:ext_rsp_valid;
 assign base_rsp_error=is_quant?(quant_bad||quant_protocol_error||quant_domain_error):ext_rsp_error;
 assign base_rsp_seq=is_quant?quant_seq:ext_rsp_seq;
 assign base_rsp_token=is_quant?16'd0:ext_rsp_token;
 assign ext_rsp_ready=base_rsp_ready&&!is_quant;
 qwen_quant_fp32_frame_bram_v3 #(.MAX_ELEMENTS(64)) quantizer(.clk,.rst_n,
  .in_valid(quant_input_valid&&quant_pending&&!quant_complete),.in_ready(quant_ir),.x_fp32(quant_input_fp32),
  .in_length(13'd64),.in_padding(13'd64),.in_last(quant_input_last),.in_tag(quant_seq),
  .out_valid(quant_out_valid),.out_ready(quant_out_ready),.result_i16(quant_y),.out_last(quant_out_last),.out_tag(quant_tag),.scale_fp32(quant_scale_out),
  .protocol_error(quant_protocol_error),.domain_error(quant_domain_error));
 qwen_token_kv_dispatch_v1 #(.DDR_BASE(DDR_BASE),.ENABLE_CHECKPOINT(ENABLE_CHECKPOINT)) dispatch(.checkpoint_enable,.checkpoint_resume,.checkpoint_seq,.checkpoint_paused,.clk,.rst_n,.start,.start_token,.start_position,
  .start_output_head,.start_emit_logits,.busy,.done,.error,.result_position,.result_token,.result_token_valid,.debug_control,.debug_sequence,
  .ext_cmd_valid(base_cmd_valid),.ext_cmd_ready(base_cmd_ready),.cmd_seq,.cmd_token,.cmd_position,.cmd_stage,.cmd_layer,.cmd_head,.cmd_op,.cmd_src,.cmd_dst,
  .cmd_rows,.cmd_cols,.cmd_stride_groups,.cmd_padding,.cmd_vector_offset,.cmd_matrix_offset,.cmd_param_offset,
  .ext_rsp_valid(base_rsp_valid),.ext_rsp_ready(base_rsp_ready),.ext_rsp_seq(base_rsp_seq),.ext_rsp_token(base_rsp_token),.ext_rsp_error(base_rsp_error),
  .kv_start,.kv_scale_fp32(quant_scale),.kv_data_valid(kv_valid),.kv_data_ready(kv_ready),.kv_data(kv_read_word),.kv_data_last(kv_index==63),
  .m_axi_awaddr,.m_axi_awlen,.m_axi_awsize,.m_axi_awburst,.m_axi_awvalid,.m_axi_awready,
  .m_axi_wdata,.m_axi_wstrb,.m_axi_wlast,.m_axi_wvalid,.m_axi_wready,.m_axi_bresp,.m_axi_bvalid,.m_axi_bready);
 // Explicit single address port, retaining original procedural-if
 // priority (including unknown start falling through to the next address).
 reg [5:0] kv_prefetch_addr;
 always @* begin
  kv_prefetch_addr=kv_index+6'd1;
  if(kv_start)kv_prefetch_addr=0;
 end
 // Controller retires the quant response before a following KV command.
 // The original kv_start edge primes word zero; each consumed word primes
 // its successor. No new cycle or change to the KV stream handshakes.
 // Data RAM deliberately has no reset; the existing feed/store state owns
 // visibility and is reset immediately by the original reset protocol.
 always @(posedge clk)begin
  if(rst_n&&quant_out_valid&&quant_out_ready&&quant_count<64)
   quant_words[quant_count[5:0]]<=quant_y;
  if(rst_n&&(kv_start||(kv_valid&&kv_ready&&kv_index!=63)))
   kv_read_word<=quant_words[kv_prefetch_addr];
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin quant_pending<=0;quant_complete<=0;quant_bad<=0;quant_seq<=0;quant_count<=0;quant_scale<=0;kv_feed<=0;kv_index<=0;end
  else begin
   if(quant_start)begin quant_pending<=1;quant_complete<=0;quant_bad<=0;quant_seq<=cmd_seq;quant_count<=0;end
   if((quant_pending||quant_start)&&quant_input_error)quant_bad<=1;
   if(quant_out_valid&&quant_out_ready)begin
    if(quant_tag!=quant_seq||quant_count>=64||quant_out_last!=(quant_count==63))quant_bad<=1;
    quant_scale<=quant_scale_out;quant_count<=quant_count+1;
    if(quant_out_last||quant_count==63)quant_complete<=1;
   end
   if(is_quant&&base_rsp_valid&&base_rsp_ready)quant_pending<=0;
   if(kv_start)begin kv_feed<=1;kv_index<=0;end
   if(kv_valid&&kv_ready)begin if(kv_index==63)kv_feed<=0;else kv_index<=kv_index+1;end
  end
 end
endmodule
