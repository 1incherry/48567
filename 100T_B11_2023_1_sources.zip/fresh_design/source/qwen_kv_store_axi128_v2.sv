// Cacheless CPU-free K/V store for the original tiled I16 layout.
// 64 input I16 values. K: 64 aligned 16-byte transactions with two-byte strobes.
// V: two four-beat 16-byte bursts. Scale write follows all successful B responses.
// A response error aborts the token; previously committed bytes are not rolled back.
module qwen_kv_store_axi128_v2 #(
 parameter [31:0] DDR_BASE=32'h80000000,
 parameter [32:0] DDR_BYTES=33'h010000000
)(
 input wire clk,rst_n,
 input wire cmd_valid,output wire cmd_ready,
 input wire cmd_value_layout,
 input wire [9:0] cmd_position,
 input wire [31:0] cmd_matrix_base,cmd_scale_addr,cmd_scale_fp32,
 input wire [15:0] cmd_seq,
 input wire s_valid,output wire s_ready,
 input wire [15:0] s_data,input wire s_last,
 output wire rsp_valid,input wire rsp_ready,
 output reg [7:0] rsp_error,output reg [15:0] rsp_seq,
 output wire busy,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output reg [127:0] m_axi_wdata,output reg [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 localparam IDLE=0,LOAD=1,AW=2,W=3,B=4,RESPONSE=5,VALIDATE=6,SELECT=7,ALIGN=8;
 reg [3:0] state;
 reg prepare_aw;
 reg [127:0] selected_payload;
 reg [31:0] prepared_awaddr;
 reg prepared_wlast;
 reg value_layout,scale_phase,chunk;
 reg [9:0] position;
 reg [31:0] matrix_base,scale_addr,scale_fp32;
 reg [5:0] input_index,write_index;
 reg [1:0] beat;
 reg [15:0] data[0:63];
 wire [32:0] window_end={1'b0,DDR_BASE}+DDR_BYTES;
 wire [31:0] key_offset=(((position>>5)*2+(write_index>>5))*2048)+((write_index&31)*64)+((position&31)*2);
 wire [31:0] value_offset=(chunk?32768:0)+((position>>5)*2048)+((position&31)*64);
 wire [31:0] byte_address=scale_phase?scale_addr:matrix_base+(value_layout?value_offset:key_offset);
 assign cmd_ready=state==IDLE&&rst_n;
 assign s_ready=state==LOAD&&rst_n;
 assign rsp_valid=state==RESPONSE&&rst_n;
 assign busy=state!=IDLE&&state!=RESPONSE;
 assign m_axi_awaddr=prepared_awaddr;
 assign m_axi_awlen=value_layout&&!scale_phase?8'd3:8'd0;
 assign m_axi_awsize=3'd4;assign m_axi_awburst=2'd1;
 assign m_axi_awvalid=state==AW&&rst_n;
 assign m_axi_wvalid=state==W&&rst_n;
 assign m_axi_wlast=prepared_wlast;
 assign m_axi_bready=state==B&&rst_n;
 integer lane;
 // Payload registers deliberately have no reset. Control gates stale/X data.
 // SELECT isolates the 64-word data mux; ALIGN isolates byte placement.
 always @(posedge clk)begin
  if(rst_n&&state==SELECT)begin
   if(scale_phase)selected_payload<={96'b0,scale_fp32};
   else if(value_layout)begin
    for(lane=0;lane<8;lane=lane+1)selected_payload[lane*16 +:16]<=data[(chunk?32:0)+beat*8+lane];
   end else selected_payload<={112'b0,data[write_index]};
  end
  if(rst_n&&state==ALIGN)begin
   prepared_awaddr<=byte_address&32'hfffffff0;
   prepared_wlast<=scale_phase||!value_layout||beat==3;
   if(scale_phase)begin
    m_axi_wdata<=selected_payload<<{scale_addr[3:0],3'b0};
    m_axi_wstrb<=16'h000f<<scale_addr[3:0];
   end else if(value_layout)begin
    m_axi_wdata<=selected_payload;m_axi_wstrb<=16'hffff;
   end else begin
    m_axi_wdata<=selected_payload<<{key_offset[3:0],3'b0};
    m_axi_wstrb<=16'h0003<<key_offset[3:0];
   end
  end
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin prepare_aw<=0;state<=IDLE;value_layout<=0;scale_phase<=0;chunk<=0;position<=0;matrix_base<=0;scale_addr<=0;scale_fp32<=0;input_index<=0;write_index<=0;beat<=0;rsp_error<=0;rsp_seq<=0;end
  else begin
   case(state)
    IDLE:if(cmd_valid&&cmd_ready)begin
     value_layout<=cmd_value_layout;position<=cmd_position;matrix_base<=cmd_matrix_base;scale_addr<=cmd_scale_addr;scale_fp32<=cmd_scale_fp32;rsp_seq<=cmd_seq;
     input_index<=0;write_index<=0;beat<=0;chunk<=0;scale_phase<=0;rsp_error<=0;
     state<=VALIDATE;
    end
    VALIDATE:begin
     if(position>=512||matrix_base[15:0]!=0||scale_addr[1:0]!=0||
        {1'b0,matrix_base}<{1'b0,DDR_BASE}||{1'b0,matrix_base}+33'd65536>window_end||
        {1'b0,scale_addr}<{1'b0,DDR_BASE}||{1'b0,scale_addr}+33'd4>window_end)begin rsp_error<=1;state<=RESPONSE;end
     else state<=LOAD;
    end
    LOAD:if(s_valid&&s_ready)begin
     data[input_index]<=s_data;
     if(s_last!=(input_index==63))begin rsp_error<=2;state<=RESPONSE;end
     else if(input_index==63)begin state<=SELECT;prepare_aw<=1;beat<=0;end
     else input_index<=input_index+1;
    end
    SELECT:state<=ALIGN;
    ALIGN:state<=prepare_aw?AW:W;
    AW:if(m_axi_awvalid&&m_axi_awready)begin state<=W;beat<=0;end
    W:if(m_axi_wvalid&&m_axi_wready)begin
     if(m_axi_wlast)state<=B;
     else begin beat<=beat+1;prepare_aw<=0;state<=SELECT;end
    end
    B:if(m_axi_bvalid&&m_axi_bready)begin
     if(m_axi_bresp!=0)begin rsp_error<=3;state<=RESPONSE;end
     else if(scale_phase)state<=RESPONSE;
     else if(value_layout&&!chunk)begin chunk<=1;beat<=0;prepare_aw<=1;state<=SELECT;end
     else if(!value_layout&&write_index<63)begin write_index<=write_index+1;beat<=0;prepare_aw<=1;state<=SELECT;end
     else begin scale_phase<=1;beat<=0;prepare_aw<=1;state<=SELECT;end
    end
    RESPONSE:if(rsp_ready)state<=IDLE;
    default:begin state<=RESPONSE;rsp_error<=4;end
   endcase
  end
 end
endmodule
