// Exact arithmetic of original C embedding: signed W4 * half(scale).
// Original C half() ignores bit15 and treats exponent31 as a finite exponent;
// this matches that storage codec, not a general IEEE binary16 converter.
// Product has at most15 significant bits: binary32 needs no rounding here.
module qwen_embedding_w4_half_fp32_v1(
 input wire signed [3:0] weight_i4,
 input wire [15:0] scale_half,
 output reg [31:0] result_fp32
);
 reg [3:0] magnitude;
 reg [10:0] significand;
 reg [14:0] product;
 reg [7:0] exponent;
 reg [23:0] normalized;
 integer highest,bit_index;
 always @* begin
  magnitude=weight_i4[3]?(~weight_i4+4'd1):weight_i4;
  significand=scale_half[14:10]==0?{1'b0,scale_half[9:0]}:{1'b1,scale_half[9:0]};
  product=magnitude*significand;
  highest=0;
  for(bit_index=0;bit_index<15;bit_index=bit_index+1)
   if(product[bit_index])highest=bit_index;
  exponent=(scale_half[14:10]==0?103:102+scale_half[14:10])+highest;
  normalized={9'b0,product}<<(23-highest);
  result_fp32=product==0?{weight_i4[3],31'd0}:{weight_i4[3],exponent,normalized[22:0]};
 end
endmodule
