`timescale 1ns/1ps
// Independent successor; original side-only barrier remains frozen.
// All *_100 fields are real accepted local owners,not CDC busy estimates.
module mcs_host_transport_barrier_main100_r3(
 input wire host_clk,source_clk,board_reset_n,
 input wire freeze_precommit,freeze_disable,freeze_main,main_close,independent_fault100,
 input wire normal_write_busy,normal_read_busy,host_write_busy,host_read_busy,
 input wire side_transport_pending,side_metadata_valid,
 input wire[31:0]side_address,side_data,input wire[3:0]side_strb,input wire other_quiet100,
 input wire normal_write_owner_cpu,normal_write_done,normal_write_first_seen,normal_write_lock,
 input wire[31:0]normal_write_address,normal_write_data,input wire[7:0]normal_write_len,
 input wire[2:0]normal_write_size,input wire[1:0]normal_write_burst,input wire[3:0]normal_write_strb,input wire normal_write_last,
 input wire host_write_boot,input wire[31:0]host_write_address,input wire[7:0]host_write_len,
 output wire host_new_admit100,source_drain_ack,source_drain_fault,source_release_permit,
 output wire source_main_retired,source_main_owner_cpu,source_main_closed_ack,output reg main_closed100,
 output reg ack100,protocol_fault,output wire exact_self_excluded,output wire main_fence_active100,
 output reg main_identity_seen,main_write_retired100,output wire main_fully_retired100);
 (* ASYNC_REG="TRUE" *)reg[2:0]pre_sync,disable_sync,main_sync,allow_sync,ack_sync,fault_sync,retired_sync,cpu_sync,close_sync,closed_ack_sync;
 reg[1:0]quiet_history;reg main_owner_cpu;
 (* ASYNC_REG="TRUE" *)reg[2:0]release_permit;
 always@(posedge source_clk or negedge board_reset_n or posedge protocol_fault)
 if(!board_reset_n||protocol_fault)release_permit<=0;else release_permit<={release_permit[1:0],1'b1};
 assign source_release_permit=release_permit[2];
 wire raw_freeze=freeze_precommit||freeze_disable||freeze_main;
 always@(posedge host_clk or negedge board_reset_n)
 if(!board_reset_n)begin pre_sync<=0;disable_sync<=0;main_sync<=0;close_sync<=0;end
 else begin pre_sync<={pre_sync[1:0],freeze_precommit};disable_sync<={disable_sync[1:0],freeze_disable};main_sync<={main_sync[1:0],freeze_main};close_sync<={close_sync[1:0],main_close};end
 always@(posedge host_clk or negedge board_reset_n or posedge raw_freeze)
 if(!board_reset_n||raw_freeze)allow_sync<=0;else allow_sync<={allow_sync[1:0],1'b1};
 always@(posedge source_clk or negedge board_reset_n)
 if(!board_reset_n)begin ack_sync<=0;fault_sync<=0;retired_sync<=0;cpu_sync<=0;closed_ack_sync<=0;end
 else begin ack_sync<={ack_sync[1:0],ack100};fault_sync<={fault_sync[1:0],protocol_fault};retired_sync<={retired_sync[1:0],main_fully_retired100};cpu_sync<={cpu_sync[1:0],main_owner_cpu};closed_ack_sync<={closed_ack_sync[1:0],main_closed100};end
 wire pre=pre_sync[2],dis=disable_sync[2],main=main_sync[2];
 wire single_mode=(pre&&!dis&&!main)||(!pre&&dis&&!main)||(!pre&&!dis&&main);
 wire any_mode=pre||dis||main;
 wire exact_pre=side_metadata_valid&&side_strb==15&&((side_address==32'h41000080&&side_data==32'h51574d31)||(side_address==32'h41000084&&side_data==1));
 wire exact_disable=side_metadata_valid&&side_strb==15&&side_address==32'h41000084&&side_data==0;
 wire exact_main_geometry=normal_write_first_seen&&normal_write_address==32'h41000034&&normal_write_len==0&&normal_write_size==2&&(normal_write_burst==0||normal_write_burst==1)&&!normal_write_lock&&normal_write_data==2&&normal_write_strb==15&&normal_write_last;
 wire main_host_matches=!host_write_boot&&host_write_address==32'h41000034&&host_write_len==0;
 wire main_owner_matches=normal_write_busy&&exact_main_geometry&&normal_write_owner_cpu==main_owner_cpu;
 wire main_self=main&&main_identity_seen&&(!normal_write_busy||main_owner_matches);
 wire side_self=(pre&&exact_pre)||(dis&&exact_disable);
 assign exact_self_excluded=single_mode&&(main?main_self:side_self);
 wire side_quiet=side_transport_pending&&side_self&&other_quiet100&&!normal_write_busy&&!normal_read_busy&&!host_read_busy;
 wire main_quiet=main_identity_seen&&other_quiet100&&!normal_read_busy&&!host_read_busy&&!side_transport_pending&&
   (!normal_write_busy||main_owner_matches)&&(!host_write_busy||(!main_owner_cpu&&main_host_matches));
 wire real_quiet=main?main_quiet:side_quiet;
 assign host_new_admit100=allow_sync[2]&&!protocol_fault;
 assign source_drain_ack=ack_sync[2];assign source_drain_fault=fault_sync[2];
 assign main_fence_active100=main;
 assign main_fully_retired100=main&&main_identity_seen&&main_write_retired100&&(main_owner_cpu||!host_write_busy);
 assign source_main_retired=retired_sync[2];assign source_main_owner_cpu=cpu_sync[2];assign source_main_closed_ack=closed_ack_sync[2];
 always@(posedge host_clk or negedge board_reset_n)begin
 if(!board_reset_n)begin main_closed100<=0;ack100<=0;protocol_fault<=0;quiet_history<=0;main_identity_seen<=0;main_write_retired100<=0;main_owner_cpu<=0;end
 else begin
  if(independent_fault100)protocol_fault<=1;
  if(!main)begin main_closed100<=0;main_identity_seen<=0;main_write_retired100<=0;main_owner_cpu<=0;end
  else if(!main_identity_seen)begin
   if(normal_write_busy&&exact_main_geometry)begin
    main_identity_seen<=1;main_owner_cpu<=normal_write_owner_cpu;
    // A second accepted host write behind the current CPU release cannot
    // drain while its B is withheld. Fail before serial release,never ignore it.
    if(host_write_busy&&(normal_write_owner_cpu||!main_host_matches))protocol_fault<=1;
   end else protocol_fault<=1;
  end else begin if(normal_write_done)main_write_retired100<=1;if(close_sync[2])main_closed100<=1;end
  if(!single_mode)begin ack100<=0;quiet_history<=0;if(any_mode)protocol_fault<=1;end
  else if(protocol_fault)begin ack100<=0;quiet_history<=0;end
  else begin
   quiet_history<={quiet_history[0],real_quiet};
   // The explicit POSTCOMMIT handshake closes qualification before the CSR
   // is allowed to produce B. Track only the original latched retirement;
   // an immediately following CPU request must not be mistaken for the old job.
   if(main&&main_closed100)begin end
   else if(ack100&&!real_quiet)begin protocol_fault<=1;ack100<=0;end
   else if(real_quiet&&(&quiet_history))ack100<=1;
  end
 end end
endmodule
