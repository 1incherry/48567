`timescale 1ns/1ps
// Decode abs(x)*128 into the exact table index and binary32 fractional part.
// Supports all finite binary32 inputs, including subnormals. The above32 flag
// selects exp(-abs(x))=0; exactly32 selects table[4096]. No approximate cast.
// Three registered stages, II1, common CE for pipeline/backpressure alignment.
module qwen_exp_fp32_decode_pipeline(
 input wire clk,rst_n,ce,in_valid,
 input wire [31:0] x_fp32,
 output reg out_valid,
 output reg [12:0] index,
 output reg [31:0] fraction_fp32,
 output reg above32,nonfinite
);
 reg stage_valid,stage_above,stage_nonfinite;
 reg [31:0] scaled;
 reg split_valid,split_above,split_nonfinite,split_integer;
 reg [12:0] split_index;reg [23:0] split_tail;reg [4:0] split_shift;reg [31:0] split_small;
 function automatic [31:0] scale128(input [31:0] x);
  integer k,h;reg [30:0] mant;reg [7:0] e;reg [22:0] f;
  begin
   if(x[30:23]!=0)begin e=x[30:23]+8'd7;scale128={1'b0,e,x[22:0]};end
   else if(x[22:0]==0)scale128=0;
   else begin
    h=0;for(k=0;k<23;k=k+1)if(x[k])h=k;
    if(h<16)scale128={1'b0,8'd0,x[22:0]<<7};
    else begin e=h-15;mant={8'd0,x[22:0]}<<(23-h);f=mant[22:0];scale128={1'b0,e,f};end
   end
  end
 endfunction
 function automatic [31:0] normalize_tail(input [23:0] tail,input [4:0] shift);
  integer k,h;reg [7:0] e;reg [23:0] m;
  begin
   normalize_tail=0;
   if(tail!=0)begin
    h=0;for(k=0;k<24;k=k+1)if(tail[k])h=k;
    e=h-shift+127;m=tail<<(23-h);normalize_tail={1'b0,e,m[22:0]};
   end
  end
 endfunction
 wire [4:0] shift_now=5'd23-(scaled[30:23]-8'd127);
 wire [23:0] mant_now={1'b1,scaled[22:0]};
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin split_valid<=0;split_above<=0;split_nonfinite<=0;split_integer<=0;split_index<=0;split_tail<=0;split_shift<=0;split_small<=0;stage_valid<=0;scaled<=0;stage_above<=0;stage_nonfinite<=0;out_valid<=0;index<=0;fraction_fp32<=0;above32<=0;nonfinite<=0;end
  else if(ce)begin
   stage_valid<=in_valid;
   stage_above<=x_fp32[30:0]>31'h42000000;stage_nonfinite<=x_fp32[30:23]==8'hff;
   scaled<=x_fp32[30:0]>31'h42000000 ? 32'h45800000 : scale128(x_fp32);
   split_valid<=stage_valid;split_above<=stage_above;split_nonfinite<=stage_nonfinite;
   split_integer<=scaled[30:23]>=127;split_small<=scaled;split_shift<=shift_now;
   split_index<=scaled[30:23]>=127 ? mant_now>>shift_now : 13'd0;
   split_tail<=mant_now&((24'd1<<shift_now)-1'b1);
   out_valid<=split_valid;index<=split_index;
   fraction_fp32<=split_integer?normalize_tail(split_tail,split_shift):split_small;
   above32<=split_above;nonfinite<=split_nonfinite;
  end
 end
endmodule
