`timescale 1ns/1ps
// Production transport only; no memory,CPU,or response fixture.
// Accepted owners survive CPU reset/epoch loss; only board_reset_n resets transport.
module qwen_shared_control_transport_r1(
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWID" *) input wire h_awid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWADDR" *) input wire [31:0] h_awaddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWLEN" *) input wire [7:0] h_awlen,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWSIZE" *) input wire [2:0] h_awsize,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWBURST" *) input wire [1:0] h_awburst,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWLOCK" *) input wire h_awlock,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWCACHE" *) input wire [3:0] h_awcache,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWPROT" *) input wire [2:0] h_awprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWQOS" *) input wire [3:0] h_awqos,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWVALID" *) input wire h_awvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI AWREADY" *) output wire h_awready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI WDATA" *) input wire [31:0] h_wdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI WSTRB" *) input wire [3:0] h_wstrb,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI WLAST" *) input wire h_wlast,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI WVALID" *) input wire h_wvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI WREADY" *) output wire h_wready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI BID" *) output wire h_bid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI BRESP" *) output wire [1:0] h_bresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI BVALID" *) output wire h_bvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI BREADY" *) input wire h_bready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARID" *) input wire h_arid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARADDR" *) input wire [31:0] h_araddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARLEN" *) input wire [7:0] h_arlen,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARSIZE" *) input wire [2:0] h_arsize,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARBURST" *) input wire [1:0] h_arburst,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARLOCK" *) input wire h_arlock,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARCACHE" *) input wire [3:0] h_arcache,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARPROT" *) input wire [2:0] h_arprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARQOS" *) input wire [3:0] h_arqos,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARVALID" *) input wire h_arvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI ARREADY" *) output wire h_arready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI RDATA" *) output wire [31:0] h_rdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI RID" *) output wire h_rid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI RRESP" *) output wire [1:0] h_rresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI RLAST" *) output wire h_rlast,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI RVALID" *) output wire h_rvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 H_AXI RREADY" *) input wire h_rready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI AWADDR" *) input wire [31:0] c_awaddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI AWPROT" *) input wire [2:0] c_awprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI AWVALID" *) input wire c_awvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI AWREADY" *) output wire c_awready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI WDATA" *) input wire [31:0] c_wdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI WSTRB" *) input wire [3:0] c_wstrb,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI WVALID" *) input wire c_wvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI WREADY" *) output wire c_wready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI BRESP" *) output wire [1:0] c_bresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI BVALID" *) output wire c_bvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI BREADY" *) input wire c_bready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI ARADDR" *) input wire [31:0] c_araddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI ARPROT" *) input wire [2:0] c_arprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI ARVALID" *) input wire c_arvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI ARREADY" *) output wire c_arready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI RDATA" *) output wire [31:0] c_rdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI RRESP" *) output wire [1:0] c_rresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI RVALID" *) output wire c_rvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 C_AXI RREADY" *) input wire c_rready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWID" *) output wire m_awid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWADDR" *) output wire [31:0] m_awaddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWLEN" *) output wire [7:0] m_awlen,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWSIZE" *) output wire [2:0] m_awsize,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWBURST" *) output wire [1:0] m_awburst,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWLOCK" *) output wire m_awlock,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWCACHE" *) output wire [3:0] m_awcache,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWPROT" *) output wire [2:0] m_awprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWQOS" *) output wire [3:0] m_awqos,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWVALID" *) output wire m_awvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWREADY" *) input wire m_awready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WDATA" *) output wire [31:0] m_wdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WSTRB" *) output wire [3:0] m_wstrb,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WLAST" *) output wire m_wlast,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WVALID" *) output wire m_wvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WREADY" *) input wire m_wready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BID" *) input wire m_bid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BRESP" *) input wire [1:0] m_bresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BVALID" *) input wire m_bvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BREADY" *) output wire m_bready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARID" *) output wire m_arid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARADDR" *) output wire [31:0] m_araddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARLEN" *) output wire [7:0] m_arlen,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARSIZE" *) output wire [2:0] m_arsize,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARBURST" *) output wire [1:0] m_arburst,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARLOCK" *) output wire m_arlock,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARCACHE" *) output wire [3:0] m_arcache,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARPROT" *) output wire [2:0] m_arprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARQOS" *) output wire [3:0] m_arqos,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARVALID" *) output wire m_arvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARREADY" *) input wire m_arready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RDATA" *) input wire [31:0] m_rdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RID" *) input wire m_rid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RRESP" *) input wire [1:0] m_rresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RLAST" *) input wire m_rlast,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RVALID" *) input wire m_rvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RREADY" *) output wire m_rready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI AWADDR" *) output wire [31:0] b_awaddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI AWPROT" *) output wire [2:0] b_awprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI AWVALID" *) output wire b_awvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI AWREADY" *) input wire b_awready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI WDATA" *) output wire [31:0] b_wdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI WSTRB" *) output wire [3:0] b_wstrb,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI WVALID" *) output wire b_wvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI WREADY" *) input wire b_wready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI BRESP" *) input wire [1:0] b_bresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI BVALID" *) input wire b_bvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI BREADY" *) output wire b_bready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI ARADDR" *) output wire [31:0] b_araddr,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI ARPROT" *) output wire [2:0] b_arprot,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI ARVALID" *) output wire b_arvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI ARREADY" *) input wire b_arready,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI RDATA" *) input wire [31:0] b_rdata,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI RRESP" *) input wire [1:0] b_rresp,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI RVALID" *) input wire b_rvalid,
(* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 B_AXI RREADY" *) output wire b_rready,
(* X_INTERFACE_INFO="xilinx.com:signal:clock:1.0 host_clk CLK", X_INTERFACE_PARAMETER="XIL_INTERFACENAME host_clk, FREQ_HZ 100000000, ASSOCIATED_BUSIF H_AXI:C_AXI:M_AXI:B_AXI, ASSOCIATED_RESET board_reset_n" *) input wire host_clk,
(* X_INTERFACE_INFO="xilinx.com:signal:clock:1.0 source_clk CLK", X_INTERFACE_PARAMETER="XIL_INTERFACENAME source_clk, FREQ_HZ 125000000, ASSOCIATED_RESET board_reset_n" *) input wire source_clk,
(* X_INTERFACE_INFO="xilinx.com:signal:reset:1.0 board_reset_n RST", X_INTERFACE_PARAMETER="XIL_INTERFACENAME board_reset_n, POLARITY ACTIVE_LOW" *) input wire board_reset_n,
input wire freeze_precommit,
input wire freeze_disable,
input wire side_retire_ack,
output wire side_retire_req,
input wire main_start,
input wire main_prepare,
input wire main_response_consumed,
output wire main_ready,
output wire main_qualified,
output wire main_good,
output wire main_fault,
output wire main_closed_ack,
output wire main_active,
input wire qualify_start,
output wire qualify_ready,
output wire qualify_done,
output wire qualify_good,
output wire qualify_fault,
input wire independent_fault100,
input wire other_quiet100,
input wire release_completion_toggle50,
input wire release_owned50,
output wire release_owned125,
output wire trusted_stop100,
output wire trusted_stop125,
output wire drain_ack125,
output wire drain_fault125,
output wire release_permit125,
output wire transport_fault100
);
wire  ack100;
wire  arb_protocol_fault;
wire  arb_quiescent;
wire [31:0] arb_rd_addr;
wire  arb_rd_done;
wire  arb_rd_id;
wire [7:0] arb_rd_len;
wire  arb_rd_owner;
wire [31:0] arb_wr_addr;
wire [1:0] arb_wr_burst;
wire  arb_wr_done;
wire [31:0] arb_wr_first_data;
wire  arb_wr_first_last;
wire  arb_wr_first_seen;
wire [3:0] arb_wr_first_strb;
wire  arb_wr_id;
wire  arb_wr_is_034_candidate;
wire  arb_wr_is_release;
wire [7:0] arb_wr_len;
wire  arb_wr_owner;
wire [2:0] arb_wr_size;
wire  bfault100;
wire  hostadmit;
wire  hostrp;
wire  hostwp;
wire  identityfault;
wire  identityvalid;
wire  main100;
wire  mainClose;
wire  mainClosed100;
wire  mainCpuOwner;
wire  mainFreeze;
wire  mainFullRetired;
wire  mainID;
wire  mainRetired;
wire  mainWrRetired;
wire [31:0] metaaddr;
wire [31:0] metadata;
wire [3:0] metastrb;
wire [31:0] n_araddr;
wire [1:0] n_arburst;
wire [3:0] n_arcache;
wire  n_arid;
wire [7:0] n_arlen;
wire  n_arlock;
wire [2:0] n_arprot;
wire [3:0] n_arqos;
wire  n_arready;
wire [2:0] n_arsize;
wire  n_arvalid;
wire [31:0] n_awaddr;
wire [1:0] n_awburst;
wire [3:0] n_awcache;
wire  n_awid;
wire [7:0] n_awlen;
wire  n_awlock;
wire [2:0] n_awprot;
wire [3:0] n_awqos;
wire  n_awready;
wire [2:0] n_awsize;
wire  n_awvalid;
wire  n_bid;
wire  n_bready;
wire [1:0] n_bresp;
wire  n_bvalid;
wire [31:0] n_rdata;
wire  n_rid;
wire  n_rlast;
wire  n_rready;
wire [1:0] n_rresp;
wire  n_rvalid;
wire [31:0] n_wdata;
wire  n_wlast;
wire  n_wready;
wire [3:0] n_wstrb;
wire  n_wvalid;
wire  normal_rbusy;
wire  normal_wbusy;
wire  retadmit;
wire  retcomplete;
wire  retfault;
wire  retpending;
wire [1:0] retstate;
wire  seenaw;
wire  seenw;
wire  selfexclude;
wire  split_dis_candidate;
wire  split_fault;
wire  split_quiet;
wire  split_rboot;
wire [31:0] split_wa;
wire  split_wboot;
wire [7:0] split_wlen;
 (* ASYNC_REG="TRUE" *)reg[2:0]release_toggle_sync,release_owned_sync,trusted_stop_sync;
 always@(posedge source_clk or negedge board_reset_n)
 if(!board_reset_n)begin release_toggle_sync<=0;release_owned_sync<=0;trusted_stop_sync<=0;end
 else begin release_toggle_sync<={release_toggle_sync[1:0],release_completion_toggle50};release_owned_sync<={release_owned_sync[1:0],release_owned50};trusted_stop_sync<={trusted_stop_sync[1:0],trusted_stop100};end
 assign release_owned125=release_owned_sync[2];assign trusted_stop125=trusted_stop_sync[2];
 assign transport_fault100=arb_protocol_fault||split_fault||retfault||identityfault||bfault100;
 wire awacc=b_awvalid&&b_awready,wacc=b_wvalid&&b_wready,bcons=h_bvalid&&h_bready&&split_wboot;

qwen_jtag_boot_split32 actual_splitter(.clk(host_clk),.board_reset_n(board_reset_n),.normal_aw_admit(hostadmit),.normal_ar_admit(hostadmit),.boot_aw_admit(hostadmit&&retadmit),.boot_ar_admit(hostadmit),.wr_pending(hostwp),.rd_pending(hostrp),.quiescent(split_quiet),.protocol_fault(split_fault),.wr_addr(split_wa),.wr_len(split_wlen),.wr_boot_disable(split_dis_candidate),.wr_boot(split_wboot),.rd_boot(split_rboot),.h_awid(h_awid),.h_awaddr(h_awaddr),.h_awlen(h_awlen),.h_awsize(h_awsize),.h_awburst(h_awburst),.h_awlock(h_awlock),.h_awcache(h_awcache),.h_awprot(h_awprot),.h_awqos(h_awqos),.h_awvalid(h_awvalid),.h_awready(h_awready),.h_wdata(h_wdata),.h_wstrb(h_wstrb),.h_wlast(h_wlast),.h_wvalid(h_wvalid),.h_wready(h_wready),.h_bid(h_bid),.h_bresp(h_bresp),.h_bvalid(h_bvalid),.h_bready(h_bready),.h_arid(h_arid),.h_araddr(h_araddr),.h_arlen(h_arlen),.h_arsize(h_arsize),.h_arburst(h_arburst),.h_arlock(h_arlock),.h_arcache(h_arcache),.h_arprot(h_arprot),.h_arqos(h_arqos),.h_arvalid(h_arvalid),.h_arready(h_arready),.h_rid(h_rid),.h_rdata(h_rdata),.h_rresp(h_rresp),.h_rlast(h_rlast),.h_rvalid(h_rvalid),.h_rready(h_rready),.n_awid(n_awid),.n_awaddr(n_awaddr),.n_awlen(n_awlen),.n_awsize(n_awsize),.n_awburst(n_awburst),.n_awlock(n_awlock),.n_awcache(n_awcache),.n_awprot(n_awprot),.n_awqos(n_awqos),.n_awvalid(n_awvalid),.n_awready(n_awready),.n_wdata(n_wdata),.n_wstrb(n_wstrb),.n_wlast(n_wlast),.n_wvalid(n_wvalid),.n_wready(n_wready),.n_bid(n_bid),.n_bresp(n_bresp),.n_bvalid(n_bvalid),.n_bready(n_bready),.n_arid(n_arid),.n_araddr(n_araddr),.n_arlen(n_arlen),.n_arsize(n_arsize),.n_arburst(n_arburst),.n_arlock(n_arlock),.n_arcache(n_arcache),.n_arprot(n_arprot),.n_arqos(n_arqos),.n_arvalid(n_arvalid),.n_arready(n_arready),.n_rid(n_rid),.n_rdata(n_rdata),.n_rresp(n_rresp),.n_rlast(n_rlast),.n_rvalid(n_rvalid),.n_rready(n_rready),.b_awaddr(b_awaddr),.b_awprot(b_awprot),.b_awvalid(b_awvalid),.b_awready(b_awready),.b_wdata(b_wdata),.b_wstrb(b_wstrb),.b_wvalid(b_wvalid),.b_wready(b_wready),.b_bresp(b_bresp),.b_bvalid(b_bvalid),.b_bready(b_bready),.b_araddr(b_araddr),.b_arprot(b_arprot),.b_arvalid(b_arvalid),.b_arready(b_arready),.b_rdata(b_rdata),.b_rresp(b_rresp),.b_rvalid(b_rvalid),.b_rready(b_rready));
axi32_loader_runtime_arbiter_r1 actual_arbiter(.clk(host_clk),.board_reset_n(board_reset_n),.h_new_aw_admit(1'b1),.h_new_ar_admit(1'b1),.c_new_aw_admit(1'b1),.c_new_ar_admit(1'b1),.h_awid(n_awid),.h_awaddr(n_awaddr),.h_awlen(n_awlen),.h_awsize(n_awsize),.h_awburst(n_awburst),.h_awlock(n_awlock),.h_awcache(n_awcache),.h_awprot(n_awprot),.h_awqos(n_awqos),.h_awvalid(n_awvalid),.h_awready(n_awready),.h_arid(n_arid),.h_araddr(n_araddr),.h_arlen(n_arlen),.h_arsize(n_arsize),.h_arburst(n_arburst),.h_arlock(n_arlock),.h_arcache(n_arcache),.h_arprot(n_arprot),.h_arqos(n_arqos),.h_arvalid(n_arvalid),.h_arready(n_arready),.h_wdata(n_wdata),.h_wstrb(n_wstrb),.h_wlast(n_wlast),.h_wvalid(n_wvalid),.h_wready(n_wready),.h_bid(n_bid),.h_bresp(n_bresp),.h_bvalid(n_bvalid),.h_bready(n_bready),.h_rid(n_rid),.h_rdata(n_rdata),.h_rresp(n_rresp),.h_rlast(n_rlast),.h_rvalid(n_rvalid),.h_rready(n_rready),.c_awaddr(c_awaddr),.c_awprot(c_awprot),.c_awvalid(c_awvalid),.c_awready(c_awready),.c_araddr(c_araddr),.c_arprot(c_arprot),.c_arvalid(c_arvalid),.c_arready(c_arready),.c_wdata(c_wdata),.c_wstrb(c_wstrb),.c_wvalid(c_wvalid),.c_wready(c_wready),.c_bresp(c_bresp),.c_bvalid(c_bvalid),.c_bready(c_bready),.c_rdata(c_rdata),.c_rresp(c_rresp),.c_rvalid(c_rvalid),.c_rready(c_rready),.m_awid(m_awid),.m_awaddr(m_awaddr),.m_awlen(m_awlen),.m_awsize(m_awsize),.m_awburst(m_awburst),.m_awlock(m_awlock),.m_awcache(m_awcache),.m_awprot(m_awprot),.m_awqos(m_awqos),.m_awvalid(m_awvalid),.m_awready(m_awready),.m_arid(m_arid),.m_araddr(m_araddr),.m_arlen(m_arlen),.m_arsize(m_arsize),.m_arburst(m_arburst),.m_arlock(m_arlock),.m_arcache(m_arcache),.m_arprot(m_arprot),.m_arqos(m_arqos),.m_arvalid(m_arvalid),.m_arready(m_arready),.m_wdata(m_wdata),.m_wstrb(m_wstrb),.m_wlast(m_wlast),.m_wvalid(m_wvalid),.m_wready(m_wready),.m_bid(m_bid),.m_bresp(m_bresp),.m_bvalid(m_bvalid),.m_bready(m_bready),.m_rid(m_rid),.m_rdata(m_rdata),.m_rresp(m_rresp),.m_rlast(m_rlast),.m_rvalid(m_rvalid),.m_rready(m_rready),.wr_busy(normal_wbusy),.rd_busy(normal_rbusy),.wr_owner(arb_wr_owner),.rd_owner(arb_rd_owner),.wr_addr(arb_wr_addr),.rd_addr(arb_rd_addr),.wr_len(arb_wr_len),.rd_len(arb_rd_len),.wr_id(arb_wr_id),.rd_id(arb_rd_id),.wr_size(arb_wr_size),.wr_burst(arb_wr_burst),.wr_first_seen(arb_wr_first_seen),.wr_first_data(arb_wr_first_data),.wr_first_strb(arb_wr_first_strb),.wr_first_last(arb_wr_first_last),.wr_done(arb_wr_done),.rd_done(arb_rd_done),.protocol_fault(arb_protocol_fault),.wr_is_034_candidate(arb_wr_is_034_candidate),.wr_is_release(arb_wr_is_release),.quiescent(arb_quiescent));
mcs_release_geometry_qualifier geometry(.source_clk(source_clk),.host_clk(host_clk),.board_reset_n(board_reset_n),.source_start(qualify_start),.source_ready(qualify_ready),.source_done(qualify_done),.source_good(qualify_good),.source_fault(qualify_fault),.wr_busy(normal_wbusy),.wr_first_seen(arb_wr_first_seen),.wr_protocol_fault(arb_protocol_fault),.wr_lock(m_awlock),.wr_addr(arb_wr_addr),.wr_first_data(arb_wr_first_data),.wr_len(arb_wr_len),.wr_size(arb_wr_size),.wr_burst(arb_wr_burst),.wr_first_strb(arb_wr_first_strb),.wr_first_last(arb_wr_first_last));
mcs_main_release_fence125_r3 mainfence(.clk(source_clk),.board_reset_n(board_reset_n),.start(main_start),.ready(main_ready),.qualify_done(main_qualified),.qualify_good(main_good),.drain_ack(drain_ack125),.drain_fault(drain_fault125),.main_retired(mainRetired),.owner_cpu(mainCpuOwner),.this_response_consumed(main_response_consumed),.io_completion_toggle(release_toggle_sync[2]),.prepare_response(main_prepare),.closed_ack(main_closed_ack),.close_main(mainClose),.freeze_main(mainFreeze),.fault(main_fault),.active(main_active));
mcs_trusted_stop_intent100 emergency(.clk(host_clk),.board_reset_n(board_reset_n),.main_fence_active(main100),.h_awid(h_awid),.h_awaddr(h_awaddr),.h_awlen(h_awlen),.h_awsize(h_awsize),.h_awburst(h_awburst),.h_awlock(h_awlock),.h_awcache(4'd0),.h_awprot(3'd0),.h_awqos(4'd0),.h_awvalid(h_awvalid),.h_awready(h_awready),.h_wdata(h_wdata),.h_wstrb(h_wstrb),.h_wlast(h_wlast),.h_wvalid(h_wvalid),.h_wready(h_wready),.stop_latched(trusted_stop100));
mcs_boot_side_identity100 identity(.clk(host_clk),.board_reset_n(board_reset_n),.aw_accepted(awacc),.awaddr(b_awaddr),.w_accepted(wacc),.wdata(b_wdata),.wstrb(b_wstrb),.retire_complete(retcomplete),.seen_aw(seenaw),.seen_w(seenw),.address(metaaddr),.data(metadata),.strb(metastrb),.protocol_fault(identityfault),.valid(identityvalid));
mcs_boot_retire_cdc retire(.host_clk(host_clk),.source_clk(source_clk),.board_reset_n(board_reset_n),.side_aw_accepted(awacc),.side_w_accepted(wacc),.host_b_consumed(bcons),.source_retire_ack(side_retire_ack),.source_retire_req(side_retire_req),.new_boot_write_admit(retadmit),.pending(retpending),.completed(retcomplete),.protocol_fault(retfault),.host_state(retstate));
mcs_host_transport_barrier_main100_r3 barrier(.host_clk(host_clk),.source_clk(source_clk),.board_reset_n(board_reset_n),.freeze_precommit(freeze_precommit),.freeze_disable(freeze_disable),.freeze_main(mainFreeze),.main_close(mainClose),.independent_fault100(independent_fault100||arb_protocol_fault||split_fault||retfault||identityfault),.source_release_permit(release_permit125),.source_main_closed_ack(main_closed_ack),.main_closed100(mainClosed100),.normal_write_busy(normal_wbusy),.normal_read_busy(normal_rbusy),.host_write_busy(hostwp),.host_read_busy(hostrp),.side_transport_pending(retpending),.side_metadata_valid(identityvalid),.side_address(metaaddr),.side_data(metadata),.side_strb(metastrb),.other_quiet100(other_quiet100),.normal_write_owner_cpu(arb_wr_owner),.normal_write_done(arb_wr_done),.normal_write_first_seen(arb_wr_first_seen),.normal_write_lock(m_awlock),.normal_write_address(arb_wr_addr),.normal_write_data(arb_wr_first_data),.normal_write_len(arb_wr_len),.normal_write_size(arb_wr_size),.normal_write_burst(arb_wr_burst),.normal_write_strb(arb_wr_first_strb),.normal_write_last(arb_wr_first_last),.host_write_boot(split_wboot),.host_write_address(split_wa),.host_write_len(split_wlen),.source_main_retired(mainRetired),.source_main_owner_cpu(mainCpuOwner),.main_fence_active100(main100),.main_identity_seen(mainID),.main_write_retired100(mainWrRetired),.main_fully_retired100(mainFullRetired),.host_new_admit100(hostadmit),.source_drain_ack(drain_ack125),.source_drain_fault(drain_fault125),.ack100(ack100),.protocol_fault(bfault100),.exact_self_excluded(selfexclude));
endmodule
