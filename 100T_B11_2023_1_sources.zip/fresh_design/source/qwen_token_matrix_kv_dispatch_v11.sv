// Candidate CPU-free scheduler + live GEMV/post + live KV quantization/store.
// Other operators use the external executor port and its auxiliary AXI master.
// Commands are serialized. No owner switches until the executor response,
// which must follow all accepted AXI transactions and final write responses.
// External QUANT->X returns its real scale with the same tagged response.
module qwen_token_matrix_kv_dispatch_v11 #(parameter [31:0] DDR_BASE=32'h80000000,parameter ENABLE_CHECKPOINT=0)(
 input wire checkpoint_enable,checkpoint_resume,input wire [15:0] checkpoint_seq,
 output wire checkpoint_paused,
 output wire [31:0] checkpoint_scale,
 input wire clk,rst_n,start,
 input wire [15:0] start_token,input wire [9:0] start_position,
 input wire start_output_head,start_emit_logits,
 output wire busy,done,error,output wire [9:0] result_position,
 output wire [15:0] result_token,output wire result_token_valid,
 output wire [31:0] debug_control,debug_sequence,
 output wire [287:0] debug_gemv_profile,
 output wire diagnostic_matrix_rsp_valid,diagnostic_matrix_rsp_ready,
 output wire [15:0] diagnostic_matrix_rsp_seq,
 output wire [7:0] diagnostic_matrix_rsp_error,
 output wire ext_cmd_valid,input wire ext_cmd_ready,
 output wire [15:0] cmd_seq,cmd_token,input wire [31:0] ext_quant_scale_fp32,
 output wire [9:0] cmd_position,output wire [5:0] cmd_stage,
 output wire [4:0] cmd_layer,output wire [3:0] cmd_head,cmd_op,cmd_src,cmd_dst,
 output wire [15:0] cmd_rows,cmd_cols,cmd_stride_groups,cmd_padding,cmd_vector_offset,
 output wire [31:0] cmd_matrix_offset,cmd_param_offset,cmd_source_address,cmd_destination_address,
 output wire [31:0] cmd_aux_source_address,cmd_aux_destination_address,
 input wire ext_rsp_valid,output wire ext_rsp_ready,
 input wire [15:0] ext_rsp_seq,ext_rsp_token,input wire ext_rsp_error,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready,
 input wire [31:0] aux_araddr,input wire [7:0] aux_arlen,
 input wire [2:0] aux_arsize,input wire [1:0] aux_arburst,
 input wire aux_arvalid,output wire aux_arready,
 output wire [127:0] aux_rdata,output wire [1:0] aux_rresp,
 output wire aux_rlast,aux_rvalid,input wire aux_rready,
 input wire [31:0] aux_awaddr,input wire [7:0] aux_awlen,
 input wire [2:0] aux_awsize,input wire [1:0] aux_awburst,
 input wire aux_awvalid,output wire aux_awready,
 input wire [127:0] aux_wdata,input wire [15:0] aux_wstrb,
 input wire aux_wlast,aux_wvalid,output wire aux_wready,
 output wire [1:0] aux_bresp,output wire aux_bvalid,input wire aux_bready
);
 localparam [31:0] X_OFFSET=32'h0e658000,Y_OFFSET=32'h0e660000,LOGIT_OFFSET=32'h0e6e0000;
 // Disjoint candidate buffers; no relation to any existing physical bank.
 function automatic [31:0] vector_offset(input [3:0] id);
  case(id)
   0:vector_offset=32'h0e640000;1:vector_offset=32'h0e641000;
   2:vector_offset=32'h0e642000;3:vector_offset=32'h0e643000;
   4:vector_offset=32'h0e644000;5:vector_offset=32'h0e645000;
   6:vector_offset=32'h0e646000;7:vector_offset=32'h0e648000;
   8:vector_offset=32'h0e650000;9:vector_offset=32'h0e656000;
   10:vector_offset=32'h0e657000;11:vector_offset=X_OFFSET;
   12:vector_offset=Y_OFFSET;
   default:vector_offset=32'h0fffffff; // Invalid external vector id must reject.
  endcase
 endfunction
 // Single exact case of the immutable controller stage, bypassing
 // stage -> command opcode/destination -> owner decode. Unknown stage
 // follows controller default opcode15, hence all internal owners false.
 function automatic [2:0] stage_owner_flags(input [5:0] s);
  case(s)
   3,5,7,23,28,30,34,39,4,6,8,24,29,31,35,16,20,17,21,40:stage_owner_flags=3'b100;
   12,14:stage_owner_flags=3'b010;
   11,13:stage_owner_flags=3'b001;
   default:stage_owner_flags=3'b000;
  endcase
 endfunction
 (* MAX_FANOUT=16 *) wire [2:0] stage_owners=stage_owner_flags(cmd_stage);
 wire selected_matrix=stage_owners[2];
 wire selected_kv=stage_owners[1];
 wire selected_quant=stage_owners[0];
 wire selected_aux=!selected_matrix&&!selected_kv&&!selected_quant;
 wire matrix_gemv=cmd_op==3||cmd_op==4;
 wire [2:0] matrix_kind=cmd_op==8?3'd1:cmd_op==10?3'd2:cmd_op==13?3'd3:3'd0;
 wire coefficient_enable=cmd_op==8||(cmd_op==5&&cmd_param_offset!=0);
 assign cmd_source_address=DDR_BASE+vector_offset(cmd_src)+
  ((cmd_op==2)?({16'b0,cmd_vector_offset}<<2):32'd0);
 assign cmd_destination_address=cmd_op==13?DDR_BASE+LOGIT_OFFSET:
  DDR_BASE+vector_offset(cmd_dst)+((cmd_op==10)?({16'b0,cmd_vector_offset}<<2):32'd0);

 // The KV frame reader owns only the read channel for QUANT->KV_TEMP.
 // No external producer can substitute values; source bytes come from AXI.
 wire quant_start,quant_input_valid,quant_input_error,quant_input_ready,quant_input_last;
 wire [31:0] quant_input_fp32;
 wire reader_ready,reader_rsp,reader_busy;
 wire [7:0] reader_error;wire [15:0] reader_seq,reader_stream_seq;
 wire [31:0] reader_cycles,qa;wire [7:0] qal;wire [2:0] qas;wire [1:0] qab;wire qav,qrr;
 assign quant_input_error=(quant_start&&!reader_ready)||(reader_rsp&&reader_error!=0);
 qwen_fp32_frame64_axi128_reader_v2 #(.DDR_BASE(DDR_BASE)) KV_reader(
  .clk,.rst_n,.cmd_valid(quant_start),.cmd_ready(reader_ready),.cmd_source_base(cmd_source_address),.cmd_seq,
  .out_valid(quant_input_valid),.out_ready(quant_input_ready),.out_fp32(quant_input_fp32),.out_last(quant_input_last),.out_seq(reader_stream_seq),
  .rsp_valid(reader_rsp),.rsp_ready(1'b1),.rsp_error(reader_error),.rsp_seq(reader_seq),.busy(reader_busy),.cycle_count(reader_cycles),
  .m_axi_araddr(qa),.m_axi_arlen(qal),.m_axi_arsize(qas),.m_axi_arburst(qab),.m_axi_arvalid(qav),.m_axi_arready(selected_quant&&m_axi_arready),
  .m_axi_rdata,.m_axi_rresp,.m_axi_rlast,.m_axi_rvalid(selected_quant&&m_axi_rvalid),.m_axi_rready(qrr));
 wire base_cmd_valid,base_cmd_ready,base_rsp_valid,base_rsp_ready;
 wire matrix_ready,matrix_rsp_valid,matrix_busy;wire [15:0] matrix_rsp_seq;
 wire [7:0] matrix_rsp_error;
 wire [31:0] unused_g_cycles,unused_mac_cycles,unused_wait_cycles,unused_stall_cycles,unused_post_cycles;
 reg [31:0] dynamic_scale;
 wire [31:0] checkpoint_KV_scale;
 assign checkpoint_scale=(cmd_op==2 && cmd_dst==13)?checkpoint_KV_scale:dynamic_scale;
 // Passive observation of the ACTUAL matrix response delivered to the scheduler.
 assign diagnostic_matrix_rsp_valid=matrix_rsp_valid&&selected_matrix;
 assign diagnostic_matrix_rsp_ready=base_rsp_ready&&selected_matrix;
 assign diagnostic_matrix_rsp_seq=matrix_rsp_seq;
 assign diagnostic_matrix_rsp_error=matrix_rsp_error;
 assign ext_cmd_valid=base_cmd_valid&&!selected_matrix&&aux_source_ready&&aux_destination_ready;
 assign base_cmd_ready=selected_matrix?(matrix_ready&&matrix_destination_ready):(ext_cmd_ready&&aux_source_ready&&aux_destination_ready);
 assign base_rsp_valid=selected_matrix?matrix_rsp_valid:ext_rsp_valid;
 assign ext_rsp_ready=base_rsp_ready&&!selected_matrix;
 always @(posedge clk or negedge rst_n)
  if(!rst_n)dynamic_scale<=0;
  else if(start&&!busy)dynamic_scale<=0;
  else if(ext_rsp_valid&&ext_rsp_ready&&!ext_rsp_error&&ext_rsp_seq==cmd_seq&&cmd_op==2&&cmd_dst==11)
   dynamic_scale<=ext_quant_scale_fp32;
 wire [31:0] ga,gw,ka;wire [7:0] gal,gwl,kal;
 wire [2:0] gas,gws,kas;wire [1:0] gab,gwb,kab;
 wire gav,grr,gwv,gww,gwlast,gbr,kav,kwv,kwlast,kbr;
 wire [127:0] gdata,kdata;wire [15:0] gstrb,kstrb;
 qwen_token_quant_kv_dispatch_v3 #(.DDR_BASE(DDR_BASE),.ENABLE_CHECKPOINT(ENABLE_CHECKPOINT)) scheduler(
  .checkpoint_enable,.checkpoint_resume,.checkpoint_seq,.checkpoint_paused,.checkpoint_scale(checkpoint_KV_scale),
  .clk,.rst_n,.start,.start_token,.start_position,.start_output_head,.start_emit_logits,
  .busy,.done,.error,.result_position,.result_token,.result_token_valid,.debug_control,.debug_sequence,
  .ext_cmd_valid(base_cmd_valid),.ext_cmd_ready(base_cmd_ready),.cmd_seq,.cmd_token,.cmd_position,.cmd_stage,.cmd_layer,.cmd_head,.cmd_op,.cmd_src,.cmd_dst,
  .cmd_rows,.cmd_cols,.cmd_stride_groups,.cmd_padding,.cmd_vector_offset,.cmd_matrix_offset,.cmd_param_offset,
  .ext_rsp_valid(base_rsp_valid),.ext_rsp_ready(base_rsp_ready),.ext_rsp_seq(selected_matrix?matrix_rsp_seq:ext_rsp_seq),
  .ext_rsp_token(selected_matrix?16'd0:ext_rsp_token),.ext_rsp_error(selected_matrix?(matrix_rsp_error!=0):ext_rsp_error),
  .quant_start,.quant_input_valid,.quant_input_error,.quant_input_ready,.quant_input_fp32,.quant_input_last,
  .m_axi_awaddr(ka),.m_axi_awlen(kal),.m_axi_awsize(kas),.m_axi_awburst(kab),.m_axi_awvalid(kav),.m_axi_awready(selected_kv&&m_axi_awready),
  .m_axi_wdata(kdata),.m_axi_wstrb(kstrb),.m_axi_wlast(kwlast),.m_axi_wvalid(kwv),.m_axi_wready(selected_kv&&m_axi_wready),
  .m_axi_bresp,.m_axi_bvalid(selected_kv&&m_axi_bvalid),.m_axi_bready(kbr));
// Hold both accepted auxiliary addresses independently of later scheduler decode.
 wire aux_source_ready,aux_destination_ready;
 wire auxiliary_offer=base_cmd_valid&&!selected_matrix;
 wire auxiliary_take=ext_cmd_valid&&ext_cmd_ready;
 qwen_destination_address_v1 auxiliary_source_pipe(.clk,.rst_n,
  .offer(auxiliary_offer),.take(auxiliary_take),.base(DDR_BASE+vector_offset(cmd_src)),
  .offset(cmd_op==2?({16'b0,cmd_vector_offset}<<2):32'd0),
  .ready(aux_source_ready),.address(cmd_aux_source_address));
 qwen_destination_address_v1 auxiliary_destination_pipe(.clk,.rst_n,
  .offer(auxiliary_offer),.take(auxiliary_take),.base(DDR_BASE+vector_offset(cmd_dst)),
  .offset(32'd0),.ready(aux_destination_ready),.address(cmd_aux_destination_address));
 wire matrix_destination_ready;wire [31:0] matrix_destination;
 qwen_destination_address_v1 destination_pipe(.clk,.rst_n,
  .offer(base_cmd_valid&&selected_matrix),.take(base_cmd_valid&&selected_matrix&&matrix_ready&&matrix_destination_ready),
  .base(cmd_op==13?DDR_BASE+LOGIT_OFFSET:DDR_BASE+vector_offset(cmd_dst)),
  .offset(cmd_op==10?({16'b0,cmd_vector_offset}<<2):32'd0),
  .ready(matrix_destination_ready),.address(matrix_destination));
 qwen_matrix_fp32_axi128_executor_v5 #(.DDR_BASE(DDR_BASE)) matrix(
  .clk,.rst_n,.cmd_valid(base_cmd_valid&&selected_matrix&&matrix_destination_ready),.cmd_ready(matrix_ready),
  .cmd_run_gemv(matrix_gemv),.cmd_run_post(!matrix_gemv),.cmd_mode_i16(cmd_op==4),.cmd_coefficient_enable(coefficient_enable),
  .cmd_rows,.cmd_cols,.cmd_stride_groups,.cmd_seq,.cmd_kind(matrix_kind),
  .cmd_weight_base(DDR_BASE+cmd_matrix_offset),.cmd_activation_base(DDR_BASE+X_OFFSET),
  .cmd_integer_base(DDR_BASE+Y_OFFSET),.cmd_float_base(matrix_destination),
  .cmd_coefficient_base(DDR_BASE+cmd_param_offset),.cmd_scale_fp32(dynamic_scale),
  .rsp_valid(matrix_rsp_valid),.rsp_ready(base_rsp_ready&&selected_matrix),.rsp_seq(matrix_rsp_seq),.rsp_error(matrix_rsp_error),.busy(matrix_busy),
  .gemv_cycles(unused_g_cycles),.gemv_mac_cycles(unused_mac_cycles),.gemv_weight_wait_cycles(unused_wait_cycles),.gemv_read_stall_cycles(unused_stall_cycles),.post_cycles(unused_post_cycles),
  .m_axi_araddr(ga),.m_axi_arlen(gal),.m_axi_arsize(gas),.m_axi_arburst(gab),.m_axi_arvalid(gav),.m_axi_arready(selected_matrix&&m_axi_arready),
  .m_axi_rdata,.m_axi_rresp,.m_axi_rlast,.m_axi_rvalid(selected_matrix&&m_axi_rvalid),.m_axi_rready(grr),
  .m_axi_awaddr(gw),.m_axi_awlen(gwl),.m_axi_awsize(gws),.m_axi_awburst(gwb),.m_axi_awvalid(gwv),.m_axi_awready(selected_matrix&&m_axi_awready),
  .m_axi_wdata(gdata),.m_axi_wstrb(gstrb),.m_axi_wlast(gwlast),.m_axi_wvalid(gww),.m_axi_wready(selected_matrix&&m_axi_wready),
  .m_axi_bresp,.m_axi_bvalid(selected_matrix&&m_axi_bvalid),.m_axi_bready(gbr));
 assign m_axi_araddr=selected_matrix?ga:selected_quant?qa:aux_araddr;
 assign m_axi_arlen=selected_matrix?gal:selected_quant?qal:aux_arlen;
 assign m_axi_arsize=selected_matrix?gas:selected_quant?qas:aux_arsize;
 assign m_axi_arburst=selected_matrix?gab:selected_quant?qab:aux_arburst;
 assign m_axi_arvalid=rst_n&&(selected_matrix?gav:selected_quant?qav:selected_aux?aux_arvalid:1'b0);
 assign m_axi_rready=selected_matrix?grr:selected_quant?qrr:selected_aux?aux_rready:1'b0;
 assign m_axi_awaddr=selected_matrix?gw:selected_kv?ka:aux_awaddr;
 assign m_axi_awlen=selected_matrix?gwl:selected_kv?kal:aux_awlen;
 assign m_axi_awsize=selected_matrix?gws:selected_kv?kas:aux_awsize;
 assign m_axi_awburst=selected_matrix?gwb:selected_kv?kab:aux_awburst;
 assign m_axi_awvalid=rst_n&&(selected_matrix?gwv:selected_kv?kav:selected_aux?aux_awvalid:1'b0);
 assign m_axi_wdata=selected_matrix?gdata:selected_kv?kdata:aux_wdata;
 assign m_axi_wstrb=selected_matrix?gstrb:selected_kv?kstrb:aux_wstrb;
 assign m_axi_wlast=selected_matrix?gwlast:selected_kv?kwlast:aux_wlast;
 assign m_axi_wvalid=rst_n&&(selected_matrix?gww:selected_kv?kwv:selected_aux?aux_wvalid:1'b0);
 assign m_axi_bready=selected_matrix?gbr:selected_kv?kbr:selected_aux?aux_bready:1'b0;
 assign aux_arready=selected_aux&&m_axi_arready;
 assign aux_rdata=m_axi_rdata;assign aux_rresp=m_axi_rresp;assign aux_rlast=m_axi_rlast;
 assign aux_rvalid=selected_aux&&m_axi_rvalid;
 assign aux_awready=selected_aux&&m_axi_awready;assign aux_wready=selected_aux&&m_axi_wready;
 assign aux_bresp=m_axi_bresp;assign aux_bvalid=selected_aux&&m_axi_bvalid;
// Passive per-token W4 accounting; no feedback into any executor signal.
 reg profile_owned_w4;reg [31:0] profile_calls;
 reg [63:0] profile_cycles,profile_mac,profile_wait,profile_stall;
 assign debug_gemv_profile={profile_calls,profile_stall,profile_wait,profile_mac,profile_cycles};
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin profile_owned_w4<=0;profile_calls<=0;profile_cycles<=0;profile_mac<=0;profile_wait<=0;profile_stall<=0;end
  else if(start&&!busy)begin profile_owned_w4<=0;profile_calls<=0;profile_cycles<=0;profile_mac<=0;profile_wait<=0;profile_stall<=0;end
  else begin
   if(base_cmd_valid&&selected_matrix&&matrix_ready&&matrix_destination_ready)profile_owned_w4<=cmd_op==3;
   if(diagnostic_matrix_rsp_valid&&diagnostic_matrix_rsp_ready&&profile_owned_w4)begin
    profile_calls<=profile_calls+1;profile_cycles<=profile_cycles+{32'd0,unused_g_cycles};
    profile_mac<=profile_mac+{32'd0,unused_mac_cycles};profile_wait<=profile_wait+{32'd0,unused_wait_cycles};profile_stall<=profile_stall+{32'd0,unused_stall_cycles};
   end
  end
 end
endmodule
