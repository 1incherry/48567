`timescale 1ns/1ps
// Native IO pulse owner is held until that selected peripheral really responds.
// CPU-only reset cannot turn an abandoned UART completion into a new AXI ACK.
module mcs_io_dispatch(input wire clk,board_rst_n,cpu_reset_n,
 input wire io_strobe,input wire[31:0]io_address,
 input wire[31:0]bridge_data,uart_data,input wire bridge_ready,uart_ready,
 output wire bridge_strobe,uart_strobe,output wire cpu_ready,
 output wire[31:0]cpu_data,output wire idle,output reg fault);
 (* ASYNC_REG="TRUE" *)reg[2:0]cpu_alive;
 reg active,owner_uart,aborted;
 wire selected_uart=io_address[31:8]==24'hc20010;
 wire selected_ready=owner_uart?uart_ready:bridge_ready;
 assign bridge_strobe=io_strobe&&!active&&!fault&&cpu_alive[2]&&!selected_uart;
 assign uart_strobe=io_strobe&&!active&&!fault&&cpu_alive[2]&&selected_uart;
 assign cpu_ready=active&&!aborted&&!fault&&cpu_alive[2]&&selected_ready;
 assign cpu_data=owner_uart?uart_data:bridge_data;
 assign idle=!active&&!bridge_ready&&!uart_ready;
 always@(posedge clk or negedge board_rst_n or negedge cpu_reset_n)
  if(!board_rst_n||!cpu_reset_n)cpu_alive<=0;else cpu_alive<={cpu_alive[1:0],1'b1};
 always@(posedge clk or negedge board_rst_n)begin
  if(!board_rst_n)begin active<=0;owner_uart<=0;aborted<=0;fault<=0;end
  else begin
   if(active&&!cpu_alive[2])aborted<=1;
   if(active&&selected_ready)begin active<=0;aborted<=0;end
   if(io_strobe&&cpu_alive[2])begin
    if(active)fault<=1;
    else if(!fault)begin active<=1;owner_uart<=selected_uart;aborted<=0;end
   end
  end
 end
endmodule
