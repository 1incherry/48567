// Exact C operation order: sequential sum(x*x), sum/H+epsilon,
// 1/sqrt(...), then (x*inverse)*gamma. Fresh AMD FP32 IP only.
// Frame buffering permits pipelined input squares and II1 affine output.
// Ordered reduction intentionally preserves every binary32 rounding point.
module qwen_rmsnorm_fp32_frame_bram_v2 #(
 parameter ELEMENTS=896, TAG_WIDTH=16, MUL_LAT=8,
 parameter [31:0] ELEMENTS_FP32=32'h44600000,
 parameter [31:0] EPSILON_FP32=32'h358637bd
)(
 input wire clk,rst_n,in_valid,
 output wire in_ready,
 input wire [31:0] x_fp32,gamma_fp32,
 input wire in_last,
 input wire [TAG_WIDTH-1:0] in_tag,
 output wire out_valid,
 input wire out_ready,
 output wire [31:0] result_fp32,
 output wire out_last,
 output wire [TAG_WIDTH-1:0] out_tag,
 output wire [223:0] diagnostic_state,
 output reg protocol_error
);
 localparam CAPTURE=0,WAIT_SQUARE=1,REDUCE=2,AVERAGE=3,
            ADD_EPS=4,ROOT=5,INVERSE=6,EMIT=7,DRAIN=8;
 reg [3:0] state;
 integer input_count,square_count,sum_index,emit_index;
 reg pending,read_pending,emit_read_valid;
 reg [TAG_WIDTH-1:0] frame_tag;
 reg [31:0] sum,average,root_input,root_value,inverse;
 (* ram_style="block" *) reg [31:0] x_mem[0:ELEMENTS-1];
 (* ram_style="block" *) reg [31:0] gamma_mem[0:ELEMENTS-1];
 (* ram_style="block" *) reg [31:0] square_mem[0:ELEMENTS-1];
 reg [31:0] square_rd,x_rd,gamma_rd;
 reg emit_read_last;
 wire ce=out_ready||!out_valid;
 assign in_ready=rst_n&&ce&&(state==CAPTURE);
 wire accept=in_valid&&in_ready;
 wire square_valid;wire [31:0] square_result;
 qwen_fp_mul square(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(accept),.s_axis_a_tdata(x_fp32),
  .s_axis_b_tvalid(accept),.s_axis_b_tdata(x_fp32),
  .m_axis_result_tvalid(square_valid),.m_axis_result_tdata(square_result));
 wire add_issue=(state==REDUCE&&read_pending&&!pending)||
                (state==ADD_EPS&&!pending);
 wire add_valid;wire [31:0] add_result;
 qwen_fp_add adder(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(add_issue),.s_axis_a_tdata(state==REDUCE?sum:average),
  .s_axis_b_tvalid(add_issue),.s_axis_b_tdata(state==REDUCE?square_rd:EPSILON_FP32),
  .m_axis_result_tvalid(add_valid),.m_axis_result_tdata(add_result));
 wire div_issue=(state==AVERAGE||state==INVERSE)&&!pending;
 wire div_valid;wire [31:0] div_result;
 qwen_fp_div divider(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(div_issue),.s_axis_a_tdata(state==AVERAGE?sum:32'h3f800000),
  .s_axis_b_tvalid(div_issue),.s_axis_b_tdata(state==AVERAGE?ELEMENTS_FP32:root_value),
  .m_axis_result_tvalid(div_valid),.m_axis_result_tdata(div_result));
 wire sqrt_issue=state==ROOT&&!pending;
 wire sqrt_valid;wire [31:0] sqrt_result;
 qwen_fp_sqrt sqrt_pipeline(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(sqrt_issue),.s_axis_a_tdata(root_input),
  .m_axis_result_tvalid(sqrt_valid),.m_axis_result_tdata(sqrt_result));
 wire scaled_valid;wire [31:0] scaled,gamma_delayed;
 qwen_fp_mul scale_pipeline(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(emit_read_valid),.s_axis_a_tdata(x_rd),
  .s_axis_b_tvalid(emit_read_valid),.s_axis_b_tdata(inverse),
  .m_axis_result_tvalid(scaled_valid),.m_axis_result_tdata(scaled));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(MUL_LAT)) gamma_delay(
  .clk,.rst_n,.ce,.din(gamma_rd),.dout(gamma_delayed));
 qwen_fp_mul affine_pipeline(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(scaled_valid),.s_axis_a_tdata(scaled),
  .s_axis_b_tvalid(scaled_valid),.s_axis_b_tdata(gamma_delayed),
  .m_axis_result_tvalid(out_valid),.m_axis_result_tdata(result_fp32));
 qwen_ce_delay #(.WIDTH(1),.DEPTH(2*MUL_LAT)) last_delay(
  .clk,.rst_n,.ce,.din(emit_read_last),.dout(out_last));
 assign out_tag=frame_tag;
 // Read-only observation: no debug bit feeds arithmetic, reset or handshake.
 assign diagnostic_state[31:0]={10'd0,protocol_error,rst_n,ce,out_valid,
  scaled_valid,sqrt_valid,sqrt_issue,div_valid,div_issue,add_valid,add_issue,
  square_valid,in_ready,accept,emit_read_last,emit_read_valid,read_pending,pending,state};
 assign diagnostic_state[63:32]={square_count[15:0],input_count[15:0]};
 assign diagnostic_state[95:64]={emit_index[15:0],sum_index[15:0]};
 assign diagnostic_state[127:96]=sum;
 assign diagnostic_state[159:128]=root_input;
 assign diagnostic_state[191:160]=root_value;
 assign diagnostic_state[223:192]=inverse;
 // RAM contents/read registers have no reset; resettable valid/control gates their use.
 // These reads occur on the same enabled edges as in the original C-exact implementation.
 always @(posedge clk)begin
  if(rst_n&&accept)begin x_mem[input_count]<=x_fp32;gamma_mem[input_count]<=gamma_fp32;end
  if(rst_n&&ce&&square_valid)square_mem[square_count]<=square_result;
  if(rst_n&&ce&&state==REDUCE&&!pending&&!read_pending)square_rd<=square_mem[sum_index];
  if(rst_n&&ce&&state==EMIT)begin x_rd<=x_mem[emit_index];gamma_rd<=gamma_mem[emit_index];end
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   state<=CAPTURE;input_count<=0;square_count<=0;sum_index<=0;emit_index<=0;
   pending<=0;read_pending<=0;emit_read_valid<=0;emit_read_last<=0;
   frame_tag<=0;sum<=0;average<=0;root_input<=0;root_value<=0;inverse<=0;
   protocol_error<=0;
  end else if(ce)begin
   emit_read_valid<=0;emit_read_last<=0;
   if(accept)begin
    if(input_count==0)frame_tag<=in_tag;
    if(in_last!==(input_count==ELEMENTS-1)||
       (input_count!=0&&in_tag!==frame_tag))protocol_error<=1;
    if(input_count==ELEMENTS-1)begin state<=WAIT_SQUARE;input_count<=0;end
    else input_count<=input_count+1;
   end
   if(square_valid)begin
    if(square_count==ELEMENTS-1)begin
     square_count<=0;sum_index<=0;sum<=0;state<=REDUCE;pending<=0;read_pending<=0;
    end else square_count<=square_count+1;
   end
   case(state)
    REDUCE:begin
     if(!pending&&!read_pending)begin read_pending<=1;end
     if(add_issue)begin pending<=1;read_pending<=0;end
     if(add_valid)begin
      sum<=add_result;pending<=0;
      if(sum_index==ELEMENTS-1)state<=AVERAGE;
      else sum_index<=sum_index+1;
     end
    end
    AVERAGE:begin
     if(div_issue)pending<=1;
     if(div_valid)begin average<=div_result;pending<=0;state<=ADD_EPS;end
    end
    ADD_EPS:begin
     if(add_issue)pending<=1;
     if(add_valid)begin root_input<=add_result;pending<=0;state<=ROOT;end
    end
    ROOT:begin
     if(sqrt_issue)pending<=1;
     if(sqrt_valid)begin root_value<=sqrt_result;pending<=0;state<=INVERSE;end
    end
    INVERSE:begin
     if(div_issue)pending<=1;
     if(div_valid)begin inverse<=div_result;pending<=0;state<=EMIT;emit_index<=0;end
    end
    EMIT:begin
     emit_read_valid<=1;emit_read_last<=emit_index==ELEMENTS-1;
     if(emit_index==ELEMENTS-1)state<=DRAIN;
     else emit_index<=emit_index+1;
    end
    DRAIN:if(out_valid&&out_ready&&out_last)begin state<=CAPTURE;input_count<=0;end
    default:begin end
   endcase
  end
 end
endmodule
