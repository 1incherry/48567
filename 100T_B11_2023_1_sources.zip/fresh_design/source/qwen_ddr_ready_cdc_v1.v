// Actual Vivado 2023.1 XPM single-bit CDC; no clock-group blanket exception.
module qwen_ddr_ready_cdc_v1(input wire ui_clk,core_clk,core_resetn,
 input wire calibrated,mig_locked,mig_axi_reset_n,(* MAX_FANOUT=16 *) output wire engine_ready);
 wire qualified;
 xpm_cdc_single #(.DEST_SYNC_FF(3),.SRC_INPUT_REG(1),.INIT_SYNC_FF(1),.SIM_ASSERT_CHK(1))
 ready_transfer(.src_clk(ui_clk),.src_in(calibrated && mig_locked && mig_axi_reset_n),.dest_clk(core_clk),.dest_out(qualified));
 // Board core reset remains synchronously released after 32 core clocks.
 // No request can launch while reset is active. Stable ready crosses via XPM.
 assign engine_ready=core_resetn && qualified;
endmodule
