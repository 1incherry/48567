// Reuse the original50M UART PHY. No extra RX/TX decoder or clock.
// Actual owner change is accepted by the existing MMIO mux only when TXquiet.
module qwen_uart_pin_profile #(parameter integer USE_GPIO_QA=0)(
 input wire clk,board_reset_n,runtime_mode,usb_rx,gpio_rx,shared_tx,
 output wire shared_rx,usb_tx,gpio_tx,owner_rx_abort);
 generate if(USE_GPIO_QA!=0)begin:gpio_profile
  reg previous_owner;
  always@(posedge clk or negedge board_reset_n)
   if(!board_reset_n)previous_owner<=0;else previous_owner<=runtime_mode;
  assign owner_rx_abort=runtime_mode!=previous_owner;
  assign shared_rx=runtime_mode?gpio_rx:usb_rx;
  assign gpio_tx=runtime_mode?shared_tx:1'b1;
 end else begin:usb_profile
  assign owner_rx_abort=1'b0;
  assign shared_rx=usb_rx;
  assign gpio_tx=1'b1;
 end endgenerate
 assign usb_tx=shared_tx;
endmodule
