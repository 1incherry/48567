module qwen_board_core_adapter_v16 #(parameter READY_CONTAINS_ARESETN=0,parameter ENABLE_CHECKPOINT=0)(
 (* X_INTERFACE_INFO="xilinx.com:signal:clock:1.0 aclk CLK", X_INTERFACE_PARAMETER="XIL_INTERFACENAME aclk, ASSOCIATED_BUSIF M_AXI:S_AXI, ASSOCIATED_RESET aresetn, FREQ_HZ 125000000" *) input wire aclk,
 (* X_INTERFACE_INFO="xilinx.com:signal:reset:1.0 aresetn RST", X_INTERFACE_PARAMETER="XIL_INTERFACENAME aresetn, POLARITY ACTIVE_LOW" *) input wire aresetn,
 input wire engine_ready,uart_rx,output wire uart_tx,
 input wire token_board_resetn,token_cpu_parked,token_cpu_park_ack,token_cpu_ddr_allowed,token_cpu_ddr_idle,
 input wire token_bridge_quiet,token_shared_quiet,token_camera_done,token_camera_completed,token_camera_fault,token_camera_owner_live,token_guard_fault,
 output wire token_camera_request,token_unpark_allow,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARADDR", X_INTERFACE_PARAMETER="XIL_INTERFACENAME M_AXI, PROTOCOL AXI4, DATA_WIDTH 128, ADDR_WIDTH 32, ID_WIDTH 0, HAS_BURST 1, HAS_RRESP 1, HAS_BRESP 1" *) output wire [31:0] m_axi_araddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARLEN" *) output wire [7:0] m_axi_arlen,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARSIZE" *) output wire [2:0] m_axi_arsize,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARBURST" *) output wire [1:0] m_axi_arburst,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARVALID" *) output wire  m_axi_arvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI ARREADY" *) input wire  m_axi_arready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RDATA" *) input wire [127:0] m_axi_rdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RRESP" *) input wire [1:0] m_axi_rresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RLAST" *) input wire  m_axi_rlast,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RVALID" *) input wire  m_axi_rvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI RREADY" *) output wire  m_axi_rready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWADDR" *) output wire [31:0] m_axi_awaddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWLEN" *) output wire [7:0] m_axi_awlen,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWSIZE" *) output wire [2:0] m_axi_awsize,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWBURST" *) output wire [1:0] m_axi_awburst,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWVALID" *) output wire  m_axi_awvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI AWREADY" *) input wire  m_axi_awready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WDATA" *) output wire [127:0] m_axi_wdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WSTRB" *) output wire [15:0] m_axi_wstrb,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WLAST" *) output wire  m_axi_wlast,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WVALID" *) output wire  m_axi_wvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI WREADY" *) input wire  m_axi_wready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BRESP" *) input wire [1:0] m_axi_bresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BVALID" *) input wire  m_axi_bvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 M_AXI BREADY" *) output wire  m_axi_bready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWADDR", X_INTERFACE_PARAMETER="XIL_INTERFACENAME S_AXI, PROTOCOL AXI4LITE, DATA_WIDTH 32, ADDR_WIDTH 32" *) input wire [31:0] s_axi_awaddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWPROT" *) input wire [2:0] s_axi_awprot,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWVALID" *) input wire  s_axi_awvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI AWREADY" *) output wire  s_axi_awready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WDATA" *) input wire [31:0] s_axi_wdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WSTRB" *) input wire [3:0] s_axi_wstrb,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WVALID" *) input wire  s_axi_wvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI WREADY" *) output wire  s_axi_wready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI BRESP" *) output reg [1:0] s_axi_bresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI BVALID" *) output reg  s_axi_bvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI BREADY" *) input wire  s_axi_bready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARADDR" *) input wire [31:0] s_axi_araddr,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARPROT" *) input wire [2:0] s_axi_arprot,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARVALID" *) input wire  s_axi_arvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI ARREADY" *) output wire  s_axi_arready,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RDATA" *) output reg [31:0] s_axi_rdata,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RRESP" *) output reg [1:0] s_axi_rresp,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RVALID" *) output reg  s_axi_rvalid,
 (* X_INTERFACE_INFO="xilinx.com:interface:aximm:1.0 S_AXI RREADY" *) input wire  s_axi_rready
);

wire busy,done,error,result_token_valid;
reg tx_valid=0;reg [7:0] tx_byte=0;wire tx_ready;wire [7:0] rx_byte;wire rx_valid,rx_error;
// Private profile capture only; preserve a held done across sequence starts.
reg profile_done_previous;
always @(posedge aclk)begin
 if(!aresetn)profile_done_previous<=0;
 else profile_done_previous<=done;
end
reg [511:0] profile_snapshot;
reg profile_snapshot_valid;
reg profile_strobe_pending;reg [15:0] profile_strobe_capture;
reg profile_write_byte_pending;reg [4:0] profile_write_byte_increment;
reg [63:0] decode_w4_cycles,decode_w4_mac,decode_w4_wait,decode_w4_stall,decode_read_beats,decode_write_beats,decode_written_bytes;
reg [31:0] decode_w4_calls,decode_core_completions;
wire [511:0] profile_values={decode_core_completions,decode_w4_calls,decode_written_bytes,decode_write_beats,decode_read_beats,decode_w4_stall,decode_w4_wait,decode_w4_mac,decode_w4_cycles};
reg checkpoint_enable=0,checkpoint_resume=0;reg [15:0] checkpoint_seq=0;
wire checkpoint_paused;wire [31:0] checkpoint_scale;
reg have_aw=0,have_w=0;reg [31:0] wa,wd;reg [3:0] ws;
reg [31:0] requested_token=0;reg [31:0] requested_position=0;reg [1:0] flags=1;
reg start_pulse=0,accepted_busy=0,sticky_done=0,sticky_error=0,sticky_valid=0;
reg [15:0] saved_token=0;reg [9:0] saved_position=0;reg [63:0] cycles=0,saved_cycles=0;
wire [15:0] result_token;wire [9:0] result_position;
wire [287:0] debug_nonlinear;
wire [287:0] debug_gemv_profile;
wire [31:0] debug_control,debug_sequence;
(* MAX_FANOUT=16 *) wire engine_resetn=READY_CONTAINS_ARESETN ? engine_ready : (aresetn && engine_ready);
reg seq_owned=0,seq_start_pulse=0,seq_launch_pending=0;
reg seq_prompt_valid=0,seq_prompt_last=0;reg [15:0] seq_prompt_token=0;
reg [31:0] seq_limit=192;
reg seq_sticky_done=0,seq_sticky_error=0,seq_pop_pulse=0,seq_soft_reset=0;
reg seq_result_latched=0;reg [63:0] seq_saved_result_cycles=0;
reg [31:0] seq_decode_hi=0,seq_active_hi=0;
wire seq_start_ready,seq_prompt_ready,seq_busy,seq_done,seq_error;
reg[1:0]token_control;reg token_unpark_command;
wire token_park_generation_engaged,token_park_generation_ack_seen,token_cpu_allowed_qualified;
wire token_handover_unpark_allow;
wire token_park_command=have_aw&&have_w&&!s_axi_bvalid&&wa[1:0]==0&&wa[11:8]==0&&wa[7:0]==8'hf0&&ws==4'hf&&wd==3;

wire token_pause_pending,token_pause_request,token_sequence_parked,token_boundary_ack,token_witness_fault,token_handover_fault,token_raw_boundary_quiet;
wire[2:0]token_handover_state;
wire[31:0]token_completed_windows,token_cadence_cycles;
(* ASYNC_REG="TRUE" *)reg[2:0]token_cpu_parked_sync,token_cpu_park_ack_sync,token_cpu_allowed_sync,token_cpu_idle_sync,token_bridge_sync,token_shared_sync,token_camera_done_sync,token_camera_completed_sync,token_camera_fault_sync,token_owner_live_sync,token_guard_fault_sync;
always @(posedge aclk or negedge token_board_resetn)begin
 if(!token_board_resetn)begin token_cpu_parked_sync<=0;token_cpu_park_ack_sync<=0;token_cpu_allowed_sync<=0;token_cpu_idle_sync<=0;token_bridge_sync<=0;token_shared_sync<=0;token_camera_done_sync<=0;token_camera_completed_sync<=0;token_camera_fault_sync<=0;token_owner_live_sync<=0;token_guard_fault_sync<=0;end
 else begin
 token_cpu_parked_sync<={token_cpu_parked_sync[1:0],token_cpu_parked};token_cpu_park_ack_sync<={token_cpu_park_ack_sync[1:0],token_cpu_park_ack};token_cpu_allowed_sync<={token_cpu_allowed_sync[1:0],token_cpu_ddr_allowed};token_cpu_idle_sync<={token_cpu_idle_sync[1:0],token_cpu_ddr_idle};
 token_bridge_sync<={token_bridge_sync[1:0],token_bridge_quiet};token_shared_sync<={token_shared_sync[1:0],token_shared_quiet};
 token_camera_done_sync<={token_camera_done_sync[1:0],token_camera_done};token_camera_completed_sync<={token_camera_completed_sync[1:0],token_camera_completed};
 token_camera_fault_sync<={token_camera_fault_sync[1:0],token_camera_fault};token_owner_live_sync<={token_owner_live_sync[1:0],token_camera_owner_live};token_guard_fault_sync<={token_guard_fault_sync[1:0],token_guard_fault};end
end
qwen_cpu_park_generation_r2 token_park_generation(.clk(aclk),.board_reset_n(token_board_resetn),.park_command(token_park_command),.unpark_requested(!token_control[1]),
 .handover_unpark_allow(token_handover_unpark_allow),.physical_parked(token_cpu_parked_sync[2]),.physical_ddr_allowed(token_cpu_allowed_sync[2]),.fresh_park_ack(token_cpu_park_ack_sync[2]),
 .unpark_allow(token_unpark_allow),.cpu_ddr_allowed(token_cpu_allowed_qualified),.engaged(token_park_generation_engaged),.ack_seen(token_park_generation_ack_seen));
wire token_lower_quiet=token_cpu_parked_sync[2]&&!token_cpu_allowed_sync[2]&&token_cpu_idle_sync[2]&&token_bridge_sync[2]&&token_shared_sync[2];
wire[31:0]token_status={21'd0,token_cpu_park_ack_sync[2],token_owner_live_sync[2],token_cpu_allowed_qualified,(token_handover_fault||token_witness_fault||token_guard_fault_sync[2]),(token_handover_state==3),token_camera_request,token_raw_boundary_quiet,token_sequence_parked,token_pause_pending,token_cpu_parked_sync[2],token_control[0]};
qwen_token_camera_handover_r1 #(.CORE_HZ(125000000)) token_handover(
 .clk(aclk),.board_reset_n(token_board_resetn),.epoch_valid(aresetn&&engine_ready),.guard_fault(token_witness_fault||token_guard_fault_sync[2]),
 .inference_active(seq_owned&&(seq_busy||seq_launch_pending)),.enable(token_control[0]),.cpu_park_requested(token_control[1]),.cpu_parked(token_cpu_parked_sync[2]&&token_cpu_park_ack_sync[2]),.cpu_ddr_allowed(token_cpu_allowed_sync[2]),.cpu_unpark_request(token_unpark_command),
 .qwen_quiet_ack(token_boundary_ack),.qwen_source_quiet(token_raw_boundary_quiet&&token_sequence_parked),
 .camera_done(token_camera_done_sync[2]),.camera_frame_completed(token_camera_completed_sync[2]),.camera_fault(token_camera_fault_sync[2]),
 .pause_pending(token_pause_pending),.token_pause_request(token_pause_request),.camera_request(token_camera_request),.cpu_unpark_allow(token_handover_unpark_allow),.state_debug(token_handover_state),.fault(token_handover_fault),.completed_windows(token_completed_windows),.cadence_cycles(token_cadence_cycles));
wire seq_core_start,seq_core_head,seq_core_logits,seq_valid,seq_last;
wire [15:0] seq_core_token,seq_token;
wire [9:0] seq_core_position,seq_position;
wire [8:0] seq_count;wire [7:0] seq_generated;
wire [63:0] seq_result_cycles,seq_prefill_compute,seq_decode_compute,seq_fifo_wait,seq_active_wall,seq_decode_wall;
wire seq_locked=seq_busy || seq_launch_pending || seq_prompt_valid || seq_count!=0 || seq_valid || seq_pop_pulse || seq_soft_reset;
qwen_autoregressive_sequence_token_pause_r1 sequence_control(.token_pause_request(token_pause_request),.token_boundary_parked(token_sequence_parked),
 .clk(aclk),.rst_n(aresetn && !seq_soft_reset),.ddr_ready(engine_ready),
 .start_valid(seq_start_pulse),.start_ready(seq_start_ready),.start_position(requested_position[9:0]),.max_new_tokens(seq_limit[7:0]),.emit_logits(flags[1]),
 .prompt_valid(seq_prompt_valid),.prompt_ready(seq_prompt_ready),.prompt_token(seq_prompt_token),.prompt_last(seq_prompt_last),
 .busy(seq_busy),.done(seq_done),.error(seq_error),
 .core_start(seq_core_start),.core_token(seq_core_token),.core_position(seq_core_position),.core_output_head(seq_core_head),.core_emit_logits(seq_core_logits),
 .core_busy(busy),.core_done(done),.core_error(error),.core_result_token(result_token),.core_result_position(result_position),.core_result_valid(result_token_valid),
 .result_valid(seq_valid),.result_ready(seq_pop_pulse),.result_token(seq_token),.result_position(seq_position),.result_cycles(seq_result_cycles),.result_last(seq_last),
 .result_count(seq_count),.generated_count(seq_generated),.prefill_cycles(seq_prefill_compute),.decode_cycles(seq_decode_compute),.fifo_wait_cycles(seq_fifo_wait),.active_sequence_cycles(seq_active_wall),.decode_wall_cycles(seq_decode_wall));

assign s_axi_awready=aresetn && !have_aw && !s_axi_bvalid;
assign s_axi_wready=aresetn && !have_w && !s_axi_bvalid;
assign s_axi_arready=aresetn && !s_axi_rvalid;
function [31:0] merge(input [31:0] a,b,input [3:0] strobe);
 integer k;begin merge=a;for(k=0;k<4;k=k+1)if(strobe[k])merge[k*8+:8]=b[k*8+:8];end
endfunction
always @(posedge aclk)begin
 if(!aresetn)begin
  token_control<=0;token_unpark_command<=0;
  checkpoint_enable<=0;checkpoint_resume<=0;checkpoint_seq<=0;profile_snapshot_valid<=0;have_aw<=0;have_w<=0;s_axi_bvalid<=0;s_axi_bresp<=0;s_axi_rvalid<=0;s_axi_rresp<=0;s_axi_rdata<=0;
  requested_token<=0;requested_position<=0;flags<=1;start_pulse<=0;accepted_busy<=0;sticky_done<=0;sticky_error<=0;sticky_valid<=0;
  saved_token<=0;saved_position<=0;cycles<=0;saved_cycles<=0;
  seq_owned<=0;seq_start_pulse<=0;seq_launch_pending<=0;seq_prompt_valid<=0;seq_prompt_last<=0;seq_prompt_token<=0;seq_limit<=192;seq_sticky_done<=0;seq_sticky_error<=0;seq_pop_pulse<=0;seq_soft_reset<=0;seq_result_latched<=0;seq_saved_result_cycles<=0;seq_decode_hi<=0;seq_active_hi<=0;
 end else begin
  token_unpark_command<=0;
  checkpoint_resume<=0;start_pulse<=0;seq_start_pulse<=0;seq_pop_pulse<=0;seq_soft_reset<=0;
  if(seq_start_pulse)seq_launch_pending<=0;
  if(seq_prompt_valid&&seq_prompt_ready)seq_prompt_valid<=0;
  if(seq_done&&seq_owned)begin seq_sticky_done<=1;seq_sticky_error<=seq_error;end
  if(seq_pop_pulse&&seq_valid)seq_result_latched<=0;
  if(s_axi_awvalid&&s_axi_awready)begin wa<=s_axi_awaddr;have_aw<=1;end
  if(s_axi_wvalid&&s_axi_wready)begin wd<=s_axi_wdata;ws<=s_axi_wstrb;have_w<=1;end
  if(s_axi_bvalid&&s_axi_bready)s_axi_bvalid<=0;
  if(have_aw&&have_w&&!s_axi_bvalid)begin
   have_aw<=0;have_w<=0;s_axi_bvalid<=1;s_axi_bresp<=0;
   if(wa[1:0]!=0 || wa[11:8]!=0)s_axi_bresp<=2;
   else case(wa[7:0])
    8'h08:begin
     if(ws[0]&&wd[0])begin
      if(token_control!=0||token_pause_pending||accepted_busy||busy||seq_locked||!engine_ready||requested_token>=65535||requested_position>=512)s_axi_bresp<=2;
      else begin seq_owned<=0;start_pulse<=1;accepted_busy<=1;sticky_done<=0;sticky_error<=0;sticky_valid<=0;cycles<=0;end
     end
    end
    8'h0c:if(accepted_busy||busy||seq_locked)s_axi_bresp<=2;else requested_token<=merge(requested_token,wd,ws);
    8'h10:if(accepted_busy||busy||seq_locked)s_axi_bresp<=2;else requested_position<=merge(requested_position,wd,ws);
    8'h14:if(accepted_busy||busy||seq_locked)s_axi_bresp<=2;else flags<=merge({30'b0,flags},wd,ws);
    8'h28:if(tx_valid||!ws[0])s_axi_bresp<=2;
    8'h30:if(accepted_busy||busy||seq_locked)s_axi_bresp<=2;else seq_limit<=merge(seq_limit,wd,ws);
    8'h34:begin
     if(ws[0]&&wd[0])begin
      if(accepted_busy||busy||seq_locked||!seq_start_ready||checkpoint_enable||requested_position>=512||seq_limit==0||seq_limit>192||wd[31:1]!=0)s_axi_bresp<=2;
      else begin seq_owned<=1;seq_start_pulse<=1;seq_launch_pending<=1;seq_sticky_done<=0;seq_sticky_error<=0;seq_result_latched<=0;end
     end else if(wd!=0)s_axi_bresp<=2;
    end
    8'h38:begin
     if(!seq_owned||!seq_prompt_ready||seq_prompt_valid||seq_launch_pending||ws[2:0]!=3'b111||wd[31:17]!=0||wd[15:0]>=65535)s_axi_bresp<=2;
     else begin seq_prompt_valid<=1;seq_prompt_token<=wd[15:0];seq_prompt_last<=wd[16];end
    end
    8'h44:begin
     if(ws[0]&&wd[0]&&wd[31:1]==0&&seq_valid&&seq_result_latched&&!seq_pop_pulse)seq_pop_pulse<=1;
     else s_axi_bresp<=2;
    end
    8'h6c:begin
     if(ws[0]&&wd==1&&!accepted_busy&&!busy&&!seq_busy&&!seq_launch_pending)begin
      seq_soft_reset<=1;seq_owned<=0;seq_prompt_valid<=0;seq_result_latched<=0;seq_sticky_done<=0;seq_sticky_error<=0;
     end else s_axi_bresp<=2;
    end

    8'hf0:begin
     if(ws!=4'hf||(wd!=0&&wd!=1&&wd!=3))s_axi_bresp<=2;
     else begin token_control<=wd[1:0];if(wd!=3)token_unpark_command<=1;end
    end
    8'he0:if(!ENABLE_CHECKPOINT||accepted_busy||busy||seq_locked||ws!=4'hf||wd[31:1]!=0)s_axi_bresp<=2;else checkpoint_enable<=wd[0];
    8'he4:if(!ENABLE_CHECKPOINT||seq_locked||((accepted_busy||busy)&&!checkpoint_paused)||ws!=4'hf||wd[31:16]!=0)s_axi_bresp<=2;else checkpoint_seq<=wd[15:0];
    8'he8:if(!ENABLE_CHECKPOINT||!checkpoint_paused||seq_locked||ws!=4'hf||wd!=1)s_axi_bresp<=2;else checkpoint_resume<=1;
    default:s_axi_bresp<=2;
   endcase
  end
  if(accepted_busy)cycles<=cycles+1;
  if(accepted_busy&&!engine_ready)begin accepted_busy<=0;sticky_done<=1;sticky_error<=1;sticky_valid<=0;saved_cycles<=cycles;end
  if(done&&accepted_busy&&!start_pulse)begin
   accepted_busy<=0;sticky_done<=1;sticky_error<=error;sticky_valid<=result_token_valid;
   saved_token<=result_token;saved_position<=result_position;saved_cycles<=cycles;
  end
  if(s_axi_rvalid&&s_axi_rready)s_axi_rvalid<=0;
  if(s_axi_arvalid&&s_axi_arready)begin
   s_axi_rvalid<=1;s_axi_rresp<=0;s_axi_rdata<=0;
   if(s_axi_araddr[1:0]!=0 || s_axi_araddr[11:8]!=0)s_axi_rresp<=2;
   else case(s_axi_araddr[7:0])
    8'h00:s_axi_rdata<=32'h51575032;
    8'h04:s_axi_rdata<={26'b0,sticky_valid,sticky_error,sticky_done,(accepted_busy||busy),!engine_resetn,engine_ready};
    8'h0c:s_axi_rdata<=requested_token;8'h10:s_axi_rdata<=requested_position;8'h14:s_axi_rdata<={30'b0,flags};
    8'h18:s_axi_rdata<={16'b0,saved_token};8'h1c:s_axi_rdata<={22'b0,saved_position};
    8'h20:s_axi_rdata<=saved_cycles[31:0];8'h24:s_axi_rdata<=saved_cycles[63:32];
    8'h28:s_axi_rdata<={31'b0,!tx_valid};8'h2c:s_axi_rdata<={22'b0,rx_error,rx_valid,rx_byte};
    8'h30:s_axi_rdata<=seq_limit;
    8'h3c:s_axi_rdata<={14'b0,seq_count,1'b0,seq_generated};
    8'h40:if(!seq_valid)s_axi_rresp<=2;else begin
     s_axi_rdata<={1'b1,4'b0,seq_last,seq_position,seq_token};seq_result_latched<=1;seq_saved_result_cycles<=seq_result_cycles;
    end
    8'h48:begin s_axi_rdata<=seq_decode_wall[31:0];seq_decode_hi<=seq_decode_wall[63:32];end
    8'h4c:s_axi_rdata<=seq_decode_hi;
    8'h50:begin s_axi_rdata<=seq_active_wall[31:0];seq_active_hi<=seq_active_wall[63:32];end
    8'h54:s_axi_rdata<=seq_active_hi;
    8'h58:s_axi_rdata<={23'b0,seq_result_latched,seq_valid,seq_prompt_valid,seq_prompt_ready,seq_start_ready,seq_sticky_error,seq_sticky_done,seq_launch_pending,seq_busy};
    8'h60:if(!seq_result_latched)s_axi_rresp<=2;else s_axi_rdata<=seq_saved_result_cycles[31:0];
    8'h64:if(!seq_result_latched)s_axi_rresp<=2;else s_axi_rdata<=seq_saved_result_cycles[63:32];
    8'h70:s_axi_rdata<=debug_control;
    8'h74:s_axi_rdata<=debug_sequence;
    8'h78:s_axi_rdata<=debug_nonlinear[0 +:32];
    8'h7c:s_axi_rdata<=debug_nonlinear[32 +:32];
    8'h80:s_axi_rdata<=debug_nonlinear[64 +:32];
    8'h84:s_axi_rdata<=debug_nonlinear[96 +:32];
    8'h88:s_axi_rdata<=debug_nonlinear[128 +:32];
    8'h8c:s_axi_rdata<=debug_nonlinear[160 +:32];
    8'h90:s_axi_rdata<=debug_nonlinear[192 +:32];
    8'h94:s_axi_rdata<=debug_nonlinear[224 +:32];
    8'h98:s_axi_rdata<=debug_nonlinear[256 +:32];
    8'h9c:begin
     if(accepted_busy||busy||seq_busy||seq_launch_pending||profile_strobe_pending||profile_write_byte_pending)s_axi_rresp<=2;
     else begin profile_snapshot<=profile_values;profile_snapshot_valid<=1;s_axi_rdata<=32'h50524631;end
    end
    8'ha0:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[0 +:32];
    8'ha4:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[32 +:32];
    8'ha8:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[64 +:32];
    8'hac:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[96 +:32];
    8'hb0:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[128 +:32];
    8'hb4:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[160 +:32];
    8'hb8:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[192 +:32];
    8'hbc:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[224 +:32];
    8'hc0:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[256 +:32];
    8'hc4:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[288 +:32];
    8'hc8:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[320 +:32];
    8'hcc:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[352 +:32];
    8'hd0:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[384 +:32];
    8'hd4:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[416 +:32];
    8'hd8:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[448 +:32];
    8'hdc:if(!profile_snapshot_valid)s_axi_rresp<=2;else s_axi_rdata<=profile_snapshot[480 +:32];


    8'hec:s_axi_rdata<=32'h50574e31;
    8'hf0:s_axi_rdata<={30'd0,token_control};
    8'hf4:s_axi_rdata<=token_status;
    8'hf8:s_axi_rdata<=token_completed_windows;
    8'hfc:s_axi_rdata<=token_cadence_cycles;
    8'he0:if(!ENABLE_CHECKPOINT)s_axi_rresp<=2;else s_axi_rdata<=32'h43500100|{30'b0,checkpoint_enable,checkpoint_paused};
    8'he4:if(!ENABLE_CHECKPOINT)s_axi_rresp<=2;else s_axi_rdata<={16'b0,checkpoint_seq};
    8'he8:if(!ENABLE_CHECKPOINT||!checkpoint_paused)s_axi_rresp<=2;else s_axi_rdata<=checkpoint_scale;
    default:s_axi_rresp<=2;
   endcase
  end
 end
end
// Candidate transport is JTAG AXI commands/results. UART is exposed through
// a hardware byte mailbox, with no embedded CPU or fixed-answer substitution.

qwen_uart_phy #(.CLOCK_HZ(125000000),.BAUD(115200)) uart(.clk(aclk),.rst(!aresetn),.rx(uart_rx),.tx(uart_tx),.rx_data(rx_byte),.rx_valid(rx_valid),.rx_ready(1'b1),.rx_error(rx_error),.tx_data(tx_byte),.tx_valid(tx_valid),.tx_ready(tx_ready));
always @(posedge aclk)begin
 if(!aresetn)begin tx_valid<=0;tx_byte<=0;end
 else begin
  if(tx_valid&&tx_ready)tx_valid<=0;
  if(have_aw&&have_w&&!s_axi_bvalid&&wa[7:0]==8'h28&&wa[1:0]==0&&ws[0]&&!tx_valid)begin tx_byte<=wd[7:0];tx_valid<=1;end
 end
end
wire [31:0] q_axi_araddr;
wire [7:0] q_axi_arlen;
wire [2:0] q_axi_arsize;
wire [1:0] q_axi_arburst;
wire q_axi_arvalid;
wire q_axi_arready;
wire [127:0] q_axi_rdata;
wire [1:0] q_axi_rresp;
wire q_axi_rlast;
wire q_axi_rvalid;
wire q_axi_rready;
wire [31:0] q_axi_awaddr;
wire [7:0] q_axi_awlen;
wire [2:0] q_axi_awsize;
wire [1:0] q_axi_awburst;
wire q_axi_awvalid;
wire q_axi_awready;
wire [127:0] q_axi_wdata;
wire [15:0] q_axi_wstrb;
wire q_axi_wlast;
wire q_axi_wvalid;
wire q_axi_wready;
wire [1:0] q_axi_bresp;
wire q_axi_bvalid;
wire q_axi_bready;
qwen_cpu_free_token_axi128_v26 #(.ENABLE_CHECKPOINT(ENABLE_CHECKPOINT)) core(
 .checkpoint_enable(checkpoint_enable),.checkpoint_resume(checkpoint_resume),.checkpoint_seq(checkpoint_seq),.checkpoint_paused(checkpoint_paused),.checkpoint_scale(checkpoint_scale),.clk(aclk),.rst_n(engine_resetn),.start(seq_owned ? seq_core_start : start_pulse),.start_token(seq_owned ? seq_core_token : requested_token[15:0]),.start_position(seq_owned ? seq_core_position : requested_position[9:0]),.start_output_head(seq_owned ? seq_core_head : flags[0]),.start_emit_logits(seq_owned ? seq_core_logits : flags[1]),.busy(busy),.done(done),.error(error),.result_position(result_position),.result_token(result_token),.result_token_valid(result_token_valid),.debug_control(debug_control),.debug_sequence(debug_sequence),.debug_nonlinear(debug_nonlinear),.debug_gemv_profile(debug_gemv_profile),.m_axi_araddr(q_axi_araddr),.m_axi_arlen(q_axi_arlen),.m_axi_arsize(q_axi_arsize),.m_axi_arburst(q_axi_arburst),.m_axi_arvalid(q_axi_arvalid),.m_axi_arready(q_axi_arready),.m_axi_rdata(q_axi_rdata),.m_axi_rresp(q_axi_rresp),.m_axi_rlast(q_axi_rlast),.m_axi_rvalid(q_axi_rvalid),.m_axi_rready(q_axi_rready),.m_axi_awaddr(q_axi_awaddr),.m_axi_awlen(q_axi_awlen),.m_axi_awsize(q_axi_awsize),.m_axi_awburst(q_axi_awburst),.m_axi_awvalid(q_axi_awvalid),.m_axi_awready(q_axi_awready),.m_axi_wdata(q_axi_wdata),.m_axi_wstrb(q_axi_wstrb),.m_axi_wlast(q_axi_wlast),.m_axi_wvalid(q_axi_wvalid),.m_axi_wready(q_axi_wready),.m_axi_bresp(q_axi_bresp),.m_axi_bvalid(q_axi_bvalid),.m_axi_bready(q_axi_bready));
qwen_axi128_boundary_v1 #(.READY_CONTAINS_ARESETN(READY_CONTAINS_ARESETN)) boundary(.aclk(aclk),.aresetn(aresetn),.engine_ready(engine_ready),.s_axi_araddr(q_axi_araddr),.m_axi_araddr(m_axi_araddr),.s_axi_arlen(q_axi_arlen),.m_axi_arlen(m_axi_arlen),.s_axi_arsize(q_axi_arsize),.m_axi_arsize(m_axi_arsize),.s_axi_arburst(q_axi_arburst),.m_axi_arburst(m_axi_arburst),.s_axi_arvalid(q_axi_arvalid),.m_axi_arvalid(m_axi_arvalid),.s_axi_arready(q_axi_arready),.m_axi_arready(m_axi_arready),.s_axi_rdata(q_axi_rdata),.m_axi_rdata(m_axi_rdata),.s_axi_rresp(q_axi_rresp),.m_axi_rresp(m_axi_rresp),.s_axi_rlast(q_axi_rlast),.m_axi_rlast(m_axi_rlast),.s_axi_rvalid(q_axi_rvalid),.m_axi_rvalid(m_axi_rvalid),.s_axi_rready(q_axi_rready),.m_axi_rready(m_axi_rready),.s_axi_awaddr(q_axi_awaddr),.m_axi_awaddr(m_axi_awaddr),.s_axi_awlen(q_axi_awlen),.m_axi_awlen(m_axi_awlen),.s_axi_awsize(q_axi_awsize),.m_axi_awsize(m_axi_awsize),.s_axi_awburst(q_axi_awburst),.m_axi_awburst(m_axi_awburst),.s_axi_awvalid(q_axi_awvalid),.m_axi_awvalid(m_axi_awvalid),.s_axi_awready(q_axi_awready),.m_axi_awready(m_axi_awready),.s_axi_wdata(q_axi_wdata),.m_axi_wdata(m_axi_wdata),.s_axi_wstrb(q_axi_wstrb),.m_axi_wstrb(m_axi_wstrb),.s_axi_wlast(q_axi_wlast),.m_axi_wlast(m_axi_wlast),.s_axi_wvalid(q_axi_wvalid),.m_axi_wvalid(m_axi_wvalid),.s_axi_wready(q_axi_wready),.m_axi_wready(m_axi_wready),.s_axi_bresp(q_axi_bresp),.m_axi_bresp(m_axi_bresp),.s_axi_bvalid(q_axi_bvalid),.m_axi_bvalid(m_axi_bvalid),.s_axi_bready(q_axi_bready),.m_axi_bready(m_axi_bready));

// Account at the REAL token core side, before the existing two-slot boundary.
wire[3:0]token_pending_reads,token_pending_aw,token_pending_w;
wire[8:0]token_partial_w;
wire[3:0]token_first_axi_error;
qwen_axi_quiet_witness_r2 #(.MAX_PENDING(8)) token_axi_witness(
 .clk(aclk),.board_reset_n(token_board_resetn),.epoch_valid(aresetn&&engine_ready),.guard_fault(token_guard_fault_sync[2]),
 .freeze_requested(token_pause_request),.token_boundary_parked(token_sequence_parked),.lower_queues_quiet(token_lower_quiet),
 .boundary_downstream_valid(m_axi_arvalid||m_axi_awvalid||m_axi_wvalid||m_axi_rvalid||m_axi_bvalid),
 .arvalid(q_axi_arvalid),.arready(q_axi_arready),.arlen(q_axi_arlen),.rvalid(q_axi_rvalid),.rready(q_axi_rready),.rlast(q_axi_rlast),.rresp(q_axi_rresp),
 .awvalid(q_axi_awvalid),.awready(q_axi_awready),.awlen(q_axi_awlen),.wvalid(q_axi_wvalid),.wready(q_axi_wready),.wlast(q_axi_wlast),.bvalid(q_axi_bvalid),.bready(q_axi_bready),.bresp(q_axi_bresp),
 .quiet_ack(token_boundary_ack),.fault(token_witness_fault),.pending_reads(token_pending_reads),.pending_write_addresses(token_pending_aw),.pending_write_data(token_pending_w),.partial_write_beats(token_partial_w),.first_error(token_first_axi_error));
wire token_source_empty=aresetn&&engine_ready&&!token_witness_fault&&!busy&&!seq_core_start&&token_pending_reads==0&&token_pending_aw==0&&token_pending_w==0&&token_partial_w==0&&
 !(q_axi_arvalid||q_axi_awvalid||q_axi_wvalid||q_axi_rvalid||q_axi_bvalid||m_axi_arvalid||m_axi_awvalid||m_axi_wvalid||m_axi_rvalid||m_axi_bvalid);
reg[1:0]token_source_empty_history;
always @(posedge aclk or negedge token_board_resetn)if(!token_board_resetn)token_source_empty_history<=0;else token_source_empty_history<={token_source_empty_history[0],token_source_empty};
assign token_raw_boundary_quiet=token_source_empty&&(&token_source_empty_history);
// Passive ILA observation only. Clock is ungated 125MHz core aclk.
// Exclude all loads/prefill. Include first decode through EOS computation.
// Wait/stall counters overlap MAC/other activity; they are not additive phases.
function [4:0] profile_popcount(input [15:0] strobe);
 reg [2:0] n0,n1,n2,n3;reg [3:0] p0,p1;
 begin
  // Balanced nibble/pair tree, exact0..16 with normal four-state propagation.
  n0={2'd0,strobe[0]}+{2'd0,strobe[1]}+{2'd0,strobe[2]}+{2'd0,strobe[3]};
  n1={2'd0,strobe[4]}+{2'd0,strobe[5]}+{2'd0,strobe[6]}+{2'd0,strobe[7]};
  n2={2'd0,strobe[8]}+{2'd0,strobe[9]}+{2'd0,strobe[10]}+{2'd0,strobe[11]};
  n3={2'd0,strobe[12]}+{2'd0,strobe[13]}+{2'd0,strobe[14]}+{2'd0,strobe[15]};
  p0={1'b0,n0}+{1'b0,n1};p1={1'b0,n2}+{1'b0,n3};
  profile_popcount={1'b0,p0}+{1'b0,p1};
 end
endfunction
always @(posedge aclk)begin
 if(!aresetn||seq_start_pulse)begin
  decode_w4_cycles<=0;decode_w4_mac<=0;decode_w4_wait<=0;decode_w4_stall<=0;decode_read_beats<=0;decode_write_beats<=0;decode_written_bytes<=0;decode_w4_calls<=0;decode_core_completions<=0;profile_strobe_pending<=0;profile_write_byte_pending<=0;
 end else begin
  // Capture the actual accepted AXI mask before the balanced popcount tree.
  // Both valid stages drain after decode completion; unreset payload keeps X/Z.
  profile_strobe_pending<=seq_owned&&seq_busy&&seq_generated!=0&&q_axi_wvalid&&q_axi_wready;
  if(seq_owned&&seq_busy&&seq_generated!=0&&q_axi_wvalid&&q_axi_wready)profile_strobe_capture<=q_axi_wstrb;
  profile_write_byte_pending<=profile_strobe_pending;
  if(profile_strobe_pending)profile_write_byte_increment<=profile_popcount(profile_strobe_capture);
  if(profile_write_byte_pending)decode_written_bytes<=decode_written_bytes+{59'd0,profile_write_byte_increment};
  if(seq_owned&&seq_busy&&seq_generated!=0)begin
  if(done&&!profile_done_previous)begin
   decode_w4_cycles<=decode_w4_cycles+debug_gemv_profile[0 +:64];decode_w4_mac<=decode_w4_mac+debug_gemv_profile[64 +:64];
   decode_w4_wait<=decode_w4_wait+debug_gemv_profile[128 +:64];decode_w4_stall<=decode_w4_stall+debug_gemv_profile[192 +:64];
   decode_w4_calls<=decode_w4_calls+debug_gemv_profile[256 +:32];decode_core_completions<=decode_core_completions+1;
  end
  if(q_axi_rvalid&&q_axi_rready)decode_read_beats<=decode_read_beats+1;
  if(q_axi_wvalid&&q_axi_wready)decode_write_beats<=decode_write_beats+1;
  end
 end
end
endmodule


