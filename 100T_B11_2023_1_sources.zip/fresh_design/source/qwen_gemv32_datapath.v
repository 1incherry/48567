`timescale 1ns/1ps
// Four synchronized 8-lane blocks: 32 MAC DSPs + four scale DSPs.
module qwen_gemv32_datapath (
    input wire clk,input wire rst,input wire mode_i16,
    input wire in_valid,output wire in_ready,input wire signed [15:0] activation,
    input wire [511:0] weight_data,input wire in_last,
    input wire [511:0] group_scales,input wire first_group,input wire last_group,
    output wire out_valid,input wire out_ready,output wire [2047:0] output_acc,
    output wire error,output wire group_consumed
);
    wire [3:0] ready,valid,err,consumed;
    assign in_ready=&ready;assign out_valid=&valid;assign error=|err;
    assign group_consumed=&consumed;
    genvar g;
    generate for(g=0;g<4;g=g+1)begin: blocks
        wire [127:0] weights=mode_i16 ? weight_data[g*128+:128] : {96'd0,weight_data[g*32+:32]};
        qwen_gemv8_datapath core(.clk(clk),.rst(rst),.mode_i16(mode_i16),
            .in_valid(in_valid && in_ready),.in_ready(ready[g]),.activation(activation),
            .weight_data(weights),.in_last(in_last),.group_scales(group_scales[g*128+:128]),
            .first_group(first_group),.last_group(last_group),.out_valid(valid[g]),
            .out_ready(out_ready && out_valid),.output_acc(output_acc[g*512+:512]),
            .error(err[g]),.group_consumed(consumed[g]));
    end endgenerate
endmodule
