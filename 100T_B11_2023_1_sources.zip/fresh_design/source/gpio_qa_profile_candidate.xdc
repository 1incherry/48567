# Candidate only. Not selected in R20. No physical voltage confirmation yet.
if {![info exists ::GPIO_BANK35_CONFIRMED_MV] || $::GPIO_BANK35_CONFIRMED_MV != 3300} {error GPIO_BANK35_VCCIO_NOT_PHYSICALLY_CONFIRMED}
if {[llength [get_ports -quiet gpio_qa_rx]]!=1 || [llength [get_ports -quiet gpio_qa_tx]]!=1} {error GPIO_QA_PROFILE_PORTS_MISSING}
set_property PACKAGE_PIN H9 [get_ports gpio_qa_rx]
set_property PACKAGE_PIN J8 [get_ports gpio_qa_tx]
set_property IOSTANDARD LVCMOS33 [get_ports {gpio_qa_rx gpio_qa_tx}]
