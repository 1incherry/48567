`timescale 1ns/1ps
// A lost source health pulse clears every stage even with IO clock stopped.
// Restoration is local-clock synchronous after three healthy IO edges.
// This is health, not admission: normal freeze may drain outstanding R/B.
module mcs_async_health(input wire io_clk,board_reset_n,source_healthy,
 output wire io_healthy);
 (* ASYNC_REG="TRUE" *)reg[2:0]healthy_sync;
 always@(posedge io_clk or negedge board_reset_n or negedge source_healthy)
 if(!board_reset_n||!source_healthy)healthy_sync<=0;
 else healthy_sync<={healthy_sync[1:0],1'b1};
 assign io_healthy=healthy_sync[2];
endmodule
