// CPU-free current-model embedding fetch: 28 W4 blocks, each512B weights+64B scales.
// Selected token lane is retained exactly; output is original C FP32 arithmetic.
module qwen_embedding_axi128_v6 #(
 parameter [31:0] DDR_BASE=32'h80000000,parameter [32:0] DDR_BYTES=33'h010000000
)(
 input wire clk,rst_n,cmd_valid,output wire cmd_ready,
 input wire [15:0] cmd_token,cmd_seq,input wire [31:0] cmd_model_base,cmd_output_base,
 output wire rsp_valid,input wire rsp_ready,output reg [15:0] rsp_seq,
 output reg [7:0] rsp_error,output wire busy,output reg [31:0] cycle_count,
 output wire [31:0] m_axi_araddr,output wire [7:0] m_axi_arlen,
 output wire [2:0] m_axi_arsize,output wire [1:0] m_axi_arburst,
 output wire m_axi_arvalid,input wire m_axi_arready,
 input wire [127:0] m_axi_rdata,input wire [1:0] m_axi_rresp,
 input wire m_axi_rlast,m_axi_rvalid,output wire m_axi_rready,
 output wire [31:0] m_axi_awaddr,output wire [7:0] m_axi_awlen,
 output wire [2:0] m_axi_awsize,output wire [1:0] m_axi_awburst,
 output wire m_axi_awvalid,input wire m_axi_awready,
 output wire [127:0] m_axi_wdata,output wire [15:0] m_axi_wstrb,
 output wire m_axi_wlast,m_axi_wvalid,input wire m_axi_wready,
 input wire [1:0] m_axi_bresp,input wire m_axi_bvalid,output wire m_axi_bready
);
 localparam IDLE=0,RA=1,RD=2,WA=3,WD=4,WB=5,RESPONSE=6,VALIDATE=7,SELECT_WRITE=8,ENCODE_WRITE=9,PREP_READ=10,MULTIPLY_WRITE=11,PREP_WRITE_BASE=12,PREP_WRITE_ADDRESS=13,PREP_WRITE_BURST=14;
 reg [3:0] state;reg [4:0] group_index,token_lane;
 reg [5:0] read_word,burst_count,burst_length;
 reg [3:0] write_word,write_stop;reg read_bad;
 reg [31:0] model_address,output_address,group_address;
 // Descriptor payload is unknown until prepared; valid state owns it.
 reg [31:0] ar_descriptor_address;reg [5:0] ar_descriptor_beats;
 reg [31:0] write_group_address,aw_descriptor_address;reg [3:0] aw_descriptor_beats;
 reg [32:0] captured_start,captured_end,captured_output_end;reg command_bad;
 reg signed [3:0] weights[0:31];reg [15:0] scale;
 // Reset only the state/valid metadata. Payload stays unknown until selected.
 reg signed [3:0] selected_weights[0:3];reg [15:0] selected_scale;
 reg [127:0] write_payload;wire [127:0] encoded_payload;
 assign m_axi_wdata=write_payload;
 wire [32:0] window_end={1'b0,DDR_BASE}+DDR_BYTES;
 wire [32:0] requested_start={1'b0,cmd_model_base}+((cmd_token>>5)*33'd16128);
 assign cmd_ready=rst_n&&state==IDLE;assign rsp_valid=rst_n&&state==RESPONSE;
 assign busy=state!=IDLE&&state!=RESPONSE;
 wire [31:0] calculated_read_address=group_address+({26'd0,read_word}<<4);
 assign m_axi_araddr=ar_descriptor_address;
 assign m_axi_awaddr=aw_descriptor_address;
 wire [8:0] rpage=(13'd4096-{1'b0,calculated_read_address[11:0]})>>4;
 wire [8:0] wpage=(13'd4096-{1'b0,m_axi_awaddr[11:0]})>>4;
 wire [5:0] rleft=36-read_word;
 wire [3:0] wleft=8-write_word;
 wire [5:0] rburst=rleft<rpage?rleft:rpage[5:0];
 wire [3:0] wburst=wleft<wpage?wleft:wpage[3:0];
 assign m_axi_arvalid=rst_n&&state==RA;assign m_axi_arlen=ar_descriptor_beats-1;
 assign m_axi_arsize=4;assign m_axi_arburst=1;assign m_axi_rready=rst_n&&state==RD;
 assign m_axi_awvalid=rst_n&&state==WA;assign m_axi_awlen=aw_descriptor_beats-1;
 assign m_axi_awsize=4;assign m_axi_awburst=1;assign m_axi_wvalid=rst_n&&state==WD;
 assign m_axi_wlast=write_word+1==write_stop;assign m_axi_wstrb=16'hffff;
 assign m_axi_bready=rst_n&&state==WB;
 for(genvar lane=0;lane<4;lane=lane+1)begin:encode
  qwen_embedding_w4_half_fp32_pipeline_v1 arithmetic(.clk(clk),.sample(rst_n&&state==MULTIPLY_WRITE),.weight_i4(selected_weights[lane]),.scale_half(selected_scale),.result_fp32(encoded_payload[lane*32 +:32]));
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;group_index<=0;token_lane<=0;read_word<=0;burst_count<=0;burst_length<=0;write_word<=0;write_stop<=0;read_bad<=0;model_address<=0;output_address<=0;group_address<=0;scale<=0;rsp_seq<=0;rsp_error<=0;cycle_count<=0;captured_start<=0;captured_end<=0;captured_output_end<=0;command_bad<=0;end
  else begin
   if(busy)cycle_count<=cycle_count+1;
   case(state)
    IDLE:if(cmd_valid&&cmd_ready)begin
     rsp_seq<=cmd_seq;rsp_error<=0;cycle_count<=0;group_index<=0;token_lane<=cmd_token[4:0];read_word<=0;read_bad<=0;
     model_address<=requested_start[31:0];group_address<=requested_start[31:0];output_address<=cmd_output_base;
     captured_start<=requested_start;captured_end<=requested_start+33'd16128;captured_output_end<={1'b0,cmd_output_base}+33'd3584;
     command_bad<=cmd_token>=65535||cmd_model_base[3:0]!=0||cmd_output_base[3:0]!=0||
       {1'b0,cmd_model_base}<{1'b0,DDR_BASE}||{1'b0,cmd_output_base}<{1'b0,DDR_BASE};
     state<=VALIDATE;
    end
    VALIDATE:begin
     if(command_bad||captured_end>window_end||captured_output_end>window_end||
       ({1'b0,output_address}<captured_end&&captured_output_end>captured_start))
      begin rsp_error<=1;state<=RESPONSE;end
     else state<=PREP_READ;
    end
    PREP_READ:begin ar_descriptor_address<=calculated_read_address;ar_descriptor_beats<=rburst;state<=RA;end
    RA:if(m_axi_arvalid&&m_axi_arready)begin burst_length<=ar_descriptor_beats;burst_count<=0;state<=RD;end
    RD:if(m_axi_rvalid&&m_axi_rready)begin
     if(m_axi_rresp!=0)begin read_bad<=1;rsp_error<=2;end
     if(m_axi_rlast!=(burst_count+1==burst_length))begin read_bad<=1;rsp_error<=3;end
     if(read_word<32)weights[read_word]<=m_axi_rdata[token_lane*4 +:4];
     else if(read_word==32+(token_lane>>3))scale<=m_axi_rdata[token_lane[2:0]*16 +:16];
     read_word<=read_word+1;burst_count<=burst_count+1;
     if(m_axi_rlast)begin
      if(read_bad||m_axi_rresp!=0||burst_count+1!=burst_length)state<=RESPONSE;
      else if(read_word==35)begin write_word<=0;state<=PREP_WRITE_BASE;end
      else state<=PREP_READ;
     end
    end
    PREP_WRITE_BASE:begin write_group_address<=output_address+({27'd0,group_index}<<7);state<=PREP_WRITE_ADDRESS;end
    PREP_WRITE_ADDRESS:begin aw_descriptor_address<=write_group_address+({28'd0,write_word}<<4);state<=PREP_WRITE_BURST;end
    PREP_WRITE_BURST:begin aw_descriptor_beats<=wburst;state<=WA;end
    WA:if(m_axi_awvalid&&m_axi_awready)begin write_stop<=write_word+aw_descriptor_beats;state<=SELECT_WRITE;end
    SELECT_WRITE:begin
     selected_weights[0]<=weights[write_word*4+0];
     selected_weights[1]<=weights[write_word*4+1];
     selected_weights[2]<=weights[write_word*4+2];
     selected_weights[3]<=weights[write_word*4+3];
     selected_scale<=scale;state<=MULTIPLY_WRITE;
    end
    MULTIPLY_WRITE:state<=ENCODE_WRITE;
    ENCODE_WRITE:begin write_payload<=encoded_payload;state<=WD;end
    WD:if(m_axi_wvalid&&m_axi_wready)begin write_word<=write_word+1;if(m_axi_wlast)state<=WB;else state<=SELECT_WRITE;end
    WB:if(m_axi_bvalid&&m_axi_bready)begin
     if(m_axi_bresp!=0)begin rsp_error<=4;state<=RESPONSE;end
     else if(write_word<8)state<=PREP_WRITE_BASE;
     else if(group_index==27)state<=RESPONSE;
     else begin group_index<=group_index+1;group_address<=group_address+576;read_word<=0;read_bad<=0;state<=PREP_READ;end
    end
    RESPONSE:if(rsp_ready)state<=IDLE;
    default:begin rsp_error<=255;state<=RESPONSE;end
   endcase
  end
 end
endmodule
