// CPU-free operation scheduler. Executors must commit writes before responding.
// This module does not implement arithmetic, DMA or MIG; those must be connected.
// Offsets are relative to the model/DDR address window, never host pointers.
module qwen_token_controller_v1 #(parameter ENABLE_CHECKPOINT=0)(
 input wire checkpoint_enable,checkpoint_resume,input wire [15:0] checkpoint_seq,
 output wire checkpoint_paused,
 input wire clk,rst_n,start,
 input wire [15:0] start_token,
 input wire [9:0] start_position,
 input wire start_output_head,start_emit_logits,
 output reg busy,done,error,
 output reg [9:0] result_position,
 output reg [15:0] result_token,
 output reg result_token_valid,
 output wire [31:0] debug_control,debug_sequence,
 output wire cmd_valid,
 input wire cmd_ready,
 output wire [15:0] cmd_seq,
 output wire [15:0] cmd_token,
 output wire [9:0] cmd_position,
 output wire [5:0] cmd_stage,
 output wire [4:0] cmd_layer,
 output wire [3:0] cmd_head,
 output reg [3:0] cmd_op,cmd_src,cmd_dst,
 output reg [15:0] cmd_rows,cmd_cols,cmd_stride_groups,cmd_padding,cmd_vector_offset,
 output reg [31:0] cmd_matrix_offset,cmd_param_offset,
 input wire rsp_valid,
 output wire rsp_ready,
 input wire [15:0] rsp_seq,rsp_token,
 input wire rsp_error
);
 localparam EMBED=0,NORM=1,QUANT=2,W4=3,I16=4,LINEAR=5,ROPE=6,KVSTORE=7,SCORE=8,SOFTMAX=9,VALUE=10,RESIDUAL=11,SILU=12,LOGITS=13,ARGMAX=14;
 localparam HIDDEN=0,NORMED=1,QUERY=2,KEY=3,VAL=4,ATTN=5,PROJ=6,GATE=7,UP=8,SCORES=9,WEIGHTED=10,X=11,Y=12,KV_TEMP=13;
 localparam [31:0] K_BASE=32'h0e000000,V_BASE=32'h0e300000,KS_BASE=32'h0e600000,VS_BASE=32'h0e618000;
 reg [5:0] stage;
 reg [4:0] layer;
 reg [3:0] head;
 reg kv_head,output_head,emit_logits,inflight;
 reg [15:0] seq,token;
 reg response_pending,response_bad,response_finish;reg [15:0] response_token;
 reg [9:0] position;
 wire [15:0] t={6'b0,position}+16'd1;
 wire [15:0] pad=(t+16'd31)&16'hffe0;
 wire group_head=head>=7;
 wire [31:0] k_matrix=K_BASE+((layer*2+group_head)<<16);
 wire [31:0] v_matrix=V_BASE+((layer*2+group_head)<<16);
 wire [31:0] ks=KS_BASE+((layer*2+group_head)<<11);
 wire [31:0] vs=VS_BASE+((layer*2+group_head)<<11);
 `include "qwen_layer_offsets_v1.svh"
 reg checkpoint_hold;
 wire checkpoint_hit=checkpoint_enable && (seq==checkpoint_seq);
 assign checkpoint_paused=ENABLE_CHECKPOINT && checkpoint_hold;
 assign cmd_valid=busy&&!inflight;
 assign rsp_ready=busy&&inflight&&!response_pending;
 assign cmd_seq=seq;
 assign cmd_token=token;
 assign cmd_position=position;
 assign cmd_stage=stage;
 assign cmd_layer=layer;
 assign cmd_head=(stage>=11&&stage<=14)?{3'b0,kv_head}:head;
 // Read-only observation outputs; no control or arithmetic feedback.
 assign debug_control={9'b0,head,layer,stage,1'b0,emit_logits,output_head,kv_head,inflight,error,done,busy};
 assign debug_sequence={token,seq};
 always @* begin
  cmd_op=EMBED;cmd_src=HIDDEN;cmd_dst=HIDDEN;cmd_rows=896;cmd_cols=0;cmd_stride_groups=0;cmd_padding=896;cmd_vector_offset=0;cmd_matrix_offset=0;cmd_param_offset=0;
  case(stage)
   0:begin cmd_op=EMBED;cmd_matrix_offset=0;end
   1,26,37:begin cmd_op=NORM;cmd_dst=NORMED;cmd_param_offset=stage==1?layer_offset(layer,10):stage==26?layer_offset(layer,11):32'd234590208;end
   2,27,38:begin cmd_op=QUANT;cmd_src=NORMED;cmd_dst=X;cmd_cols=896;end
   3,5,7,23,28,30,34,39:begin
    cmd_op=W4;cmd_src=X;cmd_dst=Y;cmd_cols=stage==34?4864:896;cmd_stride_groups=cmd_cols>>5;
    case(stage)
     3:begin cmd_rows=896;cmd_matrix_offset=layer_offset(layer,0);end
     5:begin cmd_rows=128;cmd_matrix_offset=layer_offset(layer,1);end
     7:begin cmd_rows=128;cmd_matrix_offset=layer_offset(layer,2);end
     23:begin cmd_rows=896;cmd_matrix_offset=layer_offset(layer,3);end
     28:begin cmd_rows=4864;cmd_matrix_offset=layer_offset(layer,4);end
     30:begin cmd_rows=4864;cmd_matrix_offset=layer_offset(layer,5);end
     34:begin cmd_rows=896;cmd_matrix_offset=layer_offset(layer,6);end
     39:begin cmd_rows=65535;cmd_matrix_offset=0;end
    endcase
    cmd_padding=cmd_rows;
   end
   4,6,8,24,29,31,35:begin
    cmd_op=LINEAR;cmd_src=Y;
    case(stage)
     4:begin cmd_dst=QUERY;cmd_param_offset=layer_offset(layer,7);end
     6:begin cmd_dst=KEY;cmd_rows=128;cmd_param_offset=layer_offset(layer,8);end
     8:begin cmd_dst=VAL;cmd_rows=128;cmd_param_offset=layer_offset(layer,9);end
     24,35:cmd_dst=PROJ;
     29:begin cmd_dst=GATE;cmd_rows=4864;end
     31:begin cmd_dst=UP;cmd_rows=4864;end
    endcase
    cmd_padding=cmd_rows;
   end
   9,10:begin cmd_op=ROPE;cmd_src=stage==9?QUERY:KEY;cmd_dst=cmd_src;cmd_rows=stage==9?896:128;cmd_padding=cmd_rows;end
   11,13:begin cmd_op=QUANT;cmd_src=stage==11?KEY:VAL;cmd_dst=KV_TEMP;cmd_rows=64;cmd_cols=64;cmd_padding=64;cmd_vector_offset={9'b0,kv_head,6'b0};end
   12,14:begin cmd_op=KVSTORE;cmd_src=KV_TEMP;cmd_rows=64;cmd_cols=t;cmd_padding=64;cmd_stride_groups=stage==12?2:16;
    cmd_matrix_offset=(stage==12?K_BASE:V_BASE)+((layer*2+kv_head)<<16);
    cmd_param_offset=(stage==12?KS_BASE:VS_BASE)+((layer*2+kv_head)<<11)+(position<<2);
   end
   15:begin cmd_op=QUANT;cmd_src=QUERY;cmd_dst=X;cmd_rows=64;cmd_cols=64;cmd_padding=64;cmd_vector_offset=head<<6;end
   16:begin cmd_op=I16;cmd_src=X;cmd_dst=Y;cmd_rows=t;cmd_cols=64;cmd_padding=t;cmd_stride_groups=2;cmd_matrix_offset=k_matrix;end
   17:begin cmd_op=SCORE;cmd_src=Y;cmd_dst=SCORES;cmd_rows=t;cmd_padding=t;cmd_param_offset=ks;end
   18:begin cmd_op=SOFTMAX;cmd_src=SCORES;cmd_dst=WEIGHTED;cmd_rows=t;cmd_padding=t;cmd_param_offset=vs;end
   19:begin cmd_op=QUANT;cmd_src=WEIGHTED;cmd_dst=X;cmd_rows=t;cmd_cols=t;cmd_padding=pad;end
   20:begin cmd_op=I16;cmd_src=X;cmd_dst=Y;cmd_rows=64;cmd_cols=pad;cmd_padding=64;cmd_stride_groups=16;cmd_matrix_offset=v_matrix;end
   21:begin cmd_op=VALUE;cmd_src=Y;cmd_dst=ATTN;cmd_rows=64;cmd_padding=64;cmd_vector_offset=head<<6;end
   22:begin cmd_op=QUANT;cmd_src=ATTN;cmd_dst=X;cmd_cols=896;end
   25,36:begin cmd_op=RESIDUAL;cmd_src=PROJ;cmd_dst=HIDDEN;end
   32:begin cmd_op=SILU;cmd_src=GATE;cmd_dst=GATE;cmd_rows=4864;cmd_padding=4864;end
   33:begin cmd_op=QUANT;cmd_src=GATE;cmd_dst=X;cmd_rows=4864;cmd_cols=4864;cmd_padding=4864;end
   40:begin cmd_op=LOGITS;cmd_src=Y;cmd_rows=65535;cmd_padding=65535;end
   41:begin cmd_op=ARGMAX;cmd_src=Y;cmd_rows=65535;cmd_padding=65535;end
   default:begin cmd_op=15;end
  endcase
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin checkpoint_hold<=0;response_pending<=0;busy<=0;done<=0;error<=0;inflight<=0;stage<=0;layer<=0;head<=0;kv_head<=0;seq<=0;token<=0;position<=0;output_head<=0;emit_logits<=0;result_position<=0;result_token<=0;result_token_valid<=0;end
  else begin
   if(start&&!busy)begin
    checkpoint_hold<=0;done<=0;error<=0;result_token_valid<=0;stage<=0;layer<=0;head<=0;kv_head<=0;seq<=0;inflight<=0;
    token<=start_token;position<=start_position;output_head<=start_output_head;emit_logits<=start_emit_logits;
    if(start_token>=65535||start_position>=512)begin busy<=0;done<=1;error<=1;end else busy<=1;
   end
   if(cmd_valid&&cmd_ready)inflight<=1;
   // Accept once, then retire the captured checked response one cycle later.
   // Stage/seq/layer remain unchanged while inflight and response_pending hold.
   if(rsp_valid&&rsp_ready)begin
    response_pending<=1;response_token<=rsp_token;
    response_bad<=rsp_error||rsp_seq!=seq||(stage==41&&rsp_token>=65535);
    response_finish<=stage==41||(stage==36&&layer==23&&!output_head);
   end
   if(ENABLE_CHECKPOINT && response_pending && (checkpoint_hold || checkpoint_hit) && !checkpoint_resume)checkpoint_hold<=1;
   if(response_pending && (!ENABLE_CHECKPOINT || (!checkpoint_hold && !checkpoint_hit) || checkpoint_resume))begin
    checkpoint_hold<=0;response_pending<=0;inflight<=0;
    if(response_bad)begin busy<=0;done<=1;error<=1;result_token_valid<=0;end
    else begin
     seq<=seq+1;
     if(response_finish)begin
      busy<=0;done<=1;result_position<=position+1;result_token<=response_token;result_token_valid<=stage==41;
     end else if(stage==14)begin
      if(!kv_head)begin kv_head<=1;stage<=11;end else begin kv_head<=0;head<=0;stage<=15;end
     end else if(stage==21)begin
      if(head<13)begin head<=head+1;stage<=15;end else begin head<=0;stage<=22;end
     end else if(stage==36)begin
      if(layer<23)begin layer<=layer+1;stage<=1;end else stage<=37;
     end else if(stage==39&&!emit_logits)stage<=41;
     else stage<=stage+1;
    end
   end
  end
 end
endmodule
