// Original C negative exponential table/interpolation, binary32 operation order.
// Explicit shared CE permits use inside a stalled frame controller.
module qwen_exp_fp32_pipeline #(parameter EXP_ROM_FILE="exp_coefficients.hex")(
 input wire clk,rst_n,ce,in_valid,
 input wire [31:0] x_fp32,
 output wire out_valid,
 output wire [31:0] result_fp32
);
 wire decoded_valid,above32,nonfinite;wire [12:0] index;wire [31:0] fraction;
 qwen_exp_fp32_decode_pipeline decode(.clk,.rst_n,.ce,.in_valid,.x_fp32,
  .out_valid(decoded_valid),.index,.fraction_fp32(fraction),.above32,.nonfinite);
 (* rom_style="block" *) reg [63:0] coefficients[0:4096];
 reg [63:0] coeff;reg [31:0] frac;reg rom_valid,rom_zero;
 initial $readmemh(EXP_ROM_FILE,coefficients);
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin coeff<=0;frac<=0;rom_valid<=0;rom_zero<=0;end
  else if(ce)begin coeff<=coefficients[index];frac<=fraction;rom_valid<=decoded_valid;rom_zero<=above32;end
 end
 wire product_valid;wire [31:0] product,base_delayed,interpolated;
 qwen_fp_mul interpolate_mul(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(rom_valid),.s_axis_a_tdata(frac),
  .s_axis_b_tvalid(rom_valid),.s_axis_b_tdata(coeff[63:32]),
  .m_axis_result_tvalid(product_valid),.m_axis_result_tdata(product));
 qwen_ce_delay #(.WIDTH(32),.DEPTH(8)) base_delay(.clk,.rst_n,.ce,.din(coeff[31:0]),.dout(base_delayed));
 qwen_fp_add interpolate_add(.aclk(clk),.aclken(ce),.aresetn(rst_n),
  .s_axis_a_tvalid(product_valid),.s_axis_a_tdata(base_delayed),
  .s_axis_b_tvalid(product_valid),.s_axis_b_tdata(product),
  .m_axis_result_tvalid(out_valid),.m_axis_result_tdata(interpolated));
 wire zero;
 qwen_ce_delay #(.WIDTH(1),.DEPTH(19)) zero_delay(.clk,.rst_n,.ce,.din(rom_zero),.dout(zero));
 assign result_fp32=zero?32'd0:interpolated;
endmodule
