`timescale 1ns/1ps
// A source125 transaction fence. Inputs completion/consumption refer ONLY to
// the first accepted job,not a later CSR B or the current busy level.
module mcs_main_release_fence125_r3(input wire clk,board_reset_n,
 input wire start,output wire ready,output reg qualify_done,qualify_good,
 input wire drain_ack,drain_fault,main_retired,owner_cpu,
 input wire this_response_consumed,input wire io_completion_toggle,
 input wire prepare_response,closed_ack,output reg close_main,
 output reg freeze_main,output reg fault,output wire active);
 localparam IDLE=0,QUALIFY=1,RETIRE=2,ZERO=3;
 reg[1:0]state;reg own_io_baseline,response_consumed,io_completed;
 assign ready=state==IDLE&&!fault&&!drain_ack&&!main_retired&&!closed_ack;assign active=state!=IDLE;
 always@(posedge clk or negedge board_reset_n)begin
 if(!board_reset_n)begin close_main<=0;state<=IDLE;own_io_baseline<=0;response_consumed<=0;io_completed<=0;freeze_main<=0;fault<=0;qualify_done<=0;qualify_good<=0;end
 else begin
  qualify_done<=0;
  if(state!=IDLE&&drain_fault)fault<=1;
  if(start&&!ready)begin fault<=1;freeze_main<=1;end
  case(state)
   IDLE:if(start&&ready)begin close_main<=0;freeze_main<=1;own_io_baseline<=io_completion_toggle;response_consumed<=0;io_completed<=0;qualify_good<=0;state<=QUALIFY;end
   QUALIFY:begin
    if(io_completion_toggle!=own_io_baseline)io_completed<=1;
    if(this_response_consumed)begin fault<=1;freeze_main<=1;end
    if(drain_ack||drain_fault)begin qualify_done<=1;qualify_good<=drain_ack&&!drain_fault&&!fault&&!start&&!this_response_consumed;if(drain_fault)fault<=1;state<=RETIRE;end
   end
   RETIRE:begin
    if(prepare_response)close_main<=1;
    if(this_response_consumed)begin response_consumed<=1;if(!closed_ack)fault<=1;end
    if(io_completion_toggle!=own_io_baseline)io_completed<=1;
    if(closed_ack&&(response_consumed||this_response_consumed)&&main_retired&&(!owner_cpu||io_completed||io_completion_toggle!=own_io_baseline))begin close_main<=0;freeze_main<=0;state<=ZERO;end
   end
   ZERO:if(!drain_ack&&!main_retired&&!closed_ack)state<=IDLE;
   default:begin fault<=1;freeze_main<=1;end
  endcase
 end end
endmodule
