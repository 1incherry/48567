`timescale 1ns/1ps
// Read-only packet observation bank + explicit snapshot command. No inference,
// root authority, action, arbitrary DDR, or Qwen GO port is present here.
module ntr2_context_axil_replay(input wire clk,rst_n,
 input wire[31:0]reservation_status,input wire reservation_acquire_ready,reservation_release_ready,output reg reservation_acquire,reservation_release,
 input wire replay_consumed,output reg replay_armed,output reg[31:0]replay_expected_crc,replay_session,replay_frame,
 input wire report_valid,output wire report_ready,input wire[2047:0]report_body,input wire transport_fault,
 input wire[11:0]s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire[31:0]s_wdata,input wire[3:0]s_wstrb,input wire s_wvalid,output wire s_wready,
 output reg[1:0]s_bresp,output reg s_bvalid,input wire s_bready,
 input wire[11:0]s_araddr,input wire s_arvalid,output wire s_arready,
 output reg[31:0]s_rdata,output reg[1:0]s_rresp,output reg s_rvalid,input wire s_rready,
 output reg tx_start,output reg[863:0]tx_payload,output reg[31:0]tx_sequence,tx_session,input wire tx_busy,tx_error,
 output wire quiescent,output reg[31:0]reports_received
);

 // Two true BRAM banks. The CDC destination holds all 2048 source bits until
 // report_ready; no local 2048-bit flip-flop capture or inferred multiport RAM.
 (* ram_style="block" *)reg[31:0]latest_words[0:63];
 (* ram_style="block" *)reg[31:0]frozen_words[0:63];
 reg latest_valid,frozen_valid;reg[31:0]snapshot_number;
 reg capture_active,freeze_active,freeze_pending,body_read_pending,snapshot_fault;
 reg[5:0]capture_index,freeze_write_index;
 reg[6:0]freeze_issued;
 reg[31:0]latest_q,frozen_q;
 wire record_fault=transport_fault||snapshot_fault;
 wire body_read_launch=s_arvalid&&s_arready&&s_araddr>=12'h100&&s_araddr<12'h200&&s_araddr[1:0]==0&&frozen_valid&&!record_fault;
 always @(posedge clk)begin
  if(rst_n&&capture_active&&report_valid&&!record_fault)latest_words[capture_index]<=report_body[2047-capture_index*32-:32];
  if(rst_n&&freeze_active&&freeze_issued<64&&!record_fault)latest_q<=latest_words[freeze_issued[5:0]];
  if(rst_n&&freeze_pending&&!record_fault)frozen_words[freeze_write_index]<=latest_q;
  if(body_read_launch)frozen_q<=frozen_words[s_araddr[7:2]];
 end
 reg awhold,whold;reg[11:0]aw;reg[31:0]wd;reg[3:0]ws;
 assign report_ready=rst_n&&capture_active&&capture_index==63&&!record_fault;assign s_awready=rst_n&&!awhold&&!s_bvalid&&!freeze_active;assign s_wready=rst_n&&!whold&&!s_bvalid&&!freeze_active;
 assign s_arready=rst_n&&!s_rvalid&&!body_read_pending;
 assign quiescent=rst_n&&!awhold&&!whold&&!s_bvalid&&!s_rvalid&&!s_awvalid&&!s_wvalid&&!s_arvalid&&!tx_start&&!tx_busy&&!capture_active&&!freeze_active&&!body_read_pending;
 // Trusted JTAG-only replay authority, never an Ethernet command or model result.
 reg[31:0]last_replay_session,last_replay_frame;
 wire replay_configuration_safe=reservation_status[9]&&!reservation_status[8]&&(&reservation_status[7:0])&&!record_fault&&!tx_busy&&!tx_start;
 integer wordindex;
 always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin replay_armed<=0;replay_expected_crc<=0;replay_session<=0;replay_frame<=0;last_replay_session<=0;last_replay_frame<=0;reservation_acquire<=0;reservation_release<=0;capture_active<=0;freeze_active<=0;freeze_pending<=0;body_read_pending<=0;snapshot_fault<=0;capture_index<=0;freeze_write_index<=0;freeze_issued<=0;latest_valid<=0;frozen_valid<=0;snapshot_number<=0;awhold<=0;whold<=0;aw<=0;wd<=0;ws<=0;s_bresp<=0;s_bvalid<=0;s_rdata<=0;s_rresp<=0;s_rvalid<=0;tx_start<=0;tx_payload<=0;tx_sequence<=0;tx_session<=0;reports_received<=0;end
 else begin
 tx_start<=0;reservation_acquire<=0;reservation_release<=0;
 if(replay_consumed&&replay_armed)begin replay_armed<=0;last_replay_session<=replay_session;last_replay_frame<=replay_frame;end

 if(!capture_active&&!freeze_active&&report_valid&&!record_fault)begin capture_active<=1;capture_index<=0;latest_valid<=0;end
 if(capture_active&&!record_fault)begin
  if(!report_valid)begin snapshot_fault<=1;capture_active<=0;latest_valid<=0;end
  else if(capture_index==63)begin capture_active<=0;latest_valid<=1;reports_received<=reports_received+1'b1;end
  else capture_index<=capture_index+1'b1;
 end
 if(freeze_active)begin
  freeze_pending<=freeze_issued<64;
  if(freeze_issued<64)begin freeze_write_index<=freeze_issued[5:0];freeze_issued<=freeze_issued+1'b1;end
  if(freeze_pending&&freeze_write_index==63)begin freeze_active<=0;freeze_pending<=0;frozen_valid<=1;s_bvalid<=1;s_bresp<=0;end
 end
 if(body_read_pending)begin body_read_pending<=0;s_rdata<=frozen_q;s_rresp<=0;s_rvalid<=1;end

 if(s_awvalid&&s_awready)begin aw<=s_awaddr;awhold<=1;end
 if(s_wvalid&&s_wready)begin wd<=s_wdata;ws<=s_wstrb;whold<=1;end
 if(s_bvalid&&s_bready)s_bvalid<=0;
 if(awhold&&whold&&!s_bvalid)begin
 awhold<=0;whold<=0;s_bvalid<=1;s_bresp<=2'b10;
 if(ws==15&&aw[1:0]==0)begin
  if(aw==12'h040&&!replay_armed&&replay_configuration_safe)begin replay_expected_crc<=wd;s_bresp<=0;end
  else if(aw==12'h044&&!replay_armed&&replay_configuration_safe)begin replay_session<=wd;s_bresp<=0;end
  else if(aw==12'h048&&!replay_armed&&replay_configuration_safe)begin replay_frame<=wd;s_bresp<=0;end
  else if(aw==12'h04c&&wd==1&&!replay_armed&&replay_configuration_safe&&replay_session>last_replay_session&&replay_frame>last_replay_frame)begin replay_armed<=1;s_bresp<=0;end
  else if(aw==12'h04c&&wd==2&&replay_configuration_safe)begin replay_armed<=0;s_bresp<=0;end
  else if(aw==12'h034&&wd==1&&reservation_acquire_ready)begin reservation_acquire<=1;s_bresp<=0;end
  else if(aw==12'h034&&wd==2&&reservation_release_ready)begin reservation_release<=1;s_bresp<=0;end
  else if(aw==12'h010&&wd==1&&latest_valid&&!capture_active&&!report_valid&&!record_fault)begin freeze_active<=1;freeze_issued<=0;freeze_pending<=0;frozen_valid<=0;snapshot_number<=reports_received;s_bvalid<=0;end
  else if(aw==12'h020&&wd==1&&!tx_busy&&!tx_error&&!record_fault)begin tx_start<=1;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw==12'h024)begin tx_sequence<=wd;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw==12'h028)begin tx_session<=wd;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw>=12'h300&&aw<12'h36c)begin
   tx_payload[(aw-12'h300)*8+:32]<=wd;s_bresp<=0;
  end
 end
 end
 if(s_rvalid&&s_rready)s_rvalid<=0;
 if(s_arvalid&&s_arready)begin
 s_rvalid<=1;s_rdata<=0;s_rresp<=0;
 case(s_araddr)
 12'h000:s_rdata<=32'h4e545232;
 12'h004:s_rdata<={26'd0,record_fault,tx_error,tx_busy,1'b0,frozen_valid,latest_valid};
 12'h008:s_rdata<=reports_received;
 12'h00c:s_rdata<=snapshot_number;
 12'h030:s_rdata<=reservation_status;
 12'h040:s_rdata<=replay_expected_crc;
 12'h044:s_rdata<=replay_session;
 12'h048:s_rdata<=replay_frame;
 12'h04c:s_rdata<={30'd0,replay_configuration_safe,replay_armed};
 12'h050:s_rdata<=last_replay_session;
 12'h054:s_rdata<=last_replay_frame;
 12'h024:s_rdata<=tx_sequence;
 12'h028:s_rdata<=tx_session;
 default:if(body_read_launch)begin body_read_pending<=1;s_rvalid<=0;end else s_rresp<=2'b10;
 endcase
 end
 // A fault cannot make a partially copied record visible or acknowledge a
 // partial freeze. An existing AXI response remains held until real ready.
 if(record_fault)begin
  snapshot_fault<=1;capture_active<=0;freeze_active<=0;freeze_pending<=0;
  latest_valid<=0;frozen_valid<=0;body_read_pending<=0;tx_start<=0;
  if(freeze_active)begin s_bvalid<=1;s_bresp<=2'b10;end
  if(body_read_pending&&!s_rvalid)begin s_rvalid<=1;s_rresp<=2'b10;s_rdata<=0;end
 end
 end end
endmodule
