`timescale 1ns/1ps
// Test-system serial resource lease, not security authority. Qwen text cannot
// access this port. Caller must use actual source-ready/release, real MIG drain.
module camera_qwen_reservation(
 input wire clk,rst_n,memory_reset_n,memory_calibrated,
 input wire request_reservation,release_reservation,
 input wire camera_sublease_active,output wire reservation_owner_live,
 output wire acquire_ready,release_ready,
 input wire camera_ready,sender_busy,packet_quiescent,control_quiescent,
 input wire camera_bridge_quiescent_ui,shared_memory_quiescent_ui,
 output wire capture_inhibit,reservation_held,reservation_granted,
 output wire[31:0]status,output reg fault
);
 (* ASYNC_REG="TRUE" *)reg[2:0]bridge_quiet_sync=0,shared_quiet_sync=0;
 (* ASYNC_REG="TRUE" *)reg[2:0]memory_alive=0;
 wire memory_live=memory_reset_n&&memory_calibrated;
 always @(posedge clk or negedge rst_n or negedge memory_live)
  if(!rst_n||!memory_live)begin bridge_quiet_sync<=0;shared_quiet_sync<=0;memory_alive<=0;end
  else begin bridge_quiet_sync<={bridge_quiet_sync[1:0],camera_bridge_quiescent_ui};shared_quiet_sync<={shared_quiet_sync[1:0],shared_memory_quiescent_ui};memory_alive<={memory_alive[1:0],1'b1};end
 reg held,granted;reg[3:0]hold_age;reg[1:0]quiet_history;
 wire all_quiet=memory_alive[2]&&camera_ready&&!sender_busy&&packet_quiescent&&control_quiescent&&bridge_quiet_sync[2]&&shared_quiet_sync[2];
 assign acquire_ready=rst_n&&!held&&!fault&&memory_alive[2];
 assign release_ready=rst_n&&held&&granted&&!fault&&all_quiet&&(&quiet_history);
 assign reservation_held=held;
 // New versioned subowner permit; raw camera_ready/status stay truthful.
 assign reservation_owner_live=rst_n&&granted&&held&&!fault&&memory_alive[2]&&(camera_ready||camera_sublease_active);
 assign reservation_granted=rst_n&&granted&&held&&!fault&&memory_alive[2]&&camera_ready;
 assign capture_inhibit=(held&&!camera_sublease_active)||fault||!memory_alive[2];
 assign status={22'd0,memory_alive[2],fault,control_quiescent,packet_quiescent,shared_quiet_sync[2],bridge_quiet_sync[2],!sender_busy,camera_ready,reservation_granted,held};
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin held<=0;granted<=0;hold_age<=0;quiet_history<=0;fault<=0;end
  else begin
   quiet_history<={quiet_history[0],all_quiet};
   if(held&&granted&&(!memory_alive[2]||(!camera_ready&&!camera_sublease_active)))fault<=1;
   if(request_reservation&&acquire_ready)begin held<=1;granted<=0;hold_age<=0;quiet_history<=0;end
   else if(held)begin
    if(hold_age!=15)hold_age<=hold_age+1'b1;
    if(!granted&&!fault&&hold_age>=6&&all_quiet&&(&quiet_history))granted<=1;
    if(release_reservation&&release_ready)begin held<=0;granted<=0;hold_age<=0;quiet_history<=0;end
   end
  end
 end
endmodule

