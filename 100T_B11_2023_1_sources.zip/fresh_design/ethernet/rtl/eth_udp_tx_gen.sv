`timescale 1ns/1ps
// Finite RTL Ethernet/IPv4/UDP producer with a software-supplied, locked payload.
module eth_udp_tx_gen #(parameter [47:0] SOURCE_MAC=48'h025052587035, DEST_MAC=48'h025052583100, parameter [31:0] SOURCE_IP=32'hc0a8010b,DEST_IP=32'hc0a8010c,parameter integer PAYLOAD_WORD_INTERFACE=0)(
 input wire [863:0] payload,
 output reg payload_word_read,output reg[4:0]payload_word_address,input wire[31:0]payload_word_data,input wire payload_word_valid,input wire payload_memory_live,
 input wire clk,rst,start,input wire [15:0] frame_count,
 input wire [31:0] seq_base,seed,gap_cycles,
 output wire [7:0] m_axis_tdata,output wire m_axis_tvalid,
 input wire m_axis_tready,output wire m_axis_tlast,
 output reg busy,done,output reg [31:0] sent_count,last_seq,output reg error
);
 localparam IDLE=0,SEND=1,GAP=2;
 reg [1:0] state;
 reg [7:0] index;
 reg [31:0] seq_reg,seed_latched,count_latched,gap_latched,gap_left,crc;
 function automatic [31:0] crc_byte(input [31:0] old,input [7:0] data);
  reg [31:0] v;integer bitnum;
  begin v=old^{24'b0,data};for(bitnum=0;bitnum<8;bitnum=bitnum+1)v=v[0]?(v>>1)^32'hedb88320:(v>>1);crc_byte=v;end
 endfunction
 function automatic [15:0] ip_checksum(input [15:0] id);
  reg [31:0] sum;
  begin sum=32'h4500+32'd156+id+32'h4000+32'h4011+SOURCE_IP[31:16]+SOURCE_IP[15:0]+DEST_IP[31:16]+DEST_IP[15:0];sum={16'b0,sum[15:0]}+sum[31:16];sum={16'b0,sum[15:0]}+sum[31:16];ip_checksum=~sum[15:0];end
 endfunction
 // RAM word0 is requested at accepted header byte52. Subsequent words
 // are prefetched at the first accepted byte of the current four-byte word.
 // Two registered interface cycles fit before its final byte is accepted.
 reg[31:0]payload_current_word,payload_next_word;reg[4:0]payload_next_address;
 reg payload_read_pending,payload_read_prime;
 wire payload_cache_reset=rst||(PAYLOAD_WORD_INTERFACE!=0&&!payload_memory_live);
 always @(posedge clk or posedge payload_cache_reset)begin
  if(payload_cache_reset)begin payload_word_read<=0;payload_word_address<=0;payload_current_word<=0;payload_next_word<=0;payload_next_address<=1;payload_read_pending<=0;payload_read_prime<=0;end
  else begin
   payload_word_read<=0;
   if(PAYLOAD_WORD_INTERFACE!=0)begin
    if(m_axis_tvalid&&m_axis_tready&&index==52)begin
     payload_word_read<=1;payload_word_address<=0;payload_next_address<=1;payload_read_pending<=1;payload_read_prime<=1;
    end else if(m_axis_tvalid&&m_axis_tready&&index>=58&&index<162&&index[1:0]==2'd2)begin
     payload_word_read<=1;payload_word_address<=payload_next_address;payload_next_address<=payload_next_address+1'b1;payload_read_pending<=1;payload_read_prime<=0;
    end
    if(payload_word_valid&&payload_read_pending)begin
     if(payload_read_prime)payload_current_word<=payload_word_data;else payload_next_word<=payload_word_data;
     payload_read_pending<=0;
    end
    if(m_axis_tvalid&&m_axis_tready&&index>=61&&index<165&&index[1:0]==2'd1)payload_current_word<=payload_next_word;
   end
  end
 end
 reg [15:0] checksum;
 // Header bytes 24/25 are consumed well after the sequence changes.
 always @(posedge clk) begin
  if (rst) checksum <= 0;
  else checksum <= ip_checksum(seq_reg[15:0]);
 end
 wire [31:0] final_crc=~crc;
 reg [7:0] value;
 always @* begin
  value=0;
  case(index)
   0:value=DEST_MAC[47:40];1:value=DEST_MAC[39:32];2:value=DEST_MAC[31:24];3:value=DEST_MAC[23:16];4:value=DEST_MAC[15:8];5:value=DEST_MAC[7:0];
   6:value=SOURCE_MAC[47:40];7:value=SOURCE_MAC[39:32];8:value=SOURCE_MAC[31:24];9:value=SOURCE_MAC[23:16];10:value=SOURCE_MAC[15:8];11:value=SOURCE_MAC[7:0];
   12:value=8'h08;13:value=0;14:value=8'h45;15:value=0;16:value=0;17:value=8'h9c;
   18:value=seq_reg[15:8];19:value=seq_reg[7:0];20:value=8'h40;21:value=0;
   22:value=8'h40;23:value=8'h11;24:value=checksum[15:8];25:value=checksum[7:0];
   26:value=SOURCE_IP[31:24];27:value=SOURCE_IP[23:16];28:value=SOURCE_IP[15:8];29:value=SOURCE_IP[7:0];
   30:value=DEST_IP[31:24];31:value=DEST_IP[23:16];32:value=DEST_IP[15:8];33:value=DEST_IP[7:0];
   34:value=8'h1f;35:value=8'h91;36:value=8'h1f;37:value=8'h91;
   38:value=0;39:value=8'h88;40:value=0;41:value=0;
   42:value=8'h45;43:value=8'h54;44:value=8'h58;45:value=8'h31;
   46:value=seq_reg[31:24];47:value=seq_reg[23:16];48:value=seq_reg[15:8];49:value=seq_reg[7:0];
   50:value=count_latched[31:24];51:value=count_latched[23:16];52:value=count_latched[15:8];53:value=count_latched[7:0];
   54:value=seed_latched[31:24];55:value=seed_latched[23:16];56:value=seed_latched[15:8];57:value=seed_latched[7:0];
   166:value=final_crc[7:0];167:value=final_crc[15:8];168:value=final_crc[23:16];169:value=final_crc[31:24];
   default:if(index>=58&&index<166)begin
    if(PAYLOAD_WORD_INTERFACE==0)value=payload[(index-58)*8+:8];
    else case(index[1:0])
     2'd2:value=payload_current_word[7:0];
     2'd3:value=payload_current_word[15:8];
     2'd0:value=payload_current_word[23:16];
     2'd1:value=payload_current_word[31:24];
    endcase
   end
  endcase
 end
 assign m_axis_tdata=value;
 assign m_axis_tvalid=state==SEND;
 assign m_axis_tlast=(state==SEND)&&(index==169);
 always @(posedge clk)begin
  if(rst)begin state<=IDLE;index<=0;seq_reg<=0;seed_latched<=0;count_latched<=0;
   gap_latched<=0;gap_left<=0;crc<=32'hffffffff;busy<=0;done<=0;sent_count<=0;last_seq<=0;error<=0;end
  else begin
   done<=0;
   case(state)
    IDLE:if(start)begin
     if(frame_count==0||frame_count>256)error<=1;
     else begin state<=SEND;index<=0;seq_reg<=seq_base;seed_latched<=seed;
      count_latched<={16'b0,frame_count};gap_latched<=gap_cycles;busy<=1;error<=0;sent_count<=0;crc<=32'hffffffff;end
    end
    SEND:if(m_axis_tvalid&&m_axis_tready)begin
     if(index>=42&&index<=165)crc<=crc_byte(crc,value);
     if(index==169)begin
      sent_count<=sent_count+1;last_seq<=seq_reg;
      if(sent_count+1==count_latched)begin state<=IDLE;busy<=0;done<=1;end
      else begin seq_reg<=seq_reg+1;index<=0;crc<=32'hffffffff;
       if(gap_latched==0)state<=SEND;else begin state<=GAP;gap_left<=gap_latched-1;end
      end
     end else index<=index+1;
    end
    GAP:if(gap_left==0)state<=SEND;else gap_left<=gap_left-1;
    default:state<=IDLE;
   endcase
  end
 end
endmodule
