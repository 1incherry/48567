`timescale 1ns/1ps
// Standalone NFR pattern diagnostic. Qwen/legacy metadata image stays preserved.
module qwen_camera_endpoint #(parameter integer ENABLE_NTH4=0)(
 input wire sys_clk_50m,sys_rst_n,input wire refclk_200m,
 input wire runtime_io_resetn,runtime_source_resetn,runtime_ddr_idle,runtime_acquire_confirmed,
 input wire token_camera_request,output wire token_camera_done,token_camera_frame_completed,token_camera_fault,token_camera_owner_live,
 input wire runtime_ack_on_50,runtime_ack_off_50,runtime_owner_50,runtime_idle_50,runtime_fault_50,
 output wire runtime_descriptor_valid,runtime_enable,runtime_epoch_n,runtime_ddr_admit,runtime_lease_health,runtime_guard_fault,
 input wire eth_rxc,input wire[3:0]eth_rxd,input wire eth_rx_ctl,
 output wire eth_txc,output wire[3:0]eth_txd,output wire eth_tx_ctl,
 output wire eth_rst_n,inout wire eth_mdio,output wire eth_mdc,
 input wire[31:0]c_awaddr,c_wdata,c_araddr,input wire[3:0]c_wstrb,
 input wire c_awvalid,c_wvalid,c_bready,c_arvalid,c_rready,
 output wire c_awready,c_wready,c_bvalid,c_arready,c_rvalid,output wire[1:0]c_bresp,c_rresp,output wire[31:0]c_rdata,
 output wire bus_clk125,bus_resetn,output wire control_clk125,
 input wire[31:0]b_awaddr,b_wdata,b_araddr,input wire[3:0]b_wstrb,
 input wire b_awvalid,b_wvalid,b_bready,b_arvalid,b_rready,
 output wire b_awready,b_wready,b_bvalid,b_arready,b_rvalid,output wire[1:0]b_bresp,b_rresp,output wire[31:0]b_rdata,
 input wire sct_main_ready,sct_main_qualified,sct_main_good,sct_main_fault,sct_main_closed_ack,sct_main_active,
 output wire sct_main_start,sct_main_prepare,sct_main_response_consumed,
 input wire sct_qualify_ready,sct_qualify_done,sct_qualify_good,sct_qualify_fault,output wire sct_qualify_start,
 input wire sct_side_retire_req,output wire sct_side_retire_ack,sct_freeze_precommit,sct_freeze_disable,
 input wire sct_release_owned125,sct_trusted_stop100,sct_trusted_stop125,sct_drain_ack125,sct_drain_fault125,sct_release_permit125,
 input wire ui_clk,ui_rst_n,camera_clk,camera_rst_n,calibrated,
 input wire camera_bridge_quiescent_ui,shared_memory_quiescent_ui,
 input wire[7:0]camera_data,input wire camera_href,camera_vsync,
 input wire camera_configured,input wire[15:0]configured_width,configured_height,
 output wire[26:0]app_addr,output wire[2:0]app_cmd,output wire app_en,input wire app_rdy,
 output wire[127:0]app_wdf_data,output wire[15:0]app_wdf_mask,output wire app_wdf_end,app_wdf_wren,input wire app_wdf_rdy,
 input wire[127:0]app_rd_data,input wire app_rd_data_valid,app_rd_data_end,
 output wire[127:0]phy_debug_snapshot,output wire phy_debug_valid,
 output wire[15:0]debug_status
);
 wire fb0,fb,c0,c90,clk125,clk90,locked;
 MMCME2_BASE #(.CLKIN1_PERIOD(20.0),.DIVCLK_DIVIDE(1),.CLKFBOUT_MULT_F(15.0),.CLKOUT0_DIVIDE_F(6.0),.CLKOUT1_DIVIDE(6),.CLKOUT1_PHASE(90.0))u_mmcm(.CLKIN1(sys_clk_50m),.CLKFBIN(fb),.RST(!sys_rst_n),.PWRDWN(1'b0),.CLKFBOUT(fb0),.CLKOUT0(c0),.CLKOUT1(c90),.LOCKED(locked));
 BUFG u_fb(.I(fb0),.O(fb));BUFG u_clk(.I(c0),.O(clk125));BUFG u_clk90(.I(c90),.O(clk90));
 (* ASYNC_REG="TRUE" *)reg[3:0]reset_pipe=15;
 always @(posedge clk125 or negedge sys_rst_n)if(!sys_rst_n)reset_pipe<=15;else if(!locked)reset_pipe<=15;else reset_pipe<={reset_pipe[2:0],1'b0};
 wire rst=reset_pipe[3];reg[20:0]power_count=0;reg phy_power=0;
 always @(posedge clk125)if(rst)begin power_count<=0;phy_power<=0;end else if(!phy_power)begin if(power_count==1249999)phy_power<=1;else power_count<=power_count+1'b1;end
 assign eth_rst_n=phy_power&&!rst;
 wire mi,mo,mt,md_busy,md_done,md_ack;wire[15:0]md_rdata,md_wdata;wire[4:0]md_phy,md_reg;wire md_start,md_read,configured,phy_fault;
 nfr_phy_init init(.clk(clk125),.rst(rst),.phy_reset_done(phy_power),.md_busy(md_busy),.md_done(md_done),.md_ack(md_ack),.md_rdata(md_rdata),.md_start(md_start),.md_read(md_read),.md_phy(md_phy),.md_reg(md_reg),.md_wdata(md_wdata),.configured(configured),.fault(phy_fault),.debug_snapshot(phy_debug_snapshot),.debug_valid(phy_debug_valid));
 eth_mdio_master mdio(.clk(clk125),.rst(rst),.start(md_start),.read_cmd(md_read),.phy_addr(md_phy),.reg_addr(md_reg),.write_data(md_wdata),.mdio_i(mi),.mdio_o(mo),.mdio_t(mt),.mdc(eth_mdc),.busy(md_busy),.done(md_done),.ack_error(md_ack),.read_data(md_rdata));
 IOBUF mdio_pin(.I(mo),.T(mt),.O(mi),.IO(eth_mdio));
 // Delay data rather than weakening the external RGMII setup/hold budget.
 // A shared 200MHz reference calibrates five fixed IDELAYE2 inputs.
 wire[4:0]rx_delayed;wire[4:0]rx_input={eth_rx_ctl,eth_rxd};wire delay_ready;
 (* ASYNC_REG="TRUE" *)reg[6:0]delay_reset_pipe=127;
 always @(posedge clk125)if(rst)delay_reset_pipe<=127;else delay_reset_pipe<={delay_reset_pipe[5:0],1'b0};
 (* IODELAY_GROUP="nfr100t_rx" *)IDELAYCTRL rx_delay_control(.REFCLK(refclk_200m),.RST(delay_reset_pipe[6]),.RDY(delay_ready));
 genvar rxbit;
 generate for(rxbit=0;rxbit<5;rxbit=rxbit+1)begin:rx_input_delay
  (* IODELAY_GROUP="nfr100t_rx" *)IDELAYE2 #(.DELAY_SRC("IDATAIN"),.HIGH_PERFORMANCE_MODE("TRUE"),.IDELAY_TYPE("FIXED"),.IDELAY_VALUE(11),.REFCLK_FREQUENCY(200.0),.SIGNAL_PATTERN("DATA"))rxdelay(.DATAOUT(rx_delayed[rxbit]),.IDATAIN(rx_input[rxbit]),.DATAIN(1'b0),.C(1'b0),.CE(1'b0),.INC(1'b0),.LD(1'b0),.LDPIPEEN(1'b0),.REGRST(1'b0),.CINVCTRL(1'b0),.CNTVALUEIN(5'd0),.CNTVALUEOUT());
 end endgenerate
 wire token_mac_quiet;
 wire tx_clk,tx_rst,rx_clk,rx_rst;wire[7:0]td,rd;wire tv,tr,tl,rv,rl,ru,uf,bad,fcs;wire[1:0]speed;
 (* ASYNC_REG="TRUE" *)reg[1:0]rx_config_sync=0;
 always @(posedge rx_clk)if(rx_rst)rx_config_sync<=0;else rx_config_sync<={rx_config_sync[0],configured&&delay_ready};
 eth_mac_1g_rgmii #(.TARGET("XILINX"),.IODDR_STYLE("IODDR"),.CLOCK_INPUT_STYLE("BUFIO"),.USE_CLK90("TRUE"),.ENABLE_PADDING(1),.MIN_FRAME_LENGTH(64))u_mac(
 .gtx_clk(clk125),.gtx_clk90(clk90),.gtx_rst(rst),.rx_clk(rx_clk),.rx_rst(rx_rst),.tx_clk(tx_clk),.tx_rst(tx_rst),
 .tx_axis_tdata(td),.tx_axis_tvalid(tv),.tx_axis_tready(tr),.tx_axis_tlast(tl),.tx_axis_tuser(1'b0),
 .rx_axis_tdata(rd),.rx_axis_tvalid(rv),.rx_axis_tlast(rl),.rx_axis_tuser(ru),
 .rgmii_rx_clk(eth_rxc),.rgmii_rxd(rx_delayed[3:0]),.rgmii_rx_ctl(rx_delayed[4]),.rgmii_tx_clk(eth_txc),.rgmii_txd(eth_txd),.rgmii_tx_ctl(eth_tx_ctl),
 .token_tx_quiescent(token_mac_quiet),.tx_error_underflow(uf),.rx_error_bad_frame(bad),.rx_error_bad_fcs(fcs),.speed(speed),.cfg_ifg(8'd12),.cfg_tx_enable(configured),.cfg_rx_enable(rx_config_sync[1]));
 assign bus_clk125=clk125;assign bus_resetn=!rst;assign control_clk125=tx_clk;
 wire[7:0]nfr_data,reply_data;wire nfr_valid,nfr_last,nfr_ready,reply_valid,reply_last,reply_ready;wire packet_quiet;
 wire reply_start,reply_busy,reply_error,reply_done;wire[863:0]reply_payload;wire[31:0]reply_sequence,reply_session;
 wire reply_word_read,reply_word_valid,reply_memory_live;wire[4:0]reply_word_address;wire[31:0]reply_word_data;
 frame_axis_arbiter2 packet_arbiter(.clk(tx_clk),.rst_n(!tx_rst),.s_data({reply_data,nfr_data}),.s_valid({reply_valid,nfr_valid}),.s_last({reply_last,nfr_last}),.s_ready({reply_ready,nfr_ready}),.m_data(td),.m_valid(tv),.m_last(tl),.m_ready(tr),.quiescent(packet_quiet));
 eth_udp_tx_gen #(.SOURCE_MAC(48'h025052583100),.DEST_MAC(48'h025052587035),.SOURCE_IP(32'hc0a8010c),.DEST_IP(32'hc0a8010b),.PAYLOAD_WORD_INTERFACE(ENABLE_NTH4)) reply_tx(
 .payload_word_read(reply_word_read),.payload_word_address(reply_word_address),.payload_word_data(reply_word_data),.payload_word_valid(reply_word_valid),.payload_memory_live(reply_memory_live),.payload(reply_payload),.clk(tx_clk),.rst(tx_rst),.start(reply_start),.frame_count(16'd1),.seq_base(reply_sequence),.seed(reply_session),.gap_cycles(32'd0),.m_axis_tdata(reply_data),.m_axis_tvalid(reply_valid),.m_axis_tready(reply_ready),.m_axis_tlast(reply_last),.busy(reply_busy),.done(reply_done),.sent_count(),.last_seq(),.error(reply_error));
 wire context_common_reset=!sys_rst_n||tx_rst||rx_rst;
 (* ASYNC_REG="TRUE" *)reg[2:0]context_rx_release=0;
 always @(posedge rx_clk or posedge context_common_reset)if(context_common_reset)context_rx_release<=0;else context_rx_release<={context_rx_release[1:0],1'b1};
 wire[2:0]report_kind;wire context_nth_valid,context_nth_ready,context_word_is_nth;wire report_is_history;wire report_valid,report_ready,context_valid,context_ready,context_release,context_fault,context_quiet;wire[2047:0]report_body;wire[31:0]context_word_data;wire context_word_read,context_word_valid;wire[5:0]context_word_address;
 ntr2_nar2_packet_rx #(.ENABLE_HISTORY(1),.ENABLE_HNA(1),.ENABLE_NTH4(ENABLE_NTH4),.ENABLE_NAR3(1)) report_rx(.rx_clk(rx_clk),.rx_reset_n(context_rx_release[2]),.rx_data(rd),.rx_valid(rv),.rx_last(rl),.rx_bad(ru),.report_valid(report_valid),.report_ready(report_ready),.report_body(report_body),.accepted(),.rejected(),.busy_drops(),.report_is_history(report_is_history),.report_kind(report_kind));
  generate if(ENABLE_NTH4==0)begin:context_legacy
trusted_record_cdc context_cdc(.source_clk(rx_clk),.source_reset_n(context_rx_release[2]),.source_valid(report_valid),.source_ready(report_ready),.source_quiescent(context_quiet),.source_fault(context_fault),.source_data(report_body),.destination_clk(tx_clk),.destination_reset_n(!tx_rst),.destination_reset_released(context_release),.destination_ready(context_ready),.destination_valid(context_valid),.destination_word_data(context_word_data),.destination_word_read(context_word_read),.destination_word_address(context_word_address),.destination_word_valid(context_word_valid));
 assign context_nth_valid=1'b0;
 end else begin:context_nth4
 trusted_record_slots_cdc context_cdc(
 .board_reset_n(runtime_source_resetn),.source_clk(rx_clk),.source_reset_n(context_rx_release[2]),.source_valid(report_valid),.source_kind(report_kind),.source_data(report_body),.source_ready(report_ready),.source_quiescent(context_quiet),.source_fault(context_fault),
 .destination_clk(tx_clk),.destination_reset_n(!tx_rst),.destination_reset_released(context_release),.destination_valid(context_valid),.destination_ready(context_ready),.destination_nth_valid(context_nth_valid),.destination_nth_ready(context_nth_ready),.destination_word_read(context_word_read),.destination_word_is_nth(context_word_is_nth),.destination_word_address(context_word_address),.destination_word_data(context_word_data),.destination_word_valid(context_word_valid),.destination_quiescent());
 end endgenerate
 (* ASYNC_REG="TRUE" *)reg[1:0]context_fault_sync=0;
 always @(posedge tx_clk or negedge context_release)if(!context_release)context_fault_sync<=0;else context_fault_sync<={context_fault_sync[0],context_fault};
// Startup is not a transport-loss event. After first live, any loss remains fatal.
 reg context_ever_live;
 always @(posedge tx_clk or negedge runtime_source_resetn)
  if(!runtime_source_resetn)context_ever_live<=1'b0;
  else if(context_release)context_ever_live<=1'b1;
 wire context_transport_fault=context_fault_sync[1]||(context_ever_live&&!context_release);
 wire replay_armed,replay_consumed;wire[31:0]replay_expected_crc,replay_session,replay_frame;
 wire token_serial_owner_live,token_sublease_active,token_new_request_permit,token_request_accepted;
 (* ASYNC_REG="TRUE" *)reg[2:0]token_request_sync,token_bridge_sync,token_shared_sync;
 always @(posedge tx_clk or negedge runtime_source_resetn)if(!runtime_source_resetn)begin token_request_sync<=0;token_bridge_sync<=0;token_shared_sync<=0;end
 else begin token_request_sync<={token_request_sync[1:0],token_camera_request};token_bridge_sync<={token_bridge_sync[1:0],camera_bridge_quiescent_ui};token_shared_sync<={token_shared_sync[1:0],shared_memory_quiescent_ui};end
 wire[31:0]reservation_status;wire reservation_acquire,reservation_release,reservation_acquire_ready,reservation_release_ready,capture_inhibit,reservation_fault;
 wire serial_release,serial_held,serial_granted,release_cmd_ready,release_done,source_guard_fault,csr_quiet;
 wire boot_done,boot_error,boot_pending,boot_epoch_ok,boot_descriptor,boot_enable,boot_runtime_enable_alias,boot_command,release_admit,release_candidate,release_inflight;
 wire[31:0]boot_descriptor_read,boot_status,boot_data;wire[11:0]boot_address;
 assign runtime_enable=boot_runtime_enable_alias&&!sct_trusted_stop100&&sct_release_permit125&&!sct_main_fault;

 reg[1:0]csr_quiet_history;
 always@(posedge tx_clk or negedge runtime_source_resetn)if(!runtime_source_resetn)csr_quiet_history<=0;else csr_quiet_history<={csr_quiet_history[0],csr_quiet};
 wire effective_release_ready=reservation_release_ready&&csr_quiet&&(&csr_quiet_history)&&sct_drain_ack125&&!sct_drain_fault125&&sct_release_permit125&&!sct_main_fault;
 assign runtime_epoch_n=context_release&&ui_rst_n&&calibrated&&locked;
 wire serial_live=token_serial_owner_live&&!reservation_fault;
 assign token_camera_owner_live=runtime_epoch_n&&token_serial_owner_live&&!source_guard_fault&&sct_release_permit125&&!sct_main_fault;
 mcs_async_health runtime_health_sync(.io_clk(sys_clk_50m),.board_reset_n(runtime_io_resetn),
 .source_healthy(runtime_epoch_n&&serial_live&&!source_guard_fault&&sct_release_permit125&&!sct_main_fault),.io_healthy(runtime_lease_health));
 mcs_lease_quiesce_r2 runtime_guard(.source_clk(tx_clk),.source_rst_n(runtime_source_resetn),.source_epoch_n(runtime_epoch_n),
 .serial_held(serial_held),.serial_granted(serial_granted),.serial_live(serial_live),.serial_release_ready(effective_release_ready),
 .release_request(reservation_release),.release_request_ready(release_cmd_ready),.serial_release_valid(serial_release),.release_done(release_done),
 .source_fault(source_guard_fault),.freeze_to_io(),.io_clk(sys_clk_50m),.io_rst_n(runtime_io_resetn),
 .io_acquire_confirmed(runtime_acquire_confirmed),.io_ddr_idle(runtime_ddr_idle),.io_ddr_admit(runtime_ddr_admit),.io_quiesce_ack(),.io_fault(runtime_guard_fault),.source_state(),.io_state());
 ntr2_context_axil_shared_runtime_nth4 #(.ENABLE_HISTORY(1),.ENABLE_HNA(1),.ENABLE_NTH4(ENABLE_NTH4)) context_regs(.tx_payload_word_read(reply_word_read),.tx_payload_word_address(reply_word_address),.tx_payload_word_data(reply_word_data),.tx_payload_word_valid(reply_word_valid),.tx_payload_memory_live(reply_memory_live),.clk(tx_clk),.rst_n(runtime_source_resetn),.reservation_status(reservation_status),.reservation_acquire_ready(reservation_acquire_ready),.reservation_release_ready(release_cmd_ready),.reservation_acquire(reservation_acquire),.reservation_release(reservation_release),
 .reservation_release_done(release_done),.reservation_release_fault(source_guard_fault||reservation_fault),
 .runtime_memory_epoch_n(runtime_epoch_n),.runtime_ack_on_50(runtime_ack_on_50),.runtime_ack_off_50(runtime_ack_off_50),
 .runtime_owner_50(runtime_owner_50),.runtime_idle_50(runtime_idle_50),.runtime_fault_50(runtime_fault_50),
 .runtime_descriptor_valid(runtime_descriptor_valid),.runtime_enable(boot_runtime_enable_alias),.replay_consumed(replay_consumed),.replay_armed(replay_armed),.replay_expected_crc(replay_expected_crc),.replay_session(replay_session),.replay_frame(replay_frame),.report_valid(context_valid),.report_ready(context_ready),.report_read_data(context_word_data),.report_read_enable(context_word_read),.report_read_address(context_word_address),.report_read_valid(context_word_valid),.transport_fault(context_transport_fault),
 .shared_boot_done(boot_done),.shared_boot_error(boot_error),.shared_boot_pending(boot_pending),.shared_boot_epoch_ok(boot_epoch_ok),
 .shared_descriptor_valid(boot_descriptor),.shared_runtime_enable(boot_enable),.shared_boot_descriptor(boot_descriptor_read),.shared_boot_status(boot_status),
 .shared_boot_command(boot_command),.shared_boot_address(boot_address),.shared_boot_data(boot_data),.shared_release_admit(release_admit),.shared_release_candidate(release_candidate),.shared_release_inflight(release_inflight),
 .release_qualify_ready(sct_qualify_ready),.release_qualify_done(sct_qualify_done),.release_qualify_good(sct_qualify_good),.release_qualify_fault(sct_qualify_fault),.release_qualify_start(sct_qualify_start),
 .main_runtime_fault(!sct_release_permit125||sct_main_fault||sct_drain_fault125||source_guard_fault||reservation_fault),.main_fence_ready(sct_main_ready),.main_fence_qualified(sct_main_qualified),.main_fence_good(sct_main_good),.main_fence_fault(sct_main_fault||sct_drain_fault125),.main_fence_start(sct_main_start),
 .main_response_consumed(sct_main_response_consumed),.main_response_prepare(sct_main_prepare),.main_response_closed_ack(sct_main_closed_ack),
 .s_awaddr(c_awaddr[11:0]),.s_awvalid(c_awvalid),.s_awready(c_awready),.s_wdata(c_wdata),.s_wstrb(c_wstrb),.s_wvalid(c_wvalid),.s_wready(c_wready),.s_bresp(c_bresp),.s_bvalid(c_bvalid),.s_bready(c_bready),.s_araddr(c_araddr[11:0]),.s_arvalid(c_arvalid),.s_arready(c_arready),.s_rdata(c_rdata),.s_rresp(c_rresp),.s_rvalid(c_rvalid),.s_rready(c_rready),.tx_start(reply_start),.tx_payload(reply_payload),.tx_sequence(reply_sequence),.tx_session(reply_session),.tx_busy(reply_busy),.tx_error(reply_error),.tx_done(reply_done),.quiescent(csr_quiet),.reports_received(),.report_nth_valid(context_nth_valid),.report_nth_ready(context_nth_ready),.report_read_is_nth(context_word_is_nth));

 // Host-only exact boot side bypass. Accepted owners are board-reset persistent.
 mcs_runtime_boot_side_adapter runtime_boot_side(.clk(tx_clk),.board_reset_n(runtime_source_resetn),.memory_epoch_n(runtime_epoch_n),.reservation_status(reservation_status),.transport_fault(sct_trusted_stop125||sct_main_fault||sct_drain_fault125),
 .ack_on_50(runtime_ack_on_50),.ack_off_50(runtime_ack_off_50),.owner_50(runtime_owner_50),.idle_50(runtime_idle_50),.fault_50(runtime_fault_50),
 .normal_command(boot_command),.normal_address(boot_address),.normal_data(boot_data),.normal_done(boot_done),.normal_error(boot_error),
 .release_candidate(release_candidate),.release_inflight(release_inflight||sct_release_owned125||sct_main_active),.release_admit(release_admit),.release_reject(),
 .s_awaddr(b_awaddr[11:0]),.s_awvalid(b_awvalid),.s_awready(b_awready),.s_wdata(b_wdata),.s_wstrb(b_wstrb),.s_wvalid(b_wvalid),.s_wready(b_wready),.s_bresp(b_bresp),.s_bvalid(b_bvalid),.s_bready(b_bready),
 .s_araddr(b_araddr[11:0]),.s_arvalid(b_arvalid),.s_arready(b_arready),.s_rdata(b_rdata),.s_rresp(b_rresp),.s_rvalid(b_rvalid),.s_rready(b_rready),
 .side_retire_req(sct_side_retire_req),.side_retire_ack(sct_side_retire_ack),.drain_ack(sct_drain_ack125),.drain_fault(sct_drain_fault125),.freeze_precommit(sct_freeze_precommit),.freeze_disable(sct_freeze_disable),
 .descriptor_valid(boot_descriptor),.runtime_enable(boot_enable),.descriptor_read(boot_descriptor_read),.status_read(boot_status),.emergency_off(),.barrier_fault(),.side_job_active(),.side_disable_committed(),.quiescent(),.helper_pending(boot_pending),.helper_epoch_ok(boot_epoch_ok));
 wire pv,pr,local_valid,local_release;wire[383:0]ph,local_header;wire[31:0]rx_good,rx_bad,rx_drop;
 nfr_packet_rx #(.LOCAL_MAC(48'h025052583100),.REMOTE_MAC(48'h025052587035))control_rx(.rx_clk(rx_clk),.rx_reset(rx_rst),.rx_data(rd),.rx_valid(rv),.rx_last(rl),.rx_bad(ru),.clk(tx_clk),.rst_n(!tx_rst),.packet_valid(pv),.packet_header(ph),.packet_release(pr),.payload_read(1'b0),.payload_address(10'd0),.payload_data(),.payload_read_valid(),.received_packets(rx_good),.bad_packets(rx_bad),.busy_drops(rx_drop));
 nfr_header_stage header_stage(.clk(tx_clk),.rst_n(!tx_rst),.source_valid(pv),.source_header(ph),.source_release(pr),.header_valid(local_valid),.header(local_header),.header_release(local_release));
 wire creq,cready,cdone,cerror,release_frame,breq,baccept,bvalid,blast,berror,bready,busy,done,fault;wire[31:0]session,frame,total,framecrc,offset,retries,sent,completed;wire[15:0]width,height;wire[7:0]flags,bd;
 nfr_frame_tx sender(.clk(tx_clk),.rst_n(!tx_rst),.new_request_permit(!serial_held||token_new_request_permit),.request_accepted(token_request_accepted),.control_valid(local_valid),.control_header(local_header),.control_release(local_release),.capture_request(creq),.capture_ready(cready&&!capture_inhibit),.capture_complete(cdone),.capture_error(cerror),.session_id(session),.frame_id(frame),.total_bytes(total),.width(width),.height(height),.flags(flags),.capture_crc(framecrc),.release_frame(release_frame),.block_request(breq),.block_accept(baccept),.block_offset(offset),.block_data(bd),.block_valid(bvalid),.block_last(blast),.block_error(berror),.block_ready(bready),.m_axis_tdata(nfr_data),.m_axis_tvalid(nfr_valid),.m_axis_tlast(nfr_last),.m_axis_tready(nfr_ready),.mac_underflow(uf),.busy(busy),.done(done),.fault(fault),.retry_count(retries),.packets_sent(sent),.completed_frames(completed));
 reg replay_selected=0;
 wire use_pattern=flags[0]&&!replay_armed&&!replay_selected;
 assign replay_consumed=creq&&cready&&!capture_inhibit&&replay_armed;
 always @(posedge tx_clk)if(tx_rst)replay_selected<=0;
 else if(release_frame)replay_selected<=0;
 else if(creq&&cready&&!capture_inhibit)replay_selected<=replay_armed;
 wire replay_tuple_valid=!flags[0]&&session==replay_session&&frame==replay_frame&&width==640&&height==480;
 wire p_ready,p_done,p_error,p_accept,p_valid,p_last,p_berr;
 wire c_ready,c_done,c_error,c_accept,c_valid,c_last,c_berr;
 wire[7:0]p_data,c_data;wire[31:0]p_crc,c_crc;wire[15:0]camera_debug;
 assign cready=use_pattern?p_ready:c_ready;assign cdone=use_pattern?p_done:c_done;
 assign cerror=use_pattern?p_error:c_error;assign framecrc=use_pattern?p_crc:c_crc;
 assign baccept=use_pattern?p_accept:c_accept;assign bd=use_pattern?p_data:c_data;
 assign bvalid=use_pattern?p_valid:c_valid;assign blast=use_pattern?p_last:c_last;assign berror=use_pattern?p_berr:c_berr;
 nfr_pattern_source pattern_source(.clk(tx_clk),.rst_n(!tx_rst),.capture_request(creq&&use_pattern&&!capture_inhibit),.capture_ready(p_ready),.capture_complete(p_done),.capture_error(p_error),.width(width),.height(height),.flags(flags),.capture_crc(p_crc),.release_frame(release_frame),.block_request(breq&&use_pattern),.block_offset(offset),.block_accept(p_accept),.block_data(p_data),.block_valid(p_valid),.block_last(p_last),.block_error(p_berr),.block_ready(bready&&use_pattern));
 (* ASYNC_REG="TRUE" *)reg[1:0]configured_sync=0,profile_sync=0;
 always @(posedge tx_clk)begin configured_sync<={configured_sync[0],camera_configured};profile_sync<={profile_sync[0],configured_width==1920};end
 nfr_camera_source_replay camera_source(.clk(tx_clk),.ui_clk(ui_clk),.camera_clk(camera_clk),.rst_n(!tx_rst),.ui_rst_n(ui_rst_n),.camera_rst_n(camera_rst_n),.calibrated(calibrated),.camera_data(camera_data),.camera_href(camera_href),.camera_vsync(camera_vsync),.camera_configured(configured_sync[1]),.configured_width(profile_sync[1]?16'd1920:16'd640),.configured_height(profile_sync[1]?16'd1080:16'd480),.capture_request(creq&&!use_pattern&&!capture_inhibit),.capture_replay(replay_armed),.capture_replay_valid(replay_tuple_valid),.replay_expected_crc(replay_expected_crc),.capture_ready(c_ready),.capture_complete(c_done),.capture_error(c_error),.width(width),.height(height),.flags(flags),.capture_crc(c_crc),.release_frame(release_frame),.block_request(breq&&!use_pattern),.block_offset(offset),.block_accept(c_accept),.block_data(c_data),.block_valid(c_valid),.block_last(c_last),.block_error(c_berr),.block_ready(bready&&!use_pattern),.app_addr(app_addr),.app_cmd(app_cmd),.app_en(app_en),.app_rdy(app_rdy),.app_wdf_data(app_wdf_data),.app_wdf_mask(app_wdf_mask),.app_wdf_end(app_wdf_end),.app_wdf_wren(app_wdf_wren),.app_wdf_rdy(app_wdf_rdy),.app_rd_data(app_rd_data),.app_rd_data_valid(app_rd_data_valid),.app_rd_data_end(app_rd_data_end),.write_beats(),.read_beats(),.maximum_write_stall(),.maximum_read_stall(),.debug_status(camera_debug));
 wire token_window_draining;
 qwen_camera_window_gate_r1 token_window(.clk(tx_clk),.board_reset_n(runtime_source_resetn),.epoch_live(runtime_epoch_n),.window_request(token_request_sync[2]),.owner_live(token_camera_owner_live),
 .request_accepted(token_request_accepted),.sender_busy(busy),.sender_done(done),.sender_fault(fault),.source_ready(c_ready),.source_error(c_error),.capture_request(creq),.block_request(breq),
 .packet_quiet(packet_quiet),.mac_quiet(token_mac_quiet),.reply_busy(reply_busy),.control_quiet(!pv&&!local_valid),.bridge_quiet(token_bridge_sync[2]),.shared_quiet(token_shared_sync[2]),
 .new_request_permit(token_new_request_permit),.camera_sublease_active(token_sublease_active),.done(token_camera_done),.frame_completed(token_camera_frame_completed),.fault(token_camera_fault),.draining(token_window_draining));
 camera_qwen_reservation serial_lock(.camera_sublease_active(token_sublease_active),.reservation_owner_live(token_serial_owner_live),.clk(tx_clk),.rst_n(runtime_source_resetn),.memory_reset_n(ui_rst_n),.memory_calibrated(calibrated),.request_reservation(reservation_acquire),.release_reservation(serial_release),.acquire_ready(reservation_acquire_ready),.release_ready(reservation_release_ready),.camera_ready(c_ready),.sender_busy(busy),.packet_quiescent(packet_quiet),.control_quiescent(!pv&&!local_valid),.camera_bridge_quiescent_ui(camera_bridge_quiescent_ui),.shared_memory_quiescent_ui(shared_memory_quiescent_ui),.capture_inhibit(capture_inhibit),.reservation_held(serial_held),.reservation_granted(serial_granted),.status(reservation_status),.fault(reservation_fault));
 // Stable/individual status bits only. Numeric counters remain in their native domain.
 wire[15:0]status125={6'd0,completed!=0,retries!=0,rx_good!=0,rx_bad!=0,rx_drop!=0,cerror,fault,busy,phy_fault,configured};
 (* ASYNC_REG="TRUE" *)reg[15:0]ds1=0,ds2=0;
 always @(posedge sys_clk_50m)begin ds1<=status125;ds2<=ds1;end
 assign debug_status=ds2;
endmodule
