`timescale 1ns/1ps
// Strict observation decoder. EtherType/origin/FCS checks are NOT network crypto.
// Complete packet only, without preamble/FCS; MAC rx_bad must be preserved.
module ntr2_nar2_packet_rx #(parameter integer ENABLE_HISTORY=0,parameter integer ENABLE_HNA=0,parameter integer ENABLE_NTH4=0,parameter integer ENABLE_NAR3=0)(
 input wire rx_clk,rx_reset_n,input wire[7:0]rx_data,input wire rx_valid,rx_last,rx_bad,
 output wire report_valid,input wire report_ready,output wire[2047:0]report_body,
 output reg[31:0]accepted,rejected,busy_drops,output wire report_is_history,output wire report_is_negative,output wire[2:0]report_kind
);
 reg[9:0]position;reg failed,is_audio,is_history,is_hna,is_nth4,is_audio105;reg[1:0]hna_op;reg[31:0]nar_word;reg nar_key_nonzero,fp_hi7_all;reg[2047:0]body;
 reg[31:0]sequence_word,count_word;reg[15:0]candidate_word;reg generation_nonzero;
 wire[9:0]offset=position-14;
 wire[2047:0]next_body={body[2039:0],rx_data};
 function automatic[7:0]fixed_byte(input[5:0]p);
 begin case(p)
 0:fixed_byte=8'h02;1:fixed_byte=8'h50;2:fixed_byte=8'h52;3:fixed_byte=8'h58;4:fixed_byte=8'h31;5:fixed_byte=0;
 6:fixed_byte=8'h02;7:fixed_byte=8'h50;8:fixed_byte=8'h52;9:fixed_byte=8'h58;10:fixed_byte=8'h70;11:fixed_byte=8'h35;
 12:fixed_byte=8'h88;13:fixed_byte=8'hb6;14:fixed_byte=8'h4e;15:fixed_byte=8'h54;16:fixed_byte=8'h52;17:fixed_byte=8'h32;
 18:fixed_byte=0;19:fixed_byte=2;20:fixed_byte=0;21:fixed_byte=1;default:fixed_byte=0;endcase end endfunction
 reg byte_invalid;integer slot,subbyte;
 // HIS1 is a complete UNTRUSTED history network envelope only. Checked MCS
 // must validate body and outstanding tuple before private context and HSC1.
 // No NTR2/NAR2 authenticated/model/action verdict is fabricated here.
 wire history_now=(ENABLE_HISTORY!=0)&&(is_history||(position==14&&rx_data==8'h48));
 wire hna_now=(ENABLE_HISTORY!=0)&&(ENABLE_HNA!=0)&&(is_hna||(is_history&&position==15&&rx_data==8'h4e));

 // NTH4 is a distinct hardware family. These are syntax/FCS/origin checks;
 // live query/session/slot-generation authorization remains the checked CPU
 // decoder's job. Ethernet CRC does not establish cryptographic authenticity.
 function automatic[31:0] nthword(input[2047:0]v,input integer byte_offset);
  nthword=v[2047-byte_offset*8-:32];
 endfunction
 function automatic nthsyntax(input[2047:0]v);
  reg[31:0] flags,rc,ri;reg[15:0]x0,x1,y0,y1;
  begin
   flags=nthword(v,12);ri=nthword(v,44);rc=nthword(v,48);
   x0=v[2047-138*8-:16];x1=v[2047-136*8-:16];y0=v[2047-134*8-:16];y1=v[2047-132*8-:16];
   nthsyntax=nthword(v,0)==32'h4e544834&&nthword(v,4)==32'h00010002&&nthword(v,8)==256&&
    (flags==11||flags==15)&&v[2047-16*8-:64]!=0&&v[2047-24*8-:64]!=0&&v[2047-32*8-:64]!=0&&
    nthword(v,40)>=1&&nthword(v,40)<=100&&rc<=4&&nthword(v,52)!=0&&
    nthword(v,60)!=0&&nthword(v,64)!=0&&nthword(v,68)!=0&&nthword(v,72)!=0&&nthword(v,76)!=0&&
    v[2047-80*8-:128]!=0&&nthword(v,96)==nthword(v,56)&&nthword(v,100)!=0&&nthword(v,104)!=0&&nthword(v,108)!=0&&
    v[2047-116*8-:128]!=0&&v[2047-176*8-:256]!=0&&v[2047-208*8-:256]!=0&&nthword(v,240)!=0&&nthword(v,244)!=0&&v[63:0]==0;
   if(rc==0)nthsyntax=nthsyntax&&flags==15&&ri==0&&nthword(v,112)==0&&v[2047-132*8-:352]==0;
   else nthsyntax=nthsyntax&&flags==11&&ri<rc&&nthword(v,112)!=0&&nthword(v,160)<6300&&nthword(v,164)<105&&x0<x1&&x1<=1920&&y0<y1&&y1<=1080;
  end
 endfunction
 wire nar3_now=(ENABLE_NAR3!=0)&&is_audio&&(is_audio105||(position==17&&rx_data==8'h33));
 wire nth_now=ENABLE_NTH4!=0&&(is_nth4||(position==16&&rx_data==8'h48&&!is_audio&&!is_history));
 always @*begin
  byte_invalid=rx_bad;slot=0;subbyte=0;
  if(nth_now)begin
   case(position)
    16:if(rx_data!=8'h48)byte_invalid=1;
    17:if(rx_data!=8'h34)byte_invalid=1;
    18:if(rx_data!=0)byte_invalid=1;
    19:if(rx_data!=1)byte_invalid=1;
    20:if(rx_data!=0)byte_invalid=1;
    21:if(rx_data!=2)byte_invalid=1;
    default:begin end
   endcase
  end else if(hna_now)begin
   // HNA1 is an independent UNTRUSTED negative envelope, never a HIS1 record.
   // Checked MCS verifies application CRC32 and the complete outstanding tuple
   // before publishing NOT_STORED; envelope acceptance alone grants nothing.
   case(position)
    15:if(rx_data!=8'h4e)byte_invalid=1;
    16:if(rx_data!=8'h41)byte_invalid=1;
    17:if(rx_data!=8'h31)byte_invalid=1;
    18:if(rx_data!=0)byte_invalid=1;
    19:if(rx_data!=1)byte_invalid=1;
    20:if(rx_data!=1)byte_invalid=1;
    21:if(rx_data!=1)byte_invalid=1;
    default:begin end
   endcase
   if(offset==8&&rx_data!=1&&rx_data!=2)byte_invalid=1;
   if(offset==9)begin
    if(hna_op==1&&rx_data!=0)byte_invalid=1;
    if(hna_op==2&&rx_data!=1&&rx_data!=3&&rx_data!=4)byte_invalid=1;
    if(hna_op!=1&&hna_op!=2)byte_invalid=1;
   end
   if(offset==10&&rx_data!=1)byte_invalid=1;
   if(offset==11&&rx_data!=1)byte_invalid=1;
   if(offset>=12&&offset<=15&&rx_data!=(offset==14?8'd1:8'd0))byte_invalid=1;
   if(offset>=44&&offset<=251&&rx_data!=0)byte_invalid=1;
  end else if(history_now)begin
   case(position)
    14:if(rx_data!=8'h48)byte_invalid=1;
    15:if(rx_data!=8'h49)byte_invalid=1;
    16:if(rx_data!=8'h53)byte_invalid=1;
    17:if(rx_data!=8'h31)byte_invalid=1;
    18:if(rx_data!=0)byte_invalid=1;
    19:if(rx_data!=1)byte_invalid=1;
    20:if(rx_data!=1)byte_invalid=1;
    21:if(rx_data!=0)byte_invalid=1;
    default:begin end
   endcase
   if(offset==39&&(!rx_data[0]||rx_data[7:3]!=0))byte_invalid=1;
   if(offset==92||offset==93||offset==95)if(rx_data!=0)byte_invalid=1;
   if(offset==94&&rx_data!=1)byte_invalid=1;
  end else if(nar3_now)begin
   case(position)
    17:if(rx_data!=8'h33)byte_invalid=1;
    18:if(rx_data!=0)byte_invalid=1;
    19:if(rx_data!=3)byte_invalid=1;
    20:if(rx_data!=0)byte_invalid=1;
    21:if(rx_data!=2)byte_invalid=1;
    default:begin end
   endcase
   if(offset==11&&{sequence_word[23:0],rx_data}==0)byte_invalid=1;
   if(offset==15&&{nar_word[23:0],rx_data}!=2)byte_invalid=1;
   if((offset==19||offset==23||offset==27||offset==31)&&{nar_word[23:0],rx_data}==0)byte_invalid=1;
   if(offset==47&&!nar_key_nonzero&&rx_data==0)byte_invalid=1;
   if(offset==51&&{nar_word[23:0],rx_data}>104)byte_invalid=1;
   if(offset==55&&{nar_word[23:0],rx_data}!=105)byte_invalid=1;
   if(offset==59&&{nar_word[23:0],rx_data}!=32000)byte_invalid=1;
   if(offset==63&&{nar_word[23:0],rx_data}!=3960)byte_invalid=1;
   if(offset==65&&fp_hi7_all&&rx_data[7])byte_invalid=1;
   if(offset==71&&{nar_word[23:0],rx_data}!=32'h00020069)byte_invalid=1;
   if(offset>=72&&rx_data!=0)byte_invalid=1;
  end else begin
  if(position<22)begin
   if(position==15)begin if(rx_data!=8'h54&&rx_data!=8'h41)byte_invalid=1;end
   else if(position==21)begin if(rx_data!=(is_audio?8'd2:8'd1))byte_invalid=1;end
   else if(rx_data!=fixed_byte(position[5:0]))byte_invalid=1;
  end
  if(!is_audio&&offset==31&&{count_word[23:0],rx_data}>4)byte_invalid=1;
  if(offset==11&&{sequence_word[23:0],rx_data}==0)byte_invalid=1;
  if(position>=14&&is_audio)begin
   if((offset==19||offset==23||offset==27||offset==31)&&{nar_word[23:0],rx_data}==0)byte_invalid=1;
   if(offset==47&&!nar_key_nonzero&&rx_data==0)byte_invalid=1;
   if(offset==51&&{nar_word[23:0],rx_data}>=12)byte_invalid=1;
   if(offset==55&&{nar_word[23:0],rx_data}!=12)byte_invalid=1;
   if(offset==59&&{nar_word[23:0],rx_data}!=16000)byte_invalid=1;
   if(offset==63&&{nar_word[23:0],rx_data}!=3920)byte_invalid=1;
   if(offset>=64&&offset<112&&offset[1:0]==1&&fp_hi7_all&&rx_data[7])byte_invalid=1;
   if(offset>=112&&rx_data!=0)byte_invalid=1;
  end
  if(position>=14&&!is_audio)begin
   if(offset>=232&&rx_data!=0)byte_invalid=1;
   if(offset>=48&&offset<160)begin if(offset<76)slot=0;else if(offset<104)slot=1;else if(offset<132)slot=2;else slot=3;if(slot>=count_word&&rx_data!=0)byte_invalid=1;end
   if(offset>=160&&offset<168)begin
    slot=offset[2:1];
    if(slot>=count_word&&rx_data!=0)byte_invalid=1;
    if(offset[0]&&slot<count_word&&{candidate_word[7:0],rx_data}>=6300)byte_invalid=1;
   end
   if(offset>=168&&offset<232)begin
    if(offset<184)slot=0;else if(offset<200)slot=1;else if(offset<216)slot=2;else slot=3;subbyte={~offset[3],offset[2:0]};
    if(slot>=count_word&&rx_data!=0)byte_invalid=1;
    if(slot<count_word)begin
     if(subbyte==3&&!generation_nonzero&&rx_data==0)byte_invalid=1;
     if(subbyte==4&&rx_data>=105)byte_invalid=1;
     if(subbyte>=5&&subbyte<=7&&rx_data!=0)byte_invalid=1;
    end
   end
  end
  end
 end
 // Position269 is body offset255. For BOTH formats this byte is reserved
 // zero; every earlier rule has already accumulated into failed. Keeping the
 // generic validator unchanged preserves all nonterminal malformed-byte checks.
 // This exact terminal predicate avoids the unused offset/slot arithmetic on
 // the 2048-flop CDC enable path, with no new pipeline or ready timing.
 assign report_valid=rx_reset_n&&rx_valid&&rx_last&&position==269&&!failed&&!rx_bad&&
  ((ENABLE_NTH4!=0&&is_nth4)?nthsyntax(next_body):((ENABLE_HISTORY!=0&&is_history)||(rx_data==8'd0)));
 assign report_kind=report_valid?((ENABLE_NTH4!=0&&is_nth4)?3'd5:(is_history?3'd3:(is_audio105?3'd6:(is_audio?3'd2:3'd1)))):3'd0;
 assign report_is_history=(ENABLE_HISTORY!=0)&&is_history;
 assign report_is_negative=report_valid&&(ENABLE_HISTORY!=0)&&(ENABLE_HNA!=0)&&is_hna;
 assign report_body=next_body;
 always @(posedge rx_clk or negedge rx_reset_n)begin
  if(!rx_reset_n)begin position<=0;failed<=0;is_audio<=0;is_history<=0;is_hna<=0;is_nth4<=0;is_audio105<=0;hna_op<=0;nar_word<=0;nar_key_nonzero<=0;fp_hi7_all<=0;body<=0;sequence_word<=0;count_word<=0;candidate_word<=0;generation_nonzero<=0;accepted<=0;rejected<=0;busy_drops<=0;end
  else if(rx_valid)begin
   if(position==15)is_audio<=rx_data==8'h41;
   if(position==17)is_audio105<=ENABLE_NAR3!=0&&is_audio&&rx_data==8'h33;
   if(position==16)is_nth4<=ENABLE_NTH4!=0&&rx_data==8'h48&&!is_audio&&!is_history;
   if(position==14)is_history<=ENABLE_HISTORY!=0&&rx_data==8'h48;
   if(position==15)is_hna<=ENABLE_HISTORY!=0&&ENABLE_HNA!=0&&is_history&&rx_data==8'h4e;
   if(hna_now&&offset==8)hna_op<=rx_data[1:0];
   if(position>=14)nar_word<={nar_word[23:0],rx_data};
   if(offset>=32&&offset<=47)nar_key_nonzero<=nar_key_nonzero||rx_data!=0;
   if(offset>=64&&offset<112&&offset[1:0]==0)fp_hi7_all<=&rx_data[6:0];
   if(position>=14&&position<=269)body<=next_body;
   if(offset>=8&&offset<=11)sequence_word<={sequence_word[23:0],rx_data};
   if(offset>=28&&offset<=31)count_word<={count_word[23:0],rx_data};
   if(offset>=160&&offset<168)candidate_word<={candidate_word[7:0],rx_data};
   if(offset>=168&&offset<232)begin
    if(offset[3:0]==8)generation_nonzero<=rx_data!=0;
    else if(offset[3:0]>=9&&offset[3:0]<=10)generation_nonzero<=generation_nonzero||rx_data!=0;
   end
   if(rx_last)begin
    if(report_valid)begin if(report_ready)accepted<=accepted+1'b1;else busy_drops<=busy_drops+1'b1;end
    else rejected<=rejected+1'b1;
    position<=0;failed<=0;is_audio<=0;is_history<=0;is_hna<=0;is_nth4<=0;is_audio105<=0;hna_op<=0;nar_word<=0;nar_key_nonzero<=0;fp_hi7_all<=0;sequence_word<=0;count_word<=0;candidate_word<=0;generation_nonzero<=0;
   end else begin if(position!=1023)position<=position+1'b1;failed<=failed||byte_invalid||position>=269;end
  end
 end
endmodule
