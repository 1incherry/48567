`timescale 1ns/1ps
// Accessible only from trusted JTAG source: CPU bridge rejects080/084 writes;
// inference master has no ETH segment. Descriptor is layout, never model SHA.
module mcs_runtime_boot_control(input wire clk,rst_n,memory_epoch_n,
 input wire[31:0]reservation_status,input wire transport_fault,
 input wire command,input wire[11:0]address,input wire[31:0]data,
 input wire ack_on_50,ack_off_50,owner_50,idle_50,fault_50,
 output wire descriptor_valid,output reg runtime_enable,
 output wire[31:0]descriptor_read,status_read,
 output reg done,output reg error,output wire pending,epoch_ok);
 (* ASYNC_REG="TRUE" *)reg[2:0]epoch_sync;
 always@(posedge clk or negedge rst_n or negedge memory_epoch_n)
 if(!rst_n||!memory_epoch_n)epoch_sync<=0;else epoch_sync<={epoch_sync[1:0],1'b1};
 assign epoch_ok=epoch_sync[2];
 // Business state deasserts reset only from the final source-clock epoch
 // stage; raw memory recovery cannot release these registers between clocks.
 reg[31:0]descriptor;reg busy,desired;
 (* ASYNC_REG="TRUE" *)reg[2:0]on_sync,off_sync,owner_sync,idle_sync,fault_sync;
 wire health=epoch_ok&&reservation_status[9]&&!reservation_status[8]&&!transport_fault&&!fault_sync[2];
 wire free_owner=health&&!reservation_status[0]&&!reservation_status[1];
 wire descriptor_local=(descriptor==32'h51574d31)&&epoch_sync[2];
 // External raw output is an immediate revoke gate,never a business predicate.
 assign descriptor_valid=descriptor_local&&memory_epoch_n;
 assign descriptor_read=descriptor;
 assign status_read={23'd0,health,fault_sync[2],idle_sync[2],owner_sync[2],off_sync[2],on_sync[2],busy,runtime_enable,descriptor_local};
 assign pending=busy;
 always@(posedge clk or negedge rst_n or negedge epoch_sync[2])
 if(!rst_n||!epoch_sync[2])begin
  descriptor<=0;runtime_enable<=0;busy<=0;desired<=0;done<=0;error<=0;
  on_sync<=0;off_sync<=0;owner_sync<=0;idle_sync<=0;fault_sync<=0;
 end else begin
  on_sync<={on_sync[1:0],ack_on_50};off_sync<={off_sync[1:0],ack_off_50};
  owner_sync<={owner_sync[1:0],owner_50};idle_sync<={idle_sync[1:0],idle_50};fault_sync<={fault_sync[1:0],fault_50};
  done<=0;error<=0;
  if(busy)begin
   if(!health)begin runtime_enable<=0;busy<=0;done<=1;error<=1;end
   else if(desired&&on_sync[2]&&owner_sync[2])begin busy<=0;done<=1;end
   else if(!desired&&off_sync[2]&&!owner_sync[2]&&idle_sync[2])begin busy<=0;done<=1;end
  end else if(command)begin
   if(address==12'h080&&data==32'h51574d31&&!runtime_enable&&free_owner&&off_sync[2]&&!owner_sync[2])begin descriptor<=data;done<=1;end
   else if(address==12'h084&&data==1&&!runtime_enable&&descriptor_local&&free_owner&&off_sync[2]&&!owner_sync[2])begin
    runtime_enable<=1;desired<=1;busy<=1;
   end else if(address==12'h084&&data==0)begin
    // Debug disable revokes CPU asynchronously but never fabricates drain.
    runtime_enable<=0;desired<=0;busy<=1;
   end else begin done<=1;error<=1;end
  end
 end
endmodule
