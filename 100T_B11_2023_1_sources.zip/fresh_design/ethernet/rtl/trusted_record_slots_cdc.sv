`timescale 1ns/1ps
// Five immutable packet slots in one real dual-clock XPM block RAM.
// Four NTH4 slots have FIFO ownership; the legacy mailbox has an independent
// credit so a held HIS cannot head-of-line block the NTH4 stream.
// Only board reset erases accepted ownership. Channel reset after first-live
// revokes both admissions and latches fault; it cannot impersonate an ACK.
module trusted_record_slots_cdc(
 input wire board_reset_n,source_clk,source_reset_n,source_valid,
 input wire[2:0]source_kind,input wire[2047:0]source_data,
 output wire source_ready,source_quiescent,output reg source_fault,
 input wire destination_clk,destination_reset_n,
 output wire destination_reset_released,destination_valid,destination_nth_valid,
 input wire destination_ready,destination_nth_ready,
 input wire destination_word_read,destination_word_is_nth,input wire[5:0]destination_word_address,
 output wire[31:0]destination_word_data,output wire destination_word_valid,
 output wire destination_quiescent
);
 reg[4:0]request_toggle,ack_toggle;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]source_board_release,destination_board_release;
 wire source_board_reset_n=source_board_release[2],destination_board_reset_n=destination_board_release[2];
 always@(posedge source_clk or negedge board_reset_n)
  if(!board_reset_n)source_board_release<=0;else source_board_release<={source_board_release[1:0],1'b1};
 always@(posedge destination_clk or negedge board_reset_n)
  if(!board_reset_n)destination_board_release<=0;else destination_board_release<={destination_board_release[1:0],1'b1};
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[4:0]ack_sync1,ack_sync2,ack_sync3,req_sync1,req_sync2,req_sync3;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]source_release,destination_release,tx_alive_sync,rx_alive_sync;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]destination_fault_sync,source_fault_sync;
 reg source_armed,destination_armed,destination_fault;
 reg source_reset_pending=1'b1,destination_reset_pending=1'b1;
 reg copy_active;reg[1:0]source_tail,destination_head;reg[2:0]copy_slot;
 reg[5:0]copy_index;reg[2047:0]source_bundle;
 wire source_health=source_reset_n&&!source_reset_pending&&source_release[2]&&tx_alive_sync[2];
 wire destination_health=destination_reset_n&&!destination_reset_pending&&destination_release[2]&&rx_alive_sync[2];
 wire incoming_nth=source_kind===3'd5;
 wire[2:0]next_source_slot=incoming_nth?{1'b0,source_tail}:3'd4;
 wire slot_free=request_toggle[next_source_slot]===ack_sync3[next_source_slot];
 wire source_live=source_board_reset_n&&source_reset_n&&destination_reset_n&&source_health&&!source_fault&&!destination_fault_sync[2];
 wire destination_live=destination_board_reset_n&&source_reset_n&&destination_reset_n&&destination_health&&!destination_fault&&!source_fault_sync[2];
 assign source_ready=source_live&&!copy_active&&slot_free;
 assign source_quiescent=source_live&&!copy_active&&request_toggle==ack_sync3&&!source_valid;
 assign destination_reset_released=destination_live;
 assign destination_valid=destination_live&&(req_sync3[4]!=ack_toggle[4]);
 assign destination_nth_valid=destination_live&&(req_sync3[destination_head]!=ack_toggle[destination_head]);
 wire selected_valid=destination_word_is_nth?destination_nth_valid:destination_valid;
 wire read_fire=destination_word_read&&selected_valid;
 wire[2:0]read_slot=destination_word_is_nth?{1'b0,destination_head}:3'd4;
 wire[8:0]read_address={read_slot,destination_word_address};
 reg read_pending;reg read_nth;
 wire[31:0]ram_read_data;
 assign destination_word_valid=destination_live&&read_pending&&(read_nth?destination_nth_valid:destination_valid);
 assign destination_word_data=destination_word_valid?ram_read_data:32'd0;
 assign destination_quiescent=destination_live&&req_sync3==ack_toggle&&!read_pending;
 always@(posedge source_clk or negedge source_board_reset_n)begin
  if(!source_board_reset_n)begin source_release<=0;tx_alive_sync<=0;destination_fault_sync<=0;ack_sync1<=0;ack_sync2<=0;ack_sync3<=0;end
  else begin
   source_release<={source_release[1:0],source_reset_n};tx_alive_sync<={tx_alive_sync[1:0],destination_reset_n};
   destination_fault_sync<={destination_fault_sync[1:0],destination_fault};
   ack_sync1<=ack_toggle;ack_sync2<=ack_sync1;ack_sync3<=ack_sync2;
  end
 end
 always@(posedge destination_clk or negedge destination_board_reset_n)begin
  if(!destination_board_reset_n)begin destination_release<=0;rx_alive_sync<=0;source_fault_sync<=0;req_sync1<=0;req_sync2<=0;req_sync3<=0;end
  else begin
   destination_release<={destination_release[1:0],destination_reset_n};rx_alive_sync<={rx_alive_sync[1:0],source_reset_n};
   source_fault_sync<={source_fault_sync[1:0],source_fault};
   req_sync1<=request_toggle;req_sync2<=req_sync1;req_sync3<=req_sync2;
  end
 end
 // Async channel reset is an immediate revoke/fault after first readiness.
 // No RAM ownership or accepted-copy state is cleared by this assertion.
 always@(posedge source_clk or negedge source_reset_n)
  if(!source_reset_n)source_reset_pending<=1'b1;else source_reset_pending<=1'b0;
 always@(posedge destination_clk or negedge destination_reset_n)
  if(!destination_reset_n)destination_reset_pending<=1'b1;else destination_reset_pending<=1'b0;
 always@(posedge source_clk or negedge source_board_reset_n)begin
  if(!source_board_reset_n)begin source_fault<=0;source_armed<=0;end
  else begin if(source_health)source_armed<=1;if(source_armed&&(!source_health||destination_fault_sync[2]))source_fault<=1;end
 end
 always@(posedge destination_clk or negedge destination_board_reset_n)begin
  if(!destination_board_reset_n)begin destination_fault<=0;destination_armed<=0;end
  else begin if(destination_health)destination_armed<=1;if(destination_armed&&(!destination_health||source_fault_sync[2]))destination_fault<=1;end
 end
 always@(posedge source_clk or negedge source_board_reset_n)begin
  if(!source_board_reset_n)begin request_toggle<=0;copy_active<=0;source_tail<=0;copy_slot<=0;copy_index<=0;source_bundle<=0;end
  else if(source_live)begin
   if(source_valid&&source_ready)begin source_bundle<=source_data;copy_slot<=next_source_slot;copy_index<=0;copy_active<=1;end
   if(copy_active)begin
    if(copy_index==63)begin request_toggle[copy_slot]<=!request_toggle[copy_slot];copy_active<=0;copy_index<=0;if(copy_slot!=4)source_tail<=source_tail+1'b1;end
    else copy_index<=copy_index+1'b1;
   end
  end
 end
 always@(posedge destination_clk or negedge destination_board_reset_n)begin
  if(!destination_board_reset_n)begin ack_toggle<=0;destination_head<=0;read_pending<=0;read_nth<=0;end
  else begin
   read_pending<=read_fire;read_nth<=destination_word_is_nth;
   if(destination_live)begin
    if(destination_valid&&destination_ready)ack_toggle[4]<=req_sync3[4];
    if(destination_nth_valid&&destination_nth_ready)begin ack_toggle[destination_head]<=req_sync3[destination_head];destination_head<=destination_head+1'b1;end
   end
  end
 end
 wire write_fire=source_live&&copy_active;
 xpm_memory_tdpram #(
  .MEMORY_SIZE(16384),.MEMORY_PRIMITIVE("block"),.CLOCKING_MODE("independent_clock"),.ECC_MODE("no_ecc"),
  .MEMORY_INIT_FILE("none"),.USE_MEM_INIT(0),.SIM_ASSERT_CHK(1),.MEMORY_OPTIMIZATION("true"),
  .WRITE_DATA_WIDTH_A(32),.READ_DATA_WIDTH_A(32),.BYTE_WRITE_WIDTH_A(32),.ADDR_WIDTH_A(9),.READ_LATENCY_A(1),.WRITE_MODE_A("no_change"),.RST_MODE_A("SYNC"),
  .WRITE_DATA_WIDTH_B(32),.READ_DATA_WIDTH_B(32),.BYTE_WRITE_WIDTH_B(32),.ADDR_WIDTH_B(9),.READ_LATENCY_B(1),.WRITE_MODE_B("no_change"),.RST_MODE_B("SYNC")
 )packet_storage(
  .sleep(1'b0),.clka(source_clk),.rsta(1'b0),.ena(write_fire),.regcea(1'b1),.wea(write_fire),.addra({copy_slot,copy_index}),.dina(source_bundle[2047-copy_index*32-:32]),.injectsbiterra(1'b0),.injectdbiterra(1'b0),.douta(),.sbiterra(),.dbiterra(),
  .clkb(destination_clk),.rstb(1'b0),.enb(read_fire),.regceb(1'b1),.web(1'b0),.addrb(read_address),.dinb(32'd0),.injectsbiterrb(1'b0),.injectdbiterrb(1'b0),.doutb(ram_read_data),.sbiterrb(),.dbiterrb()
 );
endmodule
