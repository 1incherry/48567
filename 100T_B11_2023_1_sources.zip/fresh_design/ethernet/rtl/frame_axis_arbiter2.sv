`timescale 1ns/1ps
// Arbitration changes ONLY after the selected packet's actual LAST handshake.
module frame_axis_arbiter2(input wire clk,rst_n,
 input wire[15:0]s_data,input wire[1:0]s_valid,s_last,output wire[1:0]s_ready,
 output wire[7:0]m_data,output wire m_valid,m_last,input wire m_ready,output wire quiescent);
 reg held,owner,previous;
 assign m_data=s_data[owner*8+:8];assign m_valid=rst_n&&held&&s_valid[owner];assign m_last=held&&s_last[owner];
 assign s_ready=m_valid&&m_ready?(2'b01<<owner):0;
 assign quiescent=rst_n&&!held&&s_valid==0;
 always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin held<=0;owner<=0;previous<=1;end
 else begin
 if(!held&&|s_valid)begin held<=1;owner<=s_valid==3?!previous:s_valid[1];end
 if(m_valid&&m_ready&&m_last)begin held<=0;previous<=owner;end
 end end
endmodule
