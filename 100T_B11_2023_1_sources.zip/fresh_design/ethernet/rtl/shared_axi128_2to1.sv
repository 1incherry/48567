`timescale 1ns/1ps
// Two real AXI128 clients, one outstanding read + one write. Independent
// burst owners remain locked through true RLAST/B; no owner change on cancel.
module shared_axi128_2to1(
 input wire clk,rst_n,
 input wire[63:0]s_awaddr,input wire[15:0]s_awlen,input wire[5:0]s_awsize,input wire[3:0]s_awburst,input wire[1:0]s_awvalid,output wire[1:0]s_awready,
 input wire[255:0]s_wdata,input wire[31:0]s_wstrb,input wire[1:0]s_wlast,s_wvalid,output wire[1:0]s_wready,
 output wire[3:0]s_bresp,output wire[1:0]s_bvalid,input wire[1:0]s_bready,
 input wire[63:0]s_araddr,input wire[15:0]s_arlen,input wire[5:0]s_arsize,input wire[3:0]s_arburst,input wire[1:0]s_arvalid,output wire[1:0]s_arready,
 output wire[255:0]s_rdata,output wire[3:0]s_rresp,output wire[1:0]s_rlast,s_rvalid,input wire[1:0]s_rready,
 output wire[31:0]m_awaddr,output wire[7:0]m_awlen,output wire[2:0]m_awsize,output wire[1:0]m_awburst,output wire m_awvalid,input wire m_awready,
 output wire[127:0]m_wdata,output wire[15:0]m_wstrb,output wire m_wlast,m_wvalid,input wire m_wready,input wire[1:0]m_bresp,input wire m_bvalid,output wire m_bready,
 output wire[31:0]m_araddr,output wire[7:0]m_arlen,output wire[2:0]m_arsize,output wire[1:0]m_arburst,output wire m_arvalid,input wire m_arready,
 input wire[127:0]m_rdata,input wire[1:0]m_rresp,input wire m_rlast,m_rvalid,output wire m_rready,
 output wire quiescent,output reg fault
);
 reg rheld,wheld,ro,wo,raccepted,waccepted,wdata_done,rlastwinner,wlastwinner;
 reg[7:0]rbeats,wbeats,rlen,wlen;
 assign m_araddr=s_araddr[ro*32+:32];assign m_arlen=s_arlen[ro*8+:8];assign m_arsize=s_arsize[ro*3+:3];assign m_arburst=s_arburst[ro*2+:2];
 assign m_arvalid=rst_n&&rheld&&!raccepted&&s_arvalid[ro];assign s_arready=m_arvalid&&m_arready?(2'b01<<ro):0;
 assign m_rready=rst_n&&rheld&&raccepted&&s_rready[ro];assign s_rvalid=rst_n&&rheld&&raccepted&&m_rvalid?(2'b01<<ro):0;
 assign s_rdata=ro?{m_rdata,128'd0}:{128'd0,m_rdata};assign s_rresp=ro?{m_rresp,2'd0}:{2'd0,m_rresp};assign s_rlast=(m_rlast?2'b01:0)<<ro;
 assign m_awaddr=s_awaddr[wo*32+:32];assign m_awlen=s_awlen[wo*8+:8];assign m_awsize=s_awsize[wo*3+:3];assign m_awburst=s_awburst[wo*2+:2];
 assign m_awvalid=rst_n&&wheld&&!waccepted&&s_awvalid[wo];assign s_awready=m_awvalid&&m_awready?(2'b01<<wo):0;
 assign m_wdata=s_wdata[wo*128+:128];assign m_wstrb=s_wstrb[wo*16+:16];assign m_wlast=s_wlast[wo];assign m_wvalid=rst_n&&wheld&&!wdata_done&&s_wvalid[wo];assign s_wready=m_wvalid&&m_wready?(2'b01<<wo):0;
 assign m_bready=rst_n&&wheld&&waccepted&&wdata_done&&s_bready[wo];assign s_bvalid=rst_n&&wheld&&waccepted&&wdata_done&&m_bvalid?(2'b01<<wo):0;assign s_bresp=wo?{m_bresp,2'd0}:{2'd0,m_bresp};
 assign quiescent=rst_n&&!rheld&&!wheld&&s_arvalid==0&&s_awvalid==0&&s_wvalid==0&&!m_rvalid&&!m_bvalid;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin rheld<=0;wheld<=0;ro<=0;wo<=0;raccepted<=0;waccepted<=0;wdata_done<=0;rbeats<=0;wbeats<=0;rlen<=0;wlen<=0;rlastwinner<=1;wlastwinner<=1;fault<=0;end
  else begin
   if(!rheld&&|s_arvalid)begin rheld<=1;raccepted<=0;rbeats<=0;ro<=s_arvalid==3?!rlastwinner:s_arvalid[1];rlen<=s_arlen[(s_arvalid==3?!rlastwinner:s_arvalid[1])*8+:8];end
   if(m_rvalid&&m_rready)begin rbeats<=rbeats+1'b1;if(m_rlast!=(rbeats==rlen))fault<=1;end
   if(m_wvalid&&m_wready)begin wbeats<=wbeats+1'b1;if(m_wlast!=(wbeats==wlen))fault<=1;if(m_wlast)wdata_done<=1;end
   if(m_arvalid&&m_arready)raccepted<=1;
   if(m_rvalid&&m_rready&&m_rlast)begin rheld<=0;raccepted<=0;rlastwinner<=ro;end
   if(!wheld&&|s_awvalid)begin wheld<=1;waccepted<=0;wdata_done<=0;wbeats<=0;wo<=s_awvalid==3?!wlastwinner:s_awvalid[1];wlen<=s_awlen[(s_awvalid==3?!wlastwinner:s_awvalid[1])*8+:8];end
   if(m_awvalid&&m_awready)waccepted<=1;
   if(m_bvalid&&m_bready)begin wheld<=0;waccepted<=0;wlastwinner<=wo;end
   if(m_rvalid&&(!rheld||!raccepted)||m_bvalid&&(!wheld||!waccepted))fault<=1;
  end
 end
endmodule
