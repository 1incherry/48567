`timescale 1ns/1ps
// Read-only packet observation bank + explicit snapshot command. No inference,
// root authority, action, arbitrary DDR, or Qwen GO port is present here.
module ntr2_context_axil(input wire clk,rst_n,
 input wire report_valid,output wire report_ready,input wire[2047:0]report_body,input wire transport_fault,
 input wire[11:0]s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire[31:0]s_wdata,input wire[3:0]s_wstrb,input wire s_wvalid,output wire s_wready,
 output reg[1:0]s_bresp,output reg s_bvalid,input wire s_bready,
 input wire[11:0]s_araddr,input wire s_arvalid,output wire s_arready,
 output reg[31:0]s_rdata,output reg[1:0]s_rresp,output reg s_rvalid,input wire s_rready,
 output reg tx_start,output reg[863:0]tx_payload,output reg[31:0]tx_sequence,tx_session,input wire tx_busy,tx_error,
 output wire quiescent,output reg[31:0]reports_received
);
 reg[2047:0]latest,frozen;reg latest_valid,frozen_valid;reg[31:0]snapshot_number;
 reg awhold,whold;reg[11:0]aw;reg[31:0]wd;reg[3:0]ws;
 assign report_ready=rst_n;assign s_awready=rst_n&&!awhold&&!s_bvalid;assign s_wready=rst_n&&!whold&&!s_bvalid;
 assign s_arready=rst_n&&!s_rvalid;
 assign quiescent=rst_n&&!awhold&&!whold&&!s_bvalid&&!s_rvalid&&!s_awvalid&&!s_wvalid&&!s_arvalid&&!tx_start&&!tx_busy;
 integer wordindex;
 always @(posedge clk or negedge rst_n)begin
 if(!rst_n)begin latest<=0;frozen<=0;latest_valid<=0;frozen_valid<=0;snapshot_number<=0;awhold<=0;whold<=0;aw<=0;wd<=0;ws<=0;s_bresp<=0;s_bvalid<=0;s_rdata<=0;s_rresp<=0;s_rvalid<=0;tx_start<=0;tx_payload<=0;tx_sequence<=0;tx_session<=0;reports_received<=0;end
 else begin
 tx_start<=0;
 if(report_valid&&report_ready)begin latest<=report_body;latest_valid<=1;reports_received<=reports_received+1'b1;end
 if(s_awvalid&&s_awready)begin aw<=s_awaddr;awhold<=1;end
 if(s_wvalid&&s_wready)begin wd<=s_wdata;ws<=s_wstrb;whold<=1;end
 if(s_bvalid&&s_bready)s_bvalid<=0;
 if(awhold&&whold&&!s_bvalid)begin
 awhold<=0;whold<=0;s_bvalid<=1;s_bresp<=2'b10;
 if(ws==15&&aw[1:0]==0)begin
  if(aw==12'h010&&wd==1&&latest_valid)begin frozen<=latest;frozen_valid<=1;snapshot_number<=reports_received;s_bresp<=0;end
  else if(aw==12'h020&&wd==1&&!tx_busy&&!tx_error&&!transport_fault)begin tx_start<=1;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw==12'h024)begin tx_sequence<=wd;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw==12'h028)begin tx_session<=wd;s_bresp<=0;end
  else if(!tx_busy&&!tx_start&&aw>=12'h300&&aw<12'h36c)begin
   tx_payload[(aw-12'h300)*8+:32]<=wd;s_bresp<=0;
  end
 end
 end
 if(s_rvalid&&s_rready)s_rvalid<=0;
 if(s_arvalid&&s_arready)begin
 s_rvalid<=1;s_rdata<=0;s_rresp<=0;
 case(s_araddr)
 12'h000:s_rdata<=32'h4e545232;
 12'h004:s_rdata<={26'd0,transport_fault,tx_error,tx_busy,1'b0,frozen_valid,latest_valid};
 12'h008:s_rdata<=reports_received;
 12'h00c:s_rdata<=snapshot_number;
 12'h024:s_rdata<=tx_sequence;
 12'h028:s_rdata<=tx_session;
 default:if(s_araddr>=12'h100&&s_araddr<12'h200&&s_araddr[1:0]==0&&frozen_valid)begin s_rdata<=frozen[2047-(s_araddr-12'h100)*8-:32];end else s_rresp<=2'b10;
 endcase
 end
 end end
endmodule
