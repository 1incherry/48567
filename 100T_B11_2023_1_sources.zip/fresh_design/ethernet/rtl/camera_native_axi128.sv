`timescale 1ns/1ps
// One native 128-bit camera command at a time, actual AXI B/R completion.
// Native app addresses count x16 DDR words; AXI addresses count bytes.
// Native write acceptance is buffered; readback cannot pass its delayed B.
module camera_native_axi128 #(
 parameter[31:0]BASE=32'h8f000000,LIMIT=32'h8f440000
)(input wire clk,rst_n,
 input wire[26:0]app_addr,input wire[2:0]app_cmd,input wire app_en,output wire app_rdy,
 input wire[127:0]app_wdf_data,input wire[15:0]app_wdf_mask,input wire app_wdf_end,app_wdf_wren,output wire app_wdf_rdy,
 output reg[127:0]app_rd_data,output reg app_rd_data_valid,app_rd_data_end,
 output wire[31:0]m_awaddr,output wire[7:0]m_awlen,output wire[2:0]m_awsize,output wire[1:0]m_awburst,output wire m_awvalid,input wire m_awready,
 output wire[127:0]m_wdata,output wire[15:0]m_wstrb,output wire m_wlast,m_wvalid,input wire m_wready,input wire[1:0]m_bresp,input wire m_bvalid,output wire m_bready,
 output wire[31:0]m_araddr,output wire[7:0]m_arlen,output wire[2:0]m_arsize,output wire[1:0]m_arburst,output wire m_arvalid,input wire m_arready,
 input wire[127:0]m_rdata,input wire[1:0]m_rresp,input wire m_rlast,m_rvalid,output wire m_rready,
 output wire quiescent,output reg fault
);
 localparam IDLE=0,WRITE=1,BRESP=2,AR=3,RRESP=4;reg[2:0]state;reg[31:0]address;reg[127:0]data;reg[15:0]strobe;reg awdone,wdone;
 wire[31:0]byte_addr=32'h80000000+{4'd0,app_addr,1'b0};
 wire legal=byte_addr>=BASE&&byte_addr+16<=LIMIT&&app_addr[2:0]==0&&(app_cmd==0||app_cmd==1);
 assign app_rdy=rst_n&&state==IDLE&&!fault;assign app_wdf_rdy=app_rdy;
 assign m_awaddr=address;assign m_awlen=0;assign m_awsize=4;assign m_awburst=1;assign m_awvalid=rst_n&&state==WRITE&&!awdone;
 assign m_wdata=data;assign m_wstrb=strobe;assign m_wlast=1;assign m_wvalid=rst_n&&state==WRITE&&!wdone;
 assign m_bready=rst_n&&state==BRESP;
 assign m_araddr=address;assign m_arlen=0;assign m_arsize=4;assign m_arburst=1;assign m_arvalid=rst_n&&state==AR;assign m_rready=rst_n&&state==RRESP;
 assign quiescent=rst_n&&state==IDLE&&!app_en&&!app_wdf_wren&&!m_bvalid&&!m_rvalid;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin state<=IDLE;address<=0;data<=0;strobe<=0;awdone<=0;wdone<=0;fault<=0;app_rd_data<=0;app_rd_data_valid<=0;app_rd_data_end<=0;end
  else begin
   app_rd_data_valid<=0;app_rd_data_end<=0;
   case(state)
    IDLE:if(app_en&&app_rdy)begin
     if(!legal||(app_cmd==0&&(!app_wdf_wren||!app_wdf_end))||(app_cmd==1&&app_wdf_wren))fault<=1;
     else begin address<=byte_addr;awdone<=0;wdone<=0;
      if(app_cmd==0)begin data<=app_wdf_data;strobe<=~app_wdf_mask;state<=WRITE;end else state<=AR;
     end
    end
    WRITE:begin
     if(m_awvalid&&m_awready)awdone<=1;if(m_wvalid&&m_wready)wdone<=1;
     if((awdone||m_awready)&&(wdone||m_wready))state<=BRESP;
    end
    BRESP:if(m_bvalid)begin if(m_bresp!=0)fault<=1;state<=IDLE;end
    AR:if(m_arready)state<=RRESP;
    RRESP:if(m_rvalid)begin
     app_rd_data<=m_rdata;app_rd_data_valid<=1;app_rd_data_end<=m_rlast&&m_rresp==0;
     if(m_rresp!=0||!m_rlast)fault<=1;
     // Malformed burst drains until real RLAST; cannot silently reuse owner.
     if(m_rlast)state<=IDLE;
    end
    default:begin fault<=1;end
   endcase
  end
 end
endmodule
