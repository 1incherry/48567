# Reset synchronizers only. Assertion is asynchronous; release passes three
# destination-clock flip-flops. No Q->D path or business data exception.
set allreset {}
foreach {pat expect} {
 {.*ethernet/camera_source/(tx|ui|cam)_reset_pipe_reg\[[0-2]\]} 9
 {cam_reset_sync_reg\[[0-2]\]} 3
 {.*ethernet/camera_source/fifo_write_reset_pipe_reg\[[0-2]\]} 3
} {
 set cc [get_cells -hier -regexp $pat]
 if {[llength $cc]!=$expect} {error "RESET_SYNC_COUNT $pat [llength $cc] != $expect"}
 foreach c $cc {
  set ar [get_property ASYNC_REG $c]
  puts "RESET_SYNC_ATTRIBUTE $c ASYNC_REG=$ar"
  if {[string tolower $ar] ni {true 1}} {error "RESET_SYNC_NOT_ASYNC_REG $c value=$ar"}
  set pp [get_pins -of_objects $c -filter {REF_PIN_NAME == PRE || REF_PIN_NAME == CLR}]
  if {[llength $pp]!=1} {error "RESET_SYNC_ASYNC_PIN_COUNT $c"}
  set_false_path -to $pp
  puts "RESET_SYNC_ASYNC_PIN_ONLY $c $pp"
  lappend allreset $c
 }
}
if {[llength $allreset]!=15} {error RESET_SYNC_TOTAL}
