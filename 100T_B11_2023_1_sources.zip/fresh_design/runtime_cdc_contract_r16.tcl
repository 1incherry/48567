# R16 candidate only. Must bind/check exact mapped cells after fresh synthesis.
# Scope: single-bit 3FF ASYNC_REG synchronizers and their asynchronous reset
# controls. Business D/reset pins, payload buses and all-clock groups untouched.
proc runtime_checked_cells {pattern expected} {
 set cc [get_cells -hier -regexp $pattern]
 if {[llength $cc]!=$expected} {error "R16_CDC_CELL_COUNT $pattern [llength $cc] expected$expected"}
 foreach c $cc {if {[string tolower [get_property ASYNC_REG $c]] ni {true 1}} {error "R16_NOT_ASYNC_REG $c"}}
 return $cc
}
set allfirst {}
foreach {pat expected} {
 {.*ethernet/runtime_boot_side/helper/(on_sync|off_sync|owner_sync|idle_sync|fault_sync)_reg\[0\]} 5
 {.*ethernet/runtime_guard/(ack_sync|io_fault_sync|io_alive_sync|freeze_sync)_reg\[0\]} 4
 {.*shared_control.*/(release_toggle_sync|release_owned_sync|trusted_stop_sync)_reg\[0\]} 3
 {.*shared_control.*/geometry/(request_sync|good_sync|bad_sync)_reg\[0\]} 3
 {.*shared_control.*/retire/(ack_sync|request_sync)_reg\[0\]} 2
 {.*shared_control.*/barrier/(pre_sync|disable_sync|main_sync|close_sync|ack_sync|fault_sync|retired_sync|cpu_sync|closed_ack_sync)_reg\[0\]} 9
} {
 foreach c [runtime_checked_cells $pat $expected] {
  set pp [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]
  if {[llength $pp]!=1} {error R16_FIRST_STAGE_D_COUNT}
  set_false_path -to $pp
  puts "R16_SINGLE_SCALAR_FIRST_D_ONLY $c $pp"
  lappend allfirst $c
 }
}
if {[llength $allfirst]!=26} {error R16_EXPLICIT_FIRST_D_TOTAL}
set allreset {}
foreach {pat expected} {
 {.*runtime_boot/(request_sync|descriptor_sync|epoch_sync)_reg\[[0-2]\]} 9
 {.*ethernet/runtime_guard/(ack_sync|io_fault_sync|io_alive_sync)_reg\[[0-2]\]} 9
 {.*ethernet/runtime_guard/(epoch_sync|live_sync|source_epoch_sync|freeze_allow_sync)_reg\[[0-2]\]} 12
 {.*ethernet/runtime_boot_side/helper/epoch_sync_reg\[[0-2]\]} 3
 {.*ethernet/runtime_health_sync/healthy_sync_reg\[[0-2]\]} 3
 {.*runtime_cpu/dispatch/cpu_alive_reg\[[0-2]\]} 3
 {(^|.*/)(transport_release100|runtime_board_release50|runtime_board_release125)_reg\[[0-2]\]} 9
 {.*shared_control.*/barrier/(allow_sync|release_permit)_reg\[[0-2]\]} 6
} {
 foreach c [runtime_checked_cells $pat $expected] {
  set pp [get_pins -of_objects $c -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
  if {[llength $pp]!=1} {error "R16_ASYNC_CONTROL_PIN_COUNT $c"}
  set_false_path -to $pp
  puts "R16_ASYNC_SYNC_CONTROL_ONLY $c $pp"
  lappend allreset $c
 }
}
if {[llength $allreset]!=54} {error R16_EXPLICIT_ASYNC_CONTROL_TOTAL}
# Vendor SmartConnect / AXI CC / MCS constraints are generated from exact XCI;
# R12 camera/context held/FIFO constraints remain in unchanged cdc_contract.tcl.
