# Actual simulator command result, not a fabricated Time log.
help current_time
set before [current_time]
puts "R23_ACTUAL_CURRENT_TIME_BEFORE=$before"
run 1ns
set now [current_time]
puts "R23_ACTUAL_CURRENT_TIME_AFTER=$now"
if {![regexp {^\s*([0-9]+(?:\.[0-9]+)?)\s*(fs|ps|ns|us|ms|s)\s*$} $now -> number units]} {error ACTUAL_CURRENT_TIME_FORMAT_UNEXPECTED}
array set scale {fs 0.001 ps 1 ns 1000 us 1000000 ms 1000000000 s 1000000000000}
if {double($number)*$scale($units)!=1000.0} {error ACTUAL_CURRENT_TIME_NOT_EXACT_1000PS}
puts R23_NATIVE_INITIALIZATION_1NS_ACTUAL_TIME_ASSERTED
quit
