#include "qhint.h"
static int scalar(const uint8_t*p,size_t n,size_t*at,uint32_t*c){
 size_t i=*at;uint32_t v,min;unsigned need;uint8_t b;
 if(i>=n)return 0;
 b=p[i++];
 if(b<128){*at=i;*c=b;return 1;}
 if(b>=0xc2&&b<=0xdf){v=b&31u;need=1;min=128;}
 else if(b>=0xe0&&b<=0xef){v=b&15u;need=2;min=2048;}
 else if(b>=0xf0&&b<=0xf4){v=b&7u;need=3;min=65536;}
 else return -1;
 if(need>n-i)return -1;
 while(need--){b=p[i++];if((b&0xc0)!=0x80)return -1;v=(v<<6)|(b&63u);}
 if(v<min||v>0x10ffffu||(v>=0xd800&&v<=0xdfff))return -1;
 *at=i;*c=v;return 1;
}
static int space(uint32_t c){return c==32||c==9||c==10||c==13||c==0x3000;}
static unsigned digit(uint32_t c){
 switch(c){case 0x4e00:return 1;case 0x4e8c:return 2;case 0x4e09:return 3;case 0x56db:return 4;case 0x4e94:return 5;case 0x516d:return 6;case 0x4e03:return 7;case 0x516b:return 8;case 0x4e5d:return 9;default:return 0;}
}
static int numberchar(uint32_t c){return(c>='0'&&c<='9')||digit(c)||c==0x5341||c==0x767e||c==0x96f6||c==0x3007;}
static int ordinal(const uint8_t*p,size_t n,size_t start,uint32_t*value,uint32_t*suffix){
 size_t i=start,j;uint32_t a[6],c;unsigned count=0;int ascii=1,too_many=0;
 while(i<n){j=i;if(scalar(p,n,&j,&c)!=1)return 0;if(!space(c))break;i=j;}
 while(i<n){j=i;if(scalar(p,n,&j,&c)!=1)return 0;if(!numberchar(c))break;i=j;
  if(count<6)a[count++]=c;else too_many=1;if(c<'0'||c>'9')ascii=0;
 }
 if(!count)return 0;
 while(i<n){j=i;if(scalar(p,n,&j,&c)!=1)return 0;if(!space(c))break;i=j;}
 if(scalar(p,n,&i,&c)!=1||(c!=0x5f20&&c!=0x683c))return 0;
 *suffix=c;*value=0;if(too_many)return -1;
 if(ascii){if(count>3||(count>1&&a[0]=='0'))return -1;for(unsigned k=0;k<count;k++)*value=*value*10u+a[k]-'0';}
 else if(count==1){*value=a[0]==0x5341?10u:digit(a[0]);}
 else if(count==2&&a[0]==0x5341&&digit(a[1]))*value=10u+digit(a[1]);
 else if(count==2&&digit(a[0])&&a[1]==0x5341)*value=digit(a[0])*10u;
 else if(count==2&&a[0]==0x4e00&&a[1]==0x767e)*value=100;
 else if(count==3&&digit(a[0])>=2&&a[1]==0x5341&&digit(a[2]))*value=digit(a[0])*10u+digit(a[2]);
 else return -1;
 return *value>=1&&*value<=100?1:-1;
}
int qhint_parse(const uint8_t*p,size_t n,qhint*out){
 size_t i=0,j=0;uint32_t c,prev=0,first=0,second=0,third=0,image=0,pane=1;unsigned images=0,panes=0,position=0;int verb=0,negative=0,imperative=0;
 if(!out)return QHI_ARGUMENT;
 out->image_no=0;out->operation=0;out->pane=0;out->suppress_display=0;
 if(!p||!n||n>4096)return QHI_ARGUMENT;
 while(i<n){if(scalar(p,n,&i,&c)!=1)return QHI_UTF8;}
 i=0;while(i<n){if(scalar(p,n,&i,&c)!=1)return QHI_UTF8;
  if(!space(c)&&position<3){if(position==0)first=c;else if(position==1)second=c;else third=c;position++;}
  if(c==0x4e0d||c==0x522b)negative=1;
  if((prev==0x663e&&c==0x793a)||(prev==0x8c03&&c==0x51fa)||(prev==0x653e&&c==0x5230))verb=1;
  if(c==0x7b2c){uint32_t value,suffix;int r=ordinal(p,n,i,&value,&suffix);
   if(r<0)return QHI_RANGE;
   if(r==1){if(suffix==0x5f20){image=value;images++;}else{pane=value;panes++;}}
  }
  prev=c;
 }
 (void)j;
 if(!images)return QHI_OK;
 if(images!=1||panes>1)return QHI_AMBIGUOUS;
 imperative=(first==0x663e&&second==0x793a)||(first==0x8c03&&second==0x51fa)||(first==0x8bf7&&((second==0x663e&&third==0x793a)||(second==0x8c03&&third==0x51fa)))||(first==0x628a&&verb);
 out->suppress_display=(uint8_t)negative;
 if((panes||(verb&&imperative))&&!negative){if(pane!=1&&pane!=3&&pane!=4)return QHI_RANGE;out->operation=2;out->pane=(uint8_t)pane;}
 else out->operation=1;
 out->image_no=image;return QHI_OK;
}
