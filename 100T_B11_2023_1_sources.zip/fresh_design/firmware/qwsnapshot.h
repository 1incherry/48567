#ifndef QWSNAPSHOT_H
#define QWSNAPSHOT_H
#include "qwobs.h"
enum { QWS_OK=0,QWS_UNAVAILABLE=1,QWS_ARGUMENT=-200,QWS_IO=-201,
 QWS_ABI=-202,QWS_STATUS=-203,QWS_CHANGED=-204,QWS_SYNTAX=-205 };
typedef struct {void *opaque;int (*read32)(void *,uint32_t,uint32_t *);
 int (*write32)(void *,uint32_t,uint32_t);} qwsnapshot_io;
/* CPU-side translated address C1000000, AXI-side41000000.
 * Only for the exact new try-freeze CSR image. No fallback/probing old010.
 * All callbacks return0 only after the actual OKAY R/B response.
 * Input/output and256-byte body scratch are local BRAM, not unleased DDR.
 * Unavailable and failures leave record/number unchanged. Body is scratch.
 * Syntactic observations establish no authentication/freshness/authority. */
int qwsnapshot_try(qwsnapshot_io io,uint8_t body[256],qwobs_record *record,
 uint32_t *snapshot_number);
#endif
