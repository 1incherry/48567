#ifndef QWENGLISH_H
#define QWENGLISH_H
#include "qwobs.h"
/* Exact old host historical English SYSTEM and compact JSON facts.
 * Not an answer template, authentication proof or control request. */
int qwenglish_build(const qwobs_record *r,const uint8_t **system,size_t *system_bytes,uint8_t *json,size_t cap,size_t *json_bytes);
#endif
