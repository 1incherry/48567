#include "history_control.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
static uint32_t r32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static uint64_t r64(const uint8_t *p){return (uint64_t)r32(p)|(uint64_t)r32(p+4)<<32;}
static void w32(uint8_t *p,uint32_t v){unsigned i;for(i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static void w64(uint8_t *p,uint64_t v){w32(p,(uint32_t)v);w32(p+4,(uint32_t)(v>>32));}
static int legal(const hsc_request *r){return r->bridge_session&&r->nonce&&r->batch_id&&r->image_no&&r->image_no<=PSH_MAX_SLOTS&&
 ((r->op==HSC_QUERY&&r->pane==0)||(r->op==HSC_SELECT&&(r->pane==1||r->pane==3||r->pane==4)));}
hsc_rc hsc_decode(const uint8_t *p,size_t n,hsc_request *r){
 hsc_request t;
 if(!p||!r||n!=HSC_REQUEST_BYTES||memcmp(p,"HST1",4)||p[4]!=1||p[7]||r32(p+36)||r32(p+40)!=48||r32(p+44)!=psh_crc32(p,44))return HSC_WIRE;
 memset(&t,0,sizeof t);t.op=p[5];t.pane=p[6];t.bridge_session=r64(p+8);t.nonce=r64(p+16);t.batch_id=r64(p+24);t.image_no=r32(p+32);
 if(!legal(&t))return HSC_WIRE;
 *r=t;return HSC_OK;
}
hsc_rc hsc_encode(const hsc_request *r,uint8_t *p,size_t n){
 if(!r||!p||n<HSC_REQUEST_BYTES||!legal(r))return HSC_ARGUMENT;
 memset(p,0,48);memcpy(p,"HST1",4);p[4]=1;p[5]=r->op;p[6]=r->pane;w64(p+8,r->bridge_session);w64(p+16,r->nonce);w64(p+24,r->batch_id);w32(p+32,r->image_no);w32(p+40,48);w32(p+44,psh_crc32(p,44));return HSC_OK;
}
hsc_rc hsc_init(hsc_bridge *b,psh_history *h,uint64_t session){
 if(!b||!h||!h->storage||!session)return HSC_ARGUMENT;
 memset(b,0,sizeof *b);b->history=h;b->bridge_session=session;return HSC_OK;
}
hsc_rc hsc_accept(hsc_bridge *b,const uint8_t *p,size_t n){
 hsc_request r;hsc_rc rc;psh_rc pr;
 if(!b||!b->history)return HSC_ARGUMENT;
 rc=hsc_decode(p,n,&r);if(rc!=HSC_OK)return rc;
 if(r.bridge_session!=b->bridge_session)return HSC_SESSION;
 if(r.nonce<=b->last_nonce)return HSC_REPLAY;
 b->last_nonce=r.nonce;
 if(b->phase!=HSC_IDLE)return HSC_BUSY;
 if(r.batch_id!=b->history->batch_id)return HSC_HISTORY;
 if(r.op==HSC_QUERY){
  pr=psh_query(b->history,r.batch_id,r.image_no,&b->query_ticket,&b->snapshot,&b->query_raw);
  b->history_result=pr;if(pr!=PSH_OK)return HSC_HISTORY;
  b->active=r;b->phase=HSC_QUERY_HELD;return HSC_OK;
 }
 pr=psh_select_image(b->history,r.batch_id,r.image_no,r.pane);
 b->history_result=pr;if(pr!=PSH_OK)return HSC_HISTORY;
 pr=psh_display_prepare(b->history);b->history_result=pr;
 if(pr!=PSH_OK)return HSC_HISTORY;
 b->active=r;b->phase=HSC_SELECT_PREPARED;return HSC_OK;
}
hsc_rc hsc_query_context(hsc_bridge *b,uint64_t nonce,char *out,size_t cap,size_t *written){
 char record[2048];size_t len=0;int n;
 if(!b||!out||!written)return HSC_ARGUMENT;
 if(b->phase!=HSC_QUERY_HELD||b->active.nonce!=nonce)return HSC_HISTORY;
 if(psh_context_json(&b->snapshot,record,sizeof record,&len)!=PSH_OK)return HSC_HISTORY;
 n=snprintf(out,cap,"{\"protocol\":\"HST1\",\"bridge_session\":\"%016" PRIx64 "\",\"nonce\":\"%016" PRIx64 "\",\"provenance\":\"UNTRUSTED_PS_HISTORY\",\"pl_record_authenticated\":false,\"qwen_generated_answer\":false,\"record\":%s}",b->bridge_session,nonce,record);
 if(n<0||(size_t)n>=cap)return HSC_ARGUMENT;
 *written=(size_t)n;return HSC_OK;
}
hsc_rc hsc_response_json(const hsc_bridge *b,uint64_t nonce,char *out,size_t cap,size_t *written){
 const char *state;int n;
 if(!b||!out||!written)return HSC_ARGUMENT;
 *written=0;
 if(b->phase==HSC_IDLE||b->active.nonce!=nonce)return HSC_HISTORY;
 state=b->phase==HSC_QUERY_HELD?"QUERY_HELD":b->phase==HSC_SELECT_PRESENTED?"PRESENTED":b->phase==HSC_LOCKED_ERROR?"ERROR":"PENDING";
 n=snprintf(out,cap,"{\"protocol\":\"HST1\",\"bridge_session\":\"%016" PRIx64 "\",\"nonce\":\"%016" PRIx64 "\",\"batch_id\":\"%016" PRIx64 "\",\"image_no\":%" PRIu32 ",\"pane\":%u,\"operation\":\"%s\",\"status\":\"%s\",\"pl_record_authenticated\":false}",b->bridge_session,nonce,b->active.batch_id,b->active.image_no,(unsigned)b->active.pane,b->active.op==HSC_QUERY?"QUERY":"SELECT",state);
 if(n<0||(size_t)n>=cap)return HSC_ARGUMENT;
 *written=(size_t)n;return HSC_OK;
}
hsc_rc hsc_query_release(hsc_bridge *b,uint64_t nonce){
 if(!b||b->phase!=HSC_QUERY_HELD||b->active.nonce!=nonce)return HSC_HISTORY;
 if(psh_release(b->history,b->query_ticket,PSH_QUERY_LEASE)!=PSH_OK){b->phase=HSC_LOCKED_ERROR;return HSC_ERROR;}
 b->query_raw=0;b->phase=HSC_IDLE;return HSC_OK;
}
hsc_rc hsc_select_submit(hsc_bridge *b,uint64_t nonce,uint32_t seq,unsigned tag,uint32_t ack){
 if(!b||b->phase!=HSC_SELECT_PREPARED||b->active.nonce!=nonce)return HSC_HISTORY;
 b->history_result=psh_display_submit(b->history,seq,tag,ack);
 if(b->history_result!=PSH_OK)return HSC_HISTORY;
 b->phase=HSC_SELECT_SUBMITTED;return HSC_OK;
}
hsc_rc hsc_select_observe(hsc_bridge *b,uint32_t ack,unsigned tag,uint32_t frames,int error){
 if(!b||b->phase!=HSC_SELECT_SUBMITTED)return HSC_HISTORY;
 b->history_result=psh_display_observe(b->history,ack,tag,frames,error);
 if(b->history_result==PSH_PRESENTED){b->phase=HSC_SELECT_PRESENTED;return HSC_OK;}
 if(b->history_result==PSH_BUSY||b->history_result==PSH_OK)return HSC_NOT_PRESENTED;
 b->phase=HSC_LOCKED_ERROR;return HSC_ERROR;
}
hsc_rc hsc_select_complete(hsc_bridge *b,uint64_t nonce){
 if(!b||b->active.nonce!=nonce)return HSC_HISTORY;
 if(b->phase!=HSC_SELECT_PRESENTED)return HSC_NOT_PRESENTED;
 b->phase=HSC_IDLE;return HSC_OK;
}
hsc_rc hsc_cancel_prepared(hsc_bridge *b,uint64_t nonce){
 if(!b||b->phase!=HSC_SELECT_PREPARED||b->active.nonce!=nonce)return HSC_HISTORY;
 if(psh_display_cancel_prepared(b->history)!=PSH_OK)return HSC_HISTORY;
 b->phase=HSC_IDLE;return HSC_OK;
}
hsc_rc hsc_release_after_drain(hsc_bridge *b,int idle){
 if(!b||b->phase!=HSC_LOCKED_ERROR)return HSC_HISTORY;
 if(!idle)return HSC_BUSY;
 if(b->query_raw){if(psh_release(b->history,b->query_ticket,PSH_QUERY_LEASE)!=PSH_OK)return HSC_ERROR;b->query_raw=0;}
 if(psh_display_release_after_drain(b->history,1)!=PSH_OK)return HSC_ERROR;
 b->phase=HSC_IDLE;return HSC_OK;
}
