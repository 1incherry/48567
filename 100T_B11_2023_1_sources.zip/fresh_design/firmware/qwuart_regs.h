#ifndef QWUART_REGS_H
#define QWUART_REGS_H
/* Private candidate peripheral ABI2, CPU local IO; not AXI physical addresses. */
#define QWU_BASE 0xc2001000u
#define QWU_ABI 0x51555232u
#define QWU_ABI_REG (QWU_BASE+0x00u)
#define QWU_STATUS (QWU_BASE+0x04u)
#define QWU_LENGTH (QWU_BASE+0x08u)
#define QWU_POP (QWU_BASE+0x0cu)
#define QWU_TX (QWU_BASE+0x10u)
#define QWU_ADMISSION (QWU_BASE+0x14u)
#define QWU_EVENTS (QWU_BASE+0x18u)
#define QWU_ACCEPTED (QWU_BASE+0x1cu)
#define QWU_REJECTED (QWU_BASE+0x20u)
#define QWU_OVERFLOW (QWU_BASE+0x24u)
#define QWU_MODE_ABORT (QWU_BASE+0x28u)
#define QWU_FIFO_LEVEL (QWU_BASE+0x2cu)
#define QWU_MS_TICK (QWU_BASE+0x30u)
#define QWU_CLOCK_HZ (QWU_BASE+0x34u)
#define QWU_OWNER (1u<<0)
#define QWU_QUESTION_VALID (1u<<1)
#define QWU_DATA_VALID (1u<<2)
#define QWU_TX_READY (1u<<3)
#define QWU_ADMIT_ENABLED (1u<<4)
#define QWU_WIRE_RESYNC (1u<<5)
#define QWU_MMIO_FAULT (1u<<31)
#define QWU_POP_VALID (1u<<8)
#define QWU_POP_LAST (1u<<9)
#define QWU_DEFAULT_TIMEOUT_MS 600000u
#endif
