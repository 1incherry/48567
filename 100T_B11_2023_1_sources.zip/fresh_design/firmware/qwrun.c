#include "qwrun.h"
#define CORE 0x40000000u
#define LEASE 0x41000030u
#define LEASE_CMD 0x41000034u
static int fail(qwrun *r,int error){
 r->error=(uint32_t)error;r->state=QWR_FAILED;
 qwdet_abort(r->decoder);return error;
}
static int rd(qwrun *r,uint32_t address,uint32_t *value){
 return r->io.read32(r->io.opaque,address,value)==0?0:fail(r,QWR_IO);
}
static int wr(qwrun *r,uint32_t address,uint32_t value){
 return r->io.write32(r->io.opaque,address,value)==0?0:fail(r,QWR_IO);
}
static int lease(qwrun *r,uint32_t *value){
 int rc=rd(r,LEASE,value);if(rc)return rc;
 if((*value&0x300u)!=0x200u)return fail(r,QWR_LEASE);
 return 0;
}
static int idle(qwrun *r){
 uint32_t value;int rc;
 if((rc=rd(r,CORE,&value))!=0)return rc;
 if(value!=0x51575032u)return fail(r,QWR_NOT_IDLE);
 if((rc=rd(r,CORE+4u,&value))!=0)return rc;
 if((value&0x17u)!=1u)return fail(r,QWR_NOT_IDLE);
 if((rc=rd(r,CORE+0x58u,&value))!=0)return rc;
 if(value&0x1cbu)return fail(r,QWR_NOT_IDLE);
 if((rc=rd(r,CORE+0x3cu,&value))!=0)return rc;
 if((value>>9)&511u)return fail(r,QWR_NOT_IDLE);
 return 0;
}
static int emit(void *opaque,uint8_t byte){
 qwrun *r=(qwrun *)opaque;
 if(r->answer_bytes>=QWR_ANSWER_BYTES)return -1;
 r->answer[r->answer_bytes++]=byte;return 0;
}
int qwrun_init(qwrun *r,qwenc *e,qwdet *d,qwenc_workspace *w,qwrun_io io,
 uint8_t *rendered,uint16_t *prompt,uint8_t *answer){
 if(!r||!e||!d||!w||!rendered||!prompt||!answer||!io.read32||!io.write32||
    !io.zero_start||!io.zero_poll)return QWR_ARGUMENT;
 r->encoder=e;r->decoder=d;r->workspace=w;r->io=io;r->rendered=rendered;
 r->prompt=prompt;r->answer=answer;r->state=QWR_IDLE;r->error=0;
 r->answer_bytes=0;r->messages=0;r->message_count=0;return 0;
}
int qwrun_begin(qwrun *r,const qwchat_message *messages,size_t count,
 uint32_t max_new,uint32_t now,uint32_t timeout){
 uint32_t value;int rc;
 if(!r||(!messages&&count)||count>QWCHAT_MESSAGE_LIMIT||max_new<1||
    max_new>QWCHAT_MAX_NEW||timeout==0||timeout>=0x80000000u)return QWR_ARGUMENT;
 if(r->state!=QWR_IDLE&&r->state!=QWR_DONE)return QWR_NOT_IDLE;
 r->error=0;r->answer_bytes=0;r->prompt_count=0;r->prompt_sent=0;
 r->result_count=0;r->drained=0;r->saw_last=0;r->rendered_bytes=0;
 r->messages=messages;r->message_count=count;r->max_new=max_new;
 r->timeout=timeout;r->deadline=now+timeout;
 if((rc=idle(r))!=0)return rc;
 if((rc=rd(r,CORE+0xe0u,&value))!=0)return rc;
 if(value!=0x43500100u)return fail(r,QWR_CHECKPOINT);
 if((rc=lease(r,&value))!=0)return rc;
 if(value&1u)return fail(r,QWR_LEASE);
 /* Mark ACQUIRE before write: a failed/uncertain B response is not permission
  * to forget a request which hardware may already have accepted. */
 r->state=QWR_ACQUIRE;
 return wr(r,LEASE_CMD,1u);
}
int qwrun_poll(qwrun *r,uint32_t now){
 uint32_t status,value;int rc;
 if(!r)return QWR_ARGUMENT;
 if(r->state==QWR_FAILED)return (int)r->error;
 if(r->state==QWR_IDLE||r->state==QWR_DONE)return 0;
 if((uint32_t)(now-r->deadline)<0x80000000u)return fail(r,QWR_TIMEOUT);
 if((rc=lease(r,&status))!=0)return rc;
 if(r->state==QWR_RELEASE_CONFIRM){
  if((status&3u)==0u)r->state=QWR_DONE;
  return 0;
 }
 if(r->state==QWR_ACQUIRE){
  if(!(status&1u))return fail(r,QWR_LEASE);
  if((status&7u)==7u)r->state=QWR_PREPARE;
  return 0;
 }
 if((status&7u)!=7u)return fail(r,QWR_LEASE);
 switch(r->state){
 case QWR_PREPARE:
  rc=qwchat_prepare(r->encoder,r->messages,r->message_count,r->max_new,
    r->rendered,&r->rendered_bytes,r->prompt,&r->prompt_count,r->workspace);
  if(rc){r->error=(uint32_t)rc;r->state=QWR_REJECT_READY;return 0;}
  if(r->io.zero_start(r->io.opaque,0x8e000000u,6488064u))return fail(r,QWR_ZERO_ERROR);
  r->state=QWR_ZERO;return 0;
 case QWR_ZERO:
  rc=r->io.zero_poll(r->io.opaque);
  if(rc<0)return fail(r,QWR_ZERO_ERROR);
  if(rc==0)return 0;
  if((rc=idle(r))!=0)return rc;
  if((rc=rd(r,CORE+0xe0u,&value))!=0)return rc;
  if(value!=0x43500100u)return fail(r,QWR_CHECKPOINT);
  if((rc=wr(r,CORE+0x10u,0))!=0)return rc;
  if((rc=wr(r,CORE+0x14u,1))!=0)return rc;
  if((rc=wr(r,CORE+0x30u,r->max_new))!=0)return rc;
  if((rc=wr(r,CORE+0x34u,1))!=0)return rc;
  r->state=QWR_PROMPT;return 0;
 case QWR_PROMPT:
  if((rc=rd(r,CORE+0x58u,&value))!=0)return rc;
  if(value&8u)return fail(r,QWR_CORE);
  if(!(value&0x20u))return 0;
  value=r->prompt[r->prompt_sent]|((r->prompt_sent+1u==r->prompt_count)?0x10000u:0);
  if((rc=wr(r,CORE+0x38u,value))!=0)return rc;
  if(++r->prompt_sent==r->prompt_count)r->state=QWR_WAIT_DONE;
  return 0;
 case QWR_WAIT_DONE:
  if((rc=rd(r,CORE+0x58u,&value))!=0)return rc;
  if(value&8u)return fail(r,QWR_CORE);
  if(!(value&4u))return 0;
  if(value&3u)return fail(r,QWR_CORE);
  if((rc=rd(r,CORE+0x3cu,&value))!=0)return rc;
  r->result_count=(value>>9)&511u;
  if(!r->result_count||r->result_count>r->max_new||
      (value&255u)!=r->result_count)return fail(r,QWR_RESULT);
  if(qwdet_begin(r->decoder,1,emit,r))return fail(r,QWR_OUTPUT);
  r->state=QWR_DRAIN;return 0;
 case QWR_DRAIN:{
  uint32_t id,position,last,expected_last;
  if((rc=rd(r,CORE+0x58u,&value))!=0)return rc;
  if(value&8u)return fail(r,QWR_CORE);
  if(!(value&0x80u))return 0;
  if((rc=rd(r,CORE+0x40u,&value))!=0)return rc;
  id=value&65535u;position=(value>>16)&1023u;last=(value>>26)&1u;
  expected_last=(id==32451u||id==32453u||r->drained+1u>=r->max_new||position>=512u);
  if(!(value&0x80000000u)||(value&0x78000000u)||id>=65535u||
      position!=r->prompt_count+r->drained||last!=expected_last||
      last!=(r->drained+1u==r->result_count))return fail(r,QWR_RESULT);
  if(qwdet_token(r->decoder,id))return fail(r,QWR_OUTPUT);
  /* POP only after bytes were accepted into the bounded request-owned buffer. */
  if((rc=wr(r,CORE+0x44u,1))!=0)return rc;
  r->drained++;r->saw_last=(uint8_t)last;
  if(last){
   if(qwdet_finish(r->decoder))return fail(r,QWR_OUTPUT);
   if((rc=idle(r))!=0)return rc;
   r->state=QWR_ANSWER_READY;
  }
  return 0;
 }
 case QWR_ANSWER_READY:case QWR_REJECT_READY:return 0;
 case QWR_RELEASE_QUIET:
  if((rc=idle(r))!=0)return rc;
  if((status&255u)!=255u)return 0;
  /* release_ready additionally checks two quiet edges. A rejected command
   * remains a fault; it is never treated as a completed release. */
  if((rc=wr(r,LEASE_CMD,2u))!=0)return rc;
  r->state=QWR_RELEASE_CONFIRM;return 0;
 default:return fail(r,QWR_ARGUMENT);
 }
}
int qwrun_transport_done(qwrun *r,int accepted,uint32_t now){
 if(!r)return QWR_ARGUMENT;
 if(r->state!=QWR_ANSWER_READY&&r->state!=QWR_REJECT_READY)return QWR_NOT_IDLE;
 if(!accepted)return fail(r,QWR_OUTPUT);
 r->deadline=now+r->timeout;r->state=QWR_RELEASE_QUIET;return 0;
}
