#include "qwreply.h"
static void le32(uint8_t *p,uint32_t x){p[0]=(uint8_t)x;p[1]=(uint8_t)(x>>8);p[2]=(uint8_t)(x>>16);p[3]=(uint8_t)(x>>24);}
int qwreply_pack(const qwobs_record *r,const uint8_t *text,size_t bytes,uint8_t p[108]){
 static const uint8_t prefix[8]={'H','I','S','T','O','R','Y',' '};
 size_t i=0;uint32_t used=8,j;
 if(!r||!p||(!text&&bytes)||bytes>73728||!r->sequence||(r->modality!=1&&r->modality!=2))return -1;
 for(j=0;j<108;j++)p[j]=0;
 for(j=0;j<8;j++)p[28+j]=prefix[j];
 while(i<bytes){
  uint32_t cp=text[i++],n=0,min=0;
  if(cp<128){}
  else if(cp>=0xc2&&cp<=0xdf){cp&=31;n=1;min=0x80;}
  else if(cp>=0xe0&&cp<=0xef){cp&=15;n=2;min=0x800;}
  else if(cp>=0xf0&&cp<=0xf4){cp&=7;n=3;min=0x10000;}
  else return -1;
  if(n>bytes-i)return -1;
  for(j=0;j<n;j++){uint32_t v=text[i++];if((v&0xc0)!=0x80)return -1;cp=(cp<<6)|(v&63);}
  if(cp<min||cp>0x10ffff||(cp>=0xd800&&cp<=0xdfff))return -1;
  if(used<80)p[28+used++]=(uint8_t)(cp<128?cp:'?');
 }
 le32(p,0x314e5751u);le32(p+4,1);le32(p+8,4);
 le32(p+12,r->session_or_clip);le32(p+16,r->sequence);le32(p+20,used);
 return 0;
}
