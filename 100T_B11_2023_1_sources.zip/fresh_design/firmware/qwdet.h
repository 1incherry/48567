#ifndef QW_DETOKEN_H
#define QW_DETOKEN_H
#include <stdint.h>
#include <stddef.h>
/* emit must return0 only after accepting the byte. Nonzero is fatal to this
 * request; caller must abort, never retry a partially emitted token. */
typedef int (*qwdet_emit_fn)(void *opaque,uint8_t byte);
enum {QWDET_OK=0,QWDET_BAD_TABLE=-1,QWDET_BAD_ID=-2,QWDET_IO=-3,QWDET_BAD_STATE=-4};
typedef struct {
 const uint8_t *offsets,*flags,*blob;
 uint32_t blob_bytes;
 qwdet_emit_fn emit;
 void *opaque;
 uint8_t pending[4],used,needed,skip_special,active,failed;
} qwdet;
/* Validate once after immutable table is loaded. Does not allocate or copy it. */
int qwdet_init(qwdet *d,const void *table,size_t bytes);
/* Begin a request; replaces prior request state without flushing stale bytes. */
int qwdet_begin(qwdet *d,int skip_special,qwdet_emit_fn emit,void *opaque);
int qwdet_token(qwdet *d,uint32_t id);
/* Flush incomplete trailing UTF8 with one replacement then close request. */
int qwdet_finish(qwdet *d);
void qwdet_abort(qwdet *d);
#endif
