#ifndef QWCHAT_H
#define QWCHAT_H
#include "qwenc.h"
#define QWCHAT_MESSAGE_LIMIT 8u
#define QWCHAT_CONTEXT 512u
#define QWCHAT_MAX_NEW 192u
enum { QWCHAT_SYSTEM=0,QWCHAT_USER=1,QWCHAT_ASSISTANT=2 };
enum { QWCHAT_OK=0,QWCHAT_ARGUMENT=-10,QWCHAT_DELIMITER=-11,
       QWCHAT_RENDER_LIMIT=-12,QWCHAT_CONTEXT_LIMIT=-13 };
typedef struct { uint32_t role; const uint8_t *content; size_t bytes; } qwchat_message;
/* All buffers and encoder workspace are caller-owned. No truncation or heap.
 * The complete rendered prompt must fit the encoder's 4096-byte input limit.
 * IDs are published only on success; written is zero on every failure.
 * This is the existing qwen31.py renderer, not a new chat template. */
int qwchat_prepare(const qwenc *encoder,const qwchat_message *messages,size_t count,
 uint32_t max_new,uint8_t rendered[QWENC_INPUT_LIMIT],size_t *rendered_bytes,
 uint16_t ids[QWCHAT_CONTEXT],size_t *written,qwenc_workspace *work);
#endif
