#ifndef QWOBS_H
#define QWOBS_H
#include <stdint.h>
#include <stddef.h>
/* Observation syntax only. No signature verification, freshness or authority
 * is established by a syntactically valid NTR2/NAR2 body. No MMIO writes. */
typedef struct {
 uint8_t descriptor[28];uint32_t candidate_index,generation,class_id;
 int64_t logit;
} qwobs_roi;
typedef struct {
 uint32_t modality,sequence,source,session_or_clip,frame_or_generation;
 uint32_t runtime_epoch,model_epoch,roi_count,audio_class;
 uint8_t key_session[16];qwobs_roi roi[4];uint32_t audio_logit_bits[12];
} qwobs_record;
/* Accept exactly256 body bytes from64 frozen CSR words, high byte first.
 * Output is published only on success. Caller must ignore output on failure.
 * Matches pinned host parse_report.py syntax, including unused-slot padding. */
int qwobs_decode(const uint8_t *body,size_t bytes,qwobs_record *output);
const char *qwobs_class_name(uint32_t modality,uint32_t class_id);
#endif
