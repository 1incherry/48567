#include "qnth4.h"
#include "qwobs.h"
#include <string.h>
#define BASE 0xc1000000u
static uint32_t be32(const uint8_t*p){return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static uint64_t be64(const uint8_t*p){return (uint64_t)be32(p)<<32|be32(p+4);}
static int pin_read(uint8_t out[32]){
 unsigned i;uint8_t key=0;
 for(i=0;i<32;i++)out[i]=qhroot_pin[i];
 for(i=16;i<32;i++)key|=out[i];
 return be32(out)==0x51485834u&&be32(out+4)==1u&&be32(out+8)&&be32(out+12)&&key?0:QNTH4_PIN_UNAVAILABLE;
}
int qnth4_begin(qnth4_query*q,const hsc_request*r){
 uint8_t pin[32];
 if(!q||!r||r->op!=HSC_QUERY||r->pane||!r->bridge_session||!r->batch_id||!r->nonce||r->image_no<1||r->image_no>100)return QH_ARGUMENT;
 memset(q,0,sizeof *q);
 int rc=pin_read(pin);if(rc)return rc;
 memcpy(q->pin,pin,32);
 q->expected.bridge_session=r->bridge_session;q->expected.batch_id=r->batch_id;q->expected.nonce=r->nonce;q->expected.image_id=r->image_no;
 q->expected.runtime_epoch=be32(pin+8);q->expected.model_epoch=be32(pin+12);memcpy(q->expected.key_session,pin+16,16);
 return 0;
}
int qnth4_accept(qnth4_query*q,const uint8_t b[256],uint32_t kind){
 uint8_t pin[32];nth4_expected expected;nth4_record record;int rc;
 if(!q||!b||kind!=NTH4_HW_KIND||q->complete)return QH_ARGUMENT;
 if(pin_read(pin)||memcmp(pin,q->pin,32))return QNTH4_PIN_MISMATCH;
 if(be32(b)!=0x4e544834u||be32(b+4)!=0x00010002u)return QH_SYNTAX;
 /* Only a different complete request correlation is a stale packet to skip.
  * A malformed/mixed current-query record is a typed failure, never success. */
 if(be64(b+16)!=q->expected.bridge_session||be64(b+24)!=q->expected.batch_id||be64(b+32)!=q->expected.nonce||be32(b+40)!=q->expected.image_id)return QNTH4_STALE;
 expected=q->expected;
 if(!q->locked)expected.slot_generation=be32(b+240);
 rc=nth4_decode(b,256,kind,0,&expected,&record);
 if(rc!=NTH4_OK)return rc==NTH4_CONTEXT?QNTH4_PIN_MISMATCH:QH_SYNTAX;
 rc=nth4_collection_add(&q->collection,&record);
 if(rc==NTH4_DUPLICATE)return QNTH4_PENDING;
 if(rc!=NTH4_OK&&rc!=NTH4_INCOMPLETE)return QH_CHANGED;
 if(!q->locked){q->expected=expected;q->locked=1;}
 if(rc==NTH4_OK){q->complete=1;return 0;}
 return QNTH4_PENDING;
}
typedef struct {uint8_t*p;size_t n,cap;int error;} writer;
static void put(writer*w,const char*s){while(*s){if(w->n>=w->cap){w->error=1;return;}w->p[w->n++]=(uint8_t)*s++;}}
static void number(writer*w,uint32_t x){char a[10];unsigned n=0;do{a[n++]=(char)('0'+x%10u);x/=10u;}while(x);while(n){char s[2]={a[--n],0};put(w,s);}}
static void signed_number(writer*w,int64_t x){
 /* Fixed 64-bit binary-to-decimal conversion, including INT64_MIN. Avoid
  * pulling two general 64-bit division runtimes into the 64KiB MCS image. */
 uint64_t magnitude=(uint64_t)x;uint8_t digits[20]={0};unsigned first;
 if(x<0){put(w,"-");magnitude=(uint64_t)0-magnitude;}
 for(unsigned bit=0;bit<64;bit++){
  unsigned carry=(unsigned)(magnitude>>63);magnitude<<=1;
  for(int j=19;j>=0;j--){unsigned v=digits[j]*2u+carry;carry=v>=10u;digits[j]=(uint8_t)(v-(carry?10u:0u));}
 }
 for(first=0;first<19&&digits[first]==0;first++){}
 for(;first<20;first++){char s[2]={(char)('0'+digits[first]),0};put(w,s);}
}
int qnth4_facts(const qnth4_query*q,uint8_t*dst,size_t cap,size_t*bytes){
 writer w={dst,0,cap,0};uint8_t pin[32];const nth4_record*f;unsigned i,first;
 if(!q||!dst||!bytes||!q->complete||!q->locked)return QH_ARGUMENT;
 if(pin_read(pin)||memcmp(pin,q->pin,32))return QNTH4_PIN_MISMATCH;
 for(first=0;first<4&&!(q->collection.mask&(1u<<first));first++){}
 if(first==4)return QH_SYNTAX;
 f=&q->collection.records[first];
 if(q->collection.mask!=(f->roi_count?((1u<<f->roi_count)-1u):1u))return QH_CHANGED;
 put(&w,"你是FPGA视觉系统助手。依据本次查询完整收集的PL绑定历史识别结果，用中文回答原问题。历史图片不等于当前场景，不据此执行动作。禁止把PS提供的HIS元数据当作这份结果。\n");
 put(&w,"NTH4 protected-history result; image_no=");number(&w,f->image_id);put(&w,";slot_generation=");number(&w,f->slot_generation);put(&w,";capture_generation=");number(&w,f->capture_generation);
 put(&w,";capture_model=");number(&w,f->capture_model_epoch);put(&w,";execution_model=");number(&w,f->exec_model_epoch);put(&w,";report_sequence=");number(&w,f->report_sequence);put(&w,";ROI_count=");number(&w,f->roi_count);put(&w,".\n");
 if(!f->roi_count)put(&w,"NO_TARGET：该次识别没有目标，不能虚构类别。\n");
 for(i=0;i<f->roi_count;i++){
  const nth4_record*r=&q->collection.records[i];const char*label=qwobs_class_name(1,r->class_id);if(!label)return QH_SYNTAX;
  put(&w,"ROI");number(&w,i+1);put(&w,": class_id=");number(&w,r->class_id);put(&w,";label=");put(&w,label);put(&w,";signed_logit=");signed_number(&w,r->logit);put(&w,".\n");
 }
 if(w.error)return QH_ARGUMENT;
 *bytes=w.n;return 0;
}
int qnth4_snapshot(qwsnapshot_io io,uint8_t b[256],uint32_t*k,uint32_t*num){
 uint32_t v,status,first,last,kind,magic;
 if(!io.read32||!io.write32||!b||!k||!num)return QH_ARGUMENT;
 if(io.read32(io.opaque,BASE,&v))return QH_IO;
 if(v!=0x4e545232u)return QH_ABI;
 if(io.read32(io.opaque,BASE+0xa8,&v))return QH_IO;
 if(v!=0x4e540001u)return QH_ABI;
 if(io.read32(io.opaque,BASE+4,&status))return QH_IO;
 if(status&32u)return QH_STATUS;
 if(io.write32(io.opaque,BASE+0x10,2)||io.read32(io.opaque,BASE+0x18,&v))return QH_IO;
 if(!v)return QH_UNAVAILABLE;
 if(v!=1u)return QH_STATUS;
 if(io.read32(io.opaque,BASE+4,&status))return QH_IO;
 if((status&34u)!=2u)return QH_STATUS;
 if(io.read32(io.opaque,BASE+0x1c,&kind)||io.read32(io.opaque,BASE+0xc,&first))return QH_IO;
 if(kind!=1&&kind!=2&&kind!=3&&kind!=5)return QH_SYNTAX;
 for(unsigned i=0;i<64;i++){if(io.read32(io.opaque,BASE+0x100+i*4,&v))return QH_IO;for(unsigned j=0;j<4;j++)b[4*i+j]=(uint8_t)(v>>(24-8*j));}
 if(io.read32(io.opaque,BASE+0xc,&last)||io.read32(io.opaque,BASE+4,&status))return QH_IO;
 if(first!=last||(status&34u)!=2u)return QH_CHANGED;
 if(io.read32(io.opaque,BASE+0x1c,&v))return QH_IO;
 if(v!=kind)return QH_CHANGED;
 magic=be32(b);
 if(magic!=(kind==1?0x4e545232u:kind==2?0x4e415232u:kind==3?0x48495331u:0x4e544834u)&&!(kind==3&&magic==0x484e4131u))return QH_SYNTAX;
 *k=kind;*num=first;return 0;
}
