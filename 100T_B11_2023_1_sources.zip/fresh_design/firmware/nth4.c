#include "nth4.h"
#include <string.h>
static uint32_t b32(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static uint64_t b64(const uint8_t *p){return ((uint64_t)b32(p)<<32)|b32(p+4);}
static int nonzero(const uint8_t *p,size_t n){size_t i;for(i=0;i<n;i++)if(p[i])return 1;return 0;}
int nth4_decode(const uint8_t *p,size_t n,uint32_t kind,int bad,
 const nth4_expected *e,nth4_record *out){
 nth4_record r;uint32_t flags,x0,x1,y0,y1;uint64_t bits;
 if(!p||!e||!out||n!=NTH4_BYTES)return NTH4_ARGUMENT;
 if(kind!=NTH4_HW_KIND||bad!=0)return NTH4_ORIGIN;
 if(!e->bridge_session||!e->batch_id||!e->nonce||e->image_id<1||e->image_id>100||
    !e->slot_generation||!e->runtime_epoch||!e->model_epoch||!nonzero(e->key_session,16))return NTH4_ARGUMENT;
 if(b32(p)!=0x4e544834u||b32(p+4)!=0x00010002u||b32(p+8)!=256||nonzero(p+248,8))return NTH4_SYNTAX;
 flags=b32(p+12);
 if(flags!=11u&&flags!=15u)return NTH4_SYNTAX;
 if(b64(p+16)!=e->bridge_session||b64(p+24)!=e->batch_id||b64(p+32)!=e->nonce||b32(p+40)!=e->image_id)return NTH4_CONTEXT;
 memset(&r,0,sizeof r);
 r.image_id=b32(p+40);r.slot_generation=b32(p+240);r.exec_model_epoch=b32(p+244);r.slot=b32(p+44);r.roi_count=b32(p+48);r.report_sequence=b32(p+52);
 r.camera_id=b32(p+56);r.capture_session=b32(p+60);r.capture_frame=b32(p+64);
 r.capture_epoch=b32(p+68);r.capture_model_epoch=b32(p+72);r.capture_generation=b32(p+76);
 memcpy(r.capture_key_session,p+80,16);
 r.exec_camera=b32(p+96);r.exec_session=b32(p+100);r.exec_frame=b32(p+104);
 r.exec_epoch=b32(p+108);r.exec_generation=b32(p+112);memcpy(r.exec_key_session,p+116,16);
 memcpy(r.descriptor,p+132,28);r.candidate_index=b32(p+160);r.class_id=b32(p+164);
 bits=b64(p+168);memcpy(&r.logit,&bits,8);
 memcpy(r.image_sha256,p+176,32);memcpy(r.result_sha256,p+208,32);
 if(!r.report_sequence||!r.capture_session||!r.capture_frame||!r.capture_generation||
    !r.exec_session||!r.exec_frame||r.roi_count>4||r.exec_camera!=r.camera_id||
    !nonzero(r.image_sha256,32)||!nonzero(r.result_sha256,32))return NTH4_SYNTAX;
 if(!r.capture_epoch||!r.capture_model_epoch||!nonzero(r.capture_key_session,16))return NTH4_SYNTAX;
 if(r.slot_generation!=e->slot_generation||r.exec_epoch!=e->runtime_epoch||r.exec_model_epoch!=e->model_epoch||
    memcmp(r.exec_key_session,e->key_session,16))return NTH4_CONTEXT;
 if(r.roi_count==0){
  if(flags!=15||r.slot||r.exec_generation||nonzero(p+132,44))return NTH4_SYNTAX;
 }else{
  if(flags!=11||r.slot>=r.roi_count||!r.exec_generation||r.candidate_index>=6300||r.class_id>=105)return NTH4_SYNTAX;
  /* Same packed ROI layout as the existing 224-bit PL descriptor. */
  x0=((uint32_t)p[138]<<8)|p[139];x1=((uint32_t)p[136]<<8)|p[137];
  y0=((uint32_t)p[134]<<8)|p[135];y1=((uint32_t)p[132]<<8)|p[133];
  if(x0>=x1||x1>640||y0>=y1||y1>480)return NTH4_SYNTAX;
 }
 *out=r;return NTH4_OK;
}
void nth4_collection_init(nth4_collection *c){if(c)memset(c,0,sizeof *c);}
int nth4_collection_add(nth4_collection *c,const nth4_record *r){
 uint32_t wanted,bit;const nth4_record *f;unsigned first;
 if(!c||!r||r->roi_count>4||r->slot>=4||!r->report_sequence)return NTH4_ARGUMENT;
 wanted=r->roi_count?((1u<<r->roi_count)-1u):1u;bit=1u<<r->slot;
 if(!(wanted&bit))return NTH4_SYNTAX;
 if(c->mask){
  for(first=0;first<4&&!(c->mask&(1u<<first));first++){}
  if(first==4)return NTH4_CONTEXT;
  f=&c->records[first];
  if(c->count!=r->roi_count||c->report_sequence!=r->report_sequence||f->image_id!=r->image_id||f->slot_generation!=r->slot_generation||
     f->camera_id!=r->camera_id||f->capture_session!=r->capture_session||f->capture_frame!=r->capture_frame||
     f->capture_epoch!=r->capture_epoch||f->capture_generation!=r->capture_generation||f->capture_model_epoch!=r->capture_model_epoch||f->exec_model_epoch!=r->exec_model_epoch||
     f->exec_camera!=r->exec_camera||f->exec_session!=r->exec_session||f->exec_frame!=r->exec_frame||
     f->exec_epoch!=r->exec_epoch||memcmp(f->capture_key_session,r->capture_key_session,16)||
     memcmp(f->exec_key_session,r->exec_key_session,16)||memcmp(f->image_sha256,r->image_sha256,32)||
     memcmp(f->result_sha256,r->result_sha256,32))return NTH4_CONTEXT;
 }
 if(c->mask&bit)return NTH4_DUPLICATE;
 c->records[r->slot]=*r;c->mask|=bit;c->count=r->roi_count;c->report_sequence=r->report_sequence;
 return c->mask==wanted?NTH4_OK:NTH4_INCOMPLETE;
}
