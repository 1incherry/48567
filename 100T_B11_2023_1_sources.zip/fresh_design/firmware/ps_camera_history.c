#include "ps_camera_history.h"
#include <string.h>
#include <stdio.h>
#include <inttypes.h>
#include <limits.h>
#include <stdarg.h>

static int same_id(const psh_identity *a,const psh_identity *b) {
    return a&&b&&a->camera==b->camera&&a->session==b->session&&a->frame==b->frame&&
        a->runtime_epoch==b->runtime_epoch&&a->model_epoch==b->model_epoch;
}
static int overlap(const void *a,size_t an,const void *b,size_t bn) {
    uintptr_t x=(uintptr_t)a,y=(uintptr_t)b;
    if(x>UINTPTR_MAX-an||y>UINTPTR_MAX-bn)return 1;
    return x<y+bn&&y<x+an;
}
size_t psh_storage_required(unsigned cap) {
    if(!cap)cap=PSH_DEFAULT_CAPACITY;
    return cap<=PSH_MAX_SLOTS?(size_t)cap*PSH_RAW_BYTES:0;
}
psh_rc psh_init(psh_history *h,void *storage,size_t bytes,unsigned cap,uint64_t batch_id) {
    size_t need=psh_storage_required(cap);
    if(!h||!storage||!need||bytes<need||!batch_id||
       (uintptr_t)storage>UINTPTR_MAX-need)return PSH_ARGUMENT;
    memset(h,0,sizeof(*h));h->storage=storage;h->storage_bytes=need;
    h->capacity=cap?cap:PSH_DEFAULT_CAPACITY;h->batch_id=batch_id;return PSH_OK;
}
uint32_t psh_crc32(const void *p,size_t n) {
    const uint8_t *a=p;uint32_t c=UINT32_MAX;size_t i;unsigned j;
    for(i=0;i<n;++i){c^=a[i];for(j=0;j<8;++j)c=(c>>1)^((c&1)?UINT32_C(0xedb88320):0);}
    return ~c;
}
const psh_slot *psh_lookup(const psh_history *h,psh_ticket t) {
    if(!h||t.batch_id!=h->batch_id||t.slot>=h->capacity)return NULL;
    const psh_slot *s=&h->slots[t.slot];
    return s->valid&&s->generation==t.generation?s:NULL;
}
static psh_slot *slot(psh_history *h,psh_ticket t){return (psh_slot *)psh_lookup(h,t);}
static int terminal(const psh_slot *s) {
    return s->state==PSH_CLASSIFIED||s->state==PSH_NO_TARGET||s->state==PSH_FAILED;
}
psh_rc psh_push(psh_history *h,const psh_identity *id,const uint8_t *rgb,
                size_t bytes,psh_ticket *out) {
    if(!h||!h->storage||!id||!id->session||!id->frame||!id->runtime_epoch||
       !rgb||bytes!=PSH_RAW_BYTES||!out||overlap(rgb,bytes,h->storage,h->storage_bytes))return PSH_ARGUMENT;
    if(h->last_generation==UINT64_MAX||h->last_image_no==UINT32_MAX)return PSH_EXHAUSTED;
    if(h->count>=h->capacity)return PSH_FULL;
    unsigned i,index=h->count;psh_slot *s=&h->slots[index];
    for(i=0;i<h->capacity;++i)if(h->slots[i].valid&&same_id(&h->slots[i].id,id))return PSH_STATE;
    if(s->valid&&(!terminal(s)||!s->archived||s->nn_leases||s->export_leases||s->query_leases||s->display_leases))return PSH_BUSY;
    uint8_t *dst=h->storage+(size_t)index*PSH_RAW_BYTES;
    memcpy(dst,rgb,PSH_RAW_BYTES);memset(s,0,sizeof(*s));s->valid=1;s->id=*id;
    s->generation=++h->last_generation;s->batch_id=h->batch_id;s->image_no=++h->last_image_no;
    s->raw_crc32=psh_crc32(dst,PSH_RAW_BYTES);s->state=PSH_YOLO_PENDING;
    ++h->count;
    if(h->count<=PSH_PANES&&!h->selected[h->count-1])h->selected[h->count-1]=s->image_no;
    out->slot=index;out->generation=s->generation;out->batch_id=s->batch_id;return PSH_OK;
}
psh_rc psh_acquire(psh_history *h,psh_ticket t,psh_lease_role role,const uint8_t **rgb) {
    psh_slot *s=slot(h,t);if(!s)return PSH_STALE;
    if(!rgb||(role!=PSH_NN_LEASE&&role!=PSH_EXPORT_LEASE&&role!=PSH_QUERY_LEASE))return PSH_ARGUMENT;
    uint16_t *n=role==PSH_NN_LEASE?&s->nn_leases:role==PSH_EXPORT_LEASE?&s->export_leases:&s->query_leases;
    if(*n==UINT16_MAX)return PSH_EXHAUSTED;
    ++*n;*rgb=h->storage+(size_t)t.slot*PSH_RAW_BYTES;return PSH_OK;
}
psh_rc psh_release(psh_history *h,psh_ticket t,psh_lease_role role) {
    psh_slot *s=slot(h,t);if(!s)return PSH_STALE;
    if(role!=PSH_NN_LEASE&&role!=PSH_EXPORT_LEASE&&role!=PSH_QUERY_LEASE)return PSH_ARGUMENT;
    uint16_t *n=role==PSH_NN_LEASE?&s->nn_leases:role==PSH_EXPORT_LEASE?&s->export_leases:&s->query_leases;
    if(!*n)return PSH_STATE;
    --*n;return PSH_OK;
}
psh_rc psh_query(psh_history *h,uint64_t batch,uint32_t image,psh_ticket *t,psh_slot *snapshot,const uint8_t **rgb) {
    if(!h||!t||!snapshot||!rgb||!image)return PSH_ARGUMENT;
    if(batch!=h->batch_id)return PSH_NOT_FOUND;
    unsigned i;for(i=0;i<h->capacity;++i)if(h->slots[i].valid&&h->slots[i].image_no==image){
        psh_ticket found={i,h->slots[i].generation,h->batch_id};
        psh_rc rc=psh_acquire(h,found,PSH_QUERY_LEASE,rgb);if(rc!=PSH_OK)return rc;
        *t=found;*snapshot=h->slots[i];return PSH_OK;
    }
    return PSH_NOT_FOUND;
}
static int pane_index(unsigned pane){return pane==1?0:pane==3?1:pane==4?2:-1;}
psh_rc psh_select_image(psh_history *h,uint64_t batch,uint32_t image,unsigned pane) {
    int p=pane_index(pane);
    if(!h||!image||p<0)return PSH_ARGUMENT;
    if(batch!=h->batch_id||image>h->count)return PSH_NOT_FOUND;
    if(h->pending.phase!=PSH_VIEW_NONE)return PSH_BUSY;
    if(!h->slots[image-1].valid||h->slots[image-1].image_no!=image)return PSH_NOT_FOUND;
    h->selected[p]=image;return PSH_OK;
}
psh_rc psh_archive_confirm(psh_history *h,psh_ticket t,const psh_identity *id,uint32_t crc,const uint8_t sha[32]) {
    psh_slot *s=slot(h,t);if(!s||!same_id(&s->id,id))return PSH_STALE;
    if(!sha||!s->export_leases)return PSH_STATE;
    if(crc!=s->raw_crc32)return PSH_CRC;
    unsigned i,nonzero=0;for(i=0;i<32;++i)nonzero|=sha[i];if(!nonzero)return PSH_ARGUMENT;
    if(s->archived)return PSH_STATE;
    memcpy(s->archive_sha256,sha,32);s->archived=1;return PSH_OK;
}
psh_rc psh_yolo_result(psh_history *h,psh_ticket t,const psh_identity *id,const psh_roi *rois,unsigned count) {
    psh_slot *s=slot(h,t);unsigned i;if(!s||!same_id(&s->id,id))return PSH_STALE;
    if(s->state!=PSH_YOLO_PENDING||!s->nn_leases)return PSH_STATE;
    if(count>PSH_MAX_ROIS||(count&&!rois))return PSH_ARGUMENT;
    for(i=0;i<count;++i)if(rois[i].x0>=rois[i].x1||rois[i].y0>=rois[i].y1||rois[i].x1>PSH_WIDTH||rois[i].y1>PSH_HEIGHT)return PSH_ARGUMENT;
    s->roi_count=(uint8_t)count;for(i=0;i<count;++i)s->rois[i].box=rois[i];
    s->state=count?PSH_VIT_PENDING:PSH_NO_TARGET;return PSH_OK;
}
psh_rc psh_roi_classified(psh_history *h,psh_ticket t,const psh_identity *id,unsigned roi,
                          uint32_t class_id,int64_t logit,uint32_t record) {
    psh_slot *s=slot(h,t);unsigned i;if(!s||!same_id(&s->id,id))return PSH_STALE;
    if(s->state!=PSH_VIT_PENDING||!s->nn_leases||roi>=s->roi_count||s->rois[roi].done)return PSH_STATE;
    if(class_id>=PSH_VIT_CLASSES||!record)return PSH_ARGUMENT;
    s->rois[roi].class_id=class_id;s->rois[roi].best_logit=logit;s->rois[roi].record_sequence=record;s->rois[roi].done=1;
    for(i=0;i<s->roi_count;++i)if(!s->rois[i].done)return PSH_OK;
    s->state=PSH_CLASSIFIED;return PSH_OK;
}
psh_rc psh_job_error(psh_history *h,psh_ticket t,const psh_identity *id,uint32_t error) {
    psh_slot *s=slot(h,t);if(!s||!same_id(&s->id,id))return PSH_STALE;
    if(terminal(s))return PSH_STATE;
    if(!error)return PSH_ARGUMENT;
    s->state=PSH_FAILED;s->error_code=error;return PSH_OK;
}
psh_rc psh_rotate(psh_history *h,unsigned pane) {
    int p=pane_index(pane);if(!h||p<0)return PSH_ARGUMENT;
    if(h->pending.phase!=PSH_VIEW_NONE)return PSH_BUSY;
    if(!h->count)return PSH_NOT_FOUND;
    h->selected[p]=h->selected[p]%h->count+1;return PSH_OK;
}
static void drop_view(psh_history *h,psh_view *v) {
    unsigned i;for(i=0;i<PSH_PANES;++i)if(v->present[i]){
        psh_slot *s=slot(h,v->ticket[i]);if(s&&s->display_leases)--s->display_leases;
    }
    memset(v,0,sizeof(*v));
}
psh_rc psh_display_prepare(psh_history *h) {
    if(!h)return PSH_ARGUMENT;
    if(h->pending.phase!=PSH_VIEW_NONE)return PSH_BUSY;
    psh_view *v=&h->pending;unsigned i;
    for(i=0;i<PSH_PANES;++i)if(h->selected[i]){
        unsigned k=h->selected[i]-1;
        if(k>=h->count){drop_view(h,v);return PSH_STATE;}
        if(!h->slots[k].valid||h->slots[k].display_leases==UINT16_MAX){drop_view(h,v);return PSH_STATE;}
        ++h->slots[k].display_leases;v->present[i]=1;v->ticket[i]=(psh_ticket){k,h->slots[k].generation,h->batch_id};v->snapshot[i]=h->slots[k];
    }
    v->phase=PSH_VIEW_PREPARED;return PSH_OK;
}
psh_rc psh_display_cancel_prepared(psh_history *h) {
    if(!h||h->pending.phase!=PSH_VIEW_PREPARED)return PSH_STATE;
    drop_view(h,&h->pending);return PSH_OK;
}
psh_rc psh_display_submit(psh_history *h,uint32_t sequence,unsigned buffer_tag,uint32_t actual_before_ack) {
    if(!h||h->pending.phase!=PSH_VIEW_PREPARED)return PSH_STATE;
    if(!sequence||buffer_tag>1||sequence<=actual_before_ack||sequence<=h->last_display_sequence)return PSH_ARGUMENT;
    if(h->current.phase==PSH_VIEW_CURRENT&&buffer_tag==h->current.buffer_tag)return PSH_ARGUMENT;
    h->last_display_sequence=sequence;h->pending.phase=PSH_VIEW_SUBMITTED;h->pending.sequence=sequence;h->pending.buffer_tag=(uint8_t)buffer_tag;return PSH_OK;
}
psh_rc psh_display_observe(psh_history *h,uint32_t ack,unsigned buffer_tag,uint32_t frames,int error) {
    if(!h)return PSH_ARGUMENT;
    psh_view *v=&h->pending;
    if(v->phase!=PSH_VIEW_SUBMITTED&&v->phase!=PSH_VIEW_GUARD)return PSH_STATE;
    if(error){v->phase=PSH_VIEW_FAILED;return PSH_DISPLAY_ERROR;}
    if(v->phase==PSH_VIEW_SUBMITTED){
        if(ack!=v->sequence||buffer_tag!=v->buffer_tag)return PSH_BUSY;
        v->phase=PSH_VIEW_GUARD;v->anchor=frames;return PSH_BUSY;
    }
    if(ack!=v->sequence||buffer_tag!=v->buffer_tag){v->phase=PSH_VIEW_FAILED;return PSH_DISPLAY_ERROR;}
    if(!v->boundary_seen){if(frames!=v->anchor){v->boundary_seen=1;v->boundary=frames;}return PSH_BUSY;}
    if((uint32_t)(frames-v->boundary)<2)return PSH_BUSY;
    drop_view(h,&h->current);h->current=*v;h->current.phase=PSH_VIEW_CURRENT;memset(v,0,sizeof(*v));return PSH_PRESENTED;
}
psh_rc psh_display_release_after_drain(psh_history *h,int idle) {
    if(!h)return PSH_ARGUMENT;
    if(!idle)return PSH_BUSY;
    drop_view(h,&h->pending);drop_view(h,&h->current);return PSH_OK;
}
psh_rc psh_caption(const psh_slot *s,char *a,size_t na,char *b,size_t nb) {
    if(!s||!s->valid||!a||!b||!na||!nb)return PSH_ARGUMENT;
    int x=snprintf(a,na,"HISTORY B%016"PRIX64" I%02"PRIu32" C%08"PRIX32" F%08"PRIX32" E%08"PRIX32,
        s->batch_id,s->image_no,s->id.camera,s->id.frame,s->id.runtime_epoch),y;
    if(s->state==PSH_YOLO_PENDING)y=snprintf(b,nb,"PENDING YOLO");
    else if(s->state==PSH_NO_TARGET)y=snprintf(b,nb,"YOLO NO TARGET");
    else if(s->state==PSH_FAILED)y=snprintf(b,nb,"JOB ERROR %08"PRIX32,s->error_code);
    else if(s->state==PSH_VIT_PENDING){unsigned i,done=0;for(i=0;i<s->roi_count;++i)done+=s->rois[i].done?1u:0u;y=snprintf(b,nb,"PENDING VIT %u/%u",done,s->roi_count);}
    else if(s->state==PSH_CLASSIFIED){
        size_t used=0;unsigned i;for(i=0;i<s->roi_count;++i){int n=snprintf(b+used,nb-used,"%sR%u CLASS%03"PRIu32,i?" ":"",i,s->rois[i].class_id);if(n<0||(size_t)n>=nb-used)return PSH_ARGUMENT;used+=(size_t)n;}y=(int)used;
    }else return PSH_STATE;
    return x>=0&&(size_t)x<na&&y>=0&&(size_t)y<nb?PSH_OK:PSH_ARGUMENT;
}
static int append(char *out,size_t cap,size_t *used,const char *fmt,...) {
    if(*used>=cap)return 0;
    va_list args;va_start(args,fmt);int n=vsnprintf(out+*used,cap-*used,fmt,args);va_end(args);
    if(n<0||(size_t)n>=cap-*used)return 0;
    *used+=(size_t)n;return 1;
}
psh_rc psh_context_json(const psh_slot *s,char *out,size_t cap,size_t *written) {
    if(written)*written=0;
    if(!s||!s->valid||!out||!cap||!written)return PSH_ARGUMENT;
    const char *state=s->state==PSH_YOLO_PENDING?"YOLO_PENDING":s->state==PSH_VIT_PENDING?"VIT_PENDING":
        s->state==PSH_NO_TARGET?"NO_TARGET":s->state==PSH_CLASSIFIED?"CLASSIFIED":s->state==PSH_FAILED?"ERROR":NULL;
    if(!state||s->roi_count>PSH_MAX_ROIS)return PSH_STATE;
    size_t used=0;unsigned i;
    if(!append(out,cap,&used,"{\"display_only\":true,\"batch_id\":\"%016"PRIx64"\",\"image_no\":%"PRIu32
        ",\"camera_id\":%"PRIu32",\"session_id\":%"PRIu32",\"frame_id\":%"PRIu32
        ",\"runtime_epoch\":%"PRIu32",\"model_epoch\":%"PRIu32",\"raw_crc32\":\"%08"PRIx32
        "\",\"state\":\"%s\",\"error_code\":%"PRIu32",\"rois\":[",
        s->batch_id,s->image_no,s->id.camera,s->id.session,s->id.frame,s->id.runtime_epoch,s->id.model_epoch,s->raw_crc32,state,s->error_code))return PSH_ARGUMENT;
    for(i=0;i<s->roi_count;++i){const psh_roi_result *r=&s->rois[i];
        if(!append(out,cap,&used,"%s{\"roi\":%u,\"box\":[%u,%u,%u,%u],\"class_id\":",i?",":"",i,r->box.x0,r->box.y0,r->box.x1,r->box.y1))return PSH_ARGUMENT;
        if(r->done){if(!append(out,cap,&used,"%"PRIu32",\"best_logit\":\"%"PRId64"\",\"record_sequence\":%"PRIu32"}",r->class_id,r->best_logit,r->record_sequence))return PSH_ARGUMENT;}
        else if(!append(out,cap,&used,"null,\"best_logit\":null,\"record_sequence\":null}"))return PSH_ARGUMENT;
    }
    if(!append(out,cap,&used,"]}"))return PSH_ARGUMENT;
    *written=used;return PSH_OK;
}
