#ifndef QNTH4_H
#define QNTH4_H
#include "qhistory.h"
#include "nth4.h"
extern const volatile uint8_t qhroot_pin[32];
enum {QNTH4_PENDING=1,QNTH4_STALE=2,QNTH4_PIN_UNAVAILABLE=-310,QNTH4_PIN_MISMATCH=-311};
typedef struct {
 nth4_expected expected;
 nth4_collection collection;
 uint8_t pin[32],locked,complete;
} qnth4_query;
/* Each request owns this private collector until completion/typed failure.
 * The only dynamic first-packet field is the protected slot generation.
 * Execution epoch/model/key are independently pinned in local firmware. */
int qnth4_begin(qnth4_query *,const hsc_request *);
int qnth4_accept(qnth4_query *,const uint8_t[256],uint32_t actual_hw_kind);
int qnth4_facts(const qnth4_query *,uint8_t *,size_t,size_t *);
/* Exact held-CSR snapshot protocol, extended solely for hardware kind5. */
int qnth4_snapshot(qwsnapshot_io,uint8_t[256],uint32_t *,uint32_t *);
#endif
