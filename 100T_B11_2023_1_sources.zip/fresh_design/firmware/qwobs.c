#include "qwobs.h"
#include "qwobs_labels.h"
static uint32_t be32(const uint8_t *p){
 return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];
}
static int any(const uint8_t *p,size_t bytes){
 size_t i;for(i=0;i<bytes;i++)if(p[i])return 1;return 0;
}
static void copy(uint8_t *dst,const uint8_t *src,size_t bytes){
 size_t i;for(i=0;i<bytes;i++)dst[i]=src[i];
}
int qwobs_decode(const uint8_t *body,size_t bytes,qwobs_record *output){
 qwobs_record record={0};uint32_t magic,i;
 if(!body||!output||bytes!=256)return -1;
 magic=be32(body);record.sequence=be32(body+8);record.source=be32(body+12);
 record.session_or_clip=be32(body+16);record.frame_or_generation=be32(body+20);
 record.runtime_epoch=be32(body+24);copy(record.key_session,body+32,16);
 if(magic==0x4e545232u){
  if(be32(body+4)!=0x00020001u||!record.sequence||be32(body+28)>4||any(body+232,24))return -1;
  record.modality=1;record.roi_count=be32(body+28);
  for(i=0;i<4;i++){
   const uint8_t *descriptor=body+48+i*28,*value=body+168+i*16;
   qwobs_roi *roi=record.roi+i;
   uint32_t index=((uint32_t)body[160+i*2]<<8)|body[161+i*2];
   if(i>=record.roi_count){
    if(any(descriptor,28)||index||any(value,16))return -1;
    continue;
   }
   if(!be32(value)||value[4]>=105||any(value+5,3)||index>=6300)return -1;
   copy(roi->descriptor,descriptor,28);roi->candidate_index=index;
   roi->generation=be32(value);roi->class_id=value[4];
   roi->logit=(int64_t)(((uint64_t)be32(value+8)<<32)|be32(value+12));
  }
 }else if(magic==0x4e415232u){
  if(be32(body+4)!=0x00020002u||!record.sequence||!record.session_or_clip||
    !record.frame_or_generation||!record.runtime_epoch||!be32(body+28)||
    !any(body+32,16)||be32(body+48)>=12||be32(body+52)!=12||
    be32(body+56)!=16000||be32(body+60)!=3920||any(body+112,144))return -1;
  record.modality=2;record.model_epoch=be32(body+28);record.audio_class=be32(body+48);
  for(i=0;i<12;i++){
   uint32_t bits=be32(body+64+i*4);
   if(((bits>>23)&255u)==255u)return -1;
   record.audio_logit_bits[i]=bits;
  }
 }else return -1;
 *output=record;return 0;
}
const char *qwobs_class_name(uint32_t modality,uint32_t class_id){
 if(modality==1&&class_id<105)return qwobs_visual_labels[class_id];
 if(modality==2&&class_id<12)return qwobs_audio_labels[class_id];
 return 0;
}
