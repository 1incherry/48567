#ifndef HISTORY_HNA1_H
#define HISTORY_HNA1_H
#include "history_control.h"
enum { HNA_OK=0,HNA_NOT_STORED=1,HNA_ARGUMENT=-400,
       HNA_FORMAT=-401,HNA_MAC=-402,HNA_STALE=-403 };
#define HNA_BODY_BYTES 256u
#define HNA_FRAME_BYTES 270u
/* Display/history data only, never a PL authenticator. An encode call does
 * not establish that a slot is absent: the PS dispatcher must atomically
 * establish absence before calling, and hold the command until real TXdrain.
 * No function here reads MMIO, creates a lease, acknowledges consumption,
 * runs Qwen, or retires a command. */
int hna_pack_body(const hsc_request *,uint8_t out[HNA_BODY_BYTES]);
int hna_pack_frame(const hsc_request *,uint8_t out[HNA_FRAME_BYTES]);
/* actual_mac_bad must come from the actual MAC/parser, not a synthesized
 * CRC success. Body parser is only for an actually frozen HNA1 CSR body.
 * A return of NOT_STORED is explicitly PS_UNTRUSTED, not authenticated fact.
 * A caller may finish only the exact outstanding command after actual HST TX
 * and temporary DDR lease release; never emit HSC or prefill for HNA. */
int hna_decode_body(const uint8_t *,size_t,int actual_mac_bad,
                    const hsc_request *outstanding);
int hna_decode_frame(const uint8_t *,size_t,int actual_mac_bad,
                     const hsc_request *outstanding);
#endif
