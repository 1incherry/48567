#ifndef HISTORY_CONTROL_H
#define HISTORY_CONTROL_H
#include "ps_camera_history.h"
#define HSC_REQUEST_BYTES 48u
typedef enum { HSC_QUERY=1,HSC_SELECT=2 } hsc_op;
typedef enum { HSC_IDLE=0,HSC_QUERY_HELD,HSC_SELECT_PREPARED,
 HSC_SELECT_SUBMITTED,HSC_SELECT_PRESENTED,HSC_LOCKED_ERROR } hsc_phase;
typedef enum { HSC_OK=0,HSC_WIRE,HSC_REPLAY,HSC_SESSION,HSC_BUSY,
 HSC_HISTORY,HSC_ARGUMENT,HSC_NOT_PRESENTED,HSC_ERROR } hsc_rc;
typedef struct {
 uint64_t bridge_session,nonce,batch_id;
 uint32_t image_no;
 uint8_t op,pane;
} hsc_request;
typedef struct {
 psh_history *history;
 uint64_t bridge_session,last_nonce;
 hsc_phase phase;
 hsc_request active;
 psh_ticket query_ticket;
 psh_slot snapshot;
 const uint8_t *query_raw;
 psh_rc history_result;
} hsc_bridge;
/* Display-only PS protocol, never a PL authenticator or a Qwen answer.
 * Caller serializes calls and supplies a durably unique bridge_session on each
 * external resynchronization. It is NOT a PL key_session_id. No auto-reset,
 * timeout replay, pointer/MMIO argument, direct memory access or free-form verb.
 * Frame boundaries belong to the transport: accept exactly one complete48B.
 * Invalid framing/CRC must not be assembled with a later packet by the caller.
 */
hsc_rc hsc_decode(const uint8_t *,size_t,hsc_request *);
hsc_rc hsc_encode(const hsc_request *,uint8_t *,size_t);
hsc_rc hsc_init(hsc_bridge *,psh_history *,uint64_t bridge_session);
/* Well-formed matching-session nonce is consumed even on semantic rejection.
 * Only one command may be held. Busy does not trigger retries or drop leases. */
hsc_rc hsc_accept(hsc_bridge *,const uint8_t *,size_t);
/* QUERY holds source QUERY lease until exact nonce consumption. */
hsc_rc hsc_query_context(hsc_bridge *,uint64_t nonce,char *,size_t,size_t *);
hsc_rc hsc_response_json(const hsc_bridge *,uint64_t nonce,char *,size_t,size_t *);
hsc_rc hsc_query_release(hsc_bridge *,uint64_t nonce);
/* SELECT PREPARED can now be rendered with psh_render into actual inactive FB.
 * submit takes real precommit ACK and issued sequence from actual driver.
 * No completion until actual ACK/tag, fresh boundary and two whole frames.
 */
hsc_rc hsc_select_submit(hsc_bridge *,uint64_t nonce,uint32_t issued_seq,
 unsigned actual_buffer_tag,uint32_t actual_before_ack);
hsc_rc hsc_select_observe(hsc_bridge *,uint32_t actual_ack,unsigned actual_tag,
 uint32_t actual_frames,int actual_underflow_or_axi_error);
hsc_rc hsc_select_complete(hsc_bridge *,uint64_t nonce);
hsc_rc hsc_cancel_prepared(hsc_bridge *,uint64_t nonce);
/* Locked display error retains leases until actual hardware drain. This does
 * not reset nonce/session or certify that caller supplied a truthful idle. */
hsc_rc hsc_release_after_drain(hsc_bridge *,int actual_stream_idle);
#endif
