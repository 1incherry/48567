#include <stdint.h>
#include <stddef.h>
#include "qwrun.h"
#include "qwframe.h"
#include "qwmem.h"
#include "qwuart_regs.h"
#include "qwsnapshot.h"
#include "qwfacts.h"
#include "qwenglish.h"
#include "qwreply.h"
#include "qweth.h"
#include "qhistory.h"
#include "qhint.h"
#include "hna1.h"
#ifndef QW_ENABLE_NTH4
#define QW_ENABLE_NTH4 0
#endif
#ifndef QW_QUERY_FIRST_SELECT
#define QW_QUERY_FIRST_SELECT 0
#endif
#ifndef QW_NTH4_SELECT_REARM
#define QW_NTH4_SELECT_REARM 0
#endif
#if QW_NTH4_SELECT_REARM && (!QW_ENABLE_NTH4 || !QW_QUERY_FIRST_SELECT)
#error NTH4_select_rearm_requires_query_first_pinned_NTH4
#endif
#if QW_QUERY_FIRST_SELECT && !QW_ENABLE_NTH4
#error Query_first_select_requires_the_independent_pinned_NTH4_consumer
#endif
#if QW_ENABLE_NTH4
#include "qnth4.h"
#define selected_snapshot qnth4_snapshot
static int trusted_history_complete,trusted_history_failed;
#else
#define selected_snapshot qh_snapshot
#endif
#define HISTORY_NOT_STORED 1
#define HISTORY_UNAVAILABLE_STATUS (-308)
/* Actual UART application candidate, not a token/mock fixture. No inference
 * outputs are manufactured here. All kind1 bytes originate in qwrun's real
 * token FIFO path. This ELF is link-only until actual MCS/peripheral execution. */
#define BRIDGE_STATUS 0xc2000000u
#define BRIDGE_ABI 0xc200000cu
#define LEASE 0x41000030u
#define LEASE_CMD 0x41000034u
static qwenc encoder;static qwdet decoder;static qwrun runner;
#if QW_ENABLE_NTH4
static uint8_t input[4096],status_payload[20],observation_body[256],last_auto_body[256],reply_payload[108];
#else
static uint8_t input[4096],status_payload[20],observation_body[256],facts[1536],last_auto_body[256],reply_payload[108];
#endif
#define QW_FACTS_BYTES 1536u
static int have_auto_body,auto_conflict_reported;
static qh_config history_config;static int history_config_valid,history_query_active;static uint8_t history_display_pane;
static hsc_request history_request;static hnt_summary history_summary;static uint8_t history_wire[170];
#if QW_QUERY_FIRST_SELECT
static hsc_request history_query_request;
static int history_local_armed;
#endif
static qwobs_record observation;
void *memset(void*p,int v,size_t n){unsigned char*x=p;for(size_t i=0;i<n;i++)x[i]=(unsigned char)v;return p;}
void *memcpy(void*d,const void*s,size_t n){uint8_t*a=d;const uint8_t*b=s;for(size_t i=0;i<n;i++)a[i]=b[i];return d;}
int memcmp(const void*a,const void*b,size_t n){const uint8_t*x=a,*y=b;for(size_t i=0;i<n;i++)if(x[i]!=y[i])return x[i]<y[i]?-1:1;return 0;}
static uint32_t zero_next,zero_end,request_number,active_request,last_rejected;
static inline uint32_t load(uint32_t a){return *(volatile uint32_t *)(uintptr_t)a;}
static inline void store(uint32_t a,uint32_t v){*(volatile uint32_t *)(uintptr_t)a=v;}
static int bridge_ok(void){return load(BRIDGE_STATUS)==0u;}
static int translate(uint32_t a,uint32_t *out){
 if(a>=0x40000000u&&a<0x40000100u){*out=a+0x80000000u;return 0;}
 if(a>=0x41000000u&&a<0x41000100u){*out=a+0x80000000u;return 0;}
 return -1;
}
static int read32(void *unused,uint32_t a,uint32_t *v){
 uint32_t cpu;(void)unused;if(!v||a&3u||translate(a,&cpu)||!bridge_ok())return -1;
 *v=load(cpu);return bridge_ok()?0:-1;
}
static int write32(void *unused,uint32_t a,uint32_t v){
 uint32_t cpu;(void)unused;if(a&3u||translate(a,&cpu)||!bridge_ok())return -1;
 store(cpu,v);return bridge_ok()?0:-1;
}
static int observation_read(void *unused,uint32_t a,uint32_t *v){
 (void)unused;
 if(!v||!bridge_ok()||a&3u)return -1;
 if(!(a==0xc1000000u||a==0xc1000004u||a==0xc100000cu||a==0xc1000018u||a==0xc100001cu||a==0xc10000a4u||
#if QW_ENABLE_NTH4
      a==0xc10000a8u||
#endif

      (a>=0xc1000100u&&a<=0xc10001fcu)))return -1;
 *v=load(a);return bridge_ok()?0:-1;
}
static int observation_write(void *unused,uint32_t a,uint32_t v){
 (void)unused;if(a!=0xc1000010u||v!=2u||!bridge_ok())return -1;
 store(a,v);return bridge_ok()?0:-1;
}
static int zero_start(void *unused,uint32_t a,uint32_t n){
 (void)unused;if(a!=0x8e000000u||n!=6488064u||zero_next!=zero_end||!bridge_ok())return -1;
 zero_next=a+0x40000000u;zero_end=zero_next+n;return 0;
}
static int zero_poll(void *unused){
 unsigned i;(void)unused;
 /* Bounded software clear; each volatile write only returns after actual B.
  * Converter/lease adapter must preserve this checked-master contract. */
 for(i=0;i<64u&&zero_next<zero_end;i++){
  if(!bridge_ok())return -1;
  store(zero_next,0);if(!bridge_ok())return -1;
  zero_next+=4u;
 }
 return zero_next==zero_end?1:0;
}
static uint32_t now(void){return load(QWU_MS_TICK);}
static int expired(uint32_t deadline){return (uint32_t)(now()-deadline)<0x80000000u;}
static int uart_ok(void){uint32_t s=load(QWU_STATUS);return (s&(QWU_OWNER|QWU_MMIO_FAULT))==QWU_OWNER;}
static int uart_byte(uint8_t byte){
 if(!uart_ok())return -1;
 store(QWU_TX,byte); /* IOReady is the physical PHY acceptance, not enqueue. */
 return uart_ok()?0:-1;
}
static int send_wire(const uint8_t *payload,size_t bytes){
 qwframe frame;uint8_t byte;int rc;
 if(qwframe_init(&frame,payload,bytes))return -1;
 while((rc=qwframe_peek(&frame,&byte))==1){if(uart_byte(byte)||qwframe_pop(&frame))return -1;}
 return rc==0?0:-1;
}
static int send_status(uint8_t kind,int code,uint32_t id){
 size_t bytes;uint32_t next;
 if(qwreply_chunk(status_payload,sizeof status_payload,id,kind,(int16_t)code,0,0,0,&bytes,&next))return -1;
 return send_wire(status_payload,bytes);
}
__attribute__((noreturn))static void halt(int code){
 if(uart_ok()){store(QWU_ADMISSION,0);(void)send_status(3,code,active_request);}
 /* Keep uncertain lease held; never claim an answer or force recovery. */
 for(;;)__asm__ volatile("nop");
}
static int boot_lease(int acquire){
 uint32_t value,deadline=now()+QWU_DEFAULT_TIMEOUT_MS;
 if(read32(0,LEASE,&value)||(value&0x300u)!=0x200u)return -1;
 if(acquire){if(value&1u||write32(0,LEASE_CMD,1))return -1;
  for(;;){if(read32(0,LEASE,&value)||(value&0x300u)!=0x200u||!(value&1u))return -1;
   if((value&7u)==7u)return 0;
  if(expired(deadline))return -1;}
 }
 for(;;){if(read32(0,LEASE,&value)||(value&0x300u)!=0x200u||(value&7u)!=7u)return -1;
  if((value&255u)==255u)break;
  if(expired(deadline))return -1;}
 /* The enhanced release slave must delay this B to full freeze/drain/ACK/drop. */
 if(write32(0,LEASE_CMD,2))return -1;
 for(;;){if(read32(0,LEASE,&value)||(value&0x300u)!=0x200u)return -1;
  if(!(value&3u))return 0;
  if(expired(deadline))return -1;}
}
static int question(size_t *bytes){
 uint32_t n=load(QWU_LENGTH),i=0,v,deadline=now()+QWU_DEFAULT_TIMEOUT_MS;
 if(n==0||n>sizeof input||!uart_ok())return -1;
 store(QWU_ADMISSION,0);
 while(i<n){
  if(!uart_ok()||expired(deadline))return -1;
  if(!(load(QWU_STATUS)&QWU_DATA_VALID))continue;
  v=load(QWU_POP);if(!(v&QWU_POP_VALID))continue;
  if(((v&QWU_POP_LAST)!=0)!=(i+1u==n))return -1;
  input[i++]=(uint8_t)v;
 }
 *bytes=n;return 0;
}
static int send_answer(void){
 uint32_t offset=0,next;size_t bytes;
 uint8_t *frame=(uint8_t *)(uintptr_t)QWMEM_FRAME_CPU;
 do{
  if(!bridge_ok()||qwreply_chunk(frame,QWMEM_FRAME_BYTES,request_number,1,0,
      runner.answer,(uint32_t)runner.answer_bytes,offset,&bytes,&next)||!bridge_ok())return -1;
  if(send_wire(frame,bytes)||!bridge_ok())return -1;
  offset=next;
 }while(offset<runner.answer_bytes);
 return 0;
}

static int reply_read(void *unused,uint32_t a,uint32_t*v){
 (void)unused;if(!v||a&3u||!bridge_ok())return -1;
 if(!(a==0xc1000000u||a==0xc1000004u||a==0xc100000cu||a==0xc1000014u||
      (a>=0xc1000100u&&a<=0xc10001fcu)))return -1;
 *v=load(a);return bridge_ok()?0:-1;
}
static int reply_write(void *unused,uint32_t a,uint32_t v){
 (void)unused;if(a&3u||!bridge_ok())return -1;
 if(!(a==0xc1000024u||a==0xc1000028u||(a>=0xc1000300u&&a<=0xc1000368u)||
      (a==0xc1000020u&&v==1u)))return -1;
 store(a,v);return bridge_ok()?0:-1;
}
/*0=new report identity,1=exact repeated body,-1=same identity conflict.
 * Vision identity excludes ROI count (word7), audio includes model_epoch.
 * Syntax/dedup provides no authenticity/current-scene authority. */
static int compare_auto_body(void){
 unsigned i;int same=1;if(!have_auto_body)return 0;
 for(i=0;i<48;i++){
  if(observation.modality==1&&i>=28&&i<32)continue;
  if(last_auto_body[i]!=observation_body[i])return 0;
 }
 for(i=0;i<256;i++)if(last_auto_body[i]!=observation_body[i])same=0;
 return same?1:-1;
}
static qwsnapshot_io history_io;
static int history_read(void*unused,uint32_t a,uint32_t*v){
 (void)unused;if(!v||a&3u||!bridge_ok())return -1;
 if(!(a==0xc1000000u||a==0xc1000004u||a==0xc100000cu||a==0xc1000014u||a==0xc1000018u||a==0xc100001cu||a==0xc1000030u||a==0xc10000a4u||
#if QW_ENABLE_NTH4
      a==0xc10000a8u||
#endif
(a>=0xc1000100u&&a<=0xc10001fcu)))return -1;
 *v=load(a);return bridge_ok()?0:-1;
}
static int history_write(void*unused,uint32_t a,uint32_t v){
 (void)unused;if(a&3u||!bridge_ok())return -1;
 if(!((a==0xc1000010u&&v==2)||(a==0xc1000020u&&v==1)||a==0xc1000024u||a==0xc1000028u||(a>=0xc1000300u&&a<=0xc1000368u)))return -1;
 store(a,v);return bridge_ok()?0:-1;
}
#if QW_QUERY_FIRST_SELECT
static int history_control(uint32_t op){
 int rc=write32(0,0x410000a0u,op);
 if(!rc){if(op==1)history_local_armed=1;else if(op==2)history_local_armed=0;}
 return rc;
}
#else
static int history_control(uint32_t op){return write32(0,0x410000a0u,op);}
#endif
static int raw_observation(qwsnapshot_io io,uint8_t*b,qwobs_record*r,uint32_t*num){
 uint32_t kind=0,n=0;int rc=selected_snapshot(io,b,&kind,&n);
 if(rc==QH_UNAVAILABLE)return QWS_UNAVAILABLE;
 if(rc)return rc;
 if(kind==3
#if QW_ENABLE_NTH4
 ||kind==5
#endif
 )return QWS_UNAVAILABLE; /* no HIS1-to-trusted-record promotion */
 if(qwobs_decode(b,256,r))return QWS_SYNTAX;
 *num=n;return 0;
}
static int history_transmit(uint32_t seed){
 qh_tx t;int rc;qh_tx_init(&t);
 if(qh_tx_begin(&t,history_io,history_wire+58,(uint32_t)history_request.nonce,seed,now(),QWU_DEFAULT_TIMEOUT_MS))return -1;
 do{rc=qh_tx_poll(&t,now());if(rc<0)return rc;}while(!rc);
 return 0;
}
/* Caller has not yet acquired Qwen DDR. HST borrows a real temporary lease;
 * HIS1 private copy is local BRAM. The subsequent qwrun performs a fresh real
 * acquire/encode/KV-clear/GO. No input IDs, activations, logits or answer is
 * supplied by this history helper. */
static int history_roundtrip(const qhint*hint,uint8_t op,uint8_t pane
#if QW_ENABLE_NTH4
 ,qnth4_query *trusted_history_query
#endif
 ){
 uint32_t kind=0,n=0,deadline=now()+QWU_DEFAULT_TIMEOUT_MS;int rc;
 if(!history_config_valid||history_config.nonce==UINT64_MAX)return QH_ARGUMENT;
 history_request=(hsc_request){history_config.session,history_config.nonce++,history_config.batch,hint->image_no,op,pane};
#if QW_ENABLE_NTH4
 if(op==HSC_QUERY){
  rc=qnth4_begin(trusted_history_query,&history_request);
  if(rc)return rc; /* no HST or temporary lease on invalid independent pin */
 }
#endif
#if QW_QUERY_FIRST_SELECT
 /* A local receive-arm is not the peer's protected QUERY lease. Keep that
  * lease across SELECT, discard only the already privately collected body. */
#if QW_NTH4_SELECT_REARM
 /* NTH4 queue consumption does not set CSR history_held. After collecting
  * the complete private result, retire only the local arm via its real B
  * acknowledgement; the existing arm command below then starts SELECT.
  * No HSC, remote QUERY lease release, or original QUERY nonce change. */
 if(op==HSC_SELECT&&trusted_history_complete&&history_local_armed){
  if(history_control(2))return QH_IO;
 }
#endif
 if(history_control(history_local_armed?3u:1u)||hnt_pack_query(&history_request,(uint32_t)history_request.nonce,history_wire)!=HNT_OK)return QH_IO;
#else
 if(history_control(1)||hnt_pack_query(&history_request,(uint32_t)history_request.nonce,history_wire)!=HNT_OK)return QH_IO;
#endif
 if(boot_lease(1))return QH_IO;
 rc=history_transmit(0x48535431u);if(rc)return rc;
 if(boot_lease(0))return QH_IO;
 for(;;){
  if(expired(deadline))return QH_TIMEOUT;
  rc=selected_snapshot(history_io,observation_body,&kind,&n);
  if(rc==QH_UNAVAILABLE)continue;
  if(rc)return rc;
#if QW_ENABLE_NTH4
  if(kind==5){
   if(op!=HSC_QUERY){
#if QW_QUERY_FIRST_SELECT
    if(history_control(3))return QH_IO;
#endif
    continue;
   }
   rc=qnth4_accept(trusted_history_query,observation_body,kind);
   if(rc==QNTH4_STALE||rc==QNTH4_PENDING)continue;
   if(rc){trusted_history_failed=1;return rc;}
   trusted_history_complete=1;return 0;
  }
#endif
  if(kind!=3)continue;
  /* Same untrusted family as HIS1; never a trusted record. MAC/FCS validity
   * comes from the strict RX->FIFO->held CSR chain; CRC and full request
   * correlation are checked here. Only exact positive rc1 is unavailable. */
  if(observation_body[0]=='H'&&observation_body[1]=='N'&&observation_body[2]=='A'&&observation_body[3]=='1'){
   rc=hna_decode_body(observation_body,256,0,&history_request);
   if(rc==HNA_STALE){if(history_control(3))return QH_IO;continue;}
   if(rc!=HNA_NOT_STORED)return rc?rc:QH_SYNTAX;
   if(history_control(2))return QH_IO;
   return HISTORY_NOT_STORED;
  }
  rc=qh_decode(observation_body,&history_request,&history_summary);
  if(rc==QH_CHANGED){if(history_control(3))return QH_IO;continue;}
  if(rc)return rc;
#if QW_QUERY_FIRST_SELECT
  if(op==HSC_QUERY)return QH_STATUS; /* never use PS HIS1 as a class result */
#endif
  if(history_summary.status==2){if(history_control(3))return QH_IO;continue;}
  if(history_summary.status==4)return QH_STATUS;
  return 0;
 }
}
#if QW_QUERY_FIRST_SELECT
static int diagnostic_presented(void){
 return history_summary.status==3&&history_summary.ps_untrusted==1&&
  history_summary.record.state==PSH_YOLO_PENDING&&history_summary.record.roi_count==0&&
  !history_summary.record.error_code&&!history_summary.record.archived;
}
static int diagnostic_facts(uint8_t*facts,size_t*bytes,uint32_t image,uint8_t pane){
 const char*s="PS_UNTRUSTED diagnostic display: PS observed HDMI PRESENTED. No classification, no authenticated pixels, no current-scene or action authority. image_no=";
 size_t n=0;char digits[10];unsigned k=0;
 while(*s)facts[n++]=(uint8_t)*s++;
 do{digits[k++]=(char)('0'+image%10u);image/=10u;}while(image);
 while(k)facts[n++]=(uint8_t)digits[--k];
 s=";pane=";while(*s)facts[n++]=(uint8_t)*s++;facts[n++]=(uint8_t)('0'+pane);facts[n++]=10;
 *bytes=n;return 0;
}
#endif
static int history_prepare(const qhint*hint,size_t*facts_bytes
#if QW_ENABLE_NTH4
 ,uint8_t *facts
#endif
 ){
 int rc;history_display_pane=0;
#if QW_QUERY_FIRST_SELECT
 qnth4_query trusted_history_query;
 trusted_history_complete=0;history_query_active=0;
 if(hint->operation==2){
  rc=history_roundtrip(hint,HSC_SELECT,hint->pane,&trusted_history_query);if(rc)return rc;
  if(!diagnostic_presented()||history_control(2))return QH_STATUS;
  return diagnostic_facts(facts,facts_bytes,hint->image_no,hint->pane);
 }
 if(trusted_history_failed)return QNTH4_PIN_MISMATCH;
 rc=history_roundtrip(hint,HSC_QUERY,0,&trusted_history_query);if(rc)return rc;
 if(!trusted_history_complete)return QH_STATUS;
 history_query_request=history_request; /* includes the original QUERY nonce */
 if(!hint->suppress_display){
  uint8_t pane=1;
  rc=history_roundtrip(hint,HSC_SELECT,pane,&trusted_history_query);if(rc)return rc;
  if(!diagnostic_presented()||history_control(2))return QH_STATUS;
  history_display_pane=pane;
 }
 history_request=history_query_request;
 rc=qnth4_facts(&trusted_history_query,facts,QW_FACTS_BYTES,facts_bytes);
 if(rc){trusted_history_failed=1;return rc;}
 if(history_display_pane){
  const char*note="Diagnostic SELECT: PS_UNTRUSTED PRESENTED pane=1; not a result or generation proof.\n";
  while(*note){if(*facts_bytes>=QW_FACTS_BYTES)return QH_ARGUMENT;facts[(*facts_bytes)++]=(uint8_t)*note++;}
 }
 history_query_active=1;return 0;
#else
#if QW_ENABLE_NTH4
 qnth4_query trusted_history_query;
 trusted_history_complete=0;
 if(trusted_history_failed)return QNTH4_PIN_MISMATCH;
#endif
 /* Numbered questions really display the selected image first. Only the
  * confirmed PRESENTED packet allows proceeding. Explicit negative opts out;
  * pane2 is never selected. Other panes remain a PS driver responsibility. */
 if(!hint->suppress_display){
  uint8_t pane=hint->operation==2?hint->pane:1;
  rc=history_roundtrip(hint,HSC_SELECT,pane
#if QW_ENABLE_NTH4
 ,&trusted_history_query
#endif
 );if(rc)return rc;
  if(history_summary.status!=3||history_control(2))return QH_STATUS;
  history_display_pane=pane;
 }
 rc=history_roundtrip(hint,HSC_QUERY,0
#if QW_ENABLE_NTH4
 ,&trusted_history_query
#endif
 );if(rc)return rc;
#if QW_ENABLE_NTH4
 if(trusted_history_complete){
  rc=qnth4_facts(&trusted_history_query,facts,QW_FACTS_BYTES,facts_bytes);
  if(rc){trusted_history_failed=1;return rc;}
 }else{
#endif
 if(history_summary.status!=1)return QH_STATUS;
 if(qh_facts(&history_summary,facts,QW_FACTS_BYTES,facts_bytes))return QH_SYNTAX;
#if QW_ENABLE_NTH4
 }
#endif
 if(history_display_pane){
  const char*note="Prior SELECT: PS_UNTRUSTED PRESENTED pane=";
  while(*note){if(*facts_bytes>=QW_FACTS_BYTES)return QH_ARGUMENT;facts[(*facts_bytes)++]=(uint8_t)*note++;}
  if(*facts_bytes+2>QW_FACTS_BYTES)return QH_ARGUMENT;
  facts[(*facts_bytes)++]=(uint8_t)('0'+history_display_pane);facts[(*facts_bytes)++]=10;
 }
 history_query_active=1;
 return 0;
#endif
}
static int history_consumed_after_answer(void){
 if(!history_query_active)return 0;
 /* This event is stronger than prefill-entered: real result FIFO was read
  * and decoded by qwrun. A rejected input never reaches this branch. */
 if(runner.state!=QWR_ANSWER_READY||hnt_pack_consumed(&history_request,1,(uint32_t)history_request.nonce,history_wire)!=HNT_OK)return QH_STATUS;
 int rc=history_transmit(0x48534331u);if(rc)return rc;
#if QW_QUERY_FIRST_SELECT
 if(history_local_armed&&history_control(2))return QH_IO;
#else
 if(history_control(2))return QH_IO;
#endif
 history_query_active=0;return 0;
}
int main(void){
#if QW_ENABLE_NTH4
 uint8_t facts[QW_FACTS_BYTES];
#endif
 qwrun_io io={0,read32,write32,zero_start,zero_poll};qwchat_message message[2];
 qwsnapshot_io observation_io={0,observation_read,observation_write};
 qweth_io eth_io={0,reply_read,reply_write};qweth sender;size_t bytes,facts_bytes,system_bytes;
 const uint8_t *system;uint32_t snapshot=0;int rc,automatic;unsigned i;
 if(load(BRIDGE_ABI)!=0x4d435335u||load(QWU_ABI_REG)!=QWU_ABI||load(QWU_CLOCK_HZ)!=50000000u)halt(-201);
 while(!(load(QWU_STATUS)&QWU_OWNER))__asm__ volatile("nop");
 if(!uart_ok())halt(-202);
 store(QWU_ADMISSION,0);
 if(boot_lease(1))halt(-203);
 rc=qwenc_init(&encoder,(const void *)(uintptr_t)QWMEM_ENCODER_CPU,QWMEM_ENCODER_BYTES);
 if(rc||!bridge_ok())halt(-204);
 rc=qwdet_init(&decoder,(const void *)(uintptr_t)QWMEM_DECODER_CPU,QWMEM_DECODER_BYTES);
 if(rc||!bridge_ok())halt(-205);
 rc=qwrun_init(&runner,&encoder,&decoder,(qwenc_workspace *)(uintptr_t)QWMEM_WORKSPACE_CPU,io,
   (uint8_t *)(uintptr_t)QWMEM_RENDERED_CPU,(uint16_t *)(uintptr_t)QWMEM_PROMPT_CPU,
   (uint8_t *)(uintptr_t)QWMEM_ANSWER_CPU);
 if(rc)halt(-206);
 {uint8_t descriptor[32];for(unsigned k=0;k<32;k++)descriptor[k]=*(volatile uint8_t*)(uintptr_t)(QWMEM_QUESTION_CPU+k);
 history_config_valid=qh_config_decode(descriptor,&history_config)==0;if(!bridge_ok())halt(-206);}
 if(boot_lease(0))halt(-206);
 history_io=(qwsnapshot_io){0,history_read,history_write};
#if QW_ENABLE_NTH4
 {uint32_t capability;
  if(history_read(0,0xc10000a8u,&capability)||capability!=0x4e540001u)halt(-312);
 }
#endif
 last_rejected=load(QWU_REJECTED);
 if(send_status(4,0,0))halt(-207);
 store(QWU_ADMISSION,1);
 for(;;){
  if(!uart_ok())halt(-208);
  automatic=0;active_request=0;
  if(!(load(QWU_STATUS)&QWU_QUESTION_VALID)){
   uint32_t rejects=load(QWU_REJECTED);
   if(rejects!=last_rejected){last_rejected=rejects;if(send_status(2,-209,0))halt(-210);}
   rc=raw_observation(observation_io,observation_body,&observation,&snapshot);
   if(rc==QWS_UNAVAILABLE)continue;
   if(rc!=QWS_OK)halt(rc);
   rc=compare_auto_body();
   if(rc>0)continue;
   if(rc<0){
    /* No lease is held at this boundary. Refuse auto explanation, report an
     * explicit observation conflict once; ordinary UART remains available. */
    if(!auto_conflict_reported){if(send_status(3,-220,0))halt(-210);auto_conflict_reported=1;}
    continue;
   }
   auto_conflict_reported=0;
   /* A question committed while freezing takes priority over a new auto job. */
   if(load(QWU_STATUS)&QWU_QUESTION_VALID)continue;
   if(qwenglish_build(&observation,&system,&system_bytes,facts,QW_FACTS_BYTES,&facts_bytes))halt(-217);
   message[0].role=QWCHAT_SYSTEM;message[0].content=system;message[0].bytes=system_bytes;
   message[1].role=QWCHAT_USER;message[1].content=facts;message[1].bytes=facts_bytes;
   automatic=1;
   /* Freeze the full identity/body baseline for this auto generation. Same
    * identity with changed body is refused as a conflict on subsequent polls.
    * This one-record dedup is not a global anti-replay/authentication service. */
   for(i=0;i<256;i++)last_auto_body[i]=observation_body[i];
   have_auto_body=1;
  }else{
   if(question(&bytes))halt(-211);
   active_request=++request_number;
   qhint hint;rc=qhint_parse(input,bytes,&hint);
   if(rc||(!history_config_valid&&hint.operation)){
    if(send_status(2,rc?rc:QH_ARGUMENT,active_request))halt(-214);
    store(QWU_ADMISSION,1);continue;
   }
   if(hint.operation){
    rc=history_prepare(&hint,&facts_bytes
#if QW_ENABLE_NTH4
 ,facts
#endif
 );
#if QW_ENABLE_NTH4
    if(rc==QNTH4_PIN_UNAVAILABLE||rc==QNTH4_PIN_MISMATCH){
     /* An accepted remote query may remain held on mismatch. No fabricated
      * HSC/prefill/release; block further history operations until controlled
      * reinitialization, but keep ordinary UART questions available. */
     if(rc==QNTH4_PIN_MISMATCH)trusted_history_failed=1;
     if(send_status(2,rc,active_request))halt(-214);
     store(QWU_ADMISSION,1);continue;
    }
#endif
    if(rc==HISTORY_NOT_STORED){
     /* Temporary DDR lease and real HST TX are already complete. No query
      * image lease exists on PS for HNA; no qwr/prefill/GO/HSC is allowed. */
     if(send_status(2,HISTORY_UNAVAILABLE_STATUS,active_request))halt(-214);
     store(QWU_ADMISSION,1);continue;
    }
    if(rc)halt(rc);
   }
   else {
    rc=raw_observation(observation_io,observation_body,&observation,&snapshot);
    if(rc!=QWS_OK&&rc!=QWS_UNAVAILABLE)halt(rc);
    if(qwfacts_build(rc==QWS_OK?&observation:0,snapshot,facts,QW_FACTS_BYTES,&facts_bytes))halt(-216);
   }
   message[0].role=QWCHAT_SYSTEM;message[0].content=facts;message[0].bytes=facts_bytes;
   message[1].role=QWCHAT_USER;message[1].content=input;message[1].bytes=bytes;
  }
  rc=qwrun_begin(&runner,message,2,automatic?48u:192u,now(),QWU_DEFAULT_TIMEOUT_MS);if(rc)halt(rc);
  for(;;){
   rc=qwrun_poll(&runner,now());if(rc)halt(rc);
   if(runner.state==QWR_ANSWER_READY){
    if(!automatic&&history_query_active){rc=history_consumed_after_answer();if(rc)halt(rc);}
    if(automatic){
     if(!bridge_ok()||qwreply_pack(&observation,runner.answer,runner.answer_bytes,reply_payload)||!bridge_ok())halt(-218);
     qweth_init(&sender);
     if(qweth_begin(&sender,eth_io,observation_body,snapshot,reply_payload,now(),QWU_DEFAULT_TIMEOUT_MS))halt(-219);
     do{rc=qweth_poll(&sender,now());if(rc<0)halt(rc);}while(!rc);
     /* Exact entire packet local MAC acceptance, not a peer ACK. */
    }else if(send_answer())halt(-212);
    if(qwrun_transport_done(&runner,1,now()))halt(-213);
   }else if(runner.state==QWR_REJECT_READY){
    if(automatic||history_query_active)halt((int)runner.error);
    if(send_status(2,(int)runner.error,active_request))halt(-214);
    if(qwrun_transport_done(&runner,1,now()))halt(-215);
   }else if(runner.state==QWR_DONE)break;
  }
  if(!automatic)store(QWU_ADMISSION,1);
 }
}
