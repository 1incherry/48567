#include <stdint.h>
/* This independent local-BRAM section is patched only offline by root from
 * the actual authorized PL public context. Zero is deliberately unavailable.
 * It is never populated from a packet, HIS/PS metadata, or mutable DDR. */
__attribute__((used,aligned(4),section(".qhroot")))
const volatile uint8_t qhroot_pin[32]={0};
