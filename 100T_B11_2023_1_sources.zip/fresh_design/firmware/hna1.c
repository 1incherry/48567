#include "hna1.h"
#include <string.h>
static const uint8_t envelope[14]={2,0x50,0x52,0x58,0x31,0,
                                2,0x50,0x52,0x58,0x70,0x35,0x88,0xb6};
static int legal(const hsc_request *r){
 return r && r->bridge_session && r->nonce && r->batch_id &&
  r->image_no && r->image_no<=100 &&
  ((r->op==HSC_QUERY && r->pane==0) ||
   (r->op==HSC_SELECT && (r->pane==1 || r->pane==3 || r->pane==4)));
}
static uint32_t r32(const uint8_t*p){
 return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;
}
static uint64_t r64(const uint8_t*p){return r32(p)|(uint64_t)r32(p+4)<<32;}
static void w32(uint8_t*p,uint32_t v){for(unsigned k=0;k<4;k++)p[k]=(uint8_t)(v>>(8*k));}
static void w64(uint8_t*p,uint64_t v){w32(p,(uint32_t)v);w32(p+4,(uint32_t)(v>>32));}
int hna_pack_body(const hsc_request*r,uint8_t p[HNA_BODY_BYTES]){
 if(!p || !legal(r))return HNA_ARGUMENT;
 memset(p,0,256);memcpy(p,"HNA1",4);p[5]=1;p[6]=1;p[7]=1;
 p[8]=r->op;p[9]=r->pane;p[10]=1;p[11]=1;p[14]=1;
 w64(p+16,r->bridge_session);w64(p+24,r->nonce);w64(p+32,r->batch_id);
 w32(p+40,r->image_no);w32(p+252,psh_crc32(p,252));return HNA_OK;
}
int hna_pack_frame(const hsc_request*r,uint8_t p[HNA_FRAME_BYTES]){
 if(!p || !legal(r))return HNA_ARGUMENT;
 int rc=hna_pack_body(r,p+14);if(rc)return rc;
 memcpy(p,envelope,14);return HNA_OK;
}
int hna_decode_body(const uint8_t*p,size_t n,int bad,const hsc_request*r){
 if(!p || !legal(r))return HNA_ARGUMENT;
 if(bad)return HNA_MAC;
 if(n!=256)return HNA_FORMAT;
 if(memcmp(p,"HNA1",4) || p[4]!=0 || p[5]!=1 || p[6]!=1 || p[7]!=1 ||
    p[10]!=1 || p[11]!=1 || p[12]!=0 || p[13]!=0 || p[14]!=1 || p[15]!=0 ||
    r32(p+252)!=psh_crc32(p,252))return HNA_FORMAT;
 for(unsigned i=44;i<252;i++)if(p[i])return HNA_FORMAT;
 hsc_request q={r64(p+16),r64(p+24),r64(p+32),r32(p+40),p[8],p[9]};
 if(!legal(&q))return HNA_FORMAT;
 if(q.bridge_session!=r->bridge_session || q.nonce!=r->nonce ||
    q.batch_id!=r->batch_id || q.image_no!=r->image_no ||
    q.op!=r->op || q.pane!=r->pane)return HNA_STALE;
 return HNA_NOT_STORED;
}
int hna_decode_frame(const uint8_t*p,size_t n,int bad,const hsc_request*r){
 if(!p || !legal(r))return HNA_ARGUMENT;
 if(bad)return HNA_MAC;
 if(n!=270 || memcmp(p,envelope,14))return HNA_FORMAT;
 return hna_decode_body(p+14,256,0,r);
}
