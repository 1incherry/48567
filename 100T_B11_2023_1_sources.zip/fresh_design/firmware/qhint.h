#ifndef QHINT_H
#define QHINT_H
#include <stddef.h>
#include <stdint.h>
typedef struct{uint32_t image_no;uint8_t operation,pane,suppress_display;} qhint;
enum{QHI_OK=0,QHI_ARGUMENT=-1,QHI_UTF8=-2,QHI_RANGE=-3,QHI_AMBIGUOUS=-4};
/* Bounded tool intent only, not generated text. Original question goes to Qwen.
 * NONE0,QUERY1,SELECT2. Only explicit imperative display prefixes select.
 * One image1..100, displaypane1/3/4; pane2neverselected.
 * Runtime may SELECT(default1) then QUERY for neutral numbered questions;
 * conservative explicit negative sets suppress_display and remains QUERY-only. */
int qhint_parse(const uint8_t *,size_t,qhint *);
#endif
