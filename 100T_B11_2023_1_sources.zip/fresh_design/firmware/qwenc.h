#ifndef QWENC_H
#define QWENC_H
#include <stdint.h>
#include <stddef.h>
#define QWENC_INPUT_LIMIT 4096u
#define QWENC_CP_LIMIT 16384u
#define QWENC_BYTE_LIMIT 65536u
typedef struct { const uint8_t *data; uint32_t size; } qwenc;
typedef struct {
 uint32_t cp[QWENC_CP_LIMIT];
 uint32_t offset[QWENC_CP_LIMIT+1u];
 uint8_t normalized[QWENC_BYTE_LIMIT];
 uint16_t word[QWENC_BYTE_LIMIT];
 uint32_t cp_count, byte_count;
} qwenc_workspace;
enum { QWENC_OK=0,QWENC_BAD_TABLE=-1,QWENC_BAD_UTF8=-2,QWENC_TOO_LONG=-3,QWENC_OUTPUT_FULL=-4 };
int qwenc_init(qwenc *ctx,const uint8_t *data,size_t bytes);
int qwenc_normalize(const qwenc *ctx,const uint8_t *text,size_t bytes,qwenc_workspace *work);
uint32_t qwenc_next_piece(const qwenc *ctx,const qwenc_workspace *work,uint32_t position);
int qwenc_encode(const qwenc *ctx,const uint8_t *text,size_t bytes,uint16_t *output,size_t capacity,size_t *written,qwenc_workspace *work);
#endif
