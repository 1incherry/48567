#ifndef PS_CAMERA_HISTORY_H
#define PS_CAMERA_HISTORY_H
#include <stddef.h>
#include <stdint.h>
#define PSH_PANES 3u
#define PSH_DEFAULT_CAPACITY 100u
#define PSH_MAX_SLOTS 100u
#define PSH_WIDTH 640u
#define PSH_HEIGHT 480u
#define PSH_RAW_BYTES (PSH_WIDTH * PSH_HEIGHT * 3u)
#define PSH_FB_WIDTH 1280u
#define PSH_FB_HEIGHT 720u
#define PSH_FB_BYTES (PSH_FB_WIDTH * PSH_FB_HEIGHT * 4u)
#define PSH_MAX_ROIS 4u
#define PSH_VIT_CLASSES 105u
typedef enum { PSH_OK=0,PSH_BUSY,PSH_ARGUMENT,PSH_STALE,PSH_STATE,
               PSH_CRC,PSH_EXHAUSTED,PSH_DISPLAY_ERROR,PSH_PRESENTED,
               PSH_FULL,PSH_NOT_FOUND } psh_rc;
typedef enum { PSH_YOLO_PENDING=1,PSH_VIT_PENDING,PSH_NO_TARGET,
               PSH_CLASSIFIED,PSH_FAILED } psh_state;
typedef enum { PSH_NN_LEASE=0,PSH_EXPORT_LEASE=1,PSH_QUERY_LEASE=2 } psh_lease_role;
typedef struct {
    uint32_t camera,session,frame,runtime_epoch,model_epoch;
} psh_identity;
typedef struct { uint32_t slot; uint64_t generation,batch_id; } psh_ticket;
typedef struct { uint16_t x0,y0,x1,y1; } psh_roi;
typedef struct {
    psh_roi box;
    uint8_t done;
    uint32_t class_id,record_sequence;
    int64_t best_logit;
} psh_roi_result;
typedef struct {
    uint8_t valid,archived;
    psh_identity id;
    uint64_t generation,batch_id;
    uint32_t image_no,raw_crc32,error_code;
    uint8_t archive_sha256[32];
    psh_state state;
    uint8_t roi_count;
    psh_roi_result rois[PSH_MAX_ROIS];
    uint16_t nn_leases,export_leases,query_leases,display_leases;
} psh_slot;
typedef enum { PSH_VIEW_NONE=0,PSH_VIEW_PREPARED,PSH_VIEW_SUBMITTED,
               PSH_VIEW_GUARD,PSH_VIEW_CURRENT,PSH_VIEW_FAILED } psh_view_phase;
typedef struct {
    psh_view_phase phase;
    uint8_t present[PSH_PANES],boundary_seen,buffer_tag;
    psh_ticket ticket[PSH_PANES];
    psh_slot snapshot[PSH_PANES];
    uint32_t sequence,anchor,boundary;
} psh_view;
typedef struct {
    uint8_t *storage;
    size_t storage_bytes;
    unsigned capacity,count;
    uint32_t selected[PSH_PANES];
    uint64_t last_generation;
    uint64_t batch_id;
    uint32_t last_image_no;
    uint32_t last_display_sequence;
    psh_slot slots[PSH_MAX_SLOTS];
    psh_view current,pending;
} psh_history;

/* Caller serializes all API calls. No allocation, IO, MMIO or addresses here.
 * RAW must remain immutable under the actual capture owner's lease during push.
 * Linux/baremetal storage must be reserved by the system's complete DDR contract,
 * never inferred from these pointers or from apparent free physical DDR.
 */
size_t psh_storage_required(unsigned capacity);
/* batch_id must be durably unique across bridge restarts/new batches. This
 * component neither invents a persistent ID nor silently starts a new batch.
 * Reinitialization of a live history with outstanding leases is prohibited. */
psh_rc psh_init(psh_history *,void *storage,size_t storage_bytes,unsigned capacity,
                uint64_t batch_id);
uint32_t psh_crc32(const void *,size_t);
psh_rc psh_push(psh_history *,const psh_identity *,const uint8_t *rgb,
                size_t bytes,psh_ticket *);
const psh_slot *psh_lookup(const psh_history *,psh_ticket);
psh_rc psh_acquire(psh_history *,psh_ticket,psh_lease_role,const uint8_t **rgb);
psh_rc psh_release(psh_history *,psh_ticket,psh_lease_role);
/* Read-only metadata/source access: on success this acquires QUERY lease.
 * Release it explicitly after display/Qwen-context consumption. Missing/old
 * images never alias a newer slot's data, in the frozen global100 batch. */
psh_rc psh_query(psh_history *,uint64_t batch_id,uint32_t image_no,
                 psh_ticket *,psh_slot *actual_snapshot,const uint8_t **rgb);
psh_rc psh_select_image(psh_history *,uint64_t batch_id,uint32_t image_no,unsigned pane);
psh_rc psh_archive_confirm(psh_history *,psh_ticket,const psh_identity *,uint32_t raw_crc,
                           const uint8_t actual_archive_sha256[32]);
/* Only actual matched board results belong here. Python expected labels must
 * never be bound as live ViT results. These records are untrusted PS display
 * metadata; CRC/identity checks are not PL authentication or authority.
 */
psh_rc psh_yolo_result(psh_history *,psh_ticket,const psh_identity *,
                       const psh_roi *actual_rois,unsigned count);
psh_rc psh_roi_classified(psh_history *,psh_ticket,const psh_identity *,unsigned roi,
                          uint32_t class_id,int64_t actual_best_logit,
                          uint32_t actual_record_sequence);
psh_rc psh_job_error(psh_history *,psh_ticket,const psh_identity *,uint32_t actual_error);
/* pane is the physical pane number1,3,4; pane2 belongs to live preview. */
psh_rc psh_rotate(psh_history *,unsigned pane);
psh_rc psh_display_prepare(psh_history *);
psh_rc psh_display_cancel_prepared(psh_history *);
/* Requires distinct caller-provided inactive destination. Modifies panels1/3/4,
 * clones all of panel2 and top108 unchanged. No framebuffer address is chosen. */
psh_rc psh_render(const psh_history *,const uint32_t *prior,uint32_t *inactive_dst);
/* buffer_tag0/1 is opaque: actual legal physical FB mapping belongs to driver. */
psh_rc psh_display_submit(psh_history *,uint32_t issued_sequence,unsigned buffer_tag,
                          uint32_t actual_before_commit_ack);
psh_rc psh_display_observe(psh_history *,uint32_t actual_ack,unsigned actual_buffer_tag,
                           uint32_t actual_scan_frames,int actual_underflow_or_axi_error);
/* Failed/submitted views retain leases until driver has actually disabled and
 * drained scan/DMA. False does nothing. This is not a PL-trust declaration. */
psh_rc psh_display_release_after_drain(psh_history *,int actual_stream_idle);
psh_rc psh_caption(const psh_slot *,char *line1,size_t n1,char *line2,size_t n2);
/* One selected record only, no natural-language/model answer. Missing ROI
 * classifications serialize as null, not class0. A query lease belongs to the
 * caller until actual context consumption completes. */
psh_rc psh_context_json(const psh_slot *,char *out,size_t capacity,size_t *written);
#endif
