#include "qweth.h"
#define BASE 0xc1000000u
enum {IDLE=0,ABI,STATUS1,SNAPSHOT1,COUNT1,BODY1,STATUS2,SNAPSHOT2,
 SEQUENCE,SESSION,PAYLOAD,BODY2,STATUS3,SNAPSHOT3,GO,WAIT_STATUS,WAIT_COUNT,DONE,FAILED};
static uint32_t le(const uint8_t *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static uint32_t be(const uint8_t *p){return ((uint32_t)p[0]<<24)|((uint32_t)p[1]<<16)|((uint32_t)p[2]<<8)|p[3];}
static int fail(qweth *r,int error){r->state=FAILED;r->error=error;return error;}
void qweth_init(qweth *r){if(r){r->state=IDLE;r->error=0;}}
int qweth_begin(qweth *r,qweth_io io,const uint8_t body[256],uint32_t snapshot,
 const uint8_t p[108],uint32_t now,uint32_t timeout){
 uint32_t n,i,magic;
 static const uint8_t prefix[8]={'H','I','S','T','O','R','Y',' '};
 if(!r||!io.read32||!io.write32||!body||!p||!timeout||timeout>=0x80000000u)return QWE_ARGUMENT;
 if(r->state!=IDLE&&r->state!=DONE)return QWE_STATE;
 magic=be(body);
 if(!((magic==0x4e545232u&&be(body+4)==0x00020001u)||
      (magic==0x4e415232u&&be(body+4)==0x00020002u))||!be(body+8))return QWE_ARGUMENT;
 n=le(p+20);
 if(le(p)!=0x314e5751u||le(p+4)!=1||le(p+8)!=4||le(p+12)!=be(body+16)||
    le(p+16)!=be(body+8)||le(p+24)||n<8||n>80)return QWE_ARGUMENT;
 for(i=0;i<8;i++)if(p[28+i]!=prefix[i])return QWE_ARGUMENT;
 for(i=0;i<n;i++)if(p[28+i]>127)return QWE_ARGUMENT;
 for(i=n;i<80;i++)if(p[28+i])return QWE_ARGUMENT;
 r->io=io;r->body=body;r->payload=p;r->snapshot=snapshot;r->word=0;
 r->state=ABI;r->before=0;r->last_status=0;r->deadline=now+timeout;r->error=0;
 return 0;
}
int qweth_poll(qweth *r,uint32_t now){
 uint32_t value=0,address=0,wdata=0;int writing=0,next;
 if(!r)return QWE_ARGUMENT;
 if(r->state==FAILED)return r->error;
 if(r->state==DONE)return 1;
 if(r->state==IDLE)return QWE_STATE;
 if((uint32_t)(now-r->deadline)<0x80000000u)return fail(r,QWE_TIMEOUT);
 switch(r->state){
 case ABI:address=BASE;break;
 case STATUS1:case STATUS2:case STATUS3:case WAIT_STATUS:address=BASE+4;break;
 case SNAPSHOT1:case SNAPSHOT2:case SNAPSHOT3:address=BASE+0xc;break;
 case COUNT1:case WAIT_COUNT:address=BASE+0x14;break;
 case BODY1:case BODY2:address=BASE+0x100+r->word*4;break;
 case SEQUENCE:writing=1;address=BASE+0x24;wdata=le(r->payload+16);break;
 case SESSION:writing=1;address=BASE+0x28;wdata=le(r->payload+12);break;
 case PAYLOAD:writing=1;address=BASE+0x300+r->word*4;wdata=le(r->payload+r->word*4);break;
 case GO:writing=1;address=BASE+0x20;wdata=1;break;
 default:return fail(r,QWE_STATE);
 }
 if(writing){if(r->io.write32(r->io.opaque,address,wdata))return fail(r,QWE_IO);}
 else if(r->io.read32(r->io.opaque,address,&value))return fail(r,QWE_IO);
 next=(int)r->state+1;
 switch(r->state){
 case ABI:if(value!=0x4e545232u)return fail(r,QWE_STATE);break;
 case STATUS1:case STATUS2:case STATUS3:
  if((value&0x3au)!=2u)return fail(r,QWE_TX);
  break;
 case SNAPSHOT1:case SNAPSHOT2:case SNAPSHOT3:
  if(value!=r->snapshot)return fail(r,QWE_CONTEXT);
  break;
 case COUNT1:r->before=value;r->word=0;break;
 case BODY1:case BODY2:
  if(value!=be(r->body+r->word*4))return fail(r,QWE_CONTEXT);
  if(++r->word<64)next=(int)r->state;
  else r->word=0;
  break;
 case SESSION:r->word=0;break;
 case PAYLOAD:
  if(++r->word<27)next=PAYLOAD;
  else r->word=0;
  break;
 case WAIT_STATUS:
  if(value&0x30u)return fail(r,QWE_TX);
  r->last_status=value;
  break;
 case WAIT_COUNT:{
  uint32_t delta=value-r->before;
  if(delta>1u)return fail(r,QWE_COUNT);
  if(delta==1u&&!(r->last_status&8u)){r->state=DONE;return 1;}
  next=WAIT_STATUS;break;
 }
 default:break;
 }
 r->state=(uint32_t)next;return 0;
}
