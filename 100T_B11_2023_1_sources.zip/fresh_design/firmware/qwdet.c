#include "qwdet.h"
static uint32_t le32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static int put(qwdet *d,uint8_t b){if(d->emit(d->opaque,b)){d->failed=1;return QWDET_IO;}return 0;}
static int replacement(qwdet *d){int r; if((r=put(d,0xef)))return r;if((r=put(d,0xbf)))return r;return put(d,0xbd);}
static int feed(qwdet *d,uint8_t b){
 int r;unsigned i;
 /* A bad continuation replaces the accepted prefix, then reprocesses the
  * current byte. E0/ED/F0/F4 restrictions implement maximal-subpart behavior. */
 if(d->used){
  int valid=b>=0x80&&b<=0xbf;
  if(d->used==1){uint8_t first=d->pending[0];
   if(first==0xe0&&b<0xa0)valid=0;
   if(first==0xed&&b>0x9f)valid=0;
   if(first==0xf0&&b<0x90)valid=0;
   if(first==0xf4&&b>0x8f)valid=0;
  }
  if(valid){
   d->pending[d->used++]=b;
   if(d->used==d->needed){for(i=0;i<d->used;i++)if((r=put(d,d->pending[i])))return r;d->used=0;d->needed=0;}
   return 0;
  }
  if((r=replacement(d)))return r;
  d->used=0;d->needed=0;
 }
 if(b<0x80)return put(d,b);
 if(b>=0xc2&&b<=0xdf)d->needed=2;
 else if(b>=0xe0&&b<=0xef)d->needed=3;
 else if(b>=0xf0&&b<=0xf4)d->needed=4;
 else return replacement(d);
 d->pending[0]=b;d->used=1;return 0;
}
void qwdet_abort(qwdet *d){d->used=0;d->needed=0;d->active=0;d->failed=0;}
int qwdet_init(qwdet *d,const void *table,size_t bytes){
 const uint8_t *p=(const uint8_t*)table;uint32_t i,last,next,blob_bytes;
 d->offsets=0;d->flags=0;d->blob=0;d->blob_bytes=0;d->emit=0;d->opaque=0;qwdet_abort(d);
 if(!p||bytes<32)return QWDET_BAD_TABLE;
 if(p[0]!='Q'||p[1]!='W'||p[2]!='D'||p[3]!='E'||p[4]!='T'||p[5]!='V'||p[6]!='1'||p[7]!=0)return QWDET_BAD_TABLE;
 if(le32(p+8)!=1||le32(p+12)!=65535||le32(p+16)!=262144||le32(p+20)!=8192||le32(p+28)!=0)return QWDET_BAD_TABLE;
 blob_bytes=le32(p+24);
 if(bytes<270368||blob_bytes!=bytes-270368)return QWDET_BAD_TABLE;
 last=le32(p+32);if(last!=0)return QWDET_BAD_TABLE;
 for(i=0;i<65535;i++){
  next=le32(p+32+(i+1)*4);
  if(next<=last||next>blob_bytes||next-last>128)return QWDET_BAD_TABLE;
  last=next;
 }
 if(last!=blob_bytes)return QWDET_BAD_TABLE;
 /* All14true specials are contiguous32451..32464 in this pinned model.
  * The8following added-but-nonspecial tokens must never be skipped. */
 for(i=0;i<65536;i++)if(((p[262176+i/8]>>(i%8))&1u)!=(unsigned)(i>=32451&&i<=32464))return QWDET_BAD_TABLE;
 d->offsets=p+32;d->flags=p+262176;d->blob=p+270368;d->blob_bytes=blob_bytes;return 0;
}
int qwdet_begin(qwdet *d,int skip_special,qwdet_emit_fn emit,void *opaque){
 if(!d->blob||!emit)return QWDET_BAD_STATE;
 qwdet_abort(d);d->skip_special=!!skip_special;d->emit=emit;d->opaque=opaque;d->active=1;return 0;
}
int qwdet_token(qwdet *d,uint32_t id){
 uint32_t a,b;int r;
 if(!d->active||d->failed)return QWDET_BAD_STATE;
 if(id>=65535)return QWDET_BAD_ID;
 if(d->skip_special&&(d->flags[id/8]&(1u<<(id%8))))return 0;
 a=le32(d->offsets+id*4);b=le32(d->offsets+(id+1)*4);
 /* Immutable initialized table was validated once. Bounds still checked before
  * each DDR-backed access so an invalid ID/offset cannot wrap an address. */
 if(b<=a||b>d->blob_bytes||b-a>128){d->failed=1;return QWDET_BAD_TABLE;}
 while(a<b){if((r=feed(d,d->blob[a++])))return r;}return 0;
}
int qwdet_finish(qwdet *d){int r;if(!d->active||d->failed)return QWDET_BAD_STATE;
 if(d->used){if((r=replacement(d)))return r;}qwdet_abort(d);return 0;}
