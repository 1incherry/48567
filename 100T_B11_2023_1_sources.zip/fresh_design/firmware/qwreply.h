#ifndef QWREPLY_H
#define QWREPLY_H
#include "qwobs.h"
/* Exact legacy av_wire.reply_payload(context, "HISTORY "+model_text).
 * This80-byte ASCII display view is explicitly a historical explanation,
 * never an action. Full Chinese answer stays unchanged on UTF8 UART.
 * model_text is strictUTF8 up to73728B. Non-ASCII codepoints become one '?'.
 * Fixed108-byte payload is valid only after return0; ignore it on errors. */
int qwreply_pack(const qwobs_record *record,const uint8_t *model_text,
 size_t text_bytes,uint8_t payload[108]);
#endif
