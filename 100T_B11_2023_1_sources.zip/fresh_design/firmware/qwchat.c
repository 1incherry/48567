#include "qwchat.h"
static const uint8_t begin[]="<|im_start|>";
static const uint8_t end[]="<|im_end|>";
static const uint8_t eof[]="<|endoftext|>";
static const uint8_t system_role[]="system\n";
static const uint8_t user_role[]="user\n";
static const uint8_t assistant_role[]="assistant\n";
static int contains(const uint8_t *p,size_t n,const uint8_t *needle,size_t m){
 size_t i,j;
 if(n<m)return 0;
 for(i=0;i<=n-m;i++){
  for(j=0;j<m && p[i+j]==needle[j];j++){}
  if(j==m)return 1;
 }
 return 0;
}
static int append(uint8_t *out,size_t *used,const uint8_t *data,size_t n){
 size_t i;
 if(n>QWENC_INPUT_LIMIT-*used)return QWCHAT_RENDER_LIMIT;
 for(i=0;i<n;i++)out[*used+i]=data[i];
 *used+=n;return 0;
}
int qwchat_prepare(const qwenc *encoder,const qwchat_message *messages,size_t count,
 uint32_t max_new,uint8_t rendered[QWENC_INPUT_LIMIT],size_t *rendered_bytes,
 uint16_t ids[QWCHAT_CONTEXT],size_t *written,qwenc_workspace *work){
 size_t i,used=0,tokens=0;int rc;
 if(written)*written=0;
 if(rendered_bytes)*rendered_bytes=0;
 if(!encoder||!rendered||!ids||!written||!rendered_bytes||!work||
    (!messages&&count)||count>QWCHAT_MESSAGE_LIMIT||max_new<1||max_new>QWCHAT_MAX_NEW)
  return QWCHAT_ARGUMENT;
 for(i=0;i<count;i++){
  const qwchat_message *m=messages+i;const uint8_t *role;size_t role_bytes;
  if(m->role>QWCHAT_ASSISTANT||(!m->content&&m->bytes))return QWCHAT_ARGUMENT;
  if(m->bytes>QWENC_INPUT_LIMIT)return QWCHAT_RENDER_LIMIT;
  if(contains(m->content,m->bytes,begin,sizeof(begin)-1)||
     contains(m->content,m->bytes,end,sizeof(end)-1)||
     contains(m->content,m->bytes,eof,sizeof(eof)-1))return QWCHAT_DELIMITER;
  if(m->role==QWCHAT_SYSTEM){role=system_role;role_bytes=sizeof(system_role)-1;}
  else if(m->role==QWCHAT_USER){role=user_role;role_bytes=sizeof(user_role)-1;}
  else{role=assistant_role;role_bytes=sizeof(assistant_role)-1;}
  if((rc=append(rendered,&used,begin,sizeof(begin)-1))!=0)return rc;
  if((rc=append(rendered,&used,role,role_bytes))!=0)return rc;
  if((rc=append(rendered,&used,m->content,m->bytes))!=0)return rc;
  if((rc=append(rendered,&used,end,sizeof(end)-1))!=0)return rc;
  if((rc=append(rendered,&used,(const uint8_t *)"\n",1))!=0)return rc;
 }
 if((rc=append(rendered,&used,begin,sizeof(begin)-1))!=0)return rc;
 if((rc=append(rendered,&used,assistant_role,sizeof(assistant_role)-1))!=0)return rc;
 rc=qwenc_encode(encoder,rendered,used,ids,QWCHAT_CONTEXT-max_new,&tokens,work);
 if(rc==QWENC_OUTPUT_FULL)return QWCHAT_CONTEXT_LIMIT;
 if(rc!=0)return rc;
 if(!tokens||tokens+max_new>QWCHAT_CONTEXT)return QWCHAT_CONTEXT_LIMIT;
 *rendered_bytes=used;*written=tokens;return 0;
}
