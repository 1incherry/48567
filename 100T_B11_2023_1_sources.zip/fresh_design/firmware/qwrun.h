#ifndef QWRUN_H
#define QWRUN_H
#include "qwchat.h"
#include "qwdet.h"
#define QWR_ANSWER_BYTES (192u*128u*3u)
enum { QWR_IDLE=0,QWR_ACQUIRE,QWR_PREPARE,QWR_ZERO,QWR_PROMPT,
 QWR_WAIT_DONE,QWR_DRAIN,QWR_ANSWER_READY,QWR_REJECT_READY,
 QWR_RELEASE_QUIET,QWR_RELEASE_CONFIRM,QWR_DONE,QWR_FAILED };
enum { QWR_ARGUMENT=-100,QWR_IO=-101,QWR_NOT_IDLE=-102,QWR_LEASE=-103,
 QWR_CHECKPOINT=-104,QWR_TIMEOUT=-105,QWR_CORE=-106,QWR_RESULT=-107,
 QWR_ZERO_ERROR=-108,QWR_OUTPUT=-109 };
/* Checked MMIO callbacks return 0 only on a completed OKAY R/B response.
 * zero_start/poll must clear exactly the supplied interval; poll=1 means all
 * writes and their B responses completed, 0 means pending, <0 means error.
 * now is a monotonic unsigned tick; timeout must be less than 2^31 ticks.
 * No callback may silently retry uncertain writes or discard bus errors. */
typedef struct {
 void *opaque;
 int (*read32)(void *,uint32_t,uint32_t *);
 int (*write32)(void *,uint32_t,uint32_t);
 int (*zero_start)(void *,uint32_t,uint32_t);
 int (*zero_poll)(void *);
} qwrun_io;
typedef struct {
 qwenc *encoder;qwdet *decoder;qwenc_workspace *workspace;qwrun_io io;
 uint8_t *rendered,*answer;uint16_t *prompt;
 const qwchat_message *messages;size_t message_count,rendered_bytes,prompt_count;
 uint32_t state,error,max_new,deadline,timeout,prompt_sent,result_count,drained;
 size_t answer_bytes;uint8_t saw_last;
} qwrun;
/* Decoder/encoder tables are validated at one-time initialization, under the
 * same protected memory owner. All buffers (including context) stay immutable
 * to other masters. rendered=4096B, prompt=512 uint16, answer=73728B in DDR.
 * Messages and content remain valid through PREPARE. There is no heap. */
int qwrun_init(qwrun *r,qwenc *e,qwdet *d,qwenc_workspace *w,qwrun_io io,
 uint8_t *rendered,uint16_t *prompt,uint8_t *answer);
int qwrun_begin(qwrun *r,const qwchat_message *messages,size_t count,
 uint32_t max_new,uint32_t now,uint32_t timeout);
/* One bounded controller step except the bounded C tokenizer in PREPARE.
 * Answer is available only at ANSWER_READY; REJECT_READY carries a local
 * input error, never a generated model answer. FAILED retains ownership. */
int qwrun_poll(qwrun *r,uint32_t now);
/* Invoke only after complete answer/error transport acceptance, including
 * framing/trailing CRC, or pass accepted=0 to fail closed. */
int qwrun_transport_done(qwrun *r,int accepted,uint32_t now);
#endif
