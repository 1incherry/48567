#include "qwsnapshot.h"
#define BASE 0xc1000000u
int qwsnapshot_try(qwsnapshot_io io,uint8_t body[256],qwobs_record *record,uint32_t *number){
 uint32_t v,status,before,after,i;
 if(!io.read32||!io.write32||!body||!record||!number)return QWS_ARGUMENT;
 if(io.read32(io.opaque,BASE,&v))return QWS_IO;
 if(v!=0x4e545232u)return QWS_ABI;
 if(io.read32(io.opaque,BASE+4,&status))return QWS_IO;
 if(status&32u)return QWS_STATUS;
 if(io.write32(io.opaque,BASE+0x10,2))return QWS_IO;
 if(io.read32(io.opaque,BASE+0x18,&v))return QWS_IO;
 if(!v)return QWS_UNAVAILABLE;
 if(v!=1u)return QWS_STATUS;
 if(io.read32(io.opaque,BASE+4,&status))return QWS_IO;
 if((status&34u)!=2u)return QWS_STATUS;
 if(io.read32(io.opaque,BASE+0x0c,&before))return QWS_IO;
 for(i=0;i<64;i++){
  if(io.read32(io.opaque,BASE+0x100+i*4,&v))return QWS_IO;
  body[i*4]=(uint8_t)(v>>24);body[i*4+1]=(uint8_t)(v>>16);
  body[i*4+2]=(uint8_t)(v>>8);body[i*4+3]=(uint8_t)v;
 }
 if(io.read32(io.opaque,BASE+0x0c,&after))return QWS_IO;
 if(io.read32(io.opaque,BASE+4,&status))return QWS_IO;
 if((status&34u)!=2u)return QWS_STATUS;
 if(before!=after)return QWS_CHANGED;
 if(qwobs_decode(body,256,record))return QWS_SYNTAX;
 *number=before;return QWS_OK;
}
