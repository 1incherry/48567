#ifndef QWFRAME_H
#define QWFRAME_H
#include <stdint.h>
#include <stddef.h>
#define QWREPLY_CHUNK 1024u
#define QWREPLY_HEADER 20u
typedef struct {
 const uint8_t *payload;uint32_t length,position;uint16_t crc;uint8_t state;
} qwframe;
/* Payload remains immutable until done. Peek is stable under arbitrary UART
 * backpressure; pop is called only after that wire byte is actually accepted.
 * Same 7E/7D + LE16 length + CRC16-CCITT-FALSE protocol as UART ingress. */
int qwframe_init(qwframe *f,const uint8_t *payload,size_t bytes);
int qwframe_peek(const qwframe *f,uint8_t *wire_byte);
int qwframe_pop(qwframe *f);
/* Output payload is a binary QA/v1 header followed by an unmodified fragment
 * of the final UTF8 answer. Reassemble offset/total before UTF8 decoding.
 * kind1=actual generated answer, kind2=input rejection, kind3=runtime fault,
 * kind4=ready. Kind2..4 must have zero text bytes (never fake model answers).
 * Header: 'QA',version1,kind,LE32 request,LE32 offset,LE32 total,LE16 signed
 * status,flags bit0 final,reserved0. Buffer size must fit20+actual chunk bytes; status/ready need only20 bytes. */
int qwreply_chunk(uint8_t *buffer,size_t capacity,uint32_t request,uint8_t kind,
 int16_t status,const uint8_t *answer,uint32_t total,uint32_t offset,
 size_t *payload_bytes,uint32_t *next_offset);
#endif
