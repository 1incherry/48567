#include "qwfacts.h"
typedef struct {uint8_t *dst;size_t used,cap;int bad;} writer;
static void put(writer *w,const char *s){while(*s){if(w->used==w->cap){w->bad=1;return;}w->dst[w->used++]=(uint8_t)*s++;}}
static void decimal(writer *w,uint32_t n){char b[10];unsigned i=0;do{b[i++]=(char)('0'+n%10);n/=10;}while(n);while(i){char a[2]={b[--i],0};put(w,a);}}
int qwfacts_build(const qwobs_record *r,uint32_t snapshot,uint8_t *dst,size_t cap,size_t *bytes){
 writer w={dst,0,cap,0};uint32_t i;
 if(bytes)*bytes=0;
 if(!dst||!bytes||cap<1024)return -1;
 put(&w,"你是这套FPGA视觉与音频系统的中文助手。请用中文简洁回答，也可以解释FPGA和AMD。以下仅为最近收到的只读识别记录，不保证对应当前现场；请依据记录回答，不虚构状态，不下发控制指令。\n");
 if(!r){put(&w,"目前没有可用的识别记录。\n");}
 else {
  if(r->modality!=1&&r->modality!=2)return -1;
  if(r->modality==1&&r->roi_count>4)return -1;
  put(&w,"快照=");decimal(&w,snapshot);put(&w,"；来源=");decimal(&w,r->source);
  put(&w,"；序列=");decimal(&w,r->sequence);put(&w,"；运行epoch=");decimal(&w,r->runtime_epoch);
  if(r->modality==1){
   put(&w,"；类型=视觉；frame=");decimal(&w,r->frame_or_generation);
   put(&w,"；目标数=");decimal(&w,r->roi_count);put(&w,"。\n");
   for(i=0;i<r->roi_count;i++){
    const qwobs_roi *roi=r->roi+i;const char *label=qwobs_class_name(1,roi->class_id);if(!label)return -1;
    put(&w,"目标");decimal(&w,i+1);put(&w,"：类别=");put(&w,label);
    put(&w,"；类别编号=");decimal(&w,roi->class_id);put(&w,"。\n");
   }
  }else {
   const char *label=qwobs_class_name(2,r->audio_class);if(!label)return -1;
   put(&w,"；类型=音频；clip=");decimal(&w,r->session_or_clip);put(&w,"；类别=");put(&w,label);
   put(&w,"；类别编号=");decimal(&w,r->audio_class);put(&w,"。\n");
  }
 }
 if(w.bad)return -1;
 *bytes=w.used;return 0;
}
