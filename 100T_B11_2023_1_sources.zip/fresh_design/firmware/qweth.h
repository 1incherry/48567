#ifndef QWETH_H
#define QWETH_H
#include <stdint.h>
#include <stddef.h>
enum { QWE_ARGUMENT=-240,QWE_IO=-241,QWE_STATE=-242,QWE_CONTEXT=-243,
 QWE_TIMEOUT=-244,QWE_TX=-245,QWE_COUNT=-246 };
typedef struct {void *opaque;int (*read32)(void *,uint32_t,uint32_t *);
 int (*write32)(void *,uint32_t,uint32_t);} qweth_io;
typedef struct {
 qweth_io io;const uint8_t *body,*payload;
 uint32_t state,word,snapshot,before,deadline,last_status;int error;
} qweth;
/* Exact new CSR image with RO014 cumulative real reply_tx.done is required.
 * Addresses are CPU translated C1000000, not raw AXI41000000. Checked callbacks
 * return0 only on completed OKAY R/B. All buffers remain immutable/local until
 * done. No DDR access, lease command, inference GO, reset, reply retry or action.
 * The exclusive runtime controller must serialize snapshot/reply jobs. */
void qweth_init(qweth *r);
int qweth_begin(qweth *r,qweth_io io,const uint8_t body[256],uint32_t snapshot,
 const uint8_t payload[108],uint32_t now,uint32_t timeout);
/* One actual control transaction per call.0=pending,1=local AXIS/MAC input
 * accepted entire packet,negative=failed and retained until explicit reinit.
 * This is NOT peer receipt/ACK or current-scene/authentication authority.
 * Caller must retain ownership and halt on uncertain/error completion. */
int qweth_poll(qweth *r,uint32_t now);
#endif
