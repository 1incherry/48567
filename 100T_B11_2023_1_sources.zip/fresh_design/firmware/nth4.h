#ifndef NTH4_H
#define NTH4_H
#include <stddef.h>
#include <stdint.h>
#define NTH4_BYTES 256u
#define NTH4_HW_KIND 5u
/* New fixed body, separate from legacy NTR2/NAR2/HIS1/HNA1.
 * The origin gate MUST be supplied by the PL-only receiver/filter; a body flag
 * or a PS-supplied SHA does not authenticate a sender. Ethernet FCS is not a
 * cryptographic authenticator. No untrusted-network security is claimed here.
 */
typedef struct {
 uint64_t bridge_session,batch_id,nonce;
 uint32_t image_id,slot_generation,runtime_epoch,model_epoch;
 uint8_t key_session[16];
} nth4_expected;
typedef struct {
 uint32_t image_id,slot_generation,slot,roi_count,report_sequence;
 uint32_t camera_id,capture_session,capture_frame,capture_epoch,capture_model_epoch,capture_generation;
 uint8_t capture_key_session[16];
 uint32_t exec_camera,exec_session,exec_frame,exec_epoch,exec_generation,exec_model_epoch;
 uint8_t exec_key_session[16],descriptor[28];
 uint32_t candidate_index,class_id;
 int64_t logit;
 uint8_t image_sha256[32],result_sha256[32];
} nth4_record;
enum {NTH4_OK=0,NTH4_ARGUMENT=-1,NTH4_ORIGIN=-2,NTH4_SYNTAX=-3,
 NTH4_CONTEXT=-4,NTH4_INCOMPLETE=-5,NTH4_DUPLICATE=-6};
/* Failure never modifies output. This validates an actual frozen packet body;
 * it cannot turn PS metadata or test tokens into an authoritative NN result. */
int nth4_decode(const uint8_t *,size_t,uint32_t actual_frozen_hw_kind,
 int actual_mac_bad,const nth4_expected *,nth4_record *);
typedef struct {nth4_record records[4];uint32_t mask,count,report_sequence;} nth4_collection;
void nth4_collection_init(nth4_collection *);
int nth4_collection_add(nth4_collection *,const nth4_record *);
#endif
