#ifndef QWFACTS_H
#define QWFACTS_H
#include "qwobs.h"
/* Build a SYSTEM context, not a generated answer. A null record means no
 * available observation. A nonnull record must come from successful snapshot
 * syntax validation. No inference, UART, MMIO or action authority is here.
 * dst requires1024 bytes; reject smaller capacity. Output remains unpublished
 * on error (*bytes is zero); caller must ignore partially written dst. */
int qwfacts_build(const qwobs_record *record,uint32_t snapshot,uint8_t *dst,
 size_t capacity,size_t *bytes);
#endif
