#ifndef HST_NATIVE_H
#define HST_NATIVE_H
#include "history_control.h"
#define HST_NATIVE_UDP_FRAME 170u
#define HST_NATIVE_SUMMARY_FRAME 270u
typedef enum { HNT_OK=0,HNT_ARGUMENT,HNT_WIRE,HNT_CONTEXT,HNT_CONSUMED,HNT_NOT_READY } hnt_rc;
/* Native MAC frames exclude preamble/FCS. actual_mac_bad must be supplied by
 * actual MAC status. CRC/tuple checks are not cryptographic authentication.
 * 100T R20 has no HST1/HIS1/HSC1 dispatcher: this is a successor component. */
hnt_rc hnt_pack_query(const hsc_request *,uint32_t outer_sequence,uint8_t out[170]);
hnt_rc hnt_decode_query(const uint8_t *,size_t,int actual_mac_bad,hsc_request *);
/* The sole permitted consumption event is actual MCS: specified selected
 * context validated and committed to that query's private stable context and
 * real prefill. Mere Ethernet reception or a historical QWN1 is not this event.
 * No automatic timer, reconnect or synthetic complete calls this API. */
hnt_rc hnt_pack_consumed(const hsc_request *,int actual_private_context_prefill_entered,
 uint32_t outer_sequence,uint8_t out[170]);
hnt_rc hnt_accept_native(hsc_bridge *,const uint8_t *,size_t,int actual_mac_bad);
/* Fixed256B HIS1 single-record body carried in270B MAC frame. Magic/type is
 * distinct from real NTR2/NAR2. Every HIS1 view is explicitly PS_UNTRUSTED.
 * Optional full128 key ID is public metadata, not a trusted verdict/key.
 * Old R20 strict NTR2/NAR2 parser must continue rejecting this body. */
hnt_rc hnt_pack_summary(const hsc_bridge *,const uint32_t public_key_id[4],uint8_t out[270]);
typedef struct {
 hsc_request correlation;
 psh_slot record;
 uint32_t public_key_id[4];
 uint8_t status,key_present,ps_untrusted;
} hnt_summary;
hnt_rc hnt_decode_summary(const uint8_t *,size_t,int actual_mac_bad,
 const hsc_request *currently_outstanding,hnt_summary *);
#endif
