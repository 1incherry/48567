#include "hst_native.h"
#include <string.h>
static const uint8_t mac_ps[6]={2,0x50,0x52,0x58,0x70,0x35},mac_qwen[6]={2,0x50,0x52,0x58,0x31,0};
static uint16_t be16(const uint8_t *p){return (uint16_t)((unsigned)p[0]<<8|p[1]);}
static uint32_t be32(const uint8_t *p){return (uint32_t)p[0]<<24|(uint32_t)p[1]<<16|(uint32_t)p[2]<<8|p[3];}
static uint64_t be64(const uint8_t *p){return (uint64_t)be32(p)<<32|be32(p+4);}
static uint32_t le32(const uint8_t *p){return (uint32_t)p[0]|(uint32_t)p[1]<<8|(uint32_t)p[2]<<16|(uint32_t)p[3]<<24;}
static void w16(uint8_t *p,uint16_t v){p[0]=(uint8_t)(v>>8);p[1]=(uint8_t)v;}
static void w32(uint8_t *p,uint32_t v){p[0]=(uint8_t)(v>>24);p[1]=(uint8_t)(v>>16);p[2]=(uint8_t)(v>>8);p[3]=(uint8_t)v;}
static void w64(uint8_t *p,uint64_t v){w32(p,(uint32_t)(v>>32));w32(p+4,(uint32_t)v);}
static void wl32(uint8_t *p,uint32_t v){for(unsigned i=0;i<4;i++)p[i]=(uint8_t)(v>>(8*i));}
static void wl64(uint8_t *p,uint64_t v){wl32(p,(uint32_t)v);wl32(p+4,(uint32_t)(v>>32));}
static uint64_t le64(const uint8_t *p){return le32(p)|(uint64_t)le32(p+4)<<32;}
static int zeros(const uint8_t *p,size_t n){for(size_t i=0;i<n;i++)if(p[i])return 0;return 1;}
static uint16_t ipcheck(const uint8_t *p){uint32_t sum=0;for(unsigned i=0;i<20;i+=2)sum+=be16(p+i);while(sum>>16)sum=(sum&65535)+(sum>>16);return (uint16_t)~sum;}
static void udp_pack(const uint8_t payload[108],uint32_t seq,uint32_t seed,uint8_t *f){
 memset(f,0,170);memcpy(f,mac_ps,6);memcpy(f+6,mac_qwen,6);w16(f+12,0x800);f[14]=0x45;w16(f+16,156);w16(f+18,(uint16_t)seq);w16(f+20,0x4000);f[22]=64;f[23]=17;w32(f+26,0xc0a8010c);w32(f+30,0xc0a8010b);w16(f+24,ipcheck(f+14));w16(f+34,8081);w16(f+36,8081);w16(f+38,136);memcpy(f+42,"ETX1",4);w32(f+46,seq);w32(f+50,1);w32(f+54,seed);memcpy(f+58,payload,108);wl32(f+166,psh_crc32(f+42,124));
}
static int udp_valid(const uint8_t *f,size_t n,int bad){
 return f&&n==170&&!bad&&!memcmp(f,mac_ps,6)&&!memcmp(f+6,mac_qwen,6)&&be16(f+12)==0x800&&f[14]==0x45&&f[15]==0&&be16(f+16)==156&&be16(f+18)==(uint16_t)be32(f+46)&&be16(f+20)==0x4000&&f[22]==64&&f[23]==17&&ipcheck(f+14)==0&&be32(f+26)==0xc0a8010c&&be32(f+30)==0xc0a8010b&&be16(f+34)==8081&&be16(f+36)==8081&&be16(f+38)==136&&be16(f+40)==0&&!memcmp(f+42,"ETX1",4)&&be32(f+50)==1&&le32(f+166)==psh_crc32(f+42,124)&&zeros(f+106,60);
}
hnt_rc hnt_pack_query(const hsc_request *r,uint32_t seq,uint8_t out[170]){
 uint8_t body[108]={0};if(!out||hsc_encode(r,body,48)!=HSC_OK)return HNT_ARGUMENT;udp_pack(body,seq,0x48535431,out);return HNT_OK;
}
hnt_rc hnt_decode_query(const uint8_t *f,size_t n,int bad,hsc_request *r){
 if(!r)return HNT_ARGUMENT;
 if(!udp_valid(f,n,bad)||be32(f+54)!=0x48535431||hsc_decode(f+58,48,r)!=HSC_OK)return HNT_WIRE;
 return HNT_OK;
}
hnt_rc hnt_pack_consumed(const hsc_request *r,int entered,uint32_t seq,uint8_t out[170]){
 uint8_t p[108]={0};if(!r||!out||entered!=1||r->op!=HSC_QUERY||r->pane||!r->bridge_session||!r->nonce||!r->batch_id||!r->image_no||r->image_no>100)return HNT_ARGUMENT;
 memcpy(p,"HSC1",4);p[4]=1;p[5]=3;p[7]=1;wl64(p+8,r->bridge_session);wl64(p+16,r->nonce);wl64(p+24,r->batch_id);wl32(p+32,r->image_no);wl32(p+40,48);wl32(p+44,psh_crc32(p,44));udp_pack(p,seq,0x48534331,out);return HNT_OK;
}
hnt_rc hnt_accept_native(hsc_bridge *b,const uint8_t *f,size_t n,int bad){
 if(!b)return HNT_ARGUMENT;
 if(!udp_valid(f,n,bad))return HNT_WIRE;
 const uint8_t *p=f+58;
 if(be32(f+54)==0x48535431&&!memcmp(p,"HST1",4))return hsc_accept(b,p,48)==HSC_OK?HNT_OK:HNT_CONTEXT;
 if(be32(f+54)!=0x48534331||memcmp(p,"HSC1",4)||p[4]!=1||p[5]!=3||p[6]||p[7]!=1||le32(p+36)||le32(p+40)!=48||le32(p+44)!=psh_crc32(p,44))return HNT_WIRE;
 if(b->phase!=HSC_QUERY_HELD||b->active.op!=HSC_QUERY||b->active.pane||le64(p+8)!=b->bridge_session||le64(p+16)!=b->active.nonce||le64(p+24)!=b->active.batch_id||le32(p+32)!=b->active.image_no)return HNT_CONTEXT;
 return hsc_query_release(b,b->active.nonce)==HSC_OK?HNT_CONSUMED:HNT_CONTEXT;
}
static int correlate(const hsc_request *a,const hsc_request *b){return a&&b&&a->bridge_session==b->bridge_session&&a->nonce==b->nonce&&a->batch_id==b->batch_id&&a->image_no==b->image_no&&a->op==b->op&&a->pane==b->pane;}
static unsigned pane_index(unsigned p){return p==1?0:p==3?1:2;}
hnt_rc hnt_pack_summary(const hsc_bridge *b,const uint32_t key[4],uint8_t f[270]){
 if(!b||!f||b->phase==HSC_IDLE)return HNT_NOT_READY;
 const psh_slot *s;unsigned status;
 if(b->phase==HSC_QUERY_HELD){s=&b->snapshot;status=1;}
 else {status=b->phase==HSC_SELECT_PRESENTED?3:b->phase==HSC_LOCKED_ERROR?4:2;unsigned i=pane_index(b->active.pane);s=status==3?&b->history->current.snapshot[i]:&b->history->pending.snapshot[i];}
 if(!s->valid||s->batch_id!=b->active.batch_id||s->image_no!=b->active.image_no||s->roi_count>4)return HNT_CONTEXT;
 memset(f,0,270);memcpy(f,mac_qwen,6);memcpy(f+6,mac_ps,6);w16(f+12,0x88b6);uint8_t *p=f+14;memcpy(p,"HIS1",4);w16(p+4,1);w16(p+6,0x100);w64(p+8,b->bridge_session);w64(p+16,b->active.nonce);w64(p+24,s->batch_id);w32(p+32,s->image_no);p[36]=b->active.pane;p[37]=b->active.op;p[38]=(uint8_t)status;p[39]=1|(s->archived?2:0);
 w32(p+40,s->id.camera);w32(p+44,s->id.session);w32(p+48,s->id.frame);w32(p+52,s->id.runtime_epoch);w32(p+56,s->id.model_epoch);w32(p+60,s->raw_crc32);w32(p+64,s->error_code);w32(p+68,s->state);w32(p+72,s->roi_count);w32(p+92,256);
 if(key&&(key[0]|key[1]|key[2]|key[3])){p[39]|=4;for(unsigned i=0;i<4;i++)w32(p+76+4*i,key[i]);}
 for(unsigned i=0;i<s->roi_count;i++){const psh_roi_result *r=&s->rois[i];uint8_t *a=p+96+32*i;w16(a,r->box.x0);w16(a+2,r->box.y0);w16(a+4,r->box.x1);w16(a+6,r->box.y1);w32(a+8,r->done?r->class_id:UINT32_MAX);uint64_t bits=0;if(r->done)memcpy(&bits,&r->best_logit,8);w64(a+12,bits);w32(a+20,r->done?r->record_sequence:0);w32(a+24,r->done?1:0);}
 if(s->archived)memcpy(p+224,s->archive_sha256,32);
 return HNT_OK;
}
hnt_rc hnt_decode_summary(const uint8_t *f,size_t n,int bad,const hsc_request *expected,hnt_summary *out){
 uint8_t expected_wire[48];if(!out||!expected||hsc_encode(expected,expected_wire,48)!=HSC_OK)return HNT_ARGUMENT;
 if(!f||n!=270||bad||memcmp(f,mac_qwen,6)||memcmp(f+6,mac_ps,6)||be16(f+12)!=0x88b6)return HNT_WIRE;
 const uint8_t *p=f+14;if(memcmp(p,"HIS1",4)||be16(p+4)!=1||be16(p+6)!=0x100||(p[39]&~7)||!(p[39]&1)||be32(p+92)!=256)return HNT_WIRE;
 hnt_summary r;memset(&r,0,sizeof r);r.correlation=(hsc_request){be64(p+8),be64(p+16),be64(p+24),be32(p+32),p[37],p[36]};
 if(!correlate(&r.correlation,expected))return HNT_CONTEXT;
 r.status=p[38];if((expected->op==HSC_QUERY&&(r.status!=1&&r.status!=4))||(expected->op==HSC_SELECT&&(r.status<2||r.status>4)))return HNT_WIRE;
 psh_slot *s=&r.record;s->valid=1;s->batch_id=r.correlation.batch_id;s->image_no=r.correlation.image_no;s->id=(psh_identity){be32(p+40),be32(p+44),be32(p+48),be32(p+52),be32(p+56)};s->raw_crc32=be32(p+60);s->error_code=be32(p+64);s->state=(psh_state)be32(p+68);uint32_t count=be32(p+72);if(count>4||s->state<PSH_YOLO_PENDING||s->state>PSH_FAILED)return HNT_WIRE;s->roi_count=(uint8_t)count;
 if(!s->id.session||!s->id.frame||!s->id.runtime_epoch||!s->id.model_epoch||((s->state==PSH_FAILED)!=(s->error_code!=0)))return HNT_WIRE;
 r.ps_untrusted=1;r.key_present=(p[39]&4)!=0;s->archived=(p[39]&2)!=0;
 for(unsigned i=0;i<4;i++)r.public_key_id[i]=be32(p+76+4*i);
 if(r.key_present!=(!!(r.public_key_id[0]|r.public_key_id[1]|r.public_key_id[2]|r.public_key_id[3])))return HNT_WIRE;
 unsigned done=0;for(unsigned i=0;i<4;i++){
  const uint8_t *a=p+96+32*i;if(i>=count){if(!zeros(a,32))return HNT_WIRE;continue;}
  psh_roi_result *q=&s->rois[i];q->box=(psh_roi){be16(a),be16(a+2),be16(a+4),be16(a+6)};q->class_id=be32(a+8);uint64_t bits=be64(a+12);memcpy(&q->best_logit,&bits,8);q->record_sequence=be32(a+20);uint32_t d=be32(a+24);
  if(q->box.x0>=q->box.x1||q->box.x1>640||q->box.y0>=q->box.y1||q->box.y1>480||d>1||be32(a+28))return HNT_WIRE;
  q->done=(uint8_t)d;done+=d;
  if(d){if(q->class_id>=105||!q->record_sequence)return HNT_WIRE;}
  else if(q->class_id!=UINT32_MAX||bits||q->record_sequence)return HNT_WIRE;
 }
 if((s->state==PSH_YOLO_PENDING||s->state==PSH_NO_TARGET)&&count)return HNT_WIRE;
 if(s->state==PSH_CLASSIFIED&&(!count||done!=count))return HNT_WIRE;
 if(s->state==PSH_VIT_PENDING&&(!count||done==count))return HNT_WIRE;
 if(s->archived==zeros(p+224,32))return HNT_WIRE;
 if(s->archived)memcpy(s->archive_sha256,p+224,32);
 *out=r;return HNT_OK;
}
