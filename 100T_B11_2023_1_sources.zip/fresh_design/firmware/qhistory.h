#ifndef QHISTORY_H
#define QHISTORY_H
#include "hst_native.h"
#include "qwsnapshot.h"
typedef struct {uint64_t session,batch,nonce;} qh_config;
enum {QH_OK=0,QH_UNAVAILABLE=1,QH_ARGUMENT=-300,QH_IO=-301,QH_ABI=-302,QH_STATUS=-303,QH_CHANGED=-304,QH_SYNTAX=-305,QH_TIMEOUT=-306,QH_TX=-307};
/* Descriptor is initialization metadata, not an authenticator. Caller must
 * read these32B only while holding the actual DDR lease. Never in idle/no-lease. */
int qh_config_decode(const uint8_t data[32],qh_config *out);
/* Raw body stays in local BRAM. Frozen kind and full magic must agree; HIS1
 * remains PS_UNTRUSTED and is never returned as a qwobs_record. */
int qh_snapshot(qwsnapshot_io io,uint8_t body[256],uint32_t *kind,uint32_t *number);
int qh_decode(const uint8_t body[256],const hsc_request *,hnt_summary *);
/* Bounded SYSTEM facts only: no prewritten answer or authority/action. */
int qh_facts(const hnt_summary *,uint8_t *,size_t,size_t *);
typedef struct {qwsnapshot_io io;const uint8_t *payload;uint32_t seq,seed,state,word,before,deadline;int error;} qh_tx;
void qh_tx_init(qh_tx *);
/* Caller holds actual lease throughout. The checked bridge still enforces it;
 * no new privilege, force-clear, retry, or synthetic done exists here. */
int qh_tx_begin(qh_tx *,qwsnapshot_io,const uint8_t payload[108],uint32_t seq,uint32_t seed,uint32_t now,uint32_t timeout);
int qh_tx_poll(qh_tx *,uint32_t now);
#endif
