#include "qwenc.h"
static uint32_t u32(const uint8_t *p){return (uint32_t)p[0]|((uint32_t)p[1]<<8)|((uint32_t)p[2]<<16)|((uint32_t)p[3]<<24);}
static uint32_t field(const qwenc *c,uint32_t at){return u32(c->data+at);}
static int area(uint32_t size,uint32_t at,uint32_t count,uint32_t width){return at<=size&&count<=(size-at)/width;}
int qwenc_init(qwenc *c,const uint8_t *p,size_t n){
 if(!c||!p||n<128u||n>UINT32_MAX)return QWENC_BAD_TABLE;
 c->data=p;c->size=(uint32_t)n;
 if(field(c,0)!=0x31544e45u||field(c,4)!=1u||field(c,8)!=(uint32_t)n)return QWENC_BAD_TABLE;
 if(!area(c->size,field(c,12),field(c,16),12)||!area(c->size,field(c,20),field(c,24),12)||
    !area(c->size,field(c,28),field(c,32),4)||!area(c->size,field(c,36),field(c,40),8)||
    !area(c->size,field(c,44),field(c,48),12)||!area(c->size,field(c,52),256,2)||
    !area(c->size,field(c,56),field(c,60),8)||!area(c->size,field(c,64),field(c,68),16)||
    !area(c->size,field(c,72),field(c,76),1))return QWENC_BAD_TABLE;
 if(field(c,60)!=131072u||field(c,68)!=22u)return QWENC_BAD_TABLE;
 return QWENC_OK;
}
static uint32_t search_cp(const qwenc *c,uint32_t at,uint32_t count,uint32_t stride,uint32_t cp){
 uint32_t lo=0,hi=count;
 while(lo<hi){uint32_t mid=lo+(hi-lo)/2u;uint32_t x=u32(c->data+at+mid*stride);if(x<cp)lo=mid+1u;else hi=mid;}
 return lo<count&&u32(c->data+at+lo*stride)==cp?lo:UINT32_MAX;
}
static uint32_t klass(const qwenc *c,uint32_t cp){
 uint32_t i=search_cp(c,field(c,36),field(c,40),8,cp);
 return i==UINT32_MAX?0:u32(c->data+field(c,36)+i*8u+4u);
}
static uint32_t property(const qwenc *c,uint32_t cp){
 uint32_t at=field(c,12),lo=0,hi=field(c,16);
 while(lo<hi){uint32_t m=lo+(hi-lo)/2u;const uint8_t *p=c->data+at+m*12u;
  if(cp<u32(p))hi=m;else if(cp>u32(p+4))lo=m+1u;else return u32(p+8);}
 return 0;
}
static int decode_one(const uint8_t *s,size_t n,size_t *at,uint32_t *cp){
 if(*at>=n)return QWENC_BAD_UTF8;
 uint32_t a=s[(*at)++],v,min;unsigned more;
 if(a<128u){*cp=a;return 0;}
 if(a>=0xc2u&&a<=0xdfu){more=1;v=a&31u;min=0x80u;}
 else if(a>=0xe0u&&a<=0xefu){more=2;v=a&15u;min=0x800u;}
 else if(a>=0xf0u&&a<=0xf4u){more=3;v=a&7u;min=0x10000u;}
 else return QWENC_BAD_UTF8;
 if(more>n-*at)return QWENC_BAD_UTF8;
 for(unsigned i=0;i<more;i++){a=s[(*at)++];if((a&0xc0u)!=0x80u)return QWENC_BAD_UTF8;v=(v<<6)|(a&63u);}
 if(v<min||v>0x10ffffu||(v>=0xd800u&&v<=0xdfffu))return QWENC_BAD_UTF8;
 *cp=v;return 0;
}
static unsigned put_cp(uint8_t *p,uint32_t v){
 if(v<0x80u){p[0]=(uint8_t)v;return 1;}
 if(v<0x800u){p[0]=(uint8_t)(0xc0u|(v>>6));p[1]=(uint8_t)(0x80u|(v&63u));return 2;}
 if(v<0x10000u){p[0]=(uint8_t)(0xe0u|(v>>12));p[1]=(uint8_t)(0x80u|((v>>6)&63u));p[2]=(uint8_t)(0x80u|(v&63u));return 3;}
 p[0]=(uint8_t)(0xf0u|(v>>18));p[1]=(uint8_t)(0x80u|((v>>12)&63u));p[2]=(uint8_t)(0x80u|((v>>6)&63u));p[3]=(uint8_t)(0x80u|(v&63u));return 4;
}
static int append_ordered(const qwenc *c,qwenc_workspace *w,uint32_t *count,uint32_t cp){
 if(*count>=QWENC_CP_LIMIT)return QWENC_TOO_LONG;
 uint32_t k=klass(c,cp),i=(*count)++;
 while(k&&i&&klass(c,w->cp[i-1u])>k){w->cp[i]=w->cp[i-1u];--i;}
 w->cp[i]=cp;return 0;
}
static uint32_t combine(const qwenc *c,uint32_t a,uint32_t b){
 if(a>=0x1100u&&a<0x1113u&&b>=0x1161u&&b<0x1176u)return 0xac00u+((a-0x1100u)*21u+b-0x1161u)*28u;
 if(a>=0xac00u&&a<0xd7a4u&&(a-0xac00u)%28u==0u&&b>=0x11a8u&&b<0x11c3u)return a+b-0x11a7u;
 uint32_t lo=0,hi=field(c,48),at=field(c,44);
 while(lo<hi){uint32_t m=lo+(hi-lo)/2u;const uint8_t *p=c->data+at+m*12u;uint32_t x=u32(p),y=u32(p+4);
  if(a<x||(a==x&&b<y))hi=m;else if(a>x||(a==x&&b>y))lo=m+1u;else return u32(p+8);}
 return UINT32_MAX;
}
int qwenc_normalize(const qwenc *c,const uint8_t *text,size_t n,qwenc_workspace *w){
 if(n>QWENC_INPUT_LIMIT)return QWENC_TOO_LONG;
 uint32_t count=0,cp;size_t pos=0;int rc;
 while(pos<n){
  rc=decode_one(text,n,&pos,&cp);if(rc)return rc;
  if(cp>=0xac00u&&cp<0xd7a4u){uint32_t s=cp-0xac00u;
   if((rc=append_ordered(c,w,&count,0x1100u+s/588u)))return rc;
   if((rc=append_ordered(c,w,&count,0x1161u+(s%588u)/28u)))return rc;
   if(s%28u&&(rc=append_ordered(c,w,&count,0x11a7u+s%28u)))return rc;
  }else{
   uint32_t i=search_cp(c,field(c,20),field(c,24),12,cp);
   if(i==UINT32_MAX){if((rc=append_ordered(c,w,&count,cp)))return rc;}
   else{const uint8_t *p=c->data+field(c,20)+i*12u;uint32_t off=u32(p+4),len=u32(p+8);
    if(off>field(c,32)||len>field(c,32)-off)return QWENC_BAD_TABLE;
    for(uint32_t j=0;j<len;j++)if((rc=append_ordered(c,w,&count,u32(c->data+field(c,28)+(off+j)*4u))))return rc;
   }
  }
 }
 uint32_t out=count?1u:0u,starter=count?w->cp[0]:0,starter_pos=0,last=count?klass(c,starter):0;
 for(uint32_t i=1;i<count;i++){
  cp=w->cp[i];uint32_t k=klass(c,cp),joined=combine(c,starter,cp);
  if(joined!=UINT32_MAX&&(last<k||last==0)){w->cp[starter_pos]=joined;starter=joined;}
  else{if(k==0){starter_pos=out;starter=cp;}w->cp[out++]=cp;last=k;}
 }
 uint32_t bytes=0;
 for(uint32_t i=0;i<out;i++){w->offset[i]=bytes;if(bytes>QWENC_BYTE_LIMIT-4u)return QWENC_TOO_LONG;bytes+=put_cp(w->normalized+bytes,w->cp[i]);}
 w->offset[out]=bytes;w->cp_count=out;w->byte_count=bytes;return 0;
}
static uint32_t lower_contraction(uint32_t cp){if(cp>='A'&&cp<='Z')return cp+32u;if(cp==0x17fu)return 's';return cp;}
uint32_t qwenc_next_piece(const qwenc *c,const qwenc_workspace *w,uint32_t p){
 uint32_t n=w->cp_count;if(p>=n)return n;
 const uint32_t *s=w->cp;uint32_t mask=property(c,s[p]),i;
 if(s[p]=='\''&&p+1u<n){uint32_t a=lower_contraction(s[p+1u]);
  if(a=='s'||a=='t'||a=='m'||a=='d')return p+2u;
  if(p+2u<n){uint32_t b=lower_contraction(s[p+2u]);if((a=='r'&&b=='e')||(a=='v'&&b=='e')||(a=='l'&&b=='l'))return p+3u;}
 }
 i=p;
 if(!(mask&3u)&&s[p]!='\r'&&s[p]!='\n'&&p+1u<n&&(property(c,s[p+1u])&1u))++i;
 if(property(c,s[i])&1u){while(i<n&&(property(c,s[i])&1u))++i;return i;}
 if(mask&2u)return p+1u;
 i=p;
 if(s[i]==' '&&i+1u<n&&!(property(c,s[i+1u])&7u))++i;
 if(!(property(c,s[i])&7u)){
  while(i<n&&!(property(c,s[i])&7u))++i;
  while(i<n&&(s[i]=='\r'||s[i]=='\n'))++i;
  return i;
 }
 if(mask&4u){uint32_t last_nl=0;i=p;
  while(i<n&&(property(c,s[i])&4u)){if(s[i]=='\r'||s[i]=='\n')last_nl=i+1u;++i;}
  if(last_nl)return last_nl;
  if(i==n)return i;
  if(i-p>=2u)return i-1u;
  return i;
 }
 return p+1u;
}
static uint32_t merged_pair(const qwenc *c,uint16_t a,uint16_t b){
 uint32_t key=((uint32_t)a<<16)|b,slots=field(c,60),mask=slots-1u;
 uint32_t hashed=key;
 hashed^=hashed>>16;hashed*=0x7feb352du;hashed^=hashed>>15;hashed*=0x846ca68bu;hashed^=hashed>>16;
 uint32_t i=hashed&mask;
 for(uint32_t attempts=0;attempts<slots;attempts++,i=(i+1u)&mask){const uint8_t *p=c->data+field(c,56)+i*8u;uint32_t k=u32(p);
  if(k==UINT32_MAX)return UINT32_MAX;
  if(k==key)return u32(p+4);}
 return UINT32_MAX;
}
static int encode_span(const qwenc *c,const uint8_t *s,size_t n,uint16_t *out,size_t cap,size_t *used,qwenc_workspace *w){
 int rc=qwenc_normalize(c,s,n,w);if(rc)return rc;
 uint32_t start=0;
 while(start<w->cp_count){uint32_t end=qwenc_next_piece(c,w,start);if(end<=start||end>w->cp_count)return QWENC_BAD_TABLE;
  uint32_t begin_byte=w->offset[start],len=w->offset[end]-begin_byte;
  for(uint32_t i=0;i<len;i++){const uint8_t *p=c->data+field(c,52)+w->normalized[begin_byte+i]*2u;w->word[i]=(uint16_t)((uint16_t)p[0]|((uint16_t)p[1]<<8));}
  while(len>=2u){uint32_t best=UINT32_MAX,bestpos=0,packed=0;
   for(uint32_t j=0;j+1u<len;j++){uint32_t v=merged_pair(c,w->word[j],w->word[j+1u]);if(v!=UINT32_MAX&&(v>>16)<best){best=v>>16;bestpos=j;packed=v;}}
   if(best==UINT32_MAX)break;
   if((packed&65535u)==65535u)return QWENC_BAD_TABLE;
   w->word[bestpos]=(uint16_t)packed;
   for(uint32_t j=bestpos+1u;j+1u<len;j++)w->word[j]=w->word[j+1u];
   --len;
  }
  if(len>cap-*used)return QWENC_OUTPUT_FULL;
  for(uint32_t i=0;i<len;i++)out[(*used)++]=w->word[i];
  start=end;
 }
 return 0;
}
static int added_at(const qwenc *c,const uint8_t *s,size_t n,uint32_t *id,uint32_t *len){
 uint32_t longest=0,result=0;
 for(uint32_t i=0;i<field(c,68);i++){const uint8_t *p=c->data+field(c,64)+i*16u;uint32_t token=u32(p),off=u32(p+4),l=u32(p+8);
  if(off>field(c,76)||l>field(c,76)-off)return QWENC_BAD_TABLE;
  if(l<=n&&l>longest){uint32_t j=0;while(j<l&&s[j]==c->data[field(c,72)+off+j])++j;if(j==l){longest=l;result=token;}}
 }
 *id=result;*len=longest;return 0;
}
int qwenc_encode(const qwenc *c,const uint8_t *s,size_t n,uint16_t *out,size_t cap,size_t *used,qwenc_workspace *w){
 if(!used||!w||!out||(!s&&n))return QWENC_BAD_UTF8;
 *used=0;if(n>QWENC_INPUT_LIMIT)return QWENC_TOO_LONG;
 /* Validate the complete original UTF8 even if some added words are skipped. */
 size_t check=0;uint32_t cp;while(check<n){int rc=decode_one(s,n,&check,&cp);if(rc)return rc;}
 size_t pos=0,span=0;
 while(pos<n){uint32_t id,len;int rc=added_at(c,s+pos,n-pos,&id,&len);if(rc)return rc;
  if(len){if(pos>span&&(rc=encode_span(c,s+span,pos-span,out,cap,used,w)))return rc;
   if(id>=65535u)return QWENC_BAD_TABLE;
   if(*used>=cap)return QWENC_OUTPUT_FULL;
   out[(*used)++]=(uint16_t)id;pos+=len;span=pos;
  }else ++pos;
 }
 if(pos>span)return encode_span(c,s+span,pos-span,out,cap,used,w);
 return 0;
}
