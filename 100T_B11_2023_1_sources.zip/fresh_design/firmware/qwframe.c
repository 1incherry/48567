#include "qwframe.h"
enum { HEAD=0,BODY=1,ESCAPED=2,TAIL=3,DONE=4 };
static uint16_t crcbyte(uint16_t crc,uint8_t value){
 uint32_t i;crc^=(uint16_t)value<<8;
 for(i=0;i<8;i++)crc=(uint16_t)((crc<<1)^((crc&0x8000u)?0x1021u:0u));
 return crc;
}
static uint8_t source(const qwframe *f){
 if(f->position==0)return (uint8_t)f->length;
 if(f->position==1)return (uint8_t)(f->length>>8);
 if(f->position<f->length+2u)return f->payload[f->position-2u];
 if(f->position==f->length+2u)return (uint8_t)f->crc;
 return (uint8_t)(f->crc>>8);
}
int qwframe_init(qwframe *f,const uint8_t *payload,size_t bytes){
 size_t i;uint16_t crc=0xffffu;
 if(!f||!payload||bytes<1||bytes>65535u)return -1;
 crc=crcbyte(crc,(uint8_t)bytes);crc=crcbyte(crc,(uint8_t)(bytes>>8));
 for(i=0;i<bytes;i++)crc=crcbyte(crc,payload[i]);
 f->payload=payload;f->length=(uint32_t)bytes;f->position=0;f->crc=crc;f->state=HEAD;
 return 0;
}
int qwframe_peek(const qwframe *f,uint8_t *wire_byte){
 uint8_t value;
 if(!f||!wire_byte||f->state>DONE)return -1;
 if(f->state==DONE)return 0;
 if(f->state==HEAD||f->state==TAIL){*wire_byte=0x7eu;return 1;}
 value=source(f);
 if(f->state==ESCAPED)*wire_byte=value^0x20u;
 else *wire_byte=(value==0x7eu||value==0x7du)?0x7du:value;
 return 1;
}
int qwframe_pop(qwframe *f){
 uint8_t value;
 if(!f||f->state>=DONE)return -1;
 if(f->state==HEAD){f->state=BODY;return 0;}
 if(f->state==TAIL){f->state=DONE;return 0;}
 value=source(f);
 if(f->state==BODY&&(value==0x7eu||value==0x7du)){f->state=ESCAPED;return 0;}
 f->position++;f->state=f->position==f->length+4u?TAIL:BODY;return 0;
}
static void store32(uint8_t *p,uint32_t value){
 p[0]=(uint8_t)value;p[1]=(uint8_t)(value>>8);p[2]=(uint8_t)(value>>16);p[3]=(uint8_t)(value>>24);
}
int qwreply_chunk(uint8_t *buffer,size_t capacity,uint32_t request,uint8_t kind,
 int16_t status,const uint8_t *answer,uint32_t total,uint32_t offset,
 size_t *payload_bytes,uint32_t *next_offset){
 uint32_t i,n;
 if(payload_bytes)*payload_bytes=0;
 if(!buffer||!payload_bytes||!next_offset||
   kind<1||kind>4||total>73728u||offset>total||(!answer&&total)||
   (kind!=1&&(total||offset))||(kind==1&&status))return -1;
 n=total-offset;if(n>QWREPLY_CHUNK)n=QWREPLY_CHUNK;
 if(capacity<QWREPLY_HEADER+n)return -1;
 buffer[0]='Q';buffer[1]='A';buffer[2]=1;buffer[3]=kind;
 store32(buffer+4,request);store32(buffer+8,offset);store32(buffer+12,total);
 buffer[16]=(uint8_t)status;buffer[17]=(uint8_t)((uint16_t)status>>8);
 buffer[18]=(uint8_t)(offset+n==total);buffer[19]=0;
 for(i=0;i<n;i++)buffer[QWREPLY_HEADER+i]=answer[offset+i];
 *payload_bytes=QWREPLY_HEADER+n;*next_offset=offset+n;return 0;
}
