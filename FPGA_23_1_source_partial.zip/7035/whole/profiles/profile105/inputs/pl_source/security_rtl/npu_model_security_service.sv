`timescale 1ns/1ps
// Static model authority and private page cache. This is a trusted internal PL
// service, not an untrusted descriptor authorizer. The consumer's role, tensor,
// tile, epoch and expected page must be checked by the enclosing PL sequencer.
module npu_model_security_service #(
 parameter [255:0] TRUSTED_PUBLIC_KEY=256'h31392d4ac05b8b49da13706566916a20c0e10dbbd97b17868377d4821bb4b1a5
)(input wire clk,rst_n,cancel,
 input wire manifest_start,output wire manifest_ready,
 input wire msg_valid,input wire [31:0] msg_data,input wire msg_last,output wire msg_ready,
 input wire sig_valid,input wire [31:0] sig_data,input wire sig_last,output wire sig_ready,
 input wire page_request,input wire [31:0] expected_page_index,output wire page_request_ready,
 input wire page_valid,input wire [31:0] page_data,output wire page_ready,
 input wire proof_valid,input wire [31:0] proof_data,output wire proof_ready,
 input wire cache_read,input wire [9:0] cache_read_addr,
 output wire cache_read_valid,output wire [31:0] cache_read_data,
 output wire model_authorized,cache_valid,busy,fault,manifest_done,page_done,
 output wire [31:0] session_epoch,cached_page_index,
 output wire [31:0] signature_elapsed_cycles,signature_compute_cycles,page_elapsed_cycles,
 output wire [7:0] signature_error,policy_error,page_error,
 output wire [31:0] debug_progress,debug_control);
 reg phase_model;wire slh_busy,slh_done,signature_valid,ownership_fault,slh_fault;
 wire [127:0] computed_root;wire page_busy,policy_done,authority_raw;
 wire [255:0] authorized_root;wire [63:0] authorized_version;
 wire [767:0] captured_message;
 wire compressor_reset,compressor_start,compressor_busy,compressor_done;
 wire [511:0] compressor_block;wire [255:0] compressor_iv,compressor_state;
 assign fault=ownership_fault || (policy_done&&policy_error!=0) || (page_done&&page_error!=0);
 assign model_authorized=authority_raw && !fault && !cancel;
 assign manifest_done=policy_done;
 assign manifest_ready=!phase_model && !slh_busy && !page_busy && !cancel && !ownership_fault;
 wire accepted_manifest=manifest_start&&manifest_ready;
 assign page_request_ready=phase_model && model_authorized && !page_busy && !cancel;
 wire accepted_page=page_request&&page_request_ready;
 assign busy=slh_busy||page_busy;
 always @(posedge clk)begin
  if(!rst_n || cancel)phase_model<=0;
  else if(!phase_model && authority_raw && !slh_busy)phase_model<=1;
 end
 reg [767:0] message_capture;
 assign captured_message=message_capture;
 always @(posedge clk)begin
  if(!rst_n || cancel || accepted_manifest)message_capture<=0;
  else if(msg_valid&&msg_ready)message_capture<={message_capture[735:0],msg_data};
 end
 slh_verify_shared_model_top verifier(.clk(clk),.rst_n(rst_n),.start(accepted_manifest),.cancel(cancel),
  .phase_model(phase_model),.model_rst_n(compressor_reset),.model_start(compressor_start),
  .model_block(compressor_block),.model_iv(compressor_iv),.model_busy(compressor_busy),.model_done(compressor_done),.model_state(compressor_state),
  .public_key(TRUSTED_PUBLIC_KEY),.external_pure(1'b1),.message_length(16'd96),.context_length(8'd0),
  .msg_valid(msg_valid),.msg_data(msg_data),.msg_bytes(3'd4),.msg_last(msg_last),.msg_ready(msg_ready),
  .sig_valid(sig_valid),.sig_word(sig_data),.sig_keep(4'hf),.sig_last(sig_last),.sig_ready(sig_ready),
  .busy(slh_busy),.done(slh_done),.auth_valid(signature_valid),.fault(slh_fault),.fault_code(signature_error),.computed_root(computed_root),
  .elapsed_cycles(signature_elapsed_cycles),.compute_cycles(signature_compute_cycles),.profile_capture(),.profile_hmsg(),.profile_fors(),.profile_hypertree(),
  .profile_feed(),.profile_wait(),.profile_ram(),.ownership_fault(ownership_fault));
 npu_model_authority authority(.clk(clk),.rst_n(rst_n),.verify_begin(accepted_manifest),
  .revoke(cancel||ownership_fault||(page_done&&page_error!=0)),
  .verification_done(slh_done),.signature_valid(signature_valid),.verification_error(signature_error),.verified_message(captured_message),
  .model_authorized(authority_raw),.model_root(authorized_root),.model_version(authorized_version),.session_epoch(session_epoch),
  .policy_done(policy_done),.policy_error(policy_error));
 wire raw_cache_valid,raw_read_valid;wire [31:0] raw_read_data;
 assign cache_valid=raw_cache_valid && model_authorized;
 assign cache_read_valid=raw_read_valid && model_authorized;
 assign cache_read_data=cache_read_valid?raw_read_data:32'd0;
 npu_verified_page_cache cache(.clk(clk),.rst_n(rst_n&&phase_model),.start(accepted_page),.cancel(cancel),
  .model_authorized(model_authorized),.model_id(64'h4e50554156533031),.model_version(authorized_version),.session_epoch(session_epoch),
  .page_index(expected_page_index),.model_root(authorized_root),.page_valid(page_valid),.page_data(page_data),.page_ready(page_ready),
  .proof_valid(proof_valid),.proof_data(proof_data),.proof_ready(proof_ready),.busy(page_busy),.cache_valid(raw_cache_valid),.done(page_done),.error_code(page_error),
  .elapsed_cycles(page_elapsed_cycles),.cached_page_index(cached_page_index),.debug_progress(debug_progress),.debug_control(debug_control),.cache_read(cache_read&&model_authorized),.cache_read_addr(cache_read_addr),
  .cache_read_valid(raw_read_valid),.cache_read_data(raw_read_data),.compressor_reset(compressor_reset),.compressor_start(compressor_start),
  .compressor_block(compressor_block),.compressor_iv(compressor_iv),.compressor_busy(compressor_busy),.compressor_done(compressor_done),.compressor_state(compressor_state));
endmodule
