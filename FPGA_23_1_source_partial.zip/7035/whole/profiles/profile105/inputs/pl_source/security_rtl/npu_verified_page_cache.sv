`timescale 1ns/1ps
// A private 4 KiB cache, readable only after its indexed Merkle proof succeeds.
// The request context comes from trusted PL policy/control. DDR/CPU only supply
// page and proof bytes. No read-after-authentication from untrusted DDR occurs.
// External compressor ports allow time sharing the SLH R3/E1 SHA core.
module npu_verified_page_cache #(
 parameter integer LEAF_COUNT=5435,DEPTH=13,TIMEOUT_CYCLES=1048575
)(input wire clk,rst_n,start,cancel,
 input wire model_authorized,input wire [63:0] model_id,model_version,
 input wire [31:0] session_epoch,page_index,input wire [255:0] model_root,
 input wire page_valid,input wire [31:0] page_data,output wire page_ready,
 input wire proof_valid,input wire [31:0] proof_data,output wire proof_ready,
 output wire busy,cache_valid,output reg done,output reg [7:0] error_code,
 output reg [31:0] elapsed_cycles,output reg [31:0] cached_page_index,
 output wire [31:0] debug_progress,debug_control,
 input wire cache_read,input wire [9:0] cache_read_addr,
 output wire cache_read_valid,output wire [31:0] cache_read_data,
 output wire compressor_reset,compressor_start,
 output wire [511:0] compressor_block,output wire [255:0] compressor_iv,
 input wire compressor_busy,compressor_done,input wire [255:0] compressor_state);
 localparam IDLE=0,LEAF_START=1,PREFIX=2,PAGE=3,LEAF_WAIT=4,
            PROOF=5,PARENT_START=6,PARENT_FEED=7,PARENT_WAIT=8,FINISH=9,FAILED=10;
 reg [3:0] state,failure_state;reg hash_enable;
 reg [63:0] saved_id,saved_version;reg [31:0] saved_epoch;
 reg [255:0] saved_root,current_digest,sibling;reg [4:0] level;
 reg [5:0] prefix_pos;reg [6:0] parent_pos;
 reg [10:0] words_loaded;reg [12:0] bytes_fed;
 reg buffer_valid;reg [31:0] buffer_word;reg [2:0] buffer_offset;
 reg [3:0] proof_words;
 reg authenticated,rd_valid;reg [31:0] rd_word;
 (* ram_style="block" *) reg [31:0] cache[0:1023];
 wire active=state!=IDLE && state!=FINISH && state!=FAILED;
 wire context_live=model_authorized && session_epoch==saved_epoch;
 assign busy=active;
 assign cache_valid=rst_n && authenticated && context_live && !start && !cancel;
 assign cache_read_valid=rd_valid && cache_valid;
 assign cache_read_data=cache_read_valid?rd_word:32'd0;
 assign page_ready=state==PAGE && !buffer_valid && words_loaded<1024 && context_live && !cancel && !start;
 assign proof_ready=state==PROOF && proof_words<8 && context_live && !cancel && !start;
 wire [199:0] prefix={8'h00,saved_id,saved_version,cached_page_index,32'd4096};
 wire right_branch=(cached_page_index>>level)&1;
 wire [519:0] parent=right_branch?{8'h01,sibling,current_digest}:{8'h01,current_digest,sibling};
 wire hash_ready,hash_done,hash_fault;wire [255:0] hash_digest;wire [2:0] capacity;
 reg [31:0] hash_word;reg [2:0] hash_count;reg hash_valid;
 wire hash_start=state==LEAF_START || state==PARENT_START;
 // A context change/cancel clears the hash FSM and the shared compressor's
 // model reset. No old completion can authenticate a later session.
 // Only a registered transaction-control bit drives the asynchronous SHA
 // reset. Combining active/context/start here can glitch on the same edge
 // that captures a new session and desynchronize the synchronous word FSM
 // from the asynchronous compressor FSM in real FPGA routing.
 wire hash_rst_n=rst_n && hash_enable;
 assign debug_progress={state==FAILED?failure_state:state,words_loaded,bytes_fed,proof_words};
 assign debug_control={15'd0,level,buffer_valid,buffer_offset,hash_rst_n,hash_ready,hash_done,hash_fault,
                       compressor_reset,compressor_start,compressor_busy,compressor_done};
 always @*begin
  hash_word=0;hash_count=0;hash_valid=0;
  if(state==PREFIX)begin
   hash_count=25-prefix_pos<4?25-prefix_pos:4;
   if(hash_count>capacity)hash_count=capacity;
   hash_valid=hash_count!=0;
   for(integer b=0;b<4;b=b+1)if(b<hash_count)hash_word[31-b*8-:8]=prefix[199-(prefix_pos+b)*8-:8];
  end else if(state==PAGE && buffer_valid)begin
   hash_count=4-buffer_offset;
   if(hash_count>capacity)hash_count=capacity;
   hash_valid=hash_count!=0;
   hash_word=buffer_word<<(buffer_offset*8);
  end else if(state==PARENT_FEED)begin
   hash_count=65-parent_pos<4?65-parent_pos:4;
   if(hash_count>capacity)hash_count=capacity;
   hash_valid=hash_count!=0;
   for(integer b=0;b<4;b=b+1)if(b<hash_count)hash_word[31-b*8-:8]=parent[519-(parent_pos+b)*8-:8];
  end
 end
 slh_sha256_word_stream_shared23 #(.EXTERNAL_COMPRESSOR(1)) page_hash(
  .clk(clk),.rst_n(hash_rst_n),.start(hash_start),.length(state==LEAF_START?16'd4121:16'd65),
  .seed_hash(1'b0),.seed_cached(),.short_valid(1'b0),.short_data(512'd0),
  .valid(hash_valid),.data(hash_word),.input_bytes(hash_count),.capacity(capacity),.ready(hash_ready),
  .busy(),.done(hash_done),.fault(hash_fault),.digest(hash_digest),
  .compressor_reset(compressor_reset),.compressor_start(compressor_start),
  .compressor_block(compressor_block),.compressor_iv(compressor_iv),
  .compressor_busy(compressor_busy),.compressor_done(compressor_done),.compressor_state(compressor_state));
 // Cache storage is not reset; its externally visible validity is reset.
 always @(posedge clk)begin
  if(page_valid && page_ready)cache[words_loaded[9:0]]<=page_data;
  if(cache_read && cache_valid)rd_word<=cache[cache_read_addr];
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;failure_state<=0;hash_enable<=0;authenticated<=0;done<=0;error_code<=0;elapsed_cycles<=0;cached_page_index<=0;
   saved_id<=0;saved_version<=0;saved_epoch<=0;saved_root<=0;current_digest<=0;sibling<=0;level<=0;
   prefix_pos<=0;parent_pos<=0;words_loaded<=0;bytes_fed<=0;buffer_valid<=0;buffer_word<=0;
   buffer_offset<=0;proof_words<=0;rd_valid<=0;
  end else begin
   rd_valid<=cache_read && cache_valid;
   if(cancel || (!start && state!=IDLE && !context_live))begin
    state<=FAILED;hash_enable<=0;authenticated<=0;done<=1;buffer_valid<=0;rd_valid<=0;
    if(state!=FAILED)begin failure_state<=state;error_code<=8'hd1;end
   end else if(start)begin
    authenticated<=0;done<=0;error_code<=0;elapsed_cycles<=0;rd_valid<=0;
    buffer_valid<=0;buffer_offset<=0;words_loaded<=0;bytes_fed<=0;prefix_pos<=0;parent_pos<=0;proof_words<=0;
    if(active || !model_authorized || page_index>=LEAF_COUNT)begin
     state<=FAILED;failure_state<=state;hash_enable<=0;done<=1;error_code<=8'hd2;
    end else begin
     saved_id<=model_id;saved_version<=model_version;saved_epoch<=session_epoch;
     saved_root<=model_root;cached_page_index<=page_index;state<=LEAF_START;level<=0;failure_state<=0;hash_enable<=1;
    end
   end else if(active && elapsed_cycles>=TIMEOUT_CYCLES)begin
    state<=FAILED;failure_state<=state;hash_enable<=0;authenticated<=0;done<=1;error_code<=8'hd3;buffer_valid<=0;
   end else begin
    if(active)elapsed_cycles<=elapsed_cycles+1'b1;
    case(state)
     LEAF_START:state<=PREFIX;
     PREFIX:if(hash_valid&&hash_ready)begin
      prefix_pos<=prefix_pos+hash_count;if(prefix_pos+hash_count==25)state<=PAGE;
     end
     PAGE:begin
      if(page_valid&&page_ready)begin
       buffer_word<=page_data;buffer_valid<=1;buffer_offset<=0;words_loaded<=words_loaded+1'b1;
      end
      if(hash_valid&&hash_ready)begin
       bytes_fed<=bytes_fed+hash_count;buffer_offset<=buffer_offset+hash_count;
       if(buffer_offset+hash_count==4)begin buffer_valid<=0;buffer_offset<=0;end
       if(bytes_fed+hash_count==4096)state<=LEAF_WAIT;
      end
     end
     LEAF_WAIT:if(hash_done)begin
      if(hash_fault)begin state<=FAILED;failure_state<=state;hash_enable<=0;done<=1;error_code<=8'hd4;end
      else begin current_digest<=hash_digest;state<=PROOF;proof_words<=0;level<=0;sibling<=0;end
     end
     PROOF:if(proof_valid&&proof_ready)begin
      sibling<={sibling[223:0],proof_data};proof_words<=proof_words+1'b1;
      if(proof_words==7)state<=PARENT_START;
     end
     PARENT_START:begin parent_pos<=0;state<=PARENT_FEED;end
     PARENT_FEED:if(hash_valid&&hash_ready)begin
      parent_pos<=parent_pos+hash_count;if(parent_pos+hash_count==65)state<=PARENT_WAIT;
     end
     PARENT_WAIT:if(hash_done)begin
      if(hash_fault)begin state<=FAILED;failure_state<=state;hash_enable<=0;done<=1;error_code<=8'hd4;end
      else if(level==DEPTH-1)begin
       done<=1;hash_enable<=0;
       if(hash_digest==saved_root)begin authenticated<=1;state<=FINISH;error_code<=0;end
       else begin authenticated<=0;state<=FAILED;failure_state<=state;error_code<=8'hd5;end
      end else begin
       current_digest<=hash_digest;level<=level+1'b1;proof_words<=0;sibling<=0;state<=PROOF;
      end
     end
     default:;
    endcase
   end
  end
 end
endmodule
