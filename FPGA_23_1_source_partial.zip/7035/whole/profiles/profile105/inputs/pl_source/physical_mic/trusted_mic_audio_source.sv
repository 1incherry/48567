`timescale 1ns/1ps
// Isolated physical profile. Original op5 protected job lifecycle, real microphone
// payload instead of op6 batches. No descriptor/GO/result/model/key override.
module trusted_mic_audio_source #(parameter integer ENABLE_ADMISSION_BUSY_REJECT=0,parameter integer TIMEOUT_CYCLES=100000000,parameter integer ENABLE_NORMAL_CAPTURE=0,parameter integer ENABLE_RAW_DIAGNOSTICS=0)(
 input wire clk,security_reset_n,cancel,
 input wire normal_capture_valid,input wire[31:0]normal_capture_epoch,normal_capture_model,
 output wire normal_capture_ready,output reg normal_result_valid,output reg[7:0]normal_result_error,
 input wire[31:0]debug_command,debug_resume_epoch,input wire[127:0]debug_key,debug_session_id,debug_key_fingerprint,
 input wire[31:0]base_ack_word,input wire controller_authorized,model_authorized,guard_key_valid,admission_blocked,
 input wire[31:0]controller_epoch,model_epoch,input wire[127:0]controller_session_id,
 output wire audio_job_valid,input wire audio_job_ready,audio_context_valid,input wire[287:0]accepted_audio_context,
 input wire audio_pool_granted,bank_drained,mic_sd,
 output wire mic_bclk,mic_ws,
 output wire b_write,input wire b_write_accepted,output wire[11:0]b_write_address,output wire[255:0]b_write_data,
 output wire b_read,input wire b_read_accepted,output wire[11:0]b_read_address,
 input wire b_response_valid,output wire b_response_ready,input wire[255:0]b_response_data,
 output wire pcm_valid,input wire pcm_ready,output wire[15:0]pcm_data,output wire[14:0]pcm_index,output wire pcm_last,output wire[287:0]pcm_context,
 output reg trusted_revoke,output wire[31:0]ack_word,output wire busy,resource_quiescent,active_clip,output wire[14:0]samples_sent,
 output reg[10:0]actual_B_committed_words,discarded_local_words,
 output wire[511:0]raw_diagnostic_snapshot
);
 localparam BOOT=0,IDLE=1,BASE_WAIT=2,CHECK=3,JOB=4,CONTEXT=5;
 reg[2:0]state;reg[31:0]command,metadata,ticks;reg[383:0]payload;
 reg[23:0]last_seen_sequence,ack_sequence;reg[7:0]ack_error;
 reg normal_origin;reg[31:0]normal_bound_epoch,normal_bound_model;
 reg active;reg[287:0]captured_context;reg[14:0]sent;
 // A captured clip admits exactly one real playback handshake until the next capture.
 reg play_accepted;
 // Root cited INMP441 power-up 2^18 SCK cycles; count real free-running
 // BCLK rises in the ungated50M domain. Never reset this counter perjob.
 reg last_bclk;reg[18:0]settle_edges;
 wire mic_settled=settle_edges==19'd262144;
 always@(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin last_bclk<=0;settle_edges<=0;end
  else begin last_bclk<=mic_bclk;if(!last_bclk&&mic_bclk&&!mic_settled)settle_edges<=settle_edges+1'b1;end
 end
 wire authorized_now=controller_authorized&&model_authorized&&guard_key_valid;
 wire debug_unchanged=command==debug_command&&metadata==debug_resume_epoch&&payload=={debug_key,debug_session_id,debug_key_fingerprint};
 wire unchanged=ENABLE_NORMAL_CAPTURE!=0&&normal_origin?(controller_epoch==normal_bound_epoch&&model_epoch==normal_bound_model):debug_unchanged;
 wire admission_live=ticks<TIMEOUT_CYCLES-1;
 wire wellformed=audio_context_valid&&accepted_audio_context[287:256]==model_epoch&&accepted_audio_context[255:224]==controller_epoch&&
  accepted_audio_context[223:192]==2&&accepted_audio_context[191:160]!=0&&accepted_audio_context[159:128]!=0&&accepted_audio_context[127:0]==controller_session_id&&
  controller_session_id!=0&&model_epoch!=0&&controller_epoch!=0&&
  (accepted_audio_context[255:224]!=captured_context[255:224]||accepted_audio_context[127:0]!=captured_context[127:0]||accepted_audio_context[159:128]>captured_context[159:128]);
 wire context_current=authorized_now&&audio_context_valid&&accepted_audio_context==captured_context;
 wire bridge_quiet,bridge_owns,bridge_fault,clip_done,play_done,cap_ready,play_ready;
 wire store_valid,store_ready,store_last;wire[255:0]store_data;wire[10:0]store_index;
 wire rd_valid,rd_ready;wire[10:0]rd_index;wire rsp_ready;
 wire[14:0]captured_samples;wire[10:0]logical_sink_words;
 wire cancelling=cancel||trusted_revoke||!authorized_now||!audio_context_valid||(active&&!context_current)||bridge_fault;
 assign normal_capture_ready=ENABLE_NORMAL_CAPTURE!=0&&security_reset_n&&state==IDLE&&debug_command[31:8]==last_seen_sequence&&
  authorized_now&&!cancel&&normal_capture_epoch==controller_epoch&&normal_capture_model==model_epoch&&controller_epoch!=0&&model_epoch!=0&&
  mic_settled&&!bridge_fault&&!(ENABLE_ADMISSION_BUSY_REJECT!=0&&admission_blocked)&&!active&&bridge_quiet&&!bridge_owns&&bank_drained;
 wire capture_fire=state==CONTEXT&&unchanged&&authorized_now&&wellformed&&cap_ready&&mic_settled&&!cancel;
 wire play_fire=play_ready&&!play_accepted&&actual_B_committed_words==2000&&discarded_local_words==0&&captured_samples==32000&&!cancelling;
 // A cancellation sink accepts/discards ONLY never-committed local queue words.
 // It issues no RAM write and cannot publish a valid clip. Real B commits are counted separately.
 assign b_write=store_valid&&!cancelling;
 assign b_write_address={1'd0,store_index};assign b_write_data=store_data;
 assign store_ready=b_write_accepted||(store_valid&&cancelling);
 assign b_read=rd_valid&&!cancelling;assign rd_ready=b_read_accepted;assign b_read_address={1'd0,rd_index};
 assign b_response_ready=rsp_ready;
 assign audio_job_valid=state==JOB&&unchanged&&admission_live&&authorized_now&&!cancel;
 assign ack_word={ack_error,ack_sequence};assign busy=state!=IDLE;
 assign resource_quiescent=bridge_quiet&&!bridge_owns&&bank_drained&&(!active||sent==32000);
 assign active_clip=active;assign samples_sent=sent[14:0];
 inmp441_clip_buffer_frontend_50m #(.ENABLE_RAW_DIAGNOSTICS(ENABLE_RAW_DIAGNOSTICS)) ingress(
  .clk(clk),.reset_n(security_reset_n),.capture_start(capture_fire),.play_start(play_fire),
  .cancel(cancelling),.context_live(authorized_now&&audio_context_valid&&!cancel),.live_context(accepted_audio_context),
  .reserve_live(audio_pool_granted),.store_drained(bank_drained),.mic_sd(mic_sd),.mic_bclk(mic_bclk),.mic_ws(mic_ws),
  .capture_start_ready(cap_ready),.play_start_ready(play_ready),.store_valid(store_valid),.store_ready(store_ready),.store_data(store_data),.store_index(store_index),.store_last(store_last),
  .read_valid(rd_valid),.read_ready(rd_ready),.read_index(rd_index),.response_valid(b_response_valid),.response_ready(rsp_ready),.response_data(b_response_data),
  .pcm_valid(pcm_valid),.pcm_ready(pcm_ready),.pcm_data(pcm_data),.pcm_index(pcm_index),.pcm_last(pcm_last),.pcm_context(pcm_context),
  .capture_done(clip_done),.play_done(play_done),.quiescent(bridge_quiet),.owns_store(bridge_owns),.fault(bridge_fault),.clip_sequence(),.captured_samples(captured_samples),.committed_words(logical_sink_words),.raw_diagnostic_snapshot(raw_diagnostic_snapshot));
 task finish(input[7:0]e);begin
  if(ENABLE_NORMAL_CAPTURE!=0&&normal_origin)begin normal_result_valid<=1;normal_result_error<=e;normal_origin<=0;end
  else begin ack_sequence<=command[31:8];ack_error<=e;end
  state<=IDLE;ticks<=0;end endtask
 task fail(input[7:0]e);begin if(active||state==JOB||state==CONTEXT)trusted_revoke<=1;active<=0;finish(e);end endtask
 always@(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin normal_origin<=0;normal_bound_epoch<=0;normal_bound_model<=0;normal_result_valid<=0;normal_result_error<=0;state<=BOOT;command<=0;metadata<=0;payload<=0;ticks<=0;last_seen_sequence<=0;ack_sequence<=0;ack_error<=0;active<=0;captured_context<=0;sent<=0;play_accepted<=0;trusted_revoke<=0;actual_B_committed_words<=0;discarded_local_words<=0;end
  else begin
   trusted_revoke<=0;normal_result_valid<=0;
   if(play_fire)play_accepted<=1;
   if(state!=IDLE)ticks<=ticks+1'b1;
   if(b_write&&b_write_accepted)actual_B_committed_words<=actual_B_committed_words+1'b1;
   if(store_valid&&store_ready&&cancelling&&!b_write_accepted)discarded_local_words<=discarded_local_words+1'b1;
   if(active&&pcm_valid&&pcm_ready)begin
    if(pcm_context!=captured_context||pcm_index!=sent||pcm_last!=(sent==31999))begin trusted_revoke<=1;active<=0;end
    else sent<=sent+1'b1;
   end
   if(active&&(cancel||!context_current))active<=0;
   if(active&&sent==32000&&bridge_quiet&&bank_drained)active<=0;
   if(bridge_fault&&active)begin trusted_revoke<=1;active<=0;end
   case(state)
    BOOT:begin last_seen_sequence<=debug_command[31:8];state<=IDLE;ticks<=0;end
    IDLE:if(debug_command[31:8]!=last_seen_sequence)begin
     last_seen_sequence<=debug_command[31:8];normal_origin<=0;
     if(debug_command[7:0]==5||debug_command[7:0]==6)begin command<=debug_command;metadata<=debug_resume_epoch;payload<={debug_key,debug_session_id,debug_key_fingerprint};ticks<=0;state<=BASE_WAIT;end
    end else if(normal_capture_valid&&normal_capture_ready)begin
     normal_origin<=1;normal_bound_epoch<=controller_epoch;normal_bound_model<=model_epoch;ticks<=0;state<=JOB;
    end
    BASE_WAIT:if(!unchanged)fail(8'h09);else if(base_ack_word[23:0]==command[31:8])begin if(base_ack_word[31:24]!=8'h07)fail(base_ack_word[31:24]);else state<=CHECK;end
    CHECK:if(!unchanged)fail(8'h09);else if(!authorized_now||cancel)fail(8'h06);
     else if(command[7:0]==6)finish(8'h07); // Explicitly no debug PCM injection in physical profile.
     else if(!mic_settled)finish(8'h06);else if(bridge_fault)finish(8'h0d);else if((ENABLE_ADMISSION_BUSY_REJECT!=0&&admission_blocked)||active||!bridge_quiet||bridge_owns||!bank_drained)finish(8'h06);else state<=JOB;
    JOB:if(!unchanged)fail(8'h09);else if(!authorized_now||cancel)fail(8'h06);else if(audio_job_valid&&audio_job_ready)state<=CONTEXT;
    CONTEXT:if(!unchanged)fail(8'h09);else if(!authorized_now||cancel)fail(8'h06);else if(capture_fire)begin captured_context<=accepted_audio_context;active<=1;sent<=0;play_accepted<=0;actual_B_committed_words<=0;discarded_local_words<=0;finish(8'h00);end
    default:fail(8'hff);
   endcase
   if(state!=IDLE&&state!=BOOT&&ticks>=TIMEOUT_CYCLES-1)fail(8'h0a);
  end
 end
endmodule
