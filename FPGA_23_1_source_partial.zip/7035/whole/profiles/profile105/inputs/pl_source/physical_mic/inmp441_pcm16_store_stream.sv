`timescale 1ns/1ps
// Physical acquisition only. No key, model authorization, descriptor or NN GO.
// reserve_live/store_drained must be real private capacity/IO facts, never PS claims.
// Caller owns a complete 1000x256b clip store before start; this module adds no clip BRAM.
module inmp441_pcm16_store_stream #(
 parameter integer CLOCK_HZ=50000000,
 parameter integer SAMPLE_HZ=16000,
 parameter integer FRAME_SAMPLES=32000,
 parameter integer ENABLE_RAW_DIAGNOSTICS=0
)(
 input wire clk,reset_n,start,cancel,reserve_live,store_drained,mic_sd,
 output wire mic_bclk,mic_ws,
 output wire start_ready,quiescent,owns_store,exhausted,
 output wire store_valid,input wire store_ready,
 output wire[255:0]store_data,output wire[10:0]store_index,output wire store_last,
 output reg[31:0]clip_sequence,
 output wire clip_valid,output wire done,output reg fault,
 input wire clip_release,
 output reg[14:0]captured_samples,output reg[10:0]committed_words,
 input wire[287:0]observation_capture_context,output wire[511:0]raw_diagnostic_snapshot
);
 localparam integer WORDS=FRAME_SAMPLES/16;
 reg active,source_finished,clip_present,done_reg;
 wire raw_valid,raw_ready,raw_last,raw_busy,raw_done,raw_overflow;
 wire[15:0]raw_data;wire[14:0]raw_index;
 reg[255:0]pack;
 reg[3:0]pack_count;
 reg[255:0]fifo[0:1];reg[10:0]indexes[0:1];reg lasts[0:1];
 reg wr_ptr,rd_ptr;reg[1:0]count;
 wire pop=store_valid&&store_ready;
 wire push=raw_valid&&raw_ready&&pack_count==15;
 wire source_cancel=cancel||fault||(active&&!reserve_live);
 assign exhausted=clip_sequence==32'hffffffff;
 assign quiescent=!active&&!raw_busy&&!raw_valid&&count==0&&store_drained;
 assign owns_store=active||clip_present||count!=0||!store_drained;
 assign clip_valid=clip_present&&!cancel&&!fault&&reserve_live;
 assign done=done_reg&&clip_valid;
 assign start_ready=reset_n&&quiescent&&!clip_present&&!cancel&&!fault&&!exhausted&&reserve_live;
 assign store_valid=reset_n&&count!=0;
 assign store_data=fifo[rd_ptr];assign store_index=indexes[rd_ptr];assign store_last=lasts[rd_ptr];
 assign raw_ready=active&&!source_cancel&&(pack_count!=15||count<2||pop);
 inmp441_pcm16_capture #(.CLOCK_HZ(CLOCK_HZ),.SAMPLE_HZ(SAMPLE_HZ),.FRAME_SAMPLES(FRAME_SAMPLES))receiver(
 .clk(clk),.reset_n(reset_n),.start(start&&start_ready),.cancel(source_cancel),.mic_sd(mic_sd),
 .mic_bclk(mic_bclk),.mic_ws(mic_ws),.pcm_valid(raw_valid),.pcm_ready(raw_ready),
 .pcm_data(raw_data),.pcm_index(raw_index),.pcm_last(raw_last),.busy(raw_busy),.done(raw_done),.overflow(raw_overflow));
 // Passive fanout ONLY of the actual pre-pack receiver handshake.
 mic_pcm_aggregate_observer #(.ENABLE(ENABLE_RAW_DIAGNOSTICS),.FRAME_SAMPLES(FRAME_SAMPLES)) raw_observer(
  .clk(clk),.reset_n(reset_n),.capture_accept(start&&start_ready),.cancel(source_cancel),.source_fault(fault),
  .capture_context(observation_capture_context),.pcm_valid(raw_valid),.pcm_ready(raw_ready),.pcm_data(raw_data),
  .pcm_index(raw_index),.pcm_last(raw_last),.pcm_context(observation_capture_context),.snapshot_words_flat(raw_diagnostic_snapshot));
 // synthesis translate_off
 initial if(FRAME_SAMPLES<16||FRAME_SAMPLES>32000||FRAME_SAMPLES%16!=0)$fatal(1,"CLIP_GEOMETRY_MUST_BE_WHOLE_16_SAMPLE_WORDS");
 // synthesis translate_on
 always@(posedge clk or negedge reset_n)begin
  if(!reset_n)begin
   active<=0;source_finished<=0;pack<=0;pack_count<=0;wr_ptr<=0;rd_ptr<=0;count<=0;
   clip_sequence<=0;clip_present<=0;done_reg<=0;fault<=0;captured_samples<=0;committed_words<=0;
  end else begin
   done_reg<=0;
   if(pop)begin rd_ptr<=!rd_ptr;committed_words<=committed_words+1'b1;end
   if(push)begin fifo[wr_ptr]<={raw_data,pack[239:0]};indexes[wr_ptr]<=raw_index[14:4];lasts[wr_ptr]<=raw_last;wr_ptr<=!wr_ptr;end
   case({push,pop})2'b10:count<=count+1'b1;2'b01:count<=count-1'b1;default:begin end endcase
   if(start&&start_ready)begin
    active<=1;source_finished<=0;pack_count<=0;captured_samples<=0;committed_words<=0;
    clip_sequence<=clip_sequence+1'b1;
   end
   if(raw_valid&&raw_ready)begin
    if(raw_index!=captured_samples||raw_last!=(captured_samples==FRAME_SAMPLES-1))begin fault<=1;active<=0;clip_present<=0;end
    captured_samples<=captured_samples+1'b1;
    pack[pack_count*16+:16]<=raw_data;pack_count<=pack_count+1'b1;
   end
   if(raw_done)source_finished<=1;
   if(raw_overflow||((active||clip_present||count!=0)&&!reserve_live))begin fault<=1;active<=0;clip_present<=0;end
   if(active&&source_finished&&!raw_busy&&!raw_valid&&count==0&&store_drained)begin
    if(captured_samples==FRAME_SAMPLES&&committed_words==WORDS&&pack_count==0&&!fault&&!cancel&&reserve_live)begin
     active<=0;clip_present<=1;done_reg<=1;
    end else begin fault<=1;active<=0;clip_present<=0;end
   end
   if(clip_release&&quiescent&&store_drained)clip_present<=0;
   if(cancel)begin active<=0;clip_present<=0;source_finished<=0;pack_count<=0;end
   // Offered full words remain stable and drain after cancellation. No partial clip is published.
  end
 end
endmodule
