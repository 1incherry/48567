`timescale 1ns/1ps
// Independent physical ingress candidate. No root/model/result authority.
// 64 BCLK per WS frame; I2S MSB is one bit after WS edge. Left channel only.
module inmp441_pcm16_capture #(
 parameter integer CLOCK_HZ=100000000,
 parameter integer SAMPLE_HZ=16000,
 parameter integer FRAME_SAMPLES=32000
)(
 input wire clk,reset_n,start,cancel,mic_sd,
 output reg mic_bclk,mic_ws,
 output reg pcm_valid,input wire pcm_ready,
 output reg[15:0]pcm_data,output reg[14:0]pcm_index,output reg pcm_last,
 output reg busy,done,overflow
);
 localparam integer EDGE_HZ=SAMPLE_HZ*128;
 reg[31:0]phase;
 reg[5:0]bit_index;
 reg[23:0]shift;
 reg[14:0]produced;
 wire[32:0]sum={1'b0,phase}+EDGE_HZ;
 wire tick=sum>=CLOCK_HZ;
 initial begin
  if(CLOCK_HZ<=EDGE_HZ||SAMPLE_HZ<8000||SAMPLE_HZ>48000||FRAME_SAMPLES<1||FRAME_SAMPLES>32000)$error("unsupported physical capture geometry");
 end
 always@(posedge clk or negedge reset_n)begin
  if(!reset_n)begin
   phase<=0;bit_index<=63;mic_bclk<=0;mic_ws<=1;shift<=0;
   pcm_valid<=0;pcm_data<=0;pcm_index<=0;pcm_last<=0;
   busy<=0;done<=0;overflow<=0;produced<=0;
  end else begin
   done<=0;
   phase<=tick?sum-CLOCK_HZ:sum;
   if(pcm_valid&&pcm_ready&&!cancel)begin
    pcm_valid<=0;
    if(pcm_last)begin busy<=0;done<=1;end
   end
   if(start&&!busy&&!pcm_valid&&!overflow)begin busy<=1;produced<=0;end
   if(cancel)begin busy<=0;pcm_valid<=0;produced<=0;end
   if(tick)begin
    mic_bclk<=!mic_bclk;
    if(mic_bclk)begin
     bit_index<=bit_index+1'b1;
     mic_ws<=bit_index==31?1'b1:bit_index==63?1'b0:mic_ws;
    end else if(bit_index>=1&&bit_index<=24)begin
     shift<={shift[22:0],mic_sd};
     if(bit_index==24&&busy&&!cancel&&produced<FRAME_SAMPLES)begin
      if(pcm_valid&&!pcm_ready)begin overflow<=1;busy<=0;pcm_valid<=0;end
      else begin
       // Signed24 -> signed16 keeps the top16 two's-complement bits.
       pcm_data<=shift[22:7];pcm_index<=produced;
       pcm_last<=produced==FRAME_SAMPLES-1;pcm_valid<=1;
       produced<=produced+1'b1;
      end
     end
    end
   end
  end
 end
endmodule
