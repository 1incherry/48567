`timescale 1ns/1ps
// Passive RAW-capture diagnostics, NOT playback/MFCC/inference completion.
// No ready, fault, cancel, grant, reset, data or authority output to the source.
module mic_pcm_aggregate_observer #(
 parameter integer ENABLE=0, parameter integer FRAME_SAMPLES=32000
)(
 input wire clk,reset_n,capture_accept,cancel,source_fault,
 input wire [287:0] capture_context,
 input wire pcm_valid,pcm_ready, input wire [15:0] pcm_data,
 input wire [14:0] pcm_index, input wire pcm_last,
 input wire [287:0] pcm_context,
 output wire [511:0] snapshot_words_flat
);
generate if(ENABLE!=0) begin:g_enabled
 reg active,complete,cancelled,bad_index,bad_context,exhausted;
 reg [31:0] generation,published_generation;
 reg [287:0] bound;
 reg [15:0] count,nz,saturated,peak;
 reg signed [15:0] min_sample,max_sample,pub_min,pub_max;
 reg [31:0] abs_sum;
 reg signed [31:0] signed_sum;
 reg [15:0] pub_count,pub_nz,pub_saturated,pub_peak;
 reg [31:0] pub_abs_sum,pub_sum;
 reg [159:0] pub_context;
 wire take=active&&!cancel&&!source_fault&&pcm_valid&&pcm_ready;
 wire [15:0] magnitude=pcm_data[15]?(~pcm_data+16'd1):pcm_data;
 wire nz_sample=pcm_data!=0;
 wire saturated_sample=pcm_data==16'h8000||pcm_data==16'h7fff;
 wire signed [15:0] signed_sample=$signed(pcm_data);
 wire signed [15:0] next_min=(count==0||signed_sample<min_sample)?signed_sample:min_sample;
 wire signed [15:0] next_max=(count==0||signed_sample>max_sample)?signed_sample:max_sample;
 wire [31:0] next_abs=abs_sum+{16'd0,magnitude};
 wire signed [31:0] extended={{16{pcm_data[15]}},pcm_data};
 wire signed [31:0] next_sum=signed_sum+extended;
 wire index_ok=pcm_index==count&&count<FRAME_SAMPLES&&pcm_last==(count==FRAME_SAMPLES-1);
 wire context_ok=pcm_context==bound;
 localparam [31:0] FRAME_SAMPLES_WORD=FRAME_SAMPLES;
 // SID is compared internally, never exported. Public tuple is model/runtime/
 // source/clip/generation; these counters confer no record validity or authority.
 assign snapshot_words_flat={published_generation,FRAME_SAMPLES_WORD,
  pub_context[31:0],pub_context[63:32],pub_context[95:64],pub_context[127:96],pub_context[159:128],
  {pub_max,pub_min},pub_sum,pub_abs_sum,{16'd0,pub_peak},{16'd0,pub_saturated},
  {pub_nz,pub_count},generation,
  {26'd0,exhausted,bad_context,bad_index,cancelled,complete,active},32'h4d534f31};
 always @(posedge clk or negedge reset_n) begin
  if(!reset_n) begin
   active<=0;complete<=0;cancelled<=0;bad_index<=0;bad_context<=0;exhausted<=0;
   generation<=0;published_generation<=0;bound<=0;
   count<=0;nz<=0;saturated<=0;peak<=0;min_sample<=0;max_sample<=0;abs_sum<=0;signed_sum<=0;
   pub_count<=0;pub_nz<=0;pub_saturated<=0;pub_peak<=0;pub_min<=0;pub_max<=0;
   pub_abs_sum<=0;pub_sum<=0;pub_context<=0;
  end else begin
   if(capture_accept&&!cancel&&!source_fault) begin
    complete<=0;cancelled<=0;bad_index<=0;bad_context<=0;
    if(generation==32'hffffffff) begin exhausted<=1;active<=0;end
    else begin
     generation<=generation+1'b1;active<=1;bound<=capture_context;
     count<=0;nz<=0;saturated<=0;peak<=0;min_sample<=0;max_sample<=0;abs_sum<=0;signed_sum<=0;
    end
   end else if(active&&(cancel||source_fault)) begin
    active<=0;complete<=0;cancelled<=1;published_generation<=generation;
    pub_count<=count;pub_nz<=nz;pub_saturated<=saturated;pub_peak<=peak;
    pub_min<=min_sample;pub_max<=max_sample;pub_abs_sum<=abs_sum;pub_sum<=signed_sum;
    pub_context<=bound[287:128];
   end else if(take) begin
    if(!index_ok)bad_index<=1;
    if(!context_ok)bad_context<=1;
    count<=count+1'b1;nz<=nz+nz_sample;saturated<=saturated+saturated_sample;
    min_sample<=next_min;max_sample<=next_max;abs_sum<=next_abs;signed_sum<=next_sum;
    if(magnitude>peak)peak<=magnitude;
    // Bounded observer even for a malformed missing/early LAST. No source control.
    if(pcm_last||count==FRAME_SAMPLES-1) begin
     active<=0;complete<=index_ok&&context_ok&&!bad_index&&!bad_context&&!exhausted;
     published_generation<=generation;pub_count<=count+1'b1;pub_nz<=nz+nz_sample;
     pub_saturated<=saturated+saturated_sample;pub_peak<=magnitude>peak?magnitude:peak;
     pub_min<=next_min;pub_max<=next_max;pub_abs_sum<=next_abs;pub_sum<=next_sum;
     pub_context<=bound[287:128];
    end
   end
  end
 end
 // A later ordinary clip release/cancel does not destroy a finished diagnostic.
 // It still is ONLY raw sampling completion, never store/crypto/NN completion.
end else begin:g_disabled
 assign snapshot_words_flat=512'd0;
end endgenerate
// synthesis translate_off
initial if(FRAME_SAMPLES<1||FRAME_SAMPLES>32000)$fatal(1,"DIAGNOSTIC_FRAME_RANGE");
// synthesis translate_on
endmodule
