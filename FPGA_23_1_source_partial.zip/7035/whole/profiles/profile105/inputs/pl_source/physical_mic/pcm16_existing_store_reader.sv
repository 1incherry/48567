`timescale 1ns/1ps
// PREPARED component only. One existing-store read credit, one256b word, no clipRAM.
// Caller: private audio owner4, B[0..999], real synchronous >=1cycle response.
module pcm16_existing_store_reader(
 input wire clk,reset_n,start,cancel,clip_valid,reserve_live,context_live,
 input wire[287:0]clip_context,
 output wire start_ready,quiescent,busy,
 output wire read_valid,input wire read_ready,output wire[10:0]read_index,
 input wire response_valid,output wire response_ready,input wire[255:0]response_data,
 output wire pcm_valid,input wire pcm_ready,output wire[15:0]pcm_data,
 output wire[14:0]pcm_index,output wire pcm_last,output wire[287:0]pcm_context,
 output reg done,fault
);
 reg active,pending,word_valid;reg[255:0]word;reg[14:0]sample_index;reg[287:0]bound_context;
 wire context_ok=context_live&&clip_context==bound_context;
 wire live=reset_n&&active&&!cancel&&!fault&&reserve_live&&clip_valid&&context_ok;
 assign quiescent=!active&&!pending&&!word_valid;
 assign busy=!quiescent;
 assign start_ready=reset_n&&quiescent&&!cancel&&!fault&&reserve_live&&clip_valid&&context_live;
 assign read_valid=live&&!pending&&!word_valid;
 assign read_index=sample_index[14:4];
 // Pending responses are always retired, including cancellation. Never lose credit.
 assign response_ready=reset_n&&pending;
 assign pcm_valid=live&&word_valid;
 assign pcm_data=word[15:0];assign pcm_index=sample_index;assign pcm_last=sample_index==15'd31999;
 assign pcm_context=pcm_valid?bound_context:288'd0;
 always@(posedge clk or negedge reset_n)begin
  if(!reset_n)begin active<=0;pending<=0;word_valid<=0;word<=0;sample_index<=0;bound_context<=0;done<=0;fault<=0;end
  else begin
   done<=0;
   if(start&&start_ready)begin active<=1;sample_index<=0;bound_context<=clip_context;word_valid<=0;end
   if(read_valid&&read_ready)pending<=1;
   if(response_valid&&!pending)fault<=1;
   if(response_valid&&response_ready)begin
    pending<=0;
    if(live)begin word<=response_data;word_valid<=1;end
   end
   if(pcm_valid&&pcm_ready)begin
    if(pcm_last)begin active<=0;word_valid<=0;done<=1;end
    else begin sample_index<=sample_index+1'b1;if(sample_index[3:0]==15)word_valid<=0;else word<=word>>16;end
   end
   if(active&&(!reserve_live||!clip_valid||!context_ok))begin active<=0;word_valid<=0;fault<=1;end
   if(cancel)begin active<=0;word_valid<=0;end
  end
 end
endmodule
