`timescale 1ns/1ps
// PREPARED physical-ingress bridge. No model, NN GO, PS state, key or result authority.
// Start/context/reserve/drained MUST come from actual protected audiojob and privateB entrance.
module inmp441_clip_buffer_frontend_50m #(parameter integer ENABLE_RAW_DIAGNOSTICS=0)(
 input wire clk,reset_n,capture_start,play_start,cancel,context_live,
 input wire[287:0]live_context,input wire reserve_live,store_drained,mic_sd,
 output wire mic_bclk,mic_ws,capture_start_ready,play_start_ready,
 output wire store_valid,input wire store_ready,output wire[255:0]store_data,
 output wire[10:0]store_index,output wire store_last,
 output wire read_valid,input wire read_ready,output wire[10:0]read_index,
 input wire response_valid,output wire response_ready,input wire[255:0]response_data,
 output wire pcm_valid,input wire pcm_ready,output wire[15:0]pcm_data,
 output wire[14:0]pcm_index,output wire pcm_last,output wire[287:0]pcm_context,
 output wire capture_done,play_done,quiescent,owns_store,fault,
 output wire[31:0]clip_sequence,output wire[14:0]captured_samples,output wire[10:0]committed_words,
 output wire[511:0]raw_diagnostic_snapshot
);
 reg have_context;reg[287:0]bound_context;
 wire cap_ready,cap_quiet,cap_owns,clip_valid,cap_fault,reader_quiet,reader_fault;
 wire context_ok=have_context&&context_live&&live_context==bound_context;
 wire source_cancel=cancel||(have_context&&!context_ok);
 wire cap_accept=capture_start&&capture_start_ready;
 assign capture_start_ready=cap_ready&&reader_quiet&&context_live&&!cancel&&!fault;
 assign fault=cap_fault||reader_fault;
 assign quiescent=cap_quiet&&reader_quiet;
 assign owns_store=cap_owns||!reader_quiet;
 inmp441_pcm16_store_stream #(.CLOCK_HZ(50000000),.SAMPLE_HZ(16000),.FRAME_SAMPLES(32000),.ENABLE_RAW_DIAGNOSTICS(ENABLE_RAW_DIAGNOSTICS)) ingress(
  .clk(clk),.reset_n(reset_n),.start(cap_accept),.cancel(source_cancel),.reserve_live(reserve_live),.store_drained(store_drained),.mic_sd(mic_sd),
  .mic_bclk(mic_bclk),.mic_ws(mic_ws),.start_ready(cap_ready),.quiescent(cap_quiet),.owns_store(cap_owns),.exhausted(),
  .store_valid(store_valid),.store_ready(store_ready),.store_data(store_data),.store_index(store_index),.store_last(store_last),
  .clip_sequence(clip_sequence),.clip_valid(clip_valid),.done(capture_done),.fault(cap_fault),
  .clip_release(play_done&&reader_quiet&&store_drained),.captured_samples(captured_samples),.committed_words(committed_words),
  .observation_capture_context(live_context),.raw_diagnostic_snapshot(raw_diagnostic_snapshot));
 pcm16_existing_store_reader reader(
  .clk(clk),.reset_n(reset_n),.start(play_start&&play_start_ready),.cancel(source_cancel),.clip_valid(clip_valid),
  .reserve_live(reserve_live),.context_live(context_ok),.clip_context(bound_context),.start_ready(play_start_ready),.quiescent(reader_quiet),.busy(),
  .read_valid(read_valid),.read_ready(read_ready),.read_index(read_index),.response_valid(response_valid),.response_ready(response_ready),.response_data(response_data),
  .pcm_valid(pcm_valid),.pcm_ready(pcm_ready),.pcm_data(pcm_data),.pcm_index(pcm_index),.pcm_last(pcm_last),.pcm_context(pcm_context),.done(play_done),.fault(reader_fault));
 always@(posedge clk or negedge reset_n)begin
  if(!reset_n)begin have_context<=0;bound_context<=0;end
  else begin
   if(cap_accept)begin have_context<=1;bound_context<=live_context;end
   if(have_context&&!cap_owns&&reader_quiet)begin have_context<=0;bound_context<=0;end
  end
 end
endmodule
