set first [get_pins -quiet -hier -regexp {.*u_frames/(receiver/(send|ack)_sync_reg\[0\]|transmitter/(send|ack)_sync_reg\[0\])/D}]
set rh [get_cells -quiet -hier -regexp {.*u_frames/receiver/held_header_reg\[[0-9]+\]}]
set th [get_cells -quiet -hier -regexp {.*u_frames/transmitter/held_packet_reg\[[0-9]+\]}]
puts "NFR_CDC first=[llength $first] rx_header=[llength $rh] tx_packet=[llength $th]"
if {[llength $first]!=4} {error "NFR first synchronizer topology changed"}
if {[llength $rh]!=384} {error "NFR RX immutable header width changed"}
if {[llength $th]!=496} {error "NFR TX immutable packet unexpectedly absent"}
set rl [get_cells -quiet -hier -regexp {.*u_frames/receiver/local_header_reg\[[0-9]+\]}]
set tl [get_cells -quiet -hier -regexp {.*u_frames/transmitter/local_packet_reg\[[0-9]+\]}]
if {[llength $rl]!=384||[llength $tl]!=496} {error "NFR destination mailbox width changed"}
puts "NFR_LOCAL_MAILBOX RX=[llength $rl] TX=[llength $tl]"
set delays [get_cells -quiet -hier -filter {REF_NAME == IDELAYE2 && NAME =~ *g_rx_delay*}]
if {[llength $delays]!=5} {error "Proven R7 RX input delays absent"}
foreach delay $delays {if {[get_property IDELAY_VALUE $delay]!=11} {error "RX tap qualification changed"}}

set ef [get_pins -quiet -hier -regexp {.*u_eth/(u_capture/(arm_sync|freeze_sync|ack_sync)_reg\[0\]|u_mac/(rx_prescale_sync|rx_mii_select_sync)_reg\[0\])/D}]
set er [get_pins -quiet -hier -regexp {.*u_eth/u_mac/rgmii_phy_if_inst/rx_rst_reg_reg\[[0-3]\]/PRE}]
if {[llength $ef]!=5 || [llength $er]!=4} {error "Ethernet synchronizer topology changed"}
if {[llength [get_clocks -quiet sys_clk_50m]]!=1} {error "Missing physical 50MHz oscillator clock"}

foreach {cn period} {sys_clk_50m 20.000 raw100 10.000 clk_raw 8.000 rgmii_rx_clk 8.000} {
 set cc [get_clocks -quiet $cn]
 if {[llength $cc]!=1} {error "Missing clock $cn"}
 if {abs([get_property PERIOD $cc]-$period)>0.001} {error "Wrong clock $cn period"}
}
