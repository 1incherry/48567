`timescale 1ns/1ps
// Read-only diagnostic timing. No authority, launch, ownership or DDR outputs.
// Durations are edge-to-edge clock intervals; NN includes its classifier head.
module trusted_pipeline_metrics(
 input wire clk,security_reset_n,authorization_live,
 input wire frame_start,ingress_done,yolo_start,yolo_done,
 input wire frontend_start,nn_start,head_start,nn_done,
 input wire [31:0] roi_index,
 input wire record_commit,abort,
 input wire page_input_wait,mac_busy,pool_wait,
 output wire snapshot_valid,output reg measurement_fault,
 output reg [63:0] total_cycles,ingress_cycles,yolo_cycles,
 output reg [255:0] frontend_cycles,nn_cycles,head_cycles,
 output reg [63:0] page_input_wait_cycles,mac_busy_cycles,pool_wait_cycles,
 output reg [3:0] roi_measured,
 output reg [31:0] sequence_id
);
 reg active,stored_valid,ingress_open,yolo_open,yolo_finished,frontend_open,nn_open,head_open;
 reg [1:0] active_roi;
 reg [63:0] ticks,yolo_tick,frontend_tick,nn_tick,head_tick;
 reg [63:0] live_ingress,live_yolo,live_page_wait,live_mac_busy,live_pool_wait;
 reg [255:0] live_frontend,live_nn,live_head;
 reg [3:0] live_roi;
 reg ingress_armed,yolo_armed,nn_armed;
 wire [63:0] now_tick=ticks+64'd1;
 wire stop=abort||!authorization_live;
 // Actual child completions may remain asserted in FINISHED until the next
 // accepted job. Consume the first completion only while its window is open.
 wire ingress_end=ingress_done&&ingress_open&&ingress_armed;
 wire yolo_end=yolo_done&&yolo_open&&yolo_armed;
 wire nn_end=nn_done&&nn_open&&nn_armed;
 assign snapshot_valid=stored_valid&&!measurement_fault&&authorization_live&&!abort&&!frame_start;
 always @(posedge clk)begin
  if(!security_reset_n)begin
   active<=0;stored_valid<=0;measurement_fault<=0;sequence_id<=0;
   ingress_armed<=0;yolo_armed<=0;nn_armed<=0;
   ingress_open<=0;yolo_open<=0;yolo_finished<=0;frontend_open<=0;nn_open<=0;head_open<=0;active_roi<=0;
   ticks<=0;yolo_tick<=0;frontend_tick<=0;nn_tick<=0;head_tick<=0;
   live_ingress<=0;live_yolo<=0;live_page_wait<=0;live_mac_busy<=0;live_pool_wait<=0;
   live_frontend<=0;live_nn<=0;live_head<=0;live_roi<=0;
   total_cycles<=0;ingress_cycles<=0;yolo_cycles<=0;frontend_cycles<=0;nn_cycles<=0;head_cycles<=0;
   page_input_wait_cycles<=0;mac_busy_cycles<=0;pool_wait_cycles<=0;roi_measured<=0;
  end else if(stop)begin
   active<=0;stored_valid<=0;
   ingress_open<=0;yolo_open<=0;frontend_open<=0;nn_open<=0;head_open<=0;
  end else if(frame_start)begin
   active<=1;stored_valid<=0;measurement_fault<=active;sequence_id<=sequence_id+1'b1;
   ingress_armed<=!ingress_done;yolo_armed<=0;nn_armed<=0;
   ingress_open<=1;yolo_open<=0;yolo_finished<=0;frontend_open<=0;nn_open<=0;head_open<=0;
   ticks<=0;live_ingress<=0;live_yolo<=0;live_page_wait<=0;live_mac_busy<=0;live_pool_wait<=0;
   live_frontend<=0;live_nn<=0;live_head<=0;live_roi<=0;
  end else if(active)begin
   ticks<=now_tick;
   if(ingress_open&&!ingress_done)ingress_armed<=1;
   if(yolo_open&&!yolo_done)yolo_armed<=1;
   if(nn_open&&!nn_done)nn_armed<=1;
   if(page_input_wait)live_page_wait<=live_page_wait+1'b1;
   if(mac_busy)live_mac_busy<=live_mac_busy+1'b1;
   if(pool_wait)live_pool_wait<=live_pool_wait+1'b1;
   if(ingress_end)begin
    ingress_open<=0;live_ingress<=now_tick;
   end
   if(yolo_start)begin
    if(yolo_open||yolo_finished||(!ingress_end&&ingress_open))measurement_fault<=1;
    yolo_open<=1;yolo_tick<=now_tick;yolo_armed<=!yolo_done;
   end
   if(yolo_end)begin
    yolo_open<=0;yolo_finished<=1;live_yolo<=now_tick-yolo_tick;
   end
   if(frontend_start)begin
    if(roi_index>=4||(!yolo_finished&&!yolo_end)||frontend_open||nn_open||head_open||live_roi[roi_index[1:0]])measurement_fault<=1;
    active_roi<=roi_index[1:0];frontend_open<=1;frontend_tick<=now_tick;
   end
   if(nn_start)begin
    if(!frontend_open||nn_open||head_open||roi_index>=4||roi_index[1:0]!=active_roi)measurement_fault<=1;
    frontend_open<=0;live_frontend[active_roi*64+:64]<=now_tick-frontend_tick;
    nn_open<=1;nn_tick<=now_tick;nn_armed<=!nn_done;
   end
   if(head_start)begin
    if(!nn_open||head_open||roi_index>=4||roi_index[1:0]!=active_roi)measurement_fault<=1;
    head_open<=1;head_tick<=now_tick;
   end
   if(nn_end)begin
    if(!nn_open||!head_open||roi_index>=4||roi_index[1:0]!=active_roi)measurement_fault<=1;
    nn_open<=0;head_open<=0;live_nn[active_roi*64+:64]<=now_tick-nn_tick;
    live_head[active_roi*64+:64]<=now_tick-head_tick;live_roi[active_roi]<=1;
   end
   if(record_commit)begin
    if(ingress_open||!yolo_finished||yolo_open||frontend_open||nn_open||head_open||
       measurement_fault||nn_end||ingress_end||yolo_end||
       yolo_start||frontend_start||nn_start||head_start)begin
     // Do not publish a stale NBA value when commit coincides with a phase end.
     // Actual resultbank commits after all stage completion handshakes.
     measurement_fault<=1;stored_valid<=0;
    end else begin
     total_cycles<=now_tick;ingress_cycles<=live_ingress;yolo_cycles<=live_yolo;
     frontend_cycles<=live_frontend;nn_cycles<=live_nn;head_cycles<=live_head;roi_measured<=live_roi;
     page_input_wait_cycles<=live_page_wait+{63'd0,page_input_wait};
     mac_busy_cycles<=live_mac_busy+{63'd0,mac_busy};pool_wait_cycles<=live_pool_wait+{63'd0,pool_wait};
     stored_valid<=1;
    end
    active<=0;
   end
  end
 end
endmodule
