# Run as ordinary Tcl against the implemented design, not through read_xdc.
# Vivado's XDC subset does not execute conditional assertions.
set sync_first [get_pins -quiet -hier -regexp {.*u_hdmi/(scan/(enable|primed)_sync_reg\[0\]|dma/(done|fault)_sync_reg\[0\]|(done|fault|lock)_sync_reg\[0\])/D}]
set bundle_src [get_cells -quiet -hier -regexp {.*u_hdmi/scan/(frames|crc_result)_reg\[[0-9]+\]}]
set bundle_dst [get_cells -quiet -hier -regexp {.*u_hdmi/(frames|crc_result)_reg\[[0-9]+\]}]
set reset_async [get_pins -quiet -hier -regexp {.*u_hdmi/pixel_reset_reg\[[0-3]\]/PRE}]
puts "HDMI_CDC_COUNTS first=[llength $sync_first] source=[llength $bundle_src] destination=[llength $bundle_dst] async_reset=[llength $reset_async]"
if {[llength $sync_first] != 7} {error "HDMI synchronizer count changed"}
if {[llength $bundle_src] != 64 || [llength $bundle_dst] != 64} {error "HDMI stable bundle width changed"}
if {[llength $reset_async] != 4} {error "HDMI pixel reset synchronizer changed"}
set skew_path [file join [file dirname [info script]] hdmi_bundle_skew.rpt]
report_bus_skew -file $skew_path
set skew_file [open $skew_path r]
set skew_text [read $skew_file]
close $skew_file
if {[regexp {Slack \(VIOLATED\)} $skew_text]} {error "HDMI stable bundle skew bound failed"}
