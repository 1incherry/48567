`timescale 1ns/1ps
// Diagnostic transport sink. One committed frame at a time, bounded profiles,
// no CPU-provided DMA address. CRC is NOT a cryptographic camera authenticator.
module nfr_preview640_rgbx_sink #(
 parameter integer TIMEOUT_CYCLES=500000000,
 parameter integer REQUEST_RETRY_CYCLES=10000000
)(
 input wire clk,rst_n,start,cancel,consume_done,pattern,display_bank,
 input wire [31:0] request_session,request_frame,
 output wire start_ready,output reg busy,output wire frame_ready,output reg fault,
 output reg [31:0] completed_frame,committed_offset,received_crc,
 output reg [31:0] frame_base,
 input wire packet_valid,input wire [383:0] packet_header,output reg packet_release,
 output wire payload_read,output wire [9:0] payload_address,
 input wire [7:0] payload_data,input wire payload_read_valid,
 output wire response_valid,input wire response_ready,
 output reg [7:0] response_kind,output reg [31:0] response_offset,response_frame_crc,
 output reg [31:0] response_session_id,response_frame_id,response_total_bytes,
 output reg [15:0] response_width,response_height,output reg [7:0] response_flags,
 output reg [31:0] session_id,frame_id,total_bytes,
 output reg [15:0] width,height,output reg [7:0] flags,
 output wire [31:0] m_awaddr,output wire [7:0] m_awlen,
 output wire [2:0] m_awsize,output wire [1:0] m_awburst,
 output wire m_awvalid,input wire m_awready,
 output wire [63:0] m_wdata,output wire [7:0] m_wstrb,
 output wire m_wlast,m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output wire packet_local_quiescent,response_local_quiescent,ddr_local_quiescent,transaction_quiescent
);
 wire profile1080=1'b1; // Fixed RGBX32 packing only; geometry below is always640x480.
 localparam IDLE=0,WAIT_PACKET=1,HI_REQ=2,HI_WAIT=3,LO_REQ=4,LO_WAIT=5,
  EMIT=6,PREPARE_BURST=7,AW=8,WDATA=9,BRESP=10,RESPOND=11,HELD=12;
 reg [3:0] state;
 reg mode1080,aborting;
 reg ready_record,response_pending;
 reg [31:0] progress_ticks;
 assign frame_ready=ready_record&&!cancel&&!aborting&&!fault;
 assign response_valid=response_pending&&(!(cancel||aborting)||response_kind==6);
 reg [31:0] frame_crc_expected,crc_committed,crc_work;
 reg [31:0] held_payload_crc,last_payload_crc,last_offset;
 reg last_valid;
 // Keep exactly the last committed final DATA header after consumer release.
 // A lost DONE must remain recoverable while the next REQUEST is retried.
 reg completed_valid;
 reg [383:0] completed_header;
 reg [31:0] request_ticks,lifetime_ticks;
 reg [9:0] input_address;
 reg [15:0] input_length,converted_bytes;
 reg [7:0] high_byte,red,green,blue;
 reg [1:0] color_index;
 reg [2:0] pack_lane;
 reg [63:0] pack;
 reg [8:0] pack_words,write_index,burst_beats,burst_sent;
 reg [31:0] write_address;
 reg [63:0] memory_q;
 (* ram_style="block" *) reg [63:0] converted[0:255];
 wire [31:0] p_session=packet_header[319:288],p_frame=packet_header[287:256];
 wire [15:0] p_camera=packet_header[255:240],p_width=packet_header[239:224],p_height=packet_header[223:208];
 wire [7:0] p_format=packet_header[207:200],p_flags=packet_header[199:192];
 wire [31:0] p_total=packet_header[191:160],p_offset=packet_header[159:128];
 wire [15:0] p_length=packet_header[127:112],p_sequence=packet_header[111:96];
 wire [31:0] p_payload_crc=packet_header[95:64],p_frame_crc=packet_header[63:32];
 wire contract_ok=packet_header[343:336]==2&&p_session==session_id&&p_frame==frame_id&&
  p_camera==0&&p_width==width&&p_height==height&&p_format==1&&p_flags==flags&&
  p_total==total_bytes&&p_length==1024&&p_sequence==p_offset[25:10]&&p_offset[9:0]==0&&
  p_offset<total_bytes&&p_offset+1024<=total_bytes&&
  (committed_offset==0||p_frame_crc==frame_crc_expected);
 wire duplicate_ok=last_valid&&p_offset==last_offset&&p_payload_crc==last_payload_crc;
 wire completed_duplicate=completed_valid&&packet_header==completed_header;
 wire replay_completed=packet_valid&&completed_duplicate&&!response_pending&&(state==IDLE||state==WAIT_PACKET);
 assign start_ready=state==IDLE&&!response_pending&&!replay_completed;
 assign payload_read=(state==HI_REQ||state==LO_REQ)&&!cancel&&!aborting;
 assign payload_address=input_address;
 wire [7:0] color_byte=color_index==0?red:color_index==1?green:color_index==2?blue:8'd0;
 wire [63:0] next_pack=(pack&~(64'hff<<(pack_lane*8)))|({56'd0,color_byte}<<(pack_lane*8));
 assign m_awaddr=write_address;assign m_awlen=burst_beats-1'b1;
 assign m_awsize=3;assign m_awburst=1;assign m_awvalid=state==AW;
 assign m_wdata=memory_q;assign m_wstrb=8'hff;
 assign m_wvalid=state==WDATA;assign m_wlast=burst_sent+1==burst_beats;
 assign m_bready=state==BRESP;
 function automatic [31:0] crc_byte(input [31:0] c,input [7:0] d);
  reg [31:0] v;integer b;
  begin v=c^d;for(b=0;b<8;b=b+1)v=v[0]?(v>>1)^32'hedb88320:v>>1;crc_byte=v;end
 endfunction
 task automatic reply(input [7:0] kind,input [31:0] offset);
  begin response_pending<=1;response_kind<=kind;response_offset<=offset;
   response_frame_crc<=frame_crc_expected;
   response_session_id<=session_id;response_frame_id<=frame_id;response_total_bytes<=total_bytes;
   response_width<=width;response_height<=height;response_flags<=flags;
   state<=RESPOND;end
 endtask
 // Same original read-enable and priority, made one physical RAM read port.
 wire converted_read_enable=(state==AW&&m_awready)||(state==WDATA&&m_wready&&!m_wlast);
 wire[31:0] converted_read_address=(state==AW)?{24'd0,write_index[7:0]}:({24'd0,write_index[7:0]}+32'd1);
 // Synchronous local packet RAM; stall leaves WDATA unchanged.
 always @(posedge clk)begin
  if(state==EMIT&&pack_lane==7)converted[pack_words[7:0]]<=next_pack;
  if(converted_read_enable)memory_q<=converted[converted_read_address];
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;busy<=0;ready_record<=0;fault<=0;mode1080<=0;aborting<=0;progress_ticks<=0;
   completed_frame<=0;committed_offset<=0;received_crc<=0;session_id<=0;frame_id<=0;total_bytes<=0;
   width<=0;height<=0;flags<=0;frame_base<=0;frame_crc_expected<=0;crc_committed<=32'hffffffff;crc_work<=32'hffffffff;
   held_payload_crc<=0;last_payload_crc<=0;last_offset<=0;last_valid<=0;input_address<=0;input_length<=0;converted_bytes<=0;
   high_byte<=0;red<=0;green<=0;blue<=0;color_index<=0;pack_lane<=0;pack<=0;pack_words<=0;
   write_index<=0;burst_beats<=0;burst_sent<=0;write_address<=0;
   response_pending<=0;response_kind<=0;response_offset<=0;response_frame_crc<=0;packet_release<=0;
   response_session_id<=0;response_frame_id<=0;response_total_bytes<=0;
   response_width<=0;response_height<=0;response_flags<=0;
   completed_valid<=0;completed_header<=0;request_ticks<=0;lifetime_ticks<=0;
  end else begin
   packet_release<=0;
   if(response_valid&&response_ready)response_pending<=0;
   if(!busy||state==HELD)progress_ticks<=0;
   else if((payload_read_valid&&(state==HI_WAIT||state==LO_WAIT))||
      (m_awvalid&&m_awready)||(m_wvalid&&m_wready)||(m_bvalid&&m_bready)||
      (response_valid&&response_ready))progress_ticks<=0;
   else progress_ticks<=progress_ticks+1'b1;
   if(!busy||state==HELD)lifetime_ticks<=0;
   else if(lifetime_ticks<TIMEOUT_CYCLES)lifetime_ticks<=lifetime_ticks+1'b1;
   // Repeated REQUEST transmissions do not extend the whole-frame deadline.
   if((cancel||progress_ticks>=TIMEOUT_CYCLES||lifetime_ticks>=TIMEOUT_CYCLES)&&busy)begin aborting<=1;fault<=1;ready_record<=0;end
   if(state==WAIT_PACKET&&committed_offset==0&&!response_pending)request_ticks<=request_ticks+1'b1;
   else request_ticks<=0;
   if(replay_completed)begin
    packet_release<=1;response_pending<=1;response_kind<=4;
    response_offset<=completed_header[191:160];response_frame_crc<=completed_header[63:32];
    response_session_id<=completed_header[319:288];response_frame_id<=completed_header[287:256];
    response_total_bytes<=completed_header[191:160];response_width<=completed_header[239:224];
    response_height<=completed_header[223:208];response_flags<=completed_header[199:192];
   end else case(state)
    IDLE:begin
     if(packet_valid)packet_release<=1;
     if(start&&start_ready&&!cancel)begin
     busy<=1;ready_record<=0;fault<=0;aborting<=0;mode1080<=profile1080;progress_ticks<=0;
     session_id<=request_session;frame_id<=request_frame;flags<={7'd0,pattern};
     width<=1920;height<=1080;
     total_bytes<=4147200;
     frame_base<=display_bank?32'h25800000:32'h25000000;
     committed_offset<=0;received_crc<=0;crc_committed<=32'hffffffff;frame_crc_expected<=0;last_valid<=0;
     response_pending<=1;response_kind<=1;response_offset<=0;response_frame_crc<=0;state<=RESPOND;
     response_session_id<=request_session;response_frame_id<=request_frame;
     response_total_bytes<=4147200;
     response_width<=1920;response_height<=1080;
     response_flags<={7'd0,pattern};
     end
    end
    WAIT_PACKET:if(packet_valid&&!response_pending)begin
     if(!contract_ok)begin packet_release<=1;reply(5,committed_offset);end
     else if(duplicate_ok)begin packet_release<=1;reply(3,committed_offset);end
     else if(p_offset!=committed_offset)begin packet_release<=1;reply(5,committed_offset);end
     else begin
      if(committed_offset==0)frame_crc_expected<=p_frame_crc;
      held_payload_crc<=p_payload_crc;input_address<=0;input_length<=p_length;converted_bytes<=0;
      crc_work<=crc_committed;pack<=0;pack_lane<=0;pack_words<=0;state<=HI_REQ;
     end
    end else if(!response_pending&&committed_offset==0&&request_ticks>=REQUEST_RETRY_CYCLES)begin
     reply(1,0);request_ticks<=0;
    end
    HI_REQ:state<=HI_WAIT;
    HI_WAIT:if(payload_read_valid)begin
     high_byte<=payload_data;crc_work<=crc_byte(crc_work,payload_data);input_address<=input_address+1'b1;state<=LO_REQ;
    end
    LO_REQ:state<=LO_WAIT;
    LO_WAIT:if(payload_read_valid)begin
     crc_work<=crc_byte(crc_work,payload_data);
     red<={high_byte[7:3],high_byte[7:5]};green<={high_byte[2:0],payload_data[7:5],high_byte[2:1]};
     blue<={payload_data[4:0],payload_data[4:2]};color_index<=0;state<=EMIT;
    end
    EMIT:begin
     pack<=next_pack;pack_lane<=pack_lane+1'b1;converted_bytes<=converted_bytes+1'b1;
     if(pack_lane==7)pack_words<=pack_words+1'b1;
     if(color_index==(mode1080?3:2))begin
      color_index<=0;
      if(input_address+1==input_length)begin
       write_address<=frame_base+(mode1080?(committed_offset<<1):((committed_offset>>1)*3));
       write_index<=0;state<=PREPARE_BURST;
      end else begin input_address<=input_address+1'b1;state<=HI_REQ;end
     end else color_index<=color_index+1'b1;
    end
    PREPARE_BURST:begin
     // Bound every AXI4 burst to one 4KiB page and at most 256 64-bit beats.
     if((13'd4096-{1'b0,write_address[11:0]})>>3 < pack_words-write_index)
      burst_beats<=(13'd4096-{1'b0,write_address[11:0]})>>3;
     else burst_beats<=pack_words-write_index;
     burst_sent<=0;state<=AW;
    end
    AW:if(m_awready)state<=WDATA;
    WDATA:if(m_wready)begin
     write_index<=write_index+1'b1;burst_sent<=burst_sent+1'b1;
     if(m_wlast)state<=BRESP;
    end
    BRESP:if(m_bvalid)begin
     if(m_bresp!=0||cancel||aborting)begin
      fault<=1;ready_record<=0;aborting<=1;packet_release<=1;reply(6,committed_offset);
     end else if(write_index<pack_words)begin write_address<=write_address+burst_beats*8;state<=PREPARE_BURST;end
     else begin
      packet_release<=1;
      if(committed_offset+input_length==total_bytes&&~crc_work!=frame_crc_expected)begin
       fault<=1;aborting<=1;ready_record<=0;reply(6,committed_offset);
      end else begin
       last_valid<=1;last_offset<=committed_offset;last_payload_crc<=held_payload_crc;
       committed_offset<=committed_offset+input_length;crc_committed<=crc_work;
       if(committed_offset+input_length==total_bytes)begin
        completed_header<=packet_header;completed_valid<=1;
        ready_record<=1;completed_frame<=frame_id;received_crc<=~crc_work;reply(4,total_bytes);
       end else reply(3,committed_offset+input_length);
      end
     end
    end
    RESPOND:if(response_valid&&response_ready)begin
     if(aborting||cancel)begin busy<=0;state<=IDLE;end
     else if(frame_ready)state<=HELD;else state<=WAIT_PACKET;
    end
    HELD:begin
     if(packet_valid)begin
      packet_release<=1;
      if(contract_ok&&duplicate_ok&&p_offset+1024==total_bytes)reply(4,total_bytes);
     end
     if(consume_done)begin ready_record<=0;busy<=0;state<=IDLE;end
    end
    default:begin fault<=1;aborting<=1;state<=IDLE;busy<=0;ready_record<=0;end
   endcase
   // Never withdraw a presented AW or abandon an accepted burst. Other
   // states can terminate immediately because no bus write is outstanding.
   if((cancel||aborting)&&busy&&state!=AW&&state!=WDATA&&state!=BRESP&&state!=RESPOND)begin
    packet_release<=packet_valid;ready_record<=0;fault<=1;aborting<=1;reply(6,committed_offset);
   end
   if((cancel||aborting)&&busy&&state==RESPOND&&response_kind!=6)begin
    response_pending<=1;response_kind<=6;response_offset<=committed_offset;
    response_session_id<=session_id;response_frame_id<=frame_id;response_total_bytes<=total_bytes;
    response_width<=width;response_height<=height;response_flags<=flags;
   end
  end
 end
 assign packet_local_quiescent=!packet_valid&&!payload_read&&!payload_read_valid&&state!=HI_REQ&&state!=HI_WAIT&&state!=LO_REQ&&state!=LO_WAIT&&state!=EMIT;
 assign response_local_quiescent=!response_pending&&state!=RESPOND;
 assign ddr_local_quiescent=state!=AW&&state!=WDATA&&state!=BRESP&&!m_awvalid&&!m_wvalid;
 assign transaction_quiescent=!busy&&start_ready&&packet_local_quiescent&&response_local_quiescent&&ddr_local_quiescent;
endmodule
