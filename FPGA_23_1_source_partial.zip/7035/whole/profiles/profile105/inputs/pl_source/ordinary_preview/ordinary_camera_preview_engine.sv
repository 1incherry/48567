`timescale 1ns/1ps
// Display-only preview shares a single owned NFR endpoint. No preview byte can
// enter authenticated NN ingress; the original NN parent/guard remains intact.
module ordinary_camera_preview_engine #(
 parameter PREVIEW_PERIOD=50000000,CAPTURE_TIMEOUT=250000000,COMMIT_TIMEOUT=50000000,CONTINUOUS_NN_PREVIEW=0
)(
output reg completed_pulse,completed_bank,
 output reg[31:0]completed_sequence,completed_base,completed_session,completed_frame,completed_epoch,completed_bytes,completed_crc,
 input wire clk,rst_n,root_live,input wire[31:0] authorization_epoch,
 input wire nn_raw_sealed,nn_raw_frame_ready,nn_raw_transport_idle,nn_raw_slot_ready,input wire[31:0]nn_raw_crc,
 output wire nn_raw_consume_done,nn_retire_pulse,nn_retire_failed,
 input wire nn_pending_intent,
 input wire trusted_cancel,preview_enable,nn_request,input wire nn_active,nn_retired,nn_error,
 output wire nn_request_ready,nn_owner_opened,nn_abort,resources_quiet,fault,
 output wire[4:0] diagnostic_fault_leaves,output reg[31:0]diagnostic_route,
 output wire[31:0] next_session,next_frame,output wire exhausted,
 output wire owner_close,owner_open,owner_purpose_nn,input wire owner_closed,owner_opened,
 output wire[31:0] owner_session,owner_frame,owner_epoch,
 input wire packet_path_quiescent,response_tx_quiescent,endpoint_live,endpoint_fault,
 input wire packet_valid,input wire[383:0]packet_header,input wire packet_purpose_nn,input wire[31:0]packet_epoch,
 output wire packet_release,payload_read,output wire[9:0]payload_address,input wire[7:0]payload_data,input wire payload_read_valid,
 output wire response_valid,input wire response_ready,output wire[7:0] response_kind,response_flags,
 output wire[31:0]response_offset,response_frame_crc,response_session_id,response_frame_id,response_total_bytes,
 output wire[15:0]response_width,response_height,
 output wire nn_packet_valid,output wire[383:0]nn_packet_header,input wire nn_packet_release,nn_payload_read,input wire[9:0]nn_payload_address,
 output wire[7:0]nn_payload_data,output wire nn_payload_read_valid,
 input wire nn_response_valid,output wire nn_response_ready,input wire[7:0]nn_response_kind,nn_response_flags,
 input wire[31:0]nn_response_offset,nn_response_frame_crc,nn_response_session_id,nn_response_frame_id,nn_response_total_bytes,
 input wire[15:0]nn_response_width,nn_response_height,
 input wire[11:0]s_axi_awaddr,s_axi_araddr,input wire s_axi_awvalid,s_axi_wvalid,s_axi_bready,s_axi_arvalid,s_axi_rready,
 input wire[31:0]s_axi_wdata,input wire[3:0]s_axi_wstrb,
 output wire s_axi_awready,s_axi_wready,s_axi_bvalid,s_axi_arready,s_axi_rvalid,
 output wire[1:0]s_axi_bresp,s_axi_rresp,output wire[31:0]s_axi_rdata,
 input wire[31:0]hdmi_ack_seq,hdmi_active_base,hdmi_frames,input wire hdmi_healthy,
 output wire[31:0]m_awaddr,output wire[7:0]m_awlen,output wire[2:0]m_awsize,output wire[1:0]m_awburst,
 output wire m_awvalid,input wire m_awready,output wire[63:0]m_wdata,output wire[7:0]m_wstrb,
 output wire m_wlast,m_wvalid,input wire m_wready,input wire[1:0]m_bresp,input wire m_bvalid,output wire m_bready);
 wire wire_retired,wire_release_pending,wire_drop,cancel_valid,cancel_ready;
 wire[31:0]cancel_s,cancel_f,cancel_e,cancel_crc;
 trusted_nfr_wire_retirement #(.ENABLE(CONTINUOUS_NN_PREVIEW)) wire_retirement(
  .clk(clk),.board_resetn(rst_n),.new_nn_accept(nn_request&&nn_request_ready),
  .raw_sealed(nn_raw_sealed),.raw_frame_ready(nn_raw_frame_ready),.raw_transport_idle(nn_raw_transport_idle),
  .raw_response_valid(nn_response_valid),.packet_quiescent(packet_path_quiescent),.response_tx_quiescent(response_tx_quiescent),
  .owner_session(owner_session),.owner_frame(owner_frame),.owner_epoch(owner_epoch),.raw_frame_crc(nn_raw_crc),
  .raw_consume_done(nn_raw_consume_done),.drop_nn_packets(wire_drop),
  .cancel_valid(cancel_valid),.cancel_ready(cancel_ready),.cancel_session(cancel_s),.cancel_frame(cancel_f),.cancel_epoch(cancel_e),.cancel_crc(cancel_crc),
  .wire_retired(wire_retired),.release_pending(wire_release_pending),.state_debug());
 assign cancel_ready=owner_purpose_nn&&response_ready;
 wire own_valid,pv_cap_valid,pv_cap_ready,pv_cap_owner,pv_cap_purpose,pv_cancel,pv_consume;
 wire[31:0]pv_base,pv_session,pv_frame,pv_epoch;
 wire provider_done,provider_error,provider_crc_ok,provider_verified,provider_purpose,provider_idle;
 wire[31:0]provider_base,provider_session,provider_frame,provider_epoch,provider_bytes,provider_crc;
 wire actual_publish,published_bank;
 wire[31:0]published_session,published_frame,published_epoch,published_crc;
 reg completion_exhausted;
 always@(posedge clk)begin
  if(!rst_n)begin
   completed_pulse<=0;completed_bank<=0;completed_sequence<=0;completed_base<=0;
   completed_session<=0;completed_frame<=0;completed_epoch<=0;completed_bytes<=0;completed_crc<=0;completion_exhausted<=0;
  end else begin
   completed_pulse<=0;
   if(actual_publish)begin
    if(completed_sequence==32'hffffffff)completion_exhausted<=1;
    else begin
     completed_pulse<=1;completed_sequence<=completed_sequence+1'b1;completed_bank<=published_bank;
     completed_base<=published_bank?32'h25800000:32'h25000000;
     completed_session<=published_session;completed_frame<=published_frame;completed_epoch<=published_epoch;
     completed_bytes<=provider_bytes;completed_crc<=published_crc;
    end
   end
  end
 end


 wire pv_packet_quiet,pv_response_quiet,pv_ddr_quiet,scheduler_fault,bank_fault;
 wire[7:0]scheduler_code;
 wire[3:0]scheduler_state;
 wire pv_packet_release,pv_payload_read,pv_response_valid,pv_response_ready;
 wire[9:0]pv_payload_address;
 wire[7:0]pv_response_kind,pv_response_flags;
 wire[31:0]pv_response_offset,pv_response_frame_crc,pv_response_session_id,pv_response_frame_id,pv_response_total_bytes;
 wire[15:0]pv_response_width,pv_response_height;
 reg payload_return_nn,route_fault;
 wire header_owner_matches=own_valid&&endpoint_live&&packet_purpose_nn==owner_purpose_nn&&packet_epoch==owner_epoch&&packet_header[319:288]==owner_session&&packet_header[287:256]==owner_frame;
 wire nn_packet_route=packet_valid&&header_owner_matches&&owner_purpose_nn&&!wire_drop;
 wire pv_packet_route=packet_valid&&header_owner_matches&&!owner_purpose_nn;
 assign nn_packet_valid=nn_packet_route;
 assign nn_packet_header=nn_packet_route?packet_header:384'd0;
 assign packet_release=owner_purpose_nn?(wire_drop?packet_valid:nn_packet_release):pv_packet_release;
 assign payload_read=owner_purpose_nn?(nn_payload_read&&!wire_drop):pv_payload_read;
 assign payload_address=owner_purpose_nn?nn_payload_address:pv_payload_address;
 assign nn_payload_data=nn_payload_read_valid?payload_data:8'd0;
 assign nn_payload_read_valid=payload_read_valid&&payload_return_nn;
 // Read response ownership is captured at the actual source request edge.
 // packet metadata may withdraw on CLOSE while this read tail is still live.
 always@(posedge clk)begin
  if(!rst_n)begin payload_return_nn<=0;route_fault<=0;end
  else begin
   if(payload_read)payload_return_nn<=owner_purpose_nn;
   if(packet_valid&&header_owner_matches!==1'b1)route_fault<=1;
  end
 end
 assign response_valid=owner_purpose_nn?(cancel_valid||(nn_response_valid&&!wire_drop)):pv_response_valid;
 assign nn_response_ready=owner_purpose_nn&&!cancel_valid&&!wire_drop&&response_ready;
 assign pv_response_ready=!owner_purpose_nn&&response_ready;
 assign response_kind=owner_purpose_nn?(cancel_valid?8'd6:nn_response_kind):pv_response_kind;
 assign response_flags=owner_purpose_nn?(cancel_valid?8'd0:nn_response_flags):pv_response_flags;
 assign response_offset=owner_purpose_nn?(cancel_valid?32'd4147200:nn_response_offset):pv_response_offset;
 assign response_frame_crc=owner_purpose_nn?(cancel_valid?cancel_crc:nn_response_frame_crc):pv_response_frame_crc;
 assign response_session_id=owner_purpose_nn?(cancel_valid?cancel_s:nn_response_session_id):pv_response_session_id;
 assign response_frame_id=owner_purpose_nn?(cancel_valid?cancel_f:nn_response_frame_id):pv_response_frame_id;
 assign response_total_bytes=owner_purpose_nn?(cancel_valid?32'd4147200:nn_response_total_bytes):pv_response_total_bytes;
 assign response_width=owner_purpose_nn?(cancel_valid?16'd1920:nn_response_width):pv_response_width;
 assign response_height=owner_purpose_nn?(cancel_valid?16'd1080:nn_response_height):pv_response_height;
 assign resources_quiet=(scheduler_state==0||scheduler_state==8)&&owner_closed&&pv_packet_quiet&&pv_response_quiet&&pv_ddr_quiet&&provider_idle;
 assign fault=scheduler_fault||bank_fault||route_fault||endpoint_fault||completion_exhausted;
 // Read-only combinational mirror; no control uses this output.
 assign diagnostic_fault_leaves={completion_exhausted,endpoint_fault,route_fault,bank_fault,scheduler_fault};
 ordinary_camera_preview_control #(.PREVIEW_PERIOD(PREVIEW_PERIOD),.CAPTURE_TIMEOUT(CAPTURE_TIMEOUT),.COMMIT_TIMEOUT(COMMIT_TIMEOUT),.HONOR_TRUSTED_CANCEL(1),.CONTINUOUS_NN_PREVIEW(CONTINUOUS_NN_PREVIEW)) control(
 .observed_publish(actual_publish),.observed_bank(published_bank),.observed_session(published_session),.observed_frame(published_frame),.observed_epoch(published_epoch),.observed_crc(published_crc),
 .clk(clk),.board_resetn(rst_n),.root_live(root_live),.authorization_epoch(authorization_epoch),.preview_enable(preview_enable),.trusted_cancel(trusted_cancel),.nn_intent((nn_pending_intent===1'b1)&&scheduler_state==0),
 .nn_request(nn_request),.nn_request_ready(nn_request_ready),.next_session(next_session),.next_frame(next_frame),.exhausted(exhausted),
 .nn_owner_opened(nn_owner_opened),.nn_abort(nn_abort),.nn_active(nn_active),.nn_retired(nn_retired),.nn_error(nn_error),
 .nn_wire_retired(wire_retired),.nn_raw_slot_ready(nn_raw_slot_ready),.nn_wire_release_pending(wire_release_pending),.nn_retire_pulse(nn_retire_pulse),.nn_retire_failed(nn_retire_failed),
 .owner_close(owner_close),.owner_closed(owner_closed),.owner_open(owner_open),.owner_opened(owner_opened),.owner_valid(own_valid),.owner_purpose_nn(owner_purpose_nn),.owner_session(owner_session),.owner_frame(owner_frame),.owner_epoch(owner_epoch),
 .capture_valid(pv_cap_valid),.capture_ready(pv_cap_ready),.capture_owner_valid(pv_cap_owner),.capture_purpose_nn(pv_cap_purpose),.capture_base(pv_base),.capture_session(pv_session),.capture_frame(pv_frame),.capture_epoch(pv_epoch),.capture_cancel(pv_cancel),.capture_consume_done(pv_consume),
 .provider_done(provider_done),.provider_error(provider_error),.provider_crc_ok(provider_crc_ok),.provider_source_verified(provider_verified),.provider_purpose_nn(provider_purpose),.provider_base(provider_base),.provider_session(provider_session),.provider_frame(provider_frame),.provider_epoch(provider_epoch),.provider_committed_bytes(provider_bytes),.provider_crc(provider_crc),
 .packet_quiescent(pv_packet_quiet),.response_quiescent(pv_response_quiet),.ddr_quiescent(pv_ddr_quiet),.provider_idle(provider_idle),
 .fault(scheduler_fault),.fault_code(scheduler_code),.preview_completed(),.preview_aborted(),.nn_completed(),.last_session(),.last_frame(),.state_debug(scheduler_state),
 .s_axi_awaddr(s_axi_awaddr),
 .s_axi_awvalid(s_axi_awvalid),
 .s_axi_awready(s_axi_awready),
 .s_axi_wdata(s_axi_wdata),
 .s_axi_wstrb(s_axi_wstrb),
 .s_axi_wvalid(s_axi_wvalid),
 .s_axi_wready(s_axi_wready),
 .s_axi_bresp(s_axi_bresp),
 .s_axi_bvalid(s_axi_bvalid),
 .s_axi_bready(s_axi_bready),
 .s_axi_araddr(s_axi_araddr),
 .s_axi_arvalid(s_axi_arvalid),
 .s_axi_arready(s_axi_arready),
 .s_axi_rdata(s_axi_rdata),
 .s_axi_rresp(s_axi_rresp),
 .s_axi_rvalid(s_axi_rvalid),
 .s_axi_rready(s_axi_rready),
 .hdmi_ack_seq(hdmi_ack_seq),.hdmi_active_base(hdmi_active_base),.hdmi_frames(hdmi_frames),.hdmi_healthy(hdmi_healthy),
 .display_valid(),.display_bank(),.display_session(),.display_frame(),.display_epoch(),.bank0_state(),.bank1_state(),.rejected_releases(),.rejected_commits(),.bank_fault(bank_fault));
 display_nfr640_backend preview_backend(
 .clk(clk),.board_resetn(rst_n),.capture_valid(pv_cap_valid),.capture_ready(pv_cap_ready),.capture_owner_valid(pv_cap_owner),.capture_purpose_nn(pv_cap_purpose),.capture_base(pv_base),.capture_session(pv_session),.capture_frame(pv_frame),.capture_epoch(pv_epoch),.capture_cancel(pv_cancel),.capture_consume_done(pv_consume),
 .provider_done(provider_done),.provider_error(provider_error),.provider_crc_ok(provider_crc_ok),.provider_source_verified(provider_verified),.provider_purpose_nn(provider_purpose),.provider_base(provider_base),.provider_session(provider_session),.provider_frame(provider_frame),.provider_epoch(provider_epoch),.provider_committed_bytes(provider_bytes),.provider_crc(provider_crc),
 .provider_idle(provider_idle),.packet_quiescent(pv_packet_quiet),.response_quiescent(pv_response_quiet),.ddr_quiescent(pv_ddr_quiet),
 .packet_path_quiescent(packet_path_quiescent),.response_tx_quiescent(response_tx_quiescent),
 .packet_valid(pv_packet_route),.packet_header(pv_packet_route?packet_header:384'd0),.packet_release(pv_packet_release),.payload_read(pv_payload_read),.payload_address(pv_payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid&&!payload_return_nn),
 .response_valid(pv_response_valid),.response_ready(pv_response_ready),
 .response_kind(pv_response_kind),
 .response_flags(pv_response_flags),
 .response_offset(pv_response_offset),
 .response_frame_crc(pv_response_frame_crc),
 .response_session_id(pv_response_session_id),
 .response_frame_id(pv_response_frame_id),
 .response_total_bytes(pv_response_total_bytes),
 .response_width(pv_response_width),
 .response_height(pv_response_height),
 .m_awaddr(m_awaddr),
 .m_awlen(m_awlen),
 .m_awsize(m_awsize),
 .m_awburst(m_awburst),
 .m_awvalid(m_awvalid),
 .m_awready(m_awready),
 .m_wdata(m_wdata),
 .m_wstrb(m_wstrb),
 .m_wlast(m_wlast),
 .m_wvalid(m_wvalid),
 .m_wready(m_wready),
 .m_bresp(m_bresp),
 .m_bvalid(m_bvalid),
 .m_bready(m_bready));
 // synthesis translate_off
 always@(posedge clk)if(rst_n&&nn_request&&!nn_request_ready)$fatal(1,"PREVIEW_NN_GO_WITHOUT_ACTUAL_READY");
 always@(posedge clk)if(rst_n&&nn_packet_valid&&(!owner_purpose_nn||packet_epoch!==owner_epoch))$fatal(1,"PREVIEW_BYTES_ROUTED_TO_NN");
 // synthesis translate_on
 always@(posedge clk)begin
  if(!rst_n)diagnostic_route<=0;
  else diagnostic_route<={12'd0,scheduler_state,wire_retired,wire_release_pending,wire_drop,payload_return_nn,own_valid,owner_purpose_nn,endpoint_live,owner_opened,nn_request_ready,nn_response_valid,nn_response_ready,packet_valid,nn_packet_route,pv_packet_route,header_owner_matches,nn_pending_intent};
 end
endmodule
