`timescale 1ns/1ps
// Private successor component, not part of frozen R14.
// A lease is immutable until CLOSE has really drained both clock domains.
// Full CRC/envelope and latched S/F checks precede the publication toggle.
module nfr_packet_rx_owned #(
 parameter integer REGISTERED_CHANNEL_LIVE=0,
 parameter [47:0] LOCAL_MAC=48'h025052587035,
 parameter [47:0] REMOTE_MAC=48'h025052583100
)(
 input wire clk,rst_n,rx_clk,rx_reset,
 input wire [7:0] rx_data,input wire rx_valid,rx_last,rx_bad,
 input wire owner_close,owner_open,owner_purpose_nn,
 input wire [31:0] owner_session,owner_frame,owner_epoch,
 output wire owner_closed,owner_opened,packet_quiescent,channel_live,
 output wire packet_valid,output wire [383:0] packet_header,
 output wire packet_purpose_nn,output wire [31:0] packet_epoch,
 input wire packet_release,payload_read,input wire [9:0] payload_address,
 output wire [7:0] payload_data,output reg payload_read_valid,
 output reg [31:0] received_packets,bad_packets,busy_drops,foreign_drops,
 output reg[63:0] diagnostic_counts,output wire[511:0] diagnostic_local,output reg[15:0] diagnostic_publications
);
 wire channel_reset=!rst_n||rx_reset;
 (* ASYNC_REG="TRUE" *) reg [2:0] core_reset_pipe=7,rx_reset_pipe=7;
 generate if(REGISTERED_CHANNEL_LIVE!=0)begin:registered_release
  // Raw reset terminates at the actual domain-release synchronizers. The
  // retained set bits assert even while clocks stop; release needs three edges.
  always @(posedge clk or posedge channel_reset)
   if(channel_reset)core_reset_pipe<=7;
   else if(channel_reset===1'b0)core_reset_pipe<={core_reset_pipe[1:0],1'b0};
   else core_reset_pipe<=7;
  always @(posedge rx_clk or posedge channel_reset)
   if(channel_reset)rx_reset_pipe<=7;
   else if(channel_reset===1'b0)rx_reset_pipe<={rx_reset_pipe[1:0],1'b0};
   else rx_reset_pipe<=7;
 end else begin:literal_original_release
  always @(posedge clk or posedge channel_reset)
   if(channel_reset)core_reset_pipe<=7;else core_reset_pipe<={core_reset_pipe[1:0],1'b0};
  always @(posedge rx_clk or posedge channel_reset)
   if(channel_reset)rx_reset_pipe<=7;else rx_reset_pipe<={rx_reset_pipe[1:0],1'b0};
 end endgenerate
 wire core_live=core_reset_pipe[2]===1'b0;
 wire rx_live=rx_reset_pipe[2]===1'b0;
 wire core_domain_reset=REGISTERED_CHANNEL_LIVE!=0?core_reset_pipe[2]:channel_reset;
 wire rx_domain_reset=REGISTERED_CHANNEL_LIVE!=0?rx_reset_pipe[2]:channel_reset;

 // Main->RX lease request. Bundle is held through its ACK and the full lease.
 (* DONT_TOUCH="TRUE" *) reg [96:0] lease_bundle;
 reg lease_request,open_pending,close_seen;
 reg [31:0] last_session,last_frame,last_epoch;
 reg rx_lease_ack,rx_lease_open;
 (* DONT_TOUCH="TRUE" *) reg [96:0] rx_lease_bundle;
 (* ASYNC_REG="TRUE" *) reg [2:0] lease_ack_sync,rx_open_sync,rx_closed_sync,rx_alive_sync,rx_quiet_sync,rx_ready_sync;
 (* ASYNC_REG="TRUE" *) reg [2:0] lease_req_sync,close_sync;
 wire tuple_known=(((owner_purpose_nn===1'b0)||(owner_purpose_nn===1'b1))&&
                   ((owner_session!=0)===1'b1)&&((owner_frame!=0)===1'b1)&&
                   ((owner_epoch!=0)===1'b1));
 wire rx_closed_ack,rx_owned_quiet;
 wire rx_ready_for_open=rx_closed_ack&&(close_sync[2]===1'b0);


 (* ram_style="block" *) reg [7:0] payload_mem[0:1023];
 reg [10:0] index;
 reg in_frame,dropping,oversize,owned_frame;
 reg [47:0] dst,src;reg [15:0] ethertype;
 reg [383:0] header;
 (* DONT_TOUCH="TRUE" *) reg [383:0] held_header,local_header;
 (* DONT_TOUCH="TRUE" *) reg [32:0] held_owner_epoch,local_owner_epoch;
 reg local_valid,release_pending;reg [7:0] payload_q;
 reg [31:0] header_crc,payload_crc;
 reg publish_pending,send_toggle,ack_toggle;
 (* ASYNC_REG="TRUE" *) reg [2:0] ack_sync,send_sync;
 wire mailbox_busy=(send_toggle!=ack_sync[2])||publish_pending;
 assign channel_live=REGISTERED_CHANNEL_LIVE!=0?(core_live&&rx_alive_sync[2]):
  ((rst_n===1'b1)&&(rx_reset===1'b0)&&core_live&&rx_alive_sync[2]);
 assign owner_opened=channel_live&&open_pending===1'b0&&lease_ack_sync[2]===lease_request&&
                     rx_open_sync[2]===1'b1&&owner_close===1'b0;
 assign owner_closed=channel_live&&rx_closed_sync[2]===1'b1&&open_pending===1'b0&&
                     lease_ack_sync[2]===lease_request&&!local_valid&&!payload_read_valid&&payload_read===1'b0;
 assign packet_quiescent=channel_live&&rx_quiet_sync[2]===1'b1&&!local_valid&&!payload_read_valid&&payload_read===1'b0;
 // NFR has no epoch field. Wire S/F must never repeat even when E changes.
 wire tuple_fresh=((owner_epoch>=last_epoch)===1'b1)&&
   ((owner_session>last_session)===1'b1)&&((owner_frame>last_frame)===1'b1);
 assign rx_owned_quiet=rx_live&&!owned_frame&&!publish_pending&&(send_toggle==ack_sync[2]);
 assign rx_closed_ack=rx_owned_quiet&&!rx_lease_open;
 assign packet_valid=owner_opened&&local_valid&&
                     local_owner_epoch==lease_bundle[96:64]&&
                     local_header[319:288]==lease_bundle[63:32]&&local_header[287:256]==lease_bundle[31:0];
 assign packet_header=packet_valid?local_header:384'd0;
 assign packet_purpose_nn=packet_valid?local_owner_epoch[32]:1'b0;
 assign packet_epoch=packet_valid?local_owner_epoch[31:0]:32'd0;
 assign payload_data=payload_read_valid?payload_q:8'd0;
 function automatic [31:0] crc_byte(input [31:0] c,input [7:0] d);
  reg [31:0] v;integer b;
  begin v=c^d;for(b=0;b<8;b=b+1)v=v[0]?(v>>1)^32'hedb88320:v>>1;crc_byte=v;end
 endfunction
 reg [383:0] next_header;
 always @* begin
  next_header=header;
  if(index>=14&&index<62)next_header[383-(index-14)*8-:8]=rx_data;
 end
 wire [15:0] length=next_header[127:112];
 wire [31:0] ending_payload_crc=index>=62?~crc_byte(payload_crc,rx_data):32'd0;
 wire header_ok=next_header[383:352]==32'h4e465231&&next_header[351:344]==1&&
    next_header[343:336]>=1&&next_header[343:336]<=6&&next_header[335:320]==48&&
    (next_header[199:192]&8'hfe)==0;
 wire envelope_ok=dst==LOCAL_MAC&&src==REMOTE_MAC&&ethertype==16'h88b5;
 wire lengths_ok=index>=61&&length<=1024&&index+1==62+length;
 wire crc_ok=(~header_crc)==next_header[31:0]&&ending_payload_crc==next_header[95:64];
 wire tuple_ok=next_header[319:288]==rx_lease_bundle[63:32]&&
   next_header[287:256]==rx_lease_bundle[31:0]&&next_header[255:240]==0&&
   next_header[239:224]==1920&&next_header[223:208]==1080&&next_header[207:200]==1&&
   next_header[199:192]==0&&next_header[191:160]==4147200;

 always @(posedge rx_clk or posedge rx_domain_reset)begin
  if(rx_domain_reset||!rx_live)begin
   index<=0;in_frame<=0;dropping<=0;oversize<=0;owned_frame<=0;dst<=0;src<=0;ethertype<=0;
   header<=0;held_header<=0;held_owner_epoch<=0;header_crc<=32'hffffffff;payload_crc<=32'hffffffff;
   send_toggle<=0;publish_pending<=0;ack_sync<=0;
   lease_req_sync<=0;close_sync<=7;rx_lease_ack<=0;rx_lease_open<=0;rx_lease_bundle<=0;
   received_packets<=0;bad_packets<=0;busy_drops<=0;foreign_drops<=0;
  end else begin
   ack_sync<={ack_sync[1:0],ack_toggle};
   lease_req_sync<={lease_req_sync[1:0],lease_request};close_sync<={close_sync[1:0],owner_close};
   publish_pending<=0;
   if(close_sync[2]!==1'b0)begin
    rx_lease_open<=0;owned_frame<=0;if(in_frame)dropping<=1;
    // ACK an abandoned OPEN only while closed; never arm it on CLOSE.
    if(lease_req_sync[2]!=rx_lease_ack)rx_lease_ack<=lease_req_sync[2];
   end else if(!rx_lease_open&&rx_owned_quiet&&lease_req_sync[2]!=rx_lease_ack)begin
    rx_lease_bundle<=lease_bundle;rx_lease_open<=1;rx_lease_ack<=lease_req_sync[2];
   end
   if(publish_pending&&rx_lease_open&&close_sync[2]===1'b0)begin
    held_header<=header;held_owner_epoch<=rx_lease_bundle[96:64];send_toggle<=!send_toggle;
   end
   if(rx_valid)begin
    if(!in_frame)begin
     in_frame<=1;oversize<=0;
     owned_frame<=rx_lease_open&&close_sync[2]===1'b0&&!mailbox_busy;
     dropping<=!(rx_lease_open&&close_sync[2]===1'b0&&!mailbox_busy);
     dst<={40'd0,rx_data};src<=0;ethertype<=0;header<=0;
     header_crc<=32'hffffffff;payload_crc<=32'hffffffff;index<=1;
    end else begin
     if(index<6)dst<={dst[39:0],rx_data};
     if(index>=6&&index<12)src<={src[39:0],rx_data};
     if(index>=12&&index<14)ethertype<={ethertype[7:0],rx_data};
     if(index>=14&&index<62)header<=next_header;
     if(index>=14&&index<58)header_crc<=crc_byte(header_crc,rx_data);
     if(index>=62)begin
      payload_crc<=crc_byte(payload_crc,rx_data);
      // Payload RAM write is in its reset-free dedicated clocked port.
     end
     if(index==2047)oversize<=1;else index<=index+1'b1;
    end
    if(rx_last)begin
     in_frame<=0;index<=0;owned_frame<=0;
     if(dropping||!owned_frame||!rx_lease_open||close_sync[2]!==1'b0)
      busy_drops<=busy_drops+1;
     else if(!in_frame||oversize||(rx_bad!==1'b0)||((envelope_ok&&header_ok&&lengths_ok&&crc_ok)!==1'b1))
      bad_packets<=bad_packets+1;
     else if(tuple_ok!==1'b1)foreign_drops<=foreign_drops+1;
     else begin publish_pending<=1;received_packets<=received_packets+1;end
    end
   end
  end
 end
 always @(posedge clk or posedge core_domain_reset)begin
  if(core_domain_reset||!core_live)begin
   lease_bundle<=0;lease_request<=0;open_pending<=0;close_seen<=0;
   lease_ack_sync<=0;rx_open_sync<=0;rx_closed_sync<=0;rx_alive_sync<=0;rx_quiet_sync<=0;rx_ready_sync<=0;
   send_sync<=0;ack_toggle<=0;local_header<=0;local_owner_epoch<=0;local_valid<=0;
   payload_read_valid<=0;release_pending<=0;
  end else begin
   lease_ack_sync<={lease_ack_sync[1:0],rx_lease_ack};rx_open_sync<={rx_open_sync[1:0],rx_lease_open};
   rx_closed_sync<={rx_closed_sync[1:0],rx_closed_ack};rx_alive_sync<={rx_alive_sync[1:0],rx_live};
   rx_quiet_sync<={rx_quiet_sync[1:0],rx_owned_quiet};rx_ready_sync<={rx_ready_sync[1:0],rx_ready_for_open};send_sync<={send_sync[1:0],send_toggle};
   if(owner_close!==1'b0)begin open_pending<=0;close_seen<=1;end
   else if(open_pending&&lease_ack_sync[2]==lease_request&&rx_open_sync[2])open_pending<=0;
   else if(owner_open===1'b1&&owner_closed&&rx_ready_sync[2]&&close_seen&&tuple_known&&tuple_fresh)begin
    lease_bundle<={owner_purpose_nn,owner_epoch,owner_session,owner_frame};
    lease_request<=!lease_request;open_pending<=1;close_seen<=0;
   end
   // CLOSE masks publication immediately. Discard an old complete mailbox only
   // after every accepted one-cycle payload read has returned to its old owner.
   if(packet_release&&local_valid)release_pending<=1;
   if(owner_close!==1'b0)begin
    if(payload_read===1'b0&&!payload_read_valid)begin
     if(local_valid||send_sync[2]!=ack_toggle)ack_toggle<=send_sync[2];
     local_valid<=0;release_pending<=0;
    end
   end else if(!local_valid&&owner_opened&&send_sync[2]!=ack_toggle)begin
    local_header<=held_header;local_owner_epoch<=held_owner_epoch;local_valid<=1;
   end else if(local_valid&&(packet_release||release_pending)&&payload_read===1'b0&&!payload_read_valid)begin
    ack_toggle<=send_sync[2];local_valid<=0;release_pending<=0;
   end
   payload_read_valid<=payload_read&&packet_valid&&(({6'd0,payload_address}<local_header[127:112])===1'b1);
   // Payload RAM read data has no reset; public valid retains the original immediate reset fence.
  end
 end
 // Reset-free simple-dual-port RAM. The RAM contents were never cleared;
 // only the private read register used an unsupported asynchronous reset.
 // Public payload_data remains zero whenever the original valid fence is zero.
 always @(posedge rx_clk)begin
  if(rx_domain_reset||!rx_live)begin end
  else if(rx_valid)begin
   if(!in_frame)begin end
   else if(index>=62)begin
    if(index<1086&&!dropping&&owned_frame&&rx_lease_open&&close_sync[2]===1'b0)
     payload_mem[index-62]<=rx_data;
   end
  end
 end
 always @(posedge clk)begin
  if(core_domain_reset||!core_live)begin end
  else if(payload_read&&packet_valid&&(({6'd0,payload_address}<local_header[127:112])===1'b1))payload_q<=payload_mem[payload_address];
 end
 // Preserve accepted tuple history across MAC-only resets. A held old OPEN
 // cannot resurrect its old label after either-domain channel reinitialization.
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin last_session<=0;last_frame<=0;last_epoch<=0;end
  else if(!core_domain_reset&&core_live&&owner_close===1'b0&&owner_open===1'b1&&
          owner_closed&&rx_ready_sync[2]&&close_seen&&tuple_known&&tuple_fresh)begin
   last_session<=owner_session;last_frame<=owner_frame;last_epoch<=owner_epoch;
  end
 end
 // All following registers are observation-only consumers.
 reg[63:0] diag_gray_rx;
 (* ASYNC_REG="TRUE" *) reg[63:0] diag_gray_core1,diag_gray_core2,diag_gray_core3;
 function automatic[15:0] diag_ungray(input[15:0]g);
  integer j;begin for(j=0;j<16;j=j+1)diag_ungray[j]=^(g>>j);end
 endfunction
 always@(posedge rx_clk or posedge rx_domain_reset)begin
  if(rx_domain_reset)diag_gray_rx<=0;
  else diag_gray_rx<={foreign_drops[15:0]^(foreign_drops[15:0]>>1),busy_drops[15:0]^(busy_drops[15:0]>>1),bad_packets[15:0]^(bad_packets[15:0]>>1),received_packets[15:0]^(received_packets[15:0]>>1)};
 end
 always@(posedge clk or posedge core_domain_reset)begin
  if(core_domain_reset)begin diag_gray_core1<=0;diag_gray_core2<=0;diag_gray_core3<=0;diagnostic_counts<=0;diagnostic_publications<=0;end
  else begin
   diag_gray_core1<=diag_gray_rx;diag_gray_core2<=diag_gray_core1;diag_gray_core3<=diag_gray_core2;
   diagnostic_counts<={diag_ungray(diag_gray_core3[63:48]),diag_ungray(diag_gray_core3[47:32]),diag_ungray(diag_gray_core3[31:16]),diag_ungray(diag_gray_core3[15:0])};
   if(!local_valid&&owner_opened&&send_sync[2]!=ack_toggle)diagnostic_publications<=diagnostic_publications+1'b1;
  end
 end
 reg[31:0]diag_local_status;
 always@(posedge clk)begin
  if(core_domain_reset)diag_local_status<=0;
  else diag_local_status<={18'd0,channel_live,owner_closed,owner_opened,rx_ready_sync[2],rx_quiet_sync[2],rx_open_sync[2],lease_bundle[96],close_seen,open_pending,payload_read,payload_read_valid,release_pending,local_valid,core_live};
 end
 // The existing core mailbox register is coherent. No RX held bus is exposed.
 assign diagnostic_local={local_header,lease_bundle[95:64],lease_bundle[31:0],lease_bundle[63:32],diag_local_status};
endmodule
