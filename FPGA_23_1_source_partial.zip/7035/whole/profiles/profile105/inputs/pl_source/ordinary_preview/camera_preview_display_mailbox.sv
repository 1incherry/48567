`timescale 1ns/1ps
// DISPLAY-ONLY relative AXI-Lite page. No enable/key/epoch/NN GO or NN DMA
// controls. Bank authority remains in camera_preview_banks. Board reset only.
module camera_preview_display_mailbox(
 input wire clk,board_resetn,
 input wire[11:0] s_axi_awaddr,input wire s_axi_awvalid,output wire s_axi_awready,
 input wire[31:0] s_axi_wdata,input wire[3:0] s_axi_wstrb,input wire s_axi_wvalid,output wire s_axi_wready,
 output reg[1:0] s_axi_bresp,output reg s_axi_bvalid,input wire s_axi_bready,
 input wire[11:0] s_axi_araddr,input wire s_axi_arvalid,output wire s_axi_arready,
 output reg[31:0] s_axi_rdata,output reg[1:0] s_axi_rresp,output reg s_axi_rvalid,input wire s_axi_rready,
 input wire offer_valid,offer_bank,input wire[31:0] offer_base,offer_session,offer_frame,offer_epoch,offer_crc,
 input wire display_valid,display_bank,input wire[31:0] display_session,display_frame,display_epoch,
 input wire[2:0] bank0_state,bank1_state,input wire bank_fault,
 input wire[31:0] bank0_session,bank0_frame,bank0_epoch,bank0_crc,bank1_session,bank1_frame,bank1_epoch,bank1_crc,
 input wire[31:0] rejected_releases,rejected_commits,
 output wire ps_commit_valid,ps_commit_bank,output wire[31:0] ps_commit_session,ps_commit_frame,ps_commit_epoch,ps_hdmi_seq,ps_hdmi_base,
 input wire ps_commit_ready,ps_commit_done,ps_commit_rejected,
 output wire ps_release_valid,ps_release_bank,output wire[31:0] ps_release_session,ps_release_frame,ps_release_epoch
);
 reg aw_held,w_held;reg[11:0] aw_addr;reg[31:0] w_data;reg[3:0] w_strb;
 reg[2:0] command_wait;reg[31:0] release_before;
 reg[5:0] staged;
 reg[31:0] accepted_token,terminal_token,terminal_kind,terminal_error,status_seq;
 reg local_fault;
 reg stage_bank;reg[31:0] stage_session,stage_frame,stage_epoch,stage_seq,stage_base;
 wire execute=aw_held&&w_held&&!s_axi_bvalid;
 wire commit_match=staged==6'b111111&&offer_valid&&stage_bank==offer_bank&&stage_session==offer_session&&stage_frame==offer_frame&&stage_epoch==offer_epoch&&stage_seq!=0&&(stage_base==32'h27000000||stage_base==32'h27800000);
 wire release_match=staged[3:0]==4'b1111&&(stage_bank?bank1_state:bank0_state)==4&&!(display_valid&&stage_bank==display_bank)&&stage_session==(stage_bank?bank1_session:bank0_session)&&stage_frame==(stage_bank?bank1_frame:bank0_frame)&&stage_epoch==(stage_bank?bank1_epoch:bank0_epoch);
 wire token_ok=accepted_token!=32'hffffffff&&!status_seq[0]&&!local_fault;
 wire queued_context=offer_valid&&stage_bank==offer_bank&&stage_session==offer_session&&stage_frame==offer_frame&&stage_epoch==offer_epoch;
 wire event_update=execute||(command_wait==1&&(!queued_context||bank_fault||ps_commit_ready))||(command_wait==3&&(ps_commit_done||ps_commit_rejected))||command_wait==4;
 wire full_command=execute&&command_wait==0&&aw_addr==12'h078&&w_strb==4'hf;
 // SAME-edge command acceptance and manager ready/match checks: no registered
 // VALID gap may lose a command during authorization revocation.
 assign ps_commit_valid=command_wait==1&&queued_context&&ps_commit_ready&&!bank_fault;
 assign ps_release_valid=command_wait==2;
 assign ps_commit_bank=stage_bank;assign ps_release_bank=stage_bank;
 assign ps_commit_session=stage_session;assign ps_release_session=stage_session;
 assign ps_commit_frame=stage_frame;assign ps_release_frame=stage_frame;
 assign ps_commit_epoch=stage_epoch;assign ps_release_epoch=stage_epoch;
 assign ps_hdmi_seq=stage_seq;assign ps_hdmi_base=stage_base;
 assign s_axi_awready=!aw_held&&!s_axi_bvalid;
 assign s_axi_wready=!w_held&&!s_axi_bvalid;
 assign s_axi_arready=!s_axi_rvalid||s_axi_rready;
 function automatic[33:0] read_word(input[11:0]a);
  reg[31:0]d;reg[1:0]r;
  begin d=0;r=0;case(a)
   8'h00:d=32'h50565732;8'h04:d=32'h00030000;
   8'h08:d={27'd0,ps_commit_rejected,bank_fault,!ps_commit_ready,display_valid,offer_valid};
   8'h0c:d={25'd0,bank1_state,1'b0,bank0_state};
   8'h10:d=offer_base;8'h14:d=offer_session;8'h18:d=offer_frame;8'h1c:d=offer_epoch;8'h20:d=offer_crc;8'h24:d={31'd0,offer_bank};
   8'h28:d=display_session;8'h2c:d=display_frame;8'h30:d=display_epoch;8'h34:d={30'd0,display_valid,display_bank};
   8'h38:d=rejected_releases;8'h3c:d=rejected_commits;
   8'h80:d=bank0_session;8'h84:d=bank0_frame;8'h88:d=bank0_epoch;8'h8c:d=bank0_crc;
   8'h90:d=bank1_session;8'h94:d=bank1_frame;8'h98:d=bank1_epoch;8'h9c:d=bank1_crc;
   8'h60:d={31'd0,stage_bank};8'h64:d=stage_session;8'h68:d=stage_frame;8'h6c:d=stage_epoch;8'h70:d=stage_seq;8'h74:d=stage_base;
   12'h0a0:d={28'd0,local_fault,command_wait};
   12'h0a4:d=accepted_token;12'h0a8:d=terminal_token;
   12'h0ac:d=terminal_kind;12'h0b0:d=terminal_error;12'h0b4:d=status_seq;
   12'h0b8:d={26'd0,staged};
   default:r=2;
  endcase read_word={r,d};end
 endfunction
 always@(posedge clk)begin
  if(!board_resetn)begin
   aw_held<=0;w_held<=0;aw_addr<=0;w_data<=0;w_strb<=0;s_axi_bvalid<=0;s_axi_bresp<=0;
   s_axi_rvalid<=0;s_axi_rdata<=0;s_axi_rresp<=0;command_wait<=0;release_before<=0;
   staged<=0;accepted_token<=0;terminal_token<=0;terminal_kind<=0;terminal_error<=0;status_seq<=0;local_fault<=0;
   stage_bank<=0;stage_session<=0;stage_frame<=0;stage_epoch<=0;stage_seq<=0;stage_base<=0;
  end else begin
   if(s_axi_bvalid&&s_axi_bready)s_axi_bvalid<=0;
   if(s_axi_rvalid&&s_axi_rready)s_axi_rvalid<=0;
   if(s_axi_awvalid&&s_axi_awready)begin aw_addr<=s_axi_awaddr;aw_held<=1;end
   if(s_axi_wvalid&&s_axi_wready)begin w_data<=s_axi_wdata;w_strb<=s_axi_wstrb;w_held<=1;end
   if(s_axi_arvalid&&s_axi_arready)begin {s_axi_rresp,s_axi_rdata}<=read_word(s_axi_araddr);s_axi_rvalid<=1;end
   if(execute)begin
    aw_held<=0;w_held<=0;s_axi_bresp<=0;
    if(command_wait!=0||local_fault||status_seq[0]||w_strb!=4'hf)begin s_axi_bvalid<=1;s_axi_bresp<=2;end
    else case(aw_addr)
     8'h60:begin if(w_data>1)s_axi_bresp<=2;else begin stage_bank<=w_data[0];staged[0]<=1;end s_axi_bvalid<=1;end
     8'h64:begin stage_session<=w_data;staged[1]<=1;s_axi_bvalid<=1;end
     8'h68:begin stage_frame<=w_data;staged[2]<=1;s_axi_bvalid<=1;end
     8'h6c:begin stage_epoch<=w_data;staged[3]<=1;s_axi_bvalid<=1;end
     8'h70:begin stage_seq<=w_data;staged[4]<=1;s_axi_bvalid<=1;end
     8'h74:begin stage_base<=w_data;staged[5]<=1;s_axi_bvalid<=1;end
     8'h78:case(w_data)
      1:begin s_axi_bvalid<=1;
       if(token_ok&&commit_match&&!bank_fault)begin command_wait<=1;accepted_token<=accepted_token+1;staged<=0;end
       else s_axi_bresp<=2;
      end
      2:begin s_axi_bvalid<=1;
       if(token_ok&&release_match&&!bank_fault)begin command_wait<=2;accepted_token<=accepted_token+1;staged<=0;end
       else s_axi_bresp<=2;
      end
      default:begin s_axi_bvalid<=1;s_axi_bresp<=2;end
     endcase
     default:begin s_axi_bvalid<=1;s_axi_bresp<=2;end
    endcase
   end
   // Queue is independent of AXI B: callback only updates RO terminal state.
   // The bank manager remains the sole owner of actual ACK/boundary/frame checks.
   case(command_wait)
    1:if(!queued_context||bank_fault)begin
       command_wait<=0;terminal_token<=accepted_token;terminal_kind<=2;terminal_error<=1;
      end else if(ps_commit_valid&&ps_commit_ready)command_wait<=3;
    2:begin release_before<=rejected_releases;command_wait<=4;end
    3:if(ps_commit_done||ps_commit_rejected)begin
       command_wait<=0;terminal_token<=accepted_token;
       terminal_kind<=ps_commit_rejected?2:1;terminal_error<=ps_commit_rejected?2:0;
      end
    4:begin command_wait<=0;terminal_token<=accepted_token;
       terminal_kind<=rejected_releases==release_before?3:2;
       terminal_error<=rejected_releases==release_before?0:3;
      end
    default:begin end
   endcase
   if(event_update&&!status_seq[0])begin
    if(status_seq>=32'hfffffffc)status_seq<=32'hffffffff;else status_seq<=status_seq+2;
   end
   if(status_seq[0]||(event_update&&status_seq>=32'hfffffffc))local_fault<=1;

  end
 end
endmodule
