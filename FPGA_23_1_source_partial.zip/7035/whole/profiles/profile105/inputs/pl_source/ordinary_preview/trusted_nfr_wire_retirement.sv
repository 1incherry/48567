`timescale 1ns/1ps
// NN RAW ownership and the camera wire transaction are separate obligations.
// This block only retires the latter. It has no NN cancel, seal, DDR or PS port.
module trusted_nfr_wire_retirement #(
 parameter ENABLE=0
)(
 input wire clk,board_resetn,new_nn_accept,
 input wire raw_sealed,raw_frame_ready,raw_transport_idle,
 input wire raw_response_valid,packet_quiescent,response_tx_quiescent,
 input wire[31:0] owner_session,owner_frame,owner_epoch,
 input wire[31:0] raw_frame_crc,
 output reg raw_consume_done,output wire drop_nn_packets,
 output wire cancel_valid,input wire cancel_ready,
 output wire[31:0] cancel_session,cancel_frame,cancel_epoch,cancel_crc,
 output wire wire_retired,release_pending,output wire[2:0] state_debug
);
 localparam WAIT_SEAL=0,CONSUME=1,DRAIN=2,OFFER_CANCEL=3,WAIT_TX=4,RETIRED=5;
 reg[2:0] state;
 reg[31:0] held_session,held_frame,held_epoch,held_crc;
 reg tx_busy_seen;
 assign state_debug=state;
 assign release_pending=ENABLE!=0&&state!=WAIT_SEAL&&state!=RETIRED;
 assign drop_nn_packets=ENABLE!=0&&state>=CONSUME;
 assign cancel_valid=ENABLE!=0&&state==OFFER_CANCEL;
 assign cancel_session=held_session;assign cancel_frame=held_frame;
 assign cancel_epoch=held_epoch;assign cancel_crc=held_crc;
 // Local ACK is only a local obligation. The next REQUEST must still establish
 // a new peer transaction by receiving real DATA for its new unique tuple.
 assign wire_retired=ENABLE!=0&&state==RETIRED&&raw_transport_idle&&
                     packet_quiescent&&response_tx_quiescent&&!raw_response_valid;
 always@(posedge clk)begin
  if(!board_resetn||new_nn_accept)begin
   state<=WAIT_SEAL;raw_consume_done<=0;held_session<=0;held_frame<=0;
   held_epoch<=0;held_crc<=0;tx_busy_seen<=0;
  end else begin
   raw_consume_done<=0;
   if(ENABLE!=0)case(state)
    WAIT_SEAL:if(raw_sealed&&raw_frame_ready&&!raw_response_valid&&
                  packet_quiescent&&response_tx_quiescent)begin
     held_session<=owner_session;held_frame<=owner_frame;
     held_epoch<=owner_epoch;held_crc<=raw_frame_crc;state<=CONSUME;
    end
    CONSUME:begin raw_consume_done<=1;state<=DRAIN;end
    DRAIN:if(raw_transport_idle&&!raw_response_valid&&packet_quiescent&&response_tx_quiescent)
     state<=OFFER_CANCEL;
    OFFER_CANCEL:if(cancel_valid&&cancel_ready)begin tx_busy_seen<=0;state<=WAIT_TX;end
    WAIT_TX:begin
     if(!response_tx_quiescent)tx_busy_seen<=1;
     if(tx_busy_seen&&response_tx_quiescent&&packet_quiescent&&
        raw_transport_idle&&!raw_response_valid)state<=RETIRED;
    end
    RETIRED:begin end
    default:state<=WAIT_SEAL;
   endcase
  end
 end
 // synthesis translate_off
 always@(posedge clk)if(board_resetn&&ENABLE!=0)begin
  if(new_nn_accept&&state!=WAIT_SEAL&&state!=RETIRED)
   $fatal(1,"NEW_NN_BEFORE_OLD_WIRE_LOCAL_DRAIN");
  if(cancel_valid&&(held_session==0||held_frame==0||held_epoch==0))
   $fatal(1,"WIRE_CANCEL_WITHOUT_CAPTURED_OWNER");
 end
 // synthesis translate_on
endmodule
