`timescale 1ns/1ps
// Untrusted DISPLAY-only RGBX32 provider. CRC is transport checking, NOT camera
// authenticity. No NN seal, inference GO, authorization or tensor port exists.
module display_nfr640_backend #(
 parameter integer TIMEOUT_CYCLES=500000000,
 parameter integer REQUEST_RETRY_CYCLES=10000000
)(
 input wire clk,board_resetn,
 input wire capture_valid,output wire capture_ready,
 input wire capture_owner_valid,capture_purpose_nn,
 input wire [31:0] capture_base,capture_session,capture_frame,capture_epoch,
 input wire capture_cancel,capture_consume_done,
 output reg provider_done,provider_error,
 output wire provider_crc_ok,provider_source_verified,provider_purpose_nn,
 output reg [31:0] provider_base,provider_session,provider_frame,provider_epoch,
 output reg [31:0] provider_committed_bytes,provider_crc,
 output wire provider_idle,packet_quiescent,response_quiescent,ddr_quiescent,
 // Real shared endpoint/response-transmitter quiet, not tied constants.
 input wire packet_path_quiescent,response_tx_quiescent,
 // Must be fed by the actual nfr_packet_rx header/payload-CRC checked mailbox.
 input wire packet_valid,input wire [383:0] packet_header,
 output wire packet_release,payload_read,output wire [9:0] payload_address,
 input wire [7:0] payload_data,input wire payload_read_valid,
 output wire response_valid,input wire response_ready,
 output wire [7:0] response_kind,response_flags,
 output wire [31:0] response_offset,response_frame_crc,
 output wire [31:0] response_session_id,response_frame_id,response_total_bytes,
 output wire [15:0] response_width,response_height,
 output wire [31:0] m_awaddr,output wire [7:0] m_awlen,
 output wire [2:0] m_awsize,output wire [1:0] m_awburst,
 output wire m_awvalid,input wire m_awready,
 output wire [63:0] m_wdata,output wire [7:0] m_wstrb,
 output wire m_wlast,m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready
);
 reg active_capture;
 wire sink_start_ready,sink_busy,sink_ready,sink_fault;
 wire [31:0] sink_frame,sink_offset,sink_crc,sink_base,sink_session,sink_id,sink_total;
 wire [15:0] sink_width,sink_height;wire [7:0] sink_flags;
 wire local_packet_quiet,local_response_quiet,local_ddr_quiet,local_transaction_quiet;
 wire base_ok=capture_base==32'h25000000||capture_base==32'h25800000;
 wire request_ok=capture_owner_valid&&!capture_purpose_nn&&base_ok&&capture_session!=0&&capture_frame!=0;
 assign packet_quiescent=local_packet_quiet&&packet_path_quiescent;
 assign response_quiescent=local_response_quiet&&response_tx_quiescent;
 assign ddr_quiescent=local_ddr_quiet;
 assign provider_idle=!active_capture&&!provider_done&&local_transaction_quiet&&packet_path_quiescent&&response_tx_quiescent;
 assign capture_ready=provider_idle&&sink_start_ready&&request_ok&&!capture_cancel;
 wire accepted=capture_valid&&capture_ready;
 wire consume=capture_consume_done&&provider_done;
 // An idle completed-frame duplicate may still need a DONE reply. Do not let
 // a later cancel suppress that replay forever when no burst/task is active.
 wire sink_cancel=sink_busy&&(capture_cancel||(active_capture&&!capture_owner_valid));
 assign provider_crc_ok=provider_done&&!provider_error;
 assign provider_source_verified=1'b0; // DISPLAY is NEVER an authenticated NN source.
 assign provider_purpose_nn=1'b0;
 nfr_preview640_rgbx_sink #(.TIMEOUT_CYCLES(TIMEOUT_CYCLES),.REQUEST_RETRY_CYCLES(REQUEST_RETRY_CYCLES)) sink(
  .clk(clk),.rst_n(board_resetn),.start(accepted),.cancel(sink_cancel),.consume_done(consume),
  .pattern(1'b0),.display_bank(capture_base==32'h25800000),
  .request_session(capture_session),.request_frame(capture_frame),
  .start_ready(sink_start_ready),.busy(sink_busy),.frame_ready(sink_ready),.fault(sink_fault),
  .completed_frame(sink_frame),.committed_offset(sink_offset),.received_crc(sink_crc),.frame_base(sink_base),
  .packet_valid(packet_valid),.packet_header(packet_header),.packet_release(packet_release),
  .payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
  .response_valid(response_valid),.response_ready(response_ready),.response_kind(response_kind),
  .response_offset(response_offset),.response_frame_crc(response_frame_crc),
  .response_session_id(response_session_id),.response_frame_id(response_frame_id),.response_total_bytes(response_total_bytes),
  .response_width(response_width),.response_height(response_height),.response_flags(response_flags),
  .session_id(sink_session),.frame_id(sink_id),.total_bytes(sink_total),.width(sink_width),.height(sink_height),.flags(sink_flags),
  .m_awaddr(m_awaddr),.m_awlen(m_awlen),.m_awsize(m_awsize),.m_awburst(m_awburst),.m_awvalid(m_awvalid),.m_awready(m_awready),
  .m_wdata(m_wdata),.m_wstrb(m_wstrb),.m_wlast(m_wlast),.m_wvalid(m_wvalid),.m_wready(m_wready),
  .m_bresp(m_bresp),.m_bvalid(m_bvalid),.m_bready(m_bready),
  .packet_local_quiescent(local_packet_quiet),.response_local_quiescent(local_response_quiet),
  .ddr_local_quiescent(local_ddr_quiet),.transaction_quiescent(local_transaction_quiet));
 always @(posedge clk)begin
  if(!board_resetn)begin
   active_capture<=0;provider_done<=0;provider_error<=0;
   provider_base<=0;provider_session<=0;provider_frame<=0;provider_epoch<=0;
   provider_committed_bytes<=0;provider_crc<=0;
  end else begin
   if(accepted)begin
    active_capture<=1;provider_done<=0;provider_error<=0;
    provider_base<=capture_base;provider_session<=capture_session;
    provider_frame<=capture_frame;provider_epoch<=capture_epoch;
    provider_committed_bytes<=0;provider_crc<=0;
   end else if(consume)begin
    active_capture<=0;provider_done<=0;
   end else if(active_capture&&!provider_done)begin
    if(sink_ready)begin
     provider_done<=1;provider_crc<=sink_crc;provider_committed_bytes<=sink_offset<<1;
     provider_error<=sink_fault||sink_base!=provider_base||sink_session!=provider_session||
      sink_frame!=provider_frame||sink_id!=provider_frame||sink_total!=4147200||
      sink_width!=1920||sink_height!=1080||sink_offset!=4147200;
    end else if(sink_fault&&!sink_busy&&local_ddr_quiet)begin
     provider_done<=1;provider_error<=1;provider_committed_bytes<=sink_offset<<1;provider_crc<=sink_crc;
    end
   end
  end
 end
endmodule
