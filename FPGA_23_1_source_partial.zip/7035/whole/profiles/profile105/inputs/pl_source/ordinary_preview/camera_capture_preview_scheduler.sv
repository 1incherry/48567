`timescale 1ns/1ps
// Same-domain component. All provider/owner/NN retirement inputs must be real PL
// completion signals. No PS input can allocate the NN tuple, seal NN data or GO.
module camera_capture_preview_scheduler #(
 parameter PREVIEW_PERIOD=50000000, parameter CAPTURE_TIMEOUT=250000000,parameter NN_OWNER_OPEN_TIMEOUT=1500000000,parameter HONOR_TRUSTED_CANCEL=0,parameter CONTINUOUS_NN_PREVIEW=0
)(
 input wire clk,board_resetn,root_live,input wire[31:0] authorization_epoch,
 input wire trusted_cancel,input wire preview_enable,nn_intent,nn_request,output wire nn_request_ready,
 output wire[31:0] next_session,next_frame,output wire exhausted,
 output wire nn_owner_opened,nn_abort,
 input wire nn_active,nn_retired,nn_error,
 input wire[1:0] preview_free_mask,input wire preview_offer_valid,preview_bank_fault,
 output reg bank_alloc_valid,bank_alloc_bank,output wire[31:0] bank_alloc_session,bank_alloc_frame,bank_alloc_epoch,
 output reg bank_publish_valid,output wire bank_publish_bank,output wire[31:0] bank_publish_session,bank_publish_frame,bank_publish_epoch,bank_publish_crc,
 input wire bank_publish_ready,
 output reg bank_abort_valid,output wire bank_abort_bank,output wire[31:0] bank_abort_session,bank_abort_frame,bank_abort_epoch,
 output wire owner_close,input wire owner_closed,output wire owner_open,input wire owner_opened,
 output wire owner_valid,owner_purpose_nn,output wire[31:0] owner_session,owner_frame,owner_epoch,
 output wire capture_valid,input wire capture_ready,output wire capture_owner_valid,capture_purpose_nn,
 output wire[31:0] capture_base,capture_session,capture_frame,capture_epoch,
 output wire capture_cancel,output reg capture_consume_done,
 input wire provider_done,provider_error,provider_crc_ok,provider_source_verified,
 input wire provider_purpose_nn,input wire[31:0] provider_base,provider_session,provider_frame,provider_epoch,provider_committed_bytes,provider_crc,
 input wire packet_quiescent,response_quiescent,ddr_quiescent,provider_idle,
 output reg fault,output reg[7:0] fault_code,
 output reg[31:0] preview_completed,preview_aborted,nn_completed,nn_aborted,last_session,last_frame,
 output wire[3:0] state_debug,
 input wire nn_wire_retired,nn_raw_slot_ready,nn_wire_release_pending,
 output reg nn_retire_pulse,nn_retire_failed
);
 localparam IDLE=0,OPEN=1,OFFER=2,ACTIVE=3,DRAIN=4,RETIRE=5,CLOSE=6,NN_ACTIVE=7,FAILED=8;
 reg[3:0] state;
 reg own_nn,own_bank,bad,terminal_fault,good,nn_seen_active;
 reg nn_slot_live,nn_slot_seen,nn_slot_bad;reg[31:0]nn_slot_epoch;
 reg[31:0] own_session,own_frame,own_epoch,own_crc,period_count,timer;
 wire real_drain=packet_quiescent&&response_quiescent&&ddr_quiescent;
 wire stop_requested=HONOR_TRUSTED_CANCEL&&(trusted_cancel!==1'b0);
 wire healthy=root_live&&authorization_epoch!=0&&!stop_requested;
 wire epoch_lost=!healthy||authorization_epoch!=own_epoch;
 wire free_bank=preview_free_mask[0]?1'b0:1'b1;
 wire identity=!provider_purpose_nn&&provider_base==capture_base&&provider_session==own_session&&provider_frame==own_frame&&provider_epoch==own_epoch;
 wire idle_safe=state==IDLE&&owner_closed&&real_drain&&provider_idle&&!provider_done;
 assign next_session=last_session+1'b1;assign next_frame=last_frame+1'b1;
 assign exhausted=last_session==32'hffffffff||last_frame==32'hffffffff;
 assign nn_request_ready=idle_safe&&healthy&&!fault&&!preview_bank_fault&&!exhausted&&(CONTINUOUS_NN_PREVIEW==0||(!nn_slot_live&&(nn_raw_slot_ready===1'b1)));
 // Same-transition Moore output. Mirror the actual next-state if branches,
 // including four-state if semantics; never register the previous decode.
 (* KEEP = "TRUE" *) reg owner_close_q;
 assign owner_close=owner_close_q;
 always@(posedge clk)begin
  if(!board_resetn)owner_close_q<=1'b1;
  else case(state)
   IDLE:begin
    owner_close_q<=1'b1;
    if(preview_bank_fault)owner_close_q<=1'b1;
    else if(provider_done)owner_close_q<=1'b1;
    else if(idle_safe&&healthy&&!fault)begin
     if(nn_request&&nn_request_ready)owner_close_q<=1'b0;
     else if(preview_enable&&!nn_intent&&period_count>=PREVIEW_PERIOD&&|preview_free_mask&&!preview_offer_valid&&!bank_publish_valid&&!bank_alloc_valid)begin
      if(exhausted)owner_close_q<=1'b1;
      else owner_close_q<=1'b0;
     end
    end
   end
   RETIRE:begin
    owner_close_q<=1'b0;
    if(provider_idle&&!provider_done&&real_drain)owner_close_q<=1'b1;
   end
   NN_ACTIVE:begin
    owner_close_q<=1'b0;
    if(CONTINUOUS_NN_PREVIEW!=0)begin
     if((nn_wire_retired===1'b1)&&real_drain)owner_close_q<=1'b1;
     else if(nn_slot_seen&&nn_retired&&!nn_active&&real_drain&&(nn_wire_release_pending===1'b0))owner_close_q<=1'b1;
    end else begin
     if(nn_seen_active&&nn_retired&&!nn_active&&real_drain)owner_close_q<=1'b1;
    end
   end
   CLOSE,FAILED:owner_close_q<=1'b1;
   OPEN,OFFER,ACTIVE,DRAIN:owner_close_q<=1'b0;
   default:owner_close_q<=1'b1;
  endcase
 end
 assign owner_open=state==OPEN;
 assign owner_valid=state!=IDLE&&state!=FAILED;
 assign owner_purpose_nn=own_nn;
 assign owner_session=own_session;assign owner_frame=own_frame;assign owner_epoch=own_epoch;
 assign nn_owner_opened=own_nn&&state==NN_ACTIVE&&!bad&&!epoch_lost;
 assign nn_abort=CONTINUOUS_NN_PREVIEW!=0?(nn_slot_live&&(nn_slot_bad||!healthy||authorization_epoch!=nn_slot_epoch||nn_error||preview_bank_fault)):(own_nn&&owner_valid&&(bad||epoch_lost||nn_error));
 assign capture_valid=state==OFFER&&!nn_intent&&!epoch_lost&&!preview_bank_fault;
 assign capture_owner_valid=owner_valid&&!own_nn;
 assign capture_purpose_nn=1'b0;
 assign capture_base=own_bank?32'h25800000:32'h25000000;
 assign capture_session=own_session;assign capture_frame=own_frame;assign capture_epoch=own_epoch;
 assign capture_cancel=capture_owner_valid&&(bad||epoch_lost||nn_intent||preview_bank_fault);
 assign bank_alloc_session=own_session;assign bank_alloc_frame=own_frame;assign bank_alloc_epoch=own_epoch;
 assign bank_publish_bank=own_bank;assign bank_publish_session=own_session;assign bank_publish_frame=own_frame;assign bank_publish_epoch=own_epoch;assign bank_publish_crc=own_crc;
 assign bank_abort_bank=own_bank;assign bank_abort_session=own_session;assign bank_abort_frame=own_frame;assign bank_abort_epoch=own_epoch;
 assign state_debug=state;
 task frame_bad;input[7:0] why;begin bad<=1;good<=0;fault_code<=why;state<=DRAIN;end endtask
 always@(posedge clk)begin
  if(!board_resetn)begin
   state<=IDLE;own_nn<=0;own_bank<=0;bad<=0;terminal_fault<=0;good<=0;nn_seen_active<=0;
   nn_slot_live<=0;nn_slot_seen<=0;nn_slot_bad<=0;nn_slot_epoch<=0;nn_retire_pulse<=0;nn_retire_failed<=0;
   own_session<=0;own_frame<=0;own_epoch<=0;own_crc<=0;period_count<=0;timer<=0;
   bank_alloc_valid<=0;bank_alloc_bank<=0;bank_publish_valid<=0;bank_abort_valid<=0;capture_consume_done<=0;
   fault<=0;fault_code<=0;preview_completed<=0;preview_aborted<=0;nn_completed<=0;nn_aborted<=0;last_session<=0;last_frame<=0;
  end else begin
   bank_alloc_valid<=0;bank_publish_valid<=0;bank_abort_valid<=0;capture_consume_done<=0;
   nn_retire_pulse<=0;nn_retire_failed<=0;
   if(CONTINUOUS_NN_PREVIEW!=0)begin
    // The NN slot is NOT the wire owner. It survives preview allocations.
    if(nn_slot_live)begin
     if(nn_active)nn_slot_seen<=1;
     if(!healthy||authorization_epoch!=nn_slot_epoch||nn_error||preview_bank_fault)nn_slot_bad<=1;
     // nn_retired is the real NN/camera/HP retirement. Preview traffic is
     // unrelated and must not manufacture or delay this completion.
     if(nn_slot_seen&&nn_retired&&!nn_active)begin
      nn_slot_live<=0;nn_retire_pulse<=1;
      nn_retire_failed<=nn_slot_bad||!healthy||authorization_epoch!=nn_slot_epoch||nn_error||preview_bank_fault;
      if(nn_slot_bad||!healthy||authorization_epoch!=nn_slot_epoch||nn_error||preview_bank_fault)nn_aborted<=nn_aborted+1'b1;
      else nn_completed<=nn_completed+1'b1;
     end
    end
    if(nn_request&&nn_request_ready)begin
     nn_slot_live<=1;nn_slot_seen<=0;nn_slot_bad<=0;nn_slot_epoch<=authorization_epoch;
    end
   end

   if(preview_enable&&healthy&&!fault)begin
    if(period_count<PREVIEW_PERIOD)period_count<=period_count+1'b1;
   end else period_count<=0;
   // Preserve real coordinator activity seen while RX OPEN is still crossing domains.
   // A legitimate early abort may retire before NN_ACTIVE is entered.
   if(own_nn&&owner_valid&&nn_active)nn_seen_active<=1;
   case(state)
    IDLE:begin
     bad<=0;terminal_fault<=0;good<=0;timer<=0;nn_seen_active<=0;
     if(preview_bank_fault)begin fault<=1;fault_code<=8'h0a;state<=FAILED;end
     else if(provider_done)begin fault<=1;fault_code<=8'h09;state<=FAILED;end
     else if(idle_safe&&healthy&&!fault)begin
      // nn_request is the actual accepted GO, never a pending command queue.
      if(nn_request&&nn_request_ready)begin
       own_nn<=1;own_session<=next_session;own_frame<=next_frame;own_epoch<=authorization_epoch;
       last_session<=next_session;last_frame<=next_frame;state<=OPEN;
      end else if(preview_enable&&!nn_intent&&period_count>=PREVIEW_PERIOD&&|preview_free_mask&&!preview_offer_valid&&!bank_publish_valid&&!bank_alloc_valid)begin
       if(exhausted)begin fault<=1;fault_code<=8'h01;state<=FAILED;end
       else begin
        own_nn<=0;own_bank<=free_bank;own_session<=next_session;own_frame<=next_frame;own_epoch<=authorization_epoch;
        last_session<=next_session;last_frame<=next_frame;period_count<=0;
        bank_alloc_valid<=1;bank_alloc_bank<=free_bank;state<=OPEN;
       end
      end
     end
    end
    OPEN:begin
     timer<=timer+1;
     if(epoch_lost||preview_bank_fault)begin bad<=1;if(preview_bank_fault)terminal_fault<=1;fault_code<=preview_bank_fault?8'h0a:8'h02;state<=own_nn?NN_ACTIVE:DRAIN;end
     else if(!own_nn&&nn_intent)begin bad<=1;state<=DRAIN;end
     else if(timer>=(own_nn?NN_OWNER_OPEN_TIMEOUT:CAPTURE_TIMEOUT))begin bad<=1;if(CONTINUOUS_NN_PREVIEW==0||own_nn)terminal_fault<=1;fault_code<=8'h04;state<=own_nn?NN_ACTIVE:DRAIN;end
     else if(owner_opened)begin state<=own_nn?NN_ACTIVE:OFFER;timer<=0;end
    end
    OFFER:begin
     // Cancel before a provider start has no provider-done credit to consume.
     if(epoch_lost||preview_bank_fault)begin bad<=1;if(preview_bank_fault)terminal_fault<=1;fault_code<=preview_bank_fault?8'h0a:8'h02;state<=DRAIN;end
     else if(nn_intent)begin bad<=1;state<=DRAIN;end
     else if(capture_valid&&capture_ready)begin state<=ACTIVE;timer<=0;end
     else if(timer>=CAPTURE_TIMEOUT)begin bad<=1;if(CONTINUOUS_NN_PREVIEW==0)terminal_fault<=1;fault_code<=8'h04;state<=DRAIN;end
     else timer<=timer+1;
    end
    ACTIVE:begin
     timer<=timer+1;
     if(epoch_lost||preview_bank_fault)begin if(preview_bank_fault)terminal_fault<=1;frame_bad(preview_bank_fault?8'h0a:8'h02);end
     else if(nn_intent)frame_bad(8'h10);
     else if(provider_error)frame_bad(8'h03);
     else if(timer>=CAPTURE_TIMEOUT)begin if(CONTINUOUS_NN_PREVIEW==0)terminal_fault<=1;frame_bad(8'h04);end
     else if(provider_done)begin
      if(!identity)begin terminal_fault<=1;frame_bad(8'h05);end
      else if(!provider_crc_ok)frame_bad(8'h06);
      else if(provider_committed_bytes!=8294400)frame_bad(8'h08);
      else begin own_crc<=provider_crc;good<=1;state<=DRAIN;end
     end
    end
    DRAIN:begin
     if(epoch_lost||preview_bank_fault)begin bad<=1;good<=0;if(preview_bank_fault)terminal_fault<=1;fault_code<=preview_bank_fault?8'h0a:8'h02;end
     if(provider_error||nn_intent)begin bad<=1;good<=0;end
     // A real done credit, including error, is consumed only after all drains.
     // If no start was accepted, provider_idle proves there is no credit.
     if(real_drain&&(provider_done||provider_idle))begin
      if(bad||provider_error||nn_intent||epoch_lost||preview_bank_fault)begin
       bank_abort_valid<=1;preview_aborted<=preview_aborted+1'b1;
       if(provider_done)capture_consume_done<=1;state<=RETIRE;
      end else if(good&&provider_done&&bank_publish_ready)begin
       bank_publish_valid<=1;preview_completed<=preview_completed+1'b1;capture_consume_done<=1;state<=RETIRE;
      end
     end
    end
    RETIRE:begin
     if(epoch_lost||preview_bank_fault)begin if(preview_bank_fault)terminal_fault<=1;fault_code<=preview_bank_fault?8'h0a:8'h02;end
     if(provider_idle&&!provider_done&&real_drain)state<=CLOSE;
    end
    NN_ACTIVE:begin
     if(nn_active)nn_seen_active<=1;
     if(epoch_lost||nn_error||preview_bank_fault)begin bad<=1;if(preview_bank_fault)terminal_fault<=1;fault_code<=preview_bank_fault?8'h0a:(epoch_lost?8'h02:8'h0b);end
     // nn_retired is the old coordinator full job/sink/consumer retirement,
     // not raw-frame arrival. It must be seen after actual NN activity.
     if(CONTINUOUS_NN_PREVIEW!=0)begin
      // A retired RAW wire path is safe to close while NN still reads220.
      // Failed/early-open jobs without a seal close only after trueNN retirement.
      if((nn_wire_retired===1'b1)&&real_drain)state<=CLOSE;
      else if(nn_slot_seen&&nn_retired&&!nn_active&&real_drain&&(nn_wire_release_pending===1'b0))state<=CLOSE;
     end else begin
     if(nn_seen_active&&nn_retired&&!nn_active&&real_drain)begin if(bad||epoch_lost||nn_error||preview_bank_fault)nn_aborted<=nn_aborted+1'b1;else nn_completed<=nn_completed+1'b1;state<=CLOSE;end
     end
    end
    CLOSE:begin
     if(epoch_lost)begin bad<=1;if(!terminal_fault)fault_code<=8'h02;end
     if(owner_closed&&real_drain&&provider_idle&&!provider_done)begin
      if(terminal_fault)begin fault<=1;state<=FAILED;end else state<=IDLE;
     end
    end
    FAILED:begin end
    default:begin fault<=1;terminal_fault<=1;fault_code<=8'hff;state<=FAILED;end
   endcase
  end
 end
endmodule
