`timescale 1ns/1ps
// Private component, sameclock interface. Providerports are trustedPL only.
// PScontrols affectdisplay ownership only, neverNN authorization orRAW220.
module camera_preview_banks #(parameter COMMIT_TIMEOUT=50000000)(
 input wire clk,board_resetn,root_live,input wire[31:0] authorization_epoch,
 input wire alloc_valid,alloc_bank,input wire[31:0] alloc_session,alloc_frame,alloc_epoch,
 output wire alloc_ready,output wire[1:0] free_mask,
 input wire publish_valid,publish_bank,input wire[31:0] publish_session,publish_frame,publish_epoch,publish_crc,
 output wire publish_ready,
 input wire abort_valid,abort_bank,input wire[31:0] abort_session,abort_frame,abort_epoch,
 output wire offer_valid,offer_bank,output wire[31:0] offer_base,offer_session,offer_frame,offer_epoch,offer_crc,
 input wire ps_commit_valid,ps_commit_bank,input wire[31:0] ps_commit_session,ps_commit_frame,ps_commit_epoch,ps_hdmi_seq,ps_hdmi_base,
 output wire ps_commit_ready,output reg ps_commit_done,ps_commit_rejected,
 input wire ps_release_valid,ps_release_bank,input wire[31:0] ps_release_session,ps_release_frame,ps_release_epoch,
 input wire[31:0] hdmi_ack_seq,hdmi_active_base,hdmi_frames,input wire hdmi_healthy,
 output reg display_valid,display_bank,output wire[31:0] display_session,display_frame,display_epoch,
 output reg fault,output reg[31:0] rejected_releases,rejected_commits,
 output wire[2:0] bank0_state,bank1_state,
 output wire[31:0] bank0_session,bank0_frame,bank0_epoch,bank0_crc,bank1_session,bank1_frame,bank1_epoch,bank1_crc
);
 localparam FREE=0,WRITING=1,READY=2,DISPLAY=3,RETIRED=4;
 reg[2:0] state[0:1];reg[31:0] sess[0:1],frm[0:1],ep[0:1],crc[0:1];
 reg offer_held,offer_index,commit_busy;reg[1:0] commit_phase;
 reg[31:0] wanted_seq,wanted_base,anchor,guard,timer,last_display_seq;
 integer i;
 assign bank0_state=state[0];assign bank1_state=state[1];
 assign bank0_session=sess[0];assign bank0_frame=frm[0];assign bank0_epoch=ep[0];assign bank0_crc=crc[0];
 assign bank1_session=sess[1];assign bank1_frame=frm[1];assign bank1_epoch=ep[1];assign bank1_crc=crc[1];
 assign free_mask={state[1]==FREE&&!fault,state[0]==FREE&&!fault};
 assign alloc_ready=!fault&&root_live&&state[alloc_bank]==FREE;
 assign publish_ready=!fault&&root_live&&!offer_held&&state[publish_bank]==WRITING;
 assign offer_valid=offer_held&&!fault&&root_live&&ep[offer_index]==authorization_epoch;
 assign offer_bank=offer_index;assign offer_base=offer_index?32'h25800000:32'h25000000;
 assign offer_session=sess[offer_index];assign offer_frame=frm[offer_index];assign offer_epoch=ep[offer_index];assign offer_crc=crc[offer_index];
 assign display_session=sess[display_bank];assign display_frame=frm[display_bank];assign display_epoch=ep[display_bank];
 assign ps_commit_ready=!commit_busy&&!fault;
 wire commit_match=offer_valid&&ps_commit_bank==offer_index&&ps_commit_session==offer_session&&ps_commit_frame==offer_frame&&ps_commit_epoch==offer_epoch&&
   ps_hdmi_seq!=0&&ps_hdmi_seq!=last_display_seq&&(ps_hdmi_base==32'h27000000||ps_hdmi_base==32'h27800000);
 wire hardware_ack=hdmi_ack_seq==wanted_seq&&hdmi_active_base==wanted_base;
 task reject_commit;begin commit_busy<=0;ps_commit_rejected<=1;rejected_commits<=rejected_commits+1;end endtask
 always@(posedge clk)begin
  if(!board_resetn)begin
   for(i=0;i<2;i=i+1)begin state[i]<=FREE;sess[i]<=0;frm[i]<=0;ep[i]<=0;crc[i]<=0;end
   offer_held<=0;offer_index<=0;commit_busy<=0;commit_phase<=0;wanted_seq<=0;wanted_base<=0;anchor<=0;guard<=0;timer<=0;last_display_seq<=0;
   display_valid<=0;display_bank<=0;fault<=0;ps_commit_done<=0;ps_commit_rejected<=0;rejected_releases<=0;rejected_commits<=0;
  end else begin
   ps_commit_done<=0;ps_commit_rejected<=0;
   // A complete READY offer has no accepted producer writes outstanding.
   // Rekey may invalidate its public view. Retire, NEVER free or recycle it;
   // exact old S/F/E remains available to PS. WRITING and DISPLAY are untouched.
   if(!fault&&root_live&&offer_held&&!commit_busy&&state[offer_index]==READY&&ep[offer_index]!=authorization_epoch)begin
    if(display_valid&&offer_index==display_bank)fault<=1;
    else begin state[offer_index]<=RETIRED;offer_held<=0;end
   end
   if(alloc_valid)begin
    if(!alloc_ready||!alloc_session||!alloc_frame||alloc_epoch!=authorization_epoch)fault<=1;
    else begin state[alloc_bank]<=WRITING;sess[alloc_bank]<=alloc_session;frm[alloc_bank]<=alloc_frame;ep[alloc_bank]<=alloc_epoch;end
   end
   if(publish_valid)begin
    if(!publish_ready||publish_session!=sess[publish_bank]||publish_frame!=frm[publish_bank]||publish_epoch!=ep[publish_bank]||publish_epoch!=authorization_epoch)fault<=1;
    else begin state[publish_bank]<=READY;crc[publish_bank]<=publish_crc;offer_index<=publish_bank;offer_held<=1;end
   end
   if(abort_valid)begin
    if(state[abort_bank]!=WRITING||abort_session!=sess[abort_bank]||abort_frame!=frm[abort_bank]||abort_epoch!=ep[abort_bank])fault<=1;
    else state[abort_bank]<=FREE;
   end
   // A PSrelease can never reclaimWRITING/READY/currentDISPLAY orNN RAW.
   if(ps_release_valid)begin
    if(state[ps_release_bank]==RETIRED&&(!display_valid||ps_release_bank!=display_bank)&&
       ps_release_session==sess[ps_release_bank]&&ps_release_frame==frm[ps_release_bank]&&ps_release_epoch==ep[ps_release_bank])state[ps_release_bank]<=FREE;
    else rejected_releases<=rejected_releases+1;
   end
   if(ps_commit_valid&&ps_commit_ready)begin
    if(!commit_match)begin ps_commit_rejected<=1;rejected_commits<=rejected_commits+1;end
    else begin commit_busy<=1;commit_phase<=0;wanted_seq<=ps_hdmi_seq;wanted_base<=ps_hdmi_base;timer<=0;end
   end
   if(commit_busy)begin
    timer<=timer+1;
    if(!offer_valid||!hdmi_healthy||timer>=COMMIT_TIMEOUT)reject_commit();
    else case(commit_phase)
     0:if(hardware_ack)begin anchor<=hdmi_frames;commit_phase<=1;end
     1:if(!hardware_ack||(hdmi_frames-anchor)>=32'h80000000)reject_commit();
       else if(hdmi_frames!=anchor)begin guard<=hdmi_frames;commit_phase<=2;end
     2:if(!hardware_ack||(hdmi_frames-guard)>=32'h80000000)reject_commit();
       else if((hdmi_frames-guard)>=2)begin
        if(display_valid)state[display_bank]<=RETIRED;
        state[offer_index]<=DISPLAY;display_bank<=offer_index;display_valid<=1;offer_held<=0;
        last_display_seq<=wanted_seq;commit_busy<=0;ps_commit_done<=1;
       end
     default:begin fault<=1;reject_commit();end
    endcase
   end
  end
 end
endmodule
