`timescale 1ns/1ps
// Owned successor endpoint; original R14 endpoint is unchanged.
// CLOSE/OPEN and the complete backend/TX drains are separate contracts.
module nfr_owned_native_endpoint #(parameter integer REGISTERED_CHANNEL_LIVE=0)(
 input wire clk,rst_n,rx_clk,rx_reset,input wire [7:0] rx_data,input wire rx_valid,rx_last,rx_bad,
 input wire tx_clk,tx_reset,output wire [7:0]tx_data,output wire tx_valid,tx_last,input wire tx_ready,
 input wire owner_close,owner_open,owner_purpose_nn,
 input wire [31:0] owner_session,owner_frame,owner_epoch,
 output wire owner_closed,owner_opened,packet_quiescent,channel_live,
 output wire packet_valid,output wire [383:0]packet_header,
 output wire packet_purpose_nn,output wire [31:0]packet_epoch,
 input wire packet_release,payload_read,input wire [9:0]payload_address,
 output wire [7:0]payload_data,output wire payload_read_valid,
 input wire response_valid,output wire response_ready,input wire [7:0]response_kind,response_flags,
 input wire [31:0]response_offset,response_frame_crc,response_session_id,response_frame_id,response_total_bytes,
 input wire [15:0]response_width,response_height,output wire response_quiescent,
 output reg response_fault,
 output wire[31:0] received_packets,bad_packets,busy_drops,foreign_drops,
 output wire[767:0] diagnostic_words
);
 wire[63:0]diag_rx_counts;wire[511:0]diag_rx_local;wire[15:0]diag_publications;wire[15:0]diag_tx_gray;
 wire channel_reset=!rst_n||rx_reset||tx_reset;
 (* ASYNC_REG="TRUE" *) reg[2:0] core_reset_pipe=7;
 (* ASYNC_REG="TRUE" *) reg[2:0] core_in_tx=0,tx_reset_pipe=7,tx_alive_in_core=0;
 generate if(REGISTERED_CHANNEL_LIVE!=0)begin:registered_release
  always@(posedge clk or posedge channel_reset)
   if(channel_reset)begin core_reset_pipe<=7;tx_alive_in_core<=0;end
   else if(channel_reset===1'b0)begin core_reset_pipe<={core_reset_pipe[1:0],1'b0};tx_alive_in_core<={tx_alive_in_core[1:0],!tx_reset_pipe[2]};end
   else begin core_reset_pipe<=7;tx_alive_in_core<=0;end
 end else begin:literal_original_release
  always@(posedge clk or posedge channel_reset)
   if(channel_reset)begin core_reset_pipe<=7;tx_alive_in_core<=0;end
   else begin core_reset_pipe<={core_reset_pipe[1:0],1'b0};tx_alive_in_core<={tx_alive_in_core[1:0],!tx_reset_pipe[2]};end
 end endgenerate
 wire core_live=!core_reset_pipe[2];
 always@(posedge tx_clk or posedge channel_reset)
  if(channel_reset)begin core_in_tx<=0;tx_reset_pipe<=7;end
  else begin
   core_in_tx<={core_in_tx[1:0],core_live};
   if(!core_in_tx[2])tx_reset_pipe<=7;
   else tx_reset_pipe<={tx_reset_pipe[1:0],1'b0};
  end
 wire tx_live=!tx_reset_pipe[2];
 wire rx_live,rx_owner_closed,rx_owner_opened;
 assign channel_live=core_live&&rx_live&&tx_alive_in_core[2]&&(REGISTERED_CHANNEL_LIVE!=0?1'b1:!channel_reset);
 assign owner_closed=channel_live&&rx_owner_closed;
 assign owner_opened=channel_live&&rx_owner_opened;
 wire raw_packet_quiet;
 assign packet_quiescent=channel_live&&raw_packet_quiet;
 nfr_packet_rx_owned #(.REGISTERED_CHANNEL_LIVE(REGISTERED_CHANNEL_LIVE)) receiver(.diagnostic_counts(diag_rx_counts),.diagnostic_local(diag_rx_local),.diagnostic_publications(diag_publications),.clk(clk),.rst_n(rst_n),.rx_clk(rx_clk),.rx_reset(rx_reset||tx_reset),
  .rx_data(rx_data),.rx_valid(rx_valid),.rx_last(rx_last),.rx_bad(rx_bad),
  .owner_close(owner_close),.owner_open(owner_open&&channel_live),.owner_purpose_nn(owner_purpose_nn),
  .owner_session(owner_session),.owner_frame(owner_frame),.owner_epoch(owner_epoch),
  .owner_closed(rx_owner_closed),.owner_opened(rx_owner_opened),.packet_quiescent(raw_packet_quiet),.channel_live(rx_live),
  .packet_valid(packet_valid),.packet_header(packet_header),.packet_purpose_nn(packet_purpose_nn),.packet_epoch(packet_epoch),
  .packet_release(packet_release),.payload_read(payload_read),.payload_address(payload_address),
  .payload_data(payload_data),.payload_read_valid(payload_read_valid),
  .received_packets(received_packets),.bad_packets(bad_packets),.busy_drops(busy_drops),.foreign_drops(foreign_drops));
 // Retain the last actually opened response identity across a MAC-only reset.
 // This permits that owner's real CANCEL/ACK tail to drain while RX is closed;
 // the scheduler must not open a new owner until response_quiescent is true.
 wire control_ready;
 reg tx_obligation;
 reg response_owner_valid;reg[31:0] response_owner_session,response_owner_frame;
 wire response_identity=response_owner_valid&&response_session_id==response_owner_session&&response_frame_id==response_owner_frame&&
   response_total_bytes==4147200&&response_width==1920&&response_height==1080&&response_flags==0&&response_kind>=1&&response_kind<=6;
 always@(posedge clk or negedge rst_n)
  if(!rst_n)begin response_owner_valid<=0;response_owner_session<=0;response_owner_frame<=0;response_fault<=0;tx_obligation<=0;end
  else begin
   // Reset can abort a control packet after source acceptance but before MAC
   // completion. This is a sticky transport failure, never a successful DONE.
   // The integrator MUST feed response_fault to the trusted fault/cancel cone.
   if(tx_obligation&&!channel_live)response_fault<=1;
   if(channel_live&&control_ready)begin
    if(response_valid&&response_identity)tx_obligation<=1;
    else tx_obligation<=0;
   end
   if(owner_open&&owner_opened)begin response_owner_valid<=1;response_owner_session<=owner_session;response_owner_frame<=owner_frame;end
   if(channel_live&&response_valid&&response_identity!==1'b1)response_fault<=1;
  end
 assign response_ready=channel_live&&control_ready&&(!response_valid||response_identity);
 assign response_quiescent=channel_live&&control_ready&&!response_valid;
 nfr_control_tx transmitter(.diagnostic_request_completed_gray(diag_tx_gray),.clk(clk),.rst_n(core_live),.control_valid(response_valid&&channel_live&&response_identity),.control_ready(control_ready),
  .kind(response_kind),.session_id(response_session_id),.frame_id(response_frame_id),.total_bytes(response_total_bytes),
  .offset(response_offset),.frame_crc(response_frame_crc),.width(response_width),.height(response_height),.flags(response_flags),
  .tx_clk(tx_clk),.tx_reset(!tx_live),.m_axis_tdata(tx_data),.m_axis_tvalid(tx_valid),.m_axis_tlast(tx_last),.m_axis_tready(tx_ready));
 // synthesis translate_off
 always@(posedge clk)if(rst_n&&owner_open&&owner_opened&&!response_quiescent)
  $fatal(1,"OWNED_ENDPOINT_OPEN_BEFORE_REAL_TX_DRAIN");
 // synthesis translate_on

 (* ASYNC_REG="TRUE" *) reg[15:0]diag_tx_core1,diag_tx_core2,diag_tx_core3;
 reg[15:0]diag_tx_completed,diag_request_accepted,diag_owner_generation;
 reg[31:0]diag_status;reg[11:0]diag_channel_resets;reg diag_was_live;
 function automatic[15:0]diag_tx_ungray(input[15:0]g);
  integer j;begin for(j=0;j<16;j=j+1)diag_tx_ungray[j]=^(g>>j);end
 endfunction
 always@(posedge clk or negedge rst_n)begin
  if(!rst_n)begin diag_tx_core1<=0;diag_tx_core2<=0;diag_tx_core3<=0;diag_tx_completed<=0;diag_request_accepted<=0;diag_owner_generation<=0;diag_status<=0;diag_channel_resets<=0;diag_was_live<=0;end
  else begin
   diag_tx_core1<=diag_tx_gray;diag_tx_core2<=diag_tx_core1;diag_tx_core3<=diag_tx_core2;diag_tx_completed<=diag_tx_ungray(diag_tx_core3);
   if(response_valid&&channel_live&&response_identity&&control_ready&&response_kind==1)diag_request_accepted<=diag_request_accepted+1'b1;
   if(owner_open&&owner_opened)diag_owner_generation<=diag_owner_generation+1'b1;
   diag_was_live<=channel_live;if(diag_was_live&&!channel_live)diag_channel_resets<=diag_channel_resets+1'b1;
   diag_status<={diag_channel_resets,response_kind,response_ready,response_valid,response_fault,response_owner_valid,tx_obligation,control_ready,owner_opened,owner_closed,channel_live,tx_alive_in_core[2],rx_live,core_live};
  end
 end
 // Endpoint24word bundle, low word first. Tuple is the actual scheduler owner.
 assign diagnostic_words={diag_rx_local[159:128],diag_rx_local[191:160],diag_rx_local[223:192],diag_rx_local[255:224],diag_rx_local[287:256],diag_rx_local[319:288],diag_rx_local[351:320],diag_rx_local[383:352],diag_rx_local[415:384],diag_rx_local[447:416],diag_rx_local[479:448],diag_rx_local[511:480],diag_rx_local[127:32],diag_rx_local[31:0],diag_tx_completed,diag_request_accepted,diag_rx_counts,owner_epoch,owner_frame,owner_session,diag_status,diag_owner_generation,diag_publications};
endmodule
