`timescale 1ns/1ps
// R12: one report in flight, actual 32x128 XPM asynchronous block-RAM FIFO.
// No parallel held-data CDC remains. source_bundle is LOCAL to source_clk;
// destination_data is LOCAL to destination_clk and private while valid=0.
// The source remains immutable until the real destination/CSR acceptance ACK.
module trusted_pixel_fifo_cdc #(parameter WIDTH=2048)(
 input wire source_clk,source_reset_n,source_valid,
 output wire source_ready,source_quiescent,output reg source_fault,
 input wire [WIDTH-1:0] source_data,
 input wire destination_clk,destination_reset_n,destination_ready,
 output wire destination_reset_released,
 output wire destination_valid,
 output reg [WIDTH-1:0] destination_data
);
 localparam integer WORDS=WIDTH/32;
 localparam integer INDEX_BITS=WORDS<=1?1:$clog2(WORDS);
 localparam integer COUNT_BITS=$clog2(WORDS+1);
 initial begin
  if(WIDTH%32!=0 || WIDTH<32 || WORDS>128)$error("R12 requires whole32bit words and <=128 words");
 end
 wire common_reset_n=source_reset_n&&destination_reset_n;
 (* DONT_TOUCH="TRUE" *) reg [WIDTH-1:0] source_bundle;
 reg request_toggle,ack_toggle,source_commit_toggle;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]ack_sync,request_sync;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]destination_alive;
 reg destination_armed;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]destination_release;
 always @(posedge destination_clk or negedge common_reset_n)
  if(!common_reset_n)destination_release<=0;
  else destination_release<={destination_release[1:0],1'b1};

 // Capture even a reset pulse while source_clk is stopped. The actual XPM rst
 // register changes ONLY on source_clk, satisfying the vendor synchronous-rst
 // contract. At least eight write-clock reset edges occur after any request.
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[7:0]fifo_reset_release=0;
 reg fifo_reset=1'b1;
 reg fifo_reset_pending=1'b1;
 reg[1:0]fifo_reset_state=0;
 reg[3:0]fifo_reset_hold=8;
 always @(posedge source_clk or negedge common_reset_n)
  if(!common_reset_n)fifo_reset_release<=0;
  else fifo_reset_release<={fifo_reset_release[6:0],1'b1};
 wire fifo_full,fifo_empty,fifo_wr_busy,fifo_rd_busy;
 wire fifo_overflow,fifo_underflow,fifo_wr_ack,fifo_data_valid;
 wire[31:0]fifo_dout;
 // The vendor forbids a fresh rising reset while wr_rst_busy is active.
 // Latch every asynchronous request, keep all public state invalid, finish
 // the old real reset handshake, then service the queued request. A request
 // arriving during asserted reset extends its hold without a second edge.
 always @(posedge source_clk or negedge common_reset_n)
  if(!common_reset_n)fifo_reset_pending<=1'b1;
  else if(fifo_reset_state==0&&fifo_reset_release[7])fifo_reset_pending<=0;
 always @(posedge source_clk)begin
  case(fifo_reset_state)
   0:begin
    fifo_reset<=1;
    if(fifo_reset_pending||!fifo_reset_release[7])fifo_reset_hold<=8;
    else if(fifo_reset_hold>1)fifo_reset_hold<=fifo_reset_hold-1'b1;
    else begin fifo_reset<=0;fifo_reset_state<=1;end
   end
   1:if(!fifo_wr_busy)begin
    if(fifo_reset_pending)begin fifo_reset<=1;fifo_reset_hold<=8;fifo_reset_state<=0;end
    else fifo_reset_state<=2;
   end
   2:if(fifo_reset_pending)begin fifo_reset<=1;fifo_reset_hold<=8;fifo_reset_state<=0;end
   default:begin fifo_reset<=1;fifo_reset_hold<=8;fifo_reset_state<=0;end
  endcase
 end
 reg source_fifo_live;
 always @(posedge source_clk or negedge fifo_reset_release[7])
  if(!fifo_reset_release[7])source_fifo_live<=0;
  else if(fifo_reset||fifo_wr_busy||fifo_reset_pending||fifo_reset_state!=2)source_fifo_live<=0;
  else source_fifo_live<=1;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]fifo_live_sync;
 always @(posedge destination_clk or negedge common_reset_n)
  if(!common_reset_n)fifo_live_sync<=0;
  else fifo_live_sync<={fifo_live_sync[1:0],source_fifo_live};
 assign destination_reset_released=destination_release[2]&&fifo_live_sync[2]&&!fifo_rd_busy;

 // Independent destination reset can never impersonate a successful ACK0.
 // Existing sticky-fault semantics are retained, including short async pulses.
 wire alive_reset_n=source_reset_n&&destination_reset_released;
 always @(posedge source_clk or negedge alive_reset_n)
  if(!alive_reset_n)destination_alive<=0;
  else destination_alive<={destination_alive[1:0],1'b1};
 reg destination_fault;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]destination_fault_sync;
 always @(posedge source_clk or negedge source_reset_n)
  if(!source_reset_n)destination_fault_sync<=0;
  else destination_fault_sync<={destination_fault_sync[1:0],destination_fault};

 reg serialize_active,write_pending,final_write_pending;
 reg[INDEX_BITS-1:0]source_index;
 wire fifo_push=serialize_active&&source_fifo_live&&!fifo_reset&&!fifo_wr_busy&&!fifo_full
                 &&destination_alive[2]&&!source_fault&&!destination_fault_sync[2];
 wire[31:0]fifo_din=source_bundle[WIDTH-1-source_index*32-:32];
 assign source_ready=source_reset_n&&destination_alive[2]&&source_fifo_live&&!fifo_wr_busy
                    &&!fifo_reset&&!source_fault&&!destination_fault_sync[2]
                    &&request_toggle==ack_sync[2]&&!serialize_active&&!write_pending;
 assign source_quiescent=source_ready&&!source_valid;
 always @(posedge source_clk or negedge source_reset_n)begin
  if(!source_reset_n)begin destination_armed<=0;source_fault<=0;end
  else begin
   if(destination_alive[2])destination_armed<=1;
   if(destination_armed&&!destination_alive[2])source_fault<=1;
   if(fifo_overflow||destination_fault_sync[2])source_fault<=1;
   if(write_pending&&!fifo_wr_ack&&source_fifo_live&&!fifo_reset&&!fifo_wr_busy)source_fault<=1;
  end
 end
 always @(posedge source_clk or negedge source_reset_n)begin
  if(!source_reset_n)begin
   source_bundle<=0;request_toggle<=0;source_commit_toggle<=0;ack_sync<=0;
   serialize_active<=0;source_index<=0;write_pending<=0;final_write_pending<=0;
  end else begin
   // Idle preload only; accepted source snapshot still controls the request.
   // No FIFO push can occur until the next source edge after acceptance.
   if(source_ready)source_bundle<=source_data;
   ack_sync<={ack_sync[1:0],ack_toggle};
   write_pending<=fifo_push;
   final_write_pending<=fifo_push&&source_index==WORDS-1;
   if(final_write_pending&&fifo_wr_ack&&source_fifo_live&&!fifo_reset&&!fifo_wr_busy&&!source_fault&&!destination_fault_sync[2])source_commit_toggle<=request_toggle;
   if(!source_fifo_live||source_fault||destination_fault_sync[2])begin
    serialize_active<=0;source_index<=0;
   end else begin
    if(source_valid&&source_ready)begin
     request_toggle<=!request_toggle;
     serialize_active<=1;source_index<=0;
    end
    if(fifo_push)begin
     if(source_index==WORDS-1)begin serialize_active<=0;source_index<=0;end
     else source_index<=source_index+1'b1;
    end
   end
  end
 end

 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]commit_sync,source_fault_sync;
 reg collect_active,assembly_complete,destination_valid_reg,read_pending;
 reg[COUNT_BITS-1:0]reads_issued,words_received;
 wire fifo_pop=collect_active&&reads_issued<WORDS&&!fifo_empty&&!fifo_rd_busy
               &&destination_reset_released&&!destination_fault;
 // Exact vendor standard-mode latency1: every accepted pop has one return
 // at the next observed clock, with no duplicate/missing response.
 wire bad_return=(fifo_data_valid!=read_pending)||(fifo_data_valid&&(!collect_active||words_received>=WORDS||words_received>=reads_issued));
 always @(posedge destination_clk or negedge destination_reset_released)begin
  if(!destination_reset_released)destination_fault<=0;
  else if(destination_reset_released&&(fifo_underflow||bad_return))destination_fault<=1;
 end
 assign destination_valid=destination_reset_released&&destination_valid_reg
                          &&!destination_fault&&!source_fault_sync[2]&&!fifo_underflow&&!bad_return;
 always @(posedge destination_clk or negedge destination_reset_released)begin
  if(!destination_reset_released)begin
   request_sync<=0;commit_sync<=0;source_fault_sync<=0;ack_toggle<=0;destination_valid_reg<=0;destination_data<=0;
   collect_active<=0;assembly_complete<=0;reads_issued<=0;words_received<=0;read_pending<=0;
  end else begin
   read_pending<=fifo_pop;
   request_sync<={request_sync[1:0],request_toggle};
   commit_sync<={commit_sync[1:0],source_commit_toggle};
   source_fault_sync<={source_fault_sync[1:0],source_fault};
   if(!destination_valid_reg&&!collect_active&&!assembly_complete&&request_sync[2]!=ack_toggle&&!destination_fault&&!source_fault_sync[2])begin
    collect_active<=1;reads_issued<=0;words_received<=0;
   end
   if(fifo_pop)reads_issued<=reads_issued+1'b1;
   if(fifo_data_valid&&!bad_return&&!destination_fault&&!fifo_underflow)begin
    destination_data[WIDTH-1-words_received*32-:32]<=fifo_dout;
    words_received<=words_received+1'b1;
    if(words_received==WORDS-1)begin
     collect_active<=0;assembly_complete<=1;
    end
   end
   // Last real vendor write ACK commits the source record. Publishing waits
   // for both complete64-word assembly and its independently synced commit.
   if(assembly_complete&&!destination_valid_reg&&commit_sync[2]==request_sync[2]&&!destination_fault&&!source_fault_sync[2]&&!fifo_underflow&&!bad_return)destination_valid_reg<=1;
   if(destination_valid&&destination_ready)begin
    destination_valid_reg<=0;assembly_complete<=0;ack_toggle<=request_sync[2];
   end
   if(destination_fault||source_fault_sync[2]||fifo_underflow||bad_return)begin
    destination_valid_reg<=0;collect_active<=0;assembly_complete<=0;
   end
  end
 end
 // Actual production primitive and actual same vendor HDL in qualification.
 // No simulation-only substitute, and no inferred unqualified CDC RAM.
 xpm_fifo_async #(
  .FIFO_MEMORY_TYPE("block"),.FIFO_WRITE_DEPTH(128),.WRITE_DATA_WIDTH(32),.READ_DATA_WIDTH(32),
  .READ_MODE("std"),.FIFO_READ_LATENCY(1),.CDC_SYNC_STAGES(3),.RELATED_CLOCKS(0),
  .DOUT_RESET_VALUE("0"),.ECC_MODE("no_ecc"),.FULL_RESET_VALUE(0),
  .PROG_EMPTY_THRESH(10),.PROG_FULL_THRESH(110),.RD_DATA_COUNT_WIDTH(8),.WR_DATA_COUNT_WIDTH(8),
  .USE_ADV_FEATURES("1111"),.SIM_ASSERT_CHK(1),.WAKEUP_TIME(0)
 )report_fifo(
  .rst(fifo_reset),.wr_clk(source_clk),.rd_clk(destination_clk),
  .din(fifo_din),.wr_en(fifo_push),.rd_en(fifo_pop),.dout(fifo_dout),
  .full(fifo_full),.empty(fifo_empty),.wr_rst_busy(fifo_wr_busy),.rd_rst_busy(fifo_rd_busy),
  .overflow(fifo_overflow),.underflow(fifo_underflow),.wr_ack(fifo_wr_ack),.data_valid(fifo_data_valid),
  .almost_empty(),.almost_full(),.prog_empty(),.prog_full(),.rd_data_count(),.wr_data_count(),
  .dbiterr(),.sbiterr(),.injectdbiterr(1'b0),.injectsbiterr(1'b0),.sleep(1'b0)
 );
endmodule

