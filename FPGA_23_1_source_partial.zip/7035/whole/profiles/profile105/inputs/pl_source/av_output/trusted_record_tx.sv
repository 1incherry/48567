`timescale 1ns/1ps
// Raw Ethernet PL result protocol, EtherType88b6. MAC handles FCS/padding.
// This is fixed PL provenance against the legacy PS UDP path, NOT a claim of
// cryptographic network authentication. Never alter/withdraw an offered frame.
module trusted_record_tx #(
 parameter [47:0] DEST_MAC=48'h025052583100,SOURCE_MAC=48'h025052587035
)(input wire clk,rst_n,input wire snapshot_valid,input wire [2047:0] snapshot_data,
 output wire snapshot_ready,quiescent,
 output wire [7:0] m_data,output wire m_valid,m_last,input wire m_ready,
 output reg [31:0] sent_frames
);
 reg active;reg [8:0] position;
 assign m_valid=active;
 assign m_last=active&&position==269;
 assign m_data=position<6?DEST_MAC[47-position*8-:8]:
  position<12?SOURCE_MAC[47-(position-6)*8-:8]:
  position==12?8'h88:position==13?8'hb6:snapshot_data[2047-(position-14)*8-:8];
 assign snapshot_ready=m_valid&&m_ready&&m_last;
 assign quiescent=!active&&!snapshot_valid;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin active<=0;position<=0;sent_frames<=0;end
  else begin
   if(!active&&snapshot_valid)begin active<=1;position<=0;end
   if(active&&m_ready)begin
    if(position==269)begin active<=0;position<=0;sent_frames<=sent_frames+1'b1;end
    else position<=position+1'b1;
   end
  end
 end
endmodule
