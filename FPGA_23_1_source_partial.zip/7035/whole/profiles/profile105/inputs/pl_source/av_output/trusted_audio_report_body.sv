`timescale 1ns/1ps
// Versioned NAR3 compact105-class big-endian256B body from the actual private audio bank.
// The caller uses the SAME270B Ethernet envelope (EtherType88b6) as NTR2.
// No claim of Ethernet link cryptographic authentication is made.
module trusted_audio_report_body(
 input wire [31:0] report_sequence,input wire [287:0] result_context,
 input wire [6:0] result_class,input wire [31:0] result_score,
 output reg [2047:0] body
);
 integer i;
 always @*begin
  body=0;
  body[2047-0*8-:32]=32'h4e415233;
  body[2047-4*8-:32]=32'h00030002;
  body[2047-8*8-:32]=report_sequence;
  body[2047-12*8-:32]=result_context[223:192];
  body[2047-16*8-:32]=result_context[191:160];
  body[2047-20*8-:32]=result_context[159:128];
  body[2047-24*8-:32]=result_context[255:224];
  body[2047-28*8-:32]=result_context[287:256];
  body[2047-32*8-:128]=result_context[127:0];
  body[2047-48*8-:32]={25'd0,result_class};
  body[2047-52*8-:32]=32'd105;
  body[2047-56*8-:32]=32'd32000;
  body[2047-60*8-:32]=32'd3960;
  body[2047-64*8-:32]=result_score;
  body[2047-68*8-:32]=32'h00020069; // signed profile ID, score is rawFP32 logit, not calibrated probability
 end
endmodule
