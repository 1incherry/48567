`timescale 1ns/1ps
module trusted_av_record_outputs #(parameter CLOSED_READY_START=0)(
 input wire clk,security_reset_n,authorization_live,job_start,
 input wire record_commit,record_visible,
 input wire [31:0] record_camera,record_session,record_frame,record_epoch,
 input wire [127:0] record_key_session,input wire [2:0] record_count,
 input wire [895:0] record_rois,input wire [51:0] record_indices,input wire [511:0] record_results,
 input wire audio_record_commit,audio_record_visible,input wire [287:0] audio_record_context,
 input wire [6:0] audio_record_class,input wire [31:0] audio_record_score,
 output wire admission_ready,quiescent,fault,output wire [31:0] report_sequence,
 input wire tx_clk,tx_reset_n,output wire [7:0] tx_data,output wire tx_valid,tx_last,input wire tx_ready,
 input wire pixel_clk,pixel_reset_n,input wire [11:0] pixel_x,pixel_y,
 input wire [23:0] pixel_rgb,input wire pixel_hs,pixel_vs,pixel_de,
 output wire [23:0] overlay_rgb,output wire overlay_hs,overlay_vs,overlay_de
);
 wire source_valid,tx_source_ready,pixel_source_ready,publisher_quiet,display_current_live;
 wire tx_source_quiet,pixel_source_quiet,tx_snapshot_valid,tx_snapshot_ready,pixel_snapshot_valid,pixel_snapshot_ready;
 wire [2047:0] source_body,tx_body,pixel_body;
 wire [31:0] sequence_id,sent_frames;
 assign report_sequence=sequence_id;
 wire tx_quiet,pixel_label_valid;
 wire publisher_fault,tx_cdc_fault,pixel_cdc_fault;
 wire qualified_display_live=display_current_live&&!tx_cdc_fault&&!pixel_cdc_fault;
 wire tx_local_reset_n=security_reset_n&&tx_reset_n;
 wire pixel_local_reset_n=security_reset_n&&pixel_reset_n;
 wire tx_channel_reset_n,pixel_channel_reset_n;
 trusted_av_record_publisher #(.CLOSED_READY_START(CLOSED_READY_START)) publisher(.clk(clk),.security_reset_n(security_reset_n),.authorization_live(authorization_live),.job_start(job_start),
  .record_commit(record_commit),.record_visible(record_visible),.record_camera(record_camera),.record_session(record_session),.record_frame(record_frame),.record_epoch(record_epoch),
  .record_key_session(record_key_session),.record_count(record_count),.record_rois(record_rois),.record_indices(record_indices),.record_results(record_results),
  .audio_record_commit(audio_record_commit),.audio_record_visible(audio_record_visible),.audio_record_context(audio_record_context),
  .audio_record_class(audio_record_class),.audio_record_score(audio_record_score),
  .tx_ready(tx_source_ready),.pixel_ready(pixel_source_ready),.snapshot_valid(source_valid),.snapshot_data(source_body),
  .admission_ready(admission_ready),.quiescent(publisher_quiet),.display_current_live(display_current_live),.fault(publisher_fault),.sequence_id(sequence_id));
 trusted_record_cdc tx_cdc(.source_clk(clk),.source_reset_n(security_reset_n),.source_valid(source_valid),.source_ready(tx_source_ready),
  .source_quiescent(tx_source_quiet),.source_fault(tx_cdc_fault),.source_data(source_body),.destination_clk(tx_clk),.destination_reset_n(tx_local_reset_n),.destination_reset_released(tx_channel_reset_n),
  .destination_ready(tx_snapshot_ready),.destination_valid(tx_snapshot_valid),.destination_data(tx_body));
 trusted_pixel_fifo_cdc pixel_cdc(.source_clk(clk),.source_reset_n(security_reset_n),.source_valid(source_valid),.source_ready(pixel_source_ready),
  .source_quiescent(pixel_source_quiet),.source_fault(pixel_cdc_fault),.source_data(source_body),.destination_clk(pixel_clk),.destination_reset_n(pixel_local_reset_n),.destination_reset_released(pixel_channel_reset_n),
  .destination_ready(pixel_snapshot_ready),.destination_valid(pixel_snapshot_valid),.destination_data(pixel_body));
 trusted_record_tx transmitter(.clk(tx_clk),.rst_n(tx_channel_reset_n),.snapshot_valid(tx_snapshot_valid),.snapshot_data(tx_body),.snapshot_ready(tx_snapshot_ready),
  .quiescent(tx_quiet),.m_data(tx_data),.m_valid(tx_valid),.m_last(tx_last),.m_ready(tx_ready),.sent_frames(sent_frames));
 trusted_av_record_overlay overlay(.clk(pixel_clk),.rst_n(pixel_channel_reset_n),.source_current_live(qualified_display_live),
  .snapshot_valid(pixel_snapshot_valid),.snapshot_data(pixel_body),.snapshot_ready(pixel_snapshot_ready),
  .x(pixel_x),.y(pixel_y),.rgb_in(pixel_rgb),.hs_in(pixel_hs),.vs_in(pixel_vs),.de_in(pixel_de),
  .rgb_out(overlay_rgb),.hs_out(overlay_hs),.vs_out(overlay_vs),.de_out(overlay_de),.current_label_valid(pixel_label_valid));
 // TX CDC acknowledges only the REAL accepted LAST. Pixel CDC acknowledges
 // only the REAL display-frame boundary. No unsynchronized destination busy
 // signal participates in source-domain grant or root quiescence.
 assign quiescent=publisher_quiet;
 assign fault=publisher_fault||tx_cdc_fault||pixel_cdc_fault;
endmodule
