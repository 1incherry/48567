`timescale 1ns/1ps
// One complete immutable bundled-data mailbox. Both resets belong to trusted
// configuration/POR; software cancel never resets a half-completed handshake.
// The source bundle is held until the real destination acceptance returns.
module trusted_record_cdc #(parameter WIDTH=2048)(
 input wire source_clk,source_reset_n,source_valid,
 output wire source_ready,source_quiescent,output reg source_fault,
 input wire [WIDTH-1:0] source_data,
 input wire destination_clk,destination_reset_n,destination_ready,
 output wire destination_reset_released,
 output reg destination_valid,
 output reg [WIDTH-1:0] destination_data
);
 (* DONT_TOUCH="TRUE" *) reg [WIDTH-1:0] source_bundle;
 reg request_toggle,ack_toggle;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *) reg [2:0] ack_sync,request_sync;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *) reg [2:0] destination_alive;
 reg destination_armed;
 wire common_reset_n=source_reset_n&&destination_reset_n;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *) reg [2:0] destination_release;
 always @(posedge destination_clk or negedge common_reset_n)begin
  if(!common_reset_n)destination_release<=0;
  else destination_release<={destination_release[1:0],1'b1};
 end
 assign destination_reset_released=destination_release[2];
 wire alive_reset_n=source_reset_n&&destination_reset_released;
 // An independent destination reset must NEVER look like an ACK toggle0.
 // Async assertion captures even a sub-source-clock reset pulse; release takes
 // three source edges. After initial two-end startup, any drop is sticky fatal
 // until a shared trusted POR, rather than pretending a lost frame drained.
 always @(posedge source_clk or negedge alive_reset_n)begin
  if(!alive_reset_n)destination_alive<=0;
  else destination_alive<={destination_alive[1:0],1'b1};
 end
 always @(posedge source_clk or negedge source_reset_n)begin
  if(!source_reset_n)begin destination_armed<=0;source_fault<=0;end
  else begin
   if(destination_alive[2])destination_armed<=1;
   if(destination_armed&&!destination_alive[2])source_fault<=1;
  end
 end
 assign source_ready=source_reset_n&&destination_alive[2]&&!source_fault&&request_toggle==ack_sync[2];
 assign source_quiescent=source_ready&&!source_valid;
 always @(posedge source_clk or negedge source_reset_n)begin
  if(!source_reset_n)begin source_bundle<=0;request_toggle<=0;ack_sync<=0;end
  else begin
   ack_sync<={ack_sync[1:0],ack_toggle};
   if(source_valid&&source_ready)begin source_bundle<=source_data;request_toggle<=!request_toggle;end
  end
 end
 always @(posedge destination_clk or negedge destination_reset_released)begin
  if(!destination_reset_released)begin request_sync<=0;ack_toggle<=0;destination_valid<=0;destination_data<=0;end
  else begin
   request_sync<={request_sync[1:0],request_toggle};
   if(!destination_valid&&request_sync[2]!=ack_toggle)begin
    destination_data<=source_bundle;destination_valid<=1;
   end
   if(destination_valid&&destination_ready)begin destination_valid<=0;ack_toggle<=request_sync[2];end
  end
 end
endmodule
