`timescale 1ns/1ps
// ONE actual V2 SLH/cache and PS raw-byte feeder, common trusted100MHz domain.
// No public-key parameter/port: the actual service's fixed V2 anchor is used.
// No runtime authority is invented here. raw_model_authorized/model_epoch are
// the model service's own domain; parent binds them to its protected root lease.
module trusted_model_security_hub_observed(
 input wire clk,security_reset_n,trusted_cancel,
 input wire [2:0] trusted_selected_owner,
 input wire [3:0] page_request,input wire [127:0] expected_pages,
 input wire [3:0] cache_read,input wire [39:0] cache_addresses,
 output wire [3:0] page_ready,read_valid,
 output wire cache_valid,output wire [31:0] cached_page_index,cache_read_data,
 output wire page_done,service_busy,service_fault,
 input wire [1:0] fetch_valid,input wire [63:0] fetch_page_index,fetch_page_address,fetch_proof_address,
 output wire [1:0] fetch_ready,
 input wire [11:0] PS_AWADDR,input wire PS_AWVALID,output wire PS_AWREADY,
 input wire [31:0] PS_WDATA,input wire [3:0] PS_WSTRB,input wire PS_WVALID,output wire PS_WREADY,
 output wire [1:0] PS_BRESP,output wire PS_BVALID,input wire PS_BREADY,
 input wire [11:0] PS_ARADDR,input wire PS_ARVALID,output wire PS_ARREADY,
 output wire [31:0] PS_RDATA,output wire [1:0] PS_RRESP,output wire PS_RVALID,input wire PS_RREADY,
 output wire raw_model_authorized,output wire [31:0] model_epoch,
 output wire slh_busy,feeder_quiescent,hub_quiescent,output reg hub_fault,
 output wire observation_page_input_wait,
 output wire observation_page_accept,output wire [31:0] observation_page_index,
 output wire [31:0] observation_model_address,observation_proof_address,
 output wire model_verification_start,feeder_cancelled,
 output wire [7:0] signature_error,policy_error,page_error,feeder_error
);
 wire selected=trusted_selected_owner!=0&&trusted_selected_owner<=4;
 wire [1:0] idx=trusted_selected_owner[1:0]-1'b1;
 wire [3:0] mask=selected?(4'b0001<<idx):4'b0000;
 wire yf=trusted_selected_owner==1||trusted_selected_owner==2;
 wire [31:0] expected=selected?expected_pages[idx*32+:32]:0;
 wire [31:0] model_address=32'h30000000+(expected<<12);
 wire [31:0] proof_address=32'h38000000+(expected<<9)-(expected<<5);
 wire page_range_ok=expected<24567;
 wire fetch_tuple_ok=!yf||(fetch_page_index[idx*32+:32]==expected&&fetch_page_address[idx*32+:32]==model_address&&fetch_proof_address[idx*32+:32]==proof_address);
 wire inactive=(|(page_request&~mask))||(|(cache_read&~mask))||(|(fetch_valid&~mask[1:0]));
 wire tuple_fault=yf&&fetch_valid[idx]&&(!page_range_ok||!fetch_tuple_ok);
 wire nn_page_fault=selected&&!yf&&page_request[idx]&&!page_range_ok;
 wire protocol_fault=inactive||tuple_fault||nn_page_fault;
 wire service_cancel=trusted_cancel||hub_fault;
 wire manifest_start,manifest_ready,manifest_done,feeder_cancel,raw_page_ready,raw_read_valid,raw_cache_valid;
 wire [31:0] raw_read_data;
 wire msg_valid,msg_last,msg_ready,sig_valid,sig_last,sig_ready,page_valid,data_page_ready,proof_valid,proof_ready;
 wire [31:0] msg_data,sig_data,page_data,proof_data;
 wire feeder_transaction_idle;
 reg page_pending,read_pending;reg [2:0] page_owner,read_owner;
 // Ready to Y/F is independent of fetch_valid/tuple_fault to avoid the real
 // lease's fetch_valid=page_ready combinational loop. Its separate fetch_ready
 // prevents a bad tuple from ever producing an actual page_request acceptance.
 wire common_page_ready=security_reset_n&&raw_page_ready&&feeder_transaction_idle&&!page_pending&&!service_cancel&&!inactive;
 assign page_ready=selected&&common_page_ready&&!hub_fault?(yf?mask:(page_range_ok?mask:4'd0)):4'd0;
 assign fetch_ready=yf&&common_page_ready&&page_range_ok&&fetch_tuple_ok&&!protocol_fault?mask[1:0]:2'd0;
 wire accept_page=selected&&page_request[idx]&&page_ready[idx]&&page_range_ok&&fetch_tuple_ok&&!protocol_fault&&(!yf||fetch_valid[idx]);
 wire accept_read=selected&&cache_read[idx]&&raw_cache_valid&&!service_cancel&&!protocol_fault;
 wire [9:0] read_address=selected?cache_addresses[idx*10+:10]:0;
 assign cache_valid=raw_cache_valid&&!service_cancel&&!protocol_fault;
 assign read_valid=raw_read_valid&&cache_valid&&read_pending?(4'b0001<<(read_owner-1'b1)):4'd0;
 assign cache_read_data=(|read_valid)?raw_read_data:32'd0;
 // Count only actual V2 PAGE/PROOF input starvation, never all page-pending
 // hash time. These ready signals come from the real service state/context.
 assign observation_page_input_wait=security_reset_n&&page_pending&&
  ((data_page_ready&&!page_valid)||(proof_ready&&!proof_valid));
 assign observation_page_accept=accept_page;
 assign observation_page_index=expected;
 assign observation_model_address=model_address;assign observation_proof_address=proof_address;
 assign model_verification_start=manifest_start&&manifest_ready;
 assign feeder_cancelled=feeder_cancel;
 assign hub_quiescent=security_reset_n&&!service_busy&&feeder_quiescent&&!page_pending&&!read_pending&&!raw_read_valid&&
  page_request==0&&cache_read==0&&fetch_valid==0;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin hub_fault<=0;page_pending<=0;read_pending<=0;page_owner<=0;read_owner<=0;end
  else begin
   if(protocol_fault)hub_fault<=1;
   if((page_pending||read_pending)&&trusted_selected_owner!=(page_pending?page_owner:read_owner))hub_fault<=1;
   read_pending<=accept_read;
   if(accept_read)read_owner<=trusted_selected_owner;
   if(accept_page)begin page_pending<=1;page_owner<=trusted_selected_owner;end
   else if(page_done||(service_cancel||feeder_cancel)&&!service_busy)page_pending<=0;
  end
 end
 npu_model_security_service_v2 service(
  .clk(clk),.rst_n(security_reset_n),.cancel(service_cancel||feeder_cancel),
  .manifest_start(manifest_start),.manifest_ready(manifest_ready),.manifest_done(manifest_done),
  .msg_valid(msg_valid),.msg_data(msg_data),.msg_last(msg_last),.msg_ready(msg_ready),
  .sig_valid(sig_valid),.sig_data(sig_data),.sig_last(sig_last),.sig_ready(sig_ready),
  .page_request(accept_page),.expected_page_index(expected),.page_request_ready(raw_page_ready),
  .page_valid(page_valid),.page_data(page_data),.page_ready(data_page_ready),
  .proof_valid(proof_valid),.proof_data(proof_data),.proof_ready(proof_ready),
  .cache_read(accept_read),.cache_read_addr(read_address),.cache_read_valid(raw_read_valid),.cache_read_data(raw_read_data),
  .model_authorized(raw_model_authorized),.cache_valid(raw_cache_valid),.busy(service_busy),.fault(service_fault),
  .page_done(page_done),.session_epoch(model_epoch),.cached_page_index(cached_page_index),
  .signature_elapsed_cycles(),.signature_compute_cycles(),.page_elapsed_cycles(),
  .signature_error(signature_error),.policy_error(policy_error),.page_error(page_error),.debug_progress(),.debug_control());
 assign slh_busy=service_busy;
 trusted_model_feed_axil_observed #(.PROOF_WORDS(120)) feeder(
  .clk(clk),.rst_n(security_reset_n),.trusted_cancel(service_cancel),
  .s_awaddr(PS_AWADDR),.s_awvalid(PS_AWVALID),.s_awready(PS_AWREADY),.s_wdata(PS_WDATA),.s_wstrb(PS_WSTRB),.s_wvalid(PS_WVALID),.s_wready(PS_WREADY),
  .s_bresp(PS_BRESP),.s_bvalid(PS_BVALID),.s_bready(PS_BREADY),.s_araddr(PS_ARADDR),.s_arvalid(PS_ARVALID),.s_arready(PS_ARREADY),
  .s_rdata(PS_RDATA),.s_rresp(PS_RRESP),.s_rvalid(PS_RVALID),.s_rready(PS_RREADY),
  .trusted_page_accept(accept_page),.trusted_page_index(expected),
  .svc_manifest_ready(manifest_ready),.svc_manifest_done(manifest_done),.svc_page_done(page_done),.svc_busy(service_busy),.svc_fault(service_fault),
  .svc_model_authorized(raw_model_authorized),.svc_cache_valid(raw_cache_valid),.svc_epoch(model_epoch),.svc_cached_page_index(cached_page_index),
  .svc_signature_error(signature_error),.svc_policy_error(policy_error),.svc_page_error(page_error),
  .svc_manifest_start(manifest_start),.svc_cancel(feeder_cancel),
  .msg_valid(msg_valid),.msg_data(msg_data),.msg_last(msg_last),.msg_ready(msg_ready),
  .sig_valid(sig_valid),.sig_data(sig_data),.sig_last(sig_last),.sig_ready(sig_ready),
  .page_valid(page_valid),.page_data(page_data),.page_ready(data_page_ready),.proof_valid(proof_valid),.proof_data(proof_data),.proof_ready(proof_ready),
  .feeder_error(feeder_error),.feeder_quiescent(feeder_quiescent),.feeder_transaction_idle(feeder_transaction_idle));
endmodule
