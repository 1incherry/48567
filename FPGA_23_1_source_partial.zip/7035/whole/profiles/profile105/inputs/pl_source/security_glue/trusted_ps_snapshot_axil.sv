`timescale 1ns/1ps
// Default read-only snapshot; optional exact processed-receipt flow output.
// No bus-master, GO, reset, key, model or owner-authority output.
// The integration must supply only public side-effect-free snapshot words.
// This is NOT the manifest/signature untrusted-input feeder interface.
module trusted_ps_snapshot_axil #(
 parameter integer ENABLE_ORDINARY_FLOW=0,
 parameter integer ADDR_WIDTH=12,
 parameter integer SNAPSHOT_WORDS=16,
 parameter integer DIAGNOSTIC_WORDS=0,
 parameter [ADDR_WIDTH-1:0] SNAPSHOT_BASE=0
)(
 input wire clk,security_reset_n,
 input wire[31:0]flow_status,flow_ticket,input wire[319:0]flow_expected,
 output reg flow_ack_valid,output wire[351:0]flow_ack,
 input wire [SNAPSHOT_WORDS*32-1:0] snapshot_words_flat,
 input wire [(DIAGNOSTIC_WORDS>0?DIAGNOSTIC_WORDS:1)*32-1:0] diagnostic_words_flat,
 input wire [ADDR_WIDTH-1:0] s_axi_awaddr,input wire s_axi_awvalid,output wire s_axi_awready,
 input wire [31:0] s_axi_wdata,input wire [3:0] s_axi_wstrb,input wire s_axi_wvalid,output wire s_axi_wready,
 output wire [1:0] s_axi_bresp,output reg s_axi_bvalid,input wire s_axi_bready,
 input wire [ADDR_WIDTH-1:0] s_axi_araddr,input wire s_axi_arvalid,output wire s_axi_arready,
 output reg [31:0] s_axi_rdata,output reg [1:0] s_axi_rresp,output reg s_axi_rvalid,input wire s_axi_rready,
 output reg [31:0] blocked_writes,output wire interface_quiescent
);
 // Two-stage public read response. Stage1 captures one candidate per8-word
 // bank AT THE REAL AR HANDSHAKE; stage2 selects the latched bank. This does
 // not sample live status one cycle later and does not invent metrics_valid.
 localparam integer READ_GROUPS=(SNAPSHOT_WORDS+7)/8;
 localparam integer READ_GROUP_BITS=READ_GROUPS<=1?1:$clog2(READ_GROUPS);
 wire [READ_GROUPS*256-1:0] padded_snapshot={{(READ_GROUPS*256-SNAPSHOT_WORDS*32){1'b0}},snapshot_words_flat};
 reg [READ_GROUPS*32-1:0] read_bank_words;
 reg read_pending,read_snapshot_allowed,read_is_flow;
 reg [READ_GROUP_BITS-1:0] read_group;
 reg [1:0] read_response;
 reg [31:0] read_flow_word;
 wire [ADDR_WIDTH:0] read_offset={1'b0,s_axi_araddr}-{1'b0,SNAPSHOT_BASE};
 wire read_allowed=s_axi_araddr>=SNAPSHOT_BASE&&read_offset<SNAPSHOT_WORDS*4&&s_axi_araddr[1:0]==0;
 wire [2:0] read_low_word=read_offset>>2;
 genvar read_bank;
 generate for(read_bank=0;read_bank<READ_GROUPS;read_bank=read_bank+1)begin:g_ar_bank
  wire [255:0] bank_input=padded_snapshot[read_bank*256+:256];
  // Payload is private and invalid unless read_pending/rvalid says otherwise.
  // No reset fanout is added to544payload FFs per132word endpoint. An actual
  // new AR must capture every bank before any new response can be published.
  always @(posedge clk)
   if(security_reset_n&&s_axi_arvalid&&s_axi_arready&&read_allowed)
    read_bank_words[read_bank*32+:32]<=bank_input[read_low_word*32+:32];
 end endgenerate
 localparam integer DG=(DIAGNOSTIC_WORDS+7)/8;
 localparam integer DGN=DG>0?DG:1;
 wire[DGN*256-1:0]diag_padded={{(DGN*256-(DIAGNOSTIC_WORDS>0?DIAGNOSTIC_WORDS:1)*32){1'b0}},diagnostic_words_flat};
 wire diag_allowed=DIAGNOSTIC_WORDS>0&&s_axi_araddr>=12'h500&&s_axi_araddr<12'h500+DIAGNOSTIC_WORDS*4&&s_axi_araddr[1:0]==0;
 reg[DGN*32-1:0]diag_bank_words;reg diag_read;reg[4:0]diag_group;
 genvar dg;
 generate for(dg=0;dg<DGN;dg=dg+1)begin:g_diag_ar_bank
  always@(posedge clk)if(security_reset_n&&s_axi_arvalid&&s_axi_arready&&diag_allowed)
   diag_bank_words[dg*32+:32]<=diag_padded[dg*256+(((s_axi_araddr-12'h500)>>2)&7)*32+:32];
 end endgenerate
 always@(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin diag_read<=0;diag_group<=0;end
  else if(s_axi_arvalid&&s_axi_arready)begin diag_read<=diag_allowed;diag_group<=(s_axi_araddr-12'h500)>>5;end
 end
 reg aw_held,w_held,write_ok;
 reg[ADDR_WIDTH-1:0]write_addr;reg[31:0]write_data;reg[3:0]write_strobe;
 reg[351:0]ack_stage;reg[10:0]ack_mask;
 assign flow_ack=ack_stage;
 // A malicious PS can hold a half write or an unconsumed response forever.
 // This only blocks its own diagnostic endpoint; do not use this quiet alone
 // as an indication about any authenticated tensor AXI/MAC datapath.
 assign s_axi_awready=security_reset_n&&!aw_held&&!s_axi_bvalid;
 assign s_axi_wready=security_reset_n&&!w_held&&!s_axi_bvalid;
 assign s_axi_bresp=write_ok?2'b00:2'b10;
 assign s_axi_arready=security_reset_n&&!s_axi_rvalid&&!read_pending;
 assign interface_quiescent=security_reset_n&&!aw_held&&!w_held&&!s_axi_bvalid&&!s_axi_rvalid&&
  !s_axi_awvalid&&!s_axi_wvalid&&!s_axi_arvalid&&!read_pending;

 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   aw_held<=0;w_held<=0;s_axi_bvalid<=0;blocked_writes<=0;write_ok<=0;write_addr<=0;write_data<=0;write_strobe<=0;
   ack_stage<=0;ack_mask<=0;flow_ack_valid<=0;
   s_axi_rvalid<=0;s_axi_rdata<=0;s_axi_rresp<=0;
   read_pending<=0;read_snapshot_allowed<=0;read_is_flow<=0;read_group<=0;read_response<=0;read_flow_word<=0;
  end else begin
   flow_ack_valid<=0;
   if(s_axi_awvalid&&s_axi_awready)begin aw_held<=1;write_addr<=s_axi_awaddr;end
   if(s_axi_wvalid&&s_axi_wready)begin w_held<=1;write_data<=s_axi_wdata;write_strobe<=s_axi_wstrb;end
   if(aw_held&&w_held&&!s_axi_bvalid)begin
    aw_held<=0;w_held<=0;s_axi_bvalid<=1;
    write_ok<=0;
    if(ENABLE_ORDINARY_FLOW!=0&&write_strobe==4'hf&&write_addr>=12'h340&&write_addr<=12'h368&&write_addr[1:0]==0)begin
     ack_stage[((write_addr-12'h340)>>2)*32+:32]<=write_data;
     ack_mask[(write_addr-12'h340)>>2]<=1;write_ok<=1;
    end else if(ENABLE_ORDINARY_FLOW!=0&&write_strobe==4'hf&&write_addr==12'h36c&&write_data==32'h41434b31&&(&ack_mask))begin
     flow_ack_valid<=1;ack_mask<=0;write_ok<=1;
    end else begin
     if(write_addr==12'h36c)ack_mask<=0;
     if(blocked_writes!=32'hffffffff)blocked_writes<=blocked_writes+1'b1;
    end
   end
   if(s_axi_bvalid&&s_axi_bready)s_axi_bvalid<=0;
   if(s_axi_rvalid&&s_axi_rready)s_axi_rvalid<=0;
   if(read_pending)begin
    read_pending<=0;s_axi_rvalid<=1;s_axi_rresp<=read_response;
    s_axi_rdata<=diag_read?diag_bank_words[diag_group*32+:32]:(read_is_flow?read_flow_word:(read_snapshot_allowed?read_bank_words[read_group*32+:32]:32'd0));
   end
   if(s_axi_arvalid&&s_axi_arready)begin
    read_pending<=1;read_snapshot_allowed<=read_allowed;read_group<=read_offset>>5;
    read_response<=(read_allowed||diag_allowed)?2'b00:2'b10;read_is_flow<=0;read_flow_word<=0;
    // Flow overrides preserve original ABI and are sampled on the SAME AR
    // edge as public snapshot banks, never on later RVALID/RREADY edges.
    if(ENABLE_ORDINARY_FLOW!=0)begin
     if(s_axi_araddr==12'h300)begin read_is_flow<=1;read_flow_word<=32'h41463032;read_response<=0;end
     else if(s_axi_araddr==12'h304)begin read_is_flow<=1;read_flow_word<=flow_status;read_response<=0;end
     else if(s_axi_araddr==12'h308)begin read_is_flow<=1;read_flow_word<=flow_ticket;read_response<=0;end
     else if(s_axi_araddr>=12'h30c&&s_axi_araddr<=12'h330&&s_axi_araddr[1:0]==0)begin
      read_is_flow<=1;read_flow_word<=flow_expected[((s_axi_araddr-12'h30c)>>2)*32+:32];read_response<=0;
     end
    end
   end
  end
 end
endmodule
