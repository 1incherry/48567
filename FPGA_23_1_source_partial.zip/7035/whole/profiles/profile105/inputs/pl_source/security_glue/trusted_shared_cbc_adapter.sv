`timescale 1ns/1ps
// Exactly ONE shared CBC service (the frozen drain-safe wrapper, two-round
// existing v788 cores). No PS/key/owner generation and no added tensor RAM.
// lane0=ingress/LB, lane1=combined vision. Owner must be committed, not desired.
module trusted_shared_cbc_adapter(
 input wire clk,security_reset_n,
 input wire [1:0] trusted_selected_owner,
 input wire [1:0] request,input wire [255:0] chains,input wire [511:0] data,
 input wire [31:0] epoch,input wire [127:0] key,
 input wire key_valid,authorized,cancel,
 output wire [1:0] ready,output reg [1:0] response_valid,response_error,
 output reg [255:0] tag,output wire quiescent,output reg fault
);
 localparam IDLE=0,RUN=1,REPORT=2;
 reg [1:0] state,admitted_owner;
 reg [31:0] admitted_epoch;reg [127:0] admitted_key,result_tag;
 reg poisoned,clear_sent,have_result;
 wire [1:0] selected_mask=trusted_selected_owner==1?2'b01:trusted_selected_owner==2?2'b10:2'b00;
 wire request_violation=(|request)&&(selected_mask==0||(request&~selected_mask)!=0);
 wire core_busy,core_done;wire [127:0] core_tag;
 wire admission=security_reset_n&&state==IDLE&&!core_busy&&!core_done&&response_valid==0&&!fault&&!request_violation;
 // Denied selected requests still handshake as ERROR TOKENS so a real guard
 // already holding MAC_REQ can drain after cancel. They never start SM4.
 assign ready=admission?selected_mask:2'b00;
 wire take_request=|(ready&request);
 wire authenticated_start=take_request&&authorized&&key_valid&&!cancel;
 wire [127:0] selected_chain=trusted_selected_owner==1?chains[127:0]:chains[255:128];
 wire [255:0] selected_data=trusted_selected_owner==1?data[255:0]:data[511:256];
 wire pending_live=authorized&&key_valid&&!cancel&&epoch==admitted_epoch&&key==admitted_key&&
  trusted_selected_owner==admitted_owner&&!fault&&!request_violation&&!poisoned;
 wire clear_core=state==RUN&&!pending_live&&!clear_sent;
 trusted_sm4_cbc_mac256_drain #(.CORE_ROUNDS_PER_CYCLE(2)) core(
  .clk(clk),.rst_n(security_reset_n),.clear(clear_core),.start(authenticated_start),
  .key(key),.chain_in(selected_chain),.data_in(selected_data),.busy(core_busy),.done(core_done),.tag_out(core_tag));
 assign quiescent=security_reset_n&&state==IDLE&&!core_busy&&!core_done&&response_valid==0&&request==0;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=IDLE;admitted_owner<=0;admitted_epoch<=0;admitted_key<=0;result_tag<=0;
   poisoned<=0;clear_sent<=0;have_result<=0;response_valid<=0;response_error<=0;tag<=0;fault<=0;
  end else begin
   response_valid<=0;response_error<=0;tag<=0;
   if(request_violation)fault<=1;
   if(state==RUN&&trusted_selected_owner!=admitted_owner)fault<=1;
   case(state)
    IDLE:if(take_request)begin
     admitted_owner<=trusted_selected_owner;admitted_epoch<=epoch;admitted_key<=key;
     poisoned<=!authenticated_start;clear_sent<=0;have_result<=0;result_tag<=0;state<=RUN;
    end
    RUN:begin
     if(!pending_live)poisoned<=1;
     if(clear_core)clear_sent<=1;
     if(core_done&&pending_live)begin have_result<=1;result_tag<=core_tag;end
     // Actual wrapper busy includes its own done and both child busy/done.
     // A canceled request never gets an artificial early completion.
     if(!core_busy&&!core_done&&(have_result||!pending_live))begin
      response_valid<=admitted_owner==1?2'b01:2'b10;
      response_error<=pending_live&&have_result?2'b00:(admitted_owner==1?2'b01:2'b10);
      tag<=pending_live&&have_result?(admitted_owner==1?{128'd0,result_tag}:{result_tag,128'd0}):256'd0;
      state<=REPORT;
     end
    end
    REPORT:state<=IDLE;
    default:begin poisoned<=1;fault<=1;state<=RUN;end
   endcase
  end
 end
endmodule
