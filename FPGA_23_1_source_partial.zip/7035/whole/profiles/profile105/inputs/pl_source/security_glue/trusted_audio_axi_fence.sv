`timescale 1ns/1ps
// Diagnostic isolation, NOT audio authentication. Actual audio_ddr_cache is
// single32B INCR/full-strobe. No address translation: its BASE must be3c000000.
// Once any M_*VALID is offered it survives cancel/grant loss until handshake.
module trusted_audio_axi_fence #(
 parameter [31:0] AUDIO_BASE=32'h3c000000,AUDIO_LIMIT=32'h3c080000
)(
 input wire clk,security_reset_n,admission_enable,cancel,
 input wire [31:0] S_ARADDR,input wire [7:0] S_ARLEN,input wire [2:0] S_ARSIZE,input wire [1:0] S_ARBURST,
 input wire S_ARVALID,output wire S_ARREADY,output reg [255:0] S_RDATA,output reg [1:0] S_RRESP,
 output wire S_RLAST,output wire S_RVALID,input wire S_RREADY,
 input wire [31:0] S_AWADDR,input wire [7:0] S_AWLEN,input wire [2:0] S_AWSIZE,input wire [1:0] S_AWBURST,
 input wire S_AWVALID,output wire S_AWREADY,input wire [255:0] S_WDATA,input wire [31:0] S_WSTRB,
 input wire S_WLAST,S_WVALID,output wire S_WREADY,output reg [1:0] S_BRESP,output wire S_BVALID,input wire S_BREADY,
 output reg [31:0] M_ARADDR,output wire [7:0] M_ARLEN,output wire [2:0] M_ARSIZE,output wire [1:0] M_ARBURST,
 output wire M_ARVALID,input wire M_ARREADY,input wire [255:0] M_RDATA,input wire [1:0] M_RRESP,
 input wire M_RLAST,M_RVALID,output wire M_RREADY,
 output reg [31:0] M_AWADDR,output wire [7:0] M_AWLEN,output wire [2:0] M_AWSIZE,output wire [1:0] M_AWBURST,
 output wire M_AWVALID,input wire M_AWREADY,output reg [255:0] M_WDATA,output wire [31:0] M_WSTRB,
 output wire M_WLAST,M_WVALID,input wire M_WREADY,input wire [1:0] M_BRESP,input wire M_BVALID,output wire M_BREADY,
 output wire quiescent,output reg fault
);
 localparam R_IDLE=0,R_SEND=1,R_DRAIN=2,R_REPORT=3;
 localparam W_COLLECT=0,W_SEND=1,W_DRAIN=2,W_REPORT=3;
 reg [1:0] rs,ws;
 reg r_poison,r_seen_data;
 reg aw_held,w_held,aw_ok,w_ok,w_poison,aw_sent,w_sent;
 function allowed_address(input [31:0] address,input [7:0] len,input [2:0] size,input [1:0] burst);
  begin allowed_address=address>=AUDIO_BASE&&{1'b0,address}+33'd32<={1'b0,AUDIO_LIMIT}&&address[4:0]==0&&len==0&&size==5&&burst==1;end
 endfunction
 wire ar_ok=allowed_address(S_ARADDR,S_ARLEN,S_ARSIZE,S_ARBURST);
 wire live=admission_enable&&!cancel;
 assign S_ARREADY=security_reset_n&&rs==R_IDLE;
 assign S_RVALID=security_reset_n&&rs==R_REPORT;assign S_RLAST=1'b1;
 assign M_ARLEN=0;assign M_ARSIZE=5;assign M_ARBURST=1;
 assign M_ARVALID=security_reset_n&&rs==R_SEND;
 assign M_RREADY=security_reset_n&&rs==R_DRAIN;
 assign S_AWREADY=security_reset_n&&ws==W_COLLECT&&!aw_held;
 assign S_WREADY=security_reset_n&&ws==W_COLLECT&&!w_held;
 assign S_BVALID=security_reset_n&&ws==W_REPORT;
 assign M_AWLEN=0;assign M_AWSIZE=5;assign M_AWBURST=1;
 assign M_AWVALID=security_reset_n&&ws==W_SEND&&!aw_sent;
 assign M_WVALID=security_reset_n&&ws==W_SEND&&!w_sent;
 assign M_WSTRB=32'hffffffff;assign M_WLAST=1'b1;
 assign M_BREADY=security_reset_n&&ws==W_DRAIN;
 assign quiescent=security_reset_n&&rs==R_IDLE&&ws==W_COLLECT&&!aw_held&&!w_held&&
  !S_ARVALID&&!S_AWVALID&&!S_WVALID;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   rs<=R_IDLE;ws<=W_COLLECT;r_poison<=0;r_seen_data<=0;aw_held<=0;w_held<=0;
   aw_ok<=0;w_ok<=0;w_poison<=0;aw_sent<=0;w_sent<=0;
   M_ARADDR<=0;M_AWADDR<=0;M_WDATA<=0;S_RDATA<=0;S_RRESP<=0;S_BRESP<=0;fault<=0;
  end else begin
   // Reports are immutable once offered, even if cancel arrives under a
   // response stall. Parent cancel/current epoch gate invalidates the job.
   if(rs!=R_IDLE&&rs!=R_REPORT&&!live)r_poison<=1;
   if(ws!=W_REPORT&&(aw_held||w_held||ws!=W_COLLECT)&&!live)w_poison<=1;
   case(rs)
    R_IDLE:if(S_ARVALID&&S_ARREADY)begin
     M_ARADDR<=S_ARADDR;r_poison<=!live;r_seen_data<=0;S_RDATA<=0;
     if(ar_ok&&live)rs<=R_SEND;
     else begin rs<=R_REPORT;S_RRESP<=2'b10;if(!ar_ok)fault<=1;end
    end
    R_SEND:if(M_ARVALID&&M_ARREADY)rs<=R_DRAIN;
    R_DRAIN:if(M_RVALID&&M_RREADY)begin
     if(!r_seen_data)S_RDATA<=M_RDATA;
     r_seen_data<=1;
     if(M_RRESP!=0||!M_RLAST||r_seen_data)begin r_poison<=1;fault<=1;end
     // Missing LAST never abandons the accepted burst: drain through LAST.
     if(M_RLAST)begin
      S_RRESP<=r_poison||!live||M_RRESP!=0||r_seen_data?2'b10:2'b00;rs<=R_REPORT;
     end
    end
    R_REPORT:if(S_RVALID&&S_RREADY)rs<=R_IDLE;
   endcase
   case(ws)
    W_COLLECT:begin
     if(S_AWVALID&&S_AWREADY)begin
      aw_held<=1;M_AWADDR<=S_AWADDR;aw_ok<=allowed_address(S_AWADDR,S_AWLEN,S_AWSIZE,S_AWBURST);
      if(!live)w_poison<=1;
     end
     if(S_WVALID&&S_WREADY)begin w_held<=1;M_WDATA<=S_WDATA;w_ok<=S_WLAST&&S_WSTRB==32'hffffffff;if(!live)w_poison<=1;end
     if(aw_held&&w_held)begin
      if(aw_ok&&w_ok&&!w_poison&&live)begin ws<=W_SEND;aw_sent<=0;w_sent<=0;end
      else begin ws<=W_REPORT;S_BRESP<=2'b10;if(!aw_ok||!w_ok)fault<=1;end
     end
    end
    W_SEND:begin
     if(M_AWVALID&&M_AWREADY)aw_sent<=1;
     if(M_WVALID&&M_WREADY)w_sent<=1;
     if((aw_sent||M_AWVALID&&M_AWREADY)&&(w_sent||M_WVALID&&M_WREADY))ws<=W_DRAIN;
    end
    W_DRAIN:if(M_BVALID&&M_BREADY)begin S_BRESP<=w_poison||!live||M_BRESP!=0?2'b10:2'b00;ws<=W_REPORT;if(M_BRESP!=0)fault<=1;end
    W_REPORT:if(S_BVALID&&S_BREADY)begin ws<=W_COLLECT;aw_held<=0;w_held<=0;w_poison<=0;end
   endcase
  end
 end
endmodule
