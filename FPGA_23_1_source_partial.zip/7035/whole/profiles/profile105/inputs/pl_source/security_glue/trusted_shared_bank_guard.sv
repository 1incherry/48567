`timescale 1ns/1ps
// Final PHYSICAL A/B RAM entrance. desired_stage is trusted PL, never PS CSR.
// No added read-data pipeline: the existing RAM remains 1-cycle read+hold.
// External YOLO/frontend mutual exclusion must be enforced before this port.
module trusted_shared_bank_guard #(
 parameter integer A_WORDS=2548,B_WORDS=2352
)(
 input wire clk,security_reset_n,
 input wire [1:0] desired_stage,input wire all_quiescent,bank_access_live,
 input wire internal_a_wr,internal_b_wr,
 input wire [11:0] internal_a_write_addr,internal_b_write_addr,
 input wire [255:0] internal_a_write_data,internal_b_write_data,
 input wire internal_a_rd,internal_b_rd,
 input wire [11:0] internal_a_read_addr,internal_b_read_addr,
 input wire external_a_wr,external_b_wr,
 input wire [11:0] external_write_addr,input wire [255:0] external_write_data,
 input wire external_a_rd,external_b_rd,
 input wire [11:0] external_a_read_addr,external_b_read_addr,
 output reg [1:0] committed_stage,
 output wire owner_ready,output reg bank_fault,output wire guard_quiescent,
 output wire ram_a_wr_en,ram_b_wr_en,
 output wire [11:0] ram_a_write_addr,ram_b_write_addr,
 output wire [255:0] ram_a_write_data,ram_b_write_data,
 output wire ram_a_rd_en,ram_b_rd_en,
 output wire [11:0] ram_a_read_addr,ram_b_read_addr
);
 wire internal_request=internal_a_wr||internal_b_wr||internal_a_rd||internal_b_rd;
 wire external_request=external_a_wr||external_b_wr||external_a_rd||external_b_rd;
 wire any_request=internal_request||external_request;
 wire internal_owner=committed_stage==1;
 wire external_owner=committed_stage==2||committed_stage==3;
 wire inactive_request=(internal_request&&!internal_owner)||(external_request&&!external_owner);
 wire range_fault=
  (internal_a_wr&&internal_a_write_addr>=A_WORDS)||(internal_b_wr&&internal_b_write_addr>=B_WORDS)||
  (internal_a_rd&&internal_a_read_addr>=A_WORDS)||(internal_b_rd&&internal_b_read_addr>=B_WORDS)||
  (external_a_wr&&external_write_addr>=A_WORDS)||(external_b_wr&&external_write_addr>=B_WORDS)||
  (external_a_rd&&external_a_read_addr>=A_WORDS)||(external_b_rd&&external_b_read_addr>=B_WORDS);
 wire violation=inactive_request||range_fault;
 // Revocation/cancel closes the physical entrance on this same edge. It is
 // not itself a protocol fault; inactive/range violations still latch fault.
 wire access_allowed=security_reset_n&&bank_access_live&&!bank_fault&&!violation;
 assign ram_a_wr_en=access_allowed&&(internal_owner?internal_a_wr:external_owner&&external_a_wr);
 assign ram_b_wr_en=access_allowed&&(internal_owner?internal_b_wr:external_owner&&external_b_wr);
 assign ram_a_rd_en=access_allowed&&(internal_owner?internal_a_rd:external_owner&&external_a_rd);
 assign ram_b_rd_en=access_allowed&&(internal_owner?internal_b_rd:external_owner&&external_b_rd);
 assign ram_a_write_addr=internal_owner?internal_a_write_addr:external_write_addr;
 assign ram_b_write_addr=internal_owner?internal_b_write_addr:external_write_addr;
 assign ram_a_write_data=internal_owner?internal_a_write_data:external_write_data;
 assign ram_b_write_data=internal_owner?internal_b_write_data:external_write_data;
 assign ram_a_read_addr=internal_owner?internal_a_read_addr:external_a_read_addr;
 assign ram_b_read_addr=internal_owner?internal_b_read_addr:external_b_read_addr;
 reg previous_read,quiet_previous;
 wire quiet_now=all_quiescent&&!any_request&&!previous_read;
 // Physical quiet remains observable on a sticky fault, enabling safe system
 // drain/inspection; owner changes and all new accesses remain forbidden.
 assign guard_quiescent=security_reset_n&&quiet_now;
 assign owner_ready=security_reset_n&&!bank_fault&&!violation&&quiet_now&&quiet_previous;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin committed_stage<=0;bank_fault<=0;previous_read<=0;quiet_previous<=0;end
  else begin
   previous_read<=ram_a_rd_en||ram_b_rd_en;
   quiet_previous<=quiet_now;
   if(violation)bank_fault<=1;
   if(owner_ready)committed_stage<=desired_stage;
  end
 end
endmodule
