`timescale 1ns/1ps
// Trust-0 audio diagnostic path. PS claims are requests, never ownership grants.
// Cancellation never resets cache/core state or withdraws already offered AXI.
// If active/dirty audio cannot drain, quiescent stays false until trusted POR.
module trusted_audio_serial_path(
 input wire clk,security_reset_n,trusted_can_enable,committed_owner_grant,cancel,
 output wire claim,audio_active,audio_busy,irq,
 output wire cache_clean,cache_idle,cache_fault,management_quiet,
 output wire fence_quiet,quiescent,fault,
input wire [20:0] s_axi_awaddr,input wire [2:0] s_axi_awprot,input wire s_axi_awvalid,output wire s_axi_awready,
input wire [31:0] s_axi_wdata,input wire [3:0] s_axi_wstrb,input wire s_axi_wvalid,output wire s_axi_wready,
output wire [1:0] s_axi_bresp,output wire s_axi_bvalid,input wire s_axi_bready,
input wire [20:0] s_axi_araddr,input wire [2:0] s_axi_arprot,input wire s_axi_arvalid,output wire s_axi_arready,
output wire [31:0] s_axi_rdata,output wire [1:0] s_axi_rresp,output wire s_axi_rvalid,input wire s_axi_rready,
output wire [31:0] M_AXI_ARADDR,output wire [7:0] M_AXI_ARLEN,output wire [2:0] M_AXI_ARSIZE,output wire [1:0] M_AXI_ARBURST,
output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,input wire [255:0] M_AXI_RDATA,input wire [1:0] M_AXI_RRESP,input wire M_AXI_RLAST,M_AXI_RVALID,output wire M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,output wire [7:0] M_AXI_AWLEN,output wire [2:0] M_AXI_AWSIZE,output wire [1:0] M_AXI_AWBURST,
output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,output wire [255:0] M_AXI_WDATA,output wire [31:0] M_AXI_WSTRB,output wire M_AXI_WLAST,M_AXI_WVALID,input wire M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY);
 wire owner_live=trusted_can_enable&&committed_owner_grant&&!cancel;
 wire fence_fault;
 wire [31:0] a_M_AXI_ARADDR;
 wire [7:0] a_M_AXI_ARLEN;
 wire [2:0] a_M_AXI_ARSIZE;
 wire [1:0] a_M_AXI_ARBURST;
 wire  a_M_AXI_ARVALID;
 wire  a_M_AXI_ARREADY;
 wire [255:0] a_M_AXI_RDATA;
 wire [1:0] a_M_AXI_RRESP;
 wire  a_M_AXI_RLAST;
 wire  a_M_AXI_RVALID;
 wire  a_M_AXI_RREADY;
 wire [31:0] a_M_AXI_AWADDR;
 wire [7:0] a_M_AXI_AWLEN;
 wire [2:0] a_M_AXI_AWSIZE;
 wire [1:0] a_M_AXI_AWBURST;
 wire  a_M_AXI_AWVALID;
 wire  a_M_AXI_AWREADY;
 wire [255:0] a_M_AXI_WDATA;
 wire [31:0] a_M_AXI_WSTRB;
 wire  a_M_AXI_WLAST;
 wire  a_M_AXI_WVALID;
 wire  a_M_AXI_WREADY;
 wire [1:0] a_M_AXI_BRESP;
 wire  a_M_AXI_BVALID;
 wire  a_M_AXI_BREADY;
 audio_serial_top audio(
 .clk(clk),.rst_n(security_reset_n),.can_enable(owner_live),
 .claim(claim),.active(audio_active),.busy(audio_busy),.irq(irq),
 .diagnostic_cache_clean(cache_clean),.diagnostic_cache_idle(cache_idle),
 .diagnostic_cache_fault(cache_fault),.diagnostic_management_quiet(management_quiet),
 .s_axi_awaddr(s_axi_awaddr),
 .s_axi_awprot(s_axi_awprot),
 .s_axi_awvalid(s_axi_awvalid),
 .s_axi_awready(s_axi_awready),
 .s_axi_wdata(s_axi_wdata),
 .s_axi_wstrb(s_axi_wstrb),
 .s_axi_wvalid(s_axi_wvalid),
 .s_axi_wready(s_axi_wready),
 .s_axi_bresp(s_axi_bresp),
 .s_axi_bvalid(s_axi_bvalid),
 .s_axi_bready(s_axi_bready),
 .s_axi_araddr(s_axi_araddr),
 .s_axi_arprot(s_axi_arprot),
 .s_axi_arvalid(s_axi_arvalid),
 .s_axi_arready(s_axi_arready),
 .s_axi_rdata(s_axi_rdata),
 .s_axi_rresp(s_axi_rresp),
 .s_axi_rvalid(s_axi_rvalid),
 .s_axi_rready(s_axi_rready),
 .M_AXI_ARADDR(a_M_AXI_ARADDR),
 .M_AXI_ARLEN(a_M_AXI_ARLEN),
 .M_AXI_ARSIZE(a_M_AXI_ARSIZE),
 .M_AXI_ARBURST(a_M_AXI_ARBURST),
 .M_AXI_ARVALID(a_M_AXI_ARVALID),
 .M_AXI_ARREADY(a_M_AXI_ARREADY),
 .M_AXI_RDATA(a_M_AXI_RDATA),
 .M_AXI_RRESP(a_M_AXI_RRESP),
 .M_AXI_RLAST(a_M_AXI_RLAST),
 .M_AXI_RVALID(a_M_AXI_RVALID),
 .M_AXI_RREADY(a_M_AXI_RREADY),
 .M_AXI_AWADDR(a_M_AXI_AWADDR),
 .M_AXI_AWLEN(a_M_AXI_AWLEN),
 .M_AXI_AWSIZE(a_M_AXI_AWSIZE),
 .M_AXI_AWBURST(a_M_AXI_AWBURST),
 .M_AXI_AWVALID(a_M_AXI_AWVALID),
 .M_AXI_AWREADY(a_M_AXI_AWREADY),
 .M_AXI_WDATA(a_M_AXI_WDATA),
 .M_AXI_WSTRB(a_M_AXI_WSTRB),
 .M_AXI_WLAST(a_M_AXI_WLAST),
 .M_AXI_WVALID(a_M_AXI_WVALID),
 .M_AXI_WREADY(a_M_AXI_WREADY),
 .M_AXI_BRESP(a_M_AXI_BRESP),
 .M_AXI_BVALID(a_M_AXI_BVALID),
 .M_AXI_BREADY(a_M_AXI_BREADY));
 trusted_audio_axi_fence fence(
 .clk(clk),.security_reset_n(security_reset_n),.admission_enable(owner_live),.cancel(cancel),
 .S_ARADDR(a_M_AXI_ARADDR),
 .M_ARADDR(M_AXI_ARADDR),
 .S_ARLEN(a_M_AXI_ARLEN),
 .M_ARLEN(M_AXI_ARLEN),
 .S_ARSIZE(a_M_AXI_ARSIZE),
 .M_ARSIZE(M_AXI_ARSIZE),
 .S_ARBURST(a_M_AXI_ARBURST),
 .M_ARBURST(M_AXI_ARBURST),
 .S_ARVALID(a_M_AXI_ARVALID),
 .M_ARVALID(M_AXI_ARVALID),
 .S_ARREADY(a_M_AXI_ARREADY),
 .M_ARREADY(M_AXI_ARREADY),
 .S_RDATA(a_M_AXI_RDATA),
 .M_RDATA(M_AXI_RDATA),
 .S_RRESP(a_M_AXI_RRESP),
 .M_RRESP(M_AXI_RRESP),
 .S_RLAST(a_M_AXI_RLAST),
 .M_RLAST(M_AXI_RLAST),
 .S_RVALID(a_M_AXI_RVALID),
 .M_RVALID(M_AXI_RVALID),
 .S_RREADY(a_M_AXI_RREADY),
 .M_RREADY(M_AXI_RREADY),
 .S_AWADDR(a_M_AXI_AWADDR),
 .M_AWADDR(M_AXI_AWADDR),
 .S_AWLEN(a_M_AXI_AWLEN),
 .M_AWLEN(M_AXI_AWLEN),
 .S_AWSIZE(a_M_AXI_AWSIZE),
 .M_AWSIZE(M_AXI_AWSIZE),
 .S_AWBURST(a_M_AXI_AWBURST),
 .M_AWBURST(M_AXI_AWBURST),
 .S_AWVALID(a_M_AXI_AWVALID),
 .M_AWVALID(M_AXI_AWVALID),
 .S_AWREADY(a_M_AXI_AWREADY),
 .M_AWREADY(M_AXI_AWREADY),
 .S_WDATA(a_M_AXI_WDATA),
 .M_WDATA(M_AXI_WDATA),
 .S_WSTRB(a_M_AXI_WSTRB),
 .M_WSTRB(M_AXI_WSTRB),
 .S_WLAST(a_M_AXI_WLAST),
 .M_WLAST(M_AXI_WLAST),
 .S_WVALID(a_M_AXI_WVALID),
 .M_WVALID(M_AXI_WVALID),
 .S_WREADY(a_M_AXI_WREADY),
 .M_WREADY(M_AXI_WREADY),
 .S_BRESP(a_M_AXI_BRESP),
 .M_BRESP(M_AXI_BRESP),
 .S_BVALID(a_M_AXI_BVALID),
 .M_BVALID(M_AXI_BVALID),
 .S_BREADY(a_M_AXI_BREADY),
 .M_BREADY(M_AXI_BREADY),
 .quiescent(fence_quiet),.fault(fence_fault));
 // A manager transaction, dirty cache line or offered PS transaction is
 // outstanding work even when no DDR VALID is currently asserted.
 assign quiescent=security_reset_n&&!audio_active&&!audio_busy&&cache_clean&&cache_idle&&
   management_quiet&&fence_quiet&&!s_axi_awvalid&&!s_axi_wvalid&&!s_axi_arvalid;
 assign fault=cache_fault||fence_fault;
endmodule
