# Only first synchronizer stages are cut. All later stages remain timed.
set nfr_first [get_pins -quiet -hier -regexp {.*u_frames/(receiver/(send|ack)_sync_reg\[0\]|transmitter/(send|ack)_sync_reg\[0\])/D}]
set_false_path -to $nfr_first

# Immutable header/payload mailboxes are sampled only after three toggle
# synchronizer stages plus FSM handling. Bound data arrival, no domain cut.
set nfr_rx_held [get_cells -quiet -hier -regexp {.*u_frames/receiver/held_header_reg\[[0-9]+\]}]
set nfr_rx_local [get_cells -quiet -hier -regexp {.*u_frames/receiver/local_header_reg\[[0-9]+\]}]
set_max_delay -datapath_only 8.000 -from $nfr_rx_held -to $nfr_rx_local
set_bus_skew 4.000 -from $nfr_rx_held -to $nfr_rx_local
set nfr_tx_held [get_cells -quiet -hier -regexp {.*u_frames/transmitter/held_packet_reg\[[0-9]+\]}]
set nfr_tx_local [get_cells -quiet -hier -regexp {.*u_frames/transmitter/local_packet_reg\[[0-9]+\]}]
set_max_delay -datapath_only 8.000 -from $nfr_tx_held -to $nfr_tx_local
set_bus_skew 4.000 -from $nfr_tx_held -to $nfr_tx_local


# No raw statistics Gray counters exist in this native endpoint.
