# Only the new pixel FIFO, called on actual linked synthesis before opt.
# No direct source_bundle -> destination_data wide group exists in this architecture.
# Every actual vendor Gray bus gets max4ns/skew1ns; every business D/CE/CLR stays timed.
proc constrain_trusted_pixel_fifo_cdc {instance} {
 foreach name {ack_sync request_sync commit_sync source_fault_sync destination_fault_sync fifo_live_sync} {
  set c [get_cells -hier -filter [format {NAME == "%s/%s_reg[0]"} $instance $name]]
  if {[llength $c]!=1} {error "PIXEL_FIRST_SYNC_COUNT $instance/$name"}
  if {[string tolower [get_property ASYNC_REG $c]] ni {true 1}} {error "PIXEL_FIRST_NOT_ASYNCREG $name"}
  set_false_path -to [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]
 }
 foreach {name n} {destination_release 3 destination_alive 3 fifo_reset_release 8 ack_sync 3 request_sync 3 commit_sync 3 source_fault_sync 3 destination_fault_sync 3 fifo_live_sync 3} {
  set c [get_cells -hier -filter [format {NAME =~ "%s/%s_reg*"} $instance $name]]
  if {[llength $c]!=$n} {error "PIXEL_RESET_SYNC_COUNT $instance/$name expected$n actual[llength $c]"}
  foreach ff $c {if {[string tolower [get_property ASYNC_REG $ff]] ni {true 1}} {error "PIXEL_RESET_NOT_ASYNCREG $ff"}}
  set pp [get_pins -of_objects $c -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
  if {[llength $pp]!=$n} {error "PIXEL_SYNC_RESET_PIN_COUNT $name"}
  set_false_path -to $pp
 }
 set c [get_cells -hier -filter [format {NAME == "%s/fifo_reset_pending_reg"} $instance]]
 if {[llength $c]!=1} {error PIXEL_RESET_PENDING_COUNT}
 set pp [get_pins -of_objects $c -filter {REF_PIN_NAME == PRE}]
 if {[llength $pp]!=1} {error PIXEL_RESET_PENDING_ASYNC_SET_COUNT}
 # Deliberate asynchronous pulse catcher; eight source reset-release stages
 # plus actual vendor reset-busy handshake precede any later record acceptance.
 set_false_path -to $pp
 set pattern [format {%s/report_fifo/.*gen_rst_ic[./](wrst_rd_inst|rrst_wr_inst)/syncstages_ff_reg\[0\]} $instance]
 set c [get_cells -hier -regexp $pattern]
 if {[llength $c]!=2} {error "PIXEL_VENDOR_RESET_FIRST_STAGE_COUNT [llength $c]"}
 foreach ff $c {if {[string tolower [get_property ASYNC_REG $ff]] ni {true 1}} {error PIXEL_VENDOR_RESET_NOT_ASYNCREG}}
 set_false_path -to [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]
 set pattern [format {%s/report_fifo/.*pntr_cdc(_dc)?_inst/src_gray_ff_reg\[[0-9]+\]} $instance]
 set src [get_cells -hier -regexp $pattern]
 if {[llength $src]!=30} {error "PIXEL_LINKED_FOUR_GRAY_BUSES_EXPECTED30 actual[llength $src]"}
 set prefixes {};foreach ff $src {regsub {/src_gray_ff_reg\[[0-9]+\]$} $ff {} prefix;lappend prefixes $prefix}
 set prefixes [lsort -unique $prefixes]
 if {[llength $prefixes]!=4} {error PIXEL_LINKED_FOUR_GRAY_PREFIXES}
 foreach prefix $prefixes {
  set ss [get_cells -hier -filter "NAME =~ ${prefix}/src_gray_ff_reg*"]
  set dd [get_cells -hier -filter "NAME =~ ${prefix}/dest_graysync_ff_reg*"]
  set first {};foreach ff $dd {if {[regexp {/dest_graysync_ff_reg\[0\]\[[0-9]+\]$} $ff]} {lappend first $ff}}
  set n 7;if {[string match *pntr_cdc_dc_inst $prefix]} {set n 8}
  if {[llength $ss]!=$n||[llength $first]!=$n||[llength $dd]!=3*$n} {error "PIXEL_GRAY_TOPOLOGY $prefix"}
  foreach ff $dd {if {[string tolower [get_property ASYNC_REG $ff]] ni {true 1}} {error "PIXEL_GRAY_ASYNC_REG $ff"}}
  set_max_delay -datapath_only 4.0 -from $ss -to $first
  set_false_path -hold -from $ss -to $first
  set_bus_skew 1.0 -from $ss -to $first
  puts "TRUSTED_PIXEL_GRAY_CONSTRAINED $prefix source$n first$n max4ns skew1ns"
 }
 puts "TRUSTED_PIXEL_FIFO_LINKED_BOUND $instance groups4 src30 sync90; extended unused buses must be positively audited after opt, never claimed routed"
}
