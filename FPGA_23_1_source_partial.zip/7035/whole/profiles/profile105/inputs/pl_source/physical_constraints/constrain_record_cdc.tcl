# Source after synthesis in the actual full project, for each real mailbox.
# No asynchronous whole-clock cut. Exact first synchronizer D pins only;
# the bundled data remains timed with max-delay and bus-skew constraints.
proc constrain_trusted_record_cdc {instance source_period destination_period} {
 set prefix [format {NAME =~ "%s/source_bundle_reg*"} $instance]
 set src [get_cells -hier -filter $prefix]
 set dst [get_cells -hier -filter [format {NAME =~ "%s/destination_data_reg*"} $instance]]
 if {[llength $src]==0||[llength $dst]==0} {error "RECORD_BUNDLE_ENDPOINT_EMPTY $instance"}
 set max_delay [expr {min($source_period,$destination_period)*0.75}]
 set_max_delay -datapath_only $max_delay -from $src -to $dst
 set_bus_skew 1.0 -from $src -to $dst
 foreach name {ack_sync_reg[0] request_sync_reg[0]} {
  set first [get_cells -hier -filter [format {NAME == "%s/%s"} $instance $name]]
  if {[llength $first]!=1} {error "RECORD_FIRST_SYNC_NOT_UNIQUE $instance/$name"}
  set d [get_pins -of_objects $first -filter {REF_PIN_NAME == D}]
  if {[llength $d]!=1} {error "RECORD_FIRST_SYNC_D_NOT_UNIQUE $instance/$name"}
  set_false_path -to $d
 }
 # Only the reset synchronizers intentionally receive asynchronous assertion.
 # Their release is synchronized; ordinary data-register reset paths stay timed.
 foreach name {destination_alive_reg destination_release_reg} {
  set syncs [get_cells -hier -filter [format {NAME =~ "%s/%s*"} $instance $name]]
  if {[llength $syncs]!=3} {error "RECORD_RESET_SYNC_WIDTH $instance/$name"}
  set clears [get_pins -of_objects $syncs -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
  if {[llength $clears]!=3} {error "RECORD_RESET_SYNC_CLEAR_WIDTH $instance/$name"}
  set_false_path -to $clears
 }
 puts "TRUSTED_RECORD_CDC_CONSTRAINED $instance source=[llength $src] destination=[llength $dst] max_delay=$max_delay bus_skew=1ns"
}
proc constrain_trusted_record_overlay {instance} {
 set syncs [get_cells -hier -filter [format {NAME =~ "%s/live_sync_reg*"} $instance]]
 if {[llength $syncs]!=2} {error "RECORD_OVERLAY_RESET_SYNC_WIDTH $instance"}
 set clears [get_pins -of_objects $syncs -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
 if {[llength $clears]!=2} {error "RECORD_OVERLAY_RESET_SYNC_CLEAR_WIDTH $instance"}
 set_false_path -to $clears
}
