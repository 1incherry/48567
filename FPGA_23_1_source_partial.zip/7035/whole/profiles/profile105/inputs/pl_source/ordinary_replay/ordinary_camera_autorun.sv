`timescale 1ns/1ps
// Default-off trusted run grant + one actual vision completion flow ticket.
// PS receipts are untrusted flow control, never execution/model authority.
module ordinary_camera_autorun #(parameter integer ENABLE=0)(
 input wire clk,security_reset_n,start_grant,stop_grant,
 input wire authority_live,input wire[31:0]runtime_epoch,model_epoch,
 input wire[127:0]key_session,key_fingerprint,input wire start_resources_idle,
 output wire start_ready,request_valid,input wire request_ready,
 input wire[31:0]next_session,next_frame,
 input wire actual_active,actual_retired,actual_failed,
 input wire record_commit,record_visible,record_is_replay,
 input wire[31:0]record_camera,record_session,record_frame,record_epoch,
 input wire[127:0]record_key,
 input wire ps_ack_valid,input wire[351:0]ps_ack,
 output wire busy,grant_live,wait_ack,flow_block,
 output wire[31:0]status,ticket,output wire[319:0]expected
);
 localparam IDLE=0,OFFER=1,ACTIVE=2,COPY=3,DRAIN=4,FAILED=5,BASELINE=6;
 reg[2:0]state;
 reg grant,seen_active,failed,stop_pending,vision_valid,vision_replay;
 reg[31:0]bound_epoch,bound_model,own_session,own_frame,serial,processed_serial;
 reg[127:0]bound_key,bound_fingerprint;
 reg[287:0]vision_context;
 wire binding=authority_live&&runtime_epoch!=0&&model_epoch!=0&&runtime_epoch==bound_epoch&&model_epoch==bound_model&&key_session==bound_key&&key_fingerprint==bound_fingerprint;
 wire live_vision=ENABLE!=0&&vision_valid&&authority_live&&record_visible;
 wire pending_vision=live_vision&&processed_serial!=serial;
 wire exhausted=serial==32'hffffffff;
 wire new_vision=record_commit&&authority_live&&record_visible&&record_session!=0&&record_frame!=0&&record_epoch!=0&&record_key!=0&&!exhausted;
 assign grant_live=ENABLE!=0&&grant&&binding&&!stop_grant;
 assign busy=ENABLE!=0&&state!=IDLE;
 assign start_ready=ENABLE!=0&&state==IDLE&&start_resources_idle&&authority_live&&runtime_epoch!=0&&model_epoch!=0&&!exhausted;
 assign request_valid=grant_live&&state==OFFER&&!stop_pending&&!pending_vision&&!new_vision&&!exhausted&&next_session!=0&&next_frame!=0;
 assign wait_ack=pending_vision;
 assign flow_block=ENABLE!=0&&(pending_vision||new_vision||exhausted);
 assign ticket=ENABLE!=0?serial:32'd0;
 // Low-to-high: camera,S,F,E,model,key words0..3,vision commit serial.
 assign expected=ENABLE!=0?{serial,vision_context}:320'd0;
 assign status=ENABLE!=0?{21'd0,live_vision,vision_replay,(failed||exhausted),(state==BASELINE),state,1'b0,wait_ack,busy,grant_live}:32'd0;
 wire matching_accepted_vision=live_vision&&vision_context[31:0]==0&&vision_context[63:32]==own_session&&vision_context[95:64]==own_frame&&vision_context[127:96]==bound_epoch&&vision_context[159:128]==bound_model&&vision_context[287:160]==bound_key;
 wire exact_ack=ps_ack_valid&&live_vision&&serial!=0&&ps_ack=={serial,expected};
 always@(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=IDLE;grant<=0;seen_active<=0;failed<=0;stop_pending<=0;vision_valid<=0;vision_replay<=0;
   bound_epoch<=0;bound_model<=0;bound_key<=0;bound_fingerprint<=0;own_session<=0;own_frame<=0;serial<=0;processed_serial<=0;vision_context<=0;
  end else if(ENABLE!=0)begin
   if(!authority_live||!record_visible)vision_valid<=0;
   // Only the real private vision-bank commit changes this serial/context.
   if(new_vision)begin
    serial<=serial+1'b1;vision_valid<=1;vision_replay<=record_is_replay;
    vision_context<={record_key,model_epoch,record_epoch,record_frame,record_session,record_camera};
   end
   if(exact_ack)processed_serial<=serial;
   // ACK never writes any grant-context field and never sets grant.
   if(grant&&!binding)begin grant<=0;stop_pending<=1;end
   if(stop_grant)begin grant<=0;stop_pending<=1;end
   case(state)
    IDLE:if(start_grant&&start_ready)begin
     bound_epoch<=runtime_epoch;bound_model<=model_epoch;bound_key<=key_session;bound_fingerprint<=key_fingerprint;
     grant<=1;stop_pending<=0;failed<=0;seen_active<=0;
     if(pending_vision||new_vision)begin own_session<=new_vision?serial+1'b1:serial;state<=BASELINE;end
     else state<=OFFER;
    end
    BASELINE:begin
     if(!binding)begin grant<=0;state<=DRAIN;end
     else if(live_vision&&serial==own_session&&processed_serial==own_session)begin
      if(grant_live&&!stop_pending)state<=OFFER;else begin grant<=0;state<=IDLE;end
     end
    end
    OFFER:begin
     if(!grant_live||stop_pending)state<=IDLE;
     else if(request_valid&&request_ready)begin own_session<=next_session;own_frame<=next_frame;seen_active<=0;failed<=0;state<=ACTIVE;end
    end
    ACTIVE:begin
     if(actual_active)seen_active<=1;
     if(actual_failed)failed<=1;
     if(!binding)begin grant<=0;state<=DRAIN;end
     else if(seen_active&&actual_retired&&!actual_active)begin
      if(failed||actual_failed)begin grant<=0;failed<=1;state<=FAILED;end
      else if(matching_accepted_vision)state<=COPY;
     end
    end
    COPY:begin
     if(!binding)begin grant<=0;state<=DRAIN;end
     else if(matching_accepted_vision&&processed_serial==serial)begin
      if(grant_live&&!stop_pending&&!exhausted)state<=OFFER;
      else begin grant<=0;state<=IDLE;end
     end
    end
    DRAIN:if(actual_retired&&!actual_active)state<=IDLE;
    FAILED:if(actual_retired&&!actual_active)state<=IDLE;
    default:begin grant<=0;failed<=1;state<=DRAIN;end
   endcase
  end
 end
endmodule
