module ordinary_nfr_or_slot_letterbox_parent #(parameter integer ENABLE_ORDINARY_SLOT_REPLAY=0)(
 input wire clk,rst_n,cancel,authorized,key_valid,input wire [31:0] authorization_epoch,
 input wire frame_begin,output wire frame_begin_ready,input wire [31:0] trusted_session,trusted_frame,trusted_epoch,
 input wire producer_frame_ready,input wire [31:0] producer_session,producer_frame,
 output wire producer_cancel,output wire frame_ready,output wire quiescent,
 output wire failed,output wire [31:0] result_session,result_frame,result_epoch,
 output wire [31:0] output_committed_bytes,
 input wire [31:0] CAM_AWADDR,input wire [7:0] CAM_AWLEN,input wire [2:0] CAM_AWSIZE,input wire [1:0] CAM_AWBURST,
 input wire CAM_AWVALID,output wire CAM_AWREADY,input wire [63:0] CAM_WDATA,input wire [7:0] CAM_WSTRB,
 input wire CAM_WLAST,CAM_WVALID,output wire CAM_WREADY,output wire [1:0] CAM_BRESP,output wire CAM_BVALID,input wire CAM_BREADY,
 input wire [31:0] PS_AWADDR,input wire PS_AWVALID,output wire PS_AWREADY,
 input wire [31:0] PS_WDATA,input wire [3:0] PS_WSTRB,input wire PS_WVALID,output wire PS_WREADY,
 output wire [1:0] PS_BRESP,output wire PS_BVALID,input wire PS_BREADY,
 input wire [31:0] PS_ARADDR,input wire PS_ARVALID,output wire PS_ARREADY,
 output wire [31:0] PS_RDATA,output wire [1:0] PS_RRESP,output wire PS_RVALID,input wire PS_RREADY,
 output wire request_valid,input wire request_ready,output wire request_write,
 output wire [31:0] request_session,request_frame,request_epoch,request_version,
 output wire [15:0] request_role,request_shape,
 output wire [31:0] request_address,request_tensor_mask,request_strobe,output wire [255:0] request_data,
 input wire response_valid,output wire response_ready,input wire response_error,guard_context_live,
 input wire [255:0] response_data,input wire guard_quiescent,
 output wire raw_sealed_valid,raw_writer_quiet,output wire[31:0] raw_committed_bytes
,
 input wire replay_start_valid,output wire replay_start_ready,
 input wire[6:0] replay_slot,input wire[63:0] replay_generation,replay_batch,
 input wire replay_slot_held,replay_cache_clean,
 input wire[31:0] replay_token,replay_session,replay_frame,replay_epoch,
 input wire[31:0] current_model,input wire[127:0] current_key_session,
 input wire ingress_io_drained,
 input wire replay_retire_valid,input wire[31:0] replay_retire_token,replay_retire_session,replay_retire_frame,replay_retire_epoch,
 output wire replay_retire_ready,replay_completion_valid,input wire replay_completion_ready,
 output wire replay_completion_failed,output wire[7:0] replay_error,
 output wire replay_owner,output wire[31:0] replay_exec_token,replay_exec_session,replay_exec_frame,replay_exec_epoch,
 output wire[31:0] replay_source_bytes,replay_write_response_bytes,
 output wire[31:0] SLOT_ARADDR,output wire[7:0] SLOT_ARLEN,output wire[2:0] SLOT_ARSIZE,output wire[1:0] SLOT_ARBURST,
 output wire SLOT_ARVALID,input wire SLOT_ARREADY,input wire[63:0] SLOT_RDATA,input wire[1:0] SLOT_RRESP,
 input wire SLOT_RLAST,SLOT_RVALID,output wire SLOT_RREADY
,
 output wire[7:0] diagnostic_failure_now,diagnostic_state,diagnostic_bridge_failure_now,diagnostic_bridge_state,output wire[31:0] diagnostic_raw_accepted_bytes
);
 // Exactly one existing authwriter/letterbox/guard path. Never switch an
 // admitted frame's source based on a PS release or a ready/valid fluctuation.
 reg owner_reg;
 wire owner=ENABLE_ORDINARY_SLOT_REPLAY!=0?owner_reg:1'b0;
 assign replay_owner=owner;
 wire parent_begin_ready,src_ready,src_bind,src_loaded,src_busy,src_quiet;
 wire parent_awready,parent_wready,parent_bvalid;wire[1:0] parent_bresp;
 wire[31:0] sw_awaddr,raw_accepted;wire[7:0] sw_awlen;wire[2:0] sw_awsize;wire[1:0] sw_awburst;
 wire sw_awvalid,sw_wvalid,sw_wlast,sw_bready;wire[63:0] sw_wdata;wire[7:0] sw_wstrb;
 wire[31:0] unused_model;wire[127:0] unused_key;wire[6:0] unused_slot;wire[63:0] unused_gen,unused_batch;
 wire source_grant=ENABLE_ORDINARY_SLOT_REPLAY!=0&&replay_start_valid&&parent_begin_ready&&!frame_begin;
 assign replay_start_ready=ENABLE_ORDINARY_SLOT_REPLAY!=0&&src_ready&&parent_begin_ready&&!frame_begin;
 assign frame_begin_ready=!owner&&parent_begin_ready&&!source_grant;
 assign CAM_AWREADY=!owner&&parent_awready;assign CAM_WREADY=!owner&&parent_wready;
 assign CAM_BVALID=!owner&&parent_bvalid;assign CAM_BRESP=parent_bresp;
 always @(posedge clk)begin
  if(!rst_n)owner_reg<=0;
  else if(source_grant&&src_ready)owner_reg<=1;
  else if(replay_completion_valid&&replay_completion_ready)owner_reg<=0;
 end
 ordinary_history_slot_raw_source source(
  .clk(clk),.rst_n(rst_n),.cancel(cancel),.authorized(authorized),.key_valid(key_valid),.current_epoch(authorization_epoch),.current_model(current_model),.current_key_session(current_key_session),
  .start_valid(source_grant),.start_ready(src_ready),.start_slot(replay_slot),.start_slot_generation(replay_generation),.start_batch(replay_batch),.start_slot_held(replay_slot_held),.start_cache_clean(replay_cache_clean),
  .start_token(replay_token),.start_session(replay_session),.start_frame(replay_frame),.start_epoch(replay_epoch),.bind_valid(src_bind),.bind_ready(owner&&parent_begin_ready),
  .exec_token(replay_exec_token),.exec_session(replay_exec_session),.exec_frame(replay_exec_frame),.exec_epoch(replay_exec_epoch),.exec_model(unused_model),.exec_key_session(unused_key),.owned_slot(unused_slot),.owned_generation(unused_gen),.owned_batch(unused_batch),
  .producer_frame_ready(src_loaded),.writer_quiet(raw_writer_quiet),.writer_fault(failed),.job_io_drained(ingress_io_drained),.writer_accepted_bytes(raw_accepted),.writer_committed_bytes(raw_committed_bytes),
  .retire_valid(replay_retire_valid),.retire_token(replay_retire_token),.retire_session(replay_retire_session),.retire_frame(replay_retire_frame),.retire_epoch(replay_retire_epoch),.retire_ready(replay_retire_ready),
  .completion_valid(replay_completion_valid),.completion_ready(replay_completion_ready),.completion_failed(replay_completion_failed),.error_code(replay_error),.busy(src_busy),.quiescent(src_quiet),.source_bytes(replay_source_bytes),.write_response_bytes(replay_write_response_bytes),
  .M_ARADDR(SLOT_ARADDR),.M_ARLEN(SLOT_ARLEN),.M_ARSIZE(SLOT_ARSIZE),.M_ARBURST(SLOT_ARBURST),.M_ARVALID(SLOT_ARVALID),.M_ARREADY(SLOT_ARREADY),.M_RDATA(SLOT_RDATA),.M_RRESP(SLOT_RRESP),.M_RLAST(SLOT_RLAST),.M_RVALID(SLOT_RVALID),.M_RREADY(SLOT_RREADY),
  .CAM_AWADDR(sw_awaddr),.CAM_AWLEN(sw_awlen),.CAM_AWSIZE(sw_awsize),.CAM_AWBURST(sw_awburst),.CAM_AWVALID(sw_awvalid),.CAM_AWREADY(owner&&parent_awready),.CAM_WDATA(sw_wdata),.CAM_WSTRB(sw_wstrb),.CAM_WLAST(sw_wlast),.CAM_WVALID(sw_wvalid),.CAM_WREADY(owner&&parent_wready),.CAM_BRESP(parent_bresp),.CAM_BVALID(owner&&parent_bvalid),.CAM_BREADY(sw_bready));
 ordinary_trusted_nfr_letterbox_parent_replay_observe original_parent(
  .diagnostic_failure_now(diagnostic_failure_now),.diagnostic_state(diagnostic_state),
  .diagnostic_bridge_failure_now(diagnostic_bridge_failure_now),.diagnostic_bridge_state(diagnostic_bridge_state),
  .clk(clk),
  .rst_n(rst_n),
  .cancel(cancel),
  .authorized(authorized),
  .key_valid(key_valid),
  .authorization_epoch(authorization_epoch),
  .frame_begin(owner?src_bind:frame_begin),
  .frame_begin_ready(parent_begin_ready),
  .trusted_session(owner?replay_exec_session:trusted_session),
  .trusted_frame(owner?replay_exec_frame:trusted_frame),
  .trusted_epoch(owner?replay_exec_epoch:trusted_epoch),
  .producer_frame_ready(owner?src_loaded:producer_frame_ready),
  .producer_session(owner?replay_exec_session:producer_session),
  .producer_frame(owner?replay_exec_frame:producer_frame),
  .producer_cancel(producer_cancel),
  .frame_ready(frame_ready),
  .quiescent(quiescent),
  .failed(failed),
  .result_session(result_session),
  .result_frame(result_frame),
  .result_epoch(result_epoch),
  .output_committed_bytes(output_committed_bytes),
  .CAM_AWADDR(owner?sw_awaddr:CAM_AWADDR),
  .CAM_AWLEN(owner?sw_awlen:CAM_AWLEN),
  .CAM_AWSIZE(owner?sw_awsize:CAM_AWSIZE),
  .CAM_AWBURST(owner?sw_awburst:CAM_AWBURST),
  .CAM_AWVALID(owner?sw_awvalid:CAM_AWVALID),
  .CAM_AWREADY(parent_awready),
  .CAM_WDATA(owner?sw_wdata:CAM_WDATA),
  .CAM_WSTRB(owner?sw_wstrb:CAM_WSTRB),
  .CAM_WLAST(owner?sw_wlast:CAM_WLAST),
  .CAM_WVALID(owner?sw_wvalid:CAM_WVALID),
  .CAM_WREADY(parent_wready),
  .CAM_BRESP(parent_bresp),
  .CAM_BVALID(parent_bvalid),
  .CAM_BREADY(owner?sw_bready:CAM_BREADY),
  .PS_AWADDR(PS_AWADDR),
  .PS_AWVALID(PS_AWVALID),
  .PS_AWREADY(PS_AWREADY),
  .PS_WDATA(PS_WDATA),
  .PS_WSTRB(PS_WSTRB),
  .PS_WVALID(PS_WVALID),
  .PS_WREADY(PS_WREADY),
  .PS_BRESP(PS_BRESP),
  .PS_BVALID(PS_BVALID),
  .PS_BREADY(PS_BREADY),
  .PS_ARADDR(PS_ARADDR),
  .PS_ARVALID(PS_ARVALID),
  .PS_ARREADY(PS_ARREADY),
  .PS_RDATA(PS_RDATA),
  .PS_RRESP(PS_RRESP),
  .PS_RVALID(PS_RVALID),
  .PS_RREADY(PS_RREADY),
  .request_valid(request_valid),
  .request_ready(request_ready),
  .request_write(request_write),
  .request_session(request_session),
  .request_frame(request_frame),
  .request_epoch(request_epoch),
  .request_version(request_version),
  .request_role(request_role),
  .request_shape(request_shape),
  .request_address(request_address),
  .request_tensor_mask(request_tensor_mask),
  .request_strobe(request_strobe),
  .request_data(request_data),
  .response_valid(response_valid),
  .response_ready(response_ready),
  .response_error(response_error),
  .guard_context_live(guard_context_live),
  .response_data(response_data),
  .guard_quiescent(guard_quiescent),
  .raw_sealed_valid(raw_sealed_valid),
  .raw_writer_quiet(raw_writer_quiet),
  .raw_committed_bytes(raw_committed_bytes),
  .raw_accepted_bytes(raw_accepted));
 assign diagnostic_raw_accepted_bytes=raw_accepted;
endmodule
