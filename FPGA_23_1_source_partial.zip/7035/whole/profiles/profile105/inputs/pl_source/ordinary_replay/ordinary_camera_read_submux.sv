`timescale 1ns/1ps
// Insert ONLY in the camera-owner read channel BEFORE the existing 3-owner
// stage HP mux. Existing c_AW/W/B and all other owners remain unchanged.
// One read credit, no RAM, no cancel input. Reset is board/AXI reset only.
module ordinary_camera_read_submux #(parameter integer ENABLE_SLOT_REPLAY=0)(
 input wire clk,rst_n,
 input wire[31:0] A_ARADDR,input wire[7:0] A_ARLEN,input wire[2:0] A_ARSIZE,input wire[1:0] A_ARBURST,
 input wire A_ARVALID,output wire A_ARREADY,
 output wire[255:0] A_RDATA,output wire[1:0] A_RRESP,output wire A_RLAST,A_RVALID,input wire A_RREADY,
 input wire A_quiescent,
 input wire[31:0] B_ARADDR,input wire[7:0] B_ARLEN,input wire[2:0] B_ARSIZE,input wire[1:0] B_ARBURST,
 input wire B_ARVALID,output wire B_ARREADY,
 output wire[255:0] B_RDATA,output wire[1:0] B_RRESP,output wire B_RLAST,B_RVALID,input wire B_RREADY,
 output wire[31:0] M_ARADDR,output wire[7:0] M_ARLEN,output wire[2:0] M_ARSIZE,output wire[1:0] M_ARBURST,
 output wire M_ARVALID,input wire M_ARREADY,
 input wire[255:0] M_RDATA,input wire[1:0] M_RRESP,input wire M_RLAST,M_RVALID,output wire M_RREADY,
 output wire quiescent,output wire fault
);
 generate if(ENABLE_SLOT_REPLAY==0)begin:legacy
  assign M_ARADDR=A_ARADDR;assign M_ARLEN=A_ARLEN;assign M_ARSIZE=A_ARSIZE;assign M_ARBURST=A_ARBURST;
  assign M_ARVALID=A_ARVALID;assign A_ARREADY=M_ARREADY;
  assign A_RDATA=M_RDATA;assign A_RRESP=M_RRESP;assign A_RLAST=M_RLAST;assign A_RVALID=M_RVALID;assign M_RREADY=A_RREADY;
  assign B_ARREADY=0;assign B_RDATA=0;assign B_RRESP=0;assign B_RLAST=0;assign B_RVALID=0;
  assign quiescent=A_quiescent;assign fault=0;
 end else begin:enabled
  localparam IDLE=0,OFFER=1,RETURN_DATA=2;
  reg[1:0] state;reg owner,prefer_b;reg[31:0] address;
  reg[7:0] len;reg[2:0] size;reg[1:0] burst;
  reg[8:0] remaining;reg fault_reg;
  wire select_b=B_ARVALID&&(!A_ARVALID||prefer_b);
  assign A_ARREADY=state==IDLE&&!select_b;
  assign B_ARREADY=state==IDLE&&select_b;
  assign M_ARADDR=address;assign M_ARLEN=len;assign M_ARSIZE=size;assign M_ARBURST=burst;
  assign M_ARVALID=state==OFFER;
  assign A_RDATA=M_RDATA;assign B_RDATA=M_RDATA;
  assign A_RRESP=M_RRESP;assign B_RRESP=M_RRESP;
  assign A_RLAST=M_RLAST;assign B_RLAST=M_RLAST;
  assign A_RVALID=state==RETURN_DATA&&!owner&&M_RVALID;
  assign B_RVALID=state==RETURN_DATA&&owner&&M_RVALID;
  assign M_RREADY=state==RETURN_DATA&&(owner?B_RREADY:A_RREADY);
  assign quiescent=state==IDLE&&!A_ARVALID&&!B_ARVALID;
  assign fault=fault_reg;
  always @(posedge clk)begin
   if(!rst_n)begin state<=IDLE;owner<=0;prefer_b<=0;address<=0;len<=0;size<=0;burst<=0;remaining<=0;fault_reg<=0;end
   else case(state)
    IDLE:if(A_ARVALID||B_ARVALID)begin
     owner<=select_b;address<=select_b?B_ARADDR:A_ARADDR;
     len<=select_b?B_ARLEN:A_ARLEN;size<=select_b?B_ARSIZE:A_ARSIZE;burst<=select_b?B_ARBURST:A_ARBURST;
     remaining<={1'b0,(select_b?B_ARLEN:A_ARLEN)}+1'b1;state<=OFFER;
    end
    OFFER:if(M_ARREADY)state<=RETURN_DATA;
    RETURN_DATA:if(M_RVALID&&M_RREADY)begin
     if(M_RLAST!=(remaining==1))fault_reg<=1;
     // A physical RLAST is the transaction boundary. An inconsistent length
     // is sticky fault, never a valid source completion (clients also check).
     if(M_RLAST)begin state<=IDLE;prefer_b<=!owner;remaining<=0;end
     else if(remaining>1)remaining<=remaining-1;
    end
    default:begin fault_reg<=1;end
   endcase
  end
 end endgenerate
endmodule
