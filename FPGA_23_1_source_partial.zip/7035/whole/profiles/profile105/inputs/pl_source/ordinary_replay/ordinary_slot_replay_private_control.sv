`timescale 1ns/1ps
// Ordinary descriptor/ticket echo. PS offer is NEVER a GO or completion.
// root_grant is a private root-controlled permission; accepted_go uses the
// existing camera root gate/common allocator. No AXIL page is assigned here.
module ordinary_slot_replay_private_control #(parameter integer ENABLE_SLOT_REPLAY=0)(
 input wire clk,rst_n,
 input wire offer_valid,output wire offer_ready,
 input wire[6:0] offer_slot,input wire[63:0] offer_generation,offer_batch,
 input wire offer_held,offer_cache_clean,input wire[31:0] offer_expected_model,input wire offer_cancel,
 input wire root_grant,root_cancel,authorized,key_valid,model_valid,
 input wire[31:0] root_grant_offer_identity,
 output wire[31:0] pending_offer_identity,output wire pending_offer_live,
 input wire[31:0] current_epoch,current_model,input wire[127:0] current_key_session,
 input wire[31:0] next_exec_session,next_exec_frame,
 output wire camera_go_valid,input wire camera_go_ready,
 output wire normal_go_block,
 output reg[6:0] selected_slot,output reg[63:0] selected_generation,selected_batch,
 output reg selected_held,selected_cache_clean,output reg[31:0] selected_expected_model,
 output wire[31:0] selected_token,
 output reg[31:0] execution_session,execution_frame,execution_epoch,execution_model,
 output reg[127:0] execution_key_session,
 output reg execution_accepted,
 output wire camera_stop_requested,
 input wire camera_completion_valid,camera_completion_failed,
 input wire[7:0] camera_error,
 input wire[31:0] completed_token,completed_session,completed_frame,completed_epoch,
 input wire actual_io_drained,
 output wire receipt_valid,output reg receipt_failed,output reg[7:0] receipt_error,
 input wire receipt_ack,input wire[31:0] receipt_ack_token,
 output wire busy,output wire exhausted,output reg[31:0] rejected_late_completion
);
 localparam IDLE=0,PENDING=1,ACTIVE=2,RECEIPT=3;
 reg[1:0] state;reg[31:0] next_token,owned_token;
 reg[31:0] next_offer_identity,owned_offer_identity;
 reg token_exhausted,offer_identity_exhausted;
 // Private POR-lifetime offer identity; ordinary PS metadata remain untrusted.
 assign pending_offer_identity=ENABLE_SLOT_REPLAY!=0&&state==PENDING?owned_offer_identity:32'd0;
 assign pending_offer_live=(ENABLE_SLOT_REPLAY!=0&&state==PENDING&&owned_offer_identity!=0&&!offer_cancel)===1'b1;
 wire grant_identity_matches=(root_grant&&root_grant_offer_identity!=0&&root_grant_offer_identity==owned_offer_identity)===1'b1;
 assign exhausted=token_exhausted||offer_identity_exhausted;
 reg have_execution,terminal_seen,saved_terminal_failed;reg[7:0] saved_terminal_error;
 wire live=authorized&&key_valid&&model_valid&&!root_cancel&&current_epoch!=0&&current_model!=0&&current_key_session!=0;
 wire fresh=!have_execution||current_epoch>execution_epoch||
   (current_epoch==execution_epoch&&next_exec_session>execution_session&&next_exec_frame>execution_frame);
 wire owned_context=execution_epoch==current_epoch&&execution_model==current_model&&execution_key_session==current_key_session;
 wire terminal_matches=completed_token==owned_token&&completed_session==execution_session&&completed_frame==execution_frame&&completed_epoch==execution_epoch;
 assign offer_ready=ENABLE_SLOT_REPLAY!=0&&state==IDLE&&!exhausted;
 assign camera_go_valid=ENABLE_SLOT_REPLAY!=0&&state==PENDING&&pending_offer_live&&grant_identity_matches&&live&&fresh&&selected_expected_model==current_model&&!token_exhausted&&next_exec_session!=0&&next_exec_frame!=0;
 assign selected_token=state==ACTIVE||state==RECEIPT?owned_token:next_token;
 assign normal_go_block=ENABLE_SLOT_REPLAY!=0&&state==ACTIVE;
 assign camera_stop_requested=ENABLE_SLOT_REPLAY!=0&&state==ACTIVE&&(!live||!owned_context);
 assign receipt_valid=ENABLE_SLOT_REPLAY!=0&&state==RECEIPT;
 assign busy=ENABLE_SLOT_REPLAY!=0&&state!=IDLE;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;next_token<=1;owned_token<=0;have_execution<=0;terminal_seen<=0;saved_terminal_failed<=0;saved_terminal_error<=0;token_exhausted<=0;execution_accepted<=0;
   next_offer_identity<=1;owned_offer_identity<=0;offer_identity_exhausted<=0;
   selected_slot<=0;selected_generation<=0;selected_batch<=0;selected_held<=0;selected_cache_clean<=0;selected_expected_model<=0;
   execution_session<=0;execution_frame<=0;execution_epoch<=0;execution_model<=0;execution_key_session<=0;
   receipt_failed<=0;receipt_error<=0;rejected_late_completion<=0;
  end else if(ENABLE_SLOT_REPLAY!=0)begin
   execution_accepted<=0;
   if(camera_completion_valid&&!(state==ACTIVE&&terminal_matches))begin
    if(rejected_late_completion!=32'hffffffff)rejected_late_completion<=rejected_late_completion+1'b1;
   end
   case(state)
    IDLE:if(offer_valid&&offer_ready)begin
     owned_offer_identity<=next_offer_identity;
     if(next_offer_identity==32'hffffffff)offer_identity_exhausted<=1;
     else next_offer_identity<=next_offer_identity+1'b1;
     selected_slot<=offer_slot;selected_generation<=offer_generation;selected_batch<=offer_batch;
     selected_held<=offer_held;selected_cache_clean<=offer_cache_clean;selected_expected_model<=offer_expected_model;receipt_failed<=0;receipt_error<=0;
     if(offer_slot<1||offer_slot>100||!offer_generation||!offer_batch||!offer_held||!offer_cache_clean||!offer_expected_model)begin
      // No accepted root job and no IO; rejected metadata is not a class.
      owned_token<=0;receipt_failed<=1;receipt_error<=1;state<=RECEIPT;
     end else state<=PENDING;
    end
    PENDING:if(offer_cancel)begin owned_offer_identity<=0;state<=IDLE;end
     else if(camera_go_valid&&camera_go_ready)begin
      owned_token<=next_token;
      if(next_token==32'hffffffff)token_exhausted<=1;else next_token<=next_token+1;
      execution_session<=next_exec_session;execution_frame<=next_exec_frame;execution_epoch<=current_epoch;
      execution_model<=current_model;execution_key_session<=current_key_session;
      have_execution<=1;execution_accepted<=1;terminal_seen<=0;state<=ACTIVE;
     end
    ACTIVE:begin
     // Capture a one-cycle physical terminal; a later unrelated/late value
     // cannot replace it while the final accepted-tail fence is still busy.
     if(camera_completion_valid&&terminal_matches&&!terminal_seen)begin
      terminal_seen<=1;saved_terminal_failed<=camera_completion_failed;saved_terminal_error<=camera_error;
     end
     if((terminal_seen||(camera_completion_valid&&terminal_matches))&&actual_io_drained)begin
      receipt_failed<=(terminal_seen?saved_terminal_failed:camera_completion_failed)||!live||!owned_context;
      receipt_error<=(terminal_seen?saved_terminal_failed:camera_completion_failed)?
        (terminal_seen?saved_terminal_error:camera_error):(!live||!owned_context?8'd2:8'd0);
      state<=RECEIPT;
     end
    end
    RECEIPT:if(receipt_ack&&receipt_ack_token==owned_token)state<=IDLE;
    default:begin end
   endcase
  end
 end
endmodule
