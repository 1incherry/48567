`timescale 1ns/1ps
// Production 640-only ingress. All control/context ports belong to trusted PL.
// Packet ports connect to nfr_packet_rx/control_tx, not to PS-controlled memory.
// No inference completion, address, shape, epoch or GO register is exposed here.
module ordinary_trusted_camera_frame_job_slot_replay #(parameter EXTERNAL_TUPLES=0,parameter CONTINUOUS_RAW_WIRE=0,parameter ENABLE_ORDINARY_SLOT_REPLAY=0)(
 input wire external_nn_admit,external_owner_opened,input wire[31:0] external_next_session,external_next_frame,
 output wire observation_capture_start,
 output wire [31:0] observation_next_session,observation_next_frame,output wire observation_next_exhausted,
 input wire clk,rst_n,authorized,key_valid,input wire [31:0] authorization_epoch,
 input wire trusted_go,trusted_stop,output wire go_ready,active,fault,quiescent,
 input wire packet_valid,input wire [383:0] packet_header,output wire packet_release,
 output wire payload_read,output wire [9:0] payload_address,
 input wire [7:0] payload_data,input wire payload_read_valid,
 output wire response_valid,input wire response_ready,output wire [7:0] response_kind,response_flags,
 output wire [31:0] response_offset,response_frame_crc,response_session_id,response_frame_id,response_total_bytes,
 output wire [15:0] response_width,response_height,
 output wire job_valid,input wire job_ready,output wire [31:0] job_session,job_frame,job_epoch,job_base,
 input wire job_done,input wire [31:0] job_done_session,job_done_frame,
 output wire job_cancel,input wire job_quiescent,job_fault,
 output wire sealed_letterbox_valid,output wire [31:0] sealed_session,sealed_frame,sealed_epoch,
 output wire [31:0] completed_frames,rejected_completions,committed_offset,received_crc,
 output wire request_valid,input wire request_ready,output wire request_write,
 output wire [31:0] request_session,request_frame,request_epoch,request_version,
 output wire [15:0] request_role,request_shape,
 output wire [31:0] request_address,request_tensor_mask,request_strobe,output wire [255:0] request_data,
 input wire response_verified_valid,output wire response_verified_ready,input wire response_error,guard_context_live,
 input wire [255:0] response_data,input wire guard_quiescent,
 output wire observation_native_slot_ready,
 input wire external_raw_consume,
 output wire observation_raw_sealed,observation_raw_writer_quiet,observation_raw_frame_ready,observation_raw_transport_idle,
 output wire[31:0] observation_raw_rgb_committed,observation_capture_session,observation_capture_frame,
 // Private root-controlled mode is sampled ONLY on real trusted_go&&go_ready.
 // An ordinary PS ticket is NOT a GO. No new public AXI control is exposed here.
 input wire trusted_replay_mode,input wire[6:0] replay_offer_slot,
 input wire[63:0] replay_offer_generation,replay_offer_batch,
 input wire replay_offer_held,replay_offer_cache_clean,input wire[31:0] trusted_replay_token,
 input wire[31:0] current_model,input wire[127:0] current_key_session,
 input wire replay_ingress_io_drained,
 output wire replay_completion_valid,replay_completion_failed,output wire[7:0] replay_error,
 output wire[31:0] replay_result_token,replay_result_session,replay_result_frame,replay_result_epoch,
 output wire[31:0] SLOT_ARADDR,output wire[7:0] SLOT_ARLEN,output wire[2:0] SLOT_ARSIZE,output wire[1:0] SLOT_ARBURST,
 output wire SLOT_ARVALID,input wire SLOT_ARREADY,input wire[63:0] SLOT_RDATA,input wire[1:0] SLOT_RRESP,
 input wire SLOT_RLAST,SLOT_RVALID,output wire SLOT_RREADY
,
 output wire[223:0] observation_camera_first_cause
,
 output wire[383:0] observation_raw_diagnostic_words
);

 // Pure net/register declarations precede all references for strict SV compilation.

 // Private, read-only diagnostic latch. Never drives admission, cancel, ACK or data.
 wire[7:0]diag_raw_bad,diag_raw_state,diag_bridge_bad,diag_bridge_state;
 wire[7:0]diag_parent_bad,diag_parent_state,diag_coord_bad,diag_coord_state;
 reg diag_capture_started,diag_armed,diag_valid;
 wire[31:0]diag_raw_accepted;
 wire[31:0]diag_effective_causes={diag_coord_bad,
  ((diag_capture_started||observation_capture_start)?diag_parent_bad:8'd0),
  ((diag_capture_started||observation_capture_start)?diag_bridge_bad:8'd0),
  ((diag_capture_started||observation_capture_start)?diag_raw_bad:8'd0)};
 reg[223:0]diag_latched;

 reg slot_mode_reg,slot_terminal_drained;
 reg [6:0] saved_slot;
 reg [63:0] saved_generation,saved_batch;
 reg saved_held,saved_clean;
 reg [31:0] saved_replay_token;
 wire slot_mode;
 wire replay_start_ready,replay_owner,replay_retire_ready;
 wire [31:0] replay_exec_session,replay_exec_frame,replay_exec_epoch,replay_srcbytes,replay_bbytes;
 wire virtual_sink_busy;
 wire virtual_sink_start_ready;
 wire virtual_sink_fault;
 wire coordinator_native_ready;
 wire coordinator_ready,coordinator_active,coordinator_fault,sink_start,sink_cancel,sink_consume_done;
 wire raw_start_ready,raw_busy,raw_ready,raw_fault,capture_ready,capture_quiet,capture_failed,producer_cancel;
 wire [31:0] session_id,frame_id,raw_frame,raw_base,raw_session,raw_frame_id,raw_total;
 wire [15:0] raw_width,raw_height;
 wire [7:0] raw_flags;
 wire unused_profile,unused_pattern,unused_bank,unused_display;
 wire [31:0] unused_display_base,unused_display_seq,letterbox_bytes;
 wire ca_valid,cw_valid,cw_last,cb_ready,ca_ready,cw_ready,cb_valid;
 wire [31:0] ca_addr;
 wire [7:0] ca_len,cw_strb;
 wire [2:0] ca_size;
 wire [1:0] ca_burst,cb_resp;
 wire [63:0] cw_data;
 wire bound;
 wire coordinator_job_valid;
 wire capture_begin_ready;
 // This block does not grant a job. The original accepted coordinator still
 // allocates its genuine fresh S/F, waits for actual letterbox seal, and only
 // admits the original NN consumer through bound/job_valid.




 assign replay_result_session=replay_exec_session;
 assign replay_result_frame=replay_exec_frame;
 assign replay_result_epoch=replay_exec_epoch;
 assign slot_mode=ENABLE_ORDINARY_SLOT_REPLAY!=0&&slot_mode_reg;



 assign virtual_sink_busy=slot_mode?replay_owner:raw_busy;

 assign virtual_sink_start_ready=slot_mode?replay_start_ready:
   (raw_start_ready&&capture_begin_ready&&authorized&&key_valid&&(!EXTERNAL_TUPLES||external_owner_opened));

 assign virtual_sink_fault=slot_mode?(replay_completion_failed||capture_failed):(raw_fault||capture_failed);
 always @(posedge clk)begin
  if(!rst_n)begin slot_mode_reg<=0;slot_terminal_drained<=0;saved_slot<=0;saved_generation<=0;saved_batch<=0;saved_held<=0;saved_clean<=0;saved_replay_token<=0;end
  else begin
   if(trusted_go&&go_ready)begin
    slot_mode_reg<=ENABLE_ORDINARY_SLOT_REPLAY!=0&&trusted_replay_mode;
    saved_slot<=replay_offer_slot;saved_generation<=replay_offer_generation;saved_batch<=replay_offer_batch;
    saved_held<=replay_offer_held;saved_clean<=replay_offer_cache_clean;saved_replay_token<=trusted_replay_token;
    slot_terminal_drained<=0;
   end
   if(replay_completion_valid)slot_terminal_drained<=1;
  end
 end




 // Read-only actual accepted capture event; does not alter the ingress FSM.




 assign observation_capture_session=session_id;assign observation_capture_frame=frame_id;
 assign observation_raw_frame_ready=slot_mode?observation_raw_sealed:raw_ready;
 assign observation_raw_transport_idle=slot_mode?(slot_terminal_drained||(observation_raw_sealed&&observation_raw_writer_quiet&&replay_ingress_io_drained)):(raw_start_ready&&!raw_busy&&!response_valid);

 assign observation_next_session=EXTERNAL_TUPLES?external_next_session:session_id+32'd1;
 assign observation_next_frame=EXTERNAL_TUPLES?external_next_frame:frame_id+32'd1;
 assign observation_next_exhausted=EXTERNAL_TUPLES?(external_next_session==0||external_next_frame==0):(session_id==32'hffffffff||frame_id==32'hffffffff);
 assign observation_capture_start=slot_mode?(sink_start&&replay_start_ready&&authorized&&key_valid):(sink_start&&raw_start_ready&&capture_begin_ready&&authorized&&key_valid);





 assign bound=capture_ready&&sealed_session==session_id&&sealed_frame==frame_id&&
   sealed_epoch==authorization_epoch&&letterbox_bytes==307200&&authorized&&key_valid;

 assign observation_native_slot_ready=coordinator_native_ready&&capture_quiet&&authorized&&key_valid&&!trusted_stop;
 assign go_ready=coordinator_ready&&capture_quiet&&authorized&&key_valid&&!trusted_stop;
 assign active=coordinator_active;
 assign fault=coordinator_fault||capture_failed;
 assign quiescent=!coordinator_active&&!virtual_sink_busy&&capture_quiet&&job_quiescent&&guard_quiescent;
 assign job_valid=coordinator_job_valid&&bound;
 assign sealed_letterbox_valid=bound;
 assign job_epoch=sealed_epoch;
 ordinary_nfr_frame_coordinator #(.EXTERNAL_TUPLES(EXTERNAL_TUPLES)) coordinator(
  .diagnostic_failure_now(diag_coord_bad),.diagnostic_state(diag_coord_state),
  .native_slot_ready(coordinator_native_ready),
  .external_tuple_valid(external_nn_admit),.external_next_session(external_next_session),.external_next_frame(external_next_frame),
  .clk(clk),.rst_n(rst_n),.go(trusted_go&&go_ready),.stop(trusted_stop),
  .profile1080(1'b0),.pattern(1'b0),.repeat_frames(1'b0),
  .go_ready(coordinator_ready),.active(coordinator_active),.fault(coordinator_fault),
  .sink_start(sink_start),.sink_cancel(sink_cancel),.sink_consume_done(sink_consume_done),
  .sink_start_ready(virtual_sink_start_ready),
  .sink_busy(virtual_sink_busy||!capture_quiet),.sink_ready(bound),.sink_fault(virtual_sink_fault),
  .sink_profile1080(unused_profile),.sink_pattern(unused_pattern),.sink_display_bank(unused_bank),
  .session_id(session_id),.frame_id(frame_id),.sink_frame(slot_mode?frame_id:raw_frame),.sink_base(slot_mode?32'h22000000:raw_base),
  .job_valid(coordinator_job_valid),.job_ready(job_ready&&bound),.job_session(job_session),.job_frame(job_frame),.job_base(job_base),
  // Revoke/STOP and completion may arrive on the same edge. The diagnostic
  // coordinator retains its old behavior; this production fence must prevent
  // even its success counter from accepting an already-invalid completion.
  .job_done(job_done&&bound&&!trusted_stop&&!job_fault),.job_done_session(job_done_session),.job_done_frame(job_done_frame),
  .job_cancel(job_cancel),.job_quiescent(job_quiescent&&capture_quiet&&guard_quiescent),.job_fault(job_fault),
  .rejected_completions(rejected_completions),.completed_frames(completed_frames),
  .display_enable(unused_display),.display_base(unused_display_base),.display_seq(unused_display_seq),
  .display_ack_seq(32'd0),.display_active_base(32'd0),.display_fault(1'b0));
 nfr_frame_sink #(.TIMEOUT_CYCLES(32'd1500000000)) sink(
  .diagnostic_words(observation_raw_diagnostic_words),.diagnostic_failure_now(diag_raw_bad),.diagnostic_state(diag_raw_state),
  .clk(clk),.rst_n(rst_n),.start(sink_start&&!slot_mode),.cancel(sink_cancel||producer_cancel),.consume_done(sink_consume_done||(CONTINUOUS_RAW_WIRE!=0&&external_raw_consume===1'b1)),
  .profile1080(1'b1),.pattern(1'b0),.display_bank(1'b0),.request_session(session_id),.request_frame(frame_id),
  .start_ready(raw_start_ready),.busy(raw_busy),.frame_ready(raw_ready),.fault(raw_fault),
  .completed_frame(raw_frame),.committed_offset(committed_offset),.received_crc(received_crc),.frame_base(raw_base),
  .packet_valid(packet_valid),.packet_header(packet_header),.packet_release(packet_release),
  .payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
  .response_valid(response_valid),.response_ready(response_ready),.response_kind(response_kind),.response_offset(response_offset),.response_frame_crc(response_frame_crc),
  .response_session_id(response_session_id),.response_frame_id(response_frame_id),.response_total_bytes(response_total_bytes),
  .response_width(response_width),.response_height(response_height),.response_flags(response_flags),
  .session_id(raw_session),.frame_id(raw_frame_id),.total_bytes(raw_total),.width(raw_width),.height(raw_height),.flags(raw_flags),
  .m_awaddr(ca_addr),.m_awlen(ca_len),.m_awsize(ca_size),.m_awburst(ca_burst),.m_awvalid(ca_valid),.m_awready(ca_ready),
  .m_wdata(cw_data),.m_wstrb(cw_strb),.m_wlast(cw_last),.m_wvalid(cw_valid),.m_wready(cw_ready),
  .m_bresp(cb_resp),.m_bvalid(cb_valid),.m_bready(cb_ready));
 ordinary_nfr_or_slot_letterbox_parent #(.ENABLE_ORDINARY_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY)) capture(
  .diagnostic_raw_accepted_bytes(diag_raw_accepted),
  .diagnostic_failure_now(diag_parent_bad),.diagnostic_state(diag_parent_state),
  .diagnostic_bridge_failure_now(diag_bridge_bad),.diagnostic_bridge_state(diag_bridge_state),
  .clk(clk),.rst_n(rst_n),.cancel(sink_cancel),.authorized(authorized),.key_valid(key_valid),.authorization_epoch(authorization_epoch),
  .frame_begin(sink_start&&!slot_mode),.frame_begin_ready(capture_begin_ready),.trusted_session(session_id),.trusted_frame(frame_id),.trusted_epoch(authorization_epoch),
  .producer_frame_ready(raw_ready),.producer_session(raw_session),.producer_frame(raw_frame),
  .producer_cancel(producer_cancel),.frame_ready(capture_ready),.quiescent(capture_quiet),.failed(capture_failed),
  .result_session(sealed_session),.result_frame(sealed_frame),.result_epoch(sealed_epoch),.output_committed_bytes(letterbox_bytes),
  .CAM_AWADDR(ca_addr),.CAM_AWLEN(ca_len),.CAM_AWSIZE(ca_size),.CAM_AWBURST(ca_burst),.CAM_AWVALID(ca_valid),.CAM_AWREADY(ca_ready),
  .CAM_WDATA(cw_data),.CAM_WSTRB(cw_strb),.CAM_WLAST(cw_last),.CAM_WVALID(cw_valid),.CAM_WREADY(cw_ready),.CAM_BRESP(cb_resp),.CAM_BVALID(cb_valid),.CAM_BREADY(cb_ready),
  .PS_AWADDR(32'd0),.PS_AWVALID(1'b0),.PS_AWREADY(),.PS_WDATA(32'd0),.PS_WSTRB(4'd0),.PS_WVALID(1'b0),.PS_WREADY(),.PS_BRESP(),.PS_BVALID(),.PS_BREADY(1'b1),
  .PS_ARADDR(32'd0),.PS_ARVALID(1'b0),.PS_ARREADY(),.PS_RDATA(),.PS_RRESP(),.PS_RVALID(),.PS_RREADY(1'b1),
  .request_valid(request_valid),.request_ready(request_ready),.request_write(request_write),
  .request_session(request_session),.request_frame(request_frame),.request_epoch(request_epoch),.request_version(request_version),
  .request_role(request_role),.request_shape(request_shape),.request_address(request_address),.request_tensor_mask(request_tensor_mask),.request_strobe(request_strobe),.request_data(request_data),
  .response_valid(response_verified_valid),.response_ready(response_verified_ready),.response_error(response_error),.guard_context_live(guard_context_live),.response_data(response_data),.guard_quiescent(guard_quiescent),
  .raw_sealed_valid(observation_raw_sealed),.raw_writer_quiet(observation_raw_writer_quiet),.raw_committed_bytes(observation_raw_rgb_committed),
  .replay_start_valid(slot_mode&&sink_start),.replay_start_ready(replay_start_ready),
  .replay_slot(saved_slot),.replay_generation(saved_generation),.replay_batch(saved_batch),.replay_slot_held(saved_held),.replay_cache_clean(saved_clean),
  .replay_token(saved_replay_token),.replay_session(session_id),.replay_frame(frame_id),.replay_epoch(authorization_epoch),
  .current_model(current_model),.current_key_session(current_key_session),.ingress_io_drained(replay_ingress_io_drained),
  // RELEASE is reached ONLY after the original matching NN job_done. This
  // is deliberately not ordinary_actual_retired (which waits for this owner).
  .replay_retire_valid(slot_mode&&sink_consume_done),.replay_retire_token(saved_replay_token),
  .replay_retire_session(session_id),.replay_retire_frame(frame_id),.replay_retire_epoch(authorization_epoch),.replay_retire_ready(replay_retire_ready),
  .replay_completion_valid(replay_completion_valid),.replay_completion_ready(1'b1),.replay_completion_failed(replay_completion_failed),.replay_error(replay_error),.replay_owner(replay_owner),
  .replay_exec_token(replay_result_token),.replay_exec_session(replay_exec_session),.replay_exec_frame(replay_exec_frame),.replay_exec_epoch(replay_exec_epoch),
  .replay_source_bytes(replay_srcbytes),.replay_write_response_bytes(replay_bbytes),
  .SLOT_ARADDR(SLOT_ARADDR),.SLOT_ARLEN(SLOT_ARLEN),.SLOT_ARSIZE(SLOT_ARSIZE),.SLOT_ARBURST(SLOT_ARBURST),.SLOT_ARVALID(SLOT_ARVALID),.SLOT_ARREADY(SLOT_ARREADY),
  .SLOT_RDATA(SLOT_RDATA),.SLOT_RRESP(SLOT_RRESP),.SLOT_RLAST(SLOT_RLAST),.SLOT_RVALID(SLOT_RVALID),.SLOT_RREADY(SLOT_RREADY));
 always@(posedge clk)begin
  if(!rst_n)begin diag_capture_started<=0;diag_armed<=0;diag_valid<=0;diag_latched<=0;end
  else if(trusted_go&&go_ready)begin
   diag_capture_started<=0;diag_armed<=1;diag_valid<=0;diag_latched<=0;
  end else begin
   if(observation_capture_start)diag_capture_started<=1;
   if(diag_armed&&!diag_valid&&(|diag_effective_causes))begin
    diag_valid<=1;
    diag_latched<={frame_id,session_id,committed_offset,diag_raw_accepted,observation_raw_rgb_committed,
      diag_coord_state,diag_parent_state,diag_bridge_state,diag_raw_state,diag_effective_causes};
   end
  end
 end
 assign observation_camera_first_cause=diag_valid?diag_latched:224'd0;

endmodule
