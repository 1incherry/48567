`timescale 1ns/1ps
// Ordinary, cooperative PS storage source. This does NOT authenticate the
// archived image, allocate an NN job, assert RAW seal or publish a class.
// start_valid must be driven ONLY by a real accepted root NN job's private
// source-mode grant. PS fields are offered metadata, never the grant itself.
module ordinary_history_slot_raw_source #(
 parameter integer FRAME_BYTES=921600,
 parameter [31:0] HISTORY_BASE=32'h02400000,
 parameter [31:0] RAW_BASE=32'h22000000,
 parameter [63:0] TIMEOUT_CYCLES=64'd500000000
)(
 input wire clk,rst_n,cancel,authorized,key_valid,
 input wire [31:0] current_epoch,current_model,
 input wire [127:0] current_key_session,
 input wire start_valid,output wire start_ready,
 input wire [6:0] start_slot,
 input wire [63:0] start_slot_generation,start_batch,
 input wire start_slot_held,start_cache_clean,
 input wire [31:0] start_token,start_session,start_frame,start_epoch,
 // Same existing parent frame_begin / original CAM writer, no duplicate guard.
 output wire bind_valid,input wire bind_ready,
 output reg [31:0] exec_token,exec_session,exec_frame,exec_epoch,exec_model,
 output reg [127:0] exec_key_session,
 output reg [6:0] owned_slot,
 output reg [63:0] owned_generation,owned_batch,
 output wire producer_frame_ready,
 input wire writer_quiet,writer_fault,job_io_drained,
 input wire [31:0] writer_accepted_bytes,writer_committed_bytes,
 input wire retire_valid,
 input wire [31:0] retire_token,retire_session,retire_frame,retire_epoch,
 output wire retire_ready,
 output wire completion_valid,input wire completion_ready,
 output reg completion_failed,output reg [7:0] error_code,
 output wire busy,quiescent,
 output reg [31:0] source_bytes,write_response_bytes,
 // One outstanding, four-beat AXI64 read; never withdraw an offered AR.
 output wire [31:0] M_ARADDR,output wire [7:0] M_ARLEN,
 output wire [2:0] M_ARSIZE,output wire [1:0] M_ARBURST,
 output wire M_ARVALID,input wire M_ARREADY,
 input wire [63:0] M_RDATA,input wire [1:0] M_RRESP,
 input wire M_RLAST,M_RVALID,output wire M_RREADY,
 // Mux these into the ONE pre-existing CAM bridge only while this source owns it.
 output wire [31:0] CAM_AWADDR,output wire [7:0] CAM_AWLEN,
 output wire [2:0] CAM_AWSIZE,output wire [1:0] CAM_AWBURST,
 output wire CAM_AWVALID,input wire CAM_AWREADY,
 output wire [63:0] CAM_WDATA,output wire [7:0] CAM_WSTRB,
 output wire CAM_WLAST,CAM_WVALID,input wire CAM_WREADY,
 input wire [1:0] CAM_BRESP,input wire CAM_BVALID,output wire CAM_BREADY
);
 localparam IDLE=0,BIND=1,AR=2,READ=3,AW=4,WRITE=5,BRESP=6,CHECK=7,HOLD=8,DRAIN=9,REPLY=10;
 reg [3:0] state;
 reg aborted;
 reg [31:0] source_base,offset;
 reg [255:0] block_data;
 reg [8:0] read_beat;
 reg [1:0] write_beat;
 reg [63:0] ticks;
 wire live=authorized&&key_valid&&!cancel&&current_epoch==exec_epoch&&
   current_model==exec_model&&current_key_session==exec_key_session;
 wire timed=TIMEOUT_CYCLES!=0&&ticks>=TIMEOUT_CYCLES;
 wire ingest=state>=BIND&&state<=CHECK;
 wire abort_now=!live||timed||(state>=AR&&state<=CHECK&&writer_fault);
 wire retire_matches=retire_token==exec_token&&retire_session==exec_session&&
   retire_frame==exec_frame&&retire_epoch==exec_epoch;
 assign start_ready=state==IDLE&&writer_quiet&&job_io_drained;
 assign busy=state!=IDLE;
 // Ownership remains until the real NN retirement or cancel tail and REPLY ACK.
 assign quiescent=(state==IDLE||state==REPLY)&&writer_quiet&&job_io_drained;
 assign bind_valid=state==BIND&&!aborted&&live&&!timed;
 assign producer_frame_ready=state==HOLD&&!aborted&&live;
 assign retire_ready=state==HOLD&&retire_matches;
 assign completion_valid=state==REPLY;
 assign M_ARADDR=source_base+offset;assign M_ARLEN=3;assign M_ARSIZE=3;assign M_ARBURST=1;
 assign M_ARVALID=state==AR;assign M_RREADY=state==READ;
 assign CAM_AWADDR=RAW_BASE+offset;assign CAM_AWLEN=3;assign CAM_AWSIZE=3;assign CAM_AWBURST=1;
 assign CAM_AWVALID=state==AW;
 assign CAM_WDATA=block_data[write_beat*64+:64];assign CAM_WSTRB=8'hff;
 assign CAM_WLAST=write_beat==3;assign CAM_WVALID=state==WRITE;
 assign CAM_BREADY=state==BRESP;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;aborted<=0;completion_failed<=0;error_code<=0;
   source_base<=0;offset<=0;block_data<=0;read_beat<=0;write_beat<=0;ticks<=0;
   exec_token<=0;exec_session<=0;exec_frame<=0;exec_epoch<=0;exec_model<=0;exec_key_session<=0;
   owned_slot<=0;owned_generation<=0;owned_batch<=0;source_bytes<=0;write_response_bytes<=0;
  end else begin
   if(ingest&&ticks!=64'hffffffffffffffff)ticks<=ticks+1;
   if((ingest||state==HOLD)&&abort_now)begin
    aborted<=1;completion_failed<=1;
    if(error_code==0)error_code<=timed?8'd3:(writer_fault&&state>=AR&&state<=CHECK?8'd4:8'd2);
   end
   case(state)
    IDLE:if(start_valid&&start_ready)begin
     exec_token<=start_token;exec_session<=start_session;exec_frame<=start_frame;exec_epoch<=start_epoch;
     exec_model<=current_model;exec_key_session<=current_key_session;
     owned_slot<=start_slot;owned_generation<=start_slot_generation;owned_batch<=start_batch;
     source_base<=HISTORY_BASE+(start_slot-1)*FRAME_BYTES;
     offset<=0;source_bytes<=0;write_response_bytes<=0;block_data<=0;read_beat<=0;write_beat<=0;ticks<=0;
     aborted<=0;completion_failed<=0;error_code<=0;
     if(start_slot<1||start_slot>100||!start_slot_generation||!start_batch||!start_slot_held||!start_cache_clean||
       !start_token||!start_session||!start_frame||!authorized||!key_valid||cancel||
       !current_epoch||!current_model||current_key_session==0||start_epoch!=current_epoch||
       FRAME_BYTES<=0||FRAME_BYTES%32!=0||HISTORY_BASE[4:0]!=0||RAW_BASE[4:0]!=0||
       {1'b0,HISTORY_BASE}+100*FRAME_BYTES>33'h100000000||{1'b0,RAW_BASE}+FRAME_BYTES>33'h100000000)begin
      aborted<=1;completion_failed<=1;error_code<=1;state<=DRAIN;
     end else state<=BIND;
    end
    BIND:if(aborted||abort_now)state<=DRAIN;
      else if(bind_valid&&bind_ready)begin state<=AR;read_beat<=0;end
    // AR and AW VALID are irrevocable. Revoke still waits for real READY/tails.
    AR:if(M_ARREADY)begin state<=READ;read_beat<=0;end
    READ:if(M_RVALID&&M_RREADY)begin
     if(read_beat<4)block_data[read_beat[1:0]*64+:64]<=M_RDATA;
     if(M_RRESP!=0||M_RLAST!=(read_beat==3))begin
      aborted<=1;completion_failed<=1;if(error_code==0)error_code<=5;
     end
     // An early RLAST is a protocol fault, not permission to drop owed beats.
     // Missing/late RLAST keeps the credit until an actual tail is consumed.
     if(M_RLAST&&read_beat>=3)begin
      if(read_beat==3&&M_RRESP==0)source_bytes<=source_bytes+32;
      if(aborted||abort_now||M_RRESP!=0||read_beat!=3)state<=DRAIN;
      else begin write_beat<=0;state<=AW;end
     end else if(read_beat!=9'h1ff)read_beat<=read_beat+1;
    end
    AW:if(CAM_AWREADY)begin write_beat<=0;state<=WRITE;end
    WRITE:if(CAM_WREADY)begin
     if(write_beat==3)state<=BRESP;else write_beat<=write_beat+1;
    end
    BRESP:if(CAM_BVALID)begin
     if(CAM_BRESP!=0)begin aborted<=1;completion_failed<=1;if(error_code==0)error_code<=6;end
     if(CAM_BRESP==0&&!aborted&&!abort_now)write_response_bytes<=write_response_bytes+32;
     if(aborted||abort_now||CAM_BRESP!=0)state<=DRAIN;
     else if(offset+32==FRAME_BYTES)state<=CHECK;
     else begin offset<=offset+32;read_beat<=0;state<=AR;end
    end
    CHECK:if(aborted||abort_now)state<=DRAIN;
     else if(writer_quiet&&job_io_drained)begin
      if(source_bytes==FRAME_BYTES&&write_response_bytes==FRAME_BYTES&&
         writer_accepted_bytes==FRAME_BYTES&&writer_committed_bytes==FRAME_BYTES)state<=HOLD;
      else begin aborted<=1;completion_failed<=1;error_code<=7;state<=DRAIN;end
     end
    HOLD:if(aborted||abort_now)state<=DRAIN;
      else if(retire_valid&&retire_ready)state<=DRAIN;
    DRAIN:if(writer_quiet&&job_io_drained)state<=REPLY;
    REPLY:if(completion_ready)state<=IDLE;
    default:begin aborted<=1;completion_failed<=1;error_code<=8;state<=DRAIN;end
   endcase
  end
 end
endmodule
