`timescale 1ns/1ps
// Only bus width conversion for the ordinary fixed-slot reader. No hash,
// cipher, model, NN admission or PS control. Reset must be board/AXI reset,
// never an owner-cancel; offered AR and accepted R cannot be abandoned.
module ordinary_replay_read64_to256(
 input wire clk,rst_n,
 input wire[31:0] S_ARADDR,input wire[7:0] S_ARLEN,input wire[2:0] S_ARSIZE,input wire[1:0] S_ARBURST,
 input wire S_ARVALID,output wire S_ARREADY,
 output wire[63:0] S_RDATA,output wire[1:0] S_RRESP,output wire S_RLAST,S_RVALID,input wire S_RREADY,
 output wire[31:0] M_ARADDR,output wire[7:0] M_ARLEN,output wire[2:0] M_ARSIZE,output wire[1:0] M_ARBURST,
 output wire M_ARVALID,input wire M_ARREADY,
 input wire[255:0] M_RDATA,input wire[1:0] M_RRESP,input wire M_RLAST,M_RVALID,output wire M_RREADY,
 output wire quiescent,output reg fault
);
 localparam IDLE=0,OFFER=1,RETURN_DATA=2,SPLIT=3;
 reg[1:0] state,index;reg[8:0] return_left;reg[31:0] address;reg[255:0] data;
 reg[1:0] response;reg have_first,malformed;
 assign S_ARREADY=state==IDLE;
 assign M_ARADDR=address;assign M_ARLEN=0;assign M_ARSIZE=5;assign M_ARBURST=1;
 assign M_ARVALID=state==OFFER;assign M_RREADY=state==RETURN_DATA;
 assign S_RDATA=data[index*64+:64];assign S_RRESP=response;
 assign S_RLAST=state==SPLIT&&return_left==1;assign S_RVALID=state==SPLIT;
 assign quiescent=state==IDLE&&!S_ARVALID;
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;index<=0;return_left<=0;address<=0;data<=0;response<=0;have_first<=0;malformed<=0;fault<=0;end
  else case(state)
   IDLE:if(S_ARVALID&&S_ARREADY)begin
    address<=S_ARADDR;index<=0;return_left<={1'b0,S_ARLEN}+1'b1;data<=0;response<=0;have_first<=0;malformed<=0;
    if(S_ARADDR[4:0]!=0||S_ARLEN!=3||S_ARSIZE!=3||S_ARBURST!=1)begin
     response<=3;fault<=1;state<=SPLIT;
    end else state<=OFFER;
   end
   OFFER:if(M_ARREADY)state<=RETURN_DATA;
   RETURN_DATA:if(M_RVALID&&M_RREADY)begin
    if(!have_first)begin data<=M_RDATA;response<=M_RRESP;have_first<=1;end
    if(M_RRESP!=0)fault<=1;
    if(M_RLAST)begin
     if(malformed||have_first)begin response<=2;fault<=1;end
     state<=SPLIT;index<=0;
    end else begin malformed<=1;fault<=1;end
   end
   SPLIT:if(S_RREADY)begin
    if(return_left==1)begin state<=IDLE;return_left<=0;end
    else begin return_left<=return_left-1;index<=index+1;end
   end
   default:begin fault<=1;end // Retain unknown credit; no synthetic quiet.
  endcase
 end
endmodule
