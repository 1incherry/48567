`timescale 1ns/1ps
// Selection uses the SAME accepted event for camera_go, the private-mode bit,
// and each requester's READY. A waiting private valid cannot relabel a higher
// priority normal root GO. This does not add or bypass a root authorization.
module ordinary_root_go_source_select #(parameter integer ENABLE_SLOT_REPLAY=0)(
 input wire base_camera_go_ready,normal_request_valid,
 input wire private_request_valid,private_active,
 output wire normal_request_ready,private_request_ready,
 output wire camera_go_accepted,private_mode_accepted
);
 generate if(ENABLE_SLOT_REPLAY==0)begin:legacy
  assign normal_request_ready=base_camera_go_ready;
  assign private_request_ready=1'b0;
  assign camera_go_accepted=base_camera_go_ready&&normal_request_valid;
  assign private_mode_accepted=1'b0;
 end else begin:enabled
  wire chosen_normal=normal_request_valid&&!private_active;
  assign normal_request_ready=base_camera_go_ready&&!private_active;
  assign private_request_ready=base_camera_go_ready&&!chosen_normal;
  assign camera_go_accepted=base_camera_go_ready&&(chosen_normal||private_request_valid);
  assign private_mode_accepted=camera_go_accepted&&private_request_valid&&!chosen_normal;
 end endgenerate
endmodule
