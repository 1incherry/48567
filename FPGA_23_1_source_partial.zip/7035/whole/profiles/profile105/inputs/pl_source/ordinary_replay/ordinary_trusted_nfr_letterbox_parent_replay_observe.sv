`timescale 1ns/1ps
// Unique frame owner for ingest->letterbox. All frame controls are trusted PL
// ports. Raw PS AXI-Lite reads/writes always fail and cannot affect ownership.
module ordinary_trusted_nfr_letterbox_parent_replay_observe(
 input wire clk,rst_n,cancel,authorized,key_valid,input wire [31:0] authorization_epoch,
 input wire frame_begin,output wire frame_begin_ready,input wire [31:0] trusted_session,trusted_frame,trusted_epoch,
 input wire producer_frame_ready,input wire [31:0] producer_session,producer_frame,
 output wire producer_cancel,output wire frame_ready,output wire quiescent,
 output reg failed,output wire [31:0] result_session,result_frame,result_epoch,
 output wire [31:0] output_committed_bytes,
 input wire [31:0] CAM_AWADDR,input wire [7:0] CAM_AWLEN,input wire [2:0] CAM_AWSIZE,input wire [1:0] CAM_AWBURST,
 input wire CAM_AWVALID,output wire CAM_AWREADY,input wire [63:0] CAM_WDATA,input wire [7:0] CAM_WSTRB,
 input wire CAM_WLAST,CAM_WVALID,output wire CAM_WREADY,output wire [1:0] CAM_BRESP,output wire CAM_BVALID,input wire CAM_BREADY,
 input wire [31:0] PS_AWADDR,input wire PS_AWVALID,output wire PS_AWREADY,
 input wire [31:0] PS_WDATA,input wire [3:0] PS_WSTRB,input wire PS_WVALID,output wire PS_WREADY,
 output wire [1:0] PS_BRESP,output wire PS_BVALID,input wire PS_BREADY,
 input wire [31:0] PS_ARADDR,input wire PS_ARVALID,output wire PS_ARREADY,
 output wire [31:0] PS_RDATA,output wire [1:0] PS_RRESP,output wire PS_RVALID,input wire PS_RREADY,
 output wire request_valid,input wire request_ready,output wire request_write,
 output wire [31:0] request_session,request_frame,request_epoch,request_version,
 output wire [15:0] request_role,request_shape,
 output wire [31:0] request_address,request_tensor_mask,request_strobe,output wire [255:0] request_data,
 input wire response_valid,output wire response_ready,input wire response_error,guard_context_live,
 input wire [255:0] response_data,input wire guard_quiescent,
 output wire raw_sealed_valid,raw_writer_quiet,output wire[31:0] raw_committed_bytes,raw_accepted_bytes
,
 output wire[7:0] diagnostic_failure_now,diagnostic_state,diagnostic_bridge_failure_now,diagnostic_bridge_state
);
 localparam IDLE=0,INGEST=1,START_LETTER=2,LETTER=3,DRAIN=4,COMPLETE=5,FAULT=6;
 reg [2:0] state;reg owner_letter,aborted,have_context;reg raw_sealed_latched;
 reg [31:0] session_id,frame_id,epoch;
 wire live=authorized&&key_valid&&!cancel&&!aborted&&epoch==authorization_epoch;
 assign result_session=session_id;assign result_frame=frame_id;assign result_epoch=epoch;
 wire cam_active=!owner_letter&&(state==INGEST||state==DRAIN);
 wire cam_quiet,cam_authenticated,cam_fault,cam_context_live,io_quiet,lb_quiet;
 wire ca_ready,cw_ready,cb_valid;wire [1:0] cb_resp;
 wire cr_valid,cr_ready,cr_write,cr_rsp_ready;wire [31:0] cr_addr,cr_mask,cr_strobe;wire [255:0] cr_data;wire [15:0] cr_role,cr_shape;
 wire [31:0] unused_s,unused_f,unused_e,unused_v,ingest_accepted,ingest_committed;
 wire all_quiet=cam_quiet&&io_quiet&&lb_quiet&&guard_quiescent;
 // owner_letter is entered only after authenticated full RAW and all_quiet.
 // Thereafter no camera writer is enabled; unrelated letterbox reads are not
 // RAW-writer activity. No PS or response data controls this seal.
 assign raw_sealed_valid=raw_sealed_latched&&live&&!failed;
 assign raw_writer_quiet=owner_letter?(!CAM_AWVALID&&!CAM_WVALID):cam_quiet;
 assign raw_committed_bytes=ingest_committed;
 assign raw_accepted_bytes=ingest_accepted;
 assign quiescent=(state==IDLE||state==COMPLETE||state==FAULT)&&all_quiet;
 assign frame_begin_ready=quiescent;
 wire accept_frame=frame_begin&&frame_begin_ready;
 wire fresh=!have_context||trusted_epoch>epoch||(trusted_epoch==epoch&&
   (trusted_session>session_id||(trusted_session==session_id&&trusted_frame>frame_id)));
 wire valid_context=authorized&&key_valid&&!cancel&&trusted_session!=0&&trusted_frame!=0&&trusted_epoch==authorization_epoch&&fresh;
 wire bind_frame=accept_frame&&valid_context;
 assign producer_cancel=cancel||((aborted||failed||state==DRAIN||state==FAULT)&&!bind_frame);
 assign CAM_AWREADY=cam_active&&ca_ready;assign CAM_WREADY=cam_active&&cw_ready;
 assign CAM_BVALID=cam_active&&cb_valid;assign CAM_BRESP=cb_resp;
 trusted_nfr_write_auth_bridge camera(
  .diagnostic_failure_now(diagnostic_bridge_failure_now),.diagnostic_state(diagnostic_bridge_state),
  .clk(clk),.rst_n(rst_n),.cancel(producer_cancel),.authorized(authorized),.key_valid(key_valid),.authorization_epoch(authorization_epoch),
  .frame_begin(bind_frame),.frame_begin_ready(),.trusted_session(trusted_session),.trusted_frame(trusted_frame),.trusted_epoch(trusted_epoch),
  .producer_frame_ready(producer_frame_ready),.producer_session(producer_session),.producer_frame(producer_frame),
  .authenticated_frame_ready(cam_authenticated),.quiescent(cam_quiet),.context_live(cam_context_live),.fault(cam_fault),.accepted_bytes(ingest_accepted),.committed_bytes(ingest_committed),
  .S_AXI_AWADDR(CAM_AWADDR),.S_AXI_AWLEN(CAM_AWLEN),.S_AXI_AWSIZE(CAM_AWSIZE),.S_AXI_AWBURST(CAM_AWBURST),.S_AXI_AWVALID(cam_active&&CAM_AWVALID),.S_AXI_AWREADY(ca_ready),
  .S_AXI_WDATA(CAM_WDATA),.S_AXI_WSTRB(CAM_WSTRB),.S_AXI_WLAST(CAM_WLAST),.S_AXI_WVALID(cam_active&&CAM_WVALID),.S_AXI_WREADY(cw_ready),
  .S_AXI_BRESP(cb_resp),.S_AXI_BVALID(cb_valid),.S_AXI_BREADY(cam_active&&CAM_BREADY),
  .request_valid(cr_valid),.request_ready(cr_ready),.request_write(cr_write),.request_session(unused_s),.request_frame(unused_f),.request_epoch(unused_e),.request_version(unused_v),
  .request_role(cr_role),.request_shape(cr_shape),.request_address(cr_addr),.request_tensor_mask(cr_mask),.request_strobe(cr_strobe),.request_data(cr_data),
  .response_valid(!owner_letter&&response_valid),.response_ready(cr_rsp_ready),.response_error(response_error),.guard_context_live(guard_context_live),.guard_quiescent(guard_quiescent));
 wire lb_ready,lb_busy,lb_read,lb_read_ready,lb_pixel,lb_pixel_ready,lb_done,lb_failed;
 wire [31:0] lb_read_address,lb_pixel_address;wire [16:0] lb_index;
 wire [23:0] lb_data;wire qvalid,qverified;wire [95:0] qdata;wire [16:0] qindex;wire [31:0] qs,qf,qe;
 wire io_fault,lr_valid,lr_ready,lr_write,lr_rsp_ready;
 wire [31:0] lr_addr,lr_strobe,lr_mask;wire [255:0] lr_data;wire [15:0] lr_role,lr_shape;
 wire stage_cancel=producer_cancel||io_fault;
 trusted_yolo_letterbox_1080_fixed6 letterbox(.clk(clk),.rst_n(rst_n),.start(state==START_LETTER&&lb_ready&&live),.cancel(stage_cancel),
  .authorized(authorized&&key_valid),.session_id(session_id),.frame_id(frame_id),.epoch(epoch),.authorization_epoch(authorization_epoch),
  .ready(lb_ready),.busy(lb_busy),.quiescent(lb_quiet),.read_valid(lb_read),.read_ready(lb_read_ready),.read_source_address(lb_read_address),.read_pixel_index(lb_index),
  .response_valid(qvalid),.response_verified(qverified),.response_pixel_index(qindex),.response_session(qs),.response_frame(qf),.response_epoch(qe),.response_quad(qdata),
  .pixel_valid(lb_pixel),.pixel_ready(lb_pixel_ready),.pixel_address(lb_pixel_address),.pixel_data(lb_data),
  .memory_quiescent(io_quiet&&guard_quiescent),.write_error(io_fault),.done(lb_done),.failed(lb_failed),.result_session(),.result_frame(),.result_epoch());
 trusted_letterbox_io_native1080 io_path(.clk(clk),.rst_n(rst_n),.bind_frame(bind_frame),.cancel(stage_cancel),.authorized(authorized),.key_valid(key_valid),
  .session_id(session_id),.frame_id(frame_id),.epoch(epoch),.authorization_epoch(authorization_epoch),
  .read_valid(lb_read),.read_ready(lb_read_ready),.read_source_address(lb_read_address),.read_pixel_index(lb_index),
  .quad_valid(qvalid),.quad_verified(qverified),.quad(qdata),.quad_pixel_index(qindex),.quad_session(qs),.quad_frame(qf),.quad_epoch(qe),
  .pixel_valid(lb_pixel),.pixel_ready(lb_pixel_ready),.pixel_address(lb_pixel_address),.pixel_data(lb_data),
  .quiescent(io_quiet),.fault(io_fault),.committed_bytes(output_committed_bytes),
  .request_valid(lr_valid),.request_ready(lr_ready),.request_write(lr_write),.request_address(lr_addr),.request_strobe(lr_strobe),.request_tensor_mask(lr_mask),
  .request_data(lr_data),.request_role(lr_role),.request_shape(lr_shape),
  .response_valid(owner_letter&&response_valid),.response_ready(lr_rsp_ready),.response_error(response_error),.guard_context_live(guard_context_live),.response_data(response_data),.guard_quiescent(guard_quiescent));
 assign request_valid=owner_letter?lr_valid:cr_valid;assign cr_ready=!owner_letter&&request_ready;assign lr_ready=owner_letter&&request_ready;
 assign request_write=owner_letter?lr_write:cr_write;
 assign request_session=session_id;assign request_frame=frame_id;assign request_epoch=epoch;assign request_version=32'd2;
 assign request_address=owner_letter?lr_addr:cr_addr;assign request_strobe=owner_letter?lr_strobe:cr_strobe;
 assign request_tensor_mask=owner_letter?lr_mask:cr_mask;assign request_data=owner_letter?lr_data:cr_data;
 assign request_role=owner_letter?lr_role:cr_role;assign request_shape=owner_letter?lr_shape:cr_shape;
 assign response_ready=owner_letter?lr_rsp_ready:cr_rsp_ready;
 assign frame_ready=state==COMPLETE&&live&&!failed&&output_committed_bytes==307200&&all_quiet;
 // No CPU command, even a partially received AXI-Lite write, has authority.
 reg ps_aw,ps_w,ps_b,ps_r;
 assign PS_AWREADY=!ps_aw&&!ps_b;assign PS_WREADY=!ps_w&&!ps_b;
 assign PS_BVALID=ps_b;assign PS_BRESP=2;assign PS_ARREADY=!ps_r;
 assign PS_RVALID=ps_r;assign PS_RRESP=2;assign PS_RDATA=0;
 always @(posedge clk)begin
  if(!rst_n)begin ps_aw<=0;ps_w<=0;ps_b<=0;ps_r<=0;end
  else begin
   if(PS_AWVALID&&PS_AWREADY)ps_aw<=1;if(PS_WVALID&&PS_WREADY)ps_w<=1;
   if(ps_aw&&ps_w&&!ps_b)begin ps_aw<=0;ps_w<=0;ps_b<=1;end
   if(ps_b&&PS_BREADY)ps_b<=0;
   if(PS_ARVALID&&PS_ARREADY)ps_r<=1;else if(ps_r&&PS_RREADY)ps_r<=0;
  end
 end
 always @(posedge clk)begin
  if(!rst_n)begin raw_sealed_latched<=0;state<=IDLE;owner_letter<=0;aborted<=0;failed<=0;have_context<=0;session_id<=0;frame_id<=0;epoch<=0;end
  else begin
   if(have_context&&(cancel||!authorized||!key_valid||authorization_epoch!=epoch))begin
    aborted<=1;failed<=1;if(state==COMPLETE)state<=FAULT;
   end
   if((state==INGEST||state==START_LETTER||state==LETTER)&&(!live||cam_fault||io_fault))begin aborted<=1;failed<=1;state<=DRAIN;end
   else case(state)
    IDLE,COMPLETE,FAULT:if(accept_frame)begin
     if(valid_context)begin session_id<=trusted_session;frame_id<=trusted_frame;epoch<=trusted_epoch;have_context<=1;
      owner_letter<=0;raw_sealed_latched<=0;aborted<=0;failed<=0;state<=INGEST;end
     else begin failed<=1;aborted<=1;state<=FAULT;end
    end
    INGEST:if(cam_authenticated&&all_quiet)begin raw_sealed_latched<=1;owner_letter<=1;state<=START_LETTER;end
    START_LETTER:if(lb_ready)state<=LETTER;
    LETTER:if(lb_failed)begin failed<=1;aborted<=1;state<=DRAIN;end
     else if(lb_done)begin
      if(output_committed_bytes==307200&&live&&all_quiet)state<=COMPLETE;
      else begin failed<=1;aborted<=1;state<=DRAIN;end
     end
    DRAIN:if(all_quiet)state<=FAULT;
    default:begin failed<=1;aborted<=1;state<=DRAIN;end
   endcase
  end
 end

 assign diagnostic_state={failed,aborted,have_context,owner_letter,1'b0,state};
 assign diagnostic_failure_now={
  (state>FAULT),
  (state==LETTER&&!lb_failed&&lb_done&&!(output_committed_bytes==307200&&live&&all_quiet)),
  (state==LETTER&&lb_failed),
  ((state==IDLE||state==COMPLETE||state==FAULT)&&accept_frame&&!valid_context),
  ((state==INGEST||state==START_LETTER||state==LETTER)&&io_fault),
  ((state==INGEST||state==START_LETTER||state==LETTER)&&cam_fault),
  ((state==INGEST||state==START_LETTER||state==LETTER)&&!live),
  (have_context&&(cancel||!authorized||!key_valid||authorization_epoch!=epoch))};

endmodule
