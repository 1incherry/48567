`timescale 1ns/1ps
// Ordinary metadata only. COMMIT cannot issue camera GO; only the private
// existing VIO provider's explicit op9 can consume an offered slot.
module ordinary_replay_offer_axil #(parameter integer ENABLE=0)(
 input wire clk,rst_n,input wire[11:0]s_awaddr,s_araddr,
 input wire s_awvalid,s_wvalid,s_bready,s_arvalid,s_rready,
 input wire[31:0]s_wdata,input wire[3:0]s_wstrb,
 output wire s_awready,s_wready,s_arready,output reg s_bvalid,s_rvalid,
 output reg[1:0]s_bresp,s_rresp,output reg[31:0]s_rdata,
 output reg offer_valid,input wire offer_ready,output reg[6:0]offer_slot,
 output reg[63:0]offer_generation,offer_batch,
 output reg offer_held,offer_cache_clean,output reg[31:0]offer_expected_model,
 output reg offer_cancel,receipt_ack,output reg[31:0]receipt_ack_token,
 input wire busy,active,receipt_valid,receipt_failed,exhausted,
 input wire[7:0]receipt_error,input wire[6:0]selected_slot,
 input wire[63:0]selected_generation,selected_batch,
 input wire[31:0]token,exec_session,exec_frame,exec_epoch,exec_model,
 input wire[127:0]exec_key,output wire interface_quiet
);
 reg ah,wh;reg[11:0]aw;reg[31:0]wd;reg[3:0]ws;
 wire editable=!busy&&!offer_valid;
 assign s_awready=!ah&&!s_bvalid;assign s_wready=!wh&&!s_bvalid;
 assign s_arready=!s_rvalid;
 // Metadata offers and retained receipts are not physical IO owners.
 assign interface_quiet=!ah&&!wh&&!s_bvalid&&!s_rvalid&&!s_awvalid&&!s_wvalid&&!s_arvalid;
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   ah<=0;wh<=0;aw<=0;wd<=0;ws<=0;s_bvalid<=0;s_rvalid<=0;s_bresp<=0;s_rresp<=0;s_rdata<=0;
   offer_valid<=0;offer_slot<=0;offer_generation<=0;offer_batch<=0;offer_held<=0;offer_cache_clean<=0;offer_expected_model<=0;
   offer_cancel<=0;receipt_ack<=0;receipt_ack_token<=0;
  end else begin
   offer_cancel<=0;receipt_ack<=0;
   if(offer_valid&&offer_ready)offer_valid<=0;
   if(s_awvalid&&s_awready)begin ah<=1;aw<=s_awaddr;end
   if(s_wvalid&&s_wready)begin wh<=1;wd<=s_wdata;ws<=s_wstrb;end
   if(s_bvalid&&s_bready)s_bvalid<=0;
   if(ah&&wh&&!s_bvalid)begin
    ah<=0;wh<=0;s_bvalid<=1;s_bresp<=2;
    if(ENABLE!=0&&ws==15&&aw[1:0]==0)begin
     case(aw)
      12'h010:if(editable&&wd>=1&&wd<=100)begin offer_slot<=wd[6:0];s_bresp<=0;end
      12'h014:if(editable)begin offer_generation[31:0]<=wd;s_bresp<=0;end
      12'h018:if(editable)begin offer_generation[63:32]<=wd;s_bresp<=0;end
      12'h01c:if(editable)begin offer_batch[31:0]<=wd;s_bresp<=0;end
      12'h020:if(editable)begin offer_batch[63:32]<=wd;s_bresp<=0;end
      12'h024:if(editable&&wd==3)begin offer_held<=1;offer_cache_clean<=1;s_bresp<=0;end
      12'h028:if(editable&&wd!=0)begin offer_expected_model<=wd;s_bresp<=0;end
      12'h02c:begin
       if(wd==1&&editable&&offer_ready&&offer_slot>=1&&offer_slot<=100&&offer_generation!=0&&offer_batch!=0&&offer_held&&offer_cache_clean&&offer_expected_model!=0)begin offer_valid<=1;s_bresp<=0;end
       else if(wd==2&&busy&&!active&&!receipt_valid&&!offer_valid)begin offer_cancel<=1;s_bresp<=0;end
      end
      12'h034:if(receipt_valid&&wd==token)begin receipt_ack<=1;receipt_ack_token<=wd;s_bresp<=0;end
      default:begin end
     endcase
    end
   end
   if(s_rvalid&&s_rready)s_rvalid<=0;
   if(s_arvalid&&s_arready)begin
    s_rvalid<=1;s_rdata<=0;s_rresp<=2;
    if(ENABLE!=0&&s_araddr[1:0]==0)begin
     s_rresp<=0;
     case(s_araddr)
      12'h000:s_rdata<=32'h4f525331;12'h004:s_rdata<=32'h00010000;
      12'h008:s_rdata<={24'd0,receipt_error!=0,exhausted,receipt_failed,receipt_valid,active,busy,offer_valid,offer_ready};
      12'h010:s_rdata<={25'd0,offer_slot};
      12'h014:s_rdata<=offer_generation[31:0];12'h018:s_rdata<=offer_generation[63:32];
      12'h01c:s_rdata<=offer_batch[31:0];12'h020:s_rdata<=offer_batch[63:32];
      12'h024:s_rdata<={30'd0,offer_cache_clean,offer_held};12'h028:s_rdata<=offer_expected_model;
      12'h040:s_rdata<={25'd0,selected_slot};12'h044:s_rdata<=selected_generation[31:0];12'h048:s_rdata<=selected_generation[63:32];
      12'h04c:s_rdata<=selected_batch[31:0];12'h050:s_rdata<=selected_batch[63:32];12'h054:s_rdata<=token;
      12'h058:s_rdata<=exec_session;12'h05c:s_rdata<=exec_frame;12'h060:s_rdata<=exec_epoch;12'h064:s_rdata<=exec_model;
      12'h068:s_rdata<=exec_key[31:0];12'h06c:s_rdata<=exec_key[63:32];12'h070:s_rdata<=exec_key[95:64];12'h074:s_rdata<=exec_key[127:96];
      12'h078:s_rdata<={24'd0,receipt_error};
      default:s_rresp<=2;
     endcase
    end
   end
  end
 end
endmodule
