`timescale 1ns/1ps
// Thin adjunct to the UNMODIFIED trusted_debug_key_provider. The base provider
// first validates the same global command sequence and untorn VIO payload,
// replying07 for these deliberately new operations. Only then may this module
// request an audio job or send raw samples. No PS or raw-DDR input exists.
module trusted_debug_audio_source #(
 parameter integer TIMEOUT_CYCLES=100000000,
 parameter integer ENABLE_ADMISSION_BUSY_REJECT=0,
 parameter [31:0] SOURCE_ID=32'd2
)(
 input wire clk,security_reset_n,
 input wire [31:0] debug_command,debug_resume_epoch,
 input wire [127:0] debug_key,debug_session_id,debug_key_fingerprint,
 input wire [31:0] base_ack_word,
 input wire controller_authorized,model_authorized,guard_key_valid,admission_blocked,
 input wire [31:0] controller_epoch,model_epoch,
 input wire [127:0] controller_session_id,
 output wire audio_job_valid,input wire audio_job_ready,
 input wire audio_context_valid,input wire [287:0] accepted_audio_context,
 output wire pcm_valid,input wire pcm_ready,output wire [15:0] pcm_data,
 output wire [13:0] pcm_index,output wire pcm_last,output wire [287:0] pcm_context,
 output reg trusted_revoke,
 output wire [31:0] ack_word,output wire busy,resource_quiescent,
 output wire active_clip,output wire [13:0] samples_sent
);
 localparam BOOT=0,IDLE=1,BASE_WAIT=2,CHECK=3,JOB=4,CONTEXT=5,SEND=6;
 reg [2:0] state;
 reg [31:0] command,metadata,ticks;reg [383:0] payload;
 reg [23:0] last_seen_sequence,ack_sequence;reg [7:0] ack_error;
 reg active;
 reg [287:0] captured_context;
 reg [13:0] sent;
 reg [4:0] batch_count,batch_position;
 wire [23:0] incoming_sequence=debug_command[31:8];
 wire authorized_now=controller_authorized&&model_authorized&&guard_key_valid;
 wire context_current=authorized_now&&audio_context_valid&&accepted_audio_context==captured_context&&
  captured_context[287:256]==model_epoch&&captured_context[255:224]==controller_epoch&&captured_context[127:0]==controller_session_id;
 wire unchanged=command==debug_command&&metadata==debug_resume_epoch&&payload=={debug_key,debug_session_id,debug_key_fingerprint};
 wire admission_live=ticks<TIMEOUT_CYCLES-1;
 wire accepted_context_well_formed=audio_context_valid&&accepted_audio_context[287:256]==model_epoch&&
  accepted_audio_context[255:224]==controller_epoch&&accepted_audio_context[223:192]==SOURCE_ID&&
  accepted_audio_context[191:160]!=0&&accepted_audio_context[159:128]!=0&&
  accepted_audio_context[127:0]==controller_session_id&&controller_session_id!=0&&model_epoch!=0&&controller_epoch!=0&&
  (accepted_audio_context[255:224]!=captured_context[255:224]||accepted_audio_context[127:0]!=captured_context[127:0]||
   accepted_audio_context[159:128]>captured_context[159:128]);
 assign audio_job_valid=state==JOB&&unchanged&&admission_live&&authorized_now;
 assign pcm_valid=state==SEND&&active&&context_current&&unchanged&&admission_live;
 assign pcm_data=payload[batch_position*16+:16];
 assign pcm_index=sent;assign pcm_last=sent==15999;assign pcm_context=captured_context;
 assign ack_word={ack_error,ack_sequence};
 assign busy=state!=IDLE;
 // A waiting control OFFER owns no data resource and must not deadlock the
 // root's actual job-ready predicate. Partial raw clips remain non-quiescent.
 assign resource_quiescent=(!active||sent==16000)&&state!=SEND;
 assign active_clip=active;assign samples_sent=sent;
 task finish(input [7:0] error_code);
  begin ack_sequence<=command[31:8];ack_error<=error_code;state<=IDLE;ticks<=0;end
 endtask
 task fail(input [7:0] error_code);
  begin
   if(active||state==JOB||state==CONTEXT)trusted_revoke<=1;
   active<=0;finish(error_code);
  end
 endtask
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=BOOT;command<=0;metadata<=0;ticks<=0;payload<=0;last_seen_sequence<=0;
   ack_sequence<=0;ack_error<=0;active<=0;captured_context<=0;sent<=0;batch_count<=0;batch_position<=0;trusted_revoke<=0;
  end else begin
   trusted_revoke<=0;
   if(state!=IDLE)ticks<=ticks+1'b1;
   if(active&&!context_current)active<=0;
   case(state)
    BOOT:begin last_seen_sequence<=incoming_sequence;state<=IDLE;ticks<=0;end
    IDLE:if(incoming_sequence!=last_seen_sequence)begin
     last_seen_sequence<=incoming_sequence;
     if(debug_command[7:0]==5||debug_command[7:0]==6)begin
      command<=debug_command;metadata<=debug_resume_epoch;
      payload<={debug_key,debug_session_id,debug_key_fingerprint};ticks<=0;state<=BASE_WAIT;
     end
    end
    BASE_WAIT:if(!unchanged)fail(8'h09);
     else if(base_ack_word[23:0]==command[31:8])begin
      if(base_ack_word[31:24]!=8'h07)fail(base_ack_word[31:24]==0?8'h0b:base_ack_word[31:24]);
      else state<=CHECK;
     end
    CHECK:if(!unchanged)fail(8'h09);
     else if(!authorized_now)fail(8'h06);
     else if(command[7:0]==5)begin
      if(ENABLE_ADMISSION_BUSY_REJECT!=0&&admission_blocked)finish(8'h06);
      else if(active&&sent!=16000)fail(8'h06);else state<=JOB;
     end else begin
      // Operation6 metadata: [13:0] first sample index, [20:16] count1..24,
      // [15:14] and[31:21] zero. First sample is payload low16 bits (FP field).
      if(!active||!context_current||metadata[31:21]!=0||metadata[15:14]!=0||
        metadata[20:16]==0||metadata[20:16]>24||metadata[13:0]!=sent||
        {1'b0,sent}+{10'd0,metadata[20:16]}>16000)fail(8'h0c);
      else begin batch_count<=metadata[20:16];batch_position<=0;state<=SEND;end
     end
    JOB:if(!unchanged)fail(8'h09);
     else if(!authorized_now)fail(8'h06);
     else if(audio_job_valid&&audio_job_ready)begin active<=0;state<=CONTEXT;end
    CONTEXT:if(!unchanged)fail(8'h09);
     else if(!authorized_now)fail(8'h06);
     else if(accepted_context_well_formed)begin captured_context<=accepted_audio_context;active<=1;sent<=0;finish(8'h00);end
    SEND:if(!unchanged)fail(8'h09);
     else if(!active||!context_current)fail(8'h06);
     else if(pcm_valid&&pcm_ready)begin
      sent<=sent+1'b1;
      if(batch_position+1'b1==batch_count)finish(8'h00);else batch_position<=batch_position+1'b1;
     end
    default:fail(8'hff);
   endcase
   if(state!=IDLE&&state!=BOOT&&ticks>=TIMEOUT_CYCLES-1)fail(8'h0a);
  end
 end
endmodule
