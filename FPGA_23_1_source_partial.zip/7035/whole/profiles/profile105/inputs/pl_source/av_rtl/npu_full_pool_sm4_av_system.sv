`timescale 1ns/1ps
`include "ordinary_io/ordinary_ps_task_requester.sv"
// Actual system candidate. No PS owner/GO/authority port and no modeled NN.
// All authority comes from the protected root and the actual V2 model service.
module npu_full_pool_sm4_av_system #(parameter integer AUDIO_PARALLEL_CLOCK=0, parameter integer CLOSED_OUTPUT_FAULT_COFACTOR=0, parameter [31:0] FRONTEND_JOB_TIMEOUT_CYCLES=32'd1000000000, parameter [63:0] FRAME_JOB_TIMEOUT_CYCLES=64'd6000000000, parameter integer PROPAGATE_FRONTEND_CANCEL=0, parameter integer ENABLE_ORDINARY_PREVIEW=0, parameter integer PIPELINED_TRUSTED_CONTROL=0, parameter integer ENABLE_ORDINARY_SLOT_REPLAY=0, parameter integer ENABLE_ORDINARY_AUTORUN=0, parameter integer ENABLE_PHYSICAL_MIC=0, parameter integer ENABLE_FIRST_OBSERVED_FAULT_DIAGNOSTIC=0,parameter integer ENABLE_PS_NORMAL_TASK_REQUEST=0,parameter integer ENABLE_MIC_RAW_DIAGNOSTICS=0)(
 input wire normal_request_valid,input wire[31:0]normal_request_command,normal_request_epoch,normal_request_model,
 input wire[3:0]normal_request_strobes,output wire[7:0]normal_request_error,
 output wire[31:0]normal_result_word,normal_status_word,
 output wire[223:0]normal_witness_words,
 input wire mic_sd,output wire mic_bclk,mic_ws,
 output wire[511:0]mic_raw_diagnostic_words,
 input wire clk,trusted_por_n,clock_locked,ps_reset_n,
 input wire external_memory_available,external_resources_quiescent,
 input wire ordinary_flow_ack_valid,input wire[351:0]ordinary_flow_ack,
 input wire ordinary_physical_output_quiet,
 input wire[4:0] ordinary_preview_diagnostic_fault_leaves,
 output wire[31:0]ordinary_flow_status,ordinary_flow_ticket,output wire[319:0]ordinary_flow_expected,
 output wire ordinary_pending_nn_intent,
 input wire [31:0] debug_command,debug_resume_epoch,
 input wire [127:0] debug_key,debug_session_id,debug_key_fingerprint,
 output wire [31:0] ack_word,status_word,last_sequence_word,
 output wire security_reset_n,arith_reset_n,authorized,key_valid,active,quiescent,fault,job_done,
 output wire [31:0] authorization_epoch,model_epoch,
 output wire [127:0] key_session_id,
 output wire raw_model_authorized,model_lease_valid,
 output wire [31:0] observation_next_capture_session,observation_next_capture_frame,observation_next_capture_status,
 output wire audio_record_commit,audio_record_visible,audio_job_accepted,
 output wire [287:0] audio_record_context,output wire [6:0]audio_record_class,
 output wire [31:0]audio_record_score,output reg [63:0]audio_total_cycles,audio_post_pcm_cycles,output reg [31:0]audio_sequence,
 output wire audio_active,audio_quiescent,audio_fault,output wire [7:0]audio_phase,

 input wire [11:0] PS_AWADDR,PS_ARADDR,
 input wire PS_AWVALID,PS_WVALID,PS_BREADY,PS_ARVALID,PS_RREADY,
 input wire [31:0] PS_WDATA,input wire [3:0] PS_WSTRB,
 output wire PS_AWREADY,PS_WREADY,PS_BVALID,PS_ARREADY,PS_RVALID,
 output wire [1:0] PS_BRESP,PS_RRESP,output wire [31:0] PS_RDATA,
 input wire packet_valid,input wire [383:0] packet_header,output wire packet_release,
 output wire payload_read,output wire [9:0] payload_address,input wire [7:0] payload_data,input wire payload_read_valid,
 output wire response_valid,input wire response_ready,output wire [7:0] response_kind,response_flags,
 output wire [31:0] response_offset,response_frame_crc,response_session_id,response_frame_id,response_total_bytes,
 output wire [15:0] response_width,response_height,
 output wire [31:0] completed_frames,rejected_completions,committed_offset,received_crc,
 output wire observation_frame_start,observation_ingress_done,observation_page_accept,observation_page_input_wait,
 output wire [31:0] observation_page_index,observation_model_address,observation_proof_address,
 output wire [2:0] service_committed_owner,output wire [1:0] hp_committed_owner,
 output wire metrics_valid,metrics_fault,output wire [63:0] metrics_total,metrics_ingress,metrics_yolo,
 output wire [255:0] metrics_frontend,metrics_nn,metrics_head,
 output wire [63:0] metrics_page_input_wait,metrics_mac_busy,metrics_pool_wait,
 output wire [3:0] metrics_roi_measured,output wire [31:0] metrics_sequence,
 output wire [63:0] frame_elapsed_cycles,
 output wire record_visible,
 output wire record_commit_pulse,
 output wire [31:0] record_camera,
 output wire [31:0] record_session,
 output wire [31:0] record_frame,
 output wire [31:0] record_epoch,
 output wire [127:0] record_key_session,
 output wire [2:0] record_count,
 output wire [895:0] record_rois,
 output wire [51:0] record_indices,
 output wire [511:0] record_results,
 output wire observation_pool_wait,
 output wire observation_yolo_start,
 output wire observation_yolo_done,
 output wire observation_frontend_start,
 output wire observation_nn_start,
 output wire observation_nn_done,
 output wire observation_head_start,
 output wire [31:0] observation_roi_index,
 output wire [31:0] observation_generation,
 output wire [3:0] observation_block,
 output wire observation_norm3_valid,
 output wire observation_norm3_done,
 output wire [15:0] observation_norm3_address,
 output wire [15:0] observation_norm3_data,
 output wire observation_logit_valid,
 output wire [7:0] observation_logit_class,
 output wire [63:0] observation_logit_data,
 output wire observation_result_valid,
 output wire [7:0] observation_result_class,
 output wire [63:0] observation_result_logit,
 output wire [31:0] observation_consumer_session,
 output wire [31:0] observation_consumer_frame,
 output wire [31:0] observation_consumer_epoch,
 output wire [31:0] observation_context_camera,
 output wire [31:0] observation_context_session,
 output wire [31:0] observation_context_frame,
 output wire [31:0] observation_context_epoch,
 output wire [31:0] M_AXI_ARADDR,
 output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,
 output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,
 input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,
 input wire [1:0] M_AXI_RRESP,
 input wire M_AXI_RLAST,
 input wire M_AXI_RVALID,
 output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,
 output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,
 output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,
 input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,
 output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,
 output wire M_AXI_WVALID,
 input wire M_AXI_WREADY,
 input wire [1:0] M_AXI_BRESP,
 input wire M_AXI_BVALID,
 output wire M_AXI_BREADY,
 input wire trusted_audio_raw_clk
,
 input wire outputs_fault_for_cofactor,ps_reset_f0_for_cofactor,output wire execution_authorized_probe,
// Actual AV opt-in ordinary preview interface, synchronous to clk100.
// With ENABLE_ORDINARY_PREVIEW=0 original NN/control behavior is retained.
 input wire ordinary_nn_request_ready,ordinary_nn_owner_opened,ordinary_nn_abort,
 input wire ordinary_preview_quiet,ordinary_preview_fault,
 input wire [31:0]ordinary_next_session,ordinary_next_frame,
 input wire ordinary_allocator_exhausted,ordinary_raw_consume_done,
 input wire ordinary_packet_quiescent,ordinary_response_quiescent,
 output wire ordinary_preview_allowed,ordinary_nn_request,
 output wire ordinary_nn_active,ordinary_nn_retired,ordinary_nn_error,
 output wire ordinary_nn_raw_sealed,ordinary_nn_raw_frame_ready,
 output wire ordinary_nn_raw_transport_idle,ordinary_nn_raw_slot_ready,
 output wire [31:0]ordinary_nn_raw_crc,

// Ordinary PS metadata only. The private VIO provider alone can grant GO.
 input wire replay_offer_valid,output wire replay_offer_ready,
 input wire[6:0] replay_offer_slot,input wire[63:0] replay_offer_generation,replay_offer_batch,
 input wire replay_offer_held,replay_offer_cache_clean,input wire[31:0] replay_offer_expected_model,
 input wire replay_offer_cancel,replay_receipt_ack,input wire[31:0] replay_receipt_ack_token,
 output wire replay_busy,replay_active,replay_receipt_valid,replay_receipt_failed,replay_exhausted,
 output wire[7:0] replay_receipt_error,output wire[6:0] replay_selected_slot,
 output wire[63:0] replay_selected_generation,replay_selected_batch,
 output wire[31:0] replay_token,replay_exec_session,replay_exec_frame,replay_exec_epoch,replay_exec_model,
 output wire[127:0] replay_exec_key


,
 output wire[223:0] observation_camera_first_cause,
 output wire[383:0] observation_raw_diagnostic_words
);
wire f0_raw_model,f0_model_verification,f0_lease_revoke,f0_root_authorized,f0_root_cancel,f0_authorized;
wire cofactor_known;
wire execution_authorized;
wire legacy_authorized,legacy_f0_authorized,legacy_raw_model,legacy_f0_raw_model;
wire legacy_model_verify,legacy_f0_model_verify,legacy_lease_revoke,legacy_f0_lease_revoke;
wire ctl_root_run_scope,ctl_policy_ff,ctl_phase_leaf,ctl_other_fault;
wire ctl_cancel_public,ctl_cancel_private,ctl_verify_public_nophase,ctl_verify_private_nophase;
wire [3:0]ctl_actor_live,ctl_actor_cancel;
wire ctl_pipeline_retired,ctl_short_fence,private_record_visible,private_record_commit;

wire execution_root_cancel;
wire execution_raw_model;



wire [31:0] ordinary_camera_next_session,ordinary_camera_next_frame;
wire ordinary_camera_next_exhausted,ordinary_camera_native_slot_ready;
wire ordinary_raw_sealed_actual,ordinary_raw_writer_quiet,ordinary_raw_frame_ready_actual,ordinary_raw_transport_idle_actual;
wire[31:0]ordinary_raw_committed,ordinary_capture_session,ordinary_capture_frame;
reg ordinary_nn_accepted_live;
wire ordinary_actual_retired;
wire capture_next_exhausted;
wire [31:0] a_ARADDR;
wire [7:0] a_ARLEN;
wire [2:0] a_ARSIZE;
wire [1:0] a_ARBURST;
wire a_ARVALID;
wire a_ARREADY;
wire [255:0] a_RDATA;
wire [1:0] a_RRESP;
wire a_RLAST;
wire a_RVALID;
wire a_RREADY;
wire [31:0] a_AWADDR;
wire [7:0] a_AWLEN;
wire [2:0] a_AWSIZE;
wire [1:0] a_AWBURST;
wire a_AWVALID;
wire a_AWREADY;
wire [255:0] a_WDATA;
wire [31:0] a_WSTRB;
wire a_WLAST;
wire a_WVALID;
wire a_WREADY;
wire [1:0] a_BRESP;
wire a_BVALID;
wire a_BREADY;
reg audio_mode,audio_launched;reg[31:0]audio_generation;
reg[287:0]audio_context;reg[63:0]audio_elapsed;
wire audio_job_valid,audio_job_ready,audio_start_valid,audio_start_ready,audio_done;
wire pcm_valid,pcm_ready,pcm_last;wire[15:0]pcm_data;wire[14:0]pcm_index;wire[287:0]pcm_context;
wire audio_source_busy,audio_source_quiet,audio_source_revoke,audio_source_active;wire[14:0]pcm_samples_sent;
wire[31:0]base_ack,base_status,audio_ack;
wire debug_audio_job_valid,debug_pcm_valid,debug_pcm_last,debug_source_revoke,debug_source_busy,debug_source_quiet,debug_source_active;
wire[15:0]debug_pcm_data;wire[13:0]debug_pcm_index,debug_samples;wire[287:0]debug_pcm_context;wire[31:0]debug_audio_ack;
wire mic_audio_job_valid,mic_pcm_valid,mic_pcm_last,mic_source_revoke,mic_source_busy,mic_source_quiet,mic_source_active;
wire[15:0]mic_pcm_data;wire[14:0]mic_pcm_index,mic_samples;wire[287:0]mic_pcm_context;wire[31:0]mic_audio_ack;
wire mic_b_write,mic_b_read,mic_b_write_accepted,mic_b_read_accepted,mic_b_response_valid,mic_b_response_ready,mic_b_drained;
wire[11:0]mic_b_write_address,mic_b_read_address;wire[255:0]mic_b_write_data,mic_b_read_data;
assign audio_job_valid=ENABLE_PHYSICAL_MIC!=0?mic_audio_job_valid:debug_audio_job_valid;
assign pcm_valid=ENABLE_PHYSICAL_MIC!=0?mic_pcm_valid:debug_pcm_valid;
assign pcm_data=ENABLE_PHYSICAL_MIC!=0?mic_pcm_data:debug_pcm_data;
assign pcm_index=ENABLE_PHYSICAL_MIC!=0?mic_pcm_index:debug_pcm_index;
assign pcm_last=ENABLE_PHYSICAL_MIC!=0?mic_pcm_last:debug_pcm_last;
assign pcm_context=ENABLE_PHYSICAL_MIC!=0?mic_pcm_context:debug_pcm_context;
assign audio_source_revoke=ENABLE_PHYSICAL_MIC!=0?mic_source_revoke:debug_source_revoke;
assign audio_ack=ENABLE_PHYSICAL_MIC!=0?mic_audio_ack:debug_audio_ack;
assign audio_source_busy=ENABLE_PHYSICAL_MIC!=0?mic_source_busy:debug_source_busy;
assign audio_source_quiet=ENABLE_PHYSICAL_MIC!=0?mic_source_quiet:debug_source_quiet;
assign audio_source_active=ENABLE_PHYSICAL_MIC!=0?mic_source_active:debug_source_active;
assign pcm_samples_sent=ENABLE_PHYSICAL_MIC!=0?mic_samples:debug_samples;

wire audio_pool_request,audio_pool_read,audio_pool_write,audio_pool_granted,pool_protocol_violation;
wire[11:0]audio_pool_read_address,audio_pool_write_address;wire[255:0]audio_pool_read_data,audio_pool_write_data;
wire a_mac_request,a_mac_ready,a_mac_response_valid,a_mac_response_error;wire[127:0]a_mac_chain,a_mac_tag;wire[255:0]a_mac_data;
wire a_fetch_valid,a_fetch_ready;wire[31:0]a_fetch_page,a_fetch_address,a_fetch_proof;
wire a_page_request,a_page_ready,a_cache_read,a_read_valid;wire[31:0]a_expected_page;wire[9:0]a_cache_address;
wire audio_raw_record_visible,audio_raw_record_commit;wire[287:0]audio_raw_record_context;wire[6:0]audio_raw_record_class;wire[31:0]audio_raw_record_score;
wire audio_encoder_start,audio_encoder_done;wire[63:0]audio_current_post_pcm_cycles;
reg av_protocol_fault;
wire av_raw_protocol_violation;
reg [2:0] committed_model_owner;
wire v_mac_request,v_mac_ready,v_mac_response_valid,v_mac_response_error,v_mac_quiescent;wire [127:0] v_mac_chain,v_mac_tag;wire [255:0] v_mac_data;
wire controller_authorized,controller_key_session_valid,root_cancel,commit_allowed;
wire [127:0] controller_session_id,controller_key_fingerprint,installed_key;
wire [31:0] controller_epoch;
wire all_quiescent,provision_ready,provision_accepted,provision_rejected,provision_valid,trusted_fresh_key_ready;
wire [127:0] provision_session_id,provision_key_fingerprint;
wire resume_ready,resume_accepted,resume_rejected,trusted_resume_valid;
wire [31:0] trusted_resume_epoch;wire [127:0] trusted_resume_session_id;
wire trusted_job_ready,trusted_job_request,trusted_revoke,provider_busy;
wire root_quiet,draining,epoch_exhausted,session_exhausted,drain_timed_out,locked_fault;
wire hub_quiescent,hub_registered_quiescent,hub_fault,service_busy,service_fault,slh_busy,feeder_quiescent;
wire service_protocol_violation;
wire model_verification_start,feeder_cancelled,lease_revoke;
wire [31:0] bound_model_epoch,bound_runtime_epoch;wire [127:0] bound_key_session;
wire [7:0] signature_error,policy_error,page_error,feeder_error;



wire camera_active,camera_fault,camera_quiescent,camera_go_ready,camera_job_valid,camera_job_ready;
wire [31:0] camera_job_session,camera_job_frame,camera_job_epoch,camera_job_base;
wire camera_job_cancel,sealed_letterbox_valid;wire [31:0] sealed_session,sealed_frame,sealed_epoch;
wire observation_capture_start;
wire vision_active,vision_quiescent,vision_actors_quiescent,vision_done,vision_failed,vision_fault;
wire camera_guard_quiet,camera_backend_quiet,shared_mac_quiet,shared_mac_fault,hp_quiet,hp_fault;
wire hp_channels_quiet;
wire [31:0] c_ARADDR;
wire [7:0] c_ARLEN;
wire [2:0] c_ARSIZE;
wire [1:0] c_ARBURST;
wire c_ARVALID;
wire c_ARREADY;
wire [255:0] c_RDATA;
wire [1:0] c_RRESP;
wire c_RLAST;
wire c_RVALID;
wire c_RREADY;
wire replay_private_request,replay_private_ready,replay_private_selected,replay_root_request,replay_pending_for_root;
wire replay_selected_held,replay_selected_clean,replay_execution_accepted,replay_stop;
wire[31:0] replay_selected_model;
wire[31:0] replay_pending_offer_identity,replay_root_offer_identity;
wire replay_pending_offer_live;
wire replay_terminal,replay_terminal_failed;wire[7:0]replay_terminal_error;wire[31:0]replay_terminal_token,replay_terminal_session,replay_terminal_frame,replay_terminal_epoch;
wire replay_converter_quiet,replay_submux_quiet,replay_converter_fault,replay_submux_fault;
wire replay_io_drained=camera_guard_quiet&&camera_backend_quiet&&shared_mac_quiet&&replay_converter_quiet&&replay_submux_quiet&&hp_channels_quiet;
wire[31:0] slot_araddr,slot_m_araddr,camread_araddr;
wire[7:0] slot_arlen,slot_m_arlen,camread_arlen;
wire[2:0] slot_arsize,slot_m_arsize,camread_arsize;
wire[1:0] slot_arburst,slot_m_arburst,camread_arburst,slot_rresp,slot_m_rresp,camread_rresp;
wire slot_arvalid,slot_arready,slot_rlast,slot_rvalid,slot_rready;
wire slot_m_arvalid,slot_m_arready,slot_m_rlast,slot_m_rvalid,slot_m_rready;
wire camread_arvalid,camread_arready,camread_rlast,camread_rvalid,camread_rready;
wire[63:0] slot_rdata;wire[255:0]slot_m_rdata,camread_rdata;
wire base_camera_go_ready;
wire model_cancellation_pending;
wire hard_fault=(ENABLE_ORDINARY_SLOT_REPLAY!=0&&(replay_converter_fault||replay_submux_fault))||locked_fault||hub_fault||shared_mac_fault||hp_fault||av_protocol_fault||(ENABLE_ORDINARY_PREVIEW!=0&&ordinary_preview_fault);
wire global_fault=hard_fault;
wire stage_fault,abort_execution;
wire provider_key_valid,vision_job_ready;
wire [1:0] cbc_ready,cbc_response_valid,cbc_response_error;wire [255:0] cbc_tag;
assign authorization_epoch=controller_epoch;assign key_session_id=controller_session_id;
assign fault=hard_fault||service_fault||vision_fault||camera_fault||audio_fault;
assign active=camera_active||vision_active||audio_active||audio_mode;
assign quiescent=all_quiescent;
assign key_valid=provider_key_valid&&controller_key_session_valid;
localparam IDLE=0,CAPTURE=1,VISION=2,DRAIN=3,AUDIO=4;
reg [2:0] stage;
wire camera_resources_quiet=camera_guard_quiet&&camera_backend_quiet&&shared_mac_quiet&&replay_converter_quiet&&replay_submux_quiet;
wire auto_start,auto_stop,auto_start_ready,auto_offer,auto_busy,auto_granted,auto_wait_ack,auto_flow_block;
wire normal_selected_ready;
// Physical retirement for revocation excludes untrusted diagnostic AXI-Lite
// half-writes/responses. No PS cooperation is needed to drop the old ticket.
wire auto_physical_retired=(stage==IDLE||stage==DRAIN&&abort_execution)&&
 !camera_active&&!vision_active&&camera_quiescent&&vision_quiescent&&camera_resources_quiet&&hp_quiet&&hub_quiescent&&
 ordinary_raw_transport_idle_actual&&ordinary_packet_quiescent&&ordinary_response_quiescent&&audio_quiescent&&audio_source_quiet&&ordinary_physical_output_quiet;
wire ps_normal_start,ps_normal_stop,ps_mic_request,ps_mic_ready,ps_mic_result_valid,ps_preview_inhibit;
wire[31:0]ps_mic_epoch,ps_mic_model;wire[7:0]ps_mic_result_error;
ordinary_ps_task_requester #(.ENABLE(ENABLE_PS_NORMAL_TASK_REQUEST),.ENABLE_MIC(ENABLE_PHYSICAL_MIC),.ENABLE_RUN(ENABLE_ORDINARY_AUTORUN)) ps_task_requester(
 .clk(clk),.security_reset_n(security_reset_n),.request_valid(normal_request_valid),.request_command(normal_request_command),.request_epoch(normal_request_epoch),.request_model(normal_request_model),.request_strobes(normal_request_strobes),.request_error(normal_request_error),
 .authority_live(authorized&&key_valid&&model_lease_valid&&!trusted_revoke&&!audio_source_revoke&&!root_cancel&&!global_fault&&!stage_fault&&!model_verification_start&&!model_cancellation_pending),
 .runtime_epoch(authorization_epoch),.model_epoch(model_epoch),.vio_command(debug_command),.vio_busy(provider_busy),.vio_start(auto_start),.vio_stop(auto_stop),
 .start_ready(auto_start_ready),.run_busy(auto_busy),.run_granted(auto_granted),.flow_block(auto_flow_block),.task_boundary_quiet(all_quiescent&&auto_physical_retired),
 .start_grant(ps_normal_start),.stop_grant(ps_normal_stop),.preview_inhibit(ps_preview_inhibit),
 .mic_request_valid(ps_mic_request),.mic_request_ready(ps_mic_ready),.mic_request_epoch(ps_mic_epoch),.mic_request_model(ps_mic_model),.mic_result_valid(ps_mic_result_valid),.mic_result_error(ps_mic_result_error),.mic_capture_context(audio_context[287:128]),.mic_completion_valid(audio_record_commit&&audio_record_visible&&audio_record_context==audio_context),.mic_completion_context(audio_record_context[287:128]),.mic_completion_sequence(audio_sequence+32'd1),
 .result_word(normal_result_word),.status_word(normal_status_word),.witness_words(normal_witness_words));
ordinary_camera_autorun #(.ENABLE(ENABLE_ORDINARY_AUTORUN)) auto_run(
 .clk(clk),.security_reset_n(security_reset_n),.start_grant(ENABLE_PS_NORMAL_TASK_REQUEST!=0?((auto_start||ps_normal_start)&&!(auto_stop||ps_normal_stop)):auto_start),.stop_grant(ENABLE_PS_NORMAL_TASK_REQUEST!=0?(auto_stop||ps_normal_stop):auto_stop),
 .authority_live(authorized&&key_valid&&model_lease_valid&&!trusted_revoke&&!audio_source_revoke&&!root_cancel&&!global_fault&&!stage_fault&&!model_verification_start&&!model_cancellation_pending),
 .runtime_epoch(authorization_epoch),.model_epoch(model_epoch),.key_session(key_session_id),.key_fingerprint(controller_key_fingerprint),
 .start_resources_idle(stage==IDLE&&!camera_active&&!vision_active&&!audio_mode&&!audio_job_valid&&!audio_source_busy&&!replay_active&&!replay_private_request&&external_memory_available),
 .start_ready(auto_start_ready),.request_valid(auto_offer),.request_ready(normal_selected_ready),
 .next_session(ordinary_next_session),.next_frame(ordinary_next_frame),.actual_active(stage!=IDLE||camera_active||vision_active),.actual_retired(auto_physical_retired),.actual_failed(ordinary_nn_error),
 .record_commit(record_commit_pulse),.record_visible(record_visible),.record_is_replay(replay_active),.record_camera(record_camera),.record_session(record_session),.record_frame(record_frame),.record_epoch(record_epoch),.record_key(record_key_session),
 .ps_ack_valid(ordinary_flow_ack_valid),.ps_ack(ordinary_flow_ack),.busy(auto_busy),.grant_live(auto_granted),.wait_ack(auto_wait_ack),.flow_block(auto_flow_block),
 .status(ordinary_flow_status),.ticket(ordinary_flow_ticket),.expected(ordinary_flow_expected));
assign ordinary_pending_nn_intent=auto_offer;
trusted_debug_key_provider #(.ENABLE_ORDINARY_AUTORUN(ENABLE_ORDINARY_AUTORUN),.CLOSED_ROOT_BINDING(1),.ENABLE_ORDINARY_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY)) u_provider(
 .ordinary_autorun_ready(auto_start_ready),.ordinary_autorun_model_epoch(model_epoch),.ordinary_autorun_start(auto_start),.ordinary_autorun_stop(auto_stop),
 .ordinary_replay_offer_live(replay_pending_offer_live),.ordinary_replay_offer_identity(replay_pending_offer_identity),.ordinary_replay_request_identity(replay_root_offer_identity),
 .ordinary_replay_ready(replay_pending_for_root&&!auto_busy),.ordinary_replay_slot(replay_selected_slot),.ordinary_replay_accepted(replay_execution_accepted),.ordinary_replay_request(replay_root_request),
 .clk(clk),.security_reset_n(security_reset_n),.debug_command(debug_command),.debug_key(debug_key),.debug_session_id(debug_session_id),.debug_key_fingerprint(debug_key_fingerprint),.debug_resume_epoch(debug_resume_epoch),
 .all_quiescent(all_quiescent),.controller_authorized(controller_authorized),.controller_key_session_valid(controller_key_session_valid),.model_authorized(raw_model_authorized),.controller_session_id(controller_session_id),.controller_key_fingerprint(controller_key_fingerprint),.controller_epoch(controller_epoch),
 .provision_ready(provision_ready),.provision_accepted(provision_accepted),.provision_rejected(provision_rejected),.provision_valid(provision_valid),.trusted_fresh_key_ready(trusted_fresh_key_ready),.provision_session_id(provision_session_id),.provision_key_fingerprint(provision_key_fingerprint),
 .resume_ready(resume_ready),.resume_accepted(resume_accepted),.resume_rejected(resume_rejected),.trusted_resume_valid(trusted_resume_valid),.trusted_resume_epoch(trusted_resume_epoch),.trusted_resume_session_id(trusted_resume_session_id),
 .trusted_job_ready(trusted_job_ready),.trusted_job_request(trusted_job_request),.trusted_revoke(trusted_revoke),.installed_key(installed_key),.guard_key_valid(provider_key_valid),.ack_word(base_ack),.status_word(base_status),.last_sequence_word(last_sequence_word),.busy(provider_busy));

assign ack_word=(debug_command[7:0]==5||debug_command[7:0]==6)?audio_ack:base_ack;
assign status_word={base_status[31:1],base_status[0]||audio_source_busy};
trusted_debug_audio_source #(.ENABLE_ADMISSION_BUSY_REJECT(ENABLE_ORDINARY_AUTORUN)) u_audio_debug(
 .clk(clk),.security_reset_n(security_reset_n),.debug_command(ENABLE_PHYSICAL_MIC!=0?32'd0:debug_command),.debug_resume_epoch(debug_resume_epoch),
 .debug_key(debug_key),.debug_session_id(debug_session_id),.debug_key_fingerprint(debug_key_fingerprint),.base_ack_word(base_ack),
 .controller_authorized(controller_authorized),.model_authorized(authorized),.guard_key_valid(key_valid),.admission_blocked(auto_busy||auto_flow_block||stage!=IDLE),
 .controller_epoch(controller_epoch),.model_epoch(model_epoch),.controller_session_id(controller_session_id),
 .audio_job_valid(debug_audio_job_valid),.audio_job_ready(ENABLE_PHYSICAL_MIC==0&&audio_job_ready),.audio_context_valid(ENABLE_PHYSICAL_MIC==0&&audio_mode&&authorized&&key_valid&&!root_cancel),.accepted_audio_context(audio_context),
 .pcm_valid(debug_pcm_valid),.pcm_ready(ENABLE_PHYSICAL_MIC==0&&pcm_ready),.pcm_data(debug_pcm_data),.pcm_index(debug_pcm_index),.pcm_last(debug_pcm_last),.pcm_context(debug_pcm_context),
 .trusted_revoke(debug_source_revoke),.ack_word(debug_audio_ack),.busy(debug_source_busy),.resource_quiescent(debug_source_quiet),.active_clip(debug_source_active),.samples_sent(debug_samples));
generate if(ENABLE_PHYSICAL_MIC!=0)begin:g_physical_mic
 trusted_mic_audio_source #(.ENABLE_ADMISSION_BUSY_REJECT(ENABLE_ORDINARY_AUTORUN),.ENABLE_NORMAL_CAPTURE(ENABLE_PS_NORMAL_TASK_REQUEST),.ENABLE_RAW_DIAGNOSTICS(ENABLE_MIC_RAW_DIAGNOSTICS)) u_source(
  .normal_capture_valid(ps_mic_request),.normal_capture_epoch(ps_mic_epoch),.normal_capture_model(ps_mic_model),.normal_capture_ready(ps_mic_ready),.normal_result_valid(ps_mic_result_valid),.normal_result_error(ps_mic_result_error),
  .clk(clk),.security_reset_n(security_reset_n),.cancel(abort_execution),.debug_command(debug_command),.debug_resume_epoch(debug_resume_epoch),
  .debug_key(debug_key),.debug_session_id(debug_session_id),.debug_key_fingerprint(debug_key_fingerprint),.base_ack_word(base_ack),
  .controller_authorized(controller_authorized),.model_authorized(authorized),.guard_key_valid(key_valid),.admission_blocked(auto_busy||auto_flow_block||stage!=IDLE),
  .controller_epoch(controller_epoch),.model_epoch(model_epoch),.controller_session_id(controller_session_id),
  .audio_job_valid(mic_audio_job_valid),.audio_job_ready(audio_job_ready),.audio_context_valid(audio_mode&&authorized&&key_valid&&!root_cancel),.accepted_audio_context(audio_context),
  .audio_pool_granted(audio_pool_granted),.bank_drained(mic_b_drained),.mic_sd(mic_sd),.mic_bclk(mic_bclk),.mic_ws(mic_ws),
  .b_write(mic_b_write),.b_write_accepted(mic_b_write_accepted),.b_write_address(mic_b_write_address),.b_write_data(mic_b_write_data),
  .b_read(mic_b_read),.b_read_accepted(mic_b_read_accepted),.b_read_address(mic_b_read_address),.b_response_valid(mic_b_response_valid),.b_response_ready(mic_b_response_ready),.b_response_data(mic_b_read_data),
  .pcm_valid(mic_pcm_valid),.pcm_ready(pcm_ready),.pcm_data(mic_pcm_data),.pcm_index(mic_pcm_index),.pcm_last(mic_pcm_last),.pcm_context(mic_pcm_context),
  .trusted_revoke(mic_source_revoke),.ack_word(mic_audio_ack),.busy(mic_source_busy),.resource_quiescent(mic_source_quiet),.active_clip(mic_source_active),.samples_sent(mic_samples),.actual_B_committed_words(),.discarded_local_words(),.raw_diagnostic_snapshot(mic_raw_diagnostic_words));
end else begin:g_debug_pcm_original
 assign mic_raw_diagnostic_words=512'd0;
 assign ps_mic_ready=0;assign ps_mic_result_valid=0;assign ps_mic_result_error=8'h07;
 assign mic_bclk=0;assign mic_ws=0;assign mic_audio_job_valid=0;assign mic_pcm_valid=0;assign mic_pcm_data=0;assign mic_pcm_index=0;assign mic_pcm_last=0;assign mic_pcm_context=0;
 assign mic_source_revoke=0;assign mic_audio_ack=0;assign mic_source_busy=0;assign mic_source_quiet=1;assign mic_source_active=0;assign mic_samples=0;
 assign mic_b_write=0;assign mic_b_read=0;assign mic_b_write_address=0;assign mic_b_read_address=0;assign mic_b_write_data=0;assign mic_b_response_ready=0;
end endgenerate
trusted_reset_session_controller #(.PRIVATE_AUTH_COFACTOR(CLOSED_OUTPUT_FAULT_COFACTOR)) u_root(.control_root_run_scope_ff(ctl_root_run_scope),
 .private_ps_reset_n(ps_reset_f0_for_cofactor),.private_trusted_revoke(trusted_revoke||audio_source_revoke||f0_lease_revoke||hard_fault||stage_fault),.private_authorized(f0_root_authorized),.private_cancel(f0_root_cancel),
 .clk(clk),.trusted_por_n(trusted_por_n),.clock_locked(clock_locked),.ps_reset_n(ps_reset_n),.trusted_revoke(trusted_revoke||audio_source_revoke||lease_revoke||hard_fault||stage_fault),
 .guard_quiescent(all_quiescent),.axi_quiescent(all_quiescent),.consumer_quiescent(all_quiescent),
 .provision_valid(provision_valid),.provision_ready(provision_ready),.trusted_fresh_key_ready(trusted_fresh_key_ready),.provision_session_id(provision_session_id),.provision_key_fingerprint(provision_key_fingerprint),.provision_accepted(provision_accepted),.provision_rejected(provision_rejected),
 .trusted_resume_valid(trusted_resume_valid),.trusted_resume_ready(resume_ready),.trusted_resume_epoch(trusted_resume_epoch),.trusted_resume_session_id(trusted_resume_session_id),.resume_accepted(resume_accepted),.resume_rejected(resume_rejected),
 .consumer_done(job_done),.accepted_done(),.security_reset_n(security_reset_n),.arith_reset_n(arith_reset_n),.authorized(controller_authorized),.key_session_valid(controller_key_session_valid),.cancel(root_cancel),.commit_allowed(commit_allowed),
 .authorization_epoch(controller_epoch),.session_id(controller_session_id),.key_fingerprint(controller_key_fingerprint),.quiescent(root_quiet),.draining(draining),.epoch_exhausted(epoch_exhausted),.session_exhausted(session_exhausted),.drain_timed_out(drain_timed_out),.locked_fault(locked_fault));
trusted_runtime_model_lease #(.PRIVATE_AUTH_COFACTOR(CLOSED_OUTPUT_FAULT_COFACTOR)) u_model_lease(
 .private_root_authorized(f0_root_authorized),.private_stop(f0_root_cancel||!ps_reset_f0_for_cofactor),.private_raw_model_authorized(f0_raw_model),.private_model_verification_start(f0_model_verification),.private_authorized(legacy_f0_authorized),.private_revoke(legacy_f0_lease_revoke),
 .clk(clk),.security_reset_n(security_reset_n),.root_authorized(controller_authorized),.root_key_session_valid(key_valid),.stop(root_cancel||!ps_reset_n),.runtime_epoch(controller_epoch),.key_session_id(controller_session_id),
 .raw_model_authorized(raw_model_authorized),.model_epoch(model_epoch),.model_verification_start(model_verification_start),.feeder_cancelled(feeder_cancelled),.model_fault(service_fault||hard_fault),.all_quiescent(all_quiescent),
 .authorized(legacy_authorized),.revoke(legacy_lease_revoke),.valid(model_lease_valid),.bound_model_epoch(bound_model_epoch),.bound_runtime_epoch(bound_runtime_epoch),.bound_key_session(bound_key_session));
// Do not feed !root_authorized to the hub: initial pre-resume SLH verification
// must remain possible. A real revocation cancels until the hub actually drains,
// then permits a fresh signature while inference remains denied by the root.
reg cancel_model,previous_root_authorized;
assign model_cancellation_pending=cancel_model||!ps_reset_n;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)begin cancel_model<=0;previous_root_authorized<=0;end
 else begin
  previous_root_authorized<=controller_authorized;
  if(lease_revoke||(previous_root_authorized&&!controller_authorized)||!ps_reset_n||global_fault)cancel_model<=1;
  else if(hub_quiescent)cancel_model<=0;
 end
end
reg vision_launched,camera_launched;
assign stage_fault=(camera_launched&&stage==CAPTURE&&camera_fault)||(vision_launched&&stage==VISION&&(vision_failed||vision_fault))||(audio_launched&&stage==AUDIO&&audio_fault)||(audio_mode&&stage==AUDIO&&!audio_launched&&audio_elapsed>=64'd100000000);
assign abort_execution=execution_root_cancel||!execution_authorized||hard_fault||stage_fault;
wire [1:0] desired_hp_owner=audio_mode?2'd3:(stage==IDLE||stage==CAPTURE)?2'd1:2'd2;
wire hp_owner_ready;
assign base_camera_go_ready=!auto_flow_block&&!audio_job_valid&&stage==IDLE&&camera_go_ready&&hp_owner_ready&&hp_committed_owner==1&&shared_mac_quiet&&authorized&&key_valid&&!global_fault&&external_memory_available&&(ENABLE_ORDINARY_PREVIEW==0||ordinary_nn_request_ready);
wire camera_go;

ordinary_root_go_source_select #(.ENABLE_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY)) replay_select(
 .base_camera_go_ready(base_camera_go_ready&&(!auto_busy||auto_offer)),.normal_request_valid((trusted_job_request&&!auto_busy)||auto_offer),
 .private_request_valid(replay_private_request&&!auto_busy),.private_active(replay_active),
 .normal_request_ready(normal_selected_ready),.private_request_ready(replay_private_ready),
 .camera_go_accepted(camera_go),.private_mode_accepted(replay_private_selected));
assign trusted_job_ready=normal_selected_ready&&!auto_busy;
assign replay_pending_for_root=ENABLE_ORDINARY_SLOT_REPLAY!=0&&replay_busy&&!replay_active&&!replay_receipt_valid&&
 base_camera_go_ready&&replay_selected_model==model_epoch&&ordinary_next_session!=0&&ordinary_next_frame!=0;
ordinary_slot_replay_private_control #(.ENABLE_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY)) replay_control(
 .clk(clk),.rst_n(security_reset_n),.offer_valid(replay_offer_valid),.offer_ready(replay_offer_ready),
 .offer_slot(replay_offer_slot),.offer_generation(replay_offer_generation),.offer_batch(replay_offer_batch),
 .offer_held(replay_offer_held),.offer_cache_clean(replay_offer_cache_clean),.offer_expected_model(replay_offer_expected_model),.offer_cancel(replay_offer_cancel),
 .root_grant_offer_identity(replay_root_offer_identity),.pending_offer_identity(replay_pending_offer_identity),.pending_offer_live(replay_pending_offer_live),
 .root_grant(replay_root_request),.root_cancel(root_cancel||ctl_actor_cancel[0]||(ENABLE_ORDINARY_PREVIEW!=0&&ordinary_nn_abort)),.authorized(authorized&&!global_fault),.key_valid(key_valid),.model_valid(model_lease_valid),
 .current_epoch(authorization_epoch),.current_model(model_epoch),.current_key_session(key_session_id),
 .next_exec_session(ordinary_next_session),.next_exec_frame(ordinary_next_frame),
 .camera_go_valid(replay_private_request),.camera_go_ready(replay_private_ready),.normal_go_block(replay_active),
 .selected_slot(replay_selected_slot),.selected_generation(replay_selected_generation),.selected_batch(replay_selected_batch),
 .selected_held(replay_selected_held),.selected_cache_clean(replay_selected_clean),.selected_expected_model(replay_selected_model),.selected_token(replay_token),
 .execution_session(replay_exec_session),.execution_frame(replay_exec_frame),.execution_epoch(replay_exec_epoch),.execution_model(replay_exec_model),.execution_key_session(replay_exec_key),
 .execution_accepted(replay_execution_accepted),.camera_stop_requested(replay_stop),
 .camera_completion_valid(replay_terminal),.camera_completion_failed(replay_terminal_failed),.camera_error(replay_terminal_error),
 .completed_token(replay_terminal_token),.completed_session(replay_terminal_session),.completed_frame(replay_terminal_frame),.completed_epoch(replay_terminal_epoch),
 .actual_io_drained(replay_io_drained),.receipt_valid(replay_receipt_valid),.receipt_failed(replay_receipt_failed),.receipt_error(replay_receipt_error),
 .receipt_ack(replay_receipt_ack),.receipt_ack_token(replay_receipt_ack_token),.busy(replay_busy),.exhausted(replay_exhausted),.rejected_late_completion());
ordinary_replay_read64_to256 replay_width(
 .clk(clk),.rst_n(security_reset_n),.S_ARADDR(slot_araddr),.S_ARLEN(slot_arlen),.S_ARSIZE(slot_arsize),.S_ARBURST(slot_arburst),.S_ARVALID(slot_arvalid),.S_ARREADY(slot_arready),
 .S_RDATA(slot_rdata),.S_RRESP(slot_rresp),.S_RLAST(slot_rlast),.S_RVALID(slot_rvalid),.S_RREADY(slot_rready),
 .M_ARADDR(slot_m_araddr),.M_ARLEN(slot_m_arlen),.M_ARSIZE(slot_m_arsize),.M_ARBURST(slot_m_arburst),.M_ARVALID(slot_m_arvalid),.M_ARREADY(slot_m_arready),
 .M_RDATA(slot_m_rdata),.M_RRESP(slot_m_rresp),.M_RLAST(slot_m_rlast),.M_RVALID(slot_m_rvalid),.M_RREADY(slot_m_rready),.quiescent(replay_converter_quiet),.fault(replay_converter_fault));
ordinary_camera_read_submux #(.ENABLE_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY)) replay_reads(
 .clk(clk),.rst_n(security_reset_n),.A_ARADDR(c_ARADDR),.A_ARLEN(c_ARLEN),.A_ARSIZE(c_ARSIZE),.A_ARBURST(c_ARBURST),.A_ARVALID(c_ARVALID),.A_ARREADY(c_ARREADY),
 .A_RDATA(c_RDATA),.A_RRESP(c_RRESP),.A_RLAST(c_RLAST),.A_RVALID(c_RVALID),.A_RREADY(c_RREADY),.A_quiescent(camera_backend_quiet),
 .B_ARADDR(slot_m_araddr),.B_ARLEN(slot_m_arlen),.B_ARSIZE(slot_m_arsize),.B_ARBURST(slot_m_arburst),.B_ARVALID(slot_m_arvalid),.B_ARREADY(slot_m_arready),
 .B_RDATA(slot_m_rdata),.B_RRESP(slot_m_rresp),.B_RLAST(slot_m_rlast),.B_RVALID(slot_m_rvalid),.B_RREADY(slot_m_rready),
 .M_ARADDR(camread_araddr),.M_ARLEN(camread_arlen),.M_ARSIZE(camread_arsize),.M_ARBURST(camread_arburst),.M_ARVALID(camread_arvalid),.M_ARREADY(camread_arready),
 .M_RDATA(camread_rdata),.M_RRESP(camread_rresp),.M_RLAST(camread_rlast),.M_RVALID(camread_rvalid),.M_RREADY(camread_rready),.quiescent(replay_submux_quiet),.fault(replay_submux_fault));

assign observation_frame_start=camera_go;
generate if(ENABLE_FIRST_OBSERVED_FAULT_DIAGNOSTIC!=0)begin:g_first_observed_fault
 // Diagnostic data only. First sampled nonzero combination after actual GO;
 // same-edge multiple leaves remain a bitmap, not an asserted causal priority.
 reg armed,valid;reg[2:0]first_stage,first_auto;reg[19:0]first_leaves;
 wire[19:0]leaves={
  (trusted_revoke||audio_source_revoke||feeder_cancelled||(audio_mode&&stage==AUDIO&&!audio_launched&&audio_elapsed>=64'd100000000)),
  (ctl_phase_leaf||ctl_other_fault),outputs_fault_for_cofactor,service_fault,
  audio_fault,vision_failed,vision_fault,camera_fault,
  ordinary_preview_diagnostic_fault_leaves[4:0],av_protocol_fault,hp_fault,
  shared_mac_fault,hub_fault,locked_fault,replay_submux_fault,replay_converter_fault};
 always@(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin armed<=0;valid<=0;first_stage<=0;first_auto<=0;first_leaves<=0;end
  else begin
   if(camera_go||audio_job_accepted)armed<=1;
   if(!valid&&(armed||camera_go||audio_job_accepted)&&(|leaves))begin
    valid<=1;first_stage<=stage;first_auto<=ordinary_flow_status[6:4];first_leaves<=leaves;
   end
  end
 end
 assign observation_next_capture_status={valid,first_stage,first_leaves,first_auto,audio_mode,camera_active,capture_next_exhausted,authorized,(trusted_job_ready&&!capture_next_exhausted)};
end else begin:g_original_next_capture_status
assign observation_next_capture_status={27'd0,audio_mode,camera_active,capture_next_exhausted,authorized,(trusted_job_ready&&!capture_next_exhausted)};
end endgenerate
wire vision_job_valid=camera_job_valid&&stage==VISION&&hp_owner_ready&&hp_committed_owner==2&&authorized&&key_valid&&!global_fault;
assign camera_job_ready=vision_job_ready&&stage==VISION&&hp_owner_ready&&hp_committed_owner==2&&authorized&&key_valid&&!global_fault;
assign observation_ingress_done=vision_job_valid&&vision_job_ready;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)stage<=IDLE;
 else if(abort_execution&&stage!=IDLE)stage<=DRAIN;
 else case(stage)
  IDLE:if(audio_job_accepted)stage<=AUDIO;else if(camera_go)stage<=CAPTURE;
  CAPTURE:if(camera_job_valid&&camera_resources_quiet)stage<=VISION;
  VISION:if(vision_done||vision_failed)stage<=DRAIN;
  AUDIO:if(audio_done||audio_fault)stage<=DRAIN;
  DRAIN:if(!camera_active&&vision_quiescent&&audio_quiescent&&audio_source_quiet&&camera_resources_quiet&&hp_quiet&&hub_quiescent)stage<=IDLE;
 endcase
end
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)vision_launched<=0;
 else if(stage==IDLE)vision_launched<=0;
 else if(vision_job_valid&&vision_job_ready)vision_launched<=1;
end
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)camera_launched<=0;
 else if(camera_go)camera_launched<=0;
 else if(observation_capture_start)camera_launched<=1;
end
// The coordinator emits its completed frame count only for a matching actual
// child completion after all accepted ingress/vision work has drained.
reg [31:0] previous_completed;
assign job_done=((completed_frames!=previous_completed)||audio_record_commit)&&authorized&&key_valid&&!global_fault;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)previous_completed<=0;else previous_completed<=completed_frames;
end
// All three HP client idle conditions already occur in this conjunction.
// Keep original hp_quiet for arbitration/drain; only eliminate redundant
// selected-client quiet here, preserving actual channel credits/AXI offers.
// Global-only absorption, with all seven model actors independently quiet.
assign all_quiescent=!camera_active&&vision_actors_quiescent&&camera_resources_quiet&&hp_channels_quiet&&hub_registered_quiescent&&external_resources_quiescent&&audio_quiescent&&audio_source_quiet&&(ENABLE_ORDINARY_PREVIEW==0||ordinary_preview_quiet)&&(PIPELINED_TRUSTED_CONTROL==0||ctl_pipeline_retired);

assign audio_job_ready=!auto_busy&&!auto_flow_block&&stage==IDLE&&!audio_mode&&camera_quiescent&&vision_quiescent&&camera_resources_quiet&&hp_quiet&&hub_quiescent&&audio_quiescent&&authorized&&key_valid&&!global_fault&&external_memory_available&&audio_generation!=32'hffffffff&&(ENABLE_ORDINARY_PREVIEW==0||ordinary_preview_quiet);
assign audio_job_accepted=audio_job_valid&&audio_job_ready;
assign audio_start_valid=stage==AUDIO&&!audio_launched&&hp_committed_owner==3&&hp_owner_ready&&audio_pool_granted&&committed_model_owner==1&&authorized&&key_valid&&!abort_execution;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)begin audio_mode<=0;audio_launched<=0;audio_context<=0;audio_generation<=0;audio_elapsed<=0;audio_total_cycles<=0;audio_post_pcm_cycles<=0;audio_sequence<=0;av_protocol_fault<=0;end
 else begin
  if(av_raw_protocol_violation||pool_protocol_violation)av_protocol_fault<=1;
  if(audio_job_accepted)begin audio_mode<=1;audio_launched<=0;audio_generation<=audio_generation+1;audio_context<={model_epoch,authorization_epoch,32'd2,audio_generation+32'd1,audio_generation+32'd1,key_session_id};audio_elapsed<=0;end
  else if(audio_mode)audio_elapsed<=audio_elapsed+1;
  if(audio_start_valid&&audio_start_ready)audio_launched<=1;
  if(audio_record_commit)begin audio_total_cycles<=audio_elapsed;audio_post_pcm_cycles<=audio_current_post_pcm_cycles;audio_sequence<=audio_sequence+1;end
  if(stage==DRAIN&&!camera_active&&vision_quiescent&&audio_quiescent&&audio_source_quiet&&camera_resources_quiet&&hp_quiet&&hub_quiescent)begin audio_mode<=0;audio_launched<=0;end
 end
end
assign audio_record_visible=audio_raw_record_visible&&!av_raw_protocol_violation&&!service_protocol_violation&&!pool_protocol_violation&&(PIPELINED_TRUSTED_CONTROL==0||execution_authorized);
assign audio_record_commit=audio_raw_record_commit&&!av_raw_protocol_violation&&!service_protocol_violation&&!pool_protocol_violation&&(PIPELINED_TRUSTED_CONTROL==0||execution_authorized);
assign audio_record_context=audio_record_visible?audio_raw_record_context:288'd0;
assign audio_record_class=audio_record_visible?audio_raw_record_class:7'd0;
assign audio_record_score=audio_record_visible?audio_raw_record_score:32'd0;

wire [2:0] service_owner;
wire [3:0] service_page_request,service_cache_read,service_page_ready,service_cache_read_valid;
wire [127:0] service_expected_pages;wire [39:0] service_cache_addresses;
wire service_page_done,service_cache_valid;wire [31:0] service_cached_page,service_cache_read_data;
wire [1:0] fetch_valid,fetch_ready;wire [63:0] fetch_page_index,fetch_page_address,fetch_proof_address;

assign service_committed_owner=committed_model_owner;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)committed_model_owner<=0;
 else if(hub_quiescent)committed_model_owner<=service_owner;
end

wire[2:0]vision_service_owner;wire[3:0]vision_service_page_request,vision_service_cache_read;
wire[127:0]vision_service_expected_pages;wire[39:0]vision_service_cache_addresses;
wire[1:0]vision_fetch_valid;wire[63:0]vision_fetch_page_index,vision_fetch_page_address,vision_fetch_proof_address;
assign service_owner=audio_mode?3'd1:vision_service_owner;
assign service_page_request=audio_mode?{3'd0,a_page_request}:vision_service_page_request;
assign service_cache_read=audio_mode?{3'd0,a_cache_read}:vision_service_cache_read;
assign service_expected_pages=audio_mode?{96'd0,a_expected_page}:vision_service_expected_pages;
assign service_cache_addresses=audio_mode?{30'd0,a_cache_address}:vision_service_cache_addresses;
assign fetch_valid=audio_mode?{1'b0,a_fetch_valid}:vision_fetch_valid;
assign fetch_page_index=audio_mode?{32'd0,a_fetch_page}:vision_fetch_page_index;
assign fetch_page_address=audio_mode?{32'd0,a_fetch_address}:vision_fetch_page_address;
assign fetch_proof_address=audio_mode?{32'd0,a_fetch_proof}:vision_fetch_proof_address;
assign a_page_ready=audio_mode&&committed_model_owner==1&&service_page_ready[0];
assign a_read_valid=audio_mode&&service_cache_read_valid[0];assign a_fetch_ready=audio_mode&&fetch_ready[0];
assign av_raw_protocol_violation=(audio_mode&&(vision_service_page_request!=0||vision_service_cache_read!=0||vision_fetch_valid!=0||v_mac_request))||(!audio_mode&&(a_page_request||a_cache_read||a_fetch_valid||a_mac_request));
trusted_model_security_hub_stable #(.PRIVATE_AUTH_COFACTOR(CLOSED_OUTPUT_FAULT_COFACTOR)) u_model(
 .control_policy_authority_ff(ctl_policy_ff),.control_phase_fault_leaf(ctl_phase_leaf),.control_other_fault(ctl_other_fault),.control_cancel_public(ctl_cancel_public),.control_cancel_private(ctl_cancel_private),.control_verify_public_nophase(ctl_verify_public_nophase),.control_verify_private_nophase(ctl_verify_private_nophase),
 .private_trusted_cancel(cancel_model||!ps_reset_f0_for_cofactor),.private_raw_model_authorized(legacy_f0_raw_model),.private_model_verification_start(legacy_f0_model_verify),
 .clk(clk),.security_reset_n(security_reset_n),.trusted_cancel(model_cancellation_pending),.trusted_selected_owner(committed_model_owner),
 .page_request(service_page_request),.expected_pages(service_expected_pages),.cache_read(service_cache_read),.cache_addresses(service_cache_addresses),.page_ready(service_page_ready),.read_valid(service_cache_read_valid),
 .cache_valid(service_cache_valid),.cached_page_index(service_cached_page),.cache_read_data(service_cache_read_data),.page_done(service_page_done),.service_busy(service_busy),.service_fault(service_fault),
 .fetch_valid(fetch_valid),.fetch_page_index(fetch_page_index),.fetch_page_address(fetch_page_address),.fetch_proof_address(fetch_proof_address),.fetch_ready(fetch_ready),
 .PS_AWADDR(PS_AWADDR),.PS_AWVALID(PS_AWVALID),.PS_AWREADY(PS_AWREADY),.PS_WDATA(PS_WDATA),.PS_WSTRB(PS_WSTRB),.PS_WVALID(PS_WVALID),.PS_WREADY(PS_WREADY),.PS_BRESP(PS_BRESP),.PS_BVALID(PS_BVALID),.PS_BREADY(PS_BREADY),
 .PS_ARADDR(PS_ARADDR),.PS_ARVALID(PS_ARVALID),.PS_ARREADY(PS_ARREADY),.PS_RDATA(PS_RDATA),.PS_RRESP(PS_RRESP),.PS_RVALID(PS_RVALID),.PS_RREADY(PS_RREADY),
 .raw_model_authorized(legacy_raw_model),.model_epoch(model_epoch),.slh_busy(slh_busy),.feeder_quiescent(feeder_quiescent),.hub_quiescent(hub_quiescent),.hub_registered_quiescent(hub_registered_quiescent),.hub_fault(hub_fault),.protocol_violation(service_protocol_violation),
 .observation_page_accept(observation_page_accept),.observation_page_index(observation_page_index),.observation_model_address(observation_model_address),.observation_proof_address(observation_proof_address),.observation_page_input_wait(observation_page_input_wait),
 .model_verification_start(legacy_model_verify),.feeder_cancelled(feeder_cancelled),.signature_error(signature_error),.policy_error(policy_error),.page_error(page_error),.feeder_error(feeder_error));

wire request_valid,request_ready,request_write,response_verified_valid,response_verified_ready,response_error,guard_context_live,guard_quiescent;
 wire [31:0] request_session,request_frame,request_epoch,request_version,request_address,request_tensor_mask,request_strobe;
 wire [15:0] request_role,request_shape;wire [255:0] request_data,response_data;
wire trusted_go=camera_go;wire trusted_stop=ctl_actor_cancel[0]||(ENABLE_ORDINARY_PREVIEW!=0&&ordinary_nn_abort)||replay_stop;
wire rst_n=security_reset_n;
wire go_ready,active_unused,fault_unused,quiescent_unused;
wire [31:0] job_session,job_frame,job_epoch,job_base;
wire job_cancel,job_valid,job_ready,job_quiescent,job_fault;
wire [31:0] job_done_session,job_done_frame;
wire camera_child_done;
assign camera_go_ready=go_ready;
assign camera_job_valid=job_valid;assign camera_job_session=job_session;assign camera_job_frame=job_frame;assign camera_job_epoch=job_epoch;assign camera_job_base=job_base;
assign job_ready=camera_job_ready;assign camera_job_cancel=job_cancel;
assign job_quiescent=vision_actors_quiescent&&hub_registered_quiescent&&hp_quiet&&shared_mac_quiet;
// synthesis translate_off
always @(posedge clk or negedge clk)if(security_reset_n&&
 (vision_quiescent!==(vision_actors_quiescent&&hub_registered_quiescent)))
 $fatal(1,"CLOSED_AV_VISION_QUIET_PRECONDITION_VIOLATED");
// synthesis translate_on
assign job_fault=stage_fault||hard_fault;
assign job_done_session=record_session;assign job_done_frame=record_frame;
assign camera_child_done=vision_done&&record_visible&&authorized&&key_valid&&!global_fault;
ordinary_trusted_camera_frame_job_slot_replay #(.EXTERNAL_TUPLES(ENABLE_ORDINARY_PREVIEW),.CONTINUOUS_RAW_WIRE(ENABLE_ORDINARY_PREVIEW),.ENABLE_ORDINARY_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY)) u_camera(
 .observation_raw_diagnostic_words(observation_raw_diagnostic_words), .observation_camera_first_cause(observation_camera_first_cause),
 .trusted_replay_mode(replay_private_selected),.replay_offer_slot(replay_selected_slot),.replay_offer_generation(replay_selected_generation),.replay_offer_batch(replay_selected_batch),
 .replay_offer_held(replay_selected_held),.replay_offer_cache_clean(replay_selected_clean),.trusted_replay_token(replay_token),.current_model(model_epoch),.current_key_session(key_session_id),.replay_ingress_io_drained(replay_io_drained),
 .replay_completion_valid(replay_terminal),.replay_completion_failed(replay_terminal_failed),.replay_error(replay_terminal_error),.replay_result_token(replay_terminal_token),.replay_result_session(replay_terminal_session),.replay_result_frame(replay_terminal_frame),.replay_result_epoch(replay_terminal_epoch),
 .SLOT_ARADDR(slot_araddr),.SLOT_ARLEN(slot_arlen),.SLOT_ARSIZE(slot_arsize),.SLOT_ARBURST(slot_arburst),.SLOT_ARVALID(slot_arvalid),.SLOT_ARREADY(slot_arready),
 .SLOT_RDATA(slot_rdata),.SLOT_RRESP(slot_rresp),.SLOT_RLAST(slot_rlast),.SLOT_RVALID(slot_rvalid),.SLOT_RREADY(slot_rready),
 .external_nn_admit(ordinary_nn_request_ready),.external_owner_opened(ordinary_nn_owner_opened),.external_next_session(ordinary_next_session),.external_next_frame(ordinary_next_frame),
 .external_raw_consume(ENABLE_ORDINARY_PREVIEW!=0&&ordinary_raw_consume_done),
 .observation_native_slot_ready(ordinary_camera_native_slot_ready),
 .observation_raw_sealed(ordinary_raw_sealed_actual),.observation_raw_writer_quiet(ordinary_raw_writer_quiet),.observation_raw_frame_ready(ordinary_raw_frame_ready_actual),.observation_raw_transport_idle(ordinary_raw_transport_idle_actual),
 .observation_raw_rgb_committed(ordinary_raw_committed),.observation_capture_session(ordinary_capture_session),.observation_capture_frame(ordinary_capture_frame),
 .observation_next_session(ordinary_camera_next_session),.observation_next_frame(ordinary_camera_next_frame),.observation_next_exhausted(ordinary_camera_next_exhausted),
 .observation_capture_start(observation_capture_start),
 .clk(clk),.rst_n(rst_n),.authorized(ctl_actor_live[0]),.key_valid(key_valid),.authorization_epoch(authorization_epoch),
 .trusted_go(trusted_go),.trusted_stop(trusted_stop),.go_ready(go_ready),.active(camera_active),.fault(camera_fault),.quiescent(camera_quiescent),
 .packet_valid(packet_valid),.packet_header(packet_header),.packet_release(packet_release),.payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
 .response_valid(response_valid),.response_ready(response_ready),.response_kind(response_kind),.response_flags(response_flags),.response_offset(response_offset),.response_frame_crc(response_frame_crc),.response_session_id(response_session_id),.response_frame_id(response_frame_id),.response_total_bytes(response_total_bytes),.response_width(response_width),.response_height(response_height),
 .job_valid(job_valid),.job_ready(job_ready),.job_session(job_session),.job_frame(job_frame),.job_epoch(job_epoch),.job_base(job_base),.job_done(camera_child_done),.job_done_session(job_done_session),.job_done_frame(job_done_frame),.job_cancel(job_cancel),.job_quiescent(job_quiescent),.job_fault(job_fault),
 .sealed_letterbox_valid(sealed_letterbox_valid),.sealed_session(sealed_session),.sealed_frame(sealed_frame),.sealed_epoch(sealed_epoch),.completed_frames(completed_frames),.rejected_completions(rejected_completions),.committed_offset(committed_offset),.received_crc(received_crc),
 .request_valid(request_valid),.request_ready(request_ready),.request_write(request_write),.request_session(request_session),.request_frame(request_frame),.request_epoch(request_epoch),.request_version(request_version),.request_role(request_role),.request_shape(request_shape),.request_address(request_address),.request_tensor_mask(request_tensor_mask),.request_strobe(request_strobe),.request_data(request_data),
 .response_verified_valid(response_verified_valid),.response_verified_ready(response_verified_ready),.response_error(response_error),.guard_context_live(guard_context_live),.response_data(response_data),.guard_quiescent(camera_guard_quiet));

wire memory_read_valid,memory_read_ready,memory_write_valid,memory_write_ready,memory_response_valid,memory_response_error;
wire [31:0] memory_data_address,memory_tag_address,memory_write_mask,memory_response_mask;
wire [255:0] memory_write_data,memory_response_data;wire [127:0] memory_write_tag,memory_response_tag;
wire mac_request,mac_ready,mac_response_valid,mac_quiescent;wire [127:0] mac_chain,mac_tag;wire [255:0] mac_data;
trusted_yolo_tensor_beat_guard guard(.clk(clk),.rst_n(rst_n),.cancel(abort_execution),.authorized(execution_authorized),.key_valid(key_valid),.authorization_epoch(authorization_epoch),.request_valid(request_valid),.request_ready(request_ready),.request_write(request_write),.request_session(request_session),.request_frame(request_frame),.request_epoch(request_epoch),.request_version(request_version),.request_role(request_role),.request_shape(request_shape),.request_address(request_address),.request_tensor_mask(request_tensor_mask),.request_strobe(request_strobe),.request_data(request_data),.response_valid(response_verified_valid),.response_ready(response_verified_ready),.response_error(response_error),.context_live(guard_context_live),.response_data(response_data),.quiescent(camera_guard_quiet),.memory_read_valid(memory_read_valid),.memory_read_ready(memory_read_ready),.memory_write_valid(memory_write_valid),.memory_write_ready(memory_write_ready),.memory_data_address(memory_data_address),.memory_tag_address(memory_tag_address),.memory_write_data(memory_write_data),.memory_write_tag(memory_write_tag),.memory_write_mask(memory_write_mask),.memory_response_valid(memory_response_valid),.memory_response_error(memory_response_error),.memory_response_data(memory_response_data),.memory_response_tag(memory_response_tag),.memory_response_mask(memory_response_mask),.backend_quiescent(camera_backend_quiet),.mac_request(mac_request),.mac_ready(mac_ready),.mac_chain(mac_chain),.mac_data(mac_data),.mac_response_valid(mac_response_valid),.mac_response_error(cbc_response_error[0]),.mac_tag(mac_tag),.mac_quiescent(mac_quiescent));


trusted_shared_cbc_adapter u_cbc(
 .clk(clk),.security_reset_n(security_reset_n),.trusted_selected_owner(hp_committed_owner==3?2'd2:hp_committed_owner),.request({audio_mode?a_mac_request:v_mac_request,mac_request}),.chains({audio_mode?a_mac_chain:v_mac_chain,mac_chain}),.data({audio_mode?a_mac_data:v_mac_data,mac_data}),
 .epoch(authorization_epoch),.key(installed_key),.key_valid(key_valid),.authorized(execution_authorized),.cancel(abort_execution),.ready(cbc_ready),.response_valid(cbc_response_valid),.response_error(cbc_response_error),.tag(cbc_tag),.quiescent(shared_mac_quiet),.fault(shared_mac_fault));
assign mac_ready=cbc_ready[0];assign mac_response_valid=cbc_response_valid[0];assign mac_tag=cbc_tag[127:0];assign mac_quiescent=shared_mac_quiet;
assign v_mac_ready=!audio_mode&&cbc_ready[1];assign v_mac_response_valid=!audio_mode&&cbc_response_valid[1];assign v_mac_response_error=cbc_response_error[1];assign v_mac_tag=cbc_tag[255:128];assign v_mac_quiescent=shared_mac_quiet;

assign a_mac_ready=audio_mode&&cbc_ready[1];assign a_mac_response_valid=audio_mode&&cbc_response_valid[1];assign a_mac_response_error=cbc_response_error[1];assign a_mac_tag=cbc_tag[255:128];

wire [31:0] c_AWADDR;
wire [7:0] c_AWLEN;
wire [2:0] c_AWSIZE;
wire [1:0] c_AWBURST;
wire c_AWVALID;
wire c_AWREADY;
wire [255:0] c_WDATA;
wire [31:0] c_WSTRB;
wire c_WLAST;
wire c_WVALID;
wire c_WREADY;
wire [1:0] c_BRESP;
wire c_BVALID;
wire c_BREADY;
wire [31:0] v_ARADDR;
wire [7:0] v_ARLEN;
wire [2:0] v_ARSIZE;
wire [1:0] v_ARBURST;
wire v_ARVALID;
wire v_ARREADY;
wire [255:0] v_RDATA;
wire [1:0] v_RRESP;
wire v_RLAST;
wire v_RVALID;
wire v_RREADY;
wire [31:0] v_AWADDR;
wire [7:0] v_AWLEN;
wire [2:0] v_AWSIZE;
wire [1:0] v_AWBURST;
wire v_AWVALID;
wire v_AWREADY;
wire [255:0] v_WDATA;
wire [31:0] v_WSTRB;
wire v_WLAST;
wire v_WVALID;
wire v_WREADY;
wire [1:0] v_BRESP;
wire v_BVALID;
wire v_BREADY;
trusted_tensor_axi_backend u_ingress_backend(
.clk(clk),
.rst_n(security_reset_n),
.read_valid(memory_read_valid),
.read_ready(memory_read_ready),
.write_valid(memory_write_valid),
.write_ready(memory_write_ready),
.data_address(memory_data_address),
.tag_address(memory_tag_address),
.write_data(memory_write_data),
.write_tag(memory_write_tag),
.write_mask(memory_write_mask),
.response_valid(memory_response_valid),
.response_error(memory_response_error),
.response_data(memory_response_data),
.response_tag(memory_response_tag),
.response_mask(memory_response_mask),
.quiescent(camera_backend_quiet),
.M_AXI_ARADDR(c_ARADDR),
.M_AXI_ARLEN(c_ARLEN),
.M_AXI_ARSIZE(c_ARSIZE),
.M_AXI_ARBURST(c_ARBURST),
.M_AXI_ARVALID(c_ARVALID),
.M_AXI_ARREADY(c_ARREADY),
.M_AXI_RDATA(c_RDATA),
.M_AXI_RRESP(c_RRESP),
.M_AXI_RLAST(c_RLAST),
.M_AXI_RVALID(c_RVALID),
.M_AXI_RREADY(c_RREADY),
.M_AXI_AWADDR(c_AWADDR),
.M_AXI_AWLEN(c_AWLEN),
.M_AXI_AWSIZE(c_AWSIZE),
.M_AXI_AWBURST(c_AWBURST),
.M_AXI_AWVALID(c_AWVALID),
.M_AXI_AWREADY(c_AWREADY),
.M_AXI_WDATA(c_WDATA),
.M_AXI_WSTRB(c_WSTRB),
.M_AXI_WLAST(c_WLAST),
.M_AXI_WVALID(c_WVALID),
.M_AXI_WREADY(c_WREADY),
.M_AXI_BRESP(c_BRESP),
.M_AXI_BVALID(c_BVALID),
.M_AXI_BREADY(c_BREADY)
);
wire [1:0] ddr_committed_owner;
wire [2:0] pool_committed_stage;
npu_full_vision_core #(.ENABLE_MIC_B(ENABLE_PHYSICAL_MIC),.CLOSED_AUDIO_PRODUCER(1),.FRONTEND_JOB_TIMEOUT_CYCLES(FRONTEND_JOB_TIMEOUT_CYCLES),.FRAME_JOB_TIMEOUT_CYCLES(FRAME_JOB_TIMEOUT_CYCLES),.PROPAGATE_FRONTEND_CANCEL(PROPAGATE_FRONTEND_CANCEL)) u_vision(
.audio_pool_claim(audio_mode),.audio_pool_access_live(execution_authorized&&key_valid&&!abort_execution),.audio_pool_quiescent(audio_quiescent&&(ENABLE_PHYSICAL_MIC==0||audio_source_quiet)),
.audio_pool_granted(audio_pool_granted),.pool_protocol_violation(pool_protocol_violation),
.audio_b_write(mic_b_write),.audio_b_read(mic_b_read),.audio_b_write_address(mic_b_write_address),.audio_b_read_address(mic_b_read_address),.audio_b_write_data(mic_b_write_data),
 .audio_b_response_ready(mic_b_response_ready),.audio_b_write_accepted(mic_b_write_accepted),.audio_b_read_accepted(mic_b_read_accepted),.audio_b_read_response_valid(mic_b_response_valid),.audio_b_drained(mic_b_drained),.audio_b_read_data(mic_b_read_data),
.audio_a_write(audio_pool_write),.audio_a_read(audio_pool_read),.audio_a_write_address(audio_pool_write_address),.audio_a_read_address(audio_pool_read_address),.audio_a_write_data(audio_pool_write_data),.audio_a_read_data(audio_pool_read_data),
.clk(clk),
.security_reset_n(security_reset_n),
.arith_reset_n(arith_reset_n),
.authorized(ctl_actor_live[1]),
.key_valid(key_valid),
.cancel(ctl_actor_cancel[1]||camera_job_cancel),
.authorization_epoch(authorization_epoch),
.key_session_id(key_session_id),
.job_valid(vision_job_valid),
.job_ready(vision_job_ready),
.job_camera_id(32'd0),
.job_session(camera_job_session),
.job_frame(camera_job_frame),
.job_epoch(camera_job_epoch),
.active(vision_active),
.quiescent(vision_quiescent),
.actors_quiescent(vision_actors_quiescent),
.job_done(vision_done),
.job_failed(vision_failed),
.fault(vision_fault),
.frame_elapsed_cycles(frame_elapsed_cycles),
.record_visible(private_record_visible),
.record_commit_pulse(private_record_commit),
.record_camera(record_camera),
.record_session(record_session),
.record_frame(record_frame),
.record_epoch(record_epoch),
.record_key_session(record_key_session),
.record_count(record_count),
.record_rois(record_rois),
.record_indices(record_indices),
.record_results(record_results),
.service_committed_owner(audio_mode?3'd0:service_committed_owner),
.service_owner(vision_service_owner),
.service_page_request(vision_service_page_request),
.service_cache_read(vision_service_cache_read),
.service_expected_pages(vision_service_expected_pages),
.service_cache_addresses(vision_service_cache_addresses),
.service_page_ready(audio_mode?4'd0:service_page_ready),
.service_cache_read_valid(audio_mode?4'd0:service_cache_read_valid),
.service_page_done(service_page_done),
.service_busy(service_busy),
.service_fault(service_fault),
.service_quiescent(hub_quiescent),
.service_cache_valid(!audio_mode&&service_cache_valid),
.service_cached_page(service_cached_page),
.service_cache_read_data(service_cache_read_data),
.fetch_valid(vision_fetch_valid),
.fetch_ready(audio_mode?2'd0:fetch_ready),
.fetch_page_index(vision_fetch_page_index),
.fetch_page_address(vision_fetch_page_address),
.fetch_proof_address(vision_fetch_proof_address),
.mac_request(v_mac_request),
.mac_chain(v_mac_chain),
.mac_data(v_mac_data),
.mac_ready(v_mac_ready),
.mac_response_valid(v_mac_response_valid),
.mac_response_error(v_mac_response_error),
.mac_tag(v_mac_tag),
.mac_quiescent(v_mac_quiescent),
.ddr_committed_owner(ddr_committed_owner),
.pool_committed_stage(pool_committed_stage),
.observation_pool_wait(observation_pool_wait),
.observation_yolo_start(observation_yolo_start),
.observation_yolo_done(observation_yolo_done),
.observation_frontend_start(observation_frontend_start),
.observation_nn_start(observation_nn_start),
.observation_nn_done(observation_nn_done),
.observation_head_start(observation_head_start),
.observation_roi_index(observation_roi_index),
.observation_generation(observation_generation),
.observation_block(observation_block),
.observation_norm3_valid(observation_norm3_valid),
.observation_norm3_done(observation_norm3_done),
.observation_norm3_address(observation_norm3_address),
.observation_norm3_data(observation_norm3_data),
.observation_logit_valid(observation_logit_valid),
.observation_logit_class(observation_logit_class),
.observation_logit_data(observation_logit_data),
.observation_result_valid(observation_result_valid),
.observation_result_class(observation_result_class),
.observation_result_logit(observation_result_logit),
.observation_consumer_session(observation_consumer_session),
.observation_consumer_frame(observation_consumer_frame),
.observation_consumer_epoch(observation_consumer_epoch),
.observation_context_camera(observation_context_camera),
.observation_context_session(observation_context_session),
.observation_context_frame(observation_context_frame),
.observation_context_epoch(observation_context_epoch),
.M_AXI_ARADDR(v_ARADDR),
.M_AXI_ARLEN(v_ARLEN),
.M_AXI_ARSIZE(v_ARSIZE),
.M_AXI_ARBURST(v_ARBURST),
.M_AXI_ARVALID(v_ARVALID),
.M_AXI_ARREADY(v_ARREADY),
.M_AXI_RDATA(v_RDATA),
.M_AXI_RRESP(v_RRESP),
.M_AXI_RLAST(v_RLAST),
.M_AXI_RVALID(v_RVALID),
.M_AXI_RREADY(v_RREADY),
.M_AXI_AWADDR(v_AWADDR),
.M_AXI_AWLEN(v_AWLEN),
.M_AXI_AWSIZE(v_AWSIZE),
.M_AXI_AWBURST(v_AWBURST),
.M_AXI_AWVALID(v_AWVALID),
.M_AXI_AWREADY(v_AWREADY),
.M_AXI_WDATA(v_WDATA),
.M_AXI_WSTRB(v_WSTRB),
.M_AXI_WLAST(v_WLAST),
.M_AXI_WVALID(v_WVALID),
.M_AXI_WREADY(v_WREADY),
.M_AXI_BRESP(v_BRESP),
.M_AXI_BVALID(v_BVALID),
.M_AXI_BREADY(v_BREADY),
.service_protocol_violation(service_protocol_violation||av_raw_protocol_violation||pool_protocol_violation)
);
trusted_stage_axi_mux #(.PORTS(3),.OWNER_W(2)) u_hp_mux(
.clk(clk),
.security_reset_n(security_reset_n),
.desired_owner(desired_hp_owner),
.client_quiescent({audio_quiescent&&shared_mac_quiet,vision_quiescent&&shared_mac_quiet,camera_resources_quiet}),
.committed_owner(hp_committed_owner),
.owner_committed(hp_owner_ready),
.quiescent(hp_quiet),
.channels_quiescent(hp_channels_quiet),
.fault(hp_fault),
.S_ARADDR({a_ARADDR,v_ARADDR,camread_araddr}),
.S_ARLEN({a_ARLEN,v_ARLEN,camread_arlen}),
.S_ARSIZE({a_ARSIZE,v_ARSIZE,camread_arsize}),
.S_ARBURST({a_ARBURST,v_ARBURST,camread_arburst}),
.S_ARVALID({a_ARVALID,v_ARVALID,camread_arvalid}),
.S_ARREADY({a_ARREADY,v_ARREADY,camread_arready}),
.S_RDATA({a_RDATA,v_RDATA,camread_rdata}),
.S_RRESP({a_RRESP,v_RRESP,camread_rresp}),
.S_RLAST({a_RLAST,v_RLAST,camread_rlast}),
.S_RVALID({a_RVALID,v_RVALID,camread_rvalid}),
.S_RREADY({a_RREADY,v_RREADY,camread_rready}),
.S_AWADDR({a_AWADDR,v_AWADDR,c_AWADDR}),
.S_AWLEN({a_AWLEN,v_AWLEN,c_AWLEN}),
.S_AWSIZE({a_AWSIZE,v_AWSIZE,c_AWSIZE}),
.S_AWBURST({a_AWBURST,v_AWBURST,c_AWBURST}),
.S_AWVALID({a_AWVALID,v_AWVALID,c_AWVALID}),
.S_AWREADY({a_AWREADY,v_AWREADY,c_AWREADY}),
.S_WDATA({a_WDATA,v_WDATA,c_WDATA}),
.S_WSTRB({a_WSTRB,v_WSTRB,c_WSTRB}),
.S_WLAST({a_WLAST,v_WLAST,c_WLAST}),
.S_WVALID({a_WVALID,v_WVALID,c_WVALID}),
.S_WREADY({a_WREADY,v_WREADY,c_WREADY}),
.S_BRESP({a_BRESP,v_BRESP,c_BRESP}),
.S_BVALID({a_BVALID,v_BVALID,c_BVALID}),
.S_BREADY({a_BREADY,v_BREADY,c_BREADY}),
.M_ARADDR(M_AXI_ARADDR),
.M_ARLEN(M_AXI_ARLEN),
.M_ARSIZE(M_AXI_ARSIZE),
.M_ARBURST(M_AXI_ARBURST),
.M_ARVALID(M_AXI_ARVALID),
.M_ARREADY(M_AXI_ARREADY),
.M_RDATA(M_AXI_RDATA),
.M_RRESP(M_AXI_RRESP),
.M_RLAST(M_AXI_RLAST),
.M_RVALID(M_AXI_RVALID),
.M_RREADY(M_AXI_RREADY),
.M_AWADDR(M_AXI_AWADDR),
.M_AWLEN(M_AXI_AWLEN),
.M_AWSIZE(M_AXI_AWSIZE),
.M_AWBURST(M_AXI_AWBURST),
.M_AWVALID(M_AXI_AWVALID),
.M_AWREADY(M_AXI_AWREADY),
.M_WDATA(M_AXI_WDATA),
.M_WSTRB(M_AXI_WSTRB),
.M_WLAST(M_AXI_WLAST),
.M_WVALID(M_AXI_WVALID),
.M_WREADY(M_AXI_WREADY),
.M_BRESP(M_AXI_BRESP),
.M_BVALID(M_AXI_BVALID),
.M_BREADY(M_AXI_BREADY)
);

trusted_audio_compute_parent #(.AUDIO_PARALLEL_CLOCK(AUDIO_PARALLEL_CLOCK)) u_audio(
.trusted_core_clock_raw(trusted_audio_raw_clk),
.clk(clk),.security_reset_n(security_reset_n),.arith_reset_n(arith_reset_n),.authorized(ctl_actor_live[2]),.key_valid(key_valid),.model_authorized(model_lease_valid&&execution_raw_model),.cancel(ctl_actor_cancel[2]),.trusted_clear_fault(audio_job_accepted),
.model_epoch(model_epoch),.runtime_epoch(authorization_epoch),.source_id(audio_context[223:192]),.clip_id(audio_context[191:160]),.generation(audio_context[159:128]),.key_session_id(key_session_id),
.start_valid(audio_start_valid),.start_ready(audio_start_ready),.pcm_valid(pcm_valid),.pcm_ready(pcm_ready),.pcm_data(pcm_data),.pcm_index(pcm_index),.pcm_last(pcm_last),.pcm_context(pcm_context),
.audio_pool_granted(audio_pool_granted),.pool_requested(audio_pool_request),.pool_read(audio_pool_read),.pool_write(audio_pool_write),.pool_read_address(audio_pool_read_address),.pool_write_address(audio_pool_write_address),.pool_read_data(audio_pool_read_data),.pool_write_data(audio_pool_write_data),
.mac_request(a_mac_request),.mac_chain(a_mac_chain),.mac_data(a_mac_data),.mac_ready(a_mac_ready),.mac_response_valid(a_mac_response_valid),.mac_response_error(a_mac_response_error),.mac_tag(a_mac_tag),.mac_quiescent(shared_mac_quiet),
.fetch_valid(a_fetch_valid),.fetch_ready(a_fetch_ready),.fetch_page_index(a_fetch_page),.fetch_page_address(a_fetch_address),.fetch_proof_address(a_fetch_proof),
.service_protocol_violation(service_protocol_violation||av_raw_protocol_violation||pool_protocol_violation),
.service_page_request(a_page_request),.service_page_ready(a_page_ready),.service_expected_page(a_expected_page),.service_page_done(service_page_done),.service_busy(service_busy),.service_fault(service_fault),.service_cache_valid(audio_mode&&committed_model_owner==1&&service_cache_valid),.service_cached_page(service_cached_page),
.service_cache_read(a_cache_read),.service_cache_address(a_cache_address),.service_cache_read_valid(a_read_valid),.service_cache_read_data(service_cache_read_data),
.observation_post_pcm_cycles(audio_current_post_pcm_cycles),.busy(audio_active),.quiescent(audio_quiescent),.done(audio_done),.fault(audio_fault),.result_visible(audio_raw_record_visible),.result_context(audio_raw_record_context),.result_class(audio_raw_record_class),.result_score(audio_raw_record_score),.result_commit_pulse(audio_raw_record_commit),.observation_phase(audio_phase),.observation_encoder_start(audio_encoder_start),.observation_encoder_done(audio_encoder_done),
.M_AXI_ARADDR(a_ARADDR),
.M_AXI_ARLEN(a_ARLEN),
.M_AXI_ARSIZE(a_ARSIZE),
.M_AXI_ARBURST(a_ARBURST),
.M_AXI_ARVALID(a_ARVALID),
.M_AXI_ARREADY(a_ARREADY),
.M_AXI_RDATA(a_RDATA),
.M_AXI_RRESP(a_RRESP),
.M_AXI_RLAST(a_RLAST),
.M_AXI_RVALID(a_RVALID),
.M_AXI_RREADY(a_RREADY),
.M_AXI_AWADDR(a_AWADDR),
.M_AXI_AWLEN(a_AWLEN),
.M_AXI_AWSIZE(a_AWSIZE),
.M_AXI_AWBURST(a_AWBURST),
.M_AXI_AWVALID(a_AWVALID),
.M_AXI_AWREADY(a_AWREADY),
.M_AXI_WDATA(a_WDATA),
.M_AXI_WSTRB(a_WSTRB),
.M_AXI_WLAST(a_WLAST),
.M_AXI_WVALID(a_WVALID),
.M_AXI_WREADY(a_WREADY),
.M_AXI_BRESP(a_BRESP),
.M_AXI_BVALID(a_BVALID),
.M_AXI_BREADY(a_BREADY));
trusted_pipeline_metrics u_metrics(
 .clk(clk),.security_reset_n(security_reset_n),.authorization_live(authorized&&key_valid),
 .frame_start(observation_frame_start),.ingress_done(observation_ingress_done),.yolo_start(observation_yolo_start),.yolo_done(observation_yolo_done),
 .frontend_start(observation_frontend_start),.nn_start(observation_nn_start),.head_start(observation_head_start),.nn_done(observation_nn_done),.roi_index(observation_roi_index),
 .record_commit(record_commit_pulse),.abort(abort_execution),.page_input_wait(observation_page_input_wait),.mac_busy(!shared_mac_quiet),.pool_wait(observation_pool_wait),
 .snapshot_valid(metrics_valid),.measurement_fault(metrics_fault),.total_cycles(metrics_total),.ingress_cycles(metrics_ingress),.yolo_cycles(metrics_yolo),.frontend_cycles(metrics_frontend),.nn_cycles(metrics_nn),.head_cycles(metrics_head),
 .page_input_wait_cycles(metrics_page_input_wait),.mac_busy_cycles(metrics_mac_busy),.pool_wait_cycles(metrics_pool_wait),.roi_measured(metrics_roi_measured),.sequence_id(metrics_sequence));

// Source-only same-current-Q counterfactual; actual FF/reset/model-cancel inputs remain original.

assign cofactor_known=(outputs_fault_for_cofactor===1'b0)||(outputs_fault_for_cofactor===1'b1);
assign execution_authorized=CLOSED_OUTPUT_FAULT_COFACTOR!=0&&cofactor_known?(!outputs_fault_for_cofactor&&f0_authorized):authorized;
assign execution_root_cancel=CLOSED_OUTPUT_FAULT_COFACTOR!=0&&cofactor_known?(outputs_fault_for_cofactor||f0_root_cancel):root_cancel;
assign execution_raw_model=CLOSED_OUTPUT_FAULT_COFACTOR!=0&&cofactor_known?(!outputs_fault_for_cofactor&&f0_raw_model):raw_model_authorized;
assign execution_authorized_probe=execution_authorized;
// synthesis translate_off
always @(posedge clk or negedge clk)if($realtime>0.0&&CLOSED_OUTPUT_FAULT_COFACTOR!=0)begin
 if(execution_authorized!==authorized)$fatal(1,"PRIVATE_GLOBAL_F_G_NOT_EXACT");
 if(execution_root_cancel!==root_cancel)$fatal(1,"PRIVATE_GLOBAL_F_RC_NOT_EXACT");
 if(execution_raw_model!==raw_model_authorized)$fatal(1,"PRIVATE_GLOBAL_F_RM_NOT_EXACT");
end
initial begin #0.001;
 if(CLOSED_OUTPUT_FAULT_COFACTOR!=0)begin
 if(execution_authorized!==authorized)$fatal(1,"PRIVATE_GLOBAL_F_G_NOT_EXACT");
 if(execution_root_cancel!==root_cancel)$fatal(1,"PRIVATE_GLOBAL_F_RC_NOT_EXACT");
 if(execution_raw_model!==raw_model_authorized)$fatal(1,"PRIVATE_GLOBAL_F_RM_NOT_EXACT");
 end
end
// synthesis translate_on
// The preview allocator owns only wire S/F. NN RAW220 ownership remains in the
// original camera/guard and NN coordinator until genuine physical retirement.
assign observation_next_capture_session=ENABLE_ORDINARY_PREVIEW!=0?ordinary_next_session:ordinary_camera_next_session;
assign observation_next_capture_frame=ENABLE_ORDINARY_PREVIEW!=0?ordinary_next_frame:ordinary_camera_next_frame;
assign capture_next_exhausted=ENABLE_ORDINARY_PREVIEW!=0?ordinary_allocator_exhausted:ordinary_camera_next_exhausted;
assign ordinary_preview_allowed=!ps_preview_inhibit&&ENABLE_ORDINARY_PREVIEW!=0&&execution_authorized&&key_valid&&!abort_execution&&!audio_mode&&!audio_job_valid&&(stage==IDLE||stage==CAPTURE||stage==VISION);
assign ordinary_nn_request=ENABLE_ORDINARY_PREVIEW!=0&&camera_go;
assign ordinary_nn_active=ENABLE_ORDINARY_PREVIEW!=0&&ordinary_nn_accepted_live;
wire ordinary_nn_error_raw=ENABLE_ORDINARY_PREVIEW!=0&&(stage_fault||hard_fault||vision_failed||abort_execution);
assign ordinary_nn_raw_sealed=ENABLE_ORDINARY_PREVIEW!=0&&ordinary_raw_sealed_actual;
assign ordinary_nn_raw_frame_ready=ENABLE_ORDINARY_PREVIEW!=0&&ordinary_raw_frame_ready_actual;
assign ordinary_nn_raw_transport_idle=ENABLE_ORDINARY_PREVIEW==0||ordinary_raw_transport_idle_actual;
// Independent of external_nn_admit/engine READY, preventing a READY cycle.
assign ordinary_nn_raw_slot_ready=ENABLE_ORDINARY_PREVIEW!=0&&stage==IDLE&&ordinary_camera_native_slot_ready;
assign ordinary_nn_raw_crc=received_crc;
// No dependency on engine resources_quiet, nn_active export, or future CLOSE.
// Every actual NN/camera/HP/hub/wire accepted tail still has to drain.
assign ordinary_actual_retired=(stage==IDLE||stage==DRAIN&&abort_execution)&&
 !camera_active&&!vision_active&&camera_quiescent&&vision_quiescent&&camera_resources_quiet&&hp_quiet&&hub_quiescent&&
 ordinary_raw_transport_idle_actual&&ordinary_packet_quiescent&&ordinary_response_quiescent&&external_resources_quiescent&&audio_quiescent&&audio_source_quiet;
// One status-return boundary breaks NN->preview->root quiet combinational chaining.
// It does not delay authoritative authorization/commit fences, raw memory
// permissions, publisher admission/snapshot or physical drain. The downstream
// preview's redundant private nn_error-based abort follows this status return;
// its direct root_live/trusted_cancel denial remains immediate and unchanged.
trusted_nn_status_return_pipeline #(.ENABLE(PIPELINED_TRUSTED_CONTROL)) nn_status_return(
 .clk(clk),.security_reset_n(security_reset_n),.job_accepted(camera_go),
 .physical_retired(ENABLE_ORDINARY_PREVIEW!=0&&ordinary_actual_retired),
 .job_error(ordinary_nn_error_raw),.retired_return(ordinary_nn_retired),.error_return(ordinary_nn_error));
always@(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)ordinary_nn_accepted_live<=0;
 else if(ENABLE_ORDINARY_PREVIEW!=0)begin
  if(camera_go)ordinary_nn_accepted_live<=1;
  else if(ordinary_actual_retired)ordinary_nn_accepted_live<=0;
 end
end


// Exact retained-SLH authority flattening. Only PRIVATE actors cancel one edge
// later; every public result/command/memory authorization retains the immediate fence.
assign record_visible=PIPELINED_TRUSTED_CONTROL!=0?(private_record_visible&&execution_authorized):private_record_visible;
assign record_commit_pulse=PIPELINED_TRUSTED_CONTROL!=0?(private_record_commit&&execution_authorized):private_record_commit;
trusted_control_authority_pipeline #(.ENABLE(PIPELINED_TRUSTED_CONTROL)) short_control(
 .clk(clk),.security_reset_n(security_reset_n),
 .legacy_authorized(legacy_authorized),.legacy_private_authorized(legacy_f0_authorized),
 .legacy_raw_model(legacy_raw_model),.legacy_private_raw_model(legacy_f0_raw_model),
 .legacy_verify_begin(legacy_model_verify),.legacy_private_verify_begin(legacy_f0_model_verify),
 .legacy_model_revoke(legacy_lease_revoke),.legacy_private_model_revoke(legacy_f0_lease_revoke),
 .legacy_execution_authorized(execution_authorized),.legacy_abort(abort_execution),
 .root_run_scope_ff(ctl_root_run_scope),.root_key_scope_ff(controller_key_session_valid),.provider_key_ff(provider_key_valid),
 .ps_live_public(ps_reset_n),.ps_live_private(ps_reset_f0_for_cofactor),
 .lease_valid_ff(model_lease_valid),.policy_authority_ff(ctl_policy_ff),
 .phase_fault_leaf(ctl_phase_leaf),.other_model_fault(ctl_other_fault),
 .service_cancel_public(ctl_cancel_public),.service_cancel_private(ctl_cancel_private),
 .verify_public_nophase(ctl_verify_public_nophase),.verify_private_nophase(ctl_verify_private_nophase),
 .feeder_cancel(feeder_cancelled),.user_revoke(trusted_revoke),.audio_revoke(audio_source_revoke),.hard_fault(hard_fault),.stage_fault(stage_fault),
 .runtime_epoch(authorization_epoch),.model_epoch(model_epoch),.bound_runtime_epoch(bound_runtime_epoch),.bound_model_epoch(bound_model_epoch),
 .key_session(key_session_id),.bound_key_session(bound_key_session),
 .outputs_fault(outputs_fault_for_cofactor),.cofactor_known(cofactor_known),.closed_output_cofactor(CLOSED_OUTPUT_FAULT_COFACTOR!=0),
 .actor_retired({(ENABLE_ORDINARY_PREVIEW==0||ordinary_preview_quiet),(audio_quiescent&&audio_source_quiet),vision_actors_quiescent,(!camera_active&&camera_quiescent&&camera_resources_quiet&&hp_channels_quiet)}),
 .authorized(authorized),.private_authorized(f0_authorized),.raw_model(raw_model_authorized),.private_raw_model(f0_raw_model),
 .verify_begin(model_verification_start),.private_verify_begin(f0_model_verification),
 .model_revoke(lease_revoke),.private_model_revoke(f0_lease_revoke),
 .short_execution_fence(ctl_short_fence),.actor_authorized(ctl_actor_live),.actor_cancel(ctl_actor_cancel),.cancellation_pipeline_retired(ctl_pipeline_retired));
// synthesis translate_off
always@(posedge clk or negedge clk)if(security_reset_n&&PIPELINED_TRUSTED_CONTROL!=0)begin
 if(authorized!==legacy_authorized)$fatal(1,"FLATTENED_RETAINED_AUTHORITY_NOT_EXACT");
 if(raw_model_authorized!==legacy_raw_model)$fatal(1,"FLATTENED_MODEL_AUTHORITY_NOT_EXACT");
 if(lease_revoke!==legacy_lease_revoke)$fatal(1,"FLATTENED_MODEL_REVOKE_NOT_EXACT");
 if(ctl_short_fence!==execution_authorized)$fatal(1,"PUBLIC_SHORT_FENCE_NOT_EXACT");
end
// synthesis translate_on

endmodule


// Status return only. This is not an authorization token or a bus-credit owner.
// The immediate public deny/commit fences are upstream and remain unchanged.
module trusted_nn_status_return_pipeline #(parameter integer ENABLE=0)(
 input wire clk,security_reset_n,job_accepted,
 input wire physical_retired,job_error,
 output wire retired_return,error_return
);
 generate if(ENABLE==0)begin:g_original
  assign retired_return=physical_retired;
  assign error_return=job_error;
 end else begin:g_status_return
  reg retired_q,error_q;
  always @(posedge clk or negedge security_reset_n)begin
   if(!security_reset_n)begin retired_q<=0;error_q<=0;end
   else if(job_accepted)begin retired_q<=0;error_q<=0;end
   else begin
    // A return can only be produced from an actual prior physical retirement.
    // Unknown retirement denies; unknown error is conservatively a failure.
    retired_q<=(physical_retired===1'b1);
    error_q<=(job_error!==1'b0);
   end
  end
  assign retired_return=retired_q;
  assign error_return=error_q;
 end endgenerate
endmodule
