`timescale 1ns/1ps
// Real frontend AXI -> signed294/315 OR source V1 / ROI V2 -> one shared MAC and raw AXI.
// No new cipher, SHA or tensor BRAM. Bind/context ports are PL-parent-only.
module trusted_frontend_memory_path #(parameter POLICY_ROM="model_object_policy_v2.mem")(
input wire  clk,
input wire  rst_n,
input wire  cancel,
input wire  authorized,
input wire  key_valid,
input wire [31:0] authorization_epoch,
input wire  producer_quiescent,
output wire  transaction_quiescent,
output wire  quiescent,
output wire  transaction_fault,
input wire [1:0] S_AXI_ARPURPOSE,
input wire [31:0] S_AXI_ARADDR,
input wire [7:0] S_AXI_ARLEN,
input wire [2:0] S_AXI_ARSIZE,
input wire [1:0] S_AXI_ARBURST,
input wire  S_AXI_ARVALID,
output wire  S_AXI_ARREADY,
output wire [255:0] S_AXI_RDATA,
output wire [1:0] S_AXI_RRESP,
output wire  S_AXI_RLAST,
output wire  S_AXI_RVALID,
input wire  S_AXI_RREADY,
input wire [31:0] S_AXI_AWADDR,
input wire [7:0] S_AXI_AWLEN,
input wire [2:0] S_AXI_AWSIZE,
input wire [1:0] S_AXI_AWBURST,
input wire  S_AXI_AWVALID,
output wire  S_AXI_AWREADY,
input wire [255:0] S_AXI_WDATA,
input wire [31:0] S_AXI_WSTRB,
input wire  S_AXI_WLAST,
input wire  S_AXI_WVALID,
output wire  S_AXI_WREADY,
output wire [1:0] S_AXI_BRESP,
output wire  S_AXI_BVALID,
input wire  S_AXI_BREADY,
output wire [31:0] M_AXI_ARADDR,
output wire [7:0] M_AXI_ARLEN,
output wire [2:0] M_AXI_ARSIZE,
output wire [1:0] M_AXI_ARBURST,
output wire  M_AXI_ARVALID,
input wire  M_AXI_ARREADY,
input wire [255:0] M_AXI_RDATA,
input wire [1:0] M_AXI_RRESP,
input wire  M_AXI_RLAST,
input wire  M_AXI_RVALID,
output wire  M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,
output wire [7:0] M_AXI_AWLEN,
output wire [2:0] M_AXI_AWSIZE,
output wire [1:0] M_AXI_AWBURST,
output wire  M_AXI_AWVALID,
input wire  M_AXI_AWREADY,
output wire [255:0] M_AXI_WDATA,
output wire [31:0] M_AXI_WSTRB,
output wire  M_AXI_WLAST,
output wire  M_AXI_WVALID,
input wire  M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,
input wire  M_AXI_BVALID,
output wire  M_AXI_BREADY,
input wire  bind_valid,
output wire  bind_ready,
output wire  bind_done,
output wire  bind_verified,
input wire [31:0] bind_camera_id,
input wire [31:0] bind_session,
input wire [31:0] bind_frame,
input wire [31:0] bind_epoch,
input wire [31:0] bind_roi_index,
input wire [15:0] bind_x,
input wire [15:0] bind_y,
input wire [15:0] bind_width,
input wire [15:0] bind_height,
input wire  release_context,
output wire  released,
output wire [31:0] context_generation,
output wire  generation_exhausted,
output wire  context_authorized,
output wire [31:0] context_camera_id,
output wire [31:0] context_session,
output wire [31:0] context_frame,
output wire [31:0] context_epoch,
output wire [31:0] context_roi_index,
output wire [15:0] context_roi_x,
output wire [15:0] context_roi_y,
output wire [15:0] context_roi_width,
output wire [15:0] context_roi_height,
output wire  exclusive_page_lock,
output wire  fetch_valid,
input wire  fetch_ready,
output wire [31:0] fetch_page_index,
output wire [31:0] fetch_page_address,
output wire [31:0] fetch_proof_address,
output wire  service_page_request,
input wire  service_page_ready,
output wire [31:0] service_expected_page,
input wire  service_page_done,
input wire  service_busy,
input wire  service_fault,
input wire  service_cache_valid,
input wire [31:0] service_cached_page,
output wire  service_cache_read,
output wire [9:0] service_cache_address,
input wire  service_cache_read_valid,
input wire [31:0] service_cache_read_data,
output wire  mac_request,
input wire  mac_ready,
output wire [127:0] mac_chain,
output wire [255:0] mac_data,
input wire  mac_response_valid,
input wire  mac_response_error,
input wire [127:0] mac_tag,
input wire  mac_quiescent
);
wire  axi_quiet;
wire  static_quiet;
wire  lease_quiet;
wire  v1_quiet;
wire  v2_quiet;
wire  v2_context_quiet;
wire  raw_quiet;
wire  all_children_quiet;
wire  v1_response_valid;
wire  v1_error;
wire  v1_live;
wire  v2_response_valid;
wire  v2_error;
wire  v2_live;
wire [1:0] policy_query_purpose;
wire  policy_query_valid;
wire  policy_query_ready;
wire  policy_query_write;
wire [31:0] policy_query_address;
wire [31:0] policy_query_strobe;
wire  policy_response_valid;
wire  policy_response_ready;
wire  policy_allowed;
wire  policy_static;
wire [15:0] policy_role;
wire [15:0] policy_shape;
wire [31:0] policy_mask;
wire [31:0] policy_static_object;
wire [31:0] policy_static_offset;
wire [31:0] policy_response_address;
wire  static_request;
wire  static_ready;
wire [31:0] static_object;
wire [31:0] static_offset;
wire [31:0] static_epoch;
wire  static_response_valid;
wire  static_verified;
wire [255:0] static_data;
wire [31:0] static_response_offset;
wire [31:0] static_response_epoch;
wire  guard_request;
wire  guard_ready;
wire  guard_write;
wire [31:0] guard_address;
wire [31:0] guard_mask;
wire [31:0] guard_strobe;
wire [31:0] guard_session;
wire [31:0] guard_frame;
wire [31:0] guard_epoch;
wire [15:0] guard_role;
wire [15:0] guard_shape;
wire [255:0] guard_data;
wire  guard_response_valid;
wire  guard_verified;
wire [255:0] guard_response_data;
wire  live;

reg [1:0] dynamic_owner;reg response_seen;
assign live=context_authorized&&authorized&&key_valid&&!cancel&&!release_context&&context_camera_id==0;
assign transaction_quiescent=axi_quiet&&static_quiet&&lease_quiet&&v1_quiet&&v2_quiet&&raw_quiet&&mac_quiescent&&dynamic_owner==0;
assign all_children_quiet=producer_quiescent&&transaction_quiescent;
assign quiescent=v2_context_quiet&&all_children_quiet;

trusted_frontend_axi_guard  axi(.clk(clk),
.rst_n(rst_n),
.job_session(context_session),
.job_frame(context_frame),
.job_epoch(context_epoch),
.context_live(live),
.external_quiescent(static_quiet&&lease_quiet&&v1_quiet&&v2_quiet&&raw_quiet&&mac_quiescent),
.quiescent(axi_quiet),
.transaction_fault(transaction_fault),
.S_AXI_ARPURPOSE(S_AXI_ARPURPOSE),
.S_AXI_ARADDR(S_AXI_ARADDR),
.S_AXI_ARLEN(S_AXI_ARLEN),
.S_AXI_ARSIZE(S_AXI_ARSIZE),
.S_AXI_ARBURST(S_AXI_ARBURST),
.S_AXI_ARVALID(S_AXI_ARVALID),
.S_AXI_ARREADY(S_AXI_ARREADY),
.S_AXI_RDATA(S_AXI_RDATA),
.S_AXI_RRESP(S_AXI_RRESP),
.S_AXI_RLAST(S_AXI_RLAST),
.S_AXI_RVALID(S_AXI_RVALID),
.S_AXI_RREADY(S_AXI_RREADY),
.S_AXI_AWADDR(S_AXI_AWADDR),
.S_AXI_AWLEN(S_AXI_AWLEN),
.S_AXI_AWSIZE(S_AXI_AWSIZE),
.S_AXI_AWBURST(S_AXI_AWBURST),
.S_AXI_AWVALID(S_AXI_AWVALID),
.S_AXI_AWREADY(S_AXI_AWREADY),
.S_AXI_WDATA(S_AXI_WDATA),
.S_AXI_WSTRB(S_AXI_WSTRB),
.S_AXI_WLAST(S_AXI_WLAST),
.S_AXI_WVALID(S_AXI_WVALID),
.S_AXI_WREADY(S_AXI_WREADY),
.S_AXI_BRESP(S_AXI_BRESP),
.S_AXI_BVALID(S_AXI_BVALID),
.S_AXI_BREADY(S_AXI_BREADY),
.policy_query_purpose(policy_query_purpose),
.policy_query_valid(policy_query_valid),
.policy_query_ready(policy_query_ready),
.policy_query_write(policy_query_write),
.policy_query_address(policy_query_address),
.policy_query_strobe(policy_query_strobe),
.policy_response_valid(policy_response_valid),
.policy_response_ready(policy_response_ready),
.policy_allowed(policy_allowed),
.policy_static(policy_static),
.policy_role(policy_role),
.policy_shape(policy_shape),
.policy_mask(policy_mask),
.policy_static_object(policy_static_object),
.policy_static_offset(policy_static_offset),
.policy_response_address(policy_response_address),
.static_request(static_request),
.static_ready(static_ready),
.static_object(static_object),
.static_offset(static_offset),
.static_epoch(static_epoch),
.static_response_valid(static_response_valid),
.static_verified(static_verified),
.static_data(static_data),
.static_response_offset(static_response_offset),
.static_response_epoch(static_response_epoch),
.guard_request(guard_request),
.guard_ready(guard_ready),
.guard_write(guard_write),
.guard_address(guard_address),
.guard_mask(guard_mask),
.guard_strobe(guard_strobe),
.guard_session(guard_session),
.guard_frame(guard_frame),
.guard_epoch(guard_epoch),
.guard_role(guard_role),
.guard_shape(guard_shape),
.guard_data(guard_data),
.guard_response_valid(guard_response_valid),
.guard_verified(guard_verified),
.guard_response_data(guard_response_data));
trusted_frontend_access_policy  policy(.clk(clk),
.rst_n(rst_n),
.context_authorized(live),
.context_roi_height(context_roi_height),
.query_valid(policy_query_valid),
.query_ready(policy_query_ready),
.query_write(policy_query_write),
.query_purpose(policy_query_purpose),
.query_address(policy_query_address),
.query_strobe(policy_query_strobe),
.response_valid(policy_response_valid),
.response_ready(policy_response_ready),
.allowed(policy_allowed),
.is_static(policy_static),
.role(policy_role),
.shape(policy_shape),
.mask(policy_mask),
.static_object(policy_static_object),
.static_offset(policy_static_offset),
.response_address(policy_response_address));
wire  lease_request;
wire  lease_ready;
wire [31:0] lease_object;
wire [31:0] lease_page;
wire [31:0] lease_epoch;
wire  lease_response_valid;
wire  lease_verified;
wire [31:0] lease_response_object;
wire [31:0] lease_response_page;
wire [31:0] lease_response_epoch;
wire  lease_still_valid;
wire  word_request;
wire  word_ready;
wire [6:0] word_offset;
wire  word_response_valid;
wire [6:0] word_response_offset;
wire [255:0] word_response_data;
wire  lease_release;
wire  release_ready;
trusted_frontend_static_reader  static_reader(.clk(clk),
.rst_n(rst_n),
.cancel(cancel||release_context),
.authorized(live),
.authorization_epoch(authorization_epoch),
.context_roi_width(context_roi_width),
.context_roi_height(context_roi_height),
.request_object(static_object),
.request_valid(static_request),
.request_ready(static_ready),
.request_offset(static_offset),
.request_epoch(static_epoch),
.response_valid(static_response_valid),
.response_verified(static_verified),
.response_offset(static_response_offset),
.response_epoch(static_response_epoch),
.response_data(static_data),
.lease_request(lease_request),
.lease_ready(lease_ready),
.lease_object(lease_object),
.lease_page(lease_page),
.lease_epoch(lease_epoch),
.lease_response_valid(lease_response_valid),
.lease_verified(lease_verified),
.lease_response_object(lease_response_object),
.lease_response_page(lease_response_page),
.lease_response_epoch(lease_response_epoch),
.lease_still_valid(lease_still_valid),
.word_request(word_request),
.word_ready(word_ready),
.word_offset(word_offset),
.word_response_valid(word_response_valid),
.word_response_offset(word_response_offset),
.word_response_data(word_response_data),
.lease_release(lease_release),
.release_ready(release_ready),
.cache_quiescent(lease_quiet),
.quiescent(static_quiet));
trusted_frontend_page_lease #(.POLICY_ROM(POLICY_ROM)) page_lease(.clk(clk),
.rst_n(rst_n),
.cancel(cancel||release_context),
.model_authorized(live),
.session_epoch(authorization_epoch),
.lease_request(lease_request),
.lease_ready(lease_ready),
.lease_object(lease_object),
.lease_page(lease_page),
.lease_epoch(lease_epoch),
.lease_response_valid(lease_response_valid),
.lease_verified(lease_verified),
.lease_response_object(lease_response_object),
.lease_response_page(lease_response_page),
.lease_response_epoch(lease_response_epoch),
.lease_still_valid(lease_still_valid),
.word_request(word_request),
.word_ready(word_ready),
.word_offset(word_offset),
.word_response_valid(word_response_valid),
.word_response_offset(word_response_offset),
.word_response_data(word_response_data),
.lease_release(lease_release),
.release_ready(release_ready),
.cache_quiescent(lease_quiet),
.exclusive_page_lock(exclusive_page_lock),
.fetch_valid(fetch_valid),
.fetch_ready(fetch_ready),
.fetch_page_index(fetch_page_index),
.fetch_page_address(fetch_page_address),
.fetch_proof_address(fetch_proof_address),
.service_page_request(service_page_request),
.service_page_ready(service_page_ready),
.service_expected_page(service_expected_page),
.service_page_done(service_page_done),
.service_busy(service_busy),
.service_fault(service_fault),
.service_cache_valid(service_cache_valid),
.service_cached_page(service_cached_page),
.service_cache_read(service_cache_read),
.service_cache_address(service_cache_address),
.service_cache_read_valid(service_cache_read_valid),
.service_cache_read_data(service_cache_read_data));
wire  v1_request_valid;
wire  v2_request_valid;
wire  v1_request_ready;
wire  v2_request_ready;
wire [255:0] v1_response_data;
wire [255:0] v2_response_data;

wire source_request=guard_role==16'h4002&&guard_shape==16'h4002&&!guard_write;
wire scratch_request=(guard_role==16'h4100&&guard_shape==16'h4100)||(guard_role==16'h4101&&guard_shape==16'h4101);
assign v1_request_valid=dynamic_owner==0&&guard_request&&source_request&&v2_quiet;
assign v2_request_valid=dynamic_owner==0&&guard_request&&scratch_request&&v1_quiet;
assign guard_ready=dynamic_owner==0&&(source_request?v1_request_ready&&v2_quiet:scratch_request?v2_request_ready&&v1_quiet:1'b0);
assign guard_response_valid=dynamic_owner==1?v1_response_valid:dynamic_owner==2?v2_response_valid:1'b0;
assign guard_verified=dynamic_owner==1?(!v1_error&&v1_live):dynamic_owner==2?(!v2_error&&v2_live):1'b0;
assign guard_response_data=dynamic_owner==2?v2_response_data:v1_response_data;
always @(posedge clk)begin
 if(!rst_n)begin dynamic_owner<=0;response_seen<=0;end
 else begin
  if(guard_request&&guard_ready)begin dynamic_owner<=source_request?1:2;response_seen<=0;end
  if(guard_response_valid)response_seen<=1;
  if(response_seen&&v1_quiet&&v2_quiet&&raw_quiet&&mac_quiescent)begin dynamic_owner<=0;response_seen<=0;end
 end
end

wire  v1_memory_read_valid;
wire  v1_memory_read_ready;
wire  v1_memory_write_valid;
wire  v1_memory_write_ready;
wire [31:0] v1_memory_data_address;
wire [31:0] v1_memory_tag_address;
wire [255:0] v1_memory_write_data;
wire [127:0] v1_memory_write_tag;
wire [31:0] v1_memory_write_mask;
wire  v1_memory_response_valid;
wire  v1_memory_response_error;
wire [255:0] v1_memory_response_data;
wire [127:0] v1_memory_response_tag;
wire [31:0] v1_memory_response_mask;
wire  v1_mac_request;
wire  v1_mac_ready;
wire [127:0] v1_mac_chain;
wire [255:0] v1_mac_data;
wire  v1_mac_response_valid;
wire  v1_mac_response_error;
wire [127:0] v1_mac_tag;
trusted_yolo_tensor_beat_guard  source_guard(.clk(clk),
.rst_n(rst_n),
.cancel(cancel||release_context),
.authorized(live),
.key_valid(key_valid),
.authorization_epoch(authorization_epoch),
.request_valid(v1_request_valid),
.request_ready(v1_request_ready),
.request_write(guard_write),
.request_session(context_session),
.request_frame(context_frame),
.request_epoch(context_epoch),
.request_version(32'd2),
.request_role(16'h4002),
.request_shape(16'h4002),
.request_address(guard_address),
.request_tensor_mask(32'hffffffff),
.request_strobe(guard_strobe),
.request_data(guard_data),
.response_valid(v1_response_valid),
.response_ready(1'b1),
.response_error(v1_error),
.context_live(v1_live),
.response_data(v1_response_data),
.quiescent(v1_quiet),
.memory_read_valid(v1_memory_read_valid),
.memory_read_ready(v1_memory_read_ready),
.memory_write_valid(v1_memory_write_valid),
.memory_write_ready(v1_memory_write_ready),
.memory_data_address(v1_memory_data_address),
.memory_tag_address(v1_memory_tag_address),
.memory_write_data(v1_memory_write_data),
.memory_write_tag(v1_memory_write_tag),
.memory_write_mask(v1_memory_write_mask),
.memory_response_valid(v1_memory_response_valid),
.memory_response_error(v1_memory_response_error),
.memory_response_data(v1_memory_response_data),
.memory_response_tag(v1_memory_response_tag),
.memory_response_mask(v1_memory_response_mask),
.backend_quiescent(raw_quiet),
.mac_request(v1_mac_request),
.mac_ready(v1_mac_ready),
.mac_chain(v1_mac_chain),
.mac_data(v1_mac_data),
.mac_response_valid(v1_mac_response_valid),
.mac_response_error(v1_mac_response_error),
.mac_tag(v1_mac_tag),
.mac_quiescent(mac_quiescent));
wire  v2_memory_read_valid;
wire  v2_memory_read_ready;
wire  v2_memory_write_valid;
wire  v2_memory_write_ready;
wire [31:0] v2_memory_data_address;
wire [31:0] v2_memory_tag_address;
wire [255:0] v2_memory_write_data;
wire [127:0] v2_memory_write_tag;
wire [31:0] v2_memory_write_mask;
wire  v2_memory_response_valid;
wire  v2_memory_response_error;
wire [255:0] v2_memory_response_data;
wire [127:0] v2_memory_response_tag;
wire [31:0] v2_memory_response_mask;
wire  v2_mac_request;
wire  v2_mac_ready;
wire [127:0] v2_mac_chain;
wire [255:0] v2_mac_data;
wire  v2_mac_response_valid;
wire  v2_mac_response_error;
wire [127:0] v2_mac_tag;
trusted_frontend_context_guard  scratch_guard(.clk(clk),
.rst_n(rst_n),
.cancel(cancel||release_context),
.authorized(authorized),
.key_valid(key_valid),
.authorization_epoch(authorization_epoch),
.request_valid(v2_request_valid),
.request_ready(v2_request_ready),
.request_write(guard_write),
.request_address(guard_address),
.request_strobe(guard_strobe),
.request_data(guard_data),
.response_valid(v2_response_valid),
.response_ready(1'b1),
.response_error(v2_error),
.context_live(v2_live),
.response_data(v2_response_data),
.memory_read_valid(v2_memory_read_valid),
.memory_read_ready(v2_memory_read_ready),
.memory_write_valid(v2_memory_write_valid),
.memory_write_ready(v2_memory_write_ready),
.memory_data_address(v2_memory_data_address),
.memory_tag_address(v2_memory_tag_address),
.memory_write_data(v2_memory_write_data),
.memory_write_tag(v2_memory_write_tag),
.memory_write_mask(v2_memory_write_mask),
.memory_response_valid(v2_memory_response_valid),
.memory_response_error(v2_memory_response_error),
.memory_response_data(v2_memory_response_data),
.memory_response_tag(v2_memory_response_tag),
.memory_response_mask(v2_memory_response_mask),
.backend_quiescent(raw_quiet),
.mac_request(v2_mac_request),
.mac_ready(v2_mac_ready),
.mac_chain(v2_mac_chain),
.mac_data(v2_mac_data),
.mac_response_valid(v2_mac_response_valid),
.mac_response_error(v2_mac_response_error),
.mac_tag(v2_mac_tag),
.mac_quiescent(mac_quiescent),
.bind_valid(bind_valid),
.bind_ready(bind_ready),
.bind_done(bind_done),
.bind_verified(bind_verified),
.bind_camera_id(bind_camera_id),
.bind_session(bind_session),
.bind_frame(bind_frame),
.bind_epoch(bind_epoch),
.bind_roi_index(bind_roi_index),
.bind_x(bind_x),
.bind_y(bind_y),
.bind_width(bind_width),
.bind_height(bind_height),
.request_kind(guard_role==16'h4100 ? 2'd0:2'd1),
.release_context(release_context),
.producer_quiescent(all_children_quiet),
.released(released),
.quiescent(v2_context_quiet),
.transaction_quiescent(v2_quiet),
.context_generation(context_generation),
.generation_exhausted(generation_exhausted),
.context_authorized(context_authorized),
.context_camera_id(context_camera_id),
.context_session(context_session),
.context_frame(context_frame),
.context_epoch(context_epoch),
.context_roi_index(context_roi_index),
.context_roi_x(context_roi_x),
.context_roi_y(context_roi_y),
.context_roi_width(context_roi_width),
.context_roi_height(context_roi_height));
wire  memory_read_valid;
assign memory_read_valid=dynamic_owner==2?v2_memory_read_valid:v1_memory_read_valid;
wire  memory_read_ready;
assign v1_memory_read_ready=dynamic_owner==1?memory_read_ready:0;
assign v2_memory_read_ready=dynamic_owner==2?memory_read_ready:0;
wire  memory_write_valid;
assign memory_write_valid=dynamic_owner==2?v2_memory_write_valid:v1_memory_write_valid;
wire  memory_write_ready;
assign v1_memory_write_ready=dynamic_owner==1?memory_write_ready:0;
assign v2_memory_write_ready=dynamic_owner==2?memory_write_ready:0;
wire [31:0] memory_data_address;
assign memory_data_address=dynamic_owner==2?v2_memory_data_address:v1_memory_data_address;
wire [31:0] memory_tag_address;
assign memory_tag_address=dynamic_owner==2?v2_memory_tag_address:v1_memory_tag_address;
wire [255:0] memory_write_data;
assign memory_write_data=dynamic_owner==2?v2_memory_write_data:v1_memory_write_data;
wire [127:0] memory_write_tag;
assign memory_write_tag=dynamic_owner==2?v2_memory_write_tag:v1_memory_write_tag;
wire [31:0] memory_write_mask;
assign memory_write_mask=dynamic_owner==2?v2_memory_write_mask:v1_memory_write_mask;
wire  memory_response_valid;
assign v1_memory_response_valid=dynamic_owner==1?memory_response_valid:0;
assign v2_memory_response_valid=dynamic_owner==2?memory_response_valid:0;
wire  memory_response_error;
assign v1_memory_response_error=memory_response_error;
assign v2_memory_response_error=memory_response_error;
wire [255:0] memory_response_data;
assign v1_memory_response_data=memory_response_data;
assign v2_memory_response_data=memory_response_data;
wire [127:0] memory_response_tag;
assign v1_memory_response_tag=memory_response_tag;
assign v2_memory_response_tag=memory_response_tag;
wire [31:0] memory_response_mask;
assign v1_memory_response_mask=memory_response_mask;
assign v2_memory_response_mask=memory_response_mask;
assign mac_request=dynamic_owner==2?v2_mac_request:v1_mac_request;
assign v1_mac_ready=dynamic_owner==1?mac_ready:0;
assign v2_mac_ready=dynamic_owner==2?mac_ready:0;
assign mac_chain=dynamic_owner==2?v2_mac_chain:v1_mac_chain;
assign mac_data=dynamic_owner==2?v2_mac_data:v1_mac_data;
assign v1_mac_response_valid=dynamic_owner==1?mac_response_valid:0;
assign v2_mac_response_valid=dynamic_owner==2?mac_response_valid:0;
assign v1_mac_response_error=mac_response_error;
assign v2_mac_response_error=mac_response_error;
assign v1_mac_tag=mac_tag;
assign v2_mac_tag=mac_tag;
trusted_tensor_axi_backend  raw_backend(.clk(clk),
.rst_n(rst_n),
.read_valid(memory_read_valid),
.read_ready(memory_read_ready),
.write_valid(memory_write_valid),
.write_ready(memory_write_ready),
.data_address(memory_data_address),
.tag_address(memory_tag_address),
.write_data(memory_write_data),
.write_tag(memory_write_tag),
.write_mask(memory_write_mask),
.response_valid(memory_response_valid),
.response_error(memory_response_error),
.response_data(memory_response_data),
.response_tag(memory_response_tag),
.response_mask(memory_response_mask),
.quiescent(raw_quiet),
.M_AXI_ARADDR(M_AXI_ARADDR),
.M_AXI_ARLEN(M_AXI_ARLEN),
.M_AXI_ARSIZE(M_AXI_ARSIZE),
.M_AXI_ARBURST(M_AXI_ARBURST),
.M_AXI_ARVALID(M_AXI_ARVALID),
.M_AXI_ARREADY(M_AXI_ARREADY),
.M_AXI_RDATA(M_AXI_RDATA),
.M_AXI_RRESP(M_AXI_RRESP),
.M_AXI_RLAST(M_AXI_RLAST),
.M_AXI_RVALID(M_AXI_RVALID),
.M_AXI_RREADY(M_AXI_RREADY),
.M_AXI_AWADDR(M_AXI_AWADDR),
.M_AXI_AWLEN(M_AXI_AWLEN),
.M_AXI_AWSIZE(M_AXI_AWSIZE),
.M_AXI_AWBURST(M_AXI_AWBURST),
.M_AXI_AWVALID(M_AXI_AWVALID),
.M_AXI_AWREADY(M_AXI_AWREADY),
.M_AXI_WDATA(M_AXI_WDATA),
.M_AXI_WSTRB(M_AXI_WSTRB),
.M_AXI_WLAST(M_AXI_WLAST),
.M_AXI_WVALID(M_AXI_WVALID),
.M_AXI_WREADY(M_AXI_WREADY),
.M_AXI_BRESP(M_AXI_BRESP),
.M_AXI_BVALID(M_AXI_BVALID),
.M_AXI_BREADY(M_AXI_BREADY));
endmodule
