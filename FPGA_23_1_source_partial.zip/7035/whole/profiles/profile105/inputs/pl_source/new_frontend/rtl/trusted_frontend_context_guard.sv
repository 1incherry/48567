`timescale 1ns/1ps
// Actual trusted ROI allocator -> fixed frontend scratch policy -> typed96 MAC.
// Bind is a PL NMS/job-parent interface, NEVER a PS register. No caller port can
// set MAC generation, ROI, role, geometry or epoch after binding. Camera source
// reads remain a separate v1 role4000 route; this owns ONLY TEMP/CROP scratch.
module trusted_frontend_context_guard #(
 parameter [31:0] MODEL_VERSION=32'd2,
 parameter [31:0] TEMP_BASE=32'h2c000000,CROP_BASE=32'h2c100000
)(
input wire  clk,
input wire  rst_n,
input wire  cancel,
input wire  authorized,
input wire  key_valid,
input wire [31:0] authorization_epoch,
input wire  request_valid,
output wire  request_ready,
input wire  request_write,
input wire [31:0] request_address,
input wire [31:0] request_strobe,
input wire [255:0] request_data,
output wire  response_valid,
input wire  response_ready,
output wire  response_error,
output wire  context_live,
output wire [255:0] response_data,
output wire  memory_read_valid,
input wire  memory_read_ready,
output wire  memory_write_valid,
input wire  memory_write_ready,
output wire [31:0] memory_data_address,
output wire [31:0] memory_tag_address,
output wire [255:0] memory_write_data,
output wire [127:0] memory_write_tag,
output wire [31:0] memory_write_mask,
input wire  memory_response_valid,
input wire  memory_response_error,
input wire [255:0] memory_response_data,
input wire [127:0] memory_response_tag,
input wire [31:0] memory_response_mask,
input wire  backend_quiescent,
output wire  mac_request,
input wire  mac_ready,
output wire [127:0] mac_chain,
output wire [255:0] mac_data,
input wire  mac_response_valid,
input wire  mac_response_error,
input wire [127:0] mac_tag,
input wire  mac_quiescent,
input wire bind_valid,output wire bind_ready,output wire bind_done,bind_verified,
input wire [31:0] bind_camera_id,bind_session,bind_frame,bind_epoch,bind_roi_index,
input wire [15:0] bind_x,bind_y,bind_width,bind_height,
input wire [1:0] request_kind,
input wire release_context,producer_quiescent,
output wire released,output wire quiescent,transaction_quiescent,
output wire [31:0] context_generation,output wire generation_exhausted,
output wire context_authorized,
output wire [31:0] context_camera_id,context_session,context_frame,context_epoch,context_roi_index,
output wire [15:0] context_roi_x,context_roi_y,context_roi_width,context_roi_height
);
wire ctx_valid,ctx_quiet,guard_quiet;
wire [31:0] ctx_camera,ctx_session,ctx_frame,ctx_epoch,ctx_roi,ctx_generation;
wire [15:0] ctx_x,ctx_y,ctx_width,ctx_height;
assign context_generation=ctx_generation;
assign context_authorized=ctx_valid;
assign context_camera_id=ctx_camera;assign context_session=ctx_session;assign context_frame=ctx_frame;assign context_epoch=ctx_epoch;assign context_roi_index=ctx_roi;
assign context_roi_x=ctx_x;assign context_roi_y=ctx_y;assign context_roi_width=ctx_width;assign context_roi_height=ctx_height;
assign quiescent=ctx_quiet&&guard_quiet&&producer_quiescent;
assign transaction_quiescent=guard_quiet;
trusted_roi_context_allocator allocator(
 .clk(clk),.rst_n(rst_n),.cancel(cancel),.authorized(authorized&&key_valid),.authorization_epoch(authorization_epoch),
 .request_valid(bind_valid),.request_ready(bind_ready),
 .request_camera_id(bind_camera_id),.request_session(bind_session),.request_frame(bind_frame),.request_epoch(bind_epoch),.request_roi_index(bind_roi_index),
 .request_x(bind_x),.request_y(bind_y),.request_width(bind_width),.request_height(bind_height),
 .response_valid(bind_done),.response_granted(bind_verified),.context_valid(ctx_valid),
 .camera_id(ctx_camera),.session_id(ctx_session),.original_frame(ctx_frame),.epoch(ctx_epoch),.roi_index(ctx_roi),.tensor_generation(ctx_generation),
 .roi_x(ctx_x),.roi_y(ctx_y),.roi_width(ctx_width),.roi_height(ctx_height),
 .release_context(release_context),.children_quiescent(guard_quiet&&producer_quiescent),.quiescent(ctx_quiet),.released(released),.generation_exhausted(generation_exhausted));
wire [31:0] temp_bytes={16'd0,ctx_height}*32'd672;
wire [32:0] address_end={1'b0,request_address}+33'd32;
wire temp_hit=request_kind==0&&request_address>=TEMP_BASE&&address_end<={1'b0,TEMP_BASE}+{1'b0,temp_bytes};
wire crop_hit=request_kind==1&&request_address>=CROP_BASE&&address_end<={1'b0,CROP_BASE}+33'd150528;
wire [15:0] selected_role=temp_hit?16'h4100:crop_hit?16'h4101:16'd0;
trusted_tensor_beat_guard_v2 #(.MODEL_VERSION(MODEL_VERSION)) guard(
 .clk(clk),
 .rst_n(rst_n),
 .cancel(cancel||release_context),
 .authorized(authorized&&ctx_valid),
 .key_valid(key_valid),
 .authorization_epoch(authorization_epoch),
 .request_valid(request_valid),
 .request_ready(request_ready),
 .request_write(request_write),
 .request_session(ctx_session),
 .request_frame(ctx_frame),
 .request_epoch(ctx_epoch),
 .request_version(MODEL_VERSION),
 .request_camera_id(ctx_camera),
 .request_generation(ctx_generation),
 .request_roi_index(ctx_roi),
 .request_stride(32'd672),
 .request_width(16'd224),
 .request_height(request_kind==0?ctx_height:16'd224),
 .request_channels(16'd3),
 .request_roi_x(ctx_x),
 .request_roi_y(ctx_y),
 .request_roi_width(ctx_width),
 .request_roi_height(ctx_height),
 .request_element_bits(8'd8),
 .request_layout(8'd1),
 .request_role(selected_role),
 .request_shape(selected_role),
 .request_address(request_address),
 .request_tensor_mask(32'hffffffff),
 .request_strobe(request_strobe),
 .request_data(request_data),
 .response_valid(response_valid),
 .response_ready(response_ready),
 .response_error(response_error),
 .context_live(context_live),
 .response_data(response_data),
 .quiescent(guard_quiet),
 .memory_read_valid(memory_read_valid),
 .memory_read_ready(memory_read_ready),
 .memory_write_valid(memory_write_valid),
 .memory_write_ready(memory_write_ready),
 .memory_data_address(memory_data_address),
 .memory_tag_address(memory_tag_address),
 .memory_write_data(memory_write_data),
 .memory_write_tag(memory_write_tag),
 .memory_write_mask(memory_write_mask),
 .memory_response_valid(memory_response_valid),
 .memory_response_error(memory_response_error),
 .memory_response_data(memory_response_data),
 .memory_response_tag(memory_response_tag),
 .memory_response_mask(memory_response_mask),
 .backend_quiescent(backend_quiescent),
 .mac_request(mac_request),
 .mac_ready(mac_ready),
 .mac_chain(mac_chain),
 .mac_data(mac_data),
 .mac_response_valid(mac_response_valid),
 .mac_response_error(mac_response_error),
 .mac_tag(mac_tag),
 .mac_quiescent(mac_quiescent)
);
endmodule
