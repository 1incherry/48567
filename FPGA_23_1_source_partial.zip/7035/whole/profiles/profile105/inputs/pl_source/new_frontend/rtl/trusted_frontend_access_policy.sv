`timescale 1ns/1ps
// Actual frontend call-site purpose + immutable bound ROI -> memory domain.
// Geometry remains virtual315, PE/position/norm parameters static294, original
// source4000 uses V1, TEMP/CROP4100/4101 use explicit ROI-generation typed96.
// context_* MUST be allocator outputs, never live PS configuration fields.
module trusted_frontend_access_policy(
 input wire clk,rst_n,context_authorized,input wire [15:0] context_roi_height,
 input wire query_valid,output wire query_ready,input wire query_write,
 input wire [1:0] query_purpose,input wire [31:0] query_address,query_strobe,
 output wire response_valid,input wire response_ready,
 output reg allowed,is_static,output reg [15:0] role,shape,
 output reg [31:0] mask,static_object,static_offset,response_address
);
 reg pending;
 assign query_ready=!pending;assign response_valid=pending;
 wire [32:0] end_address={1'b0,query_address}+33'd32;
 wire aligned=query_address[4:0]==0;
 wire static_hit=query_address>=32'h29000000&&end_address<=33'h029078000;
 wire geo_hit=(query_address>=32'h29078000&&end_address<=33'h029080c00)||
              (query_address>=32'h29082000&&end_address<=33'h02908ac00);
 wire scene_hit=query_address>=32'h22000000&&end_address<=33'h0225eec00;
 wire temp_hit=query_address>=32'h2c000000&&end_address<=33'h02c000000+{17'd0,context_roi_height}*33'd672;
 wire crop_hit=query_address>=32'h2c100000&&end_address<=33'h02c124c00;
 always @(posedge clk)begin
  if(!rst_n)begin pending<=0;allowed<=0;is_static<=0;role<=0;shape<=0;mask<=0;static_object<=0;static_offset<=0;response_address<=0;end
  else begin
   if(pending&&response_ready)pending<=0;
   if(query_valid&&query_ready)begin
    pending<=1;allowed<=0;is_static<=0;role<=0;shape<=0;mask<=32'hffffffff;
    static_object<=0;static_offset<=0;response_address<=query_address;
    if(context_authorized&&context_roi_height!=0&&context_roi_height<=1080&&aligned)begin
     if(!query_write&&query_purpose==1&&static_hit)begin allowed<=1;is_static<=1;static_object<=294;static_offset<=query_address-32'h29000000;end
     else if(!query_write&&query_purpose==2&&geo_hit)begin allowed<=1;is_static<=1;static_object<=315;static_offset<=query_address;end
     else if((query_write||query_purpose==0)&&temp_hit)begin allowed<=!query_write||query_strobe!=0;role<=16'h4100;shape<=16'h4100;end
     else if((query_write||query_purpose==0)&&crop_hit)begin allowed<=!query_write||query_strobe!=0;role<=16'h4101;shape<=16'h4101;end
     else if(!query_write&&query_purpose==0&&scene_hit)begin allowed<=1;role<=16'h4002;shape<=16'h4002;end
    end
   end
  end
 end
endmodule
