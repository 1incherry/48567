`timescale 1ns/1ps
// Fixed frontend294 + virtual geometry315 -> one shared verified page lease.
// ROI dimensions MUST come from the trusted allocator. A raw DDR geometry
// address is translated to the signed dimension profile, never dereferenced.
// Response offset echoes the original call-site offset for consumer binding.
module trusted_frontend_static_reader(
 input wire clk,rst_n,cancel,authorized,input wire [31:0] authorization_epoch,
 input wire [15:0] context_roi_width,context_roi_height,
 input wire [31:0] request_object,
 input wire request_valid,output wire request_ready,input wire [31:0] request_offset,request_epoch,
 output reg response_valid,response_verified,output reg [31:0] response_offset,response_epoch,
 output wire [255:0] response_data,
 output wire lease_request,input wire lease_ready,output wire [31:0] lease_object,lease_page,lease_epoch,
 input wire lease_response_valid,lease_verified,input wire [31:0] lease_response_object,lease_response_page,lease_response_epoch,
 input wire lease_still_valid,
 output wire word_request,input wire word_ready,output wire [6:0] word_offset,
 input wire word_response_valid,input wire [6:0] word_response_offset,input wire [255:0] word_response_data,
 output wire lease_release,input wire release_ready,input wire cache_quiescent,output wire quiescent
);
 localparam IDLE=0,LEASE=1,LEASE_REPLY=2,WORD=3,WORD_REPLY=4,RELEASE=5,WAIT_RELEASE=6,REPORT=7;
 reg [2:0] state;
 reg [31:0] object_id,real_offset;
 wire geo_x=request_offset>=32'h29078000&&request_offset<32'h29080c00;
 wire geo_y=request_offset>=32'h29082000&&request_offset<32'h2908ac00;
 wire dims_good=context_roi_width!=0&&context_roi_width<=1920&&context_roi_height!=0&&context_roi_height<=1080;
 wire request_good=(request_object==294&&request_offset<491520)||
                   (request_object==315&&dims_good&&(geo_x||geo_y));
 wire [31:0] geometry_dimension=geo_x?{16'd0,context_roi_width}:{16'd0,context_roi_height};
 wire [31:0] geometry_relative=request_offset-(geo_x?32'h29078000:32'h29082000);
 wire [31:0] derived_offset=(geometry_dimension-1)*32'd36864+geometry_relative;reg [255:0] data;reg good,aborted;
 wire stopping=cancel||!authorized||authorization_epoch!=response_epoch||aborted;
 assign request_ready=state==IDLE&&cache_quiescent;
 assign quiescent=state==IDLE&&cache_quiescent;
 assign response_data=data;
 assign lease_request=state==LEASE;
 assign lease_object=object_id;
 assign lease_page=real_offset>>12;
 assign lease_epoch=response_epoch;
 assign word_request=state==WORD;
 assign word_offset=real_offset[11:5];
 assign lease_release=state==RELEASE;
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;object_id<=0;real_offset<=0;data<=0;good<=0;aborted<=0;response_valid<=0;response_verified<=0;response_offset<=0;response_epoch<=0;end
  else begin
   response_valid<=0;response_verified<=0;
   if(state!=IDLE&&stopping)aborted<=1;
   case(state)
    IDLE:if(request_valid&&request_ready)begin
     object_id<=request_object;real_offset<=request_object==315?derived_offset:request_offset;
     response_offset<=request_offset;response_epoch<=request_epoch;data<=0;good<=0;aborted<=0;
     if(cancel||!authorized||request_epoch!=authorization_epoch||request_offset[4:0]!=0||!request_good)state<=REPORT;
     else state<=LEASE;
    end
    LEASE:if(lease_ready)state<=LEASE_REPLY;
    LEASE_REPLY:if(lease_response_valid)begin
     if(!lease_verified||lease_response_object!=object_id||lease_response_page!=lease_page||lease_response_epoch!=response_epoch||!lease_still_valid||stopping)state<=RELEASE;
     else state<=WORD;
    end
    WORD:if(word_ready)state<=WORD_REPLY;
    WORD_REPLY:if(word_response_valid)begin
     if(word_response_offset==word_offset&&lease_still_valid&&!stopping)begin data<=word_response_data;good<=1;end
     state<=RELEASE;
    end
    RELEASE:if(release_ready)state<=WAIT_RELEASE;
    WAIT_RELEASE:if(cache_quiescent)state<=REPORT;
    REPORT:begin response_valid<=1;response_verified<=good&&!stopping;state<=IDLE;end
    default:begin good<=0;state<=RELEASE;end
   endcase
  end
 end
endmodule
