`timescale 1ns/1ps
// Trusted parent-only allocation. None of the request/epoch/key-session fields
// may be driven by a PS CSR. Generations are global within the authenticated
// model epoch, independent of network frame/session, and never wrap silently.
// A production fresh boot/key session remains required across power loss.
module trusted_roi_context_allocator #(
 parameter [31:0] INITIAL_GENERATION=32'd1
)(
 input wire clk,rst_n,cancel,authorized,input wire [31:0] authorization_epoch,
 input wire request_valid,output wire request_ready,
 input wire [31:0] request_camera_id,request_session,request_frame,request_epoch,request_roi_index,
 input wire [15:0] request_x,request_y,request_width,request_height,
 output reg response_valid,response_granted,output wire context_valid,
 output reg [31:0] camera_id,session_id,original_frame,epoch,roi_index,tensor_generation,
 output reg [15:0] roi_x,roi_y,roi_width,roi_height,
 input wire release_context,children_quiescent,output wire quiescent,
 output reg released,output reg generation_exhausted
);
 reg active,draining;reg [31:0] tracked_epoch,next_generation;
 wire revoked=!authorized||authorization_epoch!=epoch;
 assign context_valid=active&&!draining&&!cancel&&!release_context&&!revoked;
 assign request_ready=!active&&!draining&&children_quiescent;
 assign quiescent=!active&&!draining&&children_quiescent;
 wire geometry_ok=request_width!=0&&request_height!=0&&request_width<=1920&&request_height<=1080&&
  ({1'b0,request_x}+{1'b0,request_width}<=17'd1920)&&({1'b0,request_y}+{1'b0,request_height}<=17'd1080);
 always @(posedge clk)begin
  if(!rst_n)begin
   active<=0;draining<=0;tracked_epoch<=0;next_generation<=INITIAL_GENERATION;generation_exhausted<=0;
   response_valid<=0;response_granted<=0;released<=0;
   camera_id<=0;session_id<=0;original_frame<=0;epoch<=0;roi_index<=0;tensor_generation<=0;
   roi_x<=0;roi_y<=0;roi_width<=0;roi_height<=0;
  end else begin
   response_valid<=0;response_granted<=0;released<=0;
   if(authorization_epoch!=tracked_epoch)begin
    tracked_epoch<=authorization_epoch;next_generation<=INITIAL_GENERATION;generation_exhausted<=0;
   end
   if(active&&(cancel||release_context||revoked))draining<=1;
   if(draining&&children_quiescent)begin active<=0;draining<=0;released<=1;end
   if(request_valid&&request_ready)begin
    response_valid<=1;
    if(authorized&&!cancel&&!release_context&&request_epoch==authorization_epoch&&authorization_epoch!=0&&
       tracked_epoch==authorization_epoch&&request_session!=0&&request_frame!=0&&request_roi_index<4&&
       geometry_ok&&!generation_exhausted&&next_generation!=0)begin
     active<=1;response_granted<=1;
     camera_id<=request_camera_id;session_id<=request_session;original_frame<=request_frame;epoch<=request_epoch;
     roi_index<=request_roi_index;tensor_generation<=next_generation;
     roi_x<=request_x;roi_y<=request_y;roi_width<=request_width;roi_height<=request_height;
     if(next_generation==32'hffffffff)generation_exhausted<=1;
     else next_generation<=next_generation+1;
    end
   end
  end
 end
endmodule
