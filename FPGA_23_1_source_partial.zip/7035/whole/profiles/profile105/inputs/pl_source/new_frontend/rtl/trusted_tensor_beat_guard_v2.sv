`timescale 1ns/1ps
// V2 typed96 MAC: explicit camera / original frame / tensor generation / ROI
// and complete geometry. Fixed96B message = header0 + header1 + payload.
// All context fields MUST come from immutable policy / trusted PL lifecycle.
// No field is a PS-programmable claim. One external SM4 service is reused.
// Fixed-size, context-bound SM4-CBC-MAC transaction controller. A separate
// trusted MAC arbiter reuses the existing v789 primitive / key source. This
// module adds no SHA, SM4, tensor BRAM or PS verdict port.
//
// Each tag covers EXACTLY96 bytes: two fixed256-bit typed headers followed by a
// complete 256-bit beat (inactive bytes canonical zero). Partial writes are
// read/verify/merge/write. Their expected predecessor mask is derived from the
// contiguous WSTRB, not supplied by DDR. Source/destination buffers must start
// aligned to 32 bytes and writes within a role must fill low to high bytes.
module trusted_tensor_beat_guard_v2 #(parameter [31:0] MODEL_VERSION=32'd2)(
 input wire clk,rst_n,cancel,authorized,key_valid,
 input wire [31:0] authorization_epoch,
 input wire request_valid,output wire request_ready,
 input wire request_write,
 input wire [31:0] request_session,request_frame,request_epoch,request_version,
 input wire [31:0] request_camera_id,request_generation,request_roi_index,request_stride,
 input wire [15:0] request_width,request_height,request_channels,request_roi_x,request_roi_y,request_roi_width,request_roi_height,
 input wire [7:0] request_element_bits,request_layout,
 input wire [15:0] request_role,request_shape,
 input wire [31:0] request_address,request_tensor_mask,request_strobe,
 input wire [255:0] request_data,
 output wire response_valid,input wire response_ready,
 output wire response_error,context_live,
 output wire [255:0] response_data,
 output wire quiescent,
 output wire memory_read_valid,input wire memory_read_ready,
 output wire memory_write_valid,input wire memory_write_ready,
 output wire [31:0] memory_data_address,memory_tag_address,
 output wire [255:0] memory_write_data,
 output wire [127:0] memory_write_tag,output wire [31:0] memory_write_mask,
 input wire memory_response_valid,memory_response_error,
 input wire [255:0] memory_response_data,
 input wire [127:0] memory_response_tag,input wire [31:0] memory_response_mask,
 input wire backend_quiescent,
 output wire mac_request,input wire mac_ready,
 output wire [127:0] mac_chain,output wire [255:0] mac_data,
 input wire mac_response_valid,mac_response_error,input wire [127:0] mac_tag,
 input wire mac_quiescent
);
 localparam IDLE=0,READ=1,READ_REPLY=2,OLD_HEADER=3,OLD_HEADER_REPLY=4,OLD_DATA=5,OLD_DATA_REPLY=6,
 NEW_HEADER=7,NEW_HEADER_REPLY=8,NEW_DATA=9,NEW_DATA_REPLY=10,WRITE=11,WRITE_REPLY=12,REPORT=13,
 OLD_CONTEXT=14,OLD_CONTEXT_REPLY=15,NEW_CONTEXT=16,NEW_CONTEXT_REPLY=17;
 reg [4:0] state;
 reg [31:0] camera_id,generation,roi_index,stride;
 reg [15:0] width,height,channels,roi_x,roi_y,roi_width,roi_height;reg [7:0] element_bits,layout;
 reg writing,bad,aborted;
 reg [31:0] session_id,frame_id,epoch,version,address,expected_mask,prior_mask,new_mask,strobe;
 reg [15:0] role,shape;
 reg [255:0] offered_data,old_data,merged_data,returned_data;
 reg [127:0] old_tag,chain,new_tag;
 wire live=authorized&&key_valid&&authorization_epoch==epoch&&!cancel&&!aborted;
 assign context_live=live;
 assign request_ready=state==IDLE&&backend_quiescent&&mac_quiescent;
 assign quiescent=state==IDLE&&backend_quiescent&&mac_quiescent;
 assign memory_read_valid=state==READ;
 assign memory_write_valid=state==WRITE;
 assign memory_data_address=address;
 // Explicit disjoint metadata map. These candidate addresses are not applied
 // to the board; the enclosing signed policy must reserve them before use.
 assign memory_tag_address=(address>=32'h2c000000)?32'h35000000+(address-32'h2c000000):
                           (address>=32'h22000000)?32'h34100000+(address-32'h22000000):
                            32'h34000000+(address-32'h21000000);
 assign memory_write_data=merged_data;
 assign memory_write_tag=new_tag;
 assign memory_write_mask=new_mask;
 assign mac_request=state==OLD_HEADER||state==OLD_CONTEXT||state==OLD_DATA||state==NEW_HEADER||state==NEW_CONTEXT||state==NEW_DATA;
 assign mac_chain=state==OLD_HEADER||state==NEW_HEADER?128'd0:chain;
 wire [31:0] header_mask=(state==OLD_HEADER||state==OLD_CONTEXT)?(writing?prior_mask:expected_mask):new_mask;
 wire [255:0] header={32'h59544d32,camera_id,session_id,frame_id,epoch,generation,roi_index,version};
 wire [255:0] geometry_header={role,shape,address,header_mask,width,height,channels,element_bits,layout,stride,roi_x,roi_y,roi_width,roi_height};
 assign mac_data=state==OLD_HEADER||state==NEW_HEADER?header:
                 state==OLD_CONTEXT||state==NEW_CONTEXT?geometry_header:(state==OLD_DATA?old_data:merged_data);
 assign response_valid=state==REPORT&&backend_quiescent&&mac_quiescent;
 assign response_error=bad;
 assign response_data=bad?256'd0:returned_data;
 function [31:0] lower_mask;
  input [31:0] mask;integer i;reg found;
  begin lower_mask=0;found=0;
   for(i=0;i<32;i=i+1)begin if(mask[i])found=1;else if(!found)lower_mask[i]=1;end
  end
 endfunction
 function contiguous;
  input [31:0] mask;integer i;reg found,ended;
  begin contiguous=mask!=0;found=0;ended=0;
   for(i=0;i<32;i=i+1)begin
    if(mask[i])begin if(ended)contiguous=0;found=1;end
    else if(found)ended=1;
   end
  end
 endfunction
 wire address_allowed=(request_address[4:0]==0)&&
  ((request_address>=32'h21000000&&request_address<32'h2104b000)||
   (request_address>=32'h22000000&&request_address<32'h225eec00)||
   (request_address>=32'h2c000000&&request_address<32'h2f000000));
 wire mask_allowed=request_tensor_mask!=0&&((request_tensor_mask&(request_tensor_mask+1))==0);
 integer b;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;writing<=0;bad<=0;aborted<=0;session_id<=0;frame_id<=0;epoch<=0;version<=0;address<=0;
   expected_mask<=0;prior_mask<=0;new_mask<=0;strobe<=0;role<=0;shape<=0;
   offered_data<=0;old_data<=0;merged_data<=0;returned_data<=0;old_tag<=0;chain<=0;new_tag<=0;
   camera_id<=0;generation<=0;roi_index<=0;stride<=0;roi_x<=0;roi_y<=0;roi_width<=0;roi_height<=0;width<=0;height<=0;channels<=0;element_bits<=0;layout<=0;
  end else begin
   if(state!=IDLE&&(cancel||!authorized||!key_valid||authorization_epoch!=epoch))aborted<=1;
   case(state)
    IDLE:if(request_valid&&request_ready)begin
     camera_id<=request_camera_id;generation<=request_generation;roi_index<=request_roi_index;stride<=request_stride;
     roi_x<=request_roi_x;roi_y<=request_roi_y;roi_width<=request_roi_width;roi_height<=request_roi_height;
     width<=request_width;height<=request_height;channels<=request_channels;element_bits<=request_element_bits;layout<=request_layout;
     writing<=request_write;session_id<=request_session;frame_id<=request_frame;
     epoch<=request_epoch;version<=request_version;role<=request_role;shape<=request_shape;address<=request_address;
     expected_mask<=request_tensor_mask;prior_mask<=lower_mask(request_strobe);
     new_mask<=lower_mask(request_strobe)|request_strobe;strobe<=request_strobe;
     offered_data<=request_data;old_data<=0;merged_data<=0;returned_data<=0;
     bad<=0;aborted<=0;chain<=0;new_tag<=0;
     if(request_roi_width==0||request_roi_height==0||request_roi_width>1920||request_roi_height>1080||
        ({1'b0,request_roi_x}+{1'b0,request_roi_width}>17'd1920)||({1'b0,request_roi_y}+{1'b0,request_roi_height}>17'd1080)||
        request_generation==0||request_width==0||request_height==0||request_channels==0||request_stride==0||request_layout==0||
        (request_element_bits!=8&&request_element_bits!=16&&request_element_bits!=32)||
        (request_roi_index>3&&request_roi_index!=32'hffffffff)||
        !authorized||!key_valid||cancel||request_version!=MODEL_VERSION||request_session==0||request_frame==0||request_role==0||request_shape==0||request_epoch!=authorization_epoch||
        !address_allowed||!mask_allowed||
        (request_write&&(!contiguous(request_strobe)||((lower_mask(request_strobe)|request_strobe)&~request_tensor_mask)!=0)))begin
      bad<=1;state<=REPORT;
     end else if(!request_write||lower_mask(request_strobe)!=0)state<=READ;
     else begin
      for(b=0;b<32;b=b+1)if(request_strobe[b])merged_data[b*8+:8]<=request_data[b*8+:8];
      state<=NEW_HEADER;
     end
    end
    READ:if(memory_read_ready)state<=READ_REPLY;
    READ_REPLY:if(memory_response_valid)begin
     if(memory_response_error||!live||memory_response_mask!=(writing?prior_mask:expected_mask))begin bad<=1;state<=REPORT;end
     else begin old_data<=memory_response_data;old_tag<=memory_response_tag;state<=OLD_HEADER;end
    end
    OLD_HEADER:if(mac_ready)state<=OLD_HEADER_REPLY;
    OLD_HEADER_REPLY:if(mac_response_valid)begin
     if(mac_response_error||!live)begin bad<=1;state<=REPORT;end
     else begin chain<=mac_tag;state<=OLD_CONTEXT;end
    end
    OLD_CONTEXT:if(mac_ready)state<=OLD_CONTEXT_REPLY;
    OLD_CONTEXT_REPLY:if(mac_response_valid)begin
     if(mac_response_error||!live)begin bad<=1;state<=REPORT;end
     else begin chain<=mac_tag;state<=OLD_DATA;end
    end
    OLD_DATA:if(mac_ready)state<=OLD_DATA_REPLY;
    OLD_DATA_REPLY:if(mac_response_valid)begin
     if(mac_response_error||!live||mac_tag!=old_tag)begin bad<=1;state<=REPORT;end
     else if(!writing)begin returned_data<=old_data;state<=REPORT;end
     else begin
      for(b=0;b<32;b=b+1)merged_data[b*8+:8]<=strobe[b]?offered_data[b*8+:8]:(prior_mask[b]?old_data[b*8+:8]:8'd0);
      state<=NEW_HEADER;
     end
    end
    NEW_HEADER:if(mac_ready)state<=NEW_HEADER_REPLY;
    NEW_HEADER_REPLY:if(mac_response_valid)begin
     if(mac_response_error||!live)begin bad<=1;state<=REPORT;end
     else begin chain<=mac_tag;state<=NEW_CONTEXT;end
    end
    NEW_CONTEXT:if(mac_ready)state<=NEW_CONTEXT_REPLY;
    NEW_CONTEXT_REPLY:if(mac_response_valid)begin
     if(mac_response_error||!live)begin bad<=1;state<=REPORT;end
     else begin chain<=mac_tag;state<=NEW_DATA;end
    end
    NEW_DATA:if(mac_ready)state<=NEW_DATA_REPLY;
    NEW_DATA_REPLY:if(mac_response_valid)begin
     if(mac_response_error||!live)begin bad<=1;state<=REPORT;end
     else begin new_tag<=mac_tag;state<=WRITE;end
    end
    WRITE:if(memory_write_ready)state<=WRITE_REPLY;
    WRITE_REPLY:if(memory_response_valid)begin bad<=memory_response_error||!live;state<=REPORT;end
    REPORT:if(response_valid&&response_ready)state<=IDLE;
    default:begin bad<=1;state<=REPORT;end
   endcase
  end
 end
endmodule
