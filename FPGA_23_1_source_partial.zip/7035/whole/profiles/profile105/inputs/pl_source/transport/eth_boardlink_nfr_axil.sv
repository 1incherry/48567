`timescale 1ns/1ps
module eth_boardlink_nfr_axil(
 input wire sys_clk_50m,sys_rst_n,
 input wire eth_rxc,input wire [3:0] eth_rxd,input wire eth_rx_ctl,
 output wire eth_txc,output wire [3:0] eth_txd,output wire eth_tx_ctl,
 output wire eth_rst_n,inout wire eth_mdio,output wire eth_mdc,
 output wire [2:0] status_led,
 output wire bus_clk125,bus_resetn,
 // Streaming frame transport uses the same proven MAC/PHY. Legacy status
 // UDP remains present, with arbitration locked for a whole offered packet.
 input wire [7:0] frame_tx_data,input wire frame_tx_valid,frame_tx_last,
 output wire frame_tx_ready,frame_tx_clk,frame_tx_reset,
 output wire [7:0] frame_rx_data,output wire frame_rx_valid,frame_rx_last,frame_rx_bad,
 output wire frame_rx_clk,frame_rx_reset,
 input wire [31:0] c_awaddr,input wire c_awvalid,output wire c_awready,
 input wire [31:0] c_wdata,input wire [3:0] c_wstrb,input wire c_wvalid,output wire c_wready,
 output wire [1:0] c_bresp,output wire c_bvalid,input wire c_bready,
 input wire [31:0] c_araddr,input wire c_arvalid,output wire c_arready,
 output wire [31:0] c_rdata,output wire [1:0] c_rresp,output wire c_rvalid,input wire c_rready
);
 wire fb_raw,fb,clk_raw,clk90_raw,clk125,clk90,clk200_raw,clk200,locked;
 MMCME2_BASE #(.CLKIN1_PERIOD(20.0),.DIVCLK_DIVIDE(1),.CLKFBOUT_MULT_F(20.0),.CLKOUT0_DIVIDE_F(8.0),.CLKOUT1_DIVIDE(8),.CLKOUT1_PHASE(90.0),.CLKOUT2_DIVIDE(5)) u_mmcm(
  .CLKIN1(sys_clk_50m),.CLKFBIN(fb),.RST(!sys_rst_n),.PWRDWN(1'b0),.CLKFBOUT(fb_raw),.CLKOUT0(clk_raw),.CLKOUT1(clk90_raw),.CLKOUT2(clk200_raw),.LOCKED(locked));
 BUFG u_fb(.I(fb_raw),.O(fb));BUFG u_clk(.I(clk_raw),.O(clk125));BUFG u_clk90(.I(clk90_raw),.O(clk90));
 BUFG u_clk200(.I(clk200_raw),.O(clk200));
 wire delay_ready;
 wire rst;
 wire [4:0] raw_rx={eth_rx_ctl,eth_rxd};
 (* ASYNC_REG="TRUE" *) reg [1:0] delay_ready_sync;
 always @(posedge clk125) if(rst)delay_ready_sync<=0;else delay_ready_sync<={delay_ready_sync[0],delay_ready};
 (* IODELAY_GROUP="av_eth_rx" *) IDELAYCTRL u_rx_idelayctrl(.REFCLK(clk200),.RST(rst),.RDY(delay_ready));
 wire [4:0] delayed_rx;
 genvar rx_bit;
 generate for(rx_bit=0;rx_bit<5;rx_bit=rx_bit+1)begin:g_rx_delay
  (* IODELAY_GROUP="av_eth_rx" *) IDELAYE2 #(.DELAY_SRC("IDATAIN"),.IDELAY_TYPE("FIXED"),.IDELAY_VALUE(11),.HIGH_PERFORMANCE_MODE("TRUE"),.REFCLK_FREQUENCY(200.0),.SIGNAL_PATTERN("DATA")) u_delay(
   .IDATAIN(raw_rx[rx_bit]),.DATAIN(1'b0),.DATAOUT(delayed_rx[rx_bit]),
   .C(1'b0),.CE(1'b0),.INC(1'b0),.LD(1'b0),.LDPIPEEN(1'b0),.CNTVALUEIN(5'b0),.CINVCTRL(1'b0),.REGRST(1'b0),.CNTVALUEOUT());
 end endgenerate
 (* ASYNC_REG="TRUE" *) reg [7:0] reset_pipe=8'hff;
 always @(posedge clk125 or negedge sys_rst_n)begin
  if(!sys_rst_n)reset_pipe<=8'hff;else if(!locked)reset_pipe<=8'hff;else reset_pipe<={reset_pipe[6:0],1'b0};
 end
 assign rst=reset_pipe[7];
 reg [20:0] phy_counter;reg phy_ready;wire phy_enable;
 always @(posedge clk125)begin
  if(rst||!phy_enable||!delay_ready_sync[1])begin phy_counter<=0;phy_ready<=0;end
  else if(!phy_ready)begin if(phy_counter==1249999)phy_ready<=1;else phy_counter<=phy_counter+1;end
 end
 assign eth_rst_n=phy_ready&&!rst;
 wire[31:0] awaddr,wdata,araddr,rdata;wire[3:0]wstrb;
 wire awvalid,awready,wvalid,wready,bvalid,bready,arvalid,arready,rvalid,rready;
 wire[1:0]bresp,rresp;wire[2:0]awprot,arprot;
 assign bus_clk125=clk125;assign bus_resetn=!rst;
 assign awaddr={24'b0,c_awaddr[7:0]};assign wdata=c_wdata;assign wstrb=c_wstrb;
 assign awvalid=c_awvalid;assign c_awready=awready;assign wvalid=c_wvalid;assign c_wready=wready;
 assign c_bresp=bresp;assign c_bvalid=bvalid;assign bready=c_bready;
 assign araddr={24'b0,c_araddr[7:0]};assign arvalid=c_arvalid;assign c_arready=arready;
 assign c_rdata=rdata;assign c_rresp=rresp;assign c_rvalid=rvalid;assign rready=c_rready;
 wire [863:0] payload;
 wire start,clear,busy,done,tx_error,underflow;wire[15:0]count;wire[31:0]seq_base,seed,gap,sent,last_seq;
 wire mdio_start,mdio_read,mdio_busy,mdio_done,mdio_ack,mdio_in,mdio_out,mdio_t;
 wire[4:0]mdio_phy,mdio_reg;wire[15:0]mdio_wdata,mdio_rdata;wire[1:0]speed;
 wire rx_frozen,rx_arm,rx_freeze;wire[13:0]rx_index;wire[31:0]rx_frames,rx_bad_count,rx_overflow,rx_word;
 eth_tx_axil_regs u_regs(.payload(payload),.rx_frozen(rx_frozen),.rx_frames(rx_frames),.rx_bad(rx_bad_count),.rx_overflow(rx_overflow),.rx_data(rx_word),.rx_arm(rx_arm),.rx_freeze(rx_freeze),.rx_index(rx_index),.clk(clk125),.rst(rst),
  .s_awaddr(awaddr),.s_awvalid(awvalid),.s_awready(awready),.s_wdata(wdata),.s_wstrb(wstrb),.s_wvalid(wvalid),.s_wready(wready),
  .s_bresp(bresp),.s_bvalid(bvalid),.s_bready(bready),.s_araddr(araddr),.s_arvalid(arvalid),.s_arready(arready),.s_rdata(rdata),.s_rresp(rresp),.s_rvalid(rvalid),.s_rready(rready),
  .phy_ready(phy_ready),.clock_locked(locked),.mac_speed(speed),.tx_underflow(underflow),.tx_start(start),.tx_clear(clear),.frame_count(count),.seq_base(seq_base),.seed(seed),.gap_cycles(gap),
  .tx_busy(busy),.tx_done(done),.tx_error(tx_error),.sent_count(sent),.last_seq(last_seq),.phy_enable(phy_enable),
  .mdio_start(mdio_start),.mdio_read(mdio_read),.mdio_phy(mdio_phy),.mdio_reg(mdio_reg),.mdio_wdata(mdio_wdata),.mdio_busy(mdio_busy),.mdio_done(mdio_done),.mdio_ack_error(mdio_ack),.mdio_rdata(mdio_rdata));
 eth_mdio_master u_mdio(.clk(clk125),.rst(rst),.start(mdio_start),.read_cmd(mdio_read),.phy_addr(mdio_phy),.reg_addr(mdio_reg),.write_data(mdio_wdata),
  .mdio_i(mdio_in),.mdio_o(mdio_out),.mdio_t(mdio_t),.mdc(eth_mdc),.busy(mdio_busy),.done(mdio_done),.ack_error(mdio_ack),.read_data(mdio_rdata));
 IOBUF u_mdio_pin(.I(mdio_out),.T(mdio_t),.O(mdio_in),.IO(eth_mdio));
 wire [7:0]data;wire valid,ready,last;wire tx_clk,tx_rst,rx_clk,rx_rst;wire[7:0]rxdata;wire rxvalid,rxlast,rxuser,rxbad,rxfcs;
`ifdef BOARD_100T
 eth_udp_tx_gen #(.SOURCE_MAC(48'h025052583100),.DEST_MAC(48'h025052587035),.SOURCE_IP(32'hc0a8010c),.DEST_IP(32'hc0a8010b)) u_gen(
`else
 eth_udp_tx_gen u_gen(
`endif
.payload(payload),.clk(tx_clk),.rst(tx_rst||clear),.start(start),.frame_count(count),.seq_base(seq_base),.seed(seed),.gap_cycles(gap),
  .m_axis_tdata(data),.m_axis_tvalid(valid),.m_axis_tready(ready),.m_axis_tlast(last),.busy(busy),.done(done),.sent_count(sent),.last_seq(last_seq),.error(tx_error));
 wire [7:0] mac_data;wire mac_valid,mac_last,mac_ready;
 assign frame_tx_clk=tx_clk;assign frame_tx_reset=tx_rst;
 assign frame_rx_clk=rx_clk;assign frame_rx_reset=rx_rst;
 assign frame_rx_data=rxdata;assign frame_rx_valid=rxvalid;
 assign frame_rx_last=rxlast;assign frame_rx_bad=rxuser;
 nfr_tx_arbiter frame_arb(.clk(tx_clk),.rst(tx_rst),
  .frame_data(frame_tx_data),.frame_valid(frame_tx_valid),.frame_last(frame_tx_last),.frame_ready(frame_tx_ready),
  .legacy_data(data),.legacy_valid(valid),.legacy_last(last),.legacy_ready(ready),
  .mac_data(mac_data),.mac_valid(mac_valid),.mac_last(mac_last),.mac_ready(mac_ready));
 eth_mac_1g_rgmii #(.TARGET("XILINX"),.IODDR_STYLE("IODDR"),.CLOCK_INPUT_STYLE("BUFIO"),.USE_CLK90("TRUE"),.ENABLE_PADDING(1),.MIN_FRAME_LENGTH(64)) u_mac(
  .gtx_clk(clk125),.gtx_clk90(clk90),.gtx_rst(rst),.rx_clk(rx_clk),.rx_rst(rx_rst),.tx_clk(tx_clk),.tx_rst(tx_rst),
  .tx_axis_tdata(mac_data),.tx_axis_tvalid(mac_valid),.tx_axis_tready(mac_ready),.tx_axis_tlast(mac_last),.tx_axis_tuser(1'b0),
  .rx_axis_tdata(rxdata),.rx_axis_tvalid(rxvalid),.rx_axis_tlast(rxlast),.rx_axis_tuser(rxuser),
  .rgmii_rx_clk(eth_rxc),.rgmii_rxd(delayed_rx[3:0]),.rgmii_rx_ctl(delayed_rx[4]),.rgmii_tx_clk(eth_txc),.rgmii_txd(eth_txd),.rgmii_tx_ctl(eth_tx_ctl),
  .tx_error_underflow(underflow),.rx_error_bad_frame(rxbad),.rx_error_bad_fcs(rxfcs),.speed(speed),.cfg_ifg(8'd12),.cfg_tx_enable(phy_ready),.cfg_rx_enable(1'b1));
 eth_rx_capture #(.CONTINUOUS_HISTORY(1)) u_capture(.rx_clk(rx_clk),.rx_rst(rx_rst),.rx_data(rxdata),.rx_valid(rxvalid),.rx_last(rxlast),.rx_bad(rxuser),.reg_clk(clk125),.reg_rst(rst),.arm_toggle(rx_arm),.freeze_request(rx_freeze),.read_index(rx_index),.read_data(rx_word),.frozen(rx_frozen),.frame_count(rx_frames),.bad_count(rx_bad_count),.overflow_count(rx_overflow));
 assign status_led={busy,phy_ready,locked};
endmodule
