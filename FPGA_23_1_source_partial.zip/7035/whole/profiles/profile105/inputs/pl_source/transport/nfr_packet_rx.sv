`timescale 1ns/1ps
// One store-and-forward packet. The MAC has no RX backpressure, so a busy
// mailbox drops new packets; the stop-and-wait sender retries after timeout.
// Neither a bad MAC FCS nor a bad software CRC can publish a packet.
module nfr_packet_rx #(
 parameter [47:0] LOCAL_MAC=48'h025052587035,
 parameter [47:0] REMOTE_MAC=48'h025052583100
)(
 input wire rx_clk,rx_reset,
 input wire [7:0] rx_data,input wire rx_valid,rx_last,rx_bad,
 input wire clk,rst_n,
 output wire packet_valid,output wire [383:0] packet_header,
 input wire packet_release,
 input wire payload_read,input wire [9:0] payload_address,
 output reg [7:0] payload_data,output reg payload_read_valid,
 output reg [31:0] received_packets,bad_packets,busy_drops
);
 (* ram_style="block" *) reg [7:0] payload_mem[0:1023];
 reg [10:0] index;
 reg in_frame,dropping,oversize;
 reg [47:0] dst,src;
 reg [15:0] ethertype;
 reg [383:0] header,held_header;
 reg [31:0] header_crc,payload_crc;
 reg send_toggle,ack_toggle;
 // Capture the immutable mailbox once in the destination domain, before
 // advertising it. Only these registers are endpoints of the bundled CDC;
 // downstream contract comparisons are ordinary fabric-clock logic.
 (* DONT_TOUCH="TRUE" *) reg [383:0] local_header;
 reg local_valid;
 (* ASYNC_REG="TRUE" *) reg [2:0] ack_sync,send_sync;
 wire mailbox_busy=send_toggle!=ack_sync[2];
 assign packet_valid=rst_n&&local_valid;
 assign packet_header=local_header;

 function automatic [31:0] crc_byte(input [31:0] c,input [7:0] d);
  reg [31:0] v;integer b;
  begin v=c^d;for(b=0;b<8;b=b+1)v=v[0]?(v>>1)^32'hedb88320:v>>1;crc_byte=v;end
 endfunction
 reg [383:0] next_header;
 always @* begin
  next_header=header;
  if(index>=14&&index<62)next_header[383-(index-14)*8-:8]=rx_data;
 end
 wire [15:0] length=next_header[127:112];
 wire [31:0] ending_payload_crc=index>=62?~crc_byte(payload_crc,rx_data):32'd0;
 wire header_ok=next_header[383:352]==32'h4e465231&&
  next_header[351:344]==1&&next_header[343:336]>=1&&next_header[343:336]<=6&&
  next_header[335:320]==48&&(next_header[199:192]&8'hfe)==0;
 // Header byte23 flags maps to [199:192]. Payload CRC at byte36, header CRC44.
 wire envelope_ok=dst==LOCAL_MAC&&src==REMOTE_MAC&&ethertype==16'h88b5;
 wire lengths_ok=index>=61&&length<=1024&&index+1==62+length;
 wire crc_ok=(~header_crc)==next_header[31:0]&&ending_payload_crc==next_header[95:64];

 always @(posedge rx_clk)begin
  if(rx_reset)begin
   index<=0;in_frame<=0;dropping<=0;oversize<=0;dst<=0;src<=0;ethertype<=0;
   header<=0;held_header<=0;header_crc<=32'hffffffff;payload_crc<=32'hffffffff;
   send_toggle<=0;ack_sync<=0;received_packets<=0;bad_packets<=0;busy_drops<=0;
  end else begin
   ack_sync<={ack_sync[1:0],ack_toggle};
   if(rx_valid)begin
    if(!in_frame)begin
     in_frame<=1;dropping<=mailbox_busy;oversize<=0;
     dst<={40'd0,rx_data};src<=0;ethertype<=0;header<=0;
     header_crc<=32'hffffffff;payload_crc<=32'hffffffff;index<=1;
    end else begin
     if(index<6)dst<={dst[39:0],rx_data};
     if(index>=6&&index<12)src<={src[39:0],rx_data};
     if(index>=12&&index<14)ethertype<={ethertype[7:0],rx_data};
     if(index>=14&&index<62)header<=next_header;
     if(index>=14&&index<58)header_crc<=crc_byte(header_crc,rx_data);
     if(index>=62)begin
      payload_crc<=crc_byte(payload_crc,rx_data);
      if(index<1086&&!dropping)payload_mem[index-62]<=rx_data;
     end
     if(index==2047)oversize<=1;else index<=index+1'b1;
    end
    if(rx_last)begin
     in_frame<=0;index<=0;
     if(dropping||(!in_frame&&mailbox_busy))busy_drops<=busy_drops+1;
     else if(!in_frame||oversize||rx_bad||!envelope_ok||!header_ok||!lengths_ok||!crc_ok)
      bad_packets<=bad_packets+1;
     else begin
      held_header<=next_header;send_toggle<=!send_toggle;received_packets<=received_packets+1;
     end
    end
   end
  end
 end
 always @(posedge clk)begin
  if(!rst_n)begin send_sync<=0;ack_toggle<=0;payload_read_valid<=0;payload_data<=0;local_header<=0;local_valid<=0;end
  else begin
   send_sync<={send_sync[1:0],send_toggle};
   if(!local_valid&&send_sync[2]!=ack_toggle)begin
    local_header<=held_header;local_valid<=1;
   end else if(packet_release&&packet_valid)begin
    ack_toggle<=send_sync[2];local_valid<=0;
   end
   payload_read_valid<=payload_read&&packet_valid;
   if(payload_read&&packet_valid)payload_data<=payload_mem[payload_address];
  end
 end
endmodule
