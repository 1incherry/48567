`timescale 1ns/1ps
module nfr_native_endpoint(
input wire clk,rst_n,rx_clk,rx_reset,input wire [7:0] rx_data,input wire rx_valid,rx_last,rx_bad,
input wire tx_clk,tx_reset,output wire [7:0]tx_data,output wire tx_valid,tx_last,input wire tx_ready,
output wire packet_valid,output wire [383:0]packet_header,input wire packet_release,payload_read,input wire [9:0]payload_address,
output wire [7:0]payload_data,output wire payload_read_valid,
input wire response_valid,output wire response_ready,input wire [7:0]response_kind,response_flags,
input wire [31:0]response_offset,response_frame_crc,response_session_id,response_frame_id,response_total_bytes,
input wire [15:0]response_width,response_height,output wire tx_quiescent);
assign tx_quiescent=response_ready&&!response_valid;
wire [31:0]raw_packets,raw_bad,raw_drops;
 nfr_packet_rx receiver(.rx_clk(rx_clk),.rx_reset(rx_reset),.rx_data(rx_data),.rx_valid(rx_valid),.rx_last(rx_last),.rx_bad(rx_bad),
  .clk(clk),.rst_n(rst_n),.packet_valid(packet_valid),.packet_header(packet_header),.packet_release(packet_release),
  .payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
  .received_packets(raw_packets),.bad_packets(raw_bad),.busy_drops(raw_drops));
 nfr_control_tx transmitter(.clk(clk),.rst_n(rst_n),.control_valid(response_valid),.control_ready(response_ready),
  .kind(response_kind),.session_id(response_session_id),.frame_id(response_frame_id),.total_bytes(response_total_bytes),
  .offset(response_offset),.frame_crc(response_frame_crc),.width(response_width),.height(response_height),.flags(response_flags),
  .tx_clk(tx_clk),.tx_reset(tx_reset),.m_axis_tdata(tx_data),.m_axis_tvalid(tx_valid),.m_axis_tlast(tx_last),.m_axis_tready(tx_ready));
endmodule
