`timescale 1ns/1ps
// Header-only 7035 -> 100T NFR1 packets. Source builds a complete immutable
// packet before crossing the toggle mailbox. No bubbles inside a MAC frame.
module nfr_control_tx #(
 parameter [47:0] LOCAL_MAC=48'h025052587035,
 parameter [47:0] REMOTE_MAC=48'h025052583100
)(
 input wire clk,rst_n,control_valid,output wire control_ready,
 input wire [7:0] kind,input wire [31:0] session_id,frame_id,total_bytes,offset,frame_crc,
 input wire [15:0] width,height,input wire [7:0] flags,
 input wire tx_clk,tx_reset,
 output wire [7:0] m_axis_tdata,output wire m_axis_tvalid,m_axis_tlast,input wire m_axis_tready,
 output reg[15:0] diagnostic_request_completed_gray
);
 reg building;
 reg [5:0] build_index;
 reg [351:0] header;
 reg [495:0] held_packet;
 (* DONT_TOUCH="TRUE" *) reg [495:0] local_packet;
 reg [31:0] crc;
 reg send_toggle,ack_toggle;
 (* ASYNC_REG="TRUE" *) reg [2:0] ack_sync,send_sync;
 reg transmitting;reg [5:0] tx_index;
 assign control_ready=rst_n&&!building&&(ack_sync[2]==send_toggle);
 assign m_axis_tvalid=transmitting&&!tx_reset;
 assign m_axis_tlast=m_axis_tvalid&&tx_index==61;
 assign m_axis_tdata=local_packet[495-tx_index*8-:8];
 function automatic [31:0] crc_byte(input [31:0] c,input [7:0] d);
  reg [31:0] v;integer b;
  begin v=c^d;for(b=0;b<8;b=b+1)v=v[0]?(v>>1)^32'hedb88320:v>>1;crc_byte=v;end
 endfunction
 reg [7:0] build_byte;
 always @* begin
  if(build_index<6)build_byte=REMOTE_MAC[47-build_index*8-:8];
  else if(build_index<12)build_byte=LOCAL_MAC[47-(build_index-6)*8-:8];
  else if(build_index==12)build_byte=8'h88;
  else if(build_index==13)build_byte=8'hb5;
  else if(build_index<58)build_byte=header[351-(build_index-14)*8-:8];
  else build_byte=(~crc)>>(8*(61-build_index));
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   building<=0;build_index<=0;header<=0;held_packet<=0;crc<=32'hffffffff;send_toggle<=0;ack_sync<=0;
  end else begin
   ack_sync<={ack_sync[1:0],ack_toggle};
   if(control_valid&&control_ready)begin
    header<={32'h4e465231,8'd1,kind,16'd48,session_id,frame_id,16'd0,width,height,8'd1,flags,
             total_bytes,offset,16'd0,offset[25:10],32'd0,frame_crc};
    building<=1;build_index<=0;crc<=32'hffffffff;
   end else if(building)begin
    held_packet[495-build_index*8-:8]<=build_byte;
    if(build_index>=14&&build_index<58)crc<=crc_byte(crc,build_byte);
    if(build_index==61)begin building<=0;send_toggle<=!send_toggle;end
    else build_index<=build_index+1'b1;
   end
  end
 end
 always @(posedge tx_clk)begin
  if(tx_reset)begin send_sync<=0;ack_toggle<=0;transmitting<=0;tx_index<=0;local_packet<=0;end
  else begin
   send_sync<={send_sync[1:0],send_toggle};
   if(!transmitting&&send_sync[2]!=ack_toggle)begin
    local_packet<=held_packet;transmitting<=1;tx_index<=0;
   end
   else if(m_axis_tvalid&&m_axis_tready)begin
    if(m_axis_tlast)begin transmitting<=0;ack_toggle<=send_sync[2];tx_index<=0;end
    else tx_index<=tx_index+1'b1;
   end
  end
 end
 // Observation only. Counts final REQUEST bytes accepted by MAC stream.
 reg[15:0] diag_request_completed_bin;
 wire diag_request_complete=m_axis_tvalid&&m_axis_tready&&m_axis_tlast&&local_packet[343:336]==8'd1;
 always@(posedge tx_clk)begin
  if(tx_reset)begin diag_request_completed_bin<=0;diagnostic_request_completed_gray<=0;end
  else begin
   if(diag_request_complete)diag_request_completed_bin<=diag_request_completed_bin+1'b1;
   diagnostic_request_completed_gray<=diag_request_completed_bin^(diag_request_completed_bin>>1);
  end
 end
endmodule
