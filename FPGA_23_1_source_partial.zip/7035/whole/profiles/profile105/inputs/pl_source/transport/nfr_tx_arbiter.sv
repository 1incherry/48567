`timescale 1ns/1ps
// Two complete-frame producers share one MAC. NFR control has priority only
// between packets. An offered packet remains selected even under MAC stall.
module nfr_tx_arbiter(
 input wire clk,rst,
 input wire [7:0] frame_data,input wire frame_valid,frame_last,output wire frame_ready,
 input wire [7:0] legacy_data,input wire legacy_valid,legacy_last,output wire legacy_ready,
 output wire [7:0] mac_data,output wire mac_valid,mac_last,input wire mac_ready
);
 reg locked,owner;
 wire selected=locked?owner:frame_valid;
 assign mac_data=selected?frame_data:legacy_data;
 assign mac_valid=!rst&&(selected?frame_valid:legacy_valid);
 assign mac_last=selected?frame_last:legacy_last;
 assign frame_ready=!rst&&selected&&mac_ready;
 assign legacy_ready=!rst&&!selected&&mac_ready;
 always @(posedge clk)begin
  if(rst)begin locked<=0;owner<=0;end
  else if(mac_valid)begin
   if(mac_ready&&mac_last)locked<=0;
   else begin locked<=1;owner<=selected;end
  end
 end
endmodule
