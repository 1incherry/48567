`timescale 1ns/1ps
// Independent unselected HIS-only transport candidate. No NN/key/DDR interface.
// Narrow 65-word packet FIFO: one token +64body words, commit only real lastACK.
module untrusted_his1_narrow_transport #(
 parameter [47:0] DEST_MAC=48'h025052583100,SOURCE_MAC=48'h025052587035
)(
 input wire clk,board_resetn,
 input wire packet_begin_valid,output wire packet_begin_ready,input wire[31:0]packet_token,
 input wire word_valid,output wire word_ready,input wire[31:0]word_data,input wire word_last,
 output reg completion_valid,completion_error,output reg[31:0]completion_token,
 output reg mac_started_valid,output reg[31:0]mac_started_token,
 output wire quiescent,fault,
 input wire tx_clk,tx_reset_n,
 output wire[7:0]tx_data,output wire tx_valid,tx_last,input wire tx_ready
);
 wire source_clk=clk,source_reset_n=board_resetn;
 wire destination_clk=tx_clk,destination_reset_n=tx_reset_n;
 wire destination_reset_released;
 reg source_fault;
 assign fault=source_fault;
 wire common_reset_n=source_reset_n&&destination_reset_n;
 reg request_toggle,ack_toggle,source_commit_toggle;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]ack_sync,request_sync;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]destination_alive;
 reg destination_armed;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]destination_release;
 always @(posedge destination_clk or negedge common_reset_n)
  if(!common_reset_n)destination_release<=0;
  else destination_release<={destination_release[1:0],1'b1};

 // Capture even a reset pulse while source_clk is stopped. The actual XPM rst
 // register changes ONLY on source_clk, satisfying the vendor synchronous-rst
 // contract. At least eight write-clock reset edges occur after any request.
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[7:0]fifo_reset_release=0;
 reg fifo_reset=1'b1;
 reg fifo_reset_pending=1'b1;
 reg[1:0]fifo_reset_state=0;
 reg[3:0]fifo_reset_hold=8;
 always @(posedge source_clk or negedge common_reset_n)
  if(!common_reset_n)fifo_reset_release<=0;
  else fifo_reset_release<={fifo_reset_release[6:0],1'b1};
 wire fifo_full,fifo_empty,fifo_wr_busy,fifo_rd_busy;
 wire fifo_overflow,fifo_underflow,fifo_wr_ack,fifo_data_valid;
 wire[31:0]fifo_dout;
 // The vendor forbids a fresh rising reset while wr_rst_busy is active.
 // Latch every asynchronous request, keep all public state invalid, finish
 // the old real reset handshake, then service the queued request. A request
 // arriving during asserted reset extends its hold without a second edge.
 always @(posedge source_clk or negedge common_reset_n)
  if(!common_reset_n)fifo_reset_pending<=1'b1;
  else if(fifo_reset_state==0&&fifo_reset_release[7])fifo_reset_pending<=0;
 always @(posedge source_clk)begin
  case(fifo_reset_state)
   0:begin
    fifo_reset<=1;
    if(fifo_reset_pending||!fifo_reset_release[7])fifo_reset_hold<=8;
    else if(fifo_reset_hold>1)fifo_reset_hold<=fifo_reset_hold-1'b1;
    else begin fifo_reset<=0;fifo_reset_state<=1;end
   end
   1:if(!fifo_wr_busy)begin
    if(fifo_reset_pending)begin fifo_reset<=1;fifo_reset_hold<=8;fifo_reset_state<=0;end
    else fifo_reset_state<=2;
   end
   2:if(fifo_reset_pending)begin fifo_reset<=1;fifo_reset_hold<=8;fifo_reset_state<=0;end
   default:begin fifo_reset<=1;fifo_reset_hold<=8;fifo_reset_state<=0;end
  endcase
 end
 reg source_fifo_live;
 always @(posedge source_clk or negedge fifo_reset_release[7])
  if(!fifo_reset_release[7])source_fifo_live<=0;
  else if(fifo_reset||fifo_wr_busy||fifo_reset_pending||fifo_reset_state!=2)source_fifo_live<=0;
  else source_fifo_live<=1;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]fifo_live_sync;
 always @(posedge destination_clk or negedge common_reset_n)
  if(!common_reset_n)fifo_live_sync<=0;
  else fifo_live_sync<={fifo_live_sync[1:0],source_fifo_live};
 assign destination_reset_released=destination_release[2]&&fifo_live_sync[2]&&!fifo_rd_busy;

 // Independent destination reset can never impersonate a successful ACK0.
 // Existing sticky-fault semantics are retained, including short async pulses.
 wire alive_reset_n=source_reset_n&&destination_reset_released;
 always @(posedge source_clk or negedge alive_reset_n)
  if(!alive_reset_n)destination_alive<=0;
  else destination_alive<={destination_alive[1:0],1'b1};
 reg destination_fault;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]destination_fault_sync;
 always @(posedge source_clk or negedge source_reset_n)
  if(!source_reset_n)destination_fault_sync<=0;
  else destination_fault_sync<={destination_fault_sync[1:0],destination_fault};


 localparam S_IDLE=0,S_TOKEN=1,S_COLLECT=2,S_COMMIT=3,S_WAIT_ACK=4;
 reg[2:0]state;
 reg[5:0]body_index;
 reg[31:0]token;
 reg write_pending,final_write_pending;
 wire source_pipe_live=source_reset_n&&source_fifo_live&&!fifo_reset&&!fifo_wr_busy&&destination_alive[2];
 wire write_healthy=source_pipe_live&&!source_fault&&!destination_fault_sync[2];
 wire source_ready=write_healthy&&request_toggle==ack_sync[2]&&!write_pending;
 assign packet_begin_ready=state==S_IDLE&&source_ready;
 wire discard_tail=source_fault||destination_fault_sync[2]||!source_pipe_live;
 assign word_ready=state==S_COLLECT&&(discard_tail||!fifo_full);
 assign quiescent=state==S_IDLE&&source_ready;
 wire fifo_push=write_healthy&&!fifo_full&&
                (state==S_TOKEN||(state==S_COLLECT&&word_valid&&word_ready));
 wire[31:0]fifo_din=state==S_TOKEN?token:word_data;
 wire missing_write_ack=write_pending&&!fifo_wr_ack&&source_fifo_live&&!fifo_reset&&!fifo_wr_busy;
 wire source_problem=fifo_overflow||destination_fault_sync[2]||missing_write_ack||
                     (destination_armed&&!destination_alive[2])||
                     (state!=S_IDLE&&!source_pipe_live);
 reg start_toggle;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]start_sync;
 reg start_seen;
 always@(posedge source_clk or negedge source_reset_n)begin
  if(!source_reset_n)begin
   state<=S_IDLE;body_index<=0;token<=0;source_fault<=0;destination_armed<=0;
   request_toggle<=0;source_commit_toggle<=0;ack_sync<=0;
   write_pending<=0;final_write_pending<=0;
   completion_valid<=0;completion_error<=0;completion_token<=0;
   mac_started_valid<=0;mac_started_token<=0;start_sync<=0;start_seen<=0;
  end else begin
   ack_sync<={ack_sync[1:0],ack_toggle};
   start_sync<={start_sync[1:0],start_toggle};
   completion_valid<=0;mac_started_valid<=0;
   write_pending<=fifo_push;
   final_write_pending<=fifo_push&&state==S_COLLECT&&body_index==63;
   if(destination_alive[2])destination_armed<=1;
   if(source_problem)source_fault<=1;
   if(start_sync[2]!=start_seen)begin
    start_seen<=start_sync[2];
    if(state==S_WAIT_ACK&&!source_fault&&!source_problem)begin mac_started_valid<=1;mac_started_token<=token;end
   end
   case(state)
    S_IDLE:if(packet_begin_valid&&packet_begin_ready)begin
     token<=packet_token;body_index<=0;request_toggle<=!request_toggle;state<=S_TOKEN;
     if(packet_token==0||(^packet_token)===1'bx)source_fault<=1;
    end
    S_TOKEN:begin
     // Even an invalidated accepted BEGIN still drains its exact64 local words.
     if(source_fault||source_problem||!source_pipe_live)state<=S_COLLECT;
     else if(fifo_push)state<=S_COLLECT;
    end
    S_COLLECT:if(word_valid&&word_ready)begin
     if((word_last!==(body_index==63))||(^word_data)===1'bx)source_fault<=1;
     if(body_index==63)state<=S_COMMIT;else body_index<=body_index+1'b1;
    end
    S_COMMIT:begin
     if(source_fault||source_problem||!source_pipe_live)begin
      completion_valid<=1;completion_error<=1;completion_token<=token;state<=S_IDLE;
     end else if(final_write_pending&&fifo_wr_ack)begin
      source_commit_toggle<=request_toggle;state<=S_WAIT_ACK;
     end
    end
    S_WAIT_ACK:begin
     if(source_fault||source_problem||!source_pipe_live)begin
      completion_valid<=1;completion_error<=1;completion_token<=token;state<=S_IDLE;
     end else if(ack_sync[2]==request_toggle)begin
      completion_valid<=1;completion_error<=0;completion_token<=token;state<=S_IDLE;
     end
    end
    default:begin source_fault<=1;state<=S_IDLE;end
   endcase
  end
 end

 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *)reg[2:0]commit_sync,source_fault_sync;
 localparam D_IDLE=0,D_TOKEN=1,D_SEND=2;
 reg[1:0]destination_state;
 reg[8:0]position;
 reg[6:0]body_words_consumed;
 reg[31:0]destination_token;
 wire fifo_word_live=!fifo_empty&&!fifo_rd_busy&&fifo_data_valid;
 wire body_position=position>=14;
 wire[1:0]byte_lane=position[1:0]-2'd2;
 reg[7:0]body_byte;
 always@*case(byte_lane)
  0:body_byte=fifo_dout[7:0];1:body_byte=fifo_dout[15:8];
  2:body_byte=fifo_dout[23:16];default:body_byte=fifo_dout[31:24];
 endcase
 // Never withdraw an offered byte on a synchronized fault. If data is still
 // physically present, complete the already offered MAC frame; ACK remains denied.
 // A true unavailable FIFO word is fatal, never claimed as SENT/healthy drain.
 assign tx_valid=destination_reset_released&&destination_state==D_SEND&&(!body_position||fifo_word_live);
 assign tx_last=tx_valid&&position==269;
 assign tx_data=position<6?DEST_MAC[47-position*8-:8]:
                position<12?SOURCE_MAC[47-(position-6)*8-:8]:
                position==12?8'h88:position==13?8'hb6:body_byte;
 wire mac_accept=tx_valid&&tx_ready;
 wire tail_accept=mac_accept&&position==269;
 wire fifo_pop=destination_reset_released&&!fifo_rd_busy&&fifo_word_live&&
               ((destination_state==D_TOKEN)||
                (destination_state==D_SEND&&body_position&&byte_lane==3&&mac_accept));
 wire invalid_fifo_token=destination_state==D_TOKEN&&fifo_pop&&
                         (fifo_dout==0||(^fifo_dout)===1'bx);
 wire missing_payload=destination_state==D_SEND&&body_position&&!fifo_word_live;
 wire bad_tail_count=tail_accept&&body_words_consumed!=63;
 wire destination_problem=fifo_underflow||invalid_fifo_token||missing_payload||bad_tail_count;
 always@(posedge destination_clk or negedge destination_reset_released)begin
  if(!destination_reset_released)destination_fault<=0;
  else if(destination_problem)destination_fault<=1;
 end
 always@(posedge destination_clk or negedge destination_reset_released)begin
  if(!destination_reset_released)begin
   request_sync<=0;commit_sync<=0;source_fault_sync<=0;ack_toggle<=0;start_toggle<=0;
   destination_state<=D_IDLE;position<=0;body_words_consumed<=0;destination_token<=0;
  end else begin
   request_sync<={request_sync[1:0],request_toggle};
   commit_sync<={commit_sync[1:0],source_commit_toggle};
   source_fault_sync<={source_fault_sync[1:0],source_fault};
   case(destination_state)
    D_IDLE:if(request_sync[2]!=ack_toggle&&commit_sync[2]==request_sync[2]&&
              !destination_fault&&!source_fault_sync[2]&&!fifo_underflow)destination_state<=D_TOKEN;
    D_TOKEN:begin
     if(destination_fault||source_fault_sync[2]||destination_problem)destination_state<=D_IDLE;
     else if(fifo_pop)begin
      destination_token<=fifo_dout;position<=0;body_words_consumed<=0;destination_state<=D_SEND;
     end
    end
    D_SEND:if(mac_accept)begin
     if(position==0)start_toggle<=!start_toggle;
     if(body_position&&byte_lane==3)body_words_consumed<=body_words_consumed+1'b1;
     if(position==269)begin
      if(!destination_fault&&!source_fault_sync[2]&&!destination_problem)ack_toggle<=request_sync[2];
      destination_state<=D_IDLE;position<=0;
     end else position<=position+1'b1;
    end
    default:begin destination_state<=D_IDLE;end
   endcase
  end
 end
 // Same actual block memory depth/width; FWFT exposes one stable current word.
 // Packet visibility is independently gated by the real65th write ACK commit.
 xpm_fifo_async #(
  .FIFO_MEMORY_TYPE("block"),.FIFO_WRITE_DEPTH(128),.WRITE_DATA_WIDTH(32),.READ_DATA_WIDTH(32),
  .READ_MODE("fwft"),.FIFO_READ_LATENCY(0),.CDC_SYNC_STAGES(3),.RELATED_CLOCKS(0),
  .DOUT_RESET_VALUE("0"),.ECC_MODE("no_ecc"),.FULL_RESET_VALUE(0),
  .PROG_EMPTY_THRESH(10),.PROG_FULL_THRESH(110),.RD_DATA_COUNT_WIDTH(8),.WR_DATA_COUNT_WIDTH(8),
  .USE_ADV_FEATURES("1111"),.SIM_ASSERT_CHK(1),.WAKEUP_TIME(0)
 )report_fifo(
  .rst(fifo_reset),.wr_clk(source_clk),.rd_clk(destination_clk),
  .din(fifo_din),.wr_en(fifo_push),.rd_en(fifo_pop),.dout(fifo_dout),
  .full(fifo_full),.empty(fifo_empty),.wr_rst_busy(fifo_wr_busy),.rd_rst_busy(fifo_rd_busy),
  .overflow(fifo_overflow),.underflow(fifo_underflow),.wr_ack(fifo_wr_ack),.data_valid(fifo_data_valid),
  .almost_empty(),.almost_full(),.prog_empty(),.prog_full(),.rd_data_count(),.wr_data_count(),
  .dbiterr(),.sbiterr(),.injectdbiterr(1'b0),.injectsbiterr(1'b0),.sleep(1'b0)
 );
 // synthesis translate_off
 integer debug_writes;
 always@(posedge source_clk or negedge source_reset_n)begin
  if(!source_reset_n)debug_writes<=0;
  else begin
   if(packet_begin_valid&&packet_begin_ready)debug_writes<=0;
   else if(fifo_push)debug_writes<=debug_writes+1;
   if(state==S_COMMIT&&final_write_pending&&fifo_wr_ack&&!source_fault&&!source_problem)begin
    if(debug_writes!=65)$fatal(1,"NARROW_HIS_COMMIT_BEFORE_REAL65_WRITES");
   end
  end
 end
 // synthesis translate_on
endmodule
