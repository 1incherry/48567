`timescale 1ns/1ps
// DISPLAY-ONLY, UNTRUSTED history carrier. This module has no NN/auth/DDR ports.
// Transport outputs are main-domain32-bit words, not an implemented physical CDC.
// B acknowledges only validated local enqueue. SENT is separate token-bound true MAC completion.
module untrusted_his_hna1_tx_mailbox_typed #(parameter HONOR_TRANSPORT_FAULT=0,parameter integer HISTORY_WIDTH=640,parameter integer HISTORY_HEIGHT=480)(
 input wire clk,board_resetn,
 input wire[11:0]s_awaddr,s_araddr,input wire s_awvalid,s_wvalid,s_bready,s_arvalid,s_rready,
 input wire[31:0]s_wdata,input wire[3:0]s_wstrb,
 output wire s_awready,s_wready,s_arready,output reg s_bvalid,s_rvalid,
 output reg[1:0]s_bresp,s_rresp,output reg[31:0]s_rdata,
 output wire packet_begin_valid,input wire packet_begin_ready,output wire[31:0]packet_token,
 output wire word_valid,input wire word_ready,output wire[31:0]word_data,output wire word_last,
 input wire completion_valid,completion_error,input wire[31:0]completion_token,
 input wire mac_started_valid,input wire[31:0]mac_started_token,
 output wire local_busy,output reg local_fault,output reg[7:0]local_error,
 output reg[31:0]sent_count,rejected_count,input wire transport_fault
);
 localparam IDLE=0,VREAD=1,VCHECK=2,BEGIN_PACKET=3,SREAD=4,SEND_WORD=5,WAIT_COMPLETION=6,CRC_WORD=7;
 reg[2:0]state;reg[5:0]index;
 reg typed_hna;reg[31:0]crc_acc,crc_shift;reg[1:0]crc_byte;
 reg aw_hold,w_hold,command_pending,stage_read_pending;reg[11:0]awaddr;reg[31:0]wdata;reg[3:0]wstrb;
 reg[63:0]written;reg[31:0]token_counter,pending_token;
 reg mac_started;reg[31:0]terminal_token,terminal_error,status_seq;reg[1:0]terminal_kind;reg[6:0]words_accepted;
 wire transport_failed=HONOR_TRANSPORT_FAULT!=0&&(transport_fault!==1'b0);
 wire[2:0]phase=state==IDLE?0:(state==VREAD||state==VCHECK||state==CRC_WORD)?1:mac_started?3:2;
 reg invalid;
 wire write_execute=aw_hold&&w_hold&&!s_bvalid&&!command_pending;
 wire bad_start=mac_started_valid&&(state!=WAIT_COMPLETION||mac_started_token!==pending_token||mac_started);
 wire bad_complete=completion_valid&&(state!=WAIT_COMPLETION||completion_token!==pending_token);
 wire status_event=write_execute||(state==VCHECK&&(invalid||index==63))||
  (packet_begin_valid&&packet_begin_ready)||(word_valid&&word_ready)||mac_started_valid||completion_valid||(transport_failed&&!local_fault)||(state==BEGIN_PACKET&&transport_failed);
 (* ram_style="block" *)reg[31:0]staging[0:63];reg[31:0]ram_q;
 wire stage_ar=s_arvalid&&s_arready&&state==IDLE&&s_araddr>=12'h500&&s_araddr<=12'h5fc&&s_araddr[1:0]==0&&written[s_araddr[7:2]];
 wire stage_aw=aw_hold&&w_hold&&!s_bvalid&&!command_pending&&state==IDLE&&awaddr>=12'h500&&awaddr<=12'h5fc&&awaddr[1:0]==0&&wstrb==15;
 wire internal_read=state==VREAD||state==SREAD;
 wire[5:0]read_index=stage_ar?s_araddr[7:2]:index;
 // One synchronous read port plus independent write port. No array/reset loop.
 always@(posedge clk)begin
  if(stage_aw)staging[awaddr[7:2]]<=wdata;
  if(stage_ar||internal_read)ram_q<=staging[read_index];
 end
 reg[7:0]flags,op,status,pane;reg[2:0]roi_count,done_count;reg[31:0]record_state;
 reg key_nonzero,sha_nonzero,error_nonzero;reg[31:0]pair_or;
 reg[15:0]roi_x,roi_y;reg[31:0]roi_class,roi_sequence;reg roi_logit_nonzero;
 function automatic[31:0]be32(input[31:0]w);be32={w[7:0],w[15:8],w[23:16],w[31:24]};endfunction
 wire[31:0]v=be32(ram_q);
 wire[7:0]p_flags=ram_q[31:24],p_status=ram_q[23:16],p_op=ram_q[15:8],p_pane=ram_q[7:0];
 wire[2:0]roi_number=(index-24)>>3;wire[2:0]roi_word=(index-24)&7;
 wire[15:0]coord_a={ram_q[7:0],ram_q[15:8]},coord_b={ram_q[23:16],ram_q[31:24]};
 function automatic[31:0]crc32_byte(input[31:0]c,input[7:0]b);
  reg[31:0]t;integer k;begin t=c^{24'd0,b};for(k=0;k<8;k=k+1)t=t[0]?(t>>1)^32'hedb88320:(t>>1);crc32_byte=t;end
 endfunction
 wire check_hna=index==0?(ram_q===32'h31414e48):typed_hna;
 always@*begin
  invalid=0;
  if(check_hna)begin
   case(index)
    0:invalid=ram_q!=32'h31414e48; // bytes HNA1
    1:invalid=ram_q!=32'h01010100; // BE16 version1/type0101
    2:invalid=ram_q[31:16]!=16'h0101||
      !((ram_q[7:0]==1&&ram_q[15:8]==0)||
        (ram_q[7:0]==2&&(ram_q[15:8]==1||ram_q[15:8]==3||ram_q[15:8]==4)));
    3:invalid=ram_q!=32'h00010000; // BE32 body256
    5,7,9:invalid=(pair_or|ram_q)==0; // LE64 session/nonce/batch
    10:invalid=ram_q==0||ram_q>100; // LE32 requested ordinal
    63:invalid=ram_q!==~crc_acc; // CRC32LE of exact first252 bytes
    default:if(index>=11&&index<=62)invalid=ram_q!=0;
   endcase
  end else begin
  case(index)
   0:invalid=ram_q!=32'h31534948; // bytes HIS1
   1:invalid=ram_q!=32'h00010100; // BE16v1/type0100
   3,5,7:invalid=(pair_or|ram_q)==0;
   8:invalid=v==0||v>100;
   9:invalid=(p_flags&8'hf8)!=0||!p_flags[0]||
      !((p_op==1&&p_pane==0&&(p_status==1||p_status==4))||
        (p_op==2&&(p_pane==1||p_pane==3||p_pane==4)&&p_status>=2&&p_status<=4));
   11,12,13,14:invalid=v==0;
   17:invalid=v<1||v>5;
   18:invalid=v>4;
   23:invalid=v!=256;
   default:begin end
  endcase
  if(index>=24&&index<56)begin
   if(roi_number>=roi_count)invalid=ram_q!=0;
   else case(roi_word)
    1:invalid=roi_x>=coord_a||coord_a>HISTORY_WIDTH||roi_y>=coord_b||coord_b>HISTORY_HEIGHT;
    6:invalid=v>1||(v==1&&(roi_class>=105||roi_sequence==0))||
                (v==0&&(roi_class!=32'hffffffff||roi_logit_nonzero||roi_sequence!=0));
    7:invalid=ram_q!=0;
    default:begin end
   endcase
  end
  if(index==63)invalid=invalid||((record_state==5)!=error_nonzero)||
    ((record_state==1||record_state==3)&&roi_count!=0)||
    (record_state==4&&(roi_count==0||done_count!=roi_count))||
    (record_state==2&&(roi_count==0||done_count==roi_count))||
    (flags[2]!=key_nonzero)||(flags[1]!=(sha_nonzero||ram_q!=0));
  end
  if((^ram_q)===1'bx)invalid=1;
 end
 assign local_busy=state!=IDLE||command_pending;
 assign s_awready=!aw_hold&&!s_bvalid&&!command_pending;
 assign s_wready=!w_hold&&!s_bvalid&&!command_pending;
 assign s_arready=!s_rvalid&&!stage_read_pending;
 assign packet_begin_valid=state==BEGIN_PACKET;
 assign packet_token=pending_token;
 assign word_valid=state==SEND_WORD;
 // Constants are forced even after validation. PS cannot substitute NTR2/NAR2.
 assign word_data=typed_hna?(index==0?32'h31414e48:index==1?32'h01010100:
                  index==2?{8'h01,8'h01,ram_q[15:0]}:index==3?32'h00010000:ram_q):(index==0?32'h31534948:index==1?32'h00010100:
                  index==9?{((ram_q[31:24]&8'h06)|8'h01),ram_q[23:0]}:
                  index==23?32'h00010000:ram_q);
 assign word_last=index==63;
 task reject;input[7:0]code;begin state<=IDLE;command_pending<=0;s_bvalid<=1;s_bresp<=2;local_error<=code;rejected_count<=(rejected_count==32'hffffffff ? rejected_count : rejected_count+1);end endtask
 always@(posedge clk)begin
  if(!board_resetn)begin
   typed_hna<=0;crc_acc<=32'hffffffff;crc_shift<=0;crc_byte<=0;
   state<=IDLE;index<=0;aw_hold<=0;w_hold<=0;awaddr<=0;wdata<=0;wstrb<=0;command_pending<=0;stage_read_pending<=0;
   s_bvalid<=0;s_rvalid<=0;s_bresp<=0;s_rresp<=0;s_rdata<=0;written<=0;token_counter<=0;pending_token<=0;
   local_fault<=0;local_error<=0;sent_count<=0;rejected_count<=0;mac_started<=0;terminal_token<=0;terminal_error<=0;terminal_kind<=0;status_seq<=0;words_accepted<=0;
   flags<=0;op<=0;status<=0;pane<=0;roi_count<=0;done_count<=0;record_state<=0;
   key_nonzero<=0;sha_nonzero<=0;error_nonzero<=0;pair_or<=0;roi_x<=0;roi_y<=0;roi_class<=0;roi_sequence<=0;roi_logit_nonzero<=0;
  end else begin
   if(s_awvalid&&s_awready)begin aw_hold<=1;awaddr<=s_awaddr;end
   if(s_wvalid&&s_wready)begin w_hold<=1;wdata<=s_wdata;wstrb<=s_wstrb;end
   if(s_bvalid&&s_bready)s_bvalid<=0;
   if(s_rvalid&&s_rready)s_rvalid<=0;
   if(stage_read_pending)begin stage_read_pending<=0;s_rvalid<=1;s_rresp<=0;s_rdata<=ram_q;end
   if(s_arvalid&&s_arready)begin
    s_rvalid<=1;s_rresp<=0;s_rdata<=0;
    case(s_araddr)
     12'h400:s_rdata<=32'h48535458;
     12'h404:s_rdata<=32'h00030000;
     12'h43c:s_rdata<=32'h00010000; // typed capability ABI1
     12'h440:s_rdata<=32'h00000001; // HNA1 DISPLAY_ONLY supported
     12'h408:s_rdata<={21'd0,local_fault,(local_error!=0),(written==64'hffffffffffffffff),5'd0,phase};
     12'h410:s_rdata<=pending_token;
     12'h414:s_rdata<={24'd0,local_error};
     12'h418:s_rdata<=written[31:0];12'h41c:s_rdata<=written[63:32];
     12'h420:s_rdata<=sent_count;12'h424:s_rdata<=rejected_count;
     12'h428:s_rdata<=terminal_token;12'h42c:s_rdata<={30'd0,terminal_kind};
     12'h430:s_rdata<=terminal_error;12'h434:s_rdata<=status_seq;12'h438:s_rdata<={25'd0,words_accepted};
     default:if(stage_ar)begin stage_read_pending<=1;s_rvalid<=0;end else s_rresp<=2;
    endcase
   end
   if(aw_hold&&w_hold&&!s_bvalid&&!command_pending)begin
    aw_hold<=0;w_hold<=0;s_bvalid<=1;s_bresp<=0;
    if(stage_aw)written[awaddr[7:2]]<=1;
    else if(awaddr==12'h40c&&wstrb==15&&wdata==2&&state==IDLE)begin
     written<=0;local_fault<=0;local_error<=0;
    end else if(awaddr==12'h40c&&wstrb==15&&wdata==1&&state==IDLE)begin
     if(written!=64'hffffffffffffffff||local_fault||transport_failed||status_seq[0]||token_counter==32'hffffffff)begin s_bresp<=2;local_error<=8'h01;rejected_count<=(rejected_count==32'hffffffff ? rejected_count : rejected_count+1);end
     else begin
      typed_hna<=0;crc_acc<=32'hffffffff;crc_shift<=0;crc_byte<=0;
      command_pending<=1;s_bvalid<=0;state<=VREAD;index<=0;key_nonzero<=0;sha_nonzero<=0;error_nonzero<=0;done_count<=0;pair_or<=0;
     end
    end else begin s_bresp<=2;local_error<=8'h02;rejected_count<=(rejected_count==32'hffffffff ? rejected_count : rejected_count+1);end
   end
   if(bad_start||bad_complete)begin local_fault<=1;local_error<=8'h06;end
   if(mac_started_valid&&!bad_start)mac_started<=1;
   case(state)
    VREAD:state<=VCHECK;
    VCHECK:if(invalid||local_fault||transport_failed||bad_start||bad_complete)reject(invalid?8'h03:8'h06);else begin
     if(index==0)typed_hna<=check_hna;
     if(check_hna)begin
      if(index==4||index==6||index==8)pair_or<=ram_q;
     end else begin
     if(index==2||index==4||index==6)pair_or<=ram_q;
     if(index==9)begin flags<=p_flags;op<=p_op;status<=p_status;pane<=p_pane;end
     if(index==16)error_nonzero<=ram_q!=0;
     if(index==17)record_state<=v;
     if(index==18)roi_count<=v[2:0];
     if(index>=19&&index<=22)key_nonzero<=key_nonzero||ram_q!=0;
     if(index>=56)sha_nonzero<=sha_nonzero||ram_q!=0;
     if(index>=24&&index<56&&roi_number<roi_count)case(roi_word)
      0:begin roi_x<=coord_a;roi_y<=coord_b;roi_logit_nonzero<=0;end
      2:roi_class<=v;
      3,4:roi_logit_nonzero<=roi_logit_nonzero||ram_q!=0;
      5:roi_sequence<=v;
      6:if(v==1)done_count<=done_count+1;
      default:begin end
     endcase
     end
     if(index==63)begin
      token_counter<=token_counter+1;pending_token<=token_counter+1;state<=BEGIN_PACKET;index<=0;
      command_pending<=0;s_bvalid<=1;s_bresp<=0;mac_started<=0;words_accepted<=0;
     end
     else if(check_hna)begin crc_shift<=ram_q;crc_byte<=0;state<=CRC_WORD;end
     else begin index<=index+1;state<=VREAD;end
    end
    CRC_WORD:begin
     crc_acc<=crc32_byte(crc_acc,crc_shift[7:0]);crc_shift<={8'd0,crc_shift[31:8]};
     if(crc_byte==3)begin index<=index+1;state<=VREAD;end else crc_byte<=crc_byte+1;
    end
    BEGIN_PACKET:if(transport_failed)begin
      // B already acknowledged a local queue, never wire completion. An idle
      // transport fatal cannot strand that queue or pretend it was SENT.
      state<=IDLE;written<=0;terminal_token<=pending_token;terminal_kind<=2;terminal_error<=5;local_error<=5;
     end else if(packet_begin_valid&&packet_begin_ready)begin state<=SREAD;index<=0;end
    SREAD:state<=SEND_WORD;
    SEND_WORD:if(word_valid&&word_ready)begin
     words_accepted<=words_accepted+1;
     if(word_last)state<=WAIT_COMPLETION;
     else begin index<=index+1;state<=SREAD;end
    end
    WAIT_COMPLETION:if(completion_valid&&completion_token==pending_token)begin
     state<=IDLE;written<=0;terminal_token<=pending_token;
     // Completion cannot be inferred from source transfer, timeout or PS write.
     if(completion_error!==1'b0||local_fault||transport_failed||bad_start||!(mac_started||(mac_started_valid===1'b1&&!bad_start)))begin
      terminal_kind<=2;terminal_error<=completion_error!==1'b0 ? 32'h05 : 32'h06;local_error<=8'h05;rejected_count<=(rejected_count==32'hffffffff ? rejected_count : rejected_count+1);
     end else begin terminal_kind<=1;terminal_error<=0;sent_count<=sent_count+1;end
    end
    default:begin end
   endcase
   // Atomic stamp changes on the same edge as every externally observable event.
   if(status_event&&!status_seq[0])begin
    if(status_seq>=32'hfffffffc)status_seq<=32'hffffffff;
    else status_seq<=status_seq+2;
   end
   if(transport_failed)begin local_fault<=1;local_error<=8'h05;end
   // Odd permanently marks exhausted status snapshots; CLEAR cannot revive it.
   if(status_seq[0]||(status_event&&status_seq>=32'hfffffffc))begin local_fault<=1;local_error<=8'h08;end
  end
 end
endmodule
