`timescale 1ns/1ps
// Full 4KiB decode. One independent read and write transaction; AW and W may
// arrive in either order. No aliasing by truncating to a sub-page address.
module ordinary_hdmi_axil_router #(parameter integer ENABLE_SLOT_REPLAY=0, parameter integer ENABLE_C3_EN_RESET=0,parameter integer ENABLE_PS_NORMAL_TASK_REQUEST=0,parameter integer ENABLE_MIC_RAW_DIAGNOSTICS=0)(
 input wire clk,rst_n,
 input wire[11:0]s_awaddr,s_araddr,input wire s_awvalid,s_wvalid,s_bready,s_arvalid,s_rready,
 input wire[31:0]s_wdata,input wire[3:0]s_wstrb,
 output wire s_awready,s_wready,s_arready,output reg s_bvalid,s_rvalid,
 output reg[1:0]s_bresp,s_rresp,output reg[31:0]s_rdata,
 output wire[11:0]m_awaddr,m_araddr,output wire[31:0]m_wdata,output wire[3:0]m_wstrb,
 output wire[3:0]m_awvalid,m_wvalid,m_bready,m_arvalid,m_rready,
 input wire[3:0]m_awready,m_wready,m_bvalid,m_arready,m_rvalid,
 input wire[7:0]m_bresp,m_rresp,input wire[127:0]m_rdata
);
 function[2:0]target;input[11:0]a;begin
  target=4;
  if(a[1:0]==0)begin
   if(a<=12'h038 || (ENABLE_C3_EN_RESET!=0 && a>=12'h040 && a<=12'h05c) || (ENABLE_PS_NORMAL_TASK_REQUEST!=0 && a>=12'h060 && a<=12'h090) || (ENABLE_MIC_RAW_DIAGNOSTICS!=0 && a>=12'h094 && a<=12'h0d0))target=0; // Original HDMI control ABI, unchanged.
   else if(a>=12'h800&&a<=12'h8bc)target=1; // Plain PVW, normalized by caller.
   else if(a>=12'hc00&&a<=12'hdfc)target=2;
   else if(ENABLE_SLOT_REPLAY!=0&&a>=12'ha00&&a<=12'ha7c)target=3; // PS_UNTRUSTED HIS/HNA.
  end
 end endfunction
 reg aw_hold,w_hold,wr_active,aw_sent,w_sent;
 reg[11:0]aw_addr,ar_addr;reg[31:0]w_data;reg[3:0]w_strb;reg[2:0]wt,rt;
 reg rd_active,ar_sent;
 assign s_awready=!aw_hold&&!wr_active&&!s_bvalid;
 assign s_wready=!w_hold&&!wr_active&&!s_bvalid;
 assign s_arready=!rd_active&&!s_rvalid;
 assign m_awaddr=aw_addr;assign m_wdata=w_data;assign m_wstrb=w_strb;assign m_araddr=ar_addr;
 genvar i;generate for(i=0;i<4;i=i+1)begin:g_target
  assign m_awvalid[i]=wr_active&&wt==i&&!aw_sent;
  assign m_wvalid[i]=wr_active&&wt==i&&!w_sent;
  assign m_bready[i]=wr_active&&wt==i&&aw_sent&&w_sent&&!s_bvalid;
  assign m_arvalid[i]=rd_active&&rt==i&&!ar_sent;
  assign m_rready[i]=rd_active&&rt==i&&ar_sent&&!s_rvalid;
 end endgenerate
 always@(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   aw_hold<=0;w_hold<=0;wr_active<=0;aw_sent<=0;w_sent<=0;aw_addr<=0;w_data<=0;w_strb<=0;wt<=4;
   rd_active<=0;ar_sent<=0;ar_addr<=0;rt<=4;s_bvalid<=0;s_bresp<=0;s_rvalid<=0;s_rresp<=0;s_rdata<=0;
  end else begin
   if(s_awvalid&&s_awready)begin aw_hold<=1;aw_addr<=s_awaddr;end
   if(s_wvalid&&s_wready)begin w_hold<=1;w_data<=s_wdata;w_strb<=s_wstrb;end
   if(aw_hold&&w_hold&&!wr_active&&!s_bvalid)begin
    aw_hold<=0;w_hold<=0;wt<=target(aw_addr);aw_sent<=0;w_sent<=0;
    if(target(aw_addr)==4)begin s_bvalid<=1;s_bresp<=2;end else wr_active<=1;
   end
   if(wr_active)begin
    if(m_awvalid[wt]&&m_awready[wt])aw_sent<=1;
    if(m_wvalid[wt]&&m_wready[wt])w_sent<=1;
    if(m_bready[wt]&&m_bvalid[wt])begin s_bvalid<=1;s_bresp<=m_bresp[wt*2+:2];wr_active<=0;end
   end
   if(s_bvalid&&s_bready)s_bvalid<=0;
   if(s_arvalid&&s_arready)begin
    ar_addr<=s_araddr;rt<=target(s_araddr);ar_sent<=0;
    if(target(s_araddr)==4)begin s_rvalid<=1;s_rresp<=2;s_rdata<=0;end else rd_active<=1;
   end
   if(rd_active)begin
    if(m_arvalid[rt]&&m_arready[rt])ar_sent<=1;
    if(m_rready[rt]&&m_rvalid[rt])begin s_rvalid<=1;s_rresp<=m_rresp[rt*2+:2];s_rdata<=m_rdata[rt*32+:32];rd_active<=0;end
   end
   if(s_rvalid&&s_rready)s_rvalid<=0;
  end
 end
endmodule
