`timescale 1ns/1ps
// FILE-ONLY CANDIDATE, NOT IN R11. cmd_accept is a one-cycle ordinary-MMIO
// accepted-write pulse, never a VIO/security/NN/owner signal. No auto retry.
module c3_en_open_drain_pulse #(
 parameter integer PULSE_CYCLES=5000000 // 100 ms ONLY with an actual 50 MHz clk
)(
 input wire clk,board_resetn,
 input wire cmd_accept,
 output wire busy,
 output reg done_pulse,
 output reg [31:0] accepted_count,completed_count,rejected_busy_count,
 output wire en_observed_high,
 inout wire c3_en_n
);
 localparam integer CW=(PULSE_CYCLES<2)?1:$clog2(PULSE_CYCLES+1);
 reg [CW-1:0] remaining;
 (* ASYNC_REG="TRUE" *) reg en_meta,en_sync;
 wire en_raw;
 wire pull_low=board_resetn&&(remaining!=0);
 // I is CONSTANT ZERO: hardware can only sink or release, never drive high.
 IOBUF #(.IOSTANDARD("LVCMOS33"),.DRIVE(4),.SLEW("SLOW"))
  en_iobuf(.I(1'b0),.T(!pull_low),.O(en_raw),.IO(c3_en_n));
 assign busy=(remaining!=0);
 assign en_observed_high=en_sync; // voltage-level observation, NOT boot/listener READY
 always @(posedge clk or negedge board_resetn) begin
  if(!board_resetn)begin
   remaining<=0;done_pulse<=0;accepted_count<=0;completed_count<=0;
   rejected_busy_count<=0;en_meta<=0;en_sync<=0;
  end else begin
   en_meta<=en_raw;en_sync<=en_meta;done_pulse<=0;
   if(remaining!=0)begin
    remaining<=remaining-1'b1;
    if(remaining==1)begin done_pulse<=1;completed_count<=completed_count+1'b1;end
    if(cmd_accept)rejected_busy_count<=rejected_busy_count+1'b1;
   end else if(cmd_accept)begin
    remaining<=PULSE_CYCLES;accepted_count<=accepted_count+1'b1;
   end
  end
 end
endmodule
