`ifndef ORDINARY_PS_TASK_REQUESTER_SV
`define ORDINARY_PS_TASK_REQUESTER_SV
`timescale 1ns/1ps
// Untrusted INTENT only. No root/key/flow-ACK/PCM/result injection interface.
module ordinary_ps_task_requester #(parameter integer ENABLE=0,parameter integer ENABLE_MIC=1,parameter integer ENABLE_RUN=1)(
 input wire clk,security_reset_n,
 input wire request_valid,input wire[31:0]request_command,request_epoch,request_model,
 input wire[3:0]request_strobes,output wire[7:0]request_error,
 input wire authority_live,input wire[31:0]runtime_epoch,model_epoch,
 input wire[31:0]vio_command,input wire vio_busy,vio_start,vio_stop,
 input wire start_ready,run_busy,run_granted,flow_block,task_boundary_quiet,
 output wire start_grant,stop_grant,preview_inhibit,
 output wire mic_request_valid,input wire mic_request_ready,
 output wire[31:0]mic_request_epoch,mic_request_model,
 input wire mic_result_valid,input wire[7:0]mic_result_error,input wire[159:0]mic_capture_context,
 input wire mic_completion_valid,input wire[159:0]mic_completion_context,input wire[31:0]mic_completion_sequence,
 output wire[31:0]result_word,status_word,output wire[223:0]witness_words
);
 reg pending,stop_sent,mic_wait,mic_capture_seen,mic_complete_seen;
 reg[7:0]pending_op,last_error;
 reg[23:0]pending_sequence,last_sequence,completed_sequence,vio_seen;
 reg[31:0]bound_epoch,bound_model;
 reg[15:0]rejected_count;
 reg witness_valid,witness_blocked;reg[23:0]witness_sequence;
 reg[31:0]witness_clip,witness_generation,witness_record_sequence;
 wire vio_collision=vio_busy||vio_start||vio_stop||vio_command[31:8]!=vio_seen;
 wire context_live=authority_live&&runtime_epoch!=0&&model_epoch!=0&&
  runtime_epoch==bound_epoch&&model_epoch==bound_model;
 wire legal_op=(ENABLE_MIC!=0&&request_command[7:0]==5)||(ENABLE_RUN!=0&&(request_command[7:0]==10||request_command[7:0]==11));
 assign request_error=ENABLE==0 ? 8'h07 : request_strobes!=4'hf ? 8'h02 : !legal_op ? 8'h07 : 
  request_command[31:8]==0||request_command[31:8]<=last_sequence ? 8'h08 : 
  pending||vio_collision ? 8'h04 : !authority_live||runtime_epoch==0||model_epoch==0||
  request_epoch!=runtime_epoch||request_model!=model_epoch ? 8'h06 : 8'h00;
 wire safe_boundary=task_boundary_quiet&&!run_busy&&!flow_block;
 wire capture_matches=mic_capture_context[159:128]==bound_model&&mic_capture_context[127:96]==bound_epoch&&
  mic_capture_context[95:64]==2&&mic_capture_context[63:32]!=0&&mic_capture_context[31:0]!=0;
 wire completion_matches=mic_completion_context[159:128]==bound_model&&mic_completion_context[127:96]==bound_epoch&&
  mic_completion_context[95:64]==2&&mic_completion_context[63:32]==witness_clip&&mic_completion_context[31:0]==witness_generation&&mic_completion_sequence!=0;
 assign start_grant=ENABLE!=0&&pending&&!mic_wait&&pending_op==10&&context_live&&!vio_collision&&safe_boundary&&start_ready&&!vio_stop;
 // STOP only withdraws future ordinary offers. Never clear/ACK an active task.
 assign stop_grant=ENABLE!=0&&pending&&!mic_wait&&(pending_op==5||pending_op==11)&&!stop_sent&&context_live&&!vio_collision;
 assign preview_inhibit=ENABLE!=0&&pending&&pending_op==5&&context_live;
 assign mic_request_valid=ENABLE!=0&&pending&&!mic_wait&&pending_op==5&&stop_sent&&context_live&&!vio_collision&&safe_boundary;
 assign mic_request_epoch=bound_epoch;assign mic_request_model=bound_model;
 assign result_word=ENABLE!=0 ? {last_error,completed_sequence}:32'd0;
 assign status_word=ENABLE!=0 ? {rejected_count,pending_op,run_granted,mic_complete_seen,mic_capture_seen,(!pending&&authority_live&&!vio_collision),mic_wait,preview_inhibit,stop_sent,pending}:32'd0;
 wire witness_live=ENABLE!=0&&witness_valid&&authority_live&&runtime_epoch==bound_epoch&&model_epoch==bound_model&&!vio_collision&&!(request_valid&&request_strobes==4'hf);
 // Public identifiers only; key/session/fingerprint/PCM/logits are not exported.
 assign witness_words=witness_live ? {witness_record_sequence,witness_generation,witness_clip,32'd2,bound_model,bound_epoch,{1'b1,7'd0,witness_sequence}}:224'd0;
 task finish(input[7:0]e);begin
  if(e==0&&pending_op==5&&mic_capture_seen&&mic_complete_seen&&!vio_collision&&!witness_blocked)begin witness_valid<=1;witness_sequence<=pending_sequence;end
  last_error<=e;completed_sequence<=pending_sequence;pending<=0;stop_sent<=0;mic_wait<=0;mic_capture_seen<=0;mic_complete_seen<=0;pending_op<=0;
 end endtask
 always@(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   pending<=0;stop_sent<=0;mic_wait<=0;mic_capture_seen<=0;mic_complete_seen<=0;pending_op<=0;last_error<=0;
   pending_sequence<=0;last_sequence<=0;completed_sequence<=0;bound_epoch<=0;bound_model<=0;vio_seen<=0;rejected_count<=0;
   witness_valid<=0;witness_blocked<=0;witness_sequence<=0;witness_clip<=0;witness_generation<=0;witness_record_sequence<=0;
  end else begin
   vio_seen<=vio_command[31:8];
   if(ENABLE!=0)begin
    if(!authority_live||runtime_epoch!=bound_epoch||model_epoch!=bound_model||vio_collision)witness_valid<=0;
    if(pending&&mic_wait&&vio_collision)witness_blocked<=1;
    if(pending)begin
     // A new trusted command wins. Never carry a PS intent through rekey/revoke.
     if(!context_live||(vio_collision&&!mic_wait))finish(8'h0b);
     else begin
      if(stop_grant)stop_sent<=1;
      if(pending_op==10&&run_granted)finish(8'h00); // Already true; no second grant/task.
      else if(start_grant)finish(8'h00);
      else if(pending_op==11&&stop_sent&&safe_boundary)finish(8'h00);
      else if(mic_request_valid&&mic_request_ready)mic_wait<=1;
      else if(mic_wait)begin
       if(mic_result_valid&&mic_result_error!=0)finish(mic_result_error);
       else if(mic_result_valid&&!mic_capture_seen&&!capture_matches)finish(8'h0c);
       else begin
        if(mic_result_valid&&!mic_capture_seen)begin
         mic_capture_seen<=1;witness_clip<=mic_capture_context[63:32];witness_generation<=mic_capture_context[31:0];
        end
        if(mic_completion_valid&&completion_matches&&mic_capture_seen&&!mic_complete_seen)begin
         mic_complete_seen<=1;witness_record_sequence<=mic_completion_sequence;
        end
        if(mic_capture_seen&&mic_complete_seen&&safe_boundary)finish(witness_blocked||vio_collision ? 8'h0b : 8'h00);
       end
      end
     end
    end
    // One request at a time. Rejections never enqueue or implicitly replay.
    if(request_valid&&request_error==0)begin
     pending<=1;pending_op<=request_command[7:0];pending_sequence<=request_command[31:8];
     bound_epoch<=runtime_epoch;bound_model<=model_epoch;stop_sent<=0;mic_wait<=0;mic_capture_seen<=0;mic_complete_seen<=0;witness_blocked<=0;
    end
    if(request_valid&&request_strobes==4'hf)begin
     witness_valid<=0;
     // A complete intent consumes its fresh PS generation even on rejection.
     // It is never retained for a later authorized context or automatic retry.
     if(request_command[31:8]>last_sequence)last_sequence<=request_command[31:8];
     if(request_error!=0)begin
      last_error<=request_error;completed_sequence<=request_command[31:8];
      if(rejected_count!=16'hffff)rejected_count<=rejected_count+1'b1;
     end
    end
   end
  end
 end
endmodule
`endif
