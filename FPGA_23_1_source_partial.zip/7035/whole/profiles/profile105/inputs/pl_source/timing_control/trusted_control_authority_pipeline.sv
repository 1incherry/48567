`timescale 1ns/1ps
// Only retained FFs and direct source predicates enter this control boundary.
// The policy FF is the existing fixed-key SLH authority's authenticated token;
// this module cannot create one. Public authority is COMBINATIONAL and closes
// on the actual leaf fault in the same cycle. Only private actor cancellation
// is pipelined. It never clears an accepted bus/owner/SHA credit.
module trusted_control_authority_pipeline #(
 parameter integer ENABLE=0,ACTORS=4
)(
 input wire clk,security_reset_n,
 input wire legacy_authorized,legacy_private_authorized,
 input wire legacy_raw_model,legacy_private_raw_model,
 input wire legacy_verify_begin,legacy_private_verify_begin,
 input wire legacy_model_revoke,legacy_private_model_revoke,
 input wire legacy_execution_authorized,legacy_abort,
 input wire root_run_scope_ff,root_key_scope_ff,provider_key_ff,
 input wire ps_live_public,ps_live_private,lease_valid_ff,policy_authority_ff,
 input wire phase_fault_leaf,other_model_fault,
 input wire service_cancel_public,service_cancel_private,
 input wire verify_public_nophase,verify_private_nophase,
 input wire feeder_cancel,user_revoke,audio_revoke,hard_fault,stage_fault,
 input wire[31:0]runtime_epoch,model_epoch,bound_runtime_epoch,bound_model_epoch,
 input wire[127:0]key_session,bound_key_session,
 input wire outputs_fault,cofactor_known,input wire closed_output_cofactor,
 input wire[ACTORS-1:0]actor_retired,
 output wire authorized,private_authorized,raw_model,private_raw_model,
 output wire verify_begin,private_verify_begin,model_revoke,private_model_revoke,
 output wire short_execution_fence,
 output wire[ACTORS-1:0]actor_authorized,actor_cancel,
 output wire cancellation_pipeline_retired
);
 wire raw_pub=security_reset_n&&policy_authority_ff&&!service_cancel_public&&
  !other_model_fault&&!phase_fault_leaf&&!verify_public_nophase;
 wire raw_priv=security_reset_n&&policy_authority_ff&&!service_cancel_private&&
  !other_model_fault&&!phase_fault_leaf&&!verify_private_nophase;
 wire changed_pub=verify_public_nophase||feeder_cancel||phase_fault_leaf||other_model_fault||hard_fault||
  !policy_authority_ff||service_cancel_public||model_epoch!=bound_model_epoch;
 wire changed_priv=verify_private_nophase||feeder_cancel||phase_fault_leaf||other_model_fault||hard_fault||
  !policy_authority_ff||service_cancel_private||model_epoch!=bound_model_epoch;
 wire immediate_stop=user_revoke||audio_revoke||hard_fault||stage_fault;
 wire bound_identity=runtime_epoch==bound_runtime_epoch&&model_epoch==bound_model_epoch&&key_session==bound_key_session;
 wire flat_pub=security_reset_n&&root_run_scope_ff&&root_key_scope_ff&&provider_key_ff&&
  ps_live_public&&lease_valid_ff&&raw_pub&&bound_identity&&!immediate_stop&&!feeder_cancel;
 wire flat_priv=security_reset_n&&root_run_scope_ff&&root_key_scope_ff&&provider_key_ff&&
  ps_live_private&&lease_valid_ff&&raw_priv&&bound_identity&&!immediate_stop&&!feeder_cancel;
 // The scalar leaf is factored out of the manifest-ready expression. When it
 // is asserted all authority is already zero; it must not traverse the long
 // model/root/cofactor chain before reaching the public denial fence.
 generate if(ENABLE==0)begin:literal_original
  assign authorized=legacy_authorized;assign private_authorized=legacy_private_authorized;
  assign raw_model=legacy_raw_model;assign private_raw_model=legacy_private_raw_model;
  assign verify_begin=legacy_verify_begin;assign private_verify_begin=legacy_private_verify_begin;
  assign model_revoke=legacy_model_revoke;assign private_model_revoke=legacy_private_model_revoke;
  assign short_execution_fence=legacy_execution_authorized;
  assign actor_authorized={ACTORS{legacy_execution_authorized}};assign actor_cancel={ACTORS{legacy_abort}};
  assign cancellation_pipeline_retired=1;
 end else begin:pipelined_private_control
  function automatic known512(input[511:0]v);begin known512=1;
   // synthesis translate_off
   if((^v)===1'bx)known512=0;
   // synthesis translate_on
  end endfunction
  wire primitive_known=known512({security_reset_n,root_run_scope_ff,root_key_scope_ff,provider_key_ff,
   ps_live_public,ps_live_private,lease_valid_ff,policy_authority_ff,phase_fault_leaf,other_model_fault,
   service_cancel_public,service_cancel_private,verify_public_nophase,verify_private_nophase,
   feeder_cancel,user_revoke,audio_revoke,hard_fault,stage_fault,runtime_epoch,model_epoch,
   bound_runtime_epoch,bound_model_epoch,key_session,bound_key_session});
  assign authorized=primitive_known&&(flat_pub===1'b1);
  assign private_authorized=primitive_known&&(flat_priv===1'b1);
  assign raw_model=primitive_known&&(raw_pub===1'b1);
  assign private_raw_model=primitive_known&&(raw_priv===1'b1);
  assign verify_begin=!phase_fault_leaf&&verify_public_nophase;
  assign private_verify_begin=!phase_fault_leaf&&verify_private_nophase;
  assign model_revoke=security_reset_n&&lease_valid_ff&&changed_pub;
  assign private_model_revoke=security_reset_n&&lease_valid_ff&&changed_priv;
  assign short_execution_fence=closed_output_cofactor&&cofactor_known?
    (!outputs_fault&&private_authorized):authorized;
  // Only these four local control FFs are preserved as separate replicas. No
  // datapath cell, placement, timing path, clock or physical exclusion is set.
  (* KEEP="TRUE",DONT_TOUCH="TRUE" *)reg[ACTORS-1:0]live_q;
  genvar a;
  for(a=0;a<ACTORS;a=a+1)begin:local_actor
   always@(posedge clk or negedge security_reset_n)begin
    if(!security_reset_n)live_q[a]<=0;
    else if(short_execution_fence!==1'b1)live_q[a]<=0;
    else if(!live_q[a]&&actor_retired[a]===1'b1)live_q[a]<=1;
   end
  end
  assign actor_authorized=live_q;
  assign actor_cancel=~live_q;
  assign cancellation_pipeline_retired=(&actor_retired)&&((live_q==0)||short_execution_fence);
 end endgenerate
endmodule
