`timescale 1ns/1ps
// Binds model-domain SLH authorization to one protected runtime/key session.
// Model epoch and runtime epoch are distinct namespaces. No PS-written bind bit.
module trusted_runtime_model_lease(
 input wire clk,security_reset_n,root_authorized,root_key_session_valid,stop,
 input wire [31:0] runtime_epoch,input wire [127:0] key_session_id,
 input wire raw_model_authorized,input wire [31:0] model_epoch,
 input wire model_verification_start,feeder_cancelled,model_fault,all_quiescent,
 output wire authorized,output wire revoke,output reg valid,
 output reg [31:0] bound_model_epoch,bound_runtime_epoch,
 output reg [127:0] bound_key_session
);
 wire binding_live=valid&&raw_model_authorized&&root_authorized&&root_key_session_valid&&
   model_epoch==bound_model_epoch&&runtime_epoch==bound_runtime_epoch&&key_session_id==bound_key_session;
 wire model_changed=model_verification_start||feeder_cancelled||model_fault||!raw_model_authorized||model_epoch!=bound_model_epoch;
 assign authorized=security_reset_n&&binding_live&&!stop&&!model_verification_start&&!feeder_cancelled&&!model_fault;
 // A replacement/cancel closes admission combinationally and reaches the
 // protected root even if it pulses for only one clock. Default boot denial
 // itself must not continuously cancel the model service's initial signature.
 // Do not gate revoke with root_authorized: the root authorized output itself
 // is combinationally gated by trusted_revoke, which would create a loop.
 assign revoke=security_reset_n&&valid&&model_changed;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin valid<=0;bound_model_epoch<=0;bound_runtime_epoch<=0;bound_key_session<=0;end
  else begin
   if(stop||!root_authorized||!root_key_session_valid||
      (valid&&(!binding_live||model_changed)))valid<=0;
   else if(!valid&&root_authorized&&root_key_session_valid&&raw_model_authorized&&
     !model_verification_start&&!feeder_cancelled&&!model_fault&&all_quiescent)begin
    valid<=1;bound_model_epoch<=model_epoch;bound_runtime_epoch<=runtime_epoch;bound_key_session<=key_session_id;
   end
  end
 end
endmodule
