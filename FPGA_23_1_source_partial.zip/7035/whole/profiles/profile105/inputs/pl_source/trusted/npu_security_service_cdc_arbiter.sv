`timescale 1ns/1ps
// Two trusted PL clients share exactly one authenticated page cache.
// phase 0 idle, 1 kernel(bit0), 2 head(bit1), 3 illegal/reserved.
// c_clk and s_clk may be asynchronous. Common rst_n resets BOTH domains.
// Toggle mailboxes use stable bundled data, held until a complete round trip.
// No PS-provided authority, owner, epoch or cached-success input is permitted.
module npu_security_service_cdc_arbiter #(
 parameter integer TIMEOUT_CYCLES=4000000
)(
 input wire c_clk,s_clk,rst_n,
 input wire c_clear,c_cancel,input wire [1:0] c_phase,
 input wire [1:0] c_page_request,input wire [63:0] c_expected_page_index,
 output wire [1:0] c_page_request_ready,
 input wire [1:0] c_cache_read,input wire [19:0] c_cache_read_addr,
 output wire [1:0] c_cache_read_valid,output wire [31:0] c_cache_read_data,
 output wire c_model_authorized,output wire [31:0] c_session_epoch,
 output wire c_cache_valid,output wire [31:0] c_cached_page_index,
 output wire c_recovery_ready,
 output wire c_busy,output reg c_fault,
 input wire s_model_authorized,s_cache_valid,s_fault,s_cancel,
 input wire [31:0] s_session_epoch,s_cached_page_index,
 output wire s_service_cancel,
 output wire s_page_request,output wire [31:0] s_expected_page_index,
 input wire s_page_request_ready,s_page_done,input wire [7:0] s_page_error,
 output wire s_cache_read,output wire [9:0] s_cache_read_addr,
 input wire s_cache_read_valid,input wire [31:0] s_cache_read_data
);
 // Async assertion, two local edges for reset release. Common rst_n must
 // assert into BOTH domains; neither domain can be warm-reset independently.
 (* ASYNC_REG="TRUE" *) reg [1:0] c_reset_pipe,s_reset_pipe;
 always @(posedge c_clk or negedge rst_n)begin
  if(!rst_n)c_reset_pipe<=0;else c_reset_pipe<={c_reset_pipe[0],1'b1};
 end
 always @(posedge s_clk or negedge rst_n)begin
  if(!rst_n)s_reset_pipe<=0;else s_reset_pipe<={s_reset_pipe[0],1'b1};
 end
 wire c_reset_n=c_reset_pipe[1],s_reset_n=s_reset_pipe[1];
 // Service status mailbox. Its contents cannot tear when epoch changes.
 reg [32:0] status_hold;reg status_toggle,status_ack;
 (* ASYNC_REG="TRUE" *) reg st1,st2,sa1,sa2;
 reg [32:0] c_status;reg status_known;
 reg [31:0] status_acked_epoch;
 (* ASYNC_REG="TRUE" *) reg bad1,bad2,cancel1,cancel2;
 reg cancel_toggle,cancel_level_seen,cancel_seen;
 (* ASYNC_REG="TRUE" *) reg ca1,ca2;
 wire cancel_pending=cancel_toggle!=ca2;
 wire s_bad=(s_model_authorized!==1'b1)||(s_fault!==1'b0)||(s_cancel!==1'b0);
 // If the service changes epoch, hold the consumer closed until the coherent
 // epoch snapshot has been acknowledged back into the service clock domain.
 wire s_status_block=s_bad||s_service_cancel||(s_session_epoch!==status_acked_epoch);
 reg source_block;
 always @(posedge s_clk or negedge s_reset_n)begin
  if(!s_reset_n)source_block<=1;else source_block<=s_status_block;
 end
 assign s_service_cancel=cancel2!=cancel_seen;
 always @(posedge c_clk or negedge c_reset_n)begin
  if(!c_reset_n)begin cancel_toggle<=0;cancel_level_seen<=0;ca1<=0;ca2<=0;end
  else begin
   ca1<=cancel_seen;ca2<=ca1;cancel_level_seen<=c_cancel;
   // Coalesce repeated cancels while one is in flight; clients stay blocked.
   if(c_cancel&&!cancel_level_seen&&!cancel_pending)cancel_toggle<=!cancel_toggle;
  end
 end
 always @(posedge s_clk or negedge s_reset_n)begin
  if(!s_reset_n)begin sa1<=0;sa2<=0;status_hold<=0;status_toggle<=0;status_acked_epoch<=0;cancel1<=0;cancel2<=0;cancel_seen<=0;end
  else begin
   sa1<=status_ack;sa2<=sa1;cancel1<=cancel_toggle;cancel2<=cancel1;cancel_seen<=cancel2;
   if(sa2==status_toggle)begin
    status_acked_epoch<=status_hold[31:0];
    if(status_hold!={s_model_authorized&&!s_fault&&!s_cancel,s_session_epoch})begin
     status_hold<={s_model_authorized&&!s_fault&&!s_cancel,s_session_epoch};status_toggle<=!status_toggle;
    end
   end
  end
 end
 always @(posedge c_clk or negedge c_reset_n)begin
  if(!c_reset_n)begin st1<=0;st2<=0;status_ack<=0;c_status<=0;status_known<=0;bad1<=1;bad2<=1;end
  else begin
   st1<=status_toggle;st2<=st1;bad1<=source_block;bad2<=bad1;
   if(st2!=status_ack)begin c_status<=status_hold;status_ack<=st2;status_known<=1;end
  end
 end
 assign c_model_authorized=c_reset_n&&status_known&&c_status[32]&&!bad2&&!c_cancel&&!cancel_pending&&!c_fault;
 assign c_session_epoch=c_status[31:0];
 assign c_recovery_ready=c_reset_n&&status_known&&c_status[32]&&!bad2&&
  !c_cancel&&!cancel_pending&&!c_busy&&c_phase==0;
 // Request mailbox, held until response acknowledgement returns.
 reg request_toggle;reg req_is_read;reg [31:0] req_page,req_epoch;reg [9:0] req_word;
 (* ASYNC_REG="TRUE" *) reg rq1,rq2;
 // Response mailbox, held until next request. Request capacity is exactly one.
 reg response_toggle;reg rsp_ok,rsp_is_read;reg [31:0] rsp_epoch,rsp_page,rsp_data;
 (* ASYNC_REG="TRUE" *) reg rp1,rp2;
 reg pending,poisoned,response_captured;reg [1:0] saved_phase;
 reg c_rsp_ok,c_rsp_is_read;reg [31:0] c_rsp_epoch,c_rsp_page,c_rsp_data;
 reg [31:0] ticks;reg cache_grant;reg [31:0] grant_page,grant_epoch;
 reg [1:0] read_valid;reg [31:0] read_data;
 wire legal_phase=(c_phase==1)||(c_phase==2);
 wire selected_page=(c_phase==1)?c_page_request[0]:((c_phase==2)?c_page_request[1]:1'b0);
 wire selected_read=(c_phase==1)?c_cache_read[0]:((c_phase==2)?c_cache_read[1]:1'b0);
 wire other_request=(c_phase==1)?(c_page_request[1]||c_cache_read[1]):
                    ((c_phase==2)?(c_page_request[0]||c_cache_read[0]):(|c_page_request|| |c_cache_read));
 wire [31:0] selected_index=(c_phase==1)?c_expected_page_index[31:0]:c_expected_page_index[63:32];
 wire [9:0] selected_word=(c_phase==1)?c_cache_read_addr[9:0]:c_cache_read_addr[19:10];
 wire available=!c_busy&&legal_phase&&c_model_authorized&&!c_clear&&!other_request;
 assign c_page_request_ready=available&&!selected_read?((c_phase==1)?2'b01:2'b10):2'b00;
 assign c_cache_valid=cache_grant&&c_model_authorized&&grant_epoch==c_session_epoch&&(!pending||req_is_read);
 assign c_cached_page_index=c_cache_valid?grant_page:32'd0;
 assign c_cache_read_valid=read_valid&{2{c_model_authorized&&!c_clear&&!pending&&saved_phase==c_phase}};
 assign c_cache_read_data=(|c_cache_read_valid)?read_data:32'd0;
 assign c_busy=pending||(|read_valid)||cancel_pending;
 always @(posedge c_clk or negedge c_reset_n)begin
  if(!c_reset_n)begin
   rp1<=0;rp2<=0;request_toggle<=0;req_is_read<=0;req_page<=0;req_epoch<=0;req_word<=0;
   pending<=0;poisoned<=0;response_captured<=0;saved_phase<=0;
   c_rsp_ok<=0;c_rsp_is_read<=0;c_rsp_epoch<=0;c_rsp_page<=0;c_rsp_data<=0;ticks<=0;cache_grant<=0;grant_page<=0;grant_epoch<=0;
   read_valid<=0;read_data<=0;c_fault<=0;
  end else begin
   rp1<=response_toggle;rp2<=rp1;read_valid<=0;
   if(c_clear&&!c_busy)begin c_fault<=0;cache_grant<=0;end
   if(!c_model_authorized||c_cancel||c_clear)cache_grant<=0;
   if(((|read_valid)&&c_phase!=saved_phase)||c_phase==3||other_request||(selected_page&&selected_read))begin c_fault<=1;cache_grant<=0;end
   if(pending)begin
    ticks<=ticks+1'b1;
    if(c_cancel||c_clear||!c_model_authorized||c_phase!=saved_phase||ticks>=TIMEOUT_CYCLES||selected_read||selected_page)begin
     poisoned<=1;cache_grant<=0;c_fault<=1;
    end
    // Do not abandon a toggle on cancel: drain its acknowledgement, so a late
    // response can never be mistaken for a fresh transaction.
    if(!response_captured&&rp2==request_toggle)begin
     // Capture the stable response bundle first; evaluate status/epoch only
     // from local registers on the following c_clk edge.
     c_rsp_ok<=rsp_ok;c_rsp_is_read<=rsp_is_read;c_rsp_epoch<=rsp_epoch;
     c_rsp_page<=rsp_page;c_rsp_data<=rsp_data;response_captured<=1;
    end else if(response_captured)begin
     pending<=0;response_captured<=0;
     if(!poisoned&&!c_cancel&&!c_clear&&c_model_authorized&&c_phase==saved_phase&&
        c_rsp_ok&&c_rsp_epoch==req_epoch&&c_rsp_epoch==c_session_epoch&&c_rsp_page==req_page)begin
      cache_grant<=1;grant_page<=c_rsp_page;grant_epoch<=c_rsp_epoch;
      if(c_rsp_is_read&&req_is_read)begin read_data<=c_rsp_data;read_valid<=(saved_phase==1)?2'b01:2'b10;end
      else if(c_rsp_is_read!=req_is_read)begin c_fault<=1;cache_grant<=0;end
     end else begin c_fault<=1;cache_grant<=0;end
    end
   end else if(available&&(selected_page||selected_read)&&!(selected_page&&selected_read))begin
    if(selected_read&&!c_cache_valid)begin c_fault<=1;cache_grant<=0;end
    else begin
     pending<=1;poisoned<=0;response_captured<=0;ticks<=0;saved_phase<=c_phase;req_is_read<=selected_read;
     req_page<=selected_read?grant_page:selected_index;req_word<=selected_word;req_epoch<=c_session_epoch;
     request_toggle<=!request_toggle;if(!selected_read)cache_grant<=0;
    end
   end
  end
 end
 localparam S_IDLE=0,S_PAGE_REQ=1,S_PAGE_WAIT=2,S_READ_REQ=3,S_READ_WAIT=4,S_REPLY=5,S_ACCEPT=6;
 reg [2:0] s_state;reg [31:0] s_ticks;reg s_ok;
 reg s_req_is_read;reg [31:0] s_req_page,s_req_epoch;reg [9:0] s_req_word;
 wire service_live=(s_model_authorized===1'b1)&&(s_fault===1'b0)&&(s_cancel===1'b0)&&!s_service_cancel&&(s_session_epoch===s_req_epoch);
 wire service_page=service_live&&(s_cache_valid===1'b1)&&(s_cached_page_index===s_req_page);
 assign s_page_request=s_reset_n&&s_state==S_PAGE_REQ&&service_live;
 assign s_expected_page_index=s_req_page;
 assign s_cache_read=s_reset_n&&s_state==S_READ_REQ&&service_page;
 assign s_cache_read_addr=s_req_word;
 always @(posedge s_clk or negedge s_reset_n)begin
  if(!s_reset_n)begin
   rq1<=0;rq2<=0;response_toggle<=0;rsp_ok<=0;rsp_is_read<=0;rsp_epoch<=0;rsp_page<=0;rsp_data<=0;
   s_state<=S_IDLE;s_ticks<=0;s_ok<=0;s_req_is_read<=0;s_req_page<=0;s_req_epoch<=0;s_req_word<=0;
  end else begin
   rq1<=request_toggle;rq2<=rq1;
   if(s_state!=S_IDLE)begin
    s_ticks<=s_ticks+1'b1;
   end
   if(s_state!=S_IDLE&&s_state!=S_REPLY&&(!service_live||s_ticks>=TIMEOUT_CYCLES))begin
    s_ok<=0;s_state<=S_REPLY;
   end else case(s_state)
    S_IDLE:if(rq2!=response_toggle)begin
     // The request bundle has been stable for the two synchronizer stages.
     s_req_is_read<=req_is_read;s_req_page<=req_page;s_req_epoch<=req_epoch;s_req_word<=req_word;
     s_ticks<=0;s_state<=S_ACCEPT;
    end
    S_ACCEPT:begin
     s_ok<=service_live;rsp_is_read<=s_req_is_read;rsp_data<=0;
     if(!service_live)s_state<=S_REPLY;
     else if(s_req_is_read)begin if(service_page)s_state<=S_READ_REQ;else begin s_ok<=0;s_state<=S_REPLY;end end
     else s_state<=S_PAGE_REQ;
    end
    S_PAGE_REQ:if(service_live)begin
     if(s_page_request_ready)s_state<=S_PAGE_WAIT;
    end
    S_PAGE_WAIT:if(service_live&&s_page_done)begin
     s_ok<=service_page&&(s_page_error==0);s_state<=S_REPLY;
    end
    S_READ_REQ:if(service_live)begin
     if(service_page)s_state<=S_READ_WAIT;else begin s_ok<=0;s_state<=S_REPLY;end
    end
    S_READ_WAIT:if(service_live)begin
     if(!service_page)begin s_ok<=0;s_state<=S_REPLY;end
     else if(s_cache_read_valid)begin rsp_data<=s_cache_read_data;s_state<=S_REPLY;end
    end
    S_REPLY:begin
     rsp_ok<=s_ok&&service_page&&(!s_req_is_read||(s_page_error==0));
     rsp_epoch<=s_session_epoch;rsp_page<=s_cached_page_index;
     if(!s_ok||!service_page)rsp_data<=0;
     response_toggle<=rq2;s_state<=S_IDLE;
    end
    default:begin s_state<=S_IDLE;s_ok<=0;end
   endcase
  end
 end
endmodule
