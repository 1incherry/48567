`timescale 1ns/1ps
// Staged integration harness. Initial frontend/owner control remains outside
// the trusted boundary; compute control and all subsequent state are PL owned.
module npu_trusted_board_path(
 input wire clk,s_clk,rst_n,prepare_seed,frontend_owner,request_valid,
 output wire request_ready,model_authorized,done,fault,busy,
input wire [11:0] sec_awaddr,
input wire  sec_awvalid,
output wire  sec_awready,
input wire [31:0] sec_wdata,
input wire [3:0] sec_wstrb,
input wire  sec_wvalid,
output wire  sec_wready,
output wire [1:0] sec_bresp,
output wire  sec_bvalid,
input wire  sec_bready,
input wire [11:0] sec_araddr,
input wire  sec_arvalid,
output wire  sec_arready,
output wire [31:0] sec_rdata,
output wire [1:0] sec_rresp,
output wire  sec_rvalid,
input wire  sec_rready,
 input wire [31:0] frame_generation,
 output wire trusted_authorized,trusted_cancel,input wire handoff_ready,handoff_fault,private_read_fault,
 output wire [31:0] trusted_epoch,
 output wire handoff_start,handoff_seed,capture_pose,capture_norm,private_reads_phase,
 output wire signed [31:0] handoff_pose_coefficient,
 output wire classification_start,classification_capture,
 input wire classifier_page_request,input wire [31:0] classifier_expected_page_index,
 output wire classifier_page_request_ready,classifier_cache_valid,
 output wire [31:0] classifier_cached_page_index,
 input wire classifier_cache_read,input wire [9:0] classifier_cache_read_addr,
 output wire classifier_cache_read_valid,output wire [31:0] classifier_cache_read_data,
 input wire classifier_fault,trusted_result_valid,input wire [7:0] trusted_class_index,
 input wire signed [63:0] trusted_best_logit,input wire [31:0] trusted_result_epoch,
 output wire [3:0] current_block,output wire [15:0] debug_pc,
 output wire result_valid,output wire [7:0] result_class,
 output wire signed [63:0] result_best_logit,
 output wire [7:0] result_camera,
 output wire [31:0] result_frame,result_epoch,result_sequence,
 output wire [63:0] result_cycle,
 output wire [7:0] m_awaddr,output wire m_awvalid,input wire m_awready,
 output wire [31:0] m_wdata,output wire [3:0] m_wstrb,output wire m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output wire [7:0] m_araddr,output wire m_arvalid,input wire m_arready,
 input wire [31:0] m_rdata,input wire [1:0] m_rresp,input wire m_rvalid,output wire m_rready,
 input wire [31:0] s_araddr,input wire [7:0] s_arlen,
 input wire [2:0] s_arsize,input wire [1:0] s_arburst,
 input wire s_arvalid,output wire s_arready,
 output wire [255:0] s_rdata,output wire [1:0] s_rresp,
 output wire s_rlast,s_rvalid,input wire s_rready
);

 wire recovery_ready,recovery_clear;reg [31:0] recovered_epoch;
 wire manifest_start,manifest_ready,manifest_done,service_busy,feeder_cancel;
 wire msg_valid,msg_last,msg_ready,sig_valid,sig_last,sig_ready;
 wire page_valid,page_ready,proof_valid,proof_ready,page_request,page_request_ready;
 wire [31:0] msg_data,sig_data,page_data,proof_data,expected_page_index;
 wire [7:0] signature_error,policy_error,feeder_error;
 wire [31:0] session_epoch;wire seq_fault,seq_cancel,seq_handoff,seq_pose,seq_norm;
 wire signed [31:0] seq_coef;wire [1:0] phase;
 wire reader_fault,cdc_fault,service_fault;
 wire [8:0] expected_object;wire [3:0] expected_kind,expected_block,expected_qkv_op;
 wire [4:0] expected_dst,expected_stage;
 wire kernel_request,kernel_request_ready,kernel_cache_read,kernel_cache_read_valid;
 wire [31:0] kernel_expected_page_index,cache_read_data,cached_page_index;
 wire [9:0] kernel_cache_read_addr;
 wire cache_valid;wire [1:0] page_grant,read_grant;
 wire service_authorized,service_cache_valid,service_page_done,service_read,service_read_valid,service_cancel;
 wire [31:0] service_epoch,service_cached_page_index,service_read_data;
 wire [9:0] service_read_addr;wire [7:0] service_page_error;
 wire seq_busy;wire [7:0] error_code;
 assign recovery_clear=recovery_ready&&!seq_busy&&session_epoch!=recovered_epoch;
 always @(posedge clk)begin
  if(!rst_n)recovered_epoch<=0;
  else if(recovery_clear)recovered_epoch<=session_epoch;
 end
 assign busy=seq_busy;
 assign handoff_start=prepare_seed||seq_handoff;
 assign handoff_seed=frontend_owner;
 assign handoff_pose_coefficient=frontend_owner?32'sd498899827:seq_coef;
 assign capture_pose=frontend_owner||seq_pose;
 assign capture_norm=frontend_owner||seq_norm;
 assign trusted_authorized=model_authorized;
 assign trusted_epoch=session_epoch;
 assign trusted_cancel=seq_cancel;
 assign fault=seq_fault||reader_fault||cdc_fault||service_fault||handoff_fault||private_read_fault||classifier_fault;
 assign kernel_request_ready=page_grant[0];
 assign classifier_page_request_ready=page_grant[1];
 assign kernel_cache_read_valid=read_grant[0];
 assign classifier_cache_read_valid=read_grant[1];
 assign classifier_cache_valid=cache_valid;
 assign classifier_cached_page_index=cached_page_index;
 assign classifier_cache_read_data=cache_read_data;
 npu_trusted_vit_sequence #(.PROGRAM_WORDS(5317)) u_sequence(
 .clk(clk),.rst_n(rst_n),.request_valid(request_valid),.request_ready(request_ready),.request_rejected(),
 .model_authorized(model_authorized),.session_epoch(session_epoch),.seed_ready(handoff_ready),
 .trusted_camera_id(8'd0),.trusted_frame_id(frame_generation),
 .hardware_fault(reader_fault||cdc_fault||handoff_fault||private_read_fault||classifier_fault),
 .handoff_ready(handoff_ready),.head_result_valid(trusted_result_valid),.head_result_epoch(trusted_result_epoch),
 .head_class_index(trusted_class_index),.head_best_logit(trusted_best_logit),
 .busy(seq_busy),.done(done),.fault(seq_fault),.error_code(error_code),
 .trusted_cancel(seq_cancel),.handoff_start(seq_handoff),.classification_start(classification_start),
 .handoff_pose_coefficient(seq_coef),.private_reads_phase(private_reads_phase),
 .capture_pose(seq_pose),.capture_norm(seq_norm),.classification_capture(classification_capture),
 .service_phase(phase),.expected_object(expected_object),.expected_kind(expected_kind),
 .expected_block(expected_block),.expected_qkv_op(expected_qkv_op),.expected_dst(expected_dst),.expected_stage(expected_stage),
 .current_block(current_block),.completed_blocks(),.result_valid(result_valid),.result_class(result_class),
 .result_camera(result_camera),.result_best_logit(result_best_logit),.result_frame(result_frame),.result_epoch(result_epoch),.result_sequence(result_sequence),.result_cycle(result_cycle),.debug_pc(debug_pc),
 .m_awaddr(m_awaddr),.m_awvalid(m_awvalid),.m_awready(m_awready),.m_wdata(m_wdata),.m_wstrb(m_wstrb),.m_wvalid(m_wvalid),.m_wready(m_wready),
 .m_bresp(m_bresp),.m_bvalid(m_bvalid),.m_bready(m_bready),.m_araddr(m_araddr),.m_arvalid(m_arvalid),.m_arready(m_arready),
 .m_rdata(m_rdata),.m_rresp(m_rresp),.m_rvalid(m_rvalid),.m_rready(m_rready));
 npu_authenticated_axi_read reader(.clk(clk),.rst_n(rst_n),.clear(prepare_seed),.cancel(seq_cancel),
 .model_authorized(model_authorized),.session_epoch(session_epoch),.expected_object(expected_object),
 .expected_kind(expected_kind),.expected_block(expected_block),.expected_qkv_op(expected_qkv_op),.expected_dst(expected_dst),.expected_stage(expected_stage),
 .s_araddr(s_araddr),.s_arlen(s_arlen),.s_arsize(s_arsize),.s_arburst(s_arburst),.s_arvalid(s_arvalid),.s_arready(s_arready),
 .s_rdata(s_rdata),.s_rresp(s_rresp),.s_rlast(s_rlast),.s_rvalid(s_rvalid),.s_rready(s_rready),
 .page_request(kernel_request),.page_request_ready(kernel_request_ready),.expected_page_index(kernel_expected_page_index),
 .cache_valid(cache_valid),.cached_page_index(cached_page_index),.cache_read(kernel_cache_read),.cache_read_addr(kernel_cache_read_addr),
 .cache_read_valid(kernel_cache_read_valid),.cache_read_data(cache_read_data),.fault(reader_fault));
 npu_security_service_cdc_arbiter arbiter(.c_clk(clk),.s_clk(s_clk),.rst_n(rst_n),
 .c_clear(prepare_seed||recovery_clear),.c_cancel(seq_cancel),.c_phase(phase),
 .c_page_request({classifier_page_request,kernel_request}),.c_expected_page_index({classifier_expected_page_index,kernel_expected_page_index}),
 .c_page_request_ready(page_grant),.c_cache_read({classifier_cache_read,kernel_cache_read}),
 .c_cache_read_addr({classifier_cache_read_addr,kernel_cache_read_addr}),.c_cache_read_valid(read_grant),.c_cache_read_data(cache_read_data),
 .c_model_authorized(model_authorized),.c_session_epoch(session_epoch),.c_cache_valid(cache_valid),.c_cached_page_index(cached_page_index),
 .c_recovery_ready(recovery_ready),.c_busy(),.c_fault(cdc_fault),.s_model_authorized(service_authorized),.s_cache_valid(service_cache_valid),.s_fault(service_fault),.s_cancel(feeder_cancel),
 .s_session_epoch(service_epoch),.s_cached_page_index(service_cached_page_index),.s_service_cancel(service_cancel),
 .s_page_request(page_request),.s_expected_page_index(expected_page_index),.s_page_request_ready(page_request_ready),
 .s_page_done(service_page_done),.s_page_error(service_page_error),.s_cache_read(service_read),.s_cache_read_addr(service_read_addr),
 .s_cache_read_valid(service_read_valid),.s_cache_read_data(service_read_data));
 npu_model_security_service service(.clk(s_clk),.rst_n(rst_n),.cancel(service_cancel||feeder_cancel),
 .manifest_start(manifest_start),.manifest_ready(manifest_ready),.msg_valid(msg_valid),.msg_data(msg_data),.msg_last(msg_last),.msg_ready(msg_ready),
 .sig_valid(sig_valid),.sig_data(sig_data),.sig_last(sig_last),.sig_ready(sig_ready),
 .page_request(page_request),.page_request_ready(page_request_ready),.expected_page_index(expected_page_index),
 .page_valid(page_valid),.page_data(page_data),.page_ready(page_ready),.proof_valid(proof_valid),.proof_data(proof_data),.proof_ready(proof_ready),
 .cache_read(service_read),.cache_read_addr(service_read_addr),.cache_read_valid(service_read_valid),.cache_read_data(service_read_data),
 .model_authorized(service_authorized),.cache_valid(service_cache_valid),.busy(service_busy),.fault(service_fault),.manifest_done(manifest_done),.page_done(service_page_done),
 .session_epoch(service_epoch),.cached_page_index(service_cached_page_index),.signature_elapsed_cycles(),.signature_compute_cycles(),.page_elapsed_cycles(),
 .signature_error(signature_error),.policy_error(policy_error),.page_error(service_page_error),.debug_progress(),.debug_control());
npu_model_feed_axil feeder(
.clk(s_clk),
.rst_n(rst_n),
.trusted_cancel(service_cancel),
.trusted_page_accept(page_request&&page_request_ready),
.trusted_page_index(expected_page_index),
.svc_manifest_ready(manifest_ready),
.svc_manifest_done(manifest_done),
.svc_page_done(service_page_done),
.svc_busy(service_busy),
.svc_fault(service_fault),
.svc_model_authorized(service_authorized),
.svc_cache_valid(service_cache_valid),
.svc_epoch(service_epoch),
.svc_cached_page_index(service_cached_page_index),
.svc_signature_error(signature_error),
.svc_policy_error(policy_error),
.svc_page_error(service_page_error),
.svc_manifest_start(manifest_start),
.svc_cancel(feeder_cancel),
.feeder_error(feeder_error),
.s_awaddr(sec_awaddr),
.s_awvalid(sec_awvalid),
.s_awready(sec_awready),
.s_wdata(sec_wdata),
.s_wstrb(sec_wstrb),
.s_wvalid(sec_wvalid),
.s_wready(sec_wready),
.s_bresp(sec_bresp),
.s_bvalid(sec_bvalid),
.s_bready(sec_bready),
.s_araddr(sec_araddr),
.s_arvalid(sec_arvalid),
.s_arready(sec_arready),
.s_rdata(sec_rdata),
.s_rresp(sec_rresp),
.s_rvalid(sec_rvalid),
.s_rready(sec_rready),
.msg_valid(msg_valid),
.msg_data(msg_data),
.msg_last(msg_last),
.msg_ready(msg_ready),
.sig_valid(sig_valid),
.sig_data(sig_data),
.sig_last(sig_last),
.sig_ready(sig_ready),
.page_valid(page_valid),
.page_data(page_data),
.page_ready(page_ready),
.proof_valid(proof_valid),
.proof_data(proof_data),
.proof_ready(proof_ready)
);
endmodule
