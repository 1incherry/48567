`timescale 1ns/1ps
// Real whole-YOLO -> authenticated frontend -> original twelve-block ViT.
// No PS command/owner/config port. Single shared actual A/B lives in u_nn.u_vit.
module npu_full_vision_core(
input wire clk,security_reset_n,arith_reset_n,authorized,key_valid,cancel,
input wire [31:0] authorization_epoch,input wire [127:0] key_session_id,
input wire job_valid,output wire job_ready,input wire [31:0] job_camera_id,job_session,job_frame,job_epoch,
output wire active,quiescent,job_done,job_failed,fault,
output wire [63:0] frame_elapsed_cycles,
output wire record_visible,record_commit_pulse,
output wire [31:0] record_camera,record_session,record_frame,record_epoch,
output wire [127:0] record_key_session,output wire [2:0] record_count,
output wire [895:0] record_rois,output wire [51:0] record_indices,output wire [511:0] record_results,
input wire [2:0] service_committed_owner,output wire [2:0] service_owner,output wire [3:0] service_page_request,service_cache_read,
output wire [127:0] service_expected_pages,output wire [39:0] service_cache_addresses,
input wire [3:0] service_page_ready,service_cache_read_valid,
input wire service_page_done,service_busy,service_fault,service_quiescent,service_cache_valid,
input wire [31:0] service_cached_page,service_cache_read_data,
output wire [1:0] fetch_valid,input wire [1:0] fetch_ready,
output wire [63:0] fetch_page_index,fetch_page_address,fetch_proof_address,
output wire mac_request,output wire [127:0] mac_chain,output wire [255:0] mac_data,
input wire mac_ready,mac_response_valid,mac_response_error,input wire [127:0] mac_tag,input wire mac_quiescent,
output wire [1:0] ddr_committed_owner,pool_committed_stage,
output wire observation_pool_wait,output wire observation_yolo_start,observation_yolo_done,observation_frontend_start,observation_nn_start,observation_nn_done,observation_head_start,
output wire [31:0] observation_roi_index,observation_generation,
output wire [3:0] observation_block,output wire observation_norm3_valid,observation_norm3_done,
output wire [15:0] observation_norm3_address,observation_norm3_data,
output wire observation_logit_valid,output wire [7:0] observation_logit_class,output wire [63:0] observation_logit_data,
output wire observation_result_valid,output wire [7:0] observation_result_class,output wire [63:0] observation_result_logit,
output wire [31:0] observation_consumer_session,observation_consumer_frame,observation_consumer_epoch,
output wire [31:0] observation_context_camera,observation_context_session,observation_context_frame,observation_context_epoch,
output wire [31:0] M_AXI_ARADDR,
output wire [7:0] M_AXI_ARLEN,
output wire [2:0] M_AXI_ARSIZE,
output wire [1:0] M_AXI_ARBURST,
output wire M_AXI_ARVALID,
input wire M_AXI_ARREADY,
input wire [255:0] M_AXI_RDATA,
input wire [1:0] M_AXI_RRESP,
input wire M_AXI_RLAST,
input wire M_AXI_RVALID,
output wire M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,
output wire [7:0] M_AXI_AWLEN,
output wire [2:0] M_AXI_AWSIZE,
output wire [1:0] M_AXI_AWBURST,
output wire M_AXI_AWVALID,
input wire M_AXI_AWREADY,
output wire [255:0] M_AXI_WDATA,
output wire [31:0] M_AXI_WSTRB,
output wire M_AXI_WLAST,
output wire M_AXI_WVALID,
input wire M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,
input wire M_AXI_BVALID,
output wire M_AXI_BREADY
);
wire y_job_valid;
wire y_job_ready;
wire [31:0] y_job_session;
wire [31:0] y_job_frame;
wire [31:0] y_job_epoch;
wire [31:0] y_job_rgb_base;
wire y_authorized;
wire [31:0] y_authorization_epoch;
wire y_job_cancel;
wire y_job_quiescent;
wire y_active;
wire y_job_done;
wire y_job_failed;
wire [7:0] y_failure_code;
wire [31:0] y_result_session;
wire [31:0] y_result_frame;
wire [31:0] y_result_epoch;
wire [31:0] y_current_index;
wire [15:0] y_read_transactions;
wire [15:0] y_write_transactions;
wire y_clk;
wire y_rst_n;
wire y_a_write;
wire y_b_write;
wire [11:0] y_bank_write_address;
wire [255:0] y_bank_write_data;
wire y_a_read;
wire y_b_read;
wire [11:0] y_a_read_address;
wire [11:0] y_b_read_address;
wire [255:0] y_a_read_data;
wire [255:0] y_b_read_data;
wire [31:0] y_M_AXI_ARADDR;
wire [7:0] y_M_AXI_ARLEN;
wire [2:0] y_M_AXI_ARSIZE;
wire [1:0] y_M_AXI_ARBURST;
wire y_M_AXI_ARVALID;
wire y_M_AXI_ARREADY;
wire [255:0] y_M_AXI_RDATA;
wire [1:0] y_M_AXI_RRESP;
wire y_M_AXI_RLAST;
wire y_M_AXI_RVALID;
wire y_M_AXI_RREADY;
wire [31:0] y_M_AXI_AWADDR;
wire [7:0] y_M_AXI_AWLEN;
wire [2:0] y_M_AXI_AWSIZE;
wire [1:0] y_M_AXI_AWBURST;
wire y_M_AXI_AWVALID;
wire y_M_AXI_AWREADY;
wire [255:0] y_M_AXI_WDATA;
wire [31:0] y_M_AXI_WSTRB;
wire y_M_AXI_WLAST;
wire y_M_AXI_WVALID;
wire y_M_AXI_WREADY;
wire [1:0] y_M_AXI_BRESP;
wire y_M_AXI_BVALID;
wire y_M_AXI_BREADY;
wire y_exclusive_page_lock;
wire y_fetch_valid;
wire y_fetch_ready;
wire [31:0] y_fetch_page_index;
wire [31:0] y_fetch_page_address;
wire [31:0] y_fetch_proof_address;
wire y_service_page_request;
wire y_service_page_ready;
wire [31:0] y_service_expected_page;
wire y_service_page_done;
wire y_service_busy;
wire y_service_fault;
wire y_service_cache_valid;
wire [31:0] y_service_cached_page;
wire y_service_cache_read;
wire [9:0] y_service_cache_address;
wire y_service_cache_read_valid;
wire [31:0] y_service_cache_read_data;
wire y_key_valid;
wire y_mac_request;
wire y_mac_ready;
wire [127:0] y_mac_chain;
wire [255:0] y_mac_data;
wire y_mac_response_valid;
wire y_mac_response_error;
wire [127:0] y_mac_tag;
wire y_mac_quiescent;
wire [2:0] y_selected_count;
wire [895:0] y_selected_data;
wire [51:0] y_selected_indices;
wire [11:0] y_PS_AWADDR;
wire y_PS_AWVALID;
wire y_PS_AWREADY;
wire [31:0] y_PS_WDATA;
wire [3:0] y_PS_WSTRB;
wire y_PS_WVALID;
wire y_PS_WREADY;
wire [1:0] y_PS_BRESP;
wire y_PS_BVALID;
wire y_PS_BREADY;
wire [31:0] y_blocked_ps_writes;
wire f_clk;
wire f_rst_n;
wire f_authorized;
wire f_key_valid;
wire [31:0] f_authorization_epoch;
wire f_job_valid;
wire f_job_ready;
wire f_job_cancel;
wire [31:0] f_job_camera_id;
wire [31:0] f_job_session;
wire [31:0] f_job_frame;
wire [31:0] f_job_epoch;
wire [31:0] f_job_roi_index;
wire [15:0] f_job_x;
wire [15:0] f_job_y;
wire [15:0] f_job_width;
wire [15:0] f_job_height;
wire f_job_active;
wire f_job_quiescent;
wire f_memory_quiet;
wire f_seed_wait;
wire f_frontend_busy;
wire f_job_done;
wire f_job_failed;
wire [7:0] f_failure_code;
wire f_prepare_seed;
wire f_frontend_owner;
wire f_consumer_start;
wire f_consumer_cancel;
wire f_private_seed_ready;
wire f_private_seed_fault;
wire f_compute_quiescent;
wire f_consumer_ready;
wire f_consumer_active;
wire f_consumer_done;
wire f_consumer_fault;
wire f_consumer_quiescent;
wire f_consumer_result_valid;
wire [31:0] f_consumer_result_frame;
wire [31:0] f_consumer_result_epoch;
wire [7:0] f_consumer_result_class;
wire [63:0] f_consumer_result_logit;
wire [7:0] f_result_class;
wire [63:0] f_result_logit;
wire f_a_write;
wire f_b_write;
wire f_a_read;
wire f_b_read;
wire [11:0] f_write_address;
wire [11:0] f_a_address;
wire [11:0] f_b_address;
wire [255:0] f_write_data;
wire [255:0] f_a_data;
wire [255:0] f_b_data;
wire f_norm_clear;
wire f_norm_start;
wire f_norm_input_valid;
wire [15:0] f_norm_input_address;
wire [15:0] f_norm_input_data;
wire f_norm_scale_valid;
wire f_norm_bias_valid;
wire [7:0] f_norm_param_address;
wire [31:0] f_norm_param_data;
wire f_norm_ready;
wire f_norm_valid;
wire f_norm_done;
wire [31:0] f_perf_total;
wire [31:0] f_perf_param;
wire [31:0] f_perf_resize;
wire [31:0] f_perf_embed;
wire [31:0] f_perf_norm;
wire [31:0] f_perf_ar;
wire [31:0] f_perf_aw;
wire [15:0] f_norm_address;
wire [15:0] f_norm_data;
wire [31:0] f_M_AXI_ARADDR;
wire [7:0] f_M_AXI_ARLEN;
wire [2:0] f_M_AXI_ARSIZE;
wire [1:0] f_M_AXI_ARBURST;
wire f_M_AXI_ARVALID;
wire f_M_AXI_ARREADY;
wire [255:0] f_M_AXI_RDATA;
wire [1:0] f_M_AXI_RRESP;
wire f_M_AXI_RLAST;
wire f_M_AXI_RVALID;
wire f_M_AXI_RREADY;
wire [31:0] f_M_AXI_AWADDR;
wire [7:0] f_M_AXI_AWLEN;
wire [2:0] f_M_AXI_AWSIZE;
wire [1:0] f_M_AXI_AWBURST;
wire f_M_AXI_AWVALID;
wire f_M_AXI_AWREADY;
wire [255:0] f_M_AXI_WDATA;
wire [31:0] f_M_AXI_WSTRB;
wire f_M_AXI_WLAST;
wire f_M_AXI_WVALID;
wire f_M_AXI_WREADY;
wire [1:0] f_M_AXI_BRESP;
wire f_M_AXI_BVALID;
wire f_M_AXI_BREADY;
wire [31:0] f_context_generation;
wire f_generation_exhausted;
wire f_context_authorized;
wire [31:0] f_context_camera_id;
wire [31:0] f_context_session;
wire [31:0] f_context_frame;
wire [31:0] f_context_epoch;
wire [31:0] f_context_roi_index;
wire [15:0] f_context_roi_x;
wire [15:0] f_context_roi_y;
wire [15:0] f_context_roi_width;
wire [15:0] f_context_roi_height;
wire f_exclusive_page_lock;
wire f_fetch_valid;
wire f_fetch_ready;
wire [31:0] f_fetch_page_index;
wire [31:0] f_fetch_page_address;
wire [31:0] f_fetch_proof_address;
wire f_service_page_request;
wire f_service_page_ready;
wire [31:0] f_service_expected_page;
wire f_service_page_done;
wire f_service_busy;
wire f_service_fault;
wire f_service_cache_valid;
wire [31:0] f_service_cached_page;
wire f_service_cache_read;
wire [9:0] f_service_cache_address;
wire f_service_cache_read_valid;
wire [31:0] f_service_cache_read_data;
wire f_mac_request;
wire f_mac_ready;
wire [127:0] f_mac_chain;
wire [255:0] f_mac_data;
wire f_mac_response_valid;
wire f_mac_response_error;
wire [127:0] f_mac_tag;
wire f_mac_quiescent;
wire n_clk;
wire n_security_reset_n;
wire n_arith_reset_n;
wire n_authorized;
wire n_cancel;
wire [31:0] n_authorization_epoch;
wire n_prepare_seed;
wire n_frontend_owner;
wire n_consumer_start;
wire [31:0] n_camera_id;
wire [31:0] n_frame_id;
wire [31:0] n_roi_index;
wire [31:0] n_context_generation;
wire [31:0] n_network_session_id;
wire n_consumer_ready;
wire n_consumer_active;
wire n_consumer_done;
wire n_consumer_fault;
wire n_consumer_quiescent;
wire n_result_valid;
wire [31:0] n_result_frame;
wire [31:0] n_result_epoch;
wire [31:0] n_result_roi;
wire [31:0] n_result_generation;
wire [31:0] n_result_session;
wire [7:0] n_result_class;
wire signed [63:0] n_result_logit;
wire n_private_seed_ready;
wire n_private_seed_fault;
wire n_compute_quiescent;
wire n_f_clear;
wire n_f_start;
wire n_f_input_valid;
wire n_f_scale_valid;
wire n_f_bias_valid;
wire n_f_ready;
wire [15:0] n_f_input_address;
wire signed [15:0] n_f_input_data;
wire [7:0] n_f_param_address;
wire signed [31:0] n_f_param_data;
wire n_f_norm_valid;
wire n_f_norm_done;
wire [15:0] n_f_norm_address;
wire signed [15:0] n_f_norm_data;
wire [1:0] n_pool_desired_stage;
wire n_pool_all_quiescent;
wire n_pool_access_live;
wire [1:0] n_pool_committed_stage;
wire n_pool_owner_ready;
wire n_pool_fault;
wire n_pool_quiescent;
wire n_shared_a_write;
wire n_shared_b_write;
wire n_shared_a_read;
wire n_shared_b_read;
wire [11:0] n_shared_write_address;
wire [11:0] n_shared_a_address;
wire [11:0] n_shared_b_address;
wire [255:0] n_shared_write_data;
wire [255:0] n_shared_a_data;
wire [255:0] n_shared_b_data;
wire [1:0] n_service_phase;
wire [1:0] n_page_requests;
wire [1:0] n_cache_reads;
wire [63:0] n_expected_pages;
wire [19:0] n_cache_addresses;
wire [1:0] n_page_grants;
wire [1:0] n_read_grants;
wire n_cache_valid;
wire [31:0] n_cached_page_index;
wire [31:0] n_cache_read_data;
wire [31:0] n_stat0;
wire [31:0] n_stat1;
wire [31:0] n_stat2;
wire [31:0] n_stat3;
wire [3:0] n_observation_block;
wire n_observation_norm3_valid;
wire n_observation_norm3_done;
wire [15:0] n_observation_norm3_address;
wire [15:0] n_observation_norm3_data;
wire n_observation_logit_valid;
wire [7:0] n_observation_logit_class;
wire [63:0] n_observation_logit_data;
wire n_observation_head_start;
wire [31:0] n_M_AXI_ARADDR;
wire [7:0] n_M_AXI_ARLEN;
wire [2:0] n_M_AXI_ARSIZE;
wire [1:0] n_M_AXI_ARBURST;
wire n_M_AXI_ARVALID;
wire n_M_AXI_ARREADY;
wire [255:0] n_M_AXI_RDATA;
wire [1:0] n_M_AXI_RRESP;
wire n_M_AXI_RLAST;
wire n_M_AXI_RVALID;
wire n_M_AXI_RREADY;
wire [31:0] n_M_AXI_AWADDR;
wire [7:0] n_M_AXI_AWLEN;
wire [2:0] n_M_AXI_AWSIZE;
wire [1:0] n_M_AXI_AWBURST;
wire n_M_AXI_AWVALID;
wire n_M_AXI_AWREADY;
wire [255:0] n_M_AXI_WDATA;
wire [31:0] n_M_AXI_WSTRB;
wire n_M_AXI_WLAST;
wire n_M_AXI_WVALID;
wire n_M_AXI_WREADY;
wire [1:0] n_M_AXI_BRESP;
wire n_M_AXI_BVALID;
wire n_M_AXI_BREADY;
wire c_clk;
wire c_rst_n;
wire c_authorized;
wire c_key_valid;
wire c_job_cancel;
wire [31:0] c_authorization_epoch;
wire c_job_valid;
wire c_job_ready;
wire [31:0] c_job_camera_id;
wire [31:0] c_job_session;
wire [31:0] c_job_frame;
wire [31:0] c_job_epoch;
wire c_active;
wire c_quiescent;
wire [63:0] c_frame_elapsed_cycles;
wire c_job_done;
wire c_job_failed;
wire [7:0] c_failure_code;
wire [31:0] c_bound_camera;
wire [31:0] c_bound_session;
wire [31:0] c_bound_frame;
wire [31:0] c_bound_epoch;
wire c_resources_quiescent;
wire c_yolo_valid;
wire c_yolo_ready;
wire c_yolo_cancel;
wire c_yolo_active;
wire c_yolo_done;
wire c_yolo_failed;
wire c_yolo_quiescent;
wire [31:0] c_yolo_result_session;
wire [31:0] c_yolo_result_frame;
wire [31:0] c_yolo_result_epoch;
wire [2:0] c_yolo_selected_count;
wire [895:0] c_yolo_selected_data;
wire [51:0] c_yolo_selected_indices;
wire c_frontend_valid;
wire c_frontend_ready;
wire c_frontend_cancel;
wire c_frontend_active;
wire c_frontend_done;
wire c_frontend_failed;
wire c_frontend_quiescent;
wire [31:0] c_frontend_roi_index;
wire [15:0] c_frontend_x;
wire [15:0] c_frontend_y;
wire [15:0] c_frontend_width;
wire [15:0] c_frontend_height;
wire [31:0] c_frontend_camera;
wire [31:0] c_frontend_session;
wire [31:0] c_frontend_frame;
wire [31:0] c_frontend_epoch;
wire [31:0] c_frontend_result_roi;
wire [31:0] c_frontend_generation;
wire [15:0] c_frontend_result_x;
wire [15:0] c_frontend_result_y;
wire [15:0] c_frontend_result_width;
wire [15:0] c_frontend_result_height;
wire [7:0] c_frontend_class;
wire [63:0] c_frontend_logit;
wire c_record_valid;
wire c_record_ready;
wire [2:0] c_record_count;
wire [895:0] c_record_rois;
wire [51:0] c_record_indices;
wire [511:0] c_record_results;
wire r_clk;
wire r_security_reset_n;
wire r_authorized;
wire r_key_valid;
wire r_cancel;
wire r_trusted_clear_fault;
wire [31:0] r_authorization_epoch;
wire [127:0] r_key_session_id;
wire r_commit_valid;
wire r_commit_ready;
wire r_commit_pulse;
wire r_fault;
wire [31:0] r_commit_camera;
wire [31:0] r_commit_session;
wire [31:0] r_commit_frame;
wire [31:0] r_commit_epoch;
wire [2:0] r_commit_count;
wire [895:0] r_commit_rois;
wire [51:0] r_commit_indices;
wire [511:0] r_commit_results;
wire r_visible;
wire [31:0] r_camera_id;
wire [31:0] r_session_id;
wire [31:0] r_frame_id;
wire [31:0] r_epoch;
wire [127:0] r_result_key_session;
wire [2:0] r_count;
wire [895:0] r_rois;
wire [51:0] r_indices;
wire [511:0] r_results;

wire ddr_quiet,ddr_fault,ddr_owner_match;
wire [1:0] desired_ddr,desired_pool;
wire resources_quiet,bank_switch_quiet,local_fault;
wire raw_service_violation,raw_mac_violation;
reg nn_phase,bank_fault_latched,service_fault_latched;
wire y_bank_request=y_a_write||y_b_write||y_a_read||y_b_read;
wire f_bank_request=f_a_write||f_b_write||f_a_read||f_b_read;
wire inactive_bank_request=(y_bank_request&&pool_committed_stage!=2)||(f_bank_request&&pool_committed_stage!=3);
wire external_a_write=y_a_write||f_a_write;
wire external_b_write=y_b_write||f_b_write;
wire external_a_read=y_a_read||f_a_read;
wire external_b_read=y_b_read||f_b_read;
wire [11:0] external_write_address=pool_committed_stage==2?y_bank_write_address:f_write_address;
wire [255:0] external_write_data=pool_committed_stage==2?y_bank_write_data:f_write_data;
wire [11:0] external_a_address=pool_committed_stage==2?y_a_read_address:f_a_address;
wire [11:0] external_b_address=pool_committed_stage==2?y_b_read_address:f_b_address;
assign pool_committed_stage=n_pool_committed_stage;
always @(posedge clk)begin
 if(!security_reset_n)begin nn_phase<=0;bank_fault_latched<=0;service_fault_latched<=0;end
 else begin
  if(!f_job_active)nn_phase<=0;
  if(f_seed_wait&&f_memory_quiet&&n_private_seed_ready&&!f_prepare_seed)nn_phase<=1;
  if(inactive_bank_request)bank_fault_latched<=1;
  if(raw_service_violation||raw_mac_violation)service_fault_latched<=1;
 end
end
assign desired_ddr=(c_yolo_valid||y_active)?2'd1:
 (c_frontend_valid||f_job_active)?(nn_phase?2'd3:2'd2):2'd0;
assign desired_pool=desired_ddr==1?2'd2:desired_ddr==2?2'd3:desired_ddr==3?2'd1:2'd0;
assign bank_switch_quiet=n_compute_quiescent&&f_memory_quiet&&ddr_quiet&&mac_quiescent&&service_quiescent;
wire yolo_owner_ready=ddr_committed_owner==1&&pool_committed_stage==2&&service_committed_owner==1&&!local_fault;
wire frontend_owner_ready=ddr_committed_owner==2&&pool_committed_stage==3&&service_committed_owner==2&&!local_fault;
assign observation_pool_wait=desired_pool!=pool_committed_stage;
assign resources_quiet=ddr_quiet&&n_pool_quiescent&&n_consumer_quiescent&&service_quiescent&&mac_quiescent;
assign local_fault=ddr_fault||n_pool_fault||bank_fault_latched||service_fault_latched||service_fault||r_fault;
assign fault=local_fault||c_job_failed;
assign active=c_active;
assign quiescent=c_quiescent&&resources_quiet;
assign job_ready=c_job_ready&&!local_fault;
assign job_done=c_job_done;
assign job_failed=c_job_failed;
assign frame_elapsed_cycles=c_frame_elapsed_cycles;
assign service_owner=ddr_committed_owner==1?3'd1:ddr_committed_owner==2?3'd2:
 ddr_committed_owner==3?(n_service_phase==2?3'd4:3'd3):3'd0;
wire [3:0] service_mask=service_committed_owner>=1&&service_committed_owner<=4?(4'b0001<<(service_committed_owner-1'b1)):4'd0;
wire [3:0] desired_service_mask=service_owner>=1&&service_owner<=4?(4'b0001<<(service_owner-1'b1)):4'd0;
wire [3:0] raw_pages={n_page_requests,f_service_page_request,y_service_page_request};
wire [3:0] raw_reads={n_cache_reads,f_service_cache_read,y_service_cache_read};
wire [1:0] raw_fetches={f_fetch_valid,y_fetch_valid};
assign raw_service_violation=(|(raw_reads&~service_mask))||(|(raw_pages&~(service_mask|desired_service_mask)))||(|(raw_fetches&~(service_mask[1:0]|desired_service_mask[1:0])));
assign service_page_request=raw_pages&service_mask&{4{!raw_service_violation}};
assign service_expected_pages={n_expected_pages,f_service_expected_page,y_service_expected_page};
assign service_cache_read=raw_reads&service_mask&{4{!raw_service_violation}};
assign service_cache_addresses={n_cache_addresses,f_service_cache_address,y_service_cache_address};
assign fetch_valid=raw_fetches&service_mask[1:0]&{2{!raw_service_violation}};
assign fetch_page_index={f_fetch_page_index,y_fetch_page_index};
assign fetch_page_address={f_fetch_page_address,y_fetch_page_address};
assign fetch_proof_address={f_fetch_proof_address,y_fetch_proof_address};
wire [1:0] mac_owner=ddr_committed_owner==1?2'd1:
 (ddr_committed_owner==2||ddr_committed_owner==3)?2'd2:2'd0;
assign raw_mac_violation=(y_mac_request&&mac_owner!=1)||(f_mac_request&&mac_owner!=2);
assign mac_request=mac_owner==1?y_mac_request:mac_owner==2?f_mac_request:1'b0;
assign mac_chain=mac_owner==1?y_mac_chain:mac_owner==2?f_mac_chain:128'd0;
assign mac_data=mac_owner==1?y_mac_data:mac_owner==2?f_mac_data:256'd0;
assign record_visible=r_visible;assign record_commit_pulse=r_commit_pulse;
assign record_camera=r_camera_id;assign record_session=r_session_id;assign record_frame=r_frame_id;assign record_epoch=r_epoch;
assign record_key_session=r_result_key_session;assign record_count=r_count;
assign record_rois=r_rois;assign record_indices=r_indices;assign record_results=r_results;
assign observation_yolo_start=y_job_valid&&y_job_ready;
assign observation_yolo_done=y_job_done;
assign observation_frontend_start=f_job_valid&&f_job_ready;
assign observation_nn_start=f_consumer_start&&n_consumer_ready;
assign observation_nn_done=n_consumer_done;
assign observation_head_start=n_observation_head_start;
assign observation_roi_index=observation_frontend_start?c_frontend_roi_index:f_context_roi_index;
assign observation_generation=f_context_generation;
assign observation_context_camera=f_context_camera_id;assign observation_context_session=f_context_session;
assign observation_context_frame=f_context_frame;assign observation_context_epoch=f_context_epoch;
assign observation_result_valid=n_result_valid;assign observation_result_class=n_result_class;assign observation_result_logit=n_result_logit;
assign observation_consumer_session=n_result_session;
assign observation_consumer_frame=n_result_frame;assign observation_consumer_epoch=n_result_epoch;

assign observation_block=n_observation_block;
assign observation_norm3_valid=n_observation_norm3_valid;
assign observation_norm3_done=n_observation_norm3_done;
assign observation_norm3_address=n_observation_norm3_address;
assign observation_norm3_data=n_observation_norm3_data;
assign observation_logit_valid=n_observation_logit_valid;
assign observation_logit_class=n_observation_logit_class;
assign observation_logit_data=n_observation_logit_data;
wire [95:0] bus_ARADDR={n_M_AXI_ARADDR,f_M_AXI_ARADDR,y_M_AXI_ARADDR};
wire [23:0] bus_ARLEN={n_M_AXI_ARLEN,f_M_AXI_ARLEN,y_M_AXI_ARLEN};
wire [8:0] bus_ARSIZE={n_M_AXI_ARSIZE,f_M_AXI_ARSIZE,y_M_AXI_ARSIZE};
wire [5:0] bus_ARBURST={n_M_AXI_ARBURST,f_M_AXI_ARBURST,y_M_AXI_ARBURST};
wire [2:0] bus_ARVALID={n_M_AXI_ARVALID,f_M_AXI_ARVALID,y_M_AXI_ARVALID};
wire [2:0] bus_ARREADY;
wire [767:0] bus_RDATA;
wire [5:0] bus_RRESP;
wire [2:0] bus_RLAST;
wire [2:0] bus_RVALID;
wire [2:0] bus_RREADY={n_M_AXI_RREADY,f_M_AXI_RREADY,y_M_AXI_RREADY};
wire [95:0] bus_AWADDR={n_M_AXI_AWADDR,f_M_AXI_AWADDR,y_M_AXI_AWADDR};
wire [23:0] bus_AWLEN={n_M_AXI_AWLEN,f_M_AXI_AWLEN,y_M_AXI_AWLEN};
wire [8:0] bus_AWSIZE={n_M_AXI_AWSIZE,f_M_AXI_AWSIZE,y_M_AXI_AWSIZE};
wire [5:0] bus_AWBURST={n_M_AXI_AWBURST,f_M_AXI_AWBURST,y_M_AXI_AWBURST};
wire [2:0] bus_AWVALID={n_M_AXI_AWVALID,f_M_AXI_AWVALID,y_M_AXI_AWVALID};
wire [2:0] bus_AWREADY;
wire [767:0] bus_WDATA={n_M_AXI_WDATA,f_M_AXI_WDATA,y_M_AXI_WDATA};
wire [95:0] bus_WSTRB={n_M_AXI_WSTRB,f_M_AXI_WSTRB,y_M_AXI_WSTRB};
wire [2:0] bus_WLAST={n_M_AXI_WLAST,f_M_AXI_WLAST,y_M_AXI_WLAST};
wire [2:0] bus_WVALID={n_M_AXI_WVALID,f_M_AXI_WVALID,y_M_AXI_WVALID};
wire [2:0] bus_WREADY;
wire [5:0] bus_BRESP;
wire [2:0] bus_BVALID;
wire [2:0] bus_BREADY={n_M_AXI_BREADY,f_M_AXI_BREADY,y_M_AXI_BREADY};
trusted_stage_axi_mux #(.PORTS(3)) u_ddr(.clk(clk),.security_reset_n(security_reset_n),.desired_owner(desired_ddr),.client_quiescent({n_consumer_quiescent,f_memory_quiet,y_job_quiescent}),.committed_owner(ddr_committed_owner),.owner_committed(ddr_owner_match),.quiescent(ddr_quiet),.fault(ddr_fault),
.S_ARADDR(bus_ARADDR),.M_ARADDR(M_AXI_ARADDR),
.S_ARLEN(bus_ARLEN),.M_ARLEN(M_AXI_ARLEN),
.S_ARSIZE(bus_ARSIZE),.M_ARSIZE(M_AXI_ARSIZE),
.S_ARBURST(bus_ARBURST),.M_ARBURST(M_AXI_ARBURST),
.S_ARVALID(bus_ARVALID),.M_ARVALID(M_AXI_ARVALID),
.S_ARREADY(bus_ARREADY),.M_ARREADY(M_AXI_ARREADY),
.S_RDATA(bus_RDATA),.M_RDATA(M_AXI_RDATA),
.S_RRESP(bus_RRESP),.M_RRESP(M_AXI_RRESP),
.S_RLAST(bus_RLAST),.M_RLAST(M_AXI_RLAST),
.S_RVALID(bus_RVALID),.M_RVALID(M_AXI_RVALID),
.S_RREADY(bus_RREADY),.M_RREADY(M_AXI_RREADY),
.S_AWADDR(bus_AWADDR),.M_AWADDR(M_AXI_AWADDR),
.S_AWLEN(bus_AWLEN),.M_AWLEN(M_AXI_AWLEN),
.S_AWSIZE(bus_AWSIZE),.M_AWSIZE(M_AXI_AWSIZE),
.S_AWBURST(bus_AWBURST),.M_AWBURST(M_AXI_AWBURST),
.S_AWVALID(bus_AWVALID),.M_AWVALID(M_AXI_AWVALID),
.S_AWREADY(bus_AWREADY),.M_AWREADY(M_AXI_AWREADY),
.S_WDATA(bus_WDATA),.M_WDATA(M_AXI_WDATA),
.S_WSTRB(bus_WSTRB),.M_WSTRB(M_AXI_WSTRB),
.S_WLAST(bus_WLAST),.M_WLAST(M_AXI_WLAST),
.S_WVALID(bus_WVALID),.M_WVALID(M_AXI_WVALID),
.S_WREADY(bus_WREADY),.M_WREADY(M_AXI_WREADY),
.S_BRESP(bus_BRESP),.M_BRESP(M_AXI_BRESP),
.S_BVALID(bus_BVALID),.M_BVALID(M_AXI_BVALID),
.S_BREADY(bus_BREADY),.M_BREADY(M_AXI_BREADY));
assign y_job_valid=c_yolo_valid&&yolo_owner_ready;
assign y_job_session=c_bound_session;
assign y_job_frame=c_bound_frame;
assign y_job_epoch=c_bound_epoch;
assign y_job_rgb_base=32'h22000000;
assign y_authorized=authorized;
assign y_authorization_epoch=authorization_epoch;
assign y_job_cancel=cancel||c_yolo_cancel||local_fault;
assign y_clk=clk;
assign y_rst_n=security_reset_n;
assign y_a_read_data=n_shared_a_data;
assign y_b_read_data=n_shared_b_data;
assign y_M_AXI_ARREADY=bus_ARREADY[0+:1];
assign y_M_AXI_RDATA=bus_RDATA[0+:256];
assign y_M_AXI_RRESP=bus_RRESP[0+:2];
assign y_M_AXI_RLAST=bus_RLAST[0+:1];
assign y_M_AXI_RVALID=bus_RVALID[0+:1];
assign y_M_AXI_AWREADY=bus_AWREADY[0+:1];
assign y_M_AXI_WREADY=bus_WREADY[0+:1];
assign y_M_AXI_BRESP=bus_BRESP[0+:2];
assign y_M_AXI_BVALID=bus_BVALID[0+:1];
assign y_fetch_ready=fetch_ready[0];
assign y_service_page_ready=service_page_ready[0];
assign y_service_page_done=service_page_done;
assign y_service_busy=service_busy;
assign y_service_fault=service_fault;
assign y_service_cache_valid=service_cache_valid&&service_committed_owner==1;
assign y_service_cached_page=service_cached_page;
assign y_service_cache_read_valid=service_cache_read_valid[0];
assign y_service_cache_read_data=service_cache_read_data;
assign y_key_valid=key_valid;
assign y_mac_ready=mac_ready&&mac_owner==1;
assign y_mac_response_valid=mac_response_valid&&mac_owner==1;
assign y_mac_response_error=mac_response_error;
assign y_mac_tag=mac_tag;
assign y_mac_quiescent=mac_quiescent;
assign y_PS_AWADDR=12'd0;
assign y_PS_AWVALID=1'b0;
assign y_PS_WDATA=32'd0;
assign y_PS_WSTRB=4'd0;
assign y_PS_WVALID=1'b0;
assign y_PS_BREADY=1'b1;
trusted_yolo_pipeline_attested_poolcache u_yolo(
.job_valid(y_job_valid),
.job_ready(y_job_ready),
.job_session(y_job_session),
.job_frame(y_job_frame),
.job_epoch(y_job_epoch),
.job_rgb_base(y_job_rgb_base),
.authorized(y_authorized),
.authorization_epoch(y_authorization_epoch),
.job_cancel(y_job_cancel),
.job_quiescent(y_job_quiescent),
.active(y_active),
.job_done(y_job_done),
.job_failed(y_job_failed),
.failure_code(y_failure_code),
.result_session(y_result_session),
.result_frame(y_result_frame),
.result_epoch(y_result_epoch),
.current_index(y_current_index),
.read_transactions(y_read_transactions),
.write_transactions(y_write_transactions),
.clk(y_clk),
.rst_n(y_rst_n),
.a_write(y_a_write),
.b_write(y_b_write),
.bank_write_address(y_bank_write_address),
.bank_write_data(y_bank_write_data),
.a_read(y_a_read),
.b_read(y_b_read),
.a_read_address(y_a_read_address),
.b_read_address(y_b_read_address),
.a_read_data(y_a_read_data),
.b_read_data(y_b_read_data),
.M_AXI_ARADDR(y_M_AXI_ARADDR),
.M_AXI_ARLEN(y_M_AXI_ARLEN),
.M_AXI_ARSIZE(y_M_AXI_ARSIZE),
.M_AXI_ARBURST(y_M_AXI_ARBURST),
.M_AXI_ARVALID(y_M_AXI_ARVALID),
.M_AXI_ARREADY(y_M_AXI_ARREADY),
.M_AXI_RDATA(y_M_AXI_RDATA),
.M_AXI_RRESP(y_M_AXI_RRESP),
.M_AXI_RLAST(y_M_AXI_RLAST),
.M_AXI_RVALID(y_M_AXI_RVALID),
.M_AXI_RREADY(y_M_AXI_RREADY),
.M_AXI_AWADDR(y_M_AXI_AWADDR),
.M_AXI_AWLEN(y_M_AXI_AWLEN),
.M_AXI_AWSIZE(y_M_AXI_AWSIZE),
.M_AXI_AWBURST(y_M_AXI_AWBURST),
.M_AXI_AWVALID(y_M_AXI_AWVALID),
.M_AXI_AWREADY(y_M_AXI_AWREADY),
.M_AXI_WDATA(y_M_AXI_WDATA),
.M_AXI_WSTRB(y_M_AXI_WSTRB),
.M_AXI_WLAST(y_M_AXI_WLAST),
.M_AXI_WVALID(y_M_AXI_WVALID),
.M_AXI_WREADY(y_M_AXI_WREADY),
.M_AXI_BRESP(y_M_AXI_BRESP),
.M_AXI_BVALID(y_M_AXI_BVALID),
.M_AXI_BREADY(y_M_AXI_BREADY),
.exclusive_page_lock(y_exclusive_page_lock),
.fetch_valid(y_fetch_valid),
.fetch_ready(y_fetch_ready),
.fetch_page_index(y_fetch_page_index),
.fetch_page_address(y_fetch_page_address),
.fetch_proof_address(y_fetch_proof_address),
.service_page_request(y_service_page_request),
.service_page_ready(y_service_page_ready),
.service_expected_page(y_service_expected_page),
.service_page_done(y_service_page_done),
.service_busy(y_service_busy),
.service_fault(y_service_fault),
.service_cache_valid(y_service_cache_valid),
.service_cached_page(y_service_cached_page),
.service_cache_read(y_service_cache_read),
.service_cache_address(y_service_cache_address),
.service_cache_read_valid(y_service_cache_read_valid),
.service_cache_read_data(y_service_cache_read_data),
.key_valid(y_key_valid),
.mac_request(y_mac_request),
.mac_ready(y_mac_ready),
.mac_chain(y_mac_chain),
.mac_data(y_mac_data),
.mac_response_valid(y_mac_response_valid),
.mac_response_error(y_mac_response_error),
.mac_tag(y_mac_tag),
.mac_quiescent(y_mac_quiescent),
.selected_count(y_selected_count),
.selected_data(y_selected_data),
.selected_indices(y_selected_indices),
.PS_AWADDR(y_PS_AWADDR),
.PS_AWVALID(y_PS_AWVALID),
.PS_AWREADY(y_PS_AWREADY),
.PS_WDATA(y_PS_WDATA),
.PS_WSTRB(y_PS_WSTRB),
.PS_WVALID(y_PS_WVALID),
.PS_WREADY(y_PS_WREADY),
.PS_BRESP(y_PS_BRESP),
.PS_BVALID(y_PS_BVALID),
.PS_BREADY(y_PS_BREADY),
.blocked_ps_writes(y_blocked_ps_writes));
assign f_clk=clk;
assign f_rst_n=security_reset_n;
assign f_authorized=authorized;
assign f_key_valid=key_valid;
assign f_authorization_epoch=authorization_epoch;
assign f_job_valid=c_frontend_valid&&frontend_owner_ready;
assign f_job_cancel=cancel||c_frontend_cancel||local_fault;
assign f_job_camera_id=c_bound_camera;
assign f_job_session=c_bound_session;
assign f_job_frame=c_bound_frame;
assign f_job_epoch=c_bound_epoch;
assign f_job_roi_index=c_frontend_roi_index;
assign f_job_x=c_frontend_x;
assign f_job_y=c_frontend_y;
assign f_job_width=c_frontend_width;
assign f_job_height=c_frontend_height;
assign f_private_seed_ready=n_private_seed_ready;
assign f_private_seed_fault=n_private_seed_fault;
assign f_compute_quiescent=n_compute_quiescent;
assign f_consumer_ready=n_consumer_ready&&ddr_committed_owner==3&&service_committed_owner==3&&service_quiescent;
assign f_consumer_active=n_consumer_active;
assign f_consumer_done=n_consumer_done;
assign f_consumer_fault=n_consumer_fault;
assign f_consumer_quiescent=n_consumer_quiescent&&ddr_quiet;
assign f_consumer_result_valid=n_result_valid;
assign f_consumer_result_frame=n_result_frame;
assign f_consumer_result_epoch=n_result_epoch;
assign f_consumer_result_class=n_result_class;
assign f_consumer_result_logit=n_result_logit;
assign f_a_data=n_shared_a_data;
assign f_b_data=n_shared_b_data;
assign f_norm_valid=n_f_norm_valid;
assign f_norm_done=n_f_norm_done;
assign f_norm_address=n_f_norm_address;
assign f_norm_data=n_f_norm_data;
assign f_M_AXI_ARREADY=bus_ARREADY[1+:1];
assign f_M_AXI_RDATA=bus_RDATA[256+:256];
assign f_M_AXI_RRESP=bus_RRESP[2+:2];
assign f_M_AXI_RLAST=bus_RLAST[1+:1];
assign f_M_AXI_RVALID=bus_RVALID[1+:1];
assign f_M_AXI_AWREADY=bus_AWREADY[1+:1];
assign f_M_AXI_WREADY=bus_WREADY[1+:1];
assign f_M_AXI_BRESP=bus_BRESP[2+:2];
assign f_M_AXI_BVALID=bus_BVALID[1+:1];
assign f_fetch_ready=fetch_ready[1];
assign f_service_page_ready=service_page_ready[1];
assign f_service_page_done=service_page_done;
assign f_service_busy=service_busy;
assign f_service_fault=service_fault;
assign f_service_cache_valid=service_cache_valid&&service_committed_owner==2;
assign f_service_cached_page=service_cached_page;
assign f_service_cache_read_valid=service_cache_read_valid[1];
assign f_service_cache_read_data=service_cache_read_data;
assign f_mac_ready=mac_ready&&mac_owner==2;
assign f_mac_response_valid=mac_response_valid&&mac_owner==2;
assign f_mac_response_error=mac_response_error;
assign f_mac_tag=mac_tag;
assign f_mac_quiescent=mac_quiescent;
trusted_frontend_job_path_shared u_frontend(
.clk(f_clk),
.rst_n(f_rst_n),
.authorized(f_authorized),
.key_valid(f_key_valid),
.authorization_epoch(f_authorization_epoch),
.job_valid(f_job_valid),
.job_ready(f_job_ready),
.job_cancel(f_job_cancel),
.job_camera_id(f_job_camera_id),
.job_session(f_job_session),
.job_frame(f_job_frame),
.job_epoch(f_job_epoch),
.job_roi_index(f_job_roi_index),
.job_x(f_job_x),
.job_y(f_job_y),
.job_width(f_job_width),
.job_height(f_job_height),
.job_active(f_job_active),
.job_quiescent(f_job_quiescent),
.memory_quiet(f_memory_quiet),
.seed_wait(f_seed_wait),
.frontend_busy(f_frontend_busy),
.job_done(f_job_done),
.job_failed(f_job_failed),
.failure_code(f_failure_code),
.prepare_seed(f_prepare_seed),
.frontend_owner(f_frontend_owner),
.consumer_start(f_consumer_start),
.consumer_cancel(f_consumer_cancel),
.private_seed_ready(f_private_seed_ready),
.private_seed_fault(f_private_seed_fault),
.compute_quiescent(f_compute_quiescent),
.consumer_ready(f_consumer_ready),
.consumer_active(f_consumer_active),
.consumer_done(f_consumer_done),
.consumer_fault(f_consumer_fault),
.consumer_quiescent(f_consumer_quiescent),
.consumer_result_valid(f_consumer_result_valid),
.consumer_result_frame(f_consumer_result_frame),
.consumer_result_epoch(f_consumer_result_epoch),
.consumer_result_class(f_consumer_result_class),
.consumer_result_logit(f_consumer_result_logit),
.result_class(f_result_class),
.result_logit(f_result_logit),
.a_write(f_a_write),
.b_write(f_b_write),
.a_read(f_a_read),
.b_read(f_b_read),
.write_address(f_write_address),
.a_address(f_a_address),
.b_address(f_b_address),
.write_data(f_write_data),
.a_data(f_a_data),
.b_data(f_b_data),
.norm_clear(f_norm_clear),
.norm_start(f_norm_start),
.norm_input_valid(f_norm_input_valid),
.norm_input_address(f_norm_input_address),
.norm_input_data(f_norm_input_data),
.norm_scale_valid(f_norm_scale_valid),
.norm_bias_valid(f_norm_bias_valid),
.norm_param_address(f_norm_param_address),
.norm_param_data(f_norm_param_data),
.norm_ready(f_norm_ready),
.norm_valid(f_norm_valid),
.norm_done(f_norm_done),
.perf_total(f_perf_total),
.perf_param(f_perf_param),
.perf_resize(f_perf_resize),
.perf_embed(f_perf_embed),
.perf_norm(f_perf_norm),
.perf_ar(f_perf_ar),
.perf_aw(f_perf_aw),
.norm_address(f_norm_address),
.norm_data(f_norm_data),
.M_AXI_ARADDR(f_M_AXI_ARADDR),
.M_AXI_ARLEN(f_M_AXI_ARLEN),
.M_AXI_ARSIZE(f_M_AXI_ARSIZE),
.M_AXI_ARBURST(f_M_AXI_ARBURST),
.M_AXI_ARVALID(f_M_AXI_ARVALID),
.M_AXI_ARREADY(f_M_AXI_ARREADY),
.M_AXI_RDATA(f_M_AXI_RDATA),
.M_AXI_RRESP(f_M_AXI_RRESP),
.M_AXI_RLAST(f_M_AXI_RLAST),
.M_AXI_RVALID(f_M_AXI_RVALID),
.M_AXI_RREADY(f_M_AXI_RREADY),
.M_AXI_AWADDR(f_M_AXI_AWADDR),
.M_AXI_AWLEN(f_M_AXI_AWLEN),
.M_AXI_AWSIZE(f_M_AXI_AWSIZE),
.M_AXI_AWBURST(f_M_AXI_AWBURST),
.M_AXI_AWVALID(f_M_AXI_AWVALID),
.M_AXI_AWREADY(f_M_AXI_AWREADY),
.M_AXI_WDATA(f_M_AXI_WDATA),
.M_AXI_WSTRB(f_M_AXI_WSTRB),
.M_AXI_WLAST(f_M_AXI_WLAST),
.M_AXI_WVALID(f_M_AXI_WVALID),
.M_AXI_WREADY(f_M_AXI_WREADY),
.M_AXI_BRESP(f_M_AXI_BRESP),
.M_AXI_BVALID(f_M_AXI_BVALID),
.M_AXI_BREADY(f_M_AXI_BREADY),
.context_generation(f_context_generation),
.generation_exhausted(f_generation_exhausted),
.context_authorized(f_context_authorized),
.context_camera_id(f_context_camera_id),
.context_session(f_context_session),
.context_frame(f_context_frame),
.context_epoch(f_context_epoch),
.context_roi_index(f_context_roi_index),
.context_roi_x(f_context_roi_x),
.context_roi_y(f_context_roi_y),
.context_roi_width(f_context_roi_width),
.context_roi_height(f_context_roi_height),
.exclusive_page_lock(f_exclusive_page_lock),
.fetch_valid(f_fetch_valid),
.fetch_ready(f_fetch_ready),
.fetch_page_index(f_fetch_page_index),
.fetch_page_address(f_fetch_page_address),
.fetch_proof_address(f_fetch_proof_address),
.service_page_request(f_service_page_request),
.service_page_ready(f_service_page_ready),
.service_expected_page(f_service_expected_page),
.service_page_done(f_service_page_done),
.service_busy(f_service_busy),
.service_fault(f_service_fault),
.service_cache_valid(f_service_cache_valid),
.service_cached_page(f_service_cached_page),
.service_cache_read(f_service_cache_read),
.service_cache_address(f_service_cache_address),
.service_cache_read_valid(f_service_cache_read_valid),
.service_cache_read_data(f_service_cache_read_data),
.mac_request(f_mac_request),
.mac_ready(f_mac_ready),
.mac_chain(f_mac_chain),
.mac_data(f_mac_data),
.mac_response_valid(f_mac_response_valid),
.mac_response_error(f_mac_response_error),
.mac_tag(f_mac_tag),
.mac_quiescent(f_mac_quiescent));
assign n_clk=clk;
assign n_security_reset_n=security_reset_n;
assign n_arith_reset_n=arith_reset_n;
assign n_authorized=authorized;
assign n_cancel=cancel||c_frontend_cancel||local_fault;
assign n_authorization_epoch=authorization_epoch;
assign n_prepare_seed=f_prepare_seed;
assign n_frontend_owner=f_frontend_owner;
assign n_consumer_start=f_consumer_start;
assign n_camera_id=f_context_camera_id;
assign n_frame_id=f_context_frame;
assign n_roi_index=f_context_roi_index;
assign n_context_generation=f_context_generation;
assign n_network_session_id=f_context_session;
assign n_f_clear=f_norm_clear;
assign n_f_start=f_norm_start;
assign n_f_input_valid=f_norm_input_valid;
assign n_f_scale_valid=f_norm_scale_valid;
assign n_f_bias_valid=f_norm_bias_valid;
assign n_f_ready=f_norm_ready;
assign n_f_input_address=f_norm_input_address;
assign n_f_input_data=f_norm_input_data;
assign n_f_param_address=f_norm_param_address;
assign n_f_param_data=f_norm_param_data;
assign n_pool_desired_stage=desired_pool;
assign n_pool_all_quiescent=bank_switch_quiet;
assign n_pool_access_live=authorized&&key_valid&&!cancel&&!local_fault&&!inactive_bank_request;
assign n_shared_a_write=external_a_write;
assign n_shared_b_write=external_b_write;
assign n_shared_a_read=external_a_read;
assign n_shared_b_read=external_b_read;
assign n_shared_write_address=external_write_address;
assign n_shared_a_address=external_a_address;
assign n_shared_b_address=external_b_address;
assign n_shared_write_data=external_write_data;
assign n_page_grants=service_page_ready[3:2];
assign n_read_grants=service_cache_read_valid[3:2];
assign n_cache_valid=service_cache_valid&&((n_service_phase==2&&service_committed_owner==4)||(n_service_phase!=2&&service_committed_owner==3));
assign n_cached_page_index=service_cached_page;
assign n_cache_read_data=service_cache_read_data;
assign n_M_AXI_ARREADY=bus_ARREADY[2+:1];
assign n_M_AXI_RDATA=bus_RDATA[512+:256];
assign n_M_AXI_RRESP=bus_RRESP[4+:2];
assign n_M_AXI_RLAST=bus_RLAST[2+:1];
assign n_M_AXI_RVALID=bus_RVALID[2+:1];
assign n_M_AXI_AWREADY=bus_AWREADY[2+:1];
assign n_M_AXI_WREADY=bus_WREADY[2+:1];
assign n_M_AXI_BRESP=bus_BRESP[4+:2];
assign n_M_AXI_BVALID=bus_BVALID[2+:1];
npu_trusted_vit_consumer u_nn(
.clk(n_clk),
.security_reset_n(n_security_reset_n),
.arith_reset_n(n_arith_reset_n),
.authorized(n_authorized),
.cancel(n_cancel),
.authorization_epoch(n_authorization_epoch),
.prepare_seed(n_prepare_seed),
.frontend_owner(n_frontend_owner),
.consumer_start(n_consumer_start),
.camera_id(n_camera_id),
.frame_id(n_frame_id),
.roi_index(n_roi_index),
.context_generation(n_context_generation),
.network_session_id(n_network_session_id),
.consumer_ready(n_consumer_ready),
.consumer_active(n_consumer_active),
.consumer_done(n_consumer_done),
.consumer_fault(n_consumer_fault),
.consumer_quiescent(n_consumer_quiescent),
.result_valid(n_result_valid),
.result_frame(n_result_frame),
.result_epoch(n_result_epoch),
.result_roi(n_result_roi),
.result_generation(n_result_generation),
.result_session(n_result_session),
.result_class(n_result_class),
.result_logit(n_result_logit),
.private_seed_ready(n_private_seed_ready),
.private_seed_fault(n_private_seed_fault),
.compute_quiescent(n_compute_quiescent),
.f_clear(n_f_clear),
.f_start(n_f_start),
.f_input_valid(n_f_input_valid),
.f_scale_valid(n_f_scale_valid),
.f_bias_valid(n_f_bias_valid),
.f_ready(n_f_ready),
.f_input_address(n_f_input_address),
.f_input_data(n_f_input_data),
.f_param_address(n_f_param_address),
.f_param_data(n_f_param_data),
.f_norm_valid(n_f_norm_valid),
.f_norm_done(n_f_norm_done),
.f_norm_address(n_f_norm_address),
.f_norm_data(n_f_norm_data),
.pool_desired_stage(n_pool_desired_stage),
.pool_all_quiescent(n_pool_all_quiescent),
.pool_access_live(n_pool_access_live),
.pool_committed_stage(n_pool_committed_stage),
.pool_owner_ready(n_pool_owner_ready),
.pool_fault(n_pool_fault),
.pool_quiescent(n_pool_quiescent),
.shared_a_write(n_shared_a_write),
.shared_b_write(n_shared_b_write),
.shared_a_read(n_shared_a_read),
.shared_b_read(n_shared_b_read),
.shared_write_address(n_shared_write_address),
.shared_a_address(n_shared_a_address),
.shared_b_address(n_shared_b_address),
.shared_write_data(n_shared_write_data),
.shared_a_data(n_shared_a_data),
.shared_b_data(n_shared_b_data),
.service_phase(n_service_phase),
.page_requests(n_page_requests),
.cache_reads(n_cache_reads),
.expected_pages(n_expected_pages),
.cache_addresses(n_cache_addresses),
.page_grants(n_page_grants),
.read_grants(n_read_grants),
.cache_valid(n_cache_valid),
.cached_page_index(n_cached_page_index),
.cache_read_data(n_cache_read_data),
.stat0(n_stat0),
.stat1(n_stat1),
.stat2(n_stat2),
.stat3(n_stat3),
.observation_block(n_observation_block),
.observation_norm3_valid(n_observation_norm3_valid),
.observation_norm3_done(n_observation_norm3_done),
.observation_norm3_address(n_observation_norm3_address),
.observation_norm3_data(n_observation_norm3_data),
.observation_logit_valid(n_observation_logit_valid),
.observation_logit_class(n_observation_logit_class),
.observation_logit_data(n_observation_logit_data),
.observation_head_start(n_observation_head_start),
.M_AXI_ARADDR(n_M_AXI_ARADDR),
.M_AXI_ARLEN(n_M_AXI_ARLEN),
.M_AXI_ARSIZE(n_M_AXI_ARSIZE),
.M_AXI_ARBURST(n_M_AXI_ARBURST),
.M_AXI_ARVALID(n_M_AXI_ARVALID),
.M_AXI_ARREADY(n_M_AXI_ARREADY),
.M_AXI_RDATA(n_M_AXI_RDATA),
.M_AXI_RRESP(n_M_AXI_RRESP),
.M_AXI_RLAST(n_M_AXI_RLAST),
.M_AXI_RVALID(n_M_AXI_RVALID),
.M_AXI_RREADY(n_M_AXI_RREADY),
.M_AXI_AWADDR(n_M_AXI_AWADDR),
.M_AXI_AWLEN(n_M_AXI_AWLEN),
.M_AXI_AWSIZE(n_M_AXI_AWSIZE),
.M_AXI_AWBURST(n_M_AXI_AWBURST),
.M_AXI_AWVALID(n_M_AXI_AWVALID),
.M_AXI_AWREADY(n_M_AXI_AWREADY),
.M_AXI_WDATA(n_M_AXI_WDATA),
.M_AXI_WSTRB(n_M_AXI_WSTRB),
.M_AXI_WLAST(n_M_AXI_WLAST),
.M_AXI_WVALID(n_M_AXI_WVALID),
.M_AXI_WREADY(n_M_AXI_WREADY),
.M_AXI_BRESP(n_M_AXI_BRESP),
.M_AXI_BVALID(n_M_AXI_BVALID),
.M_AXI_BREADY(n_M_AXI_BREADY));
assign c_clk=clk;
assign c_rst_n=security_reset_n;
assign c_authorized=authorized;
assign c_key_valid=key_valid;
assign c_job_cancel=cancel||local_fault;
assign c_authorization_epoch=authorization_epoch;
assign c_job_valid=job_valid&&!local_fault;
assign c_job_camera_id=job_camera_id;
assign c_job_session=job_session;
assign c_job_frame=job_frame;
assign c_job_epoch=job_epoch;
assign c_resources_quiescent=resources_quiet;
assign c_yolo_ready=y_job_ready&&yolo_owner_ready;
assign c_yolo_active=y_active;
assign c_yolo_done=y_job_done;
assign c_yolo_failed=y_job_failed;
assign c_yolo_quiescent=y_job_quiescent;
assign c_yolo_result_session=y_result_session;
assign c_yolo_result_frame=y_result_frame;
assign c_yolo_result_epoch=y_result_epoch;
assign c_yolo_selected_count=y_selected_count;
assign c_yolo_selected_data=y_selected_data;
assign c_yolo_selected_indices=y_selected_indices;
assign c_frontend_ready=f_job_ready&&frontend_owner_ready;
assign c_frontend_active=f_job_active;
assign c_frontend_done=f_job_done;
assign c_frontend_failed=f_job_failed;
assign c_frontend_quiescent=f_job_quiescent;
assign c_frontend_camera=f_context_camera_id;
assign c_frontend_session=f_context_session;
assign c_frontend_frame=f_context_frame;
assign c_frontend_epoch=f_context_epoch;
assign c_frontend_result_roi=f_context_roi_index;
assign c_frontend_generation=f_context_generation;
assign c_frontend_result_x=f_context_roi_x;
assign c_frontend_result_y=f_context_roi_y;
assign c_frontend_result_width=f_context_roi_width;
assign c_frontend_result_height=f_context_roi_height;
assign c_frontend_class=f_result_class;
assign c_frontend_logit=f_result_logit;
assign c_record_ready=r_commit_ready;
trusted_vision_parent_controller u_lifecycle(
.clk(c_clk),
.rst_n(c_rst_n),
.authorized(c_authorized),
.key_valid(c_key_valid),
.job_cancel(c_job_cancel),
.authorization_epoch(c_authorization_epoch),
.job_valid(c_job_valid),
.job_ready(c_job_ready),
.job_camera_id(c_job_camera_id),
.job_session(c_job_session),
.job_frame(c_job_frame),
.job_epoch(c_job_epoch),
.active(c_active),
.quiescent(c_quiescent),
.frame_elapsed_cycles(c_frame_elapsed_cycles),
.job_done(c_job_done),
.job_failed(c_job_failed),
.failure_code(c_failure_code),
.bound_camera(c_bound_camera),
.bound_session(c_bound_session),
.bound_frame(c_bound_frame),
.bound_epoch(c_bound_epoch),
.resources_quiescent(c_resources_quiescent),
.yolo_valid(c_yolo_valid),
.yolo_ready(c_yolo_ready),
.yolo_cancel(c_yolo_cancel),
.yolo_active(c_yolo_active),
.yolo_done(c_yolo_done),
.yolo_failed(c_yolo_failed),
.yolo_quiescent(c_yolo_quiescent),
.yolo_result_session(c_yolo_result_session),
.yolo_result_frame(c_yolo_result_frame),
.yolo_result_epoch(c_yolo_result_epoch),
.yolo_selected_count(c_yolo_selected_count),
.yolo_selected_data(c_yolo_selected_data),
.yolo_selected_indices(c_yolo_selected_indices),
.frontend_valid(c_frontend_valid),
.frontend_ready(c_frontend_ready),
.frontend_cancel(c_frontend_cancel),
.frontend_active(c_frontend_active),
.frontend_done(c_frontend_done),
.frontend_failed(c_frontend_failed),
.frontend_quiescent(c_frontend_quiescent),
.frontend_roi_index(c_frontend_roi_index),
.frontend_x(c_frontend_x),
.frontend_y(c_frontend_y),
.frontend_width(c_frontend_width),
.frontend_height(c_frontend_height),
.frontend_camera(c_frontend_camera),
.frontend_session(c_frontend_session),
.frontend_frame(c_frontend_frame),
.frontend_epoch(c_frontend_epoch),
.frontend_result_roi(c_frontend_result_roi),
.frontend_generation(c_frontend_generation),
.frontend_result_x(c_frontend_result_x),
.frontend_result_y(c_frontend_result_y),
.frontend_result_width(c_frontend_result_width),
.frontend_result_height(c_frontend_result_height),
.frontend_class(c_frontend_class),
.frontend_logit(c_frontend_logit),
.record_valid(c_record_valid),
.record_ready(c_record_ready),
.record_count(c_record_count),
.record_rois(c_record_rois),
.record_indices(c_record_indices),
.record_results(c_record_results));
assign r_clk=clk;
assign r_security_reset_n=security_reset_n;
assign r_authorized=authorized;
assign r_key_valid=key_valid;
assign r_cancel=cancel||local_fault||c_job_failed;
assign r_trusted_clear_fault=job_valid&&job_ready;
assign r_authorization_epoch=authorization_epoch;
assign r_key_session_id=key_session_id;
assign r_commit_valid=c_record_valid;
assign r_commit_camera=c_bound_camera;
assign r_commit_session=c_bound_session;
assign r_commit_frame=c_bound_frame;
assign r_commit_epoch=c_bound_epoch;
assign r_commit_count=c_record_count;
assign r_commit_rois=c_record_rois;
assign r_commit_indices=c_record_indices;
assign r_commit_results=c_record_results;
trusted_vision_result_bank u_result(
.clk(r_clk),
.security_reset_n(r_security_reset_n),
.authorized(r_authorized),
.key_valid(r_key_valid),
.cancel(r_cancel),
.trusted_clear_fault(r_trusted_clear_fault),
.authorization_epoch(r_authorization_epoch),
.key_session_id(r_key_session_id),
.commit_valid(r_commit_valid),
.commit_ready(r_commit_ready),
.commit_pulse(r_commit_pulse),
.fault(r_fault),
.commit_camera(r_commit_camera),
.commit_session(r_commit_session),
.commit_frame(r_commit_frame),
.commit_epoch(r_commit_epoch),
.commit_count(r_commit_count),
.commit_rois(r_commit_rois),
.commit_indices(r_commit_indices),
.commit_results(r_commit_results),
.visible(r_visible),
.camera_id(r_camera_id),
.session_id(r_session_id),
.frame_id(r_frame_id),
.epoch(r_epoch),
.result_key_session(r_result_key_session),
.count(r_count),
.rois(r_rois),
.indices(r_indices),
.results(r_results));
endmodule
