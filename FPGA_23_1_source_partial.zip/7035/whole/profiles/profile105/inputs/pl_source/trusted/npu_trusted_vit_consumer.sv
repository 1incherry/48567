`timescale 1ns/1ps
// Actual R12 numerical engine/private banks/classifier. No PS command ports.
// Parent supplies real frontend generation and singleton V2 service grants.
module npu_trusted_vit_consumer #(parameter [31:0] OUT_BASE_ADDR=32'h1c000000)(
input wire clk,security_reset_n,arith_reset_n,authorized,cancel,
input wire [31:0] authorization_epoch,
input wire prepare_seed,frontend_owner,consumer_start,
input wire [31:0] camera_id,frame_id,roi_index,context_generation,network_session_id,
output wire consumer_ready,consumer_active,consumer_done,consumer_fault,consumer_quiescent,
output wire result_valid,output wire [31:0] result_frame,result_epoch,result_roi,result_generation,result_session,
output wire [7:0] result_class,output wire signed [63:0] result_logit,
output wire private_seed_ready,private_seed_fault,compute_quiescent,
input wire f_clear,f_start,f_input_valid,f_scale_valid,f_bias_valid,f_ready,
input wire [15:0] f_input_address,input wire signed [15:0] f_input_data,
input wire [7:0] f_param_address,input wire signed [31:0] f_param_data,
output wire f_norm_valid,f_norm_done,output wire [15:0] f_norm_address,
output wire signed [15:0] f_norm_data,
input wire [1:0] pool_desired_stage,input wire pool_all_quiescent,pool_access_live,
output wire [1:0] pool_committed_stage,
output wire pool_owner_ready,pool_fault,pool_quiescent,
input wire shared_a_write,shared_b_write,shared_a_read,shared_b_read,
input wire [11:0] shared_write_address,shared_a_address,shared_b_address,
input wire [255:0] shared_write_data,output wire [255:0] shared_a_data,shared_b_data,
output wire [1:0] service_phase,page_requests,cache_reads,
output wire [63:0] expected_pages,output wire [19:0] cache_addresses,
input wire [1:0] page_grants,read_grants,
input wire cache_valid,input wire [31:0] cached_page_index,cache_read_data,
output wire [31:0] stat0,stat1,stat2,stat3,
output wire [3:0] observation_block,output wire observation_norm3_valid,observation_norm3_done,
output wire [15:0] observation_norm3_address,observation_norm3_data,
output wire observation_logit_valid,output wire [7:0] observation_logit_class,
output wire [63:0] observation_logit_data,output wire observation_head_start,
output wire [31:0] M_AXI_ARADDR,
output wire [7:0] M_AXI_ARLEN,
output wire [2:0] M_AXI_ARSIZE,
output wire [1:0] M_AXI_ARBURST,
output wire M_AXI_ARVALID,
input wire M_AXI_ARREADY,
input wire [255:0] M_AXI_RDATA,
input wire [1:0] M_AXI_RRESP,
input wire M_AXI_RLAST,
input wire M_AXI_RVALID,
output wire M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,
output wire [7:0] M_AXI_AWLEN,
output wire [2:0] M_AXI_AWSIZE,
output wire [1:0] M_AXI_AWBURST,
output wire M_AXI_AWVALID,
input wire M_AXI_AWREADY,
output wire [255:0] M_AXI_WDATA,
output wire [31:0] M_AXI_WSTRB,
output wire M_AXI_WLAST,
output wire M_AXI_WVALID,
input wire M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,
input wire M_AXI_BVALID,
output wire M_AXI_BREADY
);
wire trusted_sequence_busy;
wire  trusted_authorized;
wire  trusted_cancel;
wire [31:0] trusted_epoch;
wire  handoff_start;
wire  handoff_seed;
wire signed [31:0] handoff_pose_coefficient;
wire  capture_pose;
wire  capture_norm;
wire  private_reads_phase;
wire  handoff_ready;
wire  handoff_fault;
wire  private_read_fault;
wire  trusted_fc2_valid;
wire  trusted_fc2_done;
wire [15:0] trusted_fc2_address;
wire signed [15:0] trusted_fc2_data;
wire  trusted_norm_valid;
wire  trusted_norm_done;
wire [15:0] trusted_norm_address;
wire signed [15:0] trusted_norm_data;
wire  classification_start;
wire  classification_capture;
wire  classifier_page_request;
wire  classifier_page_request_ready;
wire [31:0] classifier_expected_page_index;
wire  classifier_cache_valid;
wire [31:0] classifier_cached_page_index;
wire  classifier_cache_read;
wire [9:0] classifier_cache_read_addr;
wire  classifier_cache_read_valid;
wire [31:0] classifier_cache_read_data;
wire  classifier_norm_ready;
wire  classifier_busy;
wire  classifier_fault;
wire  trusted_result_valid;
wire [7:0] trusted_class_index;
wire signed [63:0] trusted_best_logit;
wire [31:0] trusted_result_epoch;
wire [7:0] trusted_axil_AWADDR;
wire [7:0] core_axil_AWADDR;
wire  trusted_axil_AWVALID;
wire  core_axil_AWVALID;
wire  trusted_axil_AWREADY;
wire  core_axil_AWREADY;
wire [31:0] trusted_axil_WDATA;
wire [31:0] core_axil_WDATA;
wire [3:0] trusted_axil_WSTRB;
wire [3:0] core_axil_WSTRB;
wire  trusted_axil_WVALID;
wire  core_axil_WVALID;
wire  trusted_axil_WREADY;
wire  core_axil_WREADY;
wire [1:0] trusted_axil_BRESP;
wire [1:0] core_axil_BRESP;
wire  trusted_axil_BVALID;
wire  core_axil_BVALID;
wire  trusted_axil_BREADY;
wire  core_axil_BREADY;
wire [7:0] trusted_axil_ARADDR;
wire [7:0] core_axil_ARADDR;
wire  trusted_axil_ARVALID;
wire  core_axil_ARVALID;
wire  trusted_axil_ARREADY;
wire  core_axil_ARREADY;
wire [31:0] trusted_axil_RDATA;
wire [31:0] core_axil_RDATA;
wire [1:0] trusted_axil_RRESP;
wire [1:0] core_axil_RRESP;
wire  trusted_axil_RVALID;
wire  core_axil_RVALID;
wire  trusted_axil_RREADY;
wire  core_axil_RREADY;
wire [31:0] auth_axi_ARADDR;
wire [7:0] auth_axi_ARLEN;
wire [2:0] auth_axi_ARSIZE;
wire [1:0] auth_axi_ARBURST;
wire  auth_axi_ARVALID;
wire  auth_axi_ARREADY;
wire [255:0] auth_axi_RDATA;
wire [1:0] auth_axi_RRESP;
wire  auth_axi_RLAST;
wire  auth_axi_RVALID;
wire  auth_axi_RREADY;
wire vit_busy,reader_quiescent;
wire tr_ready,tr_done,tr_fault,tr_result_valid;
wire [7:0] tr_result_class,tr_result_camera;
wire signed [63:0] tr_result_best_logit;
wire [31:0] tr_result_frame,tr_result_epoch,tr_result_sequence,tr_result_roi,tr_result_generation,tr_result_session;
wire [63:0] tr_result_cycle;
wire [3:0] tr_current_block;wire [15:0] tr_debug_pc;
reg launch_valid;
reg [15:0] writes_outstanding;
always @(posedge clk)begin
 if(!security_reset_n)begin launch_valid<=0;writes_outstanding<=0;end
 else begin
  if(prepare_seed)launch_valid<=0;
  else if(consumer_start&&consumer_ready)launch_valid<=1;
  case({M_AXI_AWVALID&&M_AXI_AWREADY,M_AXI_BVALID&&M_AXI_BREADY})
   2'b10:writes_outstanding<=writes_outstanding+1'b1;
   2'b01:writes_outstanding<=writes_outstanding-1'b1;
  endcase
 end
end
wire result_binding=tr_result_frame==frame_id&&tr_result_epoch==authorization_epoch&&
 tr_result_roi==roi_index&&tr_result_generation==context_generation&&tr_result_session==network_session_id;
assign consumer_ready=tr_ready&&camera_id<2&&pool_committed_stage==1&&!pool_fault;
assign consumer_active=trusted_sequence_busy;
assign consumer_done=launch_valid&&tr_done&&result_binding;
assign result_valid=launch_valid&&tr_result_valid&&result_binding&&!cancel&&authorized;
assign consumer_fault=pool_fault||(launch_valid&&tr_fault)||(launch_valid&&tr_result_valid&&!result_binding);
assign consumer_quiescent=!trusted_sequence_busy&&!vit_busy&&!classifier_busy&&reader_quiescent&&writes_outstanding==0&&!M_AXI_AWVALID&&!M_AXI_WVALID;
assign observation_head_start=classification_start;
assign compute_quiescent=!vit_busy&&!classifier_busy;
assign result_frame=tr_result_frame;assign result_epoch=tr_result_epoch;
assign result_roi=tr_result_roi;assign result_generation=tr_result_generation;assign result_session=tr_result_session;
assign result_class=tr_result_class;assign result_logit=tr_result_best_logit;
assign private_seed_ready=handoff_ready;
assign private_seed_fault=handoff_fault||private_read_fault;
assign observation_block=tr_current_block;
// The same Norm kernel also produces inter-block Norm1; its private capture
// flag excludes those values, matching the established full R12 observer.
assign observation_norm3_valid=trusted_sequence_busy&&trusted_norm_valid&&!capture_norm;
assign observation_norm3_done=trusted_sequence_busy&&trusted_norm_done&&!capture_norm;
assign observation_norm3_address=trusted_norm_address;
assign observation_norm3_data=trusted_norm_data;
wire [31:0] v_M_AXI_ARADDR;
wire [7:0] v_M_AXI_ARLEN;
wire [2:0] v_M_AXI_ARSIZE;
wire [1:0] v_M_AXI_ARBURST;
wire v_M_AXI_ARVALID;
wire v_M_AXI_ARREADY;
wire [255:0] v_M_AXI_RDATA;
wire [1:0] v_M_AXI_RRESP;
wire v_M_AXI_RLAST;
wire v_M_AXI_RVALID;
wire v_M_AXI_RREADY;
wire [31:0] v_M_AXI_AWADDR;
wire [7:0] v_M_AXI_AWLEN;
wire [2:0] v_M_AXI_AWSIZE;
wire [1:0] v_M_AXI_AWBURST;
wire v_M_AXI_AWVALID;
wire v_M_AXI_AWREADY;
wire [255:0] v_M_AXI_WDATA;
wire [31:0] v_M_AXI_WSTRB;
wire v_M_AXI_WLAST;
wire v_M_AXI_WVALID;
wire v_M_AXI_WREADY;
wire [1:0] v_M_AXI_BRESP;
wire v_M_AXI_BVALID;
wire v_M_AXI_BREADY;
assign core_axil_AWADDR=trusted_axil_AWADDR;
assign core_axil_AWVALID=trusted_axil_AWVALID;
assign core_axil_WDATA=trusted_axil_WDATA;
assign core_axil_WSTRB=trusted_axil_WSTRB;
assign core_axil_WVALID=trusted_axil_WVALID;
assign core_axil_BREADY=trusted_axil_BREADY;
assign core_axil_ARADDR=trusted_axil_ARADDR;
assign core_axil_ARVALID=trusted_axil_ARVALID;
assign core_axil_RREADY=trusted_axil_RREADY;
assign trusted_axil_AWREADY=core_axil_AWREADY;
assign trusted_axil_WREADY=core_axil_WREADY;
assign trusted_axil_BRESP=core_axil_BRESP;
assign trusted_axil_BVALID=core_axil_BVALID;
assign trusted_axil_ARREADY=core_axil_ARREADY;
assign trusted_axil_RDATA=core_axil_RDATA;
assign trusted_axil_RRESP=core_axil_RRESP;
assign trusted_axil_RVALID=core_axil_RVALID;
assign M_AXI_ARADDR='0;
assign M_AXI_ARLEN='0;
assign M_AXI_ARSIZE='0;
assign M_AXI_ARBURST='0;
assign M_AXI_ARVALID='0;
assign M_AXI_RREADY=1'b0;
assign M_AXI_AWADDR=v_M_AXI_AWADDR;
assign M_AXI_AWLEN=v_M_AXI_AWLEN;
assign M_AXI_AWSIZE=v_M_AXI_AWSIZE;
assign M_AXI_AWBURST=v_M_AXI_AWBURST;
assign M_AXI_AWVALID=v_M_AXI_AWVALID;
assign M_AXI_WDATA=v_M_AXI_WDATA;
assign M_AXI_WSTRB=v_M_AXI_WSTRB;
assign M_AXI_WLAST=v_M_AXI_WLAST;
assign M_AXI_WVALID=v_M_AXI_WVALID;
assign M_AXI_BREADY=v_M_AXI_BREADY;
assign v_M_AXI_AWREADY=M_AXI_AWREADY;
assign v_M_AXI_WREADY=M_AXI_WREADY;
assign v_M_AXI_BRESP=M_AXI_BRESP;
assign v_M_AXI_BVALID=M_AXI_BVALID;
assign v_M_AXI_ARREADY=auth_axi_ARREADY;
assign v_M_AXI_RDATA=auth_axi_RDATA;
assign v_M_AXI_RRESP=auth_axi_RRESP;
assign v_M_AXI_RLAST=auth_axi_RLAST;
assign v_M_AXI_RVALID=auth_axi_RVALID;
wire data_auth_enable=1'b0,data_auth_expected_valid=1'b0,data_auth_common_enable=1'b0,data_auth_secure_clear=1'b0;
wire [127:0] data_auth_expected_tag=0,data_auth_mac_key=0,data_auth_common_object_context=0;
wire [111:0] data_auth_context=0;
wire [7:0] data_auth_common_dtype=0,data_auth_common_role=0,data_auth_common_key_id=0;
wire data_auth_done,data_auth_ok,data_auth_fail;
v736_fullblock_nomemh_axi_lite_full_top #(.ENABLE_LIVE_CHAIN(1),.OUT_BASE_ADDR(OUT_BASE_ADDR)) u_vit(
.security_reset_n(security_reset_n),.pool_desired_stage(pool_desired_stage),
.pool_all_quiescent(pool_all_quiescent),.pool_access_live(pool_access_live),
.pool_committed_stage(pool_committed_stage),.pool_owner_ready(pool_owner_ready),
.pool_fault(pool_fault),.pool_quiescent(pool_quiescent),
.observation_logit_valid(observation_logit_valid),.observation_logit_class(observation_logit_class),.observation_logit_data(observation_logit_data),
.trusted_authorized(trusted_authorized),
.trusted_cancel(trusted_cancel),
.trusted_epoch(trusted_epoch),
.handoff_start(handoff_start),
.handoff_seed(handoff_seed),
.handoff_pose_coefficient(handoff_pose_coefficient),
.capture_pose(capture_pose),
.capture_norm(capture_norm),
.private_reads_phase(private_reads_phase),
.handoff_ready(handoff_ready),
.handoff_fault(handoff_fault),
.private_read_fault(private_read_fault),
.trusted_fc2_valid(trusted_fc2_valid),
.trusted_fc2_done(trusted_fc2_done),
.trusted_fc2_address(trusted_fc2_address),
.trusted_fc2_data(trusted_fc2_data),
.trusted_norm_valid(trusted_norm_valid),
.trusted_norm_done(trusted_norm_done),
.trusted_norm_address(trusted_norm_address),
.trusted_norm_data(trusted_norm_data),
.classification_start(classification_start),
.classification_capture(classification_capture),
.classifier_page_request(classifier_page_request),
.classifier_page_request_ready(classifier_page_request_ready),
.classifier_expected_page_index(classifier_expected_page_index),
.classifier_cache_valid(classifier_cache_valid),
.classifier_cached_page_index(classifier_cached_page_index),
.classifier_cache_read(classifier_cache_read),
.classifier_cache_read_addr(classifier_cache_read_addr),
.classifier_cache_read_valid(classifier_cache_read_valid),
.classifier_cache_read_data(classifier_cache_read_data),
.classifier_norm_ready(classifier_norm_ready),
.classifier_busy(classifier_busy),
.classifier_fault(classifier_fault),
.trusted_result_valid(trusted_result_valid),
.trusted_class_index(trusted_class_index),
.trusted_best_logit(trusted_best_logit),
.trusted_result_epoch(trusted_result_epoch),
.S_AXIL_AWADDR(core_axil_AWADDR),
.S_AXIL_AWVALID(core_axil_AWVALID),
.S_AXIL_AWREADY(core_axil_AWREADY),
.S_AXIL_WDATA(core_axil_WDATA),
.S_AXIL_WSTRB(core_axil_WSTRB),
.S_AXIL_WVALID(core_axil_WVALID),
.S_AXIL_WREADY(core_axil_WREADY),
.S_AXIL_BRESP(core_axil_BRESP),
.S_AXIL_BVALID(core_axil_BVALID),
.S_AXIL_BREADY(core_axil_BREADY),
.S_AXIL_ARADDR(core_axil_ARADDR),
.S_AXIL_ARVALID(core_axil_ARVALID),
.S_AXIL_ARREADY(core_axil_ARREADY),
.S_AXIL_RDATA(core_axil_RDATA),
.S_AXIL_RRESP(core_axil_RRESP),
.S_AXIL_RVALID(core_axil_RVALID),
.S_AXIL_RREADY(core_axil_RREADY),
.M_AXI_ARADDR(v_M_AXI_ARADDR),
.M_AXI_ARLEN(v_M_AXI_ARLEN),
.M_AXI_ARSIZE(v_M_AXI_ARSIZE),
.M_AXI_ARBURST(v_M_AXI_ARBURST),
.M_AXI_ARVALID(v_M_AXI_ARVALID),
.M_AXI_ARREADY(v_M_AXI_ARREADY),
.M_AXI_RDATA(v_M_AXI_RDATA),
.M_AXI_RRESP(v_M_AXI_RRESP),
.M_AXI_RLAST(v_M_AXI_RLAST),
.M_AXI_RVALID(v_M_AXI_RVALID),
.M_AXI_RREADY(v_M_AXI_RREADY),
.M_AXI_AWADDR(v_M_AXI_AWADDR),
.M_AXI_AWLEN(v_M_AXI_AWLEN),
.M_AXI_AWSIZE(v_M_AXI_AWSIZE),
.M_AXI_AWBURST(v_M_AXI_AWBURST),
.M_AXI_AWVALID(v_M_AXI_AWVALID),
.M_AXI_AWREADY(v_M_AXI_AWREADY),
.M_AXI_WDATA(v_M_AXI_WDATA),
.M_AXI_WSTRB(v_M_AXI_WSTRB),
.M_AXI_WLAST(v_M_AXI_WLAST),
.M_AXI_WVALID(v_M_AXI_WVALID),
.M_AXI_WREADY(v_M_AXI_WREADY),
.M_AXI_BRESP(v_M_AXI_BRESP),
.M_AXI_BVALID(v_M_AXI_BVALID),
.M_AXI_BREADY(v_M_AXI_BREADY),
.clk(clk),
.rst_n(arith_reset_n),
.data_auth_enable(data_auth_enable),
.data_auth_expected_valid(data_auth_expected_valid),
.data_auth_expected_tag(data_auth_expected_tag),
.data_auth_mac_key(data_auth_mac_key),
.data_auth_context(data_auth_context),
.data_auth_common_enable(data_auth_common_enable),
.data_auth_common_object_context(data_auth_common_object_context),
.data_auth_common_dtype(data_auth_common_dtype),
.data_auth_common_role(data_auth_common_role),
.data_auth_common_key_id(data_auth_common_key_id),
.data_auth_secure_clear(data_auth_secure_clear),
.data_auth_done(data_auth_done),
.data_auth_ok(data_auth_ok),
.data_auth_fail(data_auth_fail),
.stat0(stat0),
.stat1(stat1),
.stat2(stat2),
.stat3(stat3),
 .shared_owner(pool_committed_stage==2||pool_committed_stage==3),.shared_a_write(shared_a_write),.shared_b_write(shared_b_write),
 .shared_write_address(shared_write_address),.shared_write_data(shared_write_data),
 .shared_a_read(shared_a_read),.shared_b_read(shared_b_read),
 .shared_a_address(shared_a_address),.shared_b_address(shared_b_address),
 .shared_a_data(shared_a_data),.shared_b_data(shared_b_data),.integration_busy(vit_busy),
 .frontend_owner(frontend_owner),.frontend_clear(f_clear),.frontend_start(f_start),
 .frontend_input_valid(f_input_valid),.frontend_input_address(f_input_address),.frontend_input_data(f_input_data),
 .frontend_scale_valid(f_scale_valid),.frontend_bias_valid(f_bias_valid),
 .frontend_param_address(f_param_address),.frontend_param_data(f_param_data),
 .frontend_ready(f_ready),.frontend_valid(f_norm_valid),.frontend_done(f_norm_done),
 .frontend_address(f_norm_address),.frontend_data(f_norm_data));
npu_trusted_vit_control u_control(
 .clk(clk),.rst_n(security_reset_n),.prepare_seed(prepare_seed),.frontend_owner(frontend_owner),
 .request_valid(consumer_start&&consumer_ready),.request_ready(tr_ready),
 .model_authorized(authorized),.external_cancel(cancel),.pool_fault(pool_fault),
 .session_epoch(authorization_epoch),.frame_generation(frame_id),.camera_id(camera_id[7:0]),
 .roi_index(roi_index),.context_generation(context_generation),.network_session_id(network_session_id),
 .busy(trusted_sequence_busy),.done(tr_done),.fault(tr_fault),.reader_quiescent(reader_quiescent),
 .current_block(tr_current_block),.debug_pc(tr_debug_pc),
 .result_valid(tr_result_valid),.result_class(tr_result_class),.result_best_logit(tr_result_best_logit),
 .result_camera(tr_result_camera),.result_frame(tr_result_frame),.result_epoch(tr_result_epoch),
 .result_sequence(tr_result_sequence),.result_cycle(tr_result_cycle),
 .result_roi_index(tr_result_roi),.result_context_generation(tr_result_generation),.result_session(tr_result_session),
 .service_phase(service_phase),.page_requests(page_requests),.expected_pages(expected_pages),
 .cache_reads(cache_reads),.cache_addresses(cache_addresses),.page_grants(page_grants),.read_grants(read_grants),
 .cache_valid(cache_valid),.cached_page_index(cached_page_index),.cache_read_data(cache_read_data),
 .trusted_authorized(trusted_authorized),.trusted_cancel(trusted_cancel),.trusted_epoch(trusted_epoch),
 .handoff_ready(handoff_ready),.handoff_fault(handoff_fault),.private_read_fault(private_read_fault),
 .handoff_start(handoff_start),.handoff_seed(handoff_seed),.capture_pose(capture_pose),.capture_norm(capture_norm),
 .private_reads_phase(private_reads_phase),.handoff_pose_coefficient(handoff_pose_coefficient),
 .classification_start(classification_start),.classification_capture(classification_capture),
 .classifier_page_request(classifier_page_request),.classifier_page_request_ready(classifier_page_request_ready),
 .classifier_expected_page_index(classifier_expected_page_index),.classifier_cache_valid(classifier_cache_valid),
 .classifier_cached_page_index(classifier_cached_page_index),.classifier_cache_read(classifier_cache_read),
 .classifier_cache_read_addr(classifier_cache_read_addr),.classifier_cache_read_valid(classifier_cache_read_valid),
 .classifier_cache_read_data(classifier_cache_read_data),.classifier_fault(classifier_fault),
 .trusted_result_valid(trusted_result_valid),.trusted_class_index(trusted_class_index),
 .trusted_best_logit(trusted_best_logit),.trusted_result_epoch(trusted_result_epoch),
 .m_awaddr(trusted_axil_AWADDR),
 .m_awvalid(trusted_axil_AWVALID),
 .m_awready(trusted_axil_AWREADY),
 .m_wdata(trusted_axil_WDATA),
 .m_wstrb(trusted_axil_WSTRB),
 .m_wvalid(trusted_axil_WVALID),
 .m_wready(trusted_axil_WREADY),
 .m_bresp(trusted_axil_BRESP),
 .m_bvalid(trusted_axil_BVALID),
 .m_bready(trusted_axil_BREADY),
 .m_araddr(trusted_axil_ARADDR),
 .m_arvalid(trusted_axil_ARVALID),
 .m_arready(trusted_axil_ARREADY),
 .m_rdata(trusted_axil_RDATA),
 .m_rresp(trusted_axil_RRESP),
 .m_rvalid(trusted_axil_RVALID),
 .m_rready(trusted_axil_RREADY),
 .s_araddr(v_M_AXI_ARADDR),
 .s_arlen(v_M_AXI_ARLEN),
 .s_arsize(v_M_AXI_ARSIZE),
 .s_arburst(v_M_AXI_ARBURST),
 .s_arvalid(v_M_AXI_ARVALID),
 .s_rready(v_M_AXI_RREADY),
 .s_arready(auth_axi_ARREADY),
 .s_rdata(auth_axi_RDATA),
 .s_rresp(auth_axi_RRESP),
 .s_rlast(auth_axi_RLAST),
 .s_rvalid(auth_axi_RVALID));
endmodule
