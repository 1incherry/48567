`timescale 1ns/1ps
module npu_yolo_vit_core #(
parameter ENABLE_LIVE_CHAIN=1,parameter AV_CAPABILITY=0,parameter AXI_ADDR_WIDTH=32,parameter AXI_DATA_WIDTH=256,
 parameter [31:0] OUT_BASE_ADDR=32'h1c000000,parameter [15:0] NORM3_TOTAL_ITEMS=49664
)(

 input wire tr_s_clk,
input wire [11:0] sec_awaddr,
input wire  sec_awvalid,
output wire  sec_awready,
input wire [31:0] sec_wdata,
input wire [3:0] sec_wstrb,
input wire  sec_wvalid,
output wire  sec_wready,
output wire [1:0] sec_bresp,
output wire  sec_bvalid,
input wire  sec_bready,
input wire [11:0] sec_araddr,
input wire  sec_arvalid,
output wire  sec_arready,
output wire [31:0] sec_rdata,
output wire [1:0] sec_rresp,
output wire  sec_rvalid,
input wire  sec_rready,
    input wire external_busy,
    output wire external_idle,
    input  wire                         clk,
    input  wire                         rst_n,

    input  wire [11:0]                  S_AXIL_AWADDR,
    input  wire                         S_AXIL_AWVALID,
    output wire                         S_AXIL_AWREADY,
    input  wire [31:0]                  S_AXIL_WDATA,
    input  wire [3:0]                   S_AXIL_WSTRB,
    input  wire                         S_AXIL_WVALID,
    output wire                         S_AXIL_WREADY,
    output wire [1:0]                   S_AXIL_BRESP,
    output wire                         S_AXIL_BVALID,
    input  wire                         S_AXIL_BREADY,
    input  wire [11:0]                  S_AXIL_ARADDR,
    input  wire                         S_AXIL_ARVALID,
    output wire                         S_AXIL_ARREADY,
    output wire [31:0]                  S_AXIL_RDATA,
    output wire [1:0]                   S_AXIL_RRESP,
    output wire                         S_AXIL_RVALID,
    input  wire                         S_AXIL_RREADY,

    output wire [AXI_ADDR_WIDTH-1:0]    M_AXI_ARADDR,
    output wire [7:0]                   M_AXI_ARLEN,
    output wire [2:0]                   M_AXI_ARSIZE,
    output wire [1:0]                   M_AXI_ARBURST,
    output wire                         M_AXI_ARVALID,
    input  wire                         M_AXI_ARREADY,
    input  wire [AXI_DATA_WIDTH-1:0]    M_AXI_RDATA,
    input  wire [1:0]                   M_AXI_RRESP,
    input  wire                         M_AXI_RLAST,
    input  wire                         M_AXI_RVALID,
    output wire                         M_AXI_RREADY,

    output wire [AXI_ADDR_WIDTH-1:0]    M_AXI_AWADDR,
    output wire [7:0]                   M_AXI_AWLEN,
    output wire [2:0]                   M_AXI_AWSIZE,
    output wire [1:0]                   M_AXI_AWBURST,
    output wire                         M_AXI_AWVALID,
    input  wire                         M_AXI_AWREADY,
    output wire [AXI_DATA_WIDTH-1:0]    M_AXI_WDATA,
    output wire [AXI_DATA_WIDTH/8-1:0]  M_AXI_WSTRB,
    output wire                         M_AXI_WLAST,
    output wire                         M_AXI_WVALID,
    input  wire                         M_AXI_WREADY,
    input  wire [1:0]                   M_AXI_BRESP,
    input  wire                         M_AXI_BVALID,
    output wire                         M_AXI_BREADY,

    // Optional trusted data-authentication sideband.  These ports are active
    // under V799_BURST_AUTH or V801_LOAD_AUTH; legacy builds are unchanged.
    input  wire                         data_auth_enable,
    input  wire                         data_auth_expected_valid,
    input  wire [127:0]                 data_auth_expected_tag,
    input  wire [127:0]                 data_auth_mac_key,
    input  wire [111:0]                 data_auth_context,
    input  wire                         data_auth_common_enable,
    input  wire [127:0]                 data_auth_common_object_context,
    input  wire [7:0]                   data_auth_common_dtype,
    input  wire [7:0]                   data_auth_common_role,
    input  wire [7:0]                   data_auth_common_key_id,
    input  wire                         data_auth_secure_clear,
    output wire                         data_auth_done,
    output wire                         data_auth_ok,
    output wire                         data_auth_fail,

    output wire [31:0]                  stat0,
    output wire [31:0]                  stat1,
    output wire [31:0]                  stat2,
    output wire [31:0]                  stat3
);

 wire tr_ready,tr_authorized,tr_done,tr_fault,tr_seed_ready;
 wire tr_result_valid;wire [7:0] tr_result_class;
 wire signed [63:0] tr_result_best_logit;
 wire [7:0] tr_result_camera;
 wire [31:0] tr_result_frame,tr_result_epoch,tr_result_sequence;
 wire [63:0] tr_result_cycle;
 wire [3:0] tr_current_block;wire [15:0] tr_debug_pc;
 wire tr_norm_valid,tr_norm_done,tr_classification_capture;
 wire [15:0] tr_norm_address;wire signed [15:0] tr_norm_data;
 reg compute_launched;reg [31:0] frame_generation;
 // This is a PL-generated task counter, NOT an authenticated camera frame ID.
 // Initial frontend geometry/source selection is still a staged boundary.
 wire tr_prepare_seed,tr_request;
 always @(posedge clk)begin
  if(!rst_n)begin compute_launched<=0;frame_generation<=0;end
  else if(tr_prepare_seed)begin compute_launched<=0;frame_generation<=frame_generation+1'b1;end
  else if(tr_request&&tr_ready)compute_launched<=1;
 end
wire trusted_sequence_busy;
wire  trusted_authorized;
wire  trusted_cancel;
wire [31:0] trusted_epoch;
wire  handoff_start;
wire  handoff_seed;
wire signed [31:0] handoff_pose_coefficient;
wire  capture_pose;
wire  capture_norm;
wire  private_reads_phase;
wire  handoff_ready;
wire  handoff_fault;
wire  private_read_fault;
wire  trusted_fc2_valid;
wire  trusted_fc2_done;
wire [15:0] trusted_fc2_address;
wire signed [15:0] trusted_fc2_data;
wire  trusted_norm_valid;
wire  trusted_norm_done;
wire [15:0] trusted_norm_address;
wire signed [15:0] trusted_norm_data;
wire  classification_start;
wire  classification_capture;
wire  classifier_page_request;
wire  classifier_page_request_ready;
wire [31:0] classifier_expected_page_index;
wire  classifier_cache_valid;
wire [31:0] classifier_cached_page_index;
wire  classifier_cache_read;
wire [9:0] classifier_cache_read_addr;
wire  classifier_cache_read_valid;
wire [31:0] classifier_cache_read_data;
wire  classifier_norm_ready;
wire  classifier_busy;
wire  classifier_fault;
wire  trusted_result_valid;
wire [7:0] trusted_class_index;
wire signed [63:0] trusted_best_logit;
wire [31:0] trusted_result_epoch;
wire [7:0] trusted_axil_AWADDR;
wire [7:0] core_axil_AWADDR;
wire  trusted_axil_AWVALID;
wire  core_axil_AWVALID;
wire  trusted_axil_AWREADY;
wire  core_axil_AWREADY;
wire [31:0] trusted_axil_WDATA;
wire [31:0] core_axil_WDATA;
wire [3:0] trusted_axil_WSTRB;
wire [3:0] core_axil_WSTRB;
wire  trusted_axil_WVALID;
wire  core_axil_WVALID;
wire  trusted_axil_WREADY;
wire  core_axil_WREADY;
wire [1:0] trusted_axil_BRESP;
wire [1:0] core_axil_BRESP;
wire  trusted_axil_BVALID;
wire  core_axil_BVALID;
wire  trusted_axil_BREADY;
wire  core_axil_BREADY;
wire [7:0] trusted_axil_ARADDR;
wire [7:0] core_axil_ARADDR;
wire  trusted_axil_ARVALID;
wire  core_axil_ARVALID;
wire  trusted_axil_ARREADY;
wire  core_axil_ARREADY;
wire [31:0] trusted_axil_RDATA;
wire [31:0] core_axil_RDATA;
wire [1:0] trusted_axil_RRESP;
wire [1:0] core_axil_RRESP;
wire  trusted_axil_RVALID;
wire  core_axil_RVALID;
wire  trusted_axil_RREADY;
wire  core_axil_RREADY;
wire [31:0] auth_axi_ARADDR;
wire [7:0] auth_axi_ARLEN;
wire [2:0] auth_axi_ARSIZE;
wire [1:0] auth_axi_ARBURST;
wire  auth_axi_ARVALID;
wire  auth_axi_ARREADY;
wire [255:0] auth_axi_RDATA;
wire [1:0] auth_axi_RRESP;
wire  auth_axi_RLAST;
wire  auth_axi_RVALID;
wire  auth_axi_RREADY;
wire [7:0] v_S_AXIL_AWADDR;
wire  v_S_AXIL_AWVALID;
wire  v_S_AXIL_AWREADY;
wire [31:0] v_S_AXIL_WDATA;
wire [3:0] v_S_AXIL_WSTRB;
wire  v_S_AXIL_WVALID;
wire  v_S_AXIL_WREADY;
wire [1:0] v_S_AXIL_BRESP;
wire  v_S_AXIL_BVALID;
wire  v_S_AXIL_BREADY;
wire [7:0] v_S_AXIL_ARADDR;
wire  v_S_AXIL_ARVALID;
wire  v_S_AXIL_ARREADY;
wire [31:0] v_S_AXIL_RDATA;
wire [1:0] v_S_AXIL_RRESP;
wire  v_S_AXIL_RVALID;
wire  v_S_AXIL_RREADY;
wire [31:0] v_M_AXI_ARADDR;
wire [31:0] y_M_AXI_ARADDR;
wire [7:0] v_M_AXI_ARLEN;
wire [7:0] y_M_AXI_ARLEN;
wire [2:0] v_M_AXI_ARSIZE;
wire [2:0] y_M_AXI_ARSIZE;
wire [1:0] v_M_AXI_ARBURST;
wire [1:0] y_M_AXI_ARBURST;
wire  v_M_AXI_ARVALID;
wire  y_M_AXI_ARVALID;
wire  v_M_AXI_ARREADY;
wire  y_M_AXI_ARREADY;
wire [255:0] v_M_AXI_RDATA;
wire [255:0] y_M_AXI_RDATA;
wire [1:0] v_M_AXI_RRESP;
wire [1:0] y_M_AXI_RRESP;
wire  v_M_AXI_RLAST;
wire  y_M_AXI_RLAST;
wire  v_M_AXI_RVALID;
wire  y_M_AXI_RVALID;
wire  v_M_AXI_RREADY;
wire  y_M_AXI_RREADY;
wire [31:0] v_M_AXI_AWADDR;
wire [31:0] y_M_AXI_AWADDR;
wire [7:0] v_M_AXI_AWLEN;
wire [7:0] y_M_AXI_AWLEN;
wire [2:0] v_M_AXI_AWSIZE;
wire [2:0] y_M_AXI_AWSIZE;
wire [1:0] v_M_AXI_AWBURST;
wire [1:0] y_M_AXI_AWBURST;
wire  v_M_AXI_AWVALID;
wire  y_M_AXI_AWVALID;
wire  v_M_AXI_AWREADY;
wire  y_M_AXI_AWREADY;
wire [255:0] v_M_AXI_WDATA;
wire [255:0] y_M_AXI_WDATA;
wire [31:0] v_M_AXI_WSTRB;
wire [31:0] y_M_AXI_WSTRB;
wire  v_M_AXI_WLAST;
wire  y_M_AXI_WLAST;
wire  v_M_AXI_WVALID;
wire  y_M_AXI_WVALID;
wire  v_M_AXI_WREADY;
wire  y_M_AXI_WREADY;
wire [1:0] v_M_AXI_BRESP;
wire [1:0] y_M_AXI_BRESP;
wire  v_M_AXI_BVALID;
wire  y_M_AXI_BVALID;
wire  v_M_AXI_BREADY;
wire  y_M_AXI_BREADY;

wire [31:0] f_M_AXI_ARADDR;
wire [7:0] f_M_AXI_ARLEN;
wire [2:0] f_M_AXI_ARSIZE;
wire [1:0] f_M_AXI_ARBURST;
wire  f_M_AXI_ARVALID;
wire  f_M_AXI_ARREADY;
wire [255:0] f_M_AXI_RDATA;
wire [1:0] f_M_AXI_RRESP;
wire  f_M_AXI_RLAST;
wire  f_M_AXI_RVALID;
wire  f_M_AXI_RREADY;
wire [31:0] f_M_AXI_AWADDR;
wire [7:0] f_M_AXI_AWLEN;
wire [2:0] f_M_AXI_AWSIZE;
wire [1:0] f_M_AXI_AWBURST;
wire  f_M_AXI_AWVALID;
wire  f_M_AXI_AWREADY;
wire [255:0] f_M_AXI_WDATA;
wire [31:0] f_M_AXI_WSTRB;
wire  f_M_AXI_WLAST;
wire  f_M_AXI_WVALID;
wire  f_M_AXI_WREADY;
wire [1:0] f_M_AXI_BRESP;
wire  f_M_AXI_BVALID;
wire  f_M_AXI_BREADY;
wire f_busy,f_done,f_error;reg f_go;
wire [31:0] f_perf[0:6];
wire [735:0] f_debug_snapshot;
reg [31:0] f_cfg[0:11];
wire f_a_write,f_b_write,f_a_read,f_b_read;
wire [11:0] f_write_address,f_a_address,f_b_address;
wire [255:0] f_write_data;
wire y_a_write,y_b_write,y_a_read,y_b_read;
wire [11:0] y_write_address,y_a_address,y_b_address;
wire [255:0] y_write_data;
wire f_clear,f_start,f_input_valid,f_scale_valid,f_bias_valid,f_ready;
wire [15:0] f_input_address,f_norm_address;wire signed [15:0] f_input_data,f_norm_data;
wire [7:0] f_param_address;wire signed [31:0] f_param_data;
wire f_norm_valid,f_norm_done;
reg [1:0] owner;
wire vit_busy,yolo_busy,yolo_done,yolo_error,yolo_ready;
reg go;reg [1:0] operation;reg [31:0] ddr_address;reg [15:0] words;reg [11:0] local_address;
reg [31:0] geometry[0:5];reg [31:0] bias;
reg [31:0] nc_cfg[0:15];
wire [511:0] nc_descriptor;
genvar nci;generate for(nci=0;nci<16;nci=nci+1)begin:NC_DESC
 assign nc_descriptor[nci*32+:32]=nc_cfg[nci];
end endgenerate
wire shared_a_write,shared_b_write,shared_a_read,shared_b_read;
wire [11:0] shared_write_address,shared_a_address,shared_b_address;
wire [255:0] shared_write_data,shared_a_data,shared_b_data;
assign shared_a_write=(owner==3)?f_a_write:y_a_write;
assign shared_b_write=(owner==3)?f_b_write:y_b_write;
assign shared_write_address=(owner==3)?f_write_address:y_write_address;
assign shared_write_data=(owner==3)?f_write_data:y_write_data;
assign shared_a_read=(owner==3)?f_a_read:y_a_read;
assign shared_b_read=(owner==3)?f_b_read:y_b_read;
assign shared_a_address=(owner==3)?f_a_address:y_a_address;
assign shared_b_address=(owner==3)?f_b_address:y_b_address;
reg [31:0] completed,blocked;reg last_error,done_sticky;
reg [15:0] read_outstanding,write_outstanding;
reg aw_captured,w_captured,vwrite,vaw_done,vw_done;
reg [11:0] aw_address;reg [31:0] w_value;reg [3:0] w_strobe;
reg b_valid;reg [1:0] b_response;
reg ar_captured,vread,var_done;reg [11:0] ar_address;
reg r_valid;reg [31:0] r_value;reg [1:0] r_response;
assign tr_prepare_seed=f_go&&!trusted_sequence_busy&&tr_authorized;
assign tr_request=owner==2&&!compute_launched&&tr_seed_ready;
wire quiescent=!trusted_sequence_busy&&!f_busy&&!f_go&&!vit_busy&&!yolo_busy&&!go&&!read_outstanding&&!write_outstanding&&!vwrite&&!vread;
assign external_idle=owner==0&&quiescent&&!aw_captured&&!w_captured&&!ar_captured&&!S_AXIL_AWVALID&&!S_AXIL_WVALID;

assign S_AXIL_AWREADY=!aw_captured&&!vwrite&&!b_valid;
assign S_AXIL_WREADY=!w_captured&&!vwrite&&!b_valid;
assign S_AXIL_BVALID=b_valid;assign S_AXIL_BRESP=b_response;
assign S_AXIL_ARREADY=!ar_captured&&!vread&&!r_valid;
assign S_AXIL_RVALID=r_valid;assign S_AXIL_RDATA=r_value;assign S_AXIL_RRESP=r_response;
assign v_S_AXIL_AWADDR=aw_address[7:0];assign v_S_AXIL_AWVALID=vwrite&&!vaw_done;
assign v_S_AXIL_WDATA=w_value;assign v_S_AXIL_WSTRB=w_strobe;assign v_S_AXIL_WVALID=vwrite&&!vw_done;
assign v_S_AXIL_BREADY=vwrite;
assign v_S_AXIL_ARADDR=ar_address[7:0];assign v_S_AXIL_ARVALID=vread&&!var_done;
assign v_S_AXIL_RREADY=vread;
integer gi;
always @(posedge clk)begin
 if(!rst_n)begin
  owner<=0;go<=0;f_go<=0;operation<=0;ddr_address<=0;words<=0;local_address<=0;bias<=0;
  completed<=0;blocked<=0;last_error<=0;done_sticky<=0;read_outstanding<=0;write_outstanding<=0;
  aw_captured<=0;w_captured<=0;vwrite<=0;vaw_done<=0;vw_done<=0;
  aw_address<=0;w_value<=0;w_strobe<=0;b_valid<=0;b_response<=0;
  ar_captured<=0;vread<=0;var_done<=0;ar_address<=0;r_valid<=0;r_value<=0;r_response<=0;
  for(gi=0;gi<6;gi=gi+1)geometry[gi]<=0;
  for(gi=0;gi<12;gi=gi+1)f_cfg[gi]<=0;
  for(gi=0;gi<16;gi=gi+1)nc_cfg[gi]<=0;
 end else begin
  go<=0;f_go<=0;
  case({M_AXI_ARVALID&&M_AXI_ARREADY,M_AXI_RVALID&&M_AXI_RREADY&&M_AXI_RLAST})
   2'b10:read_outstanding<=read_outstanding+1;2'b01:read_outstanding<=read_outstanding-1;
  endcase
  case({M_AXI_AWVALID&&M_AXI_AWREADY,M_AXI_BVALID&&M_AXI_BREADY})
   2'b10:write_outstanding<=write_outstanding+1;2'b01:write_outstanding<=write_outstanding-1;
  endcase
  if(yolo_done)begin completed<=completed+1;last_error<=yolo_error;done_sticky<=1;end
  if(S_AXIL_AWVALID&&S_AXIL_AWREADY)begin aw_captured<=1;aw_address<=S_AXIL_AWADDR;end
  if(S_AXIL_WVALID&&S_AXIL_WREADY)begin w_captured<=1;w_value<=S_AXIL_WDATA;w_strobe<=S_AXIL_WSTRB;end
  if(b_valid&&S_AXIL_BREADY)b_valid<=0;
  if(v_S_AXIL_AWVALID&&v_S_AXIL_AWREADY)vaw_done<=1;
  if(v_S_AXIL_WVALID&&v_S_AXIL_WREADY)vw_done<=1;
  if(vwrite&&v_S_AXIL_BVALID)begin
   vwrite<=0;b_valid<=1;b_response<=v_S_AXIL_BRESP;aw_captured<=0;w_captured<=0;
  end
  if(aw_captured&&w_captured&&!vwrite&&!b_valid)begin
   if(1'b0)begin vwrite<=1;vaw_done<=0;vw_done<=0;end
   else begin
    b_valid<=1;b_response<=0;aw_captured<=0;w_captured<=0;
    if(w_strobe!=15||aw_address[1:0]!=0)begin b_response<=2;blocked<=blocked+1;end
    else if(aw_address==12'h200)begin
     if((external_busy&&w_value!=0)||!quiescent||w_value>3||(owner!=0&&w_value!=0))begin b_response<=2;blocked<=blocked+1;end
     else owner<=w_value[1:0];
    end else if(aw_address>=12'h300 && aw_address<=12'h330)begin
     if(owner!=3||f_busy||f_go||trusted_sequence_busy||!tr_authorized)begin b_response<=2;blocked<=blocked+1;end
     else if(aw_address==12'h300)begin
      if(w_value!=1)begin b_response<=2;blocked<=blocked+1;end else f_go<=1;
     end else f_cfg[(aw_address-12'h304)>>2]<=w_value;
    end else if(owner!=1||yolo_busy||go||read_outstanding||write_outstanding)begin b_response<=2;blocked<=blocked+1;end
    else if(aw_address>=12'h400&&aw_address<=12'h43c)nc_cfg[(aw_address-12'h400)>>2]<=w_value;
    else case(aw_address)
     12'h100:if(yolo_ready)begin operation<=w_value[1:0];go<=1;done_sticky<=0;last_error<=0;end
                  else begin b_response<=2;blocked<=blocked+1;end
     12'h104:ddr_address<=w_value;
     12'h108:begin words<=w_value[15:0];local_address<=w_value[27:16];end
     12'h110:geometry[0]<=w_value;
     12'h114:geometry[1]<=w_value;
     12'h118:geometry[2]<=w_value;
     12'h11c:geometry[3]<=w_value;
     12'h120:geometry[4]<=w_value;
     12'h124:geometry[5]<=w_value;
     12'h128:bias<=w_value;
     default:begin b_response<=2;blocked<=blocked+1;end
    endcase
   end
  end
  if(S_AXIL_ARVALID&&S_AXIL_ARREADY)begin ar_captured<=1;ar_address<=S_AXIL_ARADDR;end
  if(r_valid&&S_AXIL_RREADY)r_valid<=0;
  if(v_S_AXIL_ARVALID&&v_S_AXIL_ARREADY)var_done<=1;
  if(vread&&v_S_AXIL_RVALID)begin vread<=0;r_valid<=1;r_value<=v_S_AXIL_RDATA;r_response<=v_S_AXIL_RRESP;ar_captured<=0;end
  if(ar_captured&&!vread&&!r_valid)begin
   if(1'b0)begin vread<=1;var_done<=0;end
   else begin
    ar_captured<=0;r_valid<=1;r_response<=0;r_value<=0;
    case(ar_address)
     12'h100:r_value<={27'd0,owner, last_error,done_sticky,yolo_busy};
     12'h104:r_value<=ddr_address;
     12'h108:r_value<={4'd0,local_address,words};
     12'h10c:r_value<=completed;
     12'h300:r_value<={29'd0,f_error,f_done,f_busy};
     12'h334:r_value<=32'h46524e31;
     12'h338:r_value<=f_perf[0];
     12'h33c:r_value<=f_perf[1];
     12'h340:r_value<=f_perf[2];
     12'h344:r_value<=f_perf[3];
     12'h348:r_value<=f_perf[4];
     12'h34c:r_value<=f_perf[5];
     12'h350:r_value<=f_perf[6];
     12'h354:r_value<=f_debug_snapshot[0+:32];
     12'h358:r_value<=f_debug_snapshot[32+:32];
     12'h35c:r_value<=f_debug_snapshot[64+:32];
     12'h360:r_value<=f_debug_snapshot[96+:32];
     12'h364:r_value<=f_debug_snapshot[128+:32];
     12'h368:r_value<=f_debug_snapshot[160+:32];
     12'h36c:r_value<=f_debug_snapshot[192+:32];
     12'h370:r_value<=f_debug_snapshot[224+:32];
     12'h374:r_value<=f_debug_snapshot[256+:32];
     12'h378:r_value<=f_debug_snapshot[288+:32];
     12'h37c:r_value<=f_debug_snapshot[320+:32];
     12'h380:r_value<=f_debug_snapshot[352+:32];
     12'h384:r_value<=f_debug_snapshot[384+:32];
     12'h388:r_value<=f_debug_snapshot[416+:32];
     12'h38c:r_value<=f_debug_snapshot[448+:32];
     12'h390:r_value<=f_debug_snapshot[480+:32];
     12'h394:r_value<=f_debug_snapshot[512+:32];
     12'h398:r_value<=f_debug_snapshot[544+:32];
     12'h39c:r_value<=f_debug_snapshot[576+:32];
     12'h3a0:r_value<=f_debug_snapshot[608+:32];
     12'h3a4:r_value<=f_debug_snapshot[640+:32];
     12'h3a8:r_value<=f_debug_snapshot[672+:32];
     12'h3ac:r_value<=f_debug_snapshot[704+:32];

     12'h220:r_value<=32'h54564331;
     12'h224:r_value<={23'd0,tr_current_block,tr_seed_ready,tr_authorized,trusted_sequence_busy,tr_fault,tr_result_valid};
     12'h228:r_value<={24'd0,tr_result_class};
     12'h22c:r_value<=tr_result_best_logit[31:0];
     12'h230:r_value<=tr_result_best_logit[63:32];
     12'h234:r_value<={16'd0,tr_debug_pc};
     12'h238:r_value<=frame_generation;
     12'h23c:r_value<=tr_result_frame;
     12'h240:r_value<=tr_result_epoch;
     12'h244:r_value<=tr_result_sequence;
     12'h248:r_value<={24'd0,tr_result_camera};
     12'h24c:r_value<=tr_result_cycle[31:0];
     12'h250:r_value<=tr_result_cycle[63:32];
     12'h200:r_value<={30'd0,owner};
     12'h204:r_value<=blocked;
     12'h208:r_value<={write_outstanding,read_outstanding};
     12'h20c:r_value<=32'h59565431;
     12'h210:r_value<=AV_CAPABILITY?32'h41565331:0;
     default:begin
      if(ar_address>=12'h400&&ar_address<=12'h43c&&ar_address[1:0]==0)r_value<=nc_cfg[(ar_address-12'h400)>>2];
      else r_response<=2;
     end
    endcase
   end
  end
 end
end
assign M_AXI_ARADDR=(owner==3)?f_M_AXI_ARADDR:(owner==2?v_M_AXI_ARADDR:owner==1?y_M_AXI_ARADDR:0);
assign M_AXI_ARLEN=(owner==3)?f_M_AXI_ARLEN:(owner==2?v_M_AXI_ARLEN:owner==1?y_M_AXI_ARLEN:0);
assign M_AXI_ARSIZE=(owner==3)?f_M_AXI_ARSIZE:(owner==2?v_M_AXI_ARSIZE:owner==1?y_M_AXI_ARSIZE:0);
assign M_AXI_ARBURST=(owner==3)?f_M_AXI_ARBURST:(owner==2?v_M_AXI_ARBURST:owner==1?y_M_AXI_ARBURST:0);
assign M_AXI_ARVALID=(owner==3)?f_M_AXI_ARVALID:(owner==2?1'b0:owner==1?y_M_AXI_ARVALID:0);
assign v_M_AXI_ARREADY=owner==2?auth_axi_ARREADY:0;
assign y_M_AXI_ARREADY=owner==1?M_AXI_ARREADY:0;
assign v_M_AXI_RDATA=owner==2?auth_axi_RDATA:0;
assign y_M_AXI_RDATA=owner==1?M_AXI_RDATA:0;
assign v_M_AXI_RRESP=owner==2?auth_axi_RRESP:0;
assign y_M_AXI_RRESP=owner==1?M_AXI_RRESP:0;
assign v_M_AXI_RLAST=owner==2?auth_axi_RLAST:0;
assign y_M_AXI_RLAST=owner==1?M_AXI_RLAST:0;
assign v_M_AXI_RVALID=owner==2?auth_axi_RVALID:0;
assign y_M_AXI_RVALID=owner==1?M_AXI_RVALID:0;
assign M_AXI_RREADY=(owner==3)?f_M_AXI_RREADY:(owner==2?v_M_AXI_RREADY:owner==1?y_M_AXI_RREADY:0);
assign M_AXI_AWADDR=(owner==3)?f_M_AXI_AWADDR:(owner==2?v_M_AXI_AWADDR:owner==1?y_M_AXI_AWADDR:0);
assign M_AXI_AWLEN=(owner==3)?f_M_AXI_AWLEN:(owner==2?v_M_AXI_AWLEN:owner==1?y_M_AXI_AWLEN:0);
assign M_AXI_AWSIZE=(owner==3)?f_M_AXI_AWSIZE:(owner==2?v_M_AXI_AWSIZE:owner==1?y_M_AXI_AWSIZE:0);
assign M_AXI_AWBURST=(owner==3)?f_M_AXI_AWBURST:(owner==2?v_M_AXI_AWBURST:owner==1?y_M_AXI_AWBURST:0);
assign M_AXI_AWVALID=(owner==3)?f_M_AXI_AWVALID:(owner==2?v_M_AXI_AWVALID:owner==1?y_M_AXI_AWVALID:0);
assign v_M_AXI_AWREADY=owner==2?M_AXI_AWREADY:0;
assign y_M_AXI_AWREADY=owner==1?M_AXI_AWREADY:0;
assign M_AXI_WDATA=(owner==3)?f_M_AXI_WDATA:(owner==2?v_M_AXI_WDATA:owner==1?y_M_AXI_WDATA:0);
assign M_AXI_WSTRB=(owner==3)?f_M_AXI_WSTRB:(owner==2?v_M_AXI_WSTRB:owner==1?y_M_AXI_WSTRB:0);
assign M_AXI_WLAST=(owner==3)?f_M_AXI_WLAST:(owner==2?v_M_AXI_WLAST:owner==1?y_M_AXI_WLAST:0);
assign M_AXI_WVALID=(owner==3)?f_M_AXI_WVALID:(owner==2?v_M_AXI_WVALID:owner==1?y_M_AXI_WVALID:0);
assign v_M_AXI_WREADY=owner==2?M_AXI_WREADY:0;
assign y_M_AXI_WREADY=owner==1?M_AXI_WREADY:0;
assign v_M_AXI_BRESP=owner==2?M_AXI_BRESP:0;
assign y_M_AXI_BRESP=owner==1?M_AXI_BRESP:0;
assign v_M_AXI_BVALID=owner==2?M_AXI_BVALID:0;
assign y_M_AXI_BVALID=owner==1?M_AXI_BVALID:0;
assign M_AXI_BREADY=(owner==3)?f_M_AXI_BREADY:(owner==2?v_M_AXI_BREADY:owner==1?y_M_AXI_BREADY:0);
v736_fullblock_nomemh_axi_lite_full_top #(.ENABLE_LIVE_CHAIN(ENABLE_LIVE_CHAIN),.OUT_BASE_ADDR(OUT_BASE_ADDR)) u_vit(
.trusted_authorized(trusted_authorized),
.trusted_cancel(trusted_cancel),
.trusted_epoch(trusted_epoch),
.handoff_start(handoff_start),
.handoff_seed(handoff_seed),
.handoff_pose_coefficient(handoff_pose_coefficient),
.capture_pose(capture_pose),
.capture_norm(capture_norm),
.private_reads_phase(private_reads_phase),
.handoff_ready(handoff_ready),
.handoff_fault(handoff_fault),
.private_read_fault(private_read_fault),
.trusted_fc2_valid(trusted_fc2_valid),
.trusted_fc2_done(trusted_fc2_done),
.trusted_fc2_address(trusted_fc2_address),
.trusted_fc2_data(trusted_fc2_data),
.trusted_norm_valid(trusted_norm_valid),
.trusted_norm_done(trusted_norm_done),
.trusted_norm_address(trusted_norm_address),
.trusted_norm_data(trusted_norm_data),
.classification_start(classification_start),
.classification_capture(classification_capture),
.classifier_page_request(classifier_page_request),
.classifier_page_request_ready(classifier_page_request_ready),
.classifier_expected_page_index(classifier_expected_page_index),
.classifier_cache_valid(classifier_cache_valid),
.classifier_cached_page_index(classifier_cached_page_index),
.classifier_cache_read(classifier_cache_read),
.classifier_cache_read_addr(classifier_cache_read_addr),
.classifier_cache_read_valid(classifier_cache_read_valid),
.classifier_cache_read_data(classifier_cache_read_data),
.classifier_norm_ready(classifier_norm_ready),
.classifier_busy(classifier_busy),
.classifier_fault(classifier_fault),
.trusted_result_valid(trusted_result_valid),
.trusted_class_index(trusted_class_index),
.trusted_best_logit(trusted_best_logit),
.trusted_result_epoch(trusted_result_epoch),
.S_AXIL_AWADDR(core_axil_AWADDR),
.S_AXIL_AWVALID(core_axil_AWVALID),
.S_AXIL_AWREADY(core_axil_AWREADY),
.S_AXIL_WDATA(core_axil_WDATA),
.S_AXIL_WSTRB(core_axil_WSTRB),
.S_AXIL_WVALID(core_axil_WVALID),
.S_AXIL_WREADY(core_axil_WREADY),
.S_AXIL_BRESP(core_axil_BRESP),
.S_AXIL_BVALID(core_axil_BVALID),
.S_AXIL_BREADY(core_axil_BREADY),
.S_AXIL_ARADDR(core_axil_ARADDR),
.S_AXIL_ARVALID(core_axil_ARVALID),
.S_AXIL_ARREADY(core_axil_ARREADY),
.S_AXIL_RDATA(core_axil_RDATA),
.S_AXIL_RRESP(core_axil_RRESP),
.S_AXIL_RVALID(core_axil_RVALID),
.S_AXIL_RREADY(core_axil_RREADY),
.M_AXI_ARADDR(v_M_AXI_ARADDR),
.M_AXI_ARLEN(v_M_AXI_ARLEN),
.M_AXI_ARSIZE(v_M_AXI_ARSIZE),
.M_AXI_ARBURST(v_M_AXI_ARBURST),
.M_AXI_ARVALID(v_M_AXI_ARVALID),
.M_AXI_ARREADY(v_M_AXI_ARREADY),
.M_AXI_RDATA(v_M_AXI_RDATA),
.M_AXI_RRESP(v_M_AXI_RRESP),
.M_AXI_RLAST(v_M_AXI_RLAST),
.M_AXI_RVALID(v_M_AXI_RVALID),
.M_AXI_RREADY(v_M_AXI_RREADY),
.M_AXI_AWADDR(v_M_AXI_AWADDR),
.M_AXI_AWLEN(v_M_AXI_AWLEN),
.M_AXI_AWSIZE(v_M_AXI_AWSIZE),
.M_AXI_AWBURST(v_M_AXI_AWBURST),
.M_AXI_AWVALID(v_M_AXI_AWVALID),
.M_AXI_AWREADY(v_M_AXI_AWREADY),
.M_AXI_WDATA(v_M_AXI_WDATA),
.M_AXI_WSTRB(v_M_AXI_WSTRB),
.M_AXI_WLAST(v_M_AXI_WLAST),
.M_AXI_WVALID(v_M_AXI_WVALID),
.M_AXI_WREADY(v_M_AXI_WREADY),
.M_AXI_BRESP(v_M_AXI_BRESP),
.M_AXI_BVALID(v_M_AXI_BVALID),
.M_AXI_BREADY(v_M_AXI_BREADY),
.clk(clk),
.rst_n(rst_n),
.data_auth_enable(data_auth_enable),
.data_auth_expected_valid(data_auth_expected_valid),
.data_auth_expected_tag(data_auth_expected_tag),
.data_auth_mac_key(data_auth_mac_key),
.data_auth_context(data_auth_context),
.data_auth_common_enable(data_auth_common_enable),
.data_auth_common_object_context(data_auth_common_object_context),
.data_auth_common_dtype(data_auth_common_dtype),
.data_auth_common_role(data_auth_common_role),
.data_auth_common_key_id(data_auth_common_key_id),
.data_auth_secure_clear(data_auth_secure_clear),
.data_auth_done(data_auth_done),
.data_auth_ok(data_auth_ok),
.data_auth_fail(data_auth_fail),
.stat0(stat0),
.stat1(stat1),
.stat2(stat2),
.stat3(stat3),
 .shared_owner(owner==1||owner==3),.shared_a_write(shared_a_write),.shared_b_write(shared_b_write),
 .shared_write_address(shared_write_address),.shared_write_data(shared_write_data),
 .shared_a_read(shared_a_read),.shared_b_read(shared_b_read),
 .shared_a_address(shared_a_address),.shared_b_address(shared_b_address),
 .shared_a_data(shared_a_data),.shared_b_data(shared_b_data),.integration_busy(vit_busy),
 .frontend_owner(owner==3),.frontend_clear(f_clear),.frontend_start(f_start),
 .frontend_input_valid(f_input_valid),.frontend_input_address(f_input_address),.frontend_input_data(f_input_data),
 .frontend_scale_valid(f_scale_valid),.frontend_bias_valid(f_bias_valid),
 .frontend_param_address(f_param_address),.frontend_param_data(f_param_data),
 .frontend_ready(f_ready),.frontend_valid(f_norm_valid),.frontend_done(f_norm_done),
 .frontend_address(f_norm_address),.frontend_data(f_norm_data));
yolo_ddr_engine u_yolo(
.M_AXI_ARADDR(y_M_AXI_ARADDR),
.M_AXI_ARLEN(y_M_AXI_ARLEN),
.M_AXI_ARSIZE(y_M_AXI_ARSIZE),
.M_AXI_ARBURST(y_M_AXI_ARBURST),
.M_AXI_ARVALID(y_M_AXI_ARVALID),
.M_AXI_ARREADY(y_M_AXI_ARREADY),
.M_AXI_RDATA(y_M_AXI_RDATA),
.M_AXI_RRESP(y_M_AXI_RRESP),
.M_AXI_RLAST(y_M_AXI_RLAST),
.M_AXI_RVALID(y_M_AXI_RVALID),
.M_AXI_RREADY(y_M_AXI_RREADY),
.M_AXI_AWADDR(y_M_AXI_AWADDR),
.M_AXI_AWLEN(y_M_AXI_AWLEN),
.M_AXI_AWSIZE(y_M_AXI_AWSIZE),
.M_AXI_AWBURST(y_M_AXI_AWBURST),
.M_AXI_AWVALID(y_M_AXI_AWVALID),
.M_AXI_AWREADY(y_M_AXI_AWREADY),
.M_AXI_WDATA(y_M_AXI_WDATA),
.M_AXI_WSTRB(y_M_AXI_WSTRB),
.M_AXI_WLAST(y_M_AXI_WLAST),
.M_AXI_WVALID(y_M_AXI_WVALID),
.M_AXI_WREADY(y_M_AXI_WREADY),
.M_AXI_BRESP(y_M_AXI_BRESP),
.M_AXI_BVALID(y_M_AXI_BVALID),
.M_AXI_BREADY(y_M_AXI_BREADY),
 .clk(clk),.rst_n(rst_n),.cmd_valid(go),.cmd_ready(yolo_ready),.cmd_op(operation),
 .cmd_address(ddr_address),.cmd_words(words),.cmd_local_address(local_address),
 .cfg_descriptor(nc_descriptor),
 .cfg_input_h(geometry[0][31:16]),.cfg_input_w(geometry[0][15:0]),
 .cfg_input_row0(geometry[1][31:16]),.cfg_input_rows(geometry[1][15:0]),
 .cfg_channel_blocks(geometry[2][31:16]),.cfg_output_w(geometry[2][15:0]),
 .cfg_output_row0(geometry[3][31:16]),.cfg_output_rows(geometry[3][15:0]),
 .cfg_kernel(geometry[4][3:0]),.cfg_stride(geometry[4][7:4]),.cfg_padding(geometry[4][11:8]),
 .cfg_zero_point(geometry[5][7:0]),.cfg_bias(bias),.busy(yolo_busy),.done(yolo_done),.error(yolo_error),
 .a_write(y_a_write),.b_write(y_b_write),.bank_write_address(y_write_address),.bank_write_data(y_write_data),
 .a_read(y_a_read),.b_read(y_b_read),.a_read_address(y_a_address),.b_read_address(y_b_address),
 .a_read_data(shared_a_data),.b_read_data(shared_b_data));
assign f_M_AXI_ARREADY=owner==3?M_AXI_ARREADY:0;
assign f_M_AXI_RDATA=owner==3?M_AXI_RDATA:0;
assign f_M_AXI_RRESP=owner==3?M_AXI_RRESP:0;
assign f_M_AXI_RLAST=owner==3?M_AXI_RLAST:0;
assign f_M_AXI_RVALID=owner==3?M_AXI_RVALID:0;
assign f_M_AXI_AWREADY=owner==3?M_AXI_AWREADY:0;
assign f_M_AXI_WREADY=owner==3?M_AXI_WREADY:0;
assign f_M_AXI_BRESP=owner==3?M_AXI_BRESP:0;
assign f_M_AXI_BVALID=owner==3?M_AXI_BVALID:0;
frontend_ddr_engine u_frontend(
.debug_owner(owner),.debug_snapshot(f_debug_snapshot),
.perf_total(f_perf[0]),.perf_param(f_perf[1]),.perf_resize(f_perf[2]),.perf_embed(f_perf[3]),.perf_norm(f_perf[4]),.perf_ar(f_perf[5]),.perf_aw(f_perf[6]),
.M_AXI_ARADDR(f_M_AXI_ARADDR),
.M_AXI_ARLEN(f_M_AXI_ARLEN),
.M_AXI_ARSIZE(f_M_AXI_ARSIZE),
.M_AXI_ARBURST(f_M_AXI_ARBURST),
.M_AXI_ARVALID(f_M_AXI_ARVALID),
.M_AXI_ARREADY(f_M_AXI_ARREADY),
.M_AXI_RDATA(f_M_AXI_RDATA),
.M_AXI_RRESP(f_M_AXI_RRESP),
.M_AXI_RLAST(f_M_AXI_RLAST),
.M_AXI_RVALID(f_M_AXI_RVALID),
.M_AXI_RREADY(f_M_AXI_RREADY),
.M_AXI_AWADDR(f_M_AXI_AWADDR),
.M_AXI_AWLEN(f_M_AXI_AWLEN),
.M_AXI_AWSIZE(f_M_AXI_AWSIZE),
.M_AXI_AWBURST(f_M_AXI_AWBURST),
.M_AXI_AWVALID(f_M_AXI_AWVALID),
.M_AXI_AWREADY(f_M_AXI_AWREADY),
.M_AXI_WDATA(f_M_AXI_WDATA),
.M_AXI_WSTRB(f_M_AXI_WSTRB),
.M_AXI_WLAST(f_M_AXI_WLAST),
.M_AXI_WVALID(f_M_AXI_WVALID),
.M_AXI_WREADY(f_M_AXI_WREADY),
.M_AXI_BRESP(f_M_AXI_BRESP),
.M_AXI_BVALID(f_M_AXI_BVALID),
.M_AXI_BREADY(f_M_AXI_BREADY),
 .clk(clk),.rst_n(rst_n),.go(f_go),.busy(f_busy),.done(f_done),.error(f_error),
 .source_base(f_cfg[0]),.source_stride(f_cfg[1]),.roi_xy(f_cfg[2]),.roi_wh(f_cfg[3]),
 .crop_base(f_cfg[4]),.temp_base(f_cfg[5]),.param_base(f_cfg[6]),.seed_base(f_cfg[7]),
 .pose_base(f_cfg[8]),.x_base(f_cfg[9]),.source_wh(f_cfg[10]),.reserved(f_cfg[11]),
 .a_write(f_a_write),.b_write(f_b_write),.write_address(f_write_address),.write_data(f_write_data),
 .a_read(f_a_read),.b_read(f_b_read),.a_address(f_a_address),.b_address(f_b_address),
 .a_data(shared_a_data),.b_data(shared_b_data),
 .norm_clear(f_clear),.norm_start(f_start),.norm_input_valid(f_input_valid),
 .norm_input_address(f_input_address),.norm_input_data(f_input_data),
 .norm_scale_valid(f_scale_valid),.norm_bias_valid(f_bias_valid),
 .norm_param_address(f_param_address),.norm_param_data(f_param_data),
 .norm_ready(f_ready),.norm_valid(f_norm_valid),.norm_done(f_norm_done),
 .norm_address(f_norm_address),.norm_data(f_norm_data));
assign core_axil_AWADDR=owner==2?trusted_axil_AWADDR:v_S_AXIL_AWADDR;
assign core_axil_AWVALID=owner==2?trusted_axil_AWVALID:v_S_AXIL_AWVALID;
assign trusted_axil_AWREADY=owner==2?core_axil_AWREADY:'0;
assign v_S_AXIL_AWREADY=owner==2?'0:core_axil_AWREADY;
assign core_axil_WDATA=owner==2?trusted_axil_WDATA:v_S_AXIL_WDATA;
assign core_axil_WSTRB=owner==2?trusted_axil_WSTRB:v_S_AXIL_WSTRB;
assign core_axil_WVALID=owner==2?trusted_axil_WVALID:v_S_AXIL_WVALID;
assign trusted_axil_WREADY=owner==2?core_axil_WREADY:'0;
assign v_S_AXIL_WREADY=owner==2?'0:core_axil_WREADY;
assign trusted_axil_BRESP=owner==2?core_axil_BRESP:'0;
assign v_S_AXIL_BRESP=owner==2?'0:core_axil_BRESP;
assign trusted_axil_BVALID=owner==2?core_axil_BVALID:'0;
assign v_S_AXIL_BVALID=owner==2?'0:core_axil_BVALID;
assign core_axil_BREADY=owner==2?trusted_axil_BREADY:v_S_AXIL_BREADY;
assign core_axil_ARADDR=owner==2?trusted_axil_ARADDR:v_S_AXIL_ARADDR;
assign core_axil_ARVALID=owner==2?trusted_axil_ARVALID:v_S_AXIL_ARVALID;
assign trusted_axil_ARREADY=owner==2?core_axil_ARREADY:'0;
assign v_S_AXIL_ARREADY=owner==2?'0:core_axil_ARREADY;
assign trusted_axil_RDATA=owner==2?core_axil_RDATA:'0;
assign v_S_AXIL_RDATA=owner==2?'0:core_axil_RDATA;
assign trusted_axil_RRESP=owner==2?core_axil_RRESP:'0;
assign v_S_AXIL_RRESP=owner==2?'0:core_axil_RRESP;
assign trusted_axil_RVALID=owner==2?core_axil_RVALID:'0;
assign v_S_AXIL_RVALID=owner==2?'0:core_axil_RVALID;
assign core_axil_RREADY=owner==2?trusted_axil_RREADY:v_S_AXIL_RREADY;
npu_trusted_board_path trusted_path(
.frame_generation(frame_generation),
.sec_awaddr(sec_awaddr),
.sec_awvalid(sec_awvalid),
.sec_awready(sec_awready),
.sec_wdata(sec_wdata),
.sec_wstrb(sec_wstrb),
.sec_wvalid(sec_wvalid),
.sec_wready(sec_wready),
.sec_bresp(sec_bresp),
.sec_bvalid(sec_bvalid),
.sec_bready(sec_bready),
.sec_araddr(sec_araddr),
.sec_arvalid(sec_arvalid),
.sec_arready(sec_arready),
.sec_rdata(sec_rdata),
.sec_rresp(sec_rresp),
.sec_rvalid(sec_rvalid),
.sec_rready(sec_rready),
.result_camera(tr_result_camera),
.result_frame(tr_result_frame),
.result_epoch(tr_result_epoch),
.result_sequence(tr_result_sequence),
.result_cycle(tr_result_cycle),
.clk(clk),
.s_clk(tr_s_clk),
.rst_n(rst_n),
.prepare_seed(tr_prepare_seed),
.frontend_owner(owner==3),
.busy(trusted_sequence_busy),
.request_valid(tr_request),
.request_ready(tr_ready),
.model_authorized(tr_authorized),
.done(tr_done),
.fault(tr_fault),
.current_block(tr_current_block),
.debug_pc(tr_debug_pc),
.result_valid(tr_result_valid),
.result_class(tr_result_class),
.result_best_logit(tr_result_best_logit),
.trusted_authorized(trusted_authorized),
.trusted_cancel(trusted_cancel),
.trusted_epoch(trusted_epoch),
.handoff_ready(handoff_ready),
.handoff_fault(handoff_fault),
.private_read_fault(private_read_fault),
.handoff_start(handoff_start),
.handoff_seed(handoff_seed),
.capture_pose(capture_pose),
.capture_norm(capture_norm),
.private_reads_phase(private_reads_phase),
.handoff_pose_coefficient(handoff_pose_coefficient),
.classification_start(classification_start),
.classification_capture(classification_capture),
.classifier_page_request(classifier_page_request),
.classifier_page_request_ready(classifier_page_request_ready),
.classifier_expected_page_index(classifier_expected_page_index),
.classifier_cache_valid(classifier_cache_valid),
.classifier_cached_page_index(classifier_cached_page_index),
.classifier_cache_read(classifier_cache_read),
.classifier_cache_read_addr(classifier_cache_read_addr),
.classifier_cache_read_valid(classifier_cache_read_valid),
.classifier_cache_read_data(classifier_cache_read_data),
.classifier_fault(classifier_fault),
.trusted_result_valid(trusted_result_valid),
.trusted_class_index(trusted_class_index),
.trusted_best_logit(trusted_best_logit),
.trusted_result_epoch(trusted_result_epoch),
.m_awaddr(trusted_axil_AWADDR),
.m_awvalid(trusted_axil_AWVALID),
.m_awready(trusted_axil_AWREADY),
.m_wdata(trusted_axil_WDATA),
.m_wstrb(trusted_axil_WSTRB),
.m_wvalid(trusted_axil_WVALID),
.m_wready(trusted_axil_WREADY),
.m_bresp(trusted_axil_BRESP),
.m_bvalid(trusted_axil_BVALID),
.m_bready(trusted_axil_BREADY),
.m_araddr(trusted_axil_ARADDR),
.m_arvalid(trusted_axil_ARVALID),
.m_arready(trusted_axil_ARREADY),
.m_rdata(trusted_axil_RDATA),
.m_rresp(trusted_axil_RRESP),
.m_rvalid(trusted_axil_RVALID),
.m_rready(trusted_axil_RREADY),
.s_araddr(v_M_AXI_ARADDR),
.s_arlen(v_M_AXI_ARLEN),
.s_arsize(v_M_AXI_ARSIZE),
.s_arburst(v_M_AXI_ARBURST),
.s_arvalid(v_M_AXI_ARVALID&&owner==2),
.s_arready(auth_axi_ARREADY),
.s_rdata(auth_axi_RDATA),
.s_rresp(auth_axi_RRESP),
.s_rlast(auth_axi_RLAST),
.s_rvalid(auth_axi_RVALID),
.s_rready(v_M_AXI_RREADY)
);

assign tr_seed_ready=handoff_ready;
assign tr_norm_valid=trusted_norm_valid;
assign tr_norm_done=trusted_norm_done;
assign tr_norm_address=trusted_norm_address;
assign tr_norm_data=trusted_norm_data;
assign tr_classification_capture=classification_capture;
endmodule
