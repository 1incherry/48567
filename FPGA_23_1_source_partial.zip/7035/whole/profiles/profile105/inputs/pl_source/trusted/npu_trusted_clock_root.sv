`timescale 1ns/1ps
// R6 independent timing candidate. Synchronized reset release uses dedicated
// global routing instead of a single fabric net driving thousands of loads.
// No PS-controlled clock source and no extra task-state release stage.
module npu_trusted_clock_root(
 input wire sys_clk_50m,sys_rst_n,ps_reset_n,
 output wire clk100,clk50,ref200,locked,
 output wire common_reset_n,reset100_n,reset50_n,
 output wire raw100_trusted
);
 wire feedback,feedback_buffer;
 wire raw100,raw50,raw200;
 MMCME2_BASE #(
  .BANDWIDTH("OPTIMIZED"),.CLKIN1_PERIOD(20.000),
  .DIVCLK_DIVIDE(1),.CLKFBOUT_MULT_F(20.000),
  .CLKOUT0_DIVIDE_F(20.000),.CLKOUT1_DIVIDE(20),.CLKOUT2_DIVIDE(5),
  .CLKOUT0_DUTY_CYCLE(0.500),.CLKOUT1_DUTY_CYCLE(0.500),.CLKOUT2_DUTY_CYCLE(0.500),
  .STARTUP_WAIT("FALSE")
 ) u_mmcm(.CLKIN1(sys_clk_50m),.CLKFBIN(feedback_buffer),.CLKFBOUT(feedback),
  .CLKOUT0(raw100),.CLKOUT1(raw50),.CLKOUT2(raw200),.LOCKED(locked),
  .PWRDWN(1'b0),.RST(!sys_rst_n));
 BUFG u_feedback(.I(feedback),.O(feedback_buffer));
 // Dedicated MMCM clock alias; used only by an explicitly selected BUFGCE.
 assign raw100_trusted=raw100;
 BUFG u_clk100(.I(raw100),.O(clk100));
 BUFG u_clk50(.I(raw50),.O(clk50));
 BUFG u_ref200(.I(raw200),.O(ref200));
 assign common_reset_n=sys_rst_n&&ps_reset_n&&locked;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *) reg [2:0] reset100_pipe,reset50_pipe;
 always @(posedge clk100 or negedge common_reset_n)
  if(!common_reset_n)reset100_pipe<=0;else reset100_pipe<={reset100_pipe[1:0],1'b1};
 always @(posedge clk50 or negedge common_reset_n)
  if(!common_reset_n)reset50_pipe<=0;else reset50_pipe<={reset50_pipe[1:0],1'b1};
 BUFG u_reset100_global(.I(reset100_pipe[2]),.O(reset100_n));
 BUFG u_reset50_global(.I(reset50_pipe[2]),.O(reset50_n));
endmodule
