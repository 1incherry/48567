`timescale 1ns/1ps
// Actual system candidate. No PS owner/GO/authority port and no modeled NN.
// All authority comes from the protected root and the actual V2 model service.
module npu_full_pool_sm4_system(
 input wire clk,trusted_por_n,clock_locked,ps_reset_n,
 input wire external_memory_available,external_resources_quiescent,
 input wire [31:0] debug_command,debug_resume_epoch,
 input wire [127:0] debug_key,debug_session_id,debug_key_fingerprint,
 output wire [31:0] ack_word,status_word,last_sequence_word,
 output wire security_reset_n,arith_reset_n,authorized,key_valid,active,quiescent,fault,job_done,
 output wire [31:0] authorization_epoch,model_epoch,
 output wire [127:0] key_session_id,
 output wire raw_model_authorized,model_lease_valid,
 input wire [11:0] PS_AWADDR,PS_ARADDR,
 input wire PS_AWVALID,PS_WVALID,PS_BREADY,PS_ARVALID,PS_RREADY,
 input wire [31:0] PS_WDATA,input wire [3:0] PS_WSTRB,
 output wire PS_AWREADY,PS_WREADY,PS_BVALID,PS_ARREADY,PS_RVALID,
 output wire [1:0] PS_BRESP,PS_RRESP,output wire [31:0] PS_RDATA,
 input wire packet_valid,input wire [383:0] packet_header,output wire packet_release,
 output wire payload_read,output wire [9:0] payload_address,input wire [7:0] payload_data,input wire payload_read_valid,
 output wire response_valid,input wire response_ready,output wire [7:0] response_kind,response_flags,
 output wire [31:0] response_offset,response_frame_crc,response_session_id,response_frame_id,response_total_bytes,
 output wire [15:0] response_width,response_height,
 output wire [31:0] completed_frames,rejected_completions,committed_offset,received_crc,
 output wire observation_frame_start,observation_ingress_done,observation_page_accept,observation_page_input_wait,
 output wire [31:0] observation_page_index,observation_model_address,observation_proof_address,
 output wire [2:0] service_committed_owner,output wire [1:0] hp_committed_owner,
 output wire metrics_valid,metrics_fault,output wire [63:0] metrics_total,metrics_ingress,metrics_yolo,
 output wire [255:0] metrics_frontend,metrics_nn,metrics_head,
 output wire [63:0] metrics_page_input_wait,metrics_mac_busy,metrics_pool_wait,
 output wire [3:0] metrics_roi_measured,output wire [31:0] metrics_sequence,
 output wire [63:0] frame_elapsed_cycles,
 output wire record_visible,
 output wire record_commit_pulse,
 output wire [31:0] record_camera,
 output wire [31:0] record_session,
 output wire [31:0] record_frame,
 output wire [31:0] record_epoch,
 output wire [127:0] record_key_session,
 output wire [2:0] record_count,
 output wire [895:0] record_rois,
 output wire [51:0] record_indices,
 output wire [511:0] record_results,
 output wire observation_pool_wait,
 output wire observation_yolo_start,
 output wire observation_yolo_done,
 output wire observation_frontend_start,
 output wire observation_nn_start,
 output wire observation_nn_done,
 output wire observation_head_start,
 output wire [31:0] observation_roi_index,
 output wire [31:0] observation_generation,
 output wire [3:0] observation_block,
 output wire observation_norm3_valid,
 output wire observation_norm3_done,
 output wire [15:0] observation_norm3_address,
 output wire [15:0] observation_norm3_data,
 output wire observation_logit_valid,
 output wire [7:0] observation_logit_class,
 output wire [63:0] observation_logit_data,
 output wire observation_result_valid,
 output wire [7:0] observation_result_class,
 output wire [63:0] observation_result_logit,
 output wire [31:0] observation_consumer_session,
 output wire [31:0] observation_consumer_frame,
 output wire [31:0] observation_consumer_epoch,
 output wire [31:0] observation_context_camera,
 output wire [31:0] observation_context_session,
 output wire [31:0] observation_context_frame,
 output wire [31:0] observation_context_epoch,
 output wire [31:0] M_AXI_ARADDR,
 output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,
 output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,
 input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,
 input wire [1:0] M_AXI_RRESP,
 input wire M_AXI_RLAST,
 input wire M_AXI_RVALID,
 output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,
 output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,
 output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,
 input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,
 output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,
 output wire M_AXI_WVALID,
 input wire M_AXI_WREADY,
 input wire [1:0] M_AXI_BRESP,
 input wire M_AXI_BVALID,
 output wire M_AXI_BREADY
);

wire controller_authorized,controller_key_session_valid,root_cancel,commit_allowed;
wire [127:0] controller_session_id,controller_key_fingerprint,installed_key;
wire [31:0] controller_epoch;
wire all_quiescent,provision_ready,provision_accepted,provision_rejected,provision_valid,trusted_fresh_key_ready;
wire [127:0] provision_session_id,provision_key_fingerprint;
wire resume_ready,resume_accepted,resume_rejected,trusted_resume_valid;
wire [31:0] trusted_resume_epoch;wire [127:0] trusted_resume_session_id;
wire trusted_job_ready,trusted_job_request,trusted_revoke,provider_busy;
wire root_quiet,draining,epoch_exhausted,session_exhausted,drain_timed_out,locked_fault;
wire hub_quiescent,hub_fault,service_busy,service_fault,slh_busy,feeder_quiescent;
wire model_verification_start,feeder_cancelled,lease_revoke;
wire [31:0] bound_model_epoch,bound_runtime_epoch;wire [127:0] bound_key_session;
wire [7:0] signature_error,policy_error,page_error,feeder_error;
wire camera_active,camera_fault,camera_quiescent,camera_go_ready,camera_job_valid,camera_job_ready;
wire [31:0] camera_job_session,camera_job_frame,camera_job_epoch,camera_job_base;
wire camera_job_cancel,sealed_letterbox_valid;wire [31:0] sealed_session,sealed_frame,sealed_epoch;
wire observation_capture_start;
wire vision_active,vision_quiescent,vision_done,vision_failed,vision_fault;
wire camera_guard_quiet,camera_backend_quiet,shared_mac_quiet,shared_mac_fault,hp_quiet,hp_fault;
wire model_cancellation_pending;
wire hard_fault=locked_fault||hub_fault||shared_mac_fault||hp_fault;
wire global_fault=hard_fault;
wire stage_fault,abort_execution;
wire provider_key_valid,vision_job_ready;
wire [1:0] cbc_ready,cbc_response_valid,cbc_response_error;wire [255:0] cbc_tag;
assign authorization_epoch=controller_epoch;assign key_session_id=controller_session_id;
assign fault=hard_fault||service_fault||vision_fault||camera_fault;
assign active=camera_active||vision_active;
assign quiescent=all_quiescent;
assign key_valid=provider_key_valid&&controller_key_session_valid;
trusted_debug_key_provider u_provider(
 .clk(clk),.security_reset_n(security_reset_n),.debug_command(debug_command),.debug_key(debug_key),.debug_session_id(debug_session_id),.debug_key_fingerprint(debug_key_fingerprint),.debug_resume_epoch(debug_resume_epoch),
 .all_quiescent(all_quiescent),.controller_authorized(controller_authorized),.controller_key_session_valid(controller_key_session_valid),.model_authorized(raw_model_authorized),.controller_session_id(controller_session_id),.controller_key_fingerprint(controller_key_fingerprint),.controller_epoch(controller_epoch),
 .provision_ready(provision_ready),.provision_accepted(provision_accepted),.provision_rejected(provision_rejected),.provision_valid(provision_valid),.trusted_fresh_key_ready(trusted_fresh_key_ready),.provision_session_id(provision_session_id),.provision_key_fingerprint(provision_key_fingerprint),
 .resume_ready(resume_ready),.resume_accepted(resume_accepted),.resume_rejected(resume_rejected),.trusted_resume_valid(trusted_resume_valid),.trusted_resume_epoch(trusted_resume_epoch),.trusted_resume_session_id(trusted_resume_session_id),
 .trusted_job_ready(trusted_job_ready),.trusted_job_request(trusted_job_request),.trusted_revoke(trusted_revoke),.installed_key(installed_key),.guard_key_valid(provider_key_valid),.ack_word(ack_word),.status_word(status_word),.last_sequence_word(last_sequence_word),.busy(provider_busy));
trusted_reset_session_controller u_root(
 .clk(clk),.trusted_por_n(trusted_por_n),.clock_locked(clock_locked),.ps_reset_n(ps_reset_n),.trusted_revoke(trusted_revoke||lease_revoke||hard_fault||stage_fault),
 .guard_quiescent(all_quiescent),.axi_quiescent(all_quiescent),.consumer_quiescent(all_quiescent),
 .provision_valid(provision_valid),.provision_ready(provision_ready),.trusted_fresh_key_ready(trusted_fresh_key_ready),.provision_session_id(provision_session_id),.provision_key_fingerprint(provision_key_fingerprint),.provision_accepted(provision_accepted),.provision_rejected(provision_rejected),
 .trusted_resume_valid(trusted_resume_valid),.trusted_resume_ready(resume_ready),.trusted_resume_epoch(trusted_resume_epoch),.trusted_resume_session_id(trusted_resume_session_id),.resume_accepted(resume_accepted),.resume_rejected(resume_rejected),
 .consumer_done(job_done),.accepted_done(),.security_reset_n(security_reset_n),.arith_reset_n(arith_reset_n),.authorized(controller_authorized),.key_session_valid(controller_key_session_valid),.cancel(root_cancel),.commit_allowed(commit_allowed),
 .authorization_epoch(controller_epoch),.session_id(controller_session_id),.key_fingerprint(controller_key_fingerprint),.quiescent(root_quiet),.draining(draining),.epoch_exhausted(epoch_exhausted),.session_exhausted(session_exhausted),.drain_timed_out(drain_timed_out),.locked_fault(locked_fault));
trusted_runtime_model_lease u_model_lease(
 .clk(clk),.security_reset_n(security_reset_n),.root_authorized(controller_authorized),.root_key_session_valid(key_valid),.stop(root_cancel||!ps_reset_n),.runtime_epoch(controller_epoch),.key_session_id(controller_session_id),
 .raw_model_authorized(raw_model_authorized),.model_epoch(model_epoch),.model_verification_start(model_verification_start),.feeder_cancelled(feeder_cancelled),.model_fault(service_fault||hard_fault),.all_quiescent(all_quiescent),
 .authorized(authorized),.revoke(lease_revoke),.valid(model_lease_valid),.bound_model_epoch(bound_model_epoch),.bound_runtime_epoch(bound_runtime_epoch),.bound_key_session(bound_key_session));
// Do not feed !root_authorized to the hub: initial pre-resume SLH verification
// must remain possible. A real revocation cancels until the hub actually drains,
// then permits a fresh signature while inference remains denied by the root.
reg cancel_model,previous_root_authorized;
assign model_cancellation_pending=cancel_model||!ps_reset_n;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)begin cancel_model<=0;previous_root_authorized<=0;end
 else begin
  previous_root_authorized<=controller_authorized;
  if(lease_revoke||(previous_root_authorized&&!controller_authorized)||!ps_reset_n||global_fault)cancel_model<=1;
  else if(hub_quiescent)cancel_model<=0;
 end
end
localparam IDLE=0,CAPTURE=1,VISION=2,DRAIN=3;
reg [1:0] stage;
reg vision_launched,camera_launched;
assign stage_fault=(camera_launched&&stage==CAPTURE&&camera_fault)||(vision_launched&&stage==VISION&&(vision_failed||vision_fault));
assign abort_execution=root_cancel||!authorized||hard_fault||stage_fault;
wire camera_resources_quiet=camera_guard_quiet&&camera_backend_quiet&&shared_mac_quiet;
wire [1:0] desired_hp_owner=(stage==IDLE||stage==CAPTURE)?2'd1:2'd2;
wire hp_owner_ready;
assign trusted_job_ready=stage==IDLE&&camera_go_ready&&hp_owner_ready&&hp_committed_owner==1&&shared_mac_quiet&&authorized&&key_valid&&!global_fault&&external_memory_available;
wire camera_go=trusted_job_request&&trusted_job_ready;
assign observation_frame_start=camera_go;
wire vision_job_valid=camera_job_valid&&stage==VISION&&hp_owner_ready&&hp_committed_owner==2&&authorized&&key_valid&&!global_fault;
assign camera_job_ready=vision_job_ready&&stage==VISION&&hp_owner_ready&&hp_committed_owner==2&&authorized&&key_valid&&!global_fault;
assign observation_ingress_done=vision_job_valid&&vision_job_ready;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)stage<=IDLE;
 else if(abort_execution&&stage!=IDLE)stage<=DRAIN;
 else case(stage)
  IDLE:if(camera_go)stage<=CAPTURE;
  CAPTURE:if(camera_job_valid&&camera_resources_quiet)stage<=VISION;
  VISION:if(vision_done||vision_failed)stage<=DRAIN;
  DRAIN:if(!camera_active&&vision_quiescent&&camera_resources_quiet&&hp_quiet&&hub_quiescent)stage<=IDLE;
 endcase
end
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)vision_launched<=0;
 else if(stage==IDLE)vision_launched<=0;
 else if(vision_job_valid&&vision_job_ready)vision_launched<=1;
end
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)camera_launched<=0;
 else if(camera_go)camera_launched<=0;
 else if(observation_capture_start)camera_launched<=1;
end
// The coordinator emits its completed frame count only for a matching actual
// child completion after all accepted ingress/vision work has drained.
reg [31:0] previous_completed;
assign job_done=completed_frames!=previous_completed&&authorized&&key_valid&&!global_fault;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)previous_completed<=0;else previous_completed<=completed_frames;
end
assign all_quiescent=!camera_active&&vision_quiescent&&camera_resources_quiet&&hp_quiet&&hub_quiescent&&external_resources_quiescent;


wire [2:0] service_owner;
wire [3:0] service_page_request,service_cache_read,service_page_ready,service_cache_read_valid;
wire [127:0] service_expected_pages;wire [39:0] service_cache_addresses;
wire service_page_done,service_cache_valid;wire [31:0] service_cached_page,service_cache_read_data;
wire [1:0] fetch_valid,fetch_ready;wire [63:0] fetch_page_index,fetch_page_address,fetch_proof_address;
reg [2:0] committed_model_owner;
assign service_committed_owner=committed_model_owner;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)committed_model_owner<=0;
 else if(hub_quiescent)committed_model_owner<=service_owner;
end
trusted_model_security_hub_observed u_model(
 .clk(clk),.security_reset_n(security_reset_n),.trusted_cancel(model_cancellation_pending),.trusted_selected_owner(committed_model_owner),
 .page_request(service_page_request),.expected_pages(service_expected_pages),.cache_read(service_cache_read),.cache_addresses(service_cache_addresses),.page_ready(service_page_ready),.read_valid(service_cache_read_valid),
 .cache_valid(service_cache_valid),.cached_page_index(service_cached_page),.cache_read_data(service_cache_read_data),.page_done(service_page_done),.service_busy(service_busy),.service_fault(service_fault),
 .fetch_valid(fetch_valid),.fetch_page_index(fetch_page_index),.fetch_page_address(fetch_page_address),.fetch_proof_address(fetch_proof_address),.fetch_ready(fetch_ready),
 .PS_AWADDR(PS_AWADDR),.PS_AWVALID(PS_AWVALID),.PS_AWREADY(PS_AWREADY),.PS_WDATA(PS_WDATA),.PS_WSTRB(PS_WSTRB),.PS_WVALID(PS_WVALID),.PS_WREADY(PS_WREADY),.PS_BRESP(PS_BRESP),.PS_BVALID(PS_BVALID),.PS_BREADY(PS_BREADY),
 .PS_ARADDR(PS_ARADDR),.PS_ARVALID(PS_ARVALID),.PS_ARREADY(PS_ARREADY),.PS_RDATA(PS_RDATA),.PS_RRESP(PS_RRESP),.PS_RVALID(PS_RVALID),.PS_RREADY(PS_RREADY),
 .raw_model_authorized(raw_model_authorized),.model_epoch(model_epoch),.slh_busy(slh_busy),.feeder_quiescent(feeder_quiescent),.hub_quiescent(hub_quiescent),.hub_fault(hub_fault),
 .observation_page_accept(observation_page_accept),.observation_page_index(observation_page_index),.observation_model_address(observation_model_address),.observation_proof_address(observation_proof_address),.observation_page_input_wait(observation_page_input_wait),
 .model_verification_start(model_verification_start),.feeder_cancelled(feeder_cancelled),.signature_error(signature_error),.policy_error(policy_error),.page_error(page_error),.feeder_error(feeder_error));

wire request_valid,request_ready,request_write,response_verified_valid,response_verified_ready,response_error,guard_context_live,guard_quiescent;
 wire [31:0] request_session,request_frame,request_epoch,request_version,request_address,request_tensor_mask,request_strobe;
 wire [15:0] request_role,request_shape;wire [255:0] request_data,response_data;
wire trusted_go=camera_go;wire trusted_stop=abort_execution;
wire rst_n=security_reset_n;
wire go_ready,active_unused,fault_unused,quiescent_unused;
wire [31:0] job_session,job_frame,job_epoch,job_base;
wire job_cancel,job_valid,job_ready,job_quiescent,job_fault;
wire [31:0] job_done_session,job_done_frame;
wire camera_child_done;
assign camera_go_ready=go_ready;
assign camera_job_valid=job_valid;assign camera_job_session=job_session;assign camera_job_frame=job_frame;assign camera_job_epoch=job_epoch;assign camera_job_base=job_base;
assign job_ready=camera_job_ready;assign camera_job_cancel=job_cancel;
assign job_quiescent=vision_quiescent&&hp_quiet&&shared_mac_quiet;
assign job_fault=stage_fault||hard_fault;
assign job_done_session=record_session;assign job_done_frame=record_frame;
assign camera_child_done=vision_done&&record_visible&&authorized&&key_valid&&!global_fault;
trusted_camera_frame_job_current u_camera(
 .observation_capture_start(observation_capture_start),
 .clk(clk),.rst_n(rst_n),.authorized(authorized),.key_valid(key_valid),.authorization_epoch(authorization_epoch),
 .trusted_go(trusted_go),.trusted_stop(trusted_stop),.go_ready(go_ready),.active(camera_active),.fault(camera_fault),.quiescent(camera_quiescent),
 .packet_valid(packet_valid),.packet_header(packet_header),.packet_release(packet_release),.payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
 .response_valid(response_valid),.response_ready(response_ready),.response_kind(response_kind),.response_flags(response_flags),.response_offset(response_offset),.response_frame_crc(response_frame_crc),.response_session_id(response_session_id),.response_frame_id(response_frame_id),.response_total_bytes(response_total_bytes),.response_width(response_width),.response_height(response_height),
 .job_valid(job_valid),.job_ready(job_ready),.job_session(job_session),.job_frame(job_frame),.job_epoch(job_epoch),.job_base(job_base),.job_done(camera_child_done),.job_done_session(job_done_session),.job_done_frame(job_done_frame),.job_cancel(job_cancel),.job_quiescent(job_quiescent),.job_fault(job_fault),
 .sealed_letterbox_valid(sealed_letterbox_valid),.sealed_session(sealed_session),.sealed_frame(sealed_frame),.sealed_epoch(sealed_epoch),.completed_frames(completed_frames),.rejected_completions(rejected_completions),.committed_offset(committed_offset),.received_crc(received_crc),
 .request_valid(request_valid),.request_ready(request_ready),.request_write(request_write),.request_session(request_session),.request_frame(request_frame),.request_epoch(request_epoch),.request_version(request_version),.request_role(request_role),.request_shape(request_shape),.request_address(request_address),.request_tensor_mask(request_tensor_mask),.request_strobe(request_strobe),.request_data(request_data),
 .response_verified_valid(response_verified_valid),.response_verified_ready(response_verified_ready),.response_error(response_error),.guard_context_live(guard_context_live),.response_data(response_data),.guard_quiescent(camera_guard_quiet));

wire memory_read_valid,memory_read_ready,memory_write_valid,memory_write_ready,memory_response_valid,memory_response_error;
wire [31:0] memory_data_address,memory_tag_address,memory_write_mask,memory_response_mask;
wire [255:0] memory_write_data,memory_response_data;wire [127:0] memory_write_tag,memory_response_tag;
wire mac_request,mac_ready,mac_response_valid,mac_quiescent;wire [127:0] mac_chain,mac_tag;wire [255:0] mac_data;
trusted_yolo_tensor_beat_guard guard(.clk(clk),.rst_n(rst_n),.cancel(abort_execution),.authorized(authorized),.key_valid(key_valid),.authorization_epoch(authorization_epoch),.request_valid(request_valid),.request_ready(request_ready),.request_write(request_write),.request_session(request_session),.request_frame(request_frame),.request_epoch(request_epoch),.request_version(request_version),.request_role(request_role),.request_shape(request_shape),.request_address(request_address),.request_tensor_mask(request_tensor_mask),.request_strobe(request_strobe),.request_data(request_data),.response_valid(response_verified_valid),.response_ready(response_verified_ready),.response_error(response_error),.context_live(guard_context_live),.response_data(response_data),.quiescent(camera_guard_quiet),.memory_read_valid(memory_read_valid),.memory_read_ready(memory_read_ready),.memory_write_valid(memory_write_valid),.memory_write_ready(memory_write_ready),.memory_data_address(memory_data_address),.memory_tag_address(memory_tag_address),.memory_write_data(memory_write_data),.memory_write_tag(memory_write_tag),.memory_write_mask(memory_write_mask),.memory_response_valid(memory_response_valid),.memory_response_error(memory_response_error),.memory_response_data(memory_response_data),.memory_response_tag(memory_response_tag),.memory_response_mask(memory_response_mask),.backend_quiescent(camera_backend_quiet),.mac_request(mac_request),.mac_ready(mac_ready),.mac_chain(mac_chain),.mac_data(mac_data),.mac_response_valid(mac_response_valid),.mac_response_error(cbc_response_error[0]),.mac_tag(mac_tag),.mac_quiescent(mac_quiescent));

wire v_mac_request,v_mac_ready,v_mac_response_valid,v_mac_response_error,v_mac_quiescent;wire [127:0] v_mac_chain,v_mac_tag;wire [255:0] v_mac_data;
trusted_shared_cbc_adapter u_cbc(
 .clk(clk),.security_reset_n(security_reset_n),.trusted_selected_owner(hp_committed_owner),.request({v_mac_request,mac_request}),.chains({v_mac_chain,mac_chain}),.data({v_mac_data,mac_data}),
 .epoch(authorization_epoch),.key(installed_key),.key_valid(key_valid),.authorized(authorized),.cancel(abort_execution),.ready(cbc_ready),.response_valid(cbc_response_valid),.response_error(cbc_response_error),.tag(cbc_tag),.quiescent(shared_mac_quiet),.fault(shared_mac_fault));
assign mac_ready=cbc_ready[0];assign mac_response_valid=cbc_response_valid[0];assign mac_tag=cbc_tag[127:0];assign mac_quiescent=shared_mac_quiet;
assign v_mac_ready=cbc_ready[1];assign v_mac_response_valid=cbc_response_valid[1];assign v_mac_response_error=cbc_response_error[1];assign v_mac_tag=cbc_tag[255:128];assign v_mac_quiescent=shared_mac_quiet;

wire [31:0] c_ARADDR;
wire [7:0] c_ARLEN;
wire [2:0] c_ARSIZE;
wire [1:0] c_ARBURST;
wire c_ARVALID;
wire c_ARREADY;
wire [255:0] c_RDATA;
wire [1:0] c_RRESP;
wire c_RLAST;
wire c_RVALID;
wire c_RREADY;
wire [31:0] c_AWADDR;
wire [7:0] c_AWLEN;
wire [2:0] c_AWSIZE;
wire [1:0] c_AWBURST;
wire c_AWVALID;
wire c_AWREADY;
wire [255:0] c_WDATA;
wire [31:0] c_WSTRB;
wire c_WLAST;
wire c_WVALID;
wire c_WREADY;
wire [1:0] c_BRESP;
wire c_BVALID;
wire c_BREADY;
wire [31:0] v_ARADDR;
wire [7:0] v_ARLEN;
wire [2:0] v_ARSIZE;
wire [1:0] v_ARBURST;
wire v_ARVALID;
wire v_ARREADY;
wire [255:0] v_RDATA;
wire [1:0] v_RRESP;
wire v_RLAST;
wire v_RVALID;
wire v_RREADY;
wire [31:0] v_AWADDR;
wire [7:0] v_AWLEN;
wire [2:0] v_AWSIZE;
wire [1:0] v_AWBURST;
wire v_AWVALID;
wire v_AWREADY;
wire [255:0] v_WDATA;
wire [31:0] v_WSTRB;
wire v_WLAST;
wire v_WVALID;
wire v_WREADY;
wire [1:0] v_BRESP;
wire v_BVALID;
wire v_BREADY;
trusted_tensor_axi_backend u_ingress_backend(
.clk(clk),
.rst_n(security_reset_n),
.read_valid(memory_read_valid),
.read_ready(memory_read_ready),
.write_valid(memory_write_valid),
.write_ready(memory_write_ready),
.data_address(memory_data_address),
.tag_address(memory_tag_address),
.write_data(memory_write_data),
.write_tag(memory_write_tag),
.write_mask(memory_write_mask),
.response_valid(memory_response_valid),
.response_error(memory_response_error),
.response_data(memory_response_data),
.response_tag(memory_response_tag),
.response_mask(memory_response_mask),
.quiescent(camera_backend_quiet),
.M_AXI_ARADDR(c_ARADDR),
.M_AXI_ARLEN(c_ARLEN),
.M_AXI_ARSIZE(c_ARSIZE),
.M_AXI_ARBURST(c_ARBURST),
.M_AXI_ARVALID(c_ARVALID),
.M_AXI_ARREADY(c_ARREADY),
.M_AXI_RDATA(c_RDATA),
.M_AXI_RRESP(c_RRESP),
.M_AXI_RLAST(c_RLAST),
.M_AXI_RVALID(c_RVALID),
.M_AXI_RREADY(c_RREADY),
.M_AXI_AWADDR(c_AWADDR),
.M_AXI_AWLEN(c_AWLEN),
.M_AXI_AWSIZE(c_AWSIZE),
.M_AXI_AWBURST(c_AWBURST),
.M_AXI_AWVALID(c_AWVALID),
.M_AXI_AWREADY(c_AWREADY),
.M_AXI_WDATA(c_WDATA),
.M_AXI_WSTRB(c_WSTRB),
.M_AXI_WLAST(c_WLAST),
.M_AXI_WVALID(c_WVALID),
.M_AXI_WREADY(c_WREADY),
.M_AXI_BRESP(c_BRESP),
.M_AXI_BVALID(c_BVALID),
.M_AXI_BREADY(c_BREADY)
);
wire [1:0] ddr_committed_owner;
wire [1:0] pool_committed_stage;
npu_full_vision_core u_vision(
.clk(clk),
.security_reset_n(security_reset_n),
.arith_reset_n(arith_reset_n),
.authorized(authorized),
.key_valid(key_valid),
.cancel(abort_execution||camera_job_cancel),
.authorization_epoch(authorization_epoch),
.key_session_id(key_session_id),
.job_valid(vision_job_valid),
.job_ready(vision_job_ready),
.job_camera_id(32'd0),
.job_session(camera_job_session),
.job_frame(camera_job_frame),
.job_epoch(camera_job_epoch),
.active(vision_active),
.quiescent(vision_quiescent),
.job_done(vision_done),
.job_failed(vision_failed),
.fault(vision_fault),
.frame_elapsed_cycles(frame_elapsed_cycles),
.record_visible(record_visible),
.record_commit_pulse(record_commit_pulse),
.record_camera(record_camera),
.record_session(record_session),
.record_frame(record_frame),
.record_epoch(record_epoch),
.record_key_session(record_key_session),
.record_count(record_count),
.record_rois(record_rois),
.record_indices(record_indices),
.record_results(record_results),
.service_committed_owner(service_committed_owner),
.service_owner(service_owner),
.service_page_request(service_page_request),
.service_cache_read(service_cache_read),
.service_expected_pages(service_expected_pages),
.service_cache_addresses(service_cache_addresses),
.service_page_ready(service_page_ready),
.service_cache_read_valid(service_cache_read_valid),
.service_page_done(service_page_done),
.service_busy(service_busy),
.service_fault(service_fault),
.service_quiescent(hub_quiescent),
.service_cache_valid(service_cache_valid),
.service_cached_page(service_cached_page),
.service_cache_read_data(service_cache_read_data),
.fetch_valid(fetch_valid),
.fetch_ready(fetch_ready),
.fetch_page_index(fetch_page_index),
.fetch_page_address(fetch_page_address),
.fetch_proof_address(fetch_proof_address),
.mac_request(v_mac_request),
.mac_chain(v_mac_chain),
.mac_data(v_mac_data),
.mac_ready(v_mac_ready),
.mac_response_valid(v_mac_response_valid),
.mac_response_error(v_mac_response_error),
.mac_tag(v_mac_tag),
.mac_quiescent(v_mac_quiescent),
.ddr_committed_owner(ddr_committed_owner),
.pool_committed_stage(pool_committed_stage),
.observation_pool_wait(observation_pool_wait),
.observation_yolo_start(observation_yolo_start),
.observation_yolo_done(observation_yolo_done),
.observation_frontend_start(observation_frontend_start),
.observation_nn_start(observation_nn_start),
.observation_nn_done(observation_nn_done),
.observation_head_start(observation_head_start),
.observation_roi_index(observation_roi_index),
.observation_generation(observation_generation),
.observation_block(observation_block),
.observation_norm3_valid(observation_norm3_valid),
.observation_norm3_done(observation_norm3_done),
.observation_norm3_address(observation_norm3_address),
.observation_norm3_data(observation_norm3_data),
.observation_logit_valid(observation_logit_valid),
.observation_logit_class(observation_logit_class),
.observation_logit_data(observation_logit_data),
.observation_result_valid(observation_result_valid),
.observation_result_class(observation_result_class),
.observation_result_logit(observation_result_logit),
.observation_consumer_session(observation_consumer_session),
.observation_consumer_frame(observation_consumer_frame),
.observation_consumer_epoch(observation_consumer_epoch),
.observation_context_camera(observation_context_camera),
.observation_context_session(observation_context_session),
.observation_context_frame(observation_context_frame),
.observation_context_epoch(observation_context_epoch),
.M_AXI_ARADDR(v_ARADDR),
.M_AXI_ARLEN(v_ARLEN),
.M_AXI_ARSIZE(v_ARSIZE),
.M_AXI_ARBURST(v_ARBURST),
.M_AXI_ARVALID(v_ARVALID),
.M_AXI_ARREADY(v_ARREADY),
.M_AXI_RDATA(v_RDATA),
.M_AXI_RRESP(v_RRESP),
.M_AXI_RLAST(v_RLAST),
.M_AXI_RVALID(v_RVALID),
.M_AXI_RREADY(v_RREADY),
.M_AXI_AWADDR(v_AWADDR),
.M_AXI_AWLEN(v_AWLEN),
.M_AXI_AWSIZE(v_AWSIZE),
.M_AXI_AWBURST(v_AWBURST),
.M_AXI_AWVALID(v_AWVALID),
.M_AXI_AWREADY(v_AWREADY),
.M_AXI_WDATA(v_WDATA),
.M_AXI_WSTRB(v_WSTRB),
.M_AXI_WLAST(v_WLAST),
.M_AXI_WVALID(v_WVALID),
.M_AXI_WREADY(v_WREADY),
.M_AXI_BRESP(v_BRESP),
.M_AXI_BVALID(v_BVALID),
.M_AXI_BREADY(v_BREADY)
);
trusted_stage_axi_mux #(.PORTS(2),.OWNER_W(2)) u_hp_mux(
.clk(clk),
.security_reset_n(security_reset_n),
.desired_owner(desired_hp_owner),
.client_quiescent({vision_quiescent&&shared_mac_quiet,camera_resources_quiet}),
.committed_owner(hp_committed_owner),
.owner_committed(hp_owner_ready),
.quiescent(hp_quiet),
.fault(hp_fault),
.S_ARADDR({v_ARADDR,c_ARADDR}),
.S_ARLEN({v_ARLEN,c_ARLEN}),
.S_ARSIZE({v_ARSIZE,c_ARSIZE}),
.S_ARBURST({v_ARBURST,c_ARBURST}),
.S_ARVALID({v_ARVALID,c_ARVALID}),
.S_ARREADY({v_ARREADY,c_ARREADY}),
.S_RDATA({v_RDATA,c_RDATA}),
.S_RRESP({v_RRESP,c_RRESP}),
.S_RLAST({v_RLAST,c_RLAST}),
.S_RVALID({v_RVALID,c_RVALID}),
.S_RREADY({v_RREADY,c_RREADY}),
.S_AWADDR({v_AWADDR,c_AWADDR}),
.S_AWLEN({v_AWLEN,c_AWLEN}),
.S_AWSIZE({v_AWSIZE,c_AWSIZE}),
.S_AWBURST({v_AWBURST,c_AWBURST}),
.S_AWVALID({v_AWVALID,c_AWVALID}),
.S_AWREADY({v_AWREADY,c_AWREADY}),
.S_WDATA({v_WDATA,c_WDATA}),
.S_WSTRB({v_WSTRB,c_WSTRB}),
.S_WLAST({v_WLAST,c_WLAST}),
.S_WVALID({v_WVALID,c_WVALID}),
.S_WREADY({v_WREADY,c_WREADY}),
.S_BRESP({v_BRESP,c_BRESP}),
.S_BVALID({v_BVALID,c_BVALID}),
.S_BREADY({v_BREADY,c_BREADY}),
.M_ARADDR(M_AXI_ARADDR),
.M_ARLEN(M_AXI_ARLEN),
.M_ARSIZE(M_AXI_ARSIZE),
.M_ARBURST(M_AXI_ARBURST),
.M_ARVALID(M_AXI_ARVALID),
.M_ARREADY(M_AXI_ARREADY),
.M_RDATA(M_AXI_RDATA),
.M_RRESP(M_AXI_RRESP),
.M_RLAST(M_AXI_RLAST),
.M_RVALID(M_AXI_RVALID),
.M_RREADY(M_AXI_RREADY),
.M_AWADDR(M_AXI_AWADDR),
.M_AWLEN(M_AXI_AWLEN),
.M_AWSIZE(M_AXI_AWSIZE),
.M_AWBURST(M_AXI_AWBURST),
.M_AWVALID(M_AXI_AWVALID),
.M_AWREADY(M_AXI_AWREADY),
.M_WDATA(M_AXI_WDATA),
.M_WSTRB(M_AXI_WSTRB),
.M_WLAST(M_AXI_WLAST),
.M_WVALID(M_AXI_WVALID),
.M_WREADY(M_AXI_WREADY),
.M_BRESP(M_AXI_BRESP),
.M_BVALID(M_AXI_BVALID),
.M_BREADY(M_AXI_BREADY)
);
trusted_pipeline_metrics u_metrics(
 .clk(clk),.security_reset_n(security_reset_n),.authorization_live(authorized&&key_valid),
 .frame_start(observation_frame_start),.ingress_done(observation_ingress_done),.yolo_start(observation_yolo_start),.yolo_done(observation_yolo_done),
 .frontend_start(observation_frontend_start),.nn_start(observation_nn_start),.head_start(observation_head_start),.nn_done(observation_nn_done),.roi_index(observation_roi_index),
 .record_commit(record_commit_pulse),.abort(abort_execution),.page_input_wait(observation_page_input_wait),.mac_busy(!shared_mac_quiet),.pool_wait(observation_pool_wait),
 .snapshot_valid(metrics_valid),.measurement_fault(metrics_fault),.total_cycles(metrics_total),.ingress_cycles(metrics_ingress),.yolo_cycles(metrics_yolo),.frontend_cycles(metrics_frontend),.nn_cycles(metrics_nn),.head_cycles(metrics_head),
 .page_input_wait_cycles(metrics_page_input_wait),.mac_busy_cycles(metrics_mac_busy),.pool_wait_cycles(metrics_pool_wait),.roi_measured(metrics_roi_measured),.sequence_id(metrics_sequence));
endmodule

