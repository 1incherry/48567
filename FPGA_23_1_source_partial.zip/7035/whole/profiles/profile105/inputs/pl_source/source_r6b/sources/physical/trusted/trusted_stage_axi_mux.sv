`timescale 1ns/1ps
// Trusted, drain-locked master selection. No PS owner/configuration input.
// accepted AXI offers are NEVER withdrawn because authorization/cancel changes:
// the selected real client drains them, while outer admission closes new jobs.
module trusted_stage_axi_mux #(
 parameter integer PORTS=3,parameter integer OWNER_W=$clog2(PORTS+1)
)(
 input wire clk,security_reset_n,
 input wire [OWNER_W-1:0] desired_owner,
 input wire [PORTS-1:0] client_quiescent,
 output reg [OWNER_W-1:0] committed_owner,
 output wire owner_committed,quiescent,channels_quiescent,output reg fault,
 input wire [PORTS*32-1:0] S_ARADDR,input wire [PORTS*8-1:0] S_ARLEN,
 input wire [PORTS*3-1:0] S_ARSIZE,input wire [PORTS*2-1:0] S_ARBURST,
 input wire [PORTS-1:0] S_ARVALID,output wire [PORTS-1:0] S_ARREADY,
 output wire [PORTS*256-1:0] S_RDATA,output wire [PORTS*2-1:0] S_RRESP,
 output wire [PORTS-1:0] S_RLAST,S_RVALID,input wire [PORTS-1:0] S_RREADY,
 input wire [PORTS*32-1:0] S_AWADDR,input wire [PORTS*8-1:0] S_AWLEN,
 input wire [PORTS*3-1:0] S_AWSIZE,input wire [PORTS*2-1:0] S_AWBURST,
 input wire [PORTS-1:0] S_AWVALID,output wire [PORTS-1:0] S_AWREADY,
 input wire [PORTS*256-1:0] S_WDATA,input wire [PORTS*32-1:0] S_WSTRB,
 input wire [PORTS-1:0] S_WLAST,S_WVALID,output wire [PORTS-1:0] S_WREADY,
 output wire [PORTS*2-1:0] S_BRESP,output wire [PORTS-1:0] S_BVALID,
 input wire [PORTS-1:0] S_BREADY,
 output wire [31:0] M_ARADDR,output wire [7:0] M_ARLEN,
 output wire [2:0] M_ARSIZE,output wire [1:0] M_ARBURST,
 output wire M_ARVALID,input wire M_ARREADY,
 input wire [255:0] M_RDATA,input wire [1:0] M_RRESP,
 input wire M_RLAST,M_RVALID,output wire M_RREADY,
 output wire [31:0] M_AWADDR,output wire [7:0] M_AWLEN,
 output wire [2:0] M_AWSIZE,output wire [1:0] M_AWBURST,
 output wire M_AWVALID,input wire M_AWREADY,
 output wire [255:0] M_WDATA,output wire [31:0] M_WSTRB,
 output wire M_WLAST,M_WVALID,input wire M_WREADY,
 input wire [1:0] M_BRESP,input wire M_BVALID,output wire M_BREADY
);
wire selected_valid=committed_owner!=0&&committed_owner<=PORTS;
wire [OWNER_W-1:0] selected_index=committed_owner-1'b1;
wire [PORTS-1:0] selected_mask=selected_valid?({{(PORTS-1){1'b0}},1'b1}<<selected_index):0;
assign M_ARADDR=selected_valid?S_ARADDR[selected_index*32+:32]:0;
assign M_ARLEN=selected_valid?S_ARLEN[selected_index*8+:8]:0;
assign M_ARSIZE=selected_valid?S_ARSIZE[selected_index*3+:3]:0;
assign M_ARBURST=selected_valid?S_ARBURST[selected_index*2+:2]:0;
assign M_ARVALID=selected_valid&&S_ARVALID[selected_index];
assign M_RREADY=selected_valid&&S_RREADY[selected_index];
assign M_AWADDR=selected_valid?S_AWADDR[selected_index*32+:32]:0;
assign M_AWLEN=selected_valid?S_AWLEN[selected_index*8+:8]:0;
assign M_AWSIZE=selected_valid?S_AWSIZE[selected_index*3+:3]:0;
assign M_AWBURST=selected_valid?S_AWBURST[selected_index*2+:2]:0;
assign M_AWVALID=selected_valid&&S_AWVALID[selected_index];
assign M_WDATA=selected_valid?S_WDATA[selected_index*256+:256]:0;
assign M_WSTRB=selected_valid?S_WSTRB[selected_index*32+:32]:0;
assign M_WLAST=selected_valid&&S_WLAST[selected_index];
assign M_WVALID=selected_valid&&S_WVALID[selected_index];
assign M_BREADY=selected_valid&&S_BREADY[selected_index];
genvar i;generate for(i=0;i<PORTS;i=i+1)begin:RETURN_TO_OWNER
 assign S_ARREADY[i]=selected_mask[i]&&M_ARREADY;
 assign S_RDATA[i*256+:256]=selected_mask[i]?M_RDATA:256'd0;
 assign S_RRESP[i*2+:2]=selected_mask[i]?M_RRESP:2'd0;
 assign S_RLAST[i]=selected_mask[i]&&M_RLAST;
 assign S_RVALID[i]=selected_mask[i]&&M_RVALID;
 assign S_AWREADY[i]=selected_mask[i]&&M_AWREADY;
 assign S_WREADY[i]=selected_mask[i]&&M_WREADY;
 assign S_BRESP[i*2+:2]=selected_mask[i]?M_BRESP:2'd0;
 assign S_BVALID[i]=selected_mask[i]&&M_BVALID;
end endgenerate
wire ar_fire=M_ARVALID&&M_ARREADY;
wire r_fire=M_RVALID&&M_RREADY&&M_RLAST;
wire aw_fire=M_AWVALID&&M_AWREADY;
wire w_fire=M_WVALID&&M_WREADY;
wire wl_fire=w_fire&&M_WLAST;
wire b_fire=M_BVALID&&M_BREADY;
reg [15:0] read_credit,aw_credit,wl_credit;
reg partial_write,previous_activity,quiet_previous;
wire inactive_request=|(S_ARVALID&~selected_mask)|||(S_AWVALID&~selected_mask)|||(S_WVALID&~selected_mask);
wire selected_quiet=selected_valid?client_quiescent[selected_index]:&client_quiescent;
wire channels_quiet=read_credit==0&&aw_credit==0&&wl_credit==0&&!partial_write&&
 !M_ARVALID&&!M_AWVALID&&!M_WVALID&&!M_RVALID&&!M_BVALID&&!previous_activity;
assign channels_quiescent=security_reset_n&&channels_quiet;
assign quiescent=security_reset_n&&selected_quiet&&channels_quiet;
assign owner_committed=security_reset_n&&!fault&&committed_owner==desired_owner;
always @(posedge clk or negedge security_reset_n)begin
 if(!security_reset_n)begin
  committed_owner<=0;fault<=0;read_credit<=0;aw_credit<=0;wl_credit<=0;
  partial_write<=0;previous_activity<=0;quiet_previous<=0;
 end else begin
  previous_activity<=ar_fire||r_fire||aw_fire||w_fire||b_fire;
  quiet_previous<=quiescent;
  if(inactive_request||desired_owner>PORTS)fault<=1;
  // Saturation/underflow are protocol faults, never a counter wrap into quiet.
  case({ar_fire,r_fire})
   2'b10:if(read_credit==16'hffff)fault<=1;else read_credit<=read_credit+1'b1;
   2'b01:if(read_credit==0)fault<=1;else read_credit<=read_credit-1'b1;
  endcase
  case({aw_fire,b_fire})
   2'b10:if(aw_credit==16'hffff)fault<=1;else aw_credit<=aw_credit+1'b1;
   2'b01:if(aw_credit==0)fault<=1;else aw_credit<=aw_credit-1'b1;
  endcase
  case({wl_fire,b_fire})
   2'b10:if(wl_credit==16'hffff)fault<=1;else wl_credit<=wl_credit+1'b1;
   2'b01:if(wl_credit==0)fault<=1;else wl_credit<=wl_credit-1'b1;
  endcase
  if(w_fire)partial_write<=!M_WLAST;
  if(quiescent&&quiet_previous&&!fault&&!inactive_request&&desired_owner<=PORTS)
   committed_owner<=desired_owner;
 end
end
endmodule
