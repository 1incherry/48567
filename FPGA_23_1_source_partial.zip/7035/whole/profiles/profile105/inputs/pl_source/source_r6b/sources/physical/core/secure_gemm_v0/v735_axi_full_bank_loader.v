`timescale 1ns/1ps

module v735_axi_full_bank_loader (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,

    input  wire         cmd_valid,
    output wire         cmd_ready,
    input  wire [7:0]   cmd_dst,
    input  wire [31:0]  cmd_axi_addr,
    input  wire [17:0]  cmd_local_addr,
    input  wire [15:0]  cmd_beats,
    input  wire [7:0]   cmd_burst_len_m1,
    input  wire [1:0]   prefetch_mode,
    input  wire [1:0]   security_mode,
    input  wire [11:0]  prefetch_window_cap,
    input  wire [11:0]  stage_budget_cap,
    input  wire [11:0]  window_guard_words,
    input  wire [31:0]  window_base_addr,
    input  wire [15:0]  window_stride_words,
    input  wire [7:0]   crypto_key_id,
    input  wire [7:0]   prefetch_ahead_beats,
    output reg          busy,
    output reg          done,

    output reg  [31:0]  m_axi_araddr,
    output reg  [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output reg          m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [255:0] m_axi_rdata,
    input  wire         m_axi_rvalid,
    output reg          m_axi_rready,
    input  wire         m_axi_rlast,

    output reg          outproj_a_wr_valid,
    output reg  [11:0]  outproj_a_wr_addr,
    output reg  [255:0] outproj_a_wr_data,
    output reg          outproj_b_wr_valid,
    output reg  [11:0]  outproj_b_wr_addr,
    output reg  [255:0] outproj_b_wr_data,
    output reg          outproj_scale_wr_valid,
    output reg  [7:0]   outproj_scale_wr_addr,
    output reg signed [31:0] outproj_scale_wr_data,
    output reg          outproj_residual_wr_valid,
    output reg  [15:0]  outproj_residual_wr_addr,
    output reg signed [15:0] outproj_residual_wr_data,

    output reg          norm2_scale_wr_valid,
    output reg  [7:0]   norm2_scale_wr_addr,
    output reg signed [31:0] norm2_scale_wr_data,
    output reg          norm2_bias_wr_valid,
    output reg  [7:0]   norm2_bias_wr_addr,
    output reg signed [31:0] norm2_bias_wr_data,

    output reg          fc1_a_wr_valid,
    output reg  [15:0]  fc1_a_wr_addr,
    output reg signed [15:0] fc1_a_wr_data,
    output reg          fc1_b_wr_valid,
    output reg  [17:0]  fc1_b_wr_addr,
    output reg signed [15:0] fc1_b_wr_data,
    output reg          fc1_scale_wr_valid,
    output reg  [9:0]   fc1_scale_wr_addr,
    output reg signed [31:0] fc1_scale_wr_data,

    output reg          gelu_scale_wr_valid,
    output reg signed [31:0] gelu_scale_wr_data,

    output reg          fc2_b_wr_valid,
    output reg  [17:0]  fc2_b_wr_addr,
    output reg signed [15:0] fc2_b_wr_data,
    output reg          fc2_scale_wr_valid,
    output reg  [7:0]   fc2_scale_wr_addr,
    output reg signed [31:0] fc2_scale_wr_data,
    output reg          fc2_add_scale_wr_valid,
    output reg signed [31:0] fc2_add_scale_wr_data,
    output reg          fc2_residual_wr_valid,
    output reg  [15:0]  fc2_residual_wr_addr,
    output reg signed [15:0] fc2_residual_wr_data,

    output reg          norm3_scale_wr_valid,
    output reg  [7:0]   norm3_scale_wr_addr,
    output reg signed [31:0] norm3_scale_wr_data,
    output reg          norm3_bias_wr_valid,
    output reg  [7:0]   norm3_bias_wr_addr,
    output reg signed [31:0] norm3_bias_wr_data,

    output reg          qkt_scale_wr_valid,
    output reg  [15:0]  qkt_scale_wr_addr,
    output reg signed [31:0] qkt_scale_wr_data,
    output reg          av_scale_wr_valid,
    output reg  [15:0]  av_scale_wr_addr,
    output reg signed [31:0] av_scale_wr_data,

    output reg [31:0]   stat_cmds,
    output reg [31:0]   stat_beats,
    output reg [31:0]   stat_items,
    output reg [31:0]   stat_errors,
    output reg [31:0]   stat_cycles,
    output reg [7:0]    stat_active_dst,
    output reg [31:0]   stat_axi_inflight_peak,
    output reg [31:0]   stat_window_errors,
    output reg [31:0]   stat_window_peak_beats,
    output reg [31:0]   stat_last_cmd_faults
);

localparam DST_OUTPROJ_A_TILE   = 8'd8;
localparam DST_QKT_SCALE32      = 8'd6;
localparam DST_AV_SCALE32       = 8'd7;
localparam DST_OUTPROJ_B_TILE   = 8'd9;
localparam DST_OUTPROJ_SCALE32  = 8'd10;
localparam DST_OUTPROJ_RESID16  = 8'd11;
localparam DST_NORM2_SCALE32    = 8'd12;
localparam DST_NORM2_BIAS32     = 8'd13;
localparam DST_FC1_A16          = 8'd14;
localparam DST_FC1_B16          = 8'd15;
localparam DST_FC1_SCALE32      = 8'd16;
localparam DST_GELU_SCALE32     = 8'd17;
localparam DST_FC2_B16          = 8'd18;
localparam DST_FC2_SCALE32      = 8'd19;
localparam DST_FC2_ADD_SCALE32  = 8'd20;
localparam DST_FC2_RESID16      = 8'd21;
localparam DST_NORM3_SCALE32    = 8'd22;
localparam DST_NORM3_BIAS32     = 8'd23;

localparam ST_IDLE = 3'd0;
localparam ST_AR   = 3'd1;
localparam ST_R    = 3'd2;
localparam ST_EMIT = 3'd3;
localparam ST_DONE = 3'd4;

reg [2:0] state;
reg [7:0] active_dst;
reg [31:0] cur_axi_addr;
reg [17:0] cur_local_addr;
reg [15:0] remaining_beats;
reg [8:0] max_burst_beats;
reg [8:0] burst_beats;
reg [8:0] burst_left;
reg [255:0] emit_data;
reg [4:0] emit_idx;
reg emit_is_16;
reg emit_is_32;
reg [31:0] inflight_beats;

wire [12:0] window_cap_with_guard = {1'b0, prefetch_window_cap} + {1'b0, window_guard_words};
wire [17:0] cmd_local_end = cmd_local_addr + {2'd0, cmd_beats};
wire [31:0] cmd_axi_end_addr = cmd_axi_addr + ({16'd0, cmd_beats} << 5);
wire [31:0] allowed_window_end_addr = window_base_addr + ({19'd0, window_cap_with_guard} << 5);
wire [31:0] configured_stride_bytes = {16'd0, window_stride_words} << 2;
wire cmd_beats_over_window = (prefetch_window_cap != 12'd0) &&
                             (cmd_beats > {4'd0, prefetch_window_cap});
wire cmd_local_over_stage = (stage_budget_cap != 12'd0) &&
                            (cmd_local_end > {6'd0, stage_budget_cap});
wire cmd_before_window_base = (window_base_addr != 32'd0) &&
                              (cmd_axi_addr < window_base_addr);
wire cmd_after_window_end = (window_base_addr != 32'd0) &&
                            (prefetch_window_cap != 12'd0) &&
                            (cmd_axi_end_addr > allowed_window_end_addr);
wire cmd_security_key_missing = (security_mode != 2'd0) && (crypto_key_id == 8'd0);
wire cmd_prefetch_disabled = (prefetch_mode == 2'd0);
wire cmd_prefetch_ahead_over_window = (prefetch_window_cap != 12'd0) &&
                                      ({4'd0, prefetch_ahead_beats} > prefetch_window_cap);
wire cmd_stride_too_small = (configured_stride_bytes != 32'd0) &&
                            (configured_stride_bytes < ({16'd0, cmd_beats} << 5));
wire [3:0] cmd_fault_count = {3'd0, cmd_beats_over_window} +
                             {3'd0, cmd_local_over_stage} +
                             {3'd0, cmd_before_window_base} +
                             {3'd0, cmd_after_window_end} +
                             {3'd0, cmd_security_key_missing} +
                             {3'd0, cmd_prefetch_disabled} +
                             {3'd0, cmd_prefetch_ahead_over_window} +
                             {3'd0, cmd_stride_too_small};
wire enforce_window_contract = prefetch_mode[1];
wire reject_cmd_for_contract = enforce_window_contract && (cmd_fault_count != 4'd0);

assign cmd_ready = (state == ST_IDLE);
assign m_axi_arsize = 3'd5;
assign m_axi_arburst = 2'b01;

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        busy <= 1'b0;
        done <= 1'b0;
        m_axi_araddr <= 32'd0;
        m_axi_arlen <= 8'd0;
        m_axi_arvalid <= 1'b0;
        m_axi_rready <= 1'b0;
        active_dst <= 8'd0;
        cur_axi_addr <= 32'd0;
        cur_local_addr <= 18'd0;
        remaining_beats <= 16'd0;
        max_burst_beats <= 9'd1;
        burst_beats <= 9'd0;
        burst_left <= 9'd0;
        emit_data <= 256'd0;
        emit_idx <= 5'd0;
        emit_is_16 <= 1'b0;
        emit_is_32 <= 1'b0;
        inflight_beats <= 32'd0;
        outproj_a_wr_valid <= 1'b0;
        outproj_b_wr_valid <= 1'b0;
        outproj_scale_wr_valid <= 1'b0;
        outproj_residual_wr_valid <= 1'b0;
        norm2_scale_wr_valid <= 1'b0;
        norm2_bias_wr_valid <= 1'b0;
        fc1_a_wr_valid <= 1'b0;
        fc1_b_wr_valid <= 1'b0;
        fc1_scale_wr_valid <= 1'b0;
        gelu_scale_wr_valid <= 1'b0;
        fc2_b_wr_valid <= 1'b0;
        fc2_scale_wr_valid <= 1'b0;
        fc2_add_scale_wr_valid <= 1'b0;
        fc2_residual_wr_valid <= 1'b0;
        norm3_scale_wr_valid <= 1'b0;
        norm3_bias_wr_valid <= 1'b0;
        qkt_scale_wr_valid <= 1'b0;
        av_scale_wr_valid <= 1'b0;
        stat_cmds <= 32'd0;
        stat_beats <= 32'd0;
        stat_items <= 32'd0;
        stat_errors <= 32'd0;
        stat_cycles <= 32'd0;
        stat_active_dst <= 8'd0;
        stat_axi_inflight_peak <= 32'd0;
        stat_window_errors <= 32'd0;
        stat_window_peak_beats <= 32'd0;
        stat_last_cmd_faults <= 32'd0;
    end else begin
        done <= 1'b0;
        outproj_a_wr_valid <= 1'b0;
        outproj_b_wr_valid <= 1'b0;
        outproj_scale_wr_valid <= 1'b0;
        outproj_residual_wr_valid <= 1'b0;
        norm2_scale_wr_valid <= 1'b0;
        norm2_bias_wr_valid <= 1'b0;
        fc1_a_wr_valid <= 1'b0;
        fc1_b_wr_valid <= 1'b0;
        fc1_scale_wr_valid <= 1'b0;
        gelu_scale_wr_valid <= 1'b0;
        fc2_b_wr_valid <= 1'b0;
        fc2_scale_wr_valid <= 1'b0;
        fc2_add_scale_wr_valid <= 1'b0;
        fc2_residual_wr_valid <= 1'b0;
        norm3_scale_wr_valid <= 1'b0;
        norm3_bias_wr_valid <= 1'b0;
        qkt_scale_wr_valid <= 1'b0;
        av_scale_wr_valid <= 1'b0;

        if (busy)
            stat_cycles <= stat_cycles + 1'b1;

        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            m_axi_arvalid <= 1'b0;
            m_axi_rready <= 1'b0;
            stat_cmds <= 32'd0;
            stat_beats <= 32'd0;
            stat_items <= 32'd0;
            stat_errors <= 32'd0;
            stat_cycles <= 32'd0;
            stat_axi_inflight_peak <= 32'd0;
            stat_window_errors <= 32'd0;
            stat_window_peak_beats <= 32'd0;
            stat_last_cmd_faults <= 32'd0;
        end else if (state == ST_IDLE) begin
            busy <= 1'b0;
            m_axi_arvalid <= 1'b0;
            m_axi_rready <= 1'b0;
            if (cmd_valid) begin
                busy <= 1'b1;
                active_dst <= cmd_dst;
                stat_active_dst <= cmd_dst;
                cur_axi_addr <= cmd_axi_addr;
                cur_local_addr <= cmd_local_addr;
                remaining_beats <= cmd_beats;
                max_burst_beats <= {1'b0, cmd_burst_len_m1} + 9'd1;
                stat_cmds <= stat_cmds + 1'b1;
                stat_last_cmd_faults <= enforce_window_contract ? {28'd0, cmd_fault_count} : 32'd0;
                if (enforce_window_contract && (cmd_fault_count != 4'd0)) begin
                    stat_errors <= stat_errors + {28'd0, cmd_fault_count};
                    stat_window_errors <= stat_window_errors + {28'd0, cmd_fault_count};
                end
                if ({16'd0, cmd_beats} > stat_window_peak_beats)
                    stat_window_peak_beats <= {16'd0, cmd_beats};
                if (reject_cmd_for_contract)
                    state <= ST_DONE;
                else if (cmd_beats == 16'd0)
                    state <= ST_DONE;
                else
                    state <= ST_AR;
            end
        end else if (state == ST_AR) begin
            busy <= 1'b1;
            if (!m_axi_arvalid) begin
                m_axi_araddr <= cur_axi_addr;
                if (remaining_beats > {7'd0, max_burst_beats})
                    burst_beats <= max_burst_beats;
                else
                    burst_beats <= remaining_beats[8:0];
                if (remaining_beats > {7'd0, max_burst_beats})
                    m_axi_arlen <= max_burst_beats[7:0] - 1'b1;
                else
                    m_axi_arlen <= remaining_beats[7:0] - 1'b1;
                m_axi_arvalid <= 1'b1;
            end
            if (m_axi_arvalid && m_axi_arready) begin
                m_axi_arvalid <= 1'b0;
                m_axi_rready <= 1'b1;
                burst_left <= burst_beats;
                inflight_beats <= {23'd0, burst_beats};
                if ({23'd0, burst_beats} > stat_axi_inflight_peak)
                    stat_axi_inflight_peak <= {23'd0, burst_beats};
                state <= ST_R;
            end
        end else if (state == ST_R) begin
            busy <= 1'b1;
            m_axi_rready <= 1'b1;
            // AXI payload and local-bank side effects advance only on the
            // channel handshake, never from VALID alone.
            if (m_axi_rvalid && m_axi_rready) begin
                stat_beats <= stat_beats + 1'b1;
                emit_data <= m_axi_rdata;
                emit_idx <= 5'd0;
                emit_is_16 <= (active_dst == DST_OUTPROJ_RESID16) ||
                              (active_dst == DST_FC1_A16) ||
                              (active_dst == DST_FC1_B16) ||
                              (active_dst == DST_FC2_B16) ||
                              (active_dst == DST_FC2_RESID16);
                emit_is_32 <= (active_dst == DST_OUTPROJ_SCALE32) ||
                              (active_dst == DST_QKT_SCALE32) ||
                              (active_dst == DST_AV_SCALE32) ||
                              (active_dst == DST_NORM2_SCALE32) ||
                              (active_dst == DST_NORM2_BIAS32) ||
                              (active_dst == DST_FC1_SCALE32) ||
                              (active_dst == DST_GELU_SCALE32) ||
                              (active_dst == DST_FC2_SCALE32) ||
                              (active_dst == DST_FC2_ADD_SCALE32) ||
                              (active_dst == DST_NORM3_SCALE32) ||
                              (active_dst == DST_NORM3_BIAS32);

                if (active_dst == DST_OUTPROJ_A_TILE) begin
                    outproj_a_wr_valid <= 1'b1;
                    outproj_a_wr_addr <= cur_local_addr[11:0];
                    outproj_a_wr_data <= m_axi_rdata;
                    stat_items <= stat_items + 1'b1;
                end else if (active_dst == DST_OUTPROJ_B_TILE) begin
                    outproj_b_wr_valid <= 1'b1;
                    outproj_b_wr_addr <= cur_local_addr[11:0];
                    outproj_b_wr_data <= m_axi_rdata;
                    stat_items <= stat_items + 1'b1;
                end

                cur_axi_addr <= cur_axi_addr + 32'd32;
                cur_local_addr <= cur_local_addr + 1'b1;
                remaining_beats <= remaining_beats - 1'b1;
                burst_left <= burst_left - 1'b1;
                if (inflight_beats != 32'd0)
                    inflight_beats <= inflight_beats - 1'b1;

                if ((active_dst == DST_OUTPROJ_A_TILE) || (active_dst == DST_OUTPROJ_B_TILE)) begin
                    if ((burst_left == 9'd1) || m_axi_rlast) begin
                        m_axi_rready <= 1'b0;
                        if (remaining_beats == 16'd1)
                            state <= ST_DONE;
                        else
                            state <= ST_AR;
                    end
                end else begin
                    m_axi_rready <= 1'b0;
                    state <= ST_EMIT;
                end
            end
        end else if (state == ST_EMIT) begin
            busy <= 1'b1;
            if (emit_is_16) begin
                if (active_dst == DST_OUTPROJ_RESID16) begin
                    outproj_residual_wr_valid <= 1'b1;
                    outproj_residual_wr_addr <= ((cur_local_addr - 1'b1) << 4) + emit_idx[3:0];
                    outproj_residual_wr_data <= emit_data[255 - emit_idx*16 -: 16];
                end else if (active_dst == DST_FC1_A16) begin
                    fc1_a_wr_valid <= 1'b1;
                    fc1_a_wr_addr <= ((cur_local_addr - 1'b1) << 4) + emit_idx[3:0];
                    fc1_a_wr_data <= emit_data[255 - emit_idx*16 -: 16];
                end else if (active_dst == DST_FC1_B16) begin
                    fc1_b_wr_valid <= 1'b1;
                    fc1_b_wr_addr <= ((cur_local_addr - 1'b1) << 4) + emit_idx[3:0];
                    fc1_b_wr_data <= emit_data[255 - emit_idx*16 -: 16];
                end else if (active_dst == DST_FC2_B16) begin
                    fc2_b_wr_valid <= 1'b1;
                    fc2_b_wr_addr <= ((cur_local_addr - 1'b1) << 4) + emit_idx[3:0];
                    fc2_b_wr_data <= emit_data[255 - emit_idx*16 -: 16];
                end else if (active_dst == DST_FC2_RESID16) begin
                    fc2_residual_wr_valid <= 1'b1;
                    fc2_residual_wr_addr <= ((cur_local_addr - 1'b1) << 4) + emit_idx[3:0];
                    fc2_residual_wr_data <= emit_data[255 - emit_idx*16 -: 16];
                end else begin
                    stat_errors <= stat_errors + 1'b1;
                end
                stat_items <= stat_items + 1'b1;
                if (emit_idx == 5'd15)
                    state <= ((remaining_beats == 16'd0) ? ST_DONE : ST_AR);
                else
                    emit_idx <= emit_idx + 1'b1;
            end else if (emit_is_32) begin
                if (active_dst == DST_OUTPROJ_SCALE32) begin
                    outproj_scale_wr_valid <= 1'b1;
                    outproj_scale_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    outproj_scale_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_QKT_SCALE32) begin
                    qkt_scale_wr_valid <= 1'b1;
                    qkt_scale_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    qkt_scale_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_AV_SCALE32) begin
                    av_scale_wr_valid <= 1'b1;
                    av_scale_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    av_scale_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_NORM2_SCALE32) begin
                    norm2_scale_wr_valid <= 1'b1;
                    norm2_scale_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    norm2_scale_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_NORM2_BIAS32) begin
                    norm2_bias_wr_valid <= 1'b1;
                    norm2_bias_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    norm2_bias_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_FC1_SCALE32) begin
                    fc1_scale_wr_valid <= 1'b1;
                    fc1_scale_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    fc1_scale_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_GELU_SCALE32) begin
                    if (emit_idx == 5'd0) begin
                        gelu_scale_wr_valid <= 1'b1;
                        gelu_scale_wr_data <= emit_data[255:224];
                    end
                end else if (active_dst == DST_FC2_SCALE32) begin
                    fc2_scale_wr_valid <= 1'b1;
                    fc2_scale_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    fc2_scale_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_FC2_ADD_SCALE32) begin
                    if (emit_idx == 5'd0) begin
                        fc2_add_scale_wr_valid <= 1'b1;
                        fc2_add_scale_wr_data <= emit_data[255:224];
                    end
                end else if (active_dst == DST_NORM3_SCALE32) begin
                    norm3_scale_wr_valid <= 1'b1;
                    norm3_scale_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    norm3_scale_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else if (active_dst == DST_NORM3_BIAS32) begin
                    norm3_bias_wr_valid <= 1'b1;
                    norm3_bias_wr_addr <= ((cur_local_addr - 1'b1) << 3) + emit_idx[2:0];
                    norm3_bias_wr_data <= emit_data[255 - emit_idx*32 -: 32];
                end else begin
                    stat_errors <= stat_errors + 1'b1;
                end
                stat_items <= stat_items + 1'b1;
                if (emit_idx == 5'd7)
                    state <= ((remaining_beats == 16'd0) ? ST_DONE : ST_AR);
                else
                    emit_idx <= emit_idx + 1'b1;
            end else begin
                stat_errors <= stat_errors + 1'b1;
                state <= ((remaining_beats == 16'd0) ? ST_DONE : ST_AR);
            end
        end else begin
            busy <= 1'b0;
            done <= 1'b1;
            state <= ST_IDLE;
        end
    end
end

endmodule
