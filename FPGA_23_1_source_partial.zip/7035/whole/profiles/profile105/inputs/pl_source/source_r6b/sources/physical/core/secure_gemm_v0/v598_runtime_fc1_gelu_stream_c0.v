`timescale 1ns/1ps

module v598_runtime_fc1_gelu_stream_c0 #(
    parameter INPUT_MEM = "",
    parameter MAX_MEM = "",
    parameter EXP_MEM = "",
    parameter RAW_MEM = "",
    parameter GELU_MEM = "",
    parameter SCALE_MEM = "",
    parameter signed [31:0] CONSTANT_X0 = -32'sd6
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire in_wr_valid,
    input  wire [17:0] in_wr_addr,
    input  wire signed [7:0] in_wr_data,
    input  wire scale_wr_valid,
    input  wire signed [31:0] scale_wr_data,
    input  wire signed [31:0] constant_x0,
    input  wire start,
    output reg  busy,
    output reg  done,
    output reg [31:0] stat_input_writes,
    output reg [31:0] stat_input_errors,
    output reg [31:0] stat_rows,
    output reg [31:0] stat_items,
    output reg [31:0] stat_max_errors,
    output reg [31:0] stat_exp_errors,
    output reg [31:0] stat_gelu_errors,
    output reg        out_valid,
    output reg [17:0] out_addr,
    output reg signed [7:0] out_data,
    input  wire       out_ready,
    output reg [31:0] stat_stream_items
);

localparam SEQ = 256;
localparam DIM = 768;
localparam COUNT = SEQ * DIM;
localparam signed [31:0] MIN_EXP_X = -32'sd138;

localparam ST_IDLE        = 5'd0;
localparam ST_ROW_INIT    = 5'd1;
localparam ST_FIND_MAX    = 5'd2;
localparam ST_EXP_PREP    = 5'd3;
localparam ST_EXP_AFFINE  = 5'd4;
localparam ST_EXP_QR      = 5'd5;
localparam ST_EXP_OUT     = 5'd6;
localparam ST_ELEM_LOAD   = 5'd7;
localparam ST_GELU_FACTOR = 5'd8;
localparam ST_GELU_RAW    = 5'd9;
localparam ST_GELU_SCALE  = 5'd10;
localparam ST_GELU_CLIP   = 5'd11;
localparam ST_GELU_CHECK  = 5'd12;
localparam ST_NEXT_ROW    = 5'd13;
localparam ST_DONE        = 5'd14;
localparam ST_FIND_MAX_WAIT = 5'd15;
localparam ST_ELEM_WAIT     = 5'd16;
localparam ST_FIND_MAX_CAPTURE = 5'd17;
localparam ST_ELEM_CAPTURE     = 5'd18;
localparam ST_EXP_DIV          = 5'd19;
localparam ST_GELU_FACTOR_DIV  = 5'd20;

reg [4:0] state;
reg [7:0] row;
reg [9:0] col;
reg exp_mode;

reg signed [31:0] max_r;
reg signed [31:0] x_r;
reg signed [31:0] pre_x_r;
reg signed [31:0] exp_x_r;
reg signed [31:0] exp_affine_r;
reg signed [31:0] exp_q_r;
reg signed [31:0] exp_r_r;
reg signed [31:0] exp_value_r;
reg signed [31:0] exp_max_r;
reg signed [31:0] exp_sum_r;
reg signed [31:0] factor_r;
reg signed [31:0] sigmoid_r;
reg signed [63:0] raw_r;
reg signed [63:0] quant_wide_r;
reg signed [7:0] quant_r;
reg signed [31:0] min_exp_x_r;
reg signed [31:0] scale_r;
reg input_rd_en;
reg [17:0] input_rd_addr;
wire [7:0] input_rd_data_u;
wire signed [7:0] input_rd_data_s = $signed(input_rd_data_u);
wire input_wr_ok_i = in_wr_valid && (in_wr_addr < COUNT[17:0]);

// Runtime GELU divisions use the validated radix-16 divider instead of
// inferring a large combinational '/' operator.  One transaction returns both
// quotient and remainder for the exp-affine step; a second transaction
// computes the reciprocal factor.
wire signed [31:0] exp_affine_clamped_w =
    (exp_affine_r < min_exp_x_r) ? min_exp_x_r : exp_affine_r;
wire signed [31:0] gelu_factor_den_w = exp_value_r + exp_max_r;
// Exact modulo-2^32 rewrite of multiplication by the positive power-of-two
// factor (8388608 >>> q). No state, output cycle, cancellation or port change.
wire signed [31:0] exp_power2_base_w = (exp_r_r >>> 1) - constant_x0;
wire [4:0] exp_power2_shift_w = 5'd23 - exp_q_r[4:0];
wire signed [31:0] exp_power2_value_w =
    ((exp_q_r[31:5] == 27'd0) && (exp_q_r[4:0] <= 5'd23)) ?
    (exp_power2_base_w <<< exp_power2_shift_w) : 32'sd0;

wire r16_start_valid_w =
    ((state == ST_EXP_QR) && (constant_x0 != 32'sd0)) ||
    ((state == ST_GELU_FACTOR) && (gelu_factor_den_w > 32'sd0));
wire r16_start_ready_w;
wire r16_finish_valid_w;
wire [31:0] r16_quotient_w;
wire [31:0] r16_remainder_w;
wire r16_divisor_zero_w;
wire r16_signed_w = (state == ST_EXP_QR);
wire [31:0] r16_dividend_w =
    (state == ST_GELU_FACTOR) ? 32'd2147483647 : exp_affine_clamped_w;
wire [31:0] r16_divisor_w =
    (state == ST_GELU_FACTOR) ? gelu_factor_den_w : constant_x0;

intdiv_r16_plus #(.D_W(32)) u_gelu_r16_divider (
    .start_valid_i(r16_start_valid_w),
    .start_ready_o(r16_start_ready_w),
    .flush_i(clear),
    .signed_op_i(r16_signed_w),
    .dividend_i(r16_dividend_w),
    .divisor_i(r16_divisor_w),
    .finish_valid_o(r16_finish_valid_w),
    .finish_ready_i(1'b1),
    .quotient_o(r16_quotient_w),
    .remainder_o(r16_remainder_w),
    .divisor_is_zero_o(r16_divisor_zero_w),
    .clk(clk),
    .rst_n(rst_n)
);

v714_bram_sdp_sync #(
    .DATA_W(8),
    .ADDR_W(18),
    .DEPTH(COUNT),
    .FIT_MAX_DEPTH(COUNT)
) u_input_mem (
    .clk(clk),
    .wr_en(input_wr_ok_i),
    .wr_addr(in_wr_addr),
    .wr_data(in_wr_data),
    .rd_en(input_rd_en),
    .rd_addr(input_rd_addr),
    .rd_data(input_rd_data_u)
);

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        row <= 8'd0;
        col <= 10'd0;
        exp_mode <= 1'b0;
        max_r <= -32'sd2147483648;
        x_r <= 32'sd0;
        pre_x_r <= 32'sd0;
        exp_x_r <= 32'sd0;
        exp_affine_r <= 32'sd0;
        exp_q_r <= 32'sd0;
        exp_r_r <= 32'sd0;
        exp_value_r <= 32'sd0;
        exp_max_r <= 32'sd0;
        exp_sum_r <= 32'sd0;
        factor_r <= 32'sd0;
        sigmoid_r <= 32'sd0;
        raw_r <= 64'sd0;
        quant_wide_r <= 64'sd0;
        quant_r <= 8'sd0;
        min_exp_x_r <= -32'sd138;
        scale_r <= 32'sd0;
        input_rd_en <= 1'b0;
        input_rd_addr <= 18'd0;
        busy <= 1'b0;
        done <= 1'b0;
        stat_input_writes <= 32'd0;
        stat_input_errors <= 32'd0;
        stat_rows <= 32'd0;
        stat_items <= 32'd0;
        stat_max_errors <= 32'd0;
        stat_exp_errors <= 32'd0;
        stat_gelu_errors <= 32'd0;
        out_valid <= 1'b0;
        out_addr <= 18'd0;
        out_data <= 8'sd0;
        stat_stream_items <= 32'd0;
    end else begin
        done <= 1'b0;
        out_valid <= 1'b0;
        input_rd_en <= 1'b0;
        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            stat_input_writes <= 32'd0;
            stat_input_errors <= 32'd0;
            stat_rows <= 32'd0;
            stat_items <= 32'd0;
            stat_max_errors <= 32'd0;
            stat_exp_errors <= 32'd0;
            stat_gelu_errors <= 32'd0;
            stat_stream_items <= 32'd0;
        end else begin
            if (in_wr_valid) begin
                if (in_wr_addr < COUNT[17:0]) begin
                    stat_input_writes <= stat_input_writes + 1'b1;
                end else begin
                    stat_input_errors <= stat_input_errors + 1'b1;
                end
            end

            if (scale_wr_valid)
                scale_r <= scale_wr_data;

            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        row <= 8'd0;
                        col <= 10'd0;
                        stat_rows <= 32'd0;
                        stat_items <= 32'd0;
                        stat_max_errors <= 32'd0;
                        stat_exp_errors <= 32'd0;
                        stat_gelu_errors <= 32'd0;
                        stat_stream_items <= 32'd0;
                        min_exp_x_r <= (constant_x0 <<< 4) + (constant_x0 <<< 3) - constant_x0;
                        state <= ST_ROW_INIT;
                    end
                end

                ST_ROW_INIT: begin
                    col <= 10'd0;
                    max_r <= -32'sd2147483648;
                    state <= ST_FIND_MAX;
                end

                ST_FIND_MAX: begin
                    input_rd_en <= 1'b1;
                    input_rd_addr <= row * DIM + col;
                    state <= ST_FIND_MAX_WAIT;
                end

                ST_FIND_MAX_WAIT: begin
                    state <= ST_FIND_MAX_CAPTURE;
                end

                ST_FIND_MAX_CAPTURE: begin
                    if (input_rd_data_s > max_r)
                        max_r <= input_rd_data_s;
                    if (col == DIM - 1) begin
                        max_r <= (input_rd_data_s > max_r ? input_rd_data_s : max_r);
                        exp_mode <= 1'b0;
                        exp_x_r <= -1 * (input_rd_data_s > max_r ? input_rd_data_s : max_r);
                        state <= ST_EXP_PREP;
                    end else begin
                        col <= col + 1'b1;
                        state <= ST_FIND_MAX;
                    end
                end

                ST_EXP_PREP: begin
                    state <= ST_EXP_AFFINE;
                end

                ST_EXP_AFFINE: begin
                    exp_affine_r <= exp_x_r + (exp_x_r >>> 1) - (exp_x_r >>> 4);
                    state <= ST_EXP_QR;
                end

                ST_EXP_QR: begin
                    if (exp_affine_r < min_exp_x_r)
                        exp_affine_r <= min_exp_x_r;
                    if (constant_x0 == 32'sd0) begin
                        exp_q_r <= 32'sd0;
                        exp_r_r <= exp_affine_clamped_w;
                        stat_exp_errors <= stat_exp_errors + 1'b1;
                        state <= ST_EXP_OUT;
                    end else if (r16_start_ready_w) begin
                        state <= ST_EXP_DIV;
                    end
                end

                ST_EXP_DIV: begin
                    if (r16_finish_valid_w) begin
                        exp_q_r <= $signed(r16_quotient_w);
                        exp_r_r <= $signed(r16_remainder_w);
                        if (r16_divisor_zero_w)
                            stat_exp_errors <= stat_exp_errors + 1'b1;
                        state <= ST_EXP_OUT;
                    end
                end

                ST_EXP_OUT: begin
                    exp_value_r <= exp_power2_value_w;
                    if (exp_power2_value_w < 0)
                        exp_value_r <= 32'sd0;
                    if (!exp_mode) begin
                        exp_max_r <= (exp_power2_value_w < 0) ?
                                      32'sd0 :
                                      exp_power2_value_w;
                        col <= 10'd0;
                        state <= ST_ELEM_LOAD;
                    end else begin
                        state <= ST_GELU_FACTOR;
                    end
                end

                ST_ELEM_LOAD: begin
                    input_rd_en <= 1'b1;
                    input_rd_addr <= row * DIM + col;
                    state <= ST_ELEM_WAIT;
                end

                ST_ELEM_WAIT: begin
                    state <= ST_ELEM_CAPTURE;
                end

                ST_ELEM_CAPTURE: begin
                    x_r <= input_rd_data_s;
                    pre_x_r <= input_rd_data_s;
                    exp_x_r <= input_rd_data_s - max_r;
                    exp_mode <= 1'b1;
                    state <= ST_EXP_PREP;
                end

                ST_GELU_FACTOR: begin
                    exp_sum_r <= gelu_factor_den_w;
                    if (gelu_factor_den_w <= 0)
                        factor_r <= 32'sd0;
                    else if (r16_start_ready_w)
                        state <= ST_GELU_FACTOR_DIV;
                end

                ST_GELU_FACTOR_DIV: begin
                    if (r16_finish_valid_w) begin
                        factor_r <= $signed(r16_quotient_w);
                        if (r16_divisor_zero_w)
                            stat_gelu_errors <= stat_gelu_errors + 1'b1;
                        state <= ST_GELU_RAW;
                    end
                end

                ST_GELU_RAW: begin
                    sigmoid_r <= (exp_value_r * factor_r) >>> 24;
                    raw_r <= pre_x_r * ((exp_value_r * factor_r) >>> 24);
                    state <= ST_GELU_SCALE;
                end

                ST_GELU_SCALE: begin
                    quant_wide_r <= (raw_r * scale_r) >>> 29;
                    state <= ST_GELU_CLIP;
                end

                ST_GELU_CLIP: begin
                    if (quant_wide_r > 64'sd127)
                        quant_r <= 8'sh7f;
                    else if (quant_wide_r < -64'sd128)
                        quant_r <= 8'sh80;
                    else
                        quant_r <= quant_wide_r[7:0];
                    state <= ST_GELU_CHECK;
                end

                ST_GELU_CHECK: begin
                    if (out_ready) begin
                        stat_items <= stat_items + 1'b1;
                        out_valid <= 1'b1;
                        out_addr <= row * DIM + col;
                        out_data <= quant_r;
                        stat_stream_items <= stat_stream_items + 1'b1;
                        if (col == DIM - 1) begin
                            state <= ST_NEXT_ROW;
                        end else begin
                            col <= col + 1'b1;
                            state <= ST_ELEM_LOAD;
                        end
                    end
                end

                ST_NEXT_ROW: begin
                    stat_rows <= stat_rows + 1'b1;
                    if (row == SEQ - 1) begin
                        state <= ST_DONE;
                    end else begin
                        row <= row + 1'b1;
                        state <= ST_ROW_INIT;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule
