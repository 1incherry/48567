`timescale 1ns/1ps
// Independent restoring implementation of the existing divider handshake.
// No production replacement. Two selected consumers tie signed_op_i=0.
// Additional signed support is tested, not used to weaken that premise.
// Invalid quotient/remainder are unspecified, as in the original module.
// Original public zero-flag pre_0 temporary value is retained deliberately.
module intdiv_restoring_compat #(parameter D_W=32)(
 input wire start_valid_i,output wire start_ready_o,input wire flush_i,signed_op_i,
 input wire [D_W-1:0] dividend_i,divisor_i,
 output wire finish_valid_o,input wire finish_ready_i,
 output wire [D_W-1:0] quotient_o,remainder_o,output reg divisor_is_zero_o,
 input wire clk,rst_n
);
 localparam IDLE=0,PRE=1,RUN=2,POST=3;
 localparam C_W=$clog2(D_W);
 reg [1:0] state,next_state;
 reg [D_W-1:0] original_n,n_shift,d_abs,q_work,q_result,r_result;
 reg [D_W:0] rem_work;
 reg [C_W-1:0] bit_index;
 reg q_negative,r_negative;
 wire n_sign=signed_op_i&&dividend_i[D_W-1];
 wire d_sign=signed_op_i&&divisor_i[D_W-1];
 wire [D_W:0] shifted={rem_work[D_W-1:0],n_shift[D_W-1]};
 wire take=shifted>={1'b0,d_abs};
 wire [D_W:0] next_rem=take?shifted-{1'b0,d_abs}:shifted;
 wire [D_W-1:0] next_quot={q_work[D_W-2:0],take};
 assign start_ready_o=state==IDLE;
 assign finish_valid_o=state==POST;
 assign quotient_o=q_result;
 assign remainder_o=r_result;
 always @*begin
  next_state=state;
  case(state)
   IDLE:if(start_valid_i)next_state=PRE;
   PRE:next_state=d_abs==0?POST:RUN;
   RUN:if(bit_index==0)next_state=POST;
   POST:if(finish_ready_i)next_state=IDLE;
   default:next_state=IDLE;
  endcase
  if(flush_i)next_state=IDLE;
 end
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)state<=IDLE;else state<=next_state;
 end
 // Like the actual SRT reference, only the FSM has an asynchronous reset.
 // Data is never a completion without POST. A flush cancels even start/LAST.
 always @(posedge clk)begin
  if(start_valid_i&&start_ready_o)begin
   original_n<=dividend_i;
   n_shift<=n_sign?(~dividend_i+1'b1):dividend_i;
   d_abs<=d_sign?(~divisor_i+1'b1):divisor_i;
   q_negative<=n_sign^d_sign;r_negative<=n_sign;
   q_work<=0;rem_work<=0;bit_index<=D_W-1;
   divisor_is_zero_o<=~divisor_i[D_W-2];
  end else if(state==PRE)divisor_is_zero_o<=d_abs==0;
  if(state==PRE&&d_abs==0)begin q_result<={D_W{1'b1}};r_result<=original_n;end
  if(state==RUN)begin
   rem_work<=next_rem;n_shift<=n_shift<<1;q_work<=next_quot;
   if(bit_index!=0)bit_index<=bit_index-1'b1;
   if(bit_index==0)begin
    q_result<=q_negative?(~next_quot+1'b1):next_quot;
    r_result<=r_negative?(~next_rem[D_W-1:0]+1'b1):next_rem[D_W-1:0];
   end
  end
 end
endmodule
