`timescale 1ns/1ps
// Owns the NPU's private AXI-Lite bus. PS may request a fresh frame task but
// cannot supply microcode, descriptors, expected objects, or completion flags.
// model_authorized, seed_ready, frame metadata and head results are trusted PL
// signals; never mirror CPU-controlled registers onto these ports.
module npu_trusted_vit_sequence #(
 parameter PROGRAM_FILE="trusted_vit_code.mem",
 parameter ARGUMENT_FILE="trusted_vit_args.mem",
 parameter integer PROGRAM_WORDS=8192,
 parameter [31:0] TASK_TIMEOUT_CYCLES=32'd2000000000
)(input wire clk,rst_n,
 input wire request_valid,output wire request_ready,output reg request_rejected,
 input wire model_authorized,input wire [31:0] session_epoch,
 input wire seed_ready,input wire [7:0] trusted_camera_id,input wire [31:0] trusted_frame_id,
 input wire [31:0] trusted_roi_index,trusted_context_generation,trusted_session_id,
 input wire hardware_fault,
 input wire handoff_ready,head_result_valid,input wire [31:0] head_result_epoch,
 input wire [7:0] head_class_index,input wire signed [63:0] head_best_logit,
 output wire busy,output reg done,fault,output reg [7:0] error_code,
 output reg trusted_cancel,handoff_start,classification_start,
 output reg signed [31:0] handoff_pose_coefficient,
 output wire private_reads_phase,capture_pose,capture_norm,classification_capture,
 output wire [1:0] service_phase,
 output reg [8:0] expected_object,
 output reg [3:0] expected_kind,expected_block,expected_qkv_op,
 output reg [4:0] expected_dst,expected_stage,
 output reg [3:0] current_block,output reg [11:0] completed_blocks,
 output wire result_valid,output reg [7:0] result_class,result_camera,
 output reg signed [63:0] result_best_logit,
 output reg [31:0] result_frame,result_epoch,result_sequence,
 output reg [31:0] result_roi_index,result_context_generation,result_session,
 output reg [63:0] result_cycle,
 output wire [15:0] debug_pc,
 output wire [7:0] m_awaddr,output wire m_awvalid,input wire m_awready,
 output wire [31:0] m_wdata,output wire [3:0] m_wstrb,output wire m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output wire [7:0] m_araddr,output wire m_arvalid,input wire m_arready,
 input wire [31:0] m_rdata,input wire [1:0] m_rresp,input wire m_rvalid,output wire m_rready
);
 localparam IDLE=0,FETCH=1,DECODE=2,WRITE_BUS=3,READ_BUS=4,SIDE_WAIT=5,FINISHED=6,FAILED=7,LOOKUP=8;
 (* rom_style="block" *) reg [14:0] program_rom[0:PROGRAM_WORDS-1];
 (* rom_style="block" *) reg [31:0] argument_rom[0:828];
 initial $readmemh(ARGUMENT_FILE,argument_rom);
 reg [14:0] code_word;
 function automatic [11:0] prefix_value(input [4:0] index);
  begin case(index)
   5'd0:prefix_value=12'h000;
   5'd1:prefix_value=12'h004;
   5'd2:prefix_value=12'h008;
   5'd3:prefix_value=12'h00c;
   5'd4:prefix_value=12'h010;
   5'd5:prefix_value=12'h014;
   5'd6:prefix_value=12'h018;
   5'd7:prefix_value=12'h01c;
   5'd8:prefix_value=12'h020;
   5'd9:prefix_value=12'h024;
   5'd10:prefix_value=12'h028;
   5'd11:prefix_value=12'h02c;
   5'd12:prefix_value=12'h030;
   5'd13:prefix_value=12'h0b4;
   5'd14:prefix_value=12'h1b4;
   5'd15:prefix_value=12'h1b8;
   5'd16:prefix_value=12'h200;
   5'd17:prefix_value=12'h300;
   5'd18:prefix_value=12'h400;
   5'd19:prefix_value=12'h500;
   5'd20:prefix_value=12'h600;
   5'd21:prefix_value=12'h700;
   5'd22:prefix_value=12'h8bc;
   5'd23:prefix_value=12'h900;
   5'd24:prefix_value=12'ha00;
   default:prefix_value=12'hfff;
  endcase end
 endfunction
 initial $readmemh(PROGRAM_FILE,program_rom);
 reg [3:0] state;reg [2:0] read_kind;
 reg [12:0] pc;
 reg [63:0] instruction,cycle_counter;
 reg [31:0] epoch,ticks,bus_data,poll_mask;
 reg [7:0] bus_address,poll_address,camera;
 reg [31:0] frame,accepted_sequence,roi_index,context_generation,network_session;
 reg aw_sent,w_sent,ar_sent,abort_pending;
 reg [4:0] flags;
 reg [3:0] next_block;
 reg [31:0] last_epoch,last_frame0,last_frame1;
 reg [31:0] last_roi0,last_roi1,last_generation0,last_generation1,last_network_session0,last_network_session1;
 reg [1:0] seen_camera;
 wire active=state!=IDLE&&state!=FINISHED&&state!=FAILED;
 wire live=(model_authorized===1'b1)&&(session_epoch===epoch);
 wire abort_now=active&&(!live||hardware_fault||ticks>=TASK_TIMEOUT_CYCLES);
 wire camera_known=(^trusted_camera_id!==1'bx)&&trusted_camera_id<2&&(^trusted_frame_id!==1'bx);
 wire context_known=(^trusted_session_id!==1'bx)&&trusted_session_id!=0&&
  (^trusted_roi_index!==1'bx)&&trusted_roi_index<4&&
  (^trusted_context_generation!==1'bx)&&trusted_context_generation!=0;
 wire [31:0] prior_session=trusted_camera_id[0]?last_network_session1:last_network_session0;
 wire [31:0] prior_frame=trusted_camera_id[0]?last_frame1:last_frame0;
 wire [31:0] prior_roi=trusted_camera_id[0]?last_roi1:last_roi0;
 wire [31:0] prior_generation=trusted_camera_id[0]?last_generation1:last_generation0;
 // Preserve the ORIGINAL camera frame. Multiple ROIs from that frame require
 // both increasing ROI slot and the real protected frontend generation.
 wire fresh=context_known&&accepted_sequence!=32'hffffffff&&
  ((session_epoch!==last_epoch)||!seen_camera[trusted_camera_id[0]]||
   ((trusted_session_id>prior_session||
     (trusted_session_id==prior_session&&(trusted_frame_id>prior_frame||
      (trusted_frame_id==prior_frame&&trusted_roi_index>prior_roi))))&&
    trusted_context_generation>prior_generation));
 assign request_ready=rst_n&&!active&&(model_authorized===1'b1)&&(seed_ready===1'b1)&&
                      (hardware_fault===1'b0)&&(^session_epoch!==1'bx)&&camera_known&&fresh;
 assign busy=active;
 assign result_valid=done&&!fault&&live&&rst_n;
 assign private_reads_phase=active&&flags[0]&&!fault;
 assign capture_pose=active&&flags[1]&&!fault;
 assign capture_norm=active&&flags[2]&&!fault;
 assign classification_capture=active&&flags[3]&&!fault;
 assign service_phase=active&&!fault?(flags[4]?2'd2:2'd1):2'd0;
 assign debug_pc={3'd0,pc};
 assign m_awaddr=bus_address;
 assign m_awvalid=rst_n&&state==WRITE_BUS&&!aw_sent;
 assign m_wdata=bus_data;
 assign m_wstrb=4'hf;
 assign m_wvalid=rst_n&&state==WRITE_BUS&&!w_sent;
 assign m_bready=rst_n&&state==WRITE_BUS;
 assign m_araddr=bus_address;
 assign m_arvalid=rst_n&&state==READ_BUS&&!ar_sent;
 assign m_rready=rst_n&&state==READ_BUS;
 task fail(input [7:0] code);begin
  fault<=1;done<=0;error_code<=code;abort_pending<=1;
  trusted_cancel<=1;
  if(state!=WRITE_BUS&&state!=READ_BUS)state<=FAILED;
 end endtask
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;code_word<=0;read_kind<=0;pc<=0;instruction<=0;cycle_counter<=0;epoch<=0;ticks<=0;
   bus_data<=0;poll_mask<=0;bus_address<=0;poll_address<=0;camera<=0;frame<=0;accepted_sequence<=0;
   aw_sent<=0;w_sent<=0;ar_sent<=0;abort_pending<=0;flags<=0;next_block<=0;
   last_epoch<=0;last_frame0<=0;last_frame1<=0;seen_camera<=0;
   last_roi0<=0;last_roi1<=0;last_generation0<=0;last_generation1<=0;
   roi_index<=0;context_generation<=0;result_roi_index<=0;result_context_generation<=0;
   network_session<=0;result_session<=0;last_network_session0<=0;last_network_session1<=0;
   done<=0;fault<=0;error_code<=0;trusted_cancel<=0;handoff_start<=0;classification_start<=0;handoff_pose_coefficient<=0;
   expected_object<=0;expected_kind<=0;expected_block<=0;expected_qkv_op<=0;expected_dst<=0;expected_stage<=0;
   current_block<=0;completed_blocks<=0;request_rejected<=0;
   result_class<=0;result_camera<=0;result_best_logit<=0;result_frame<=0;result_epoch<=0;result_sequence<=0;result_cycle<=0;
  end else begin
   cycle_counter<=cycle_counter+1'b1;trusted_cancel<=0;handoff_start<=0;classification_start<=0;request_rejected<=0;
   if(active)ticks<=ticks+1'b1;
   if(request_valid&&(!request_ready||!camera_known||!fresh))request_rejected<=1;
   if(abort_now&&!abort_pending)fail(!live?8'd1:hardware_fault?8'd2:8'd3);
   if(active&&(abort_pending||abort_now)&&state!=WRITE_BUS&&state!=READ_BUS)state<=FAILED;
   else case(state)
    IDLE,FINISHED,FAILED:if(request_valid&&request_ready&&camera_known&&fresh)begin
     state<=FETCH;pc<=0;epoch<=session_epoch;ticks<=0;camera<=trusted_camera_id;frame<=trusted_frame_id;
     roi_index<=trusted_roi_index;context_generation<=trusted_context_generation;network_session<=trusted_session_id;
     accepted_sequence<=accepted_sequence+1'b1;done<=0;fault<=0;error_code<=0;abort_pending<=0;
     flags<=0;next_block<=0;completed_blocks<=0;
     if(session_epoch!==last_epoch)seen_camera<=trusted_camera_id[0]?2'b10:2'b01;
     else seen_camera[trusted_camera_id[0]]<=1;
     last_epoch<=session_epoch;
     if(trusted_camera_id[0])begin last_frame1<=trusted_frame_id;last_roi1<=trusted_roi_index;last_generation1<=trusted_context_generation;last_network_session1<=trusted_session_id;end
     else begin last_frame0<=trusted_frame_id;last_roi0<=trusted_roi_index;last_generation0<=trusted_context_generation;last_network_session0<=trusted_session_id;end
    end
    FETCH:begin
     if(pc>=PROGRAM_WORDS)fail(8'd4);
     else begin code_word<=program_rom[pc];state<=LOOKUP;end
    end
    LOOKUP:begin
     if(code_word[14:10]>=25||code_word[9:0]>=829)fail(8'd8);
     else begin
      instruction<={prefix_value(code_word[14:10]),20'd0,argument_rom[code_word[9:0]]};
      state<=DECODE;
     end
    end
    DECODE:begin
     case(instruction[63:60])
      0:begin bus_address<=instruction[59:52];bus_data<=instruction[31:0];aw_sent<=0;w_sent<=0;state<=WRITE_BUS;end
      1:begin poll_address<=instruction[59:52];poll_mask<=instruction[31:0];bus_address<=8'h4c;read_kind<=1;ar_sent<=0;state<=READ_BUS;end
      2:begin
       expected_object<=instruction[8:0];expected_kind<=instruction[12:9];expected_block<=instruction[16:13];
       expected_dst<=instruction[21:17];expected_qkv_op<=instruction[25:22];expected_stage<=instruction[30:26];pc<=pc+1'b1;state<=FETCH;
      end
      3:begin flags<=instruction[4:0];pc<=pc+1'b1;state<=FETCH;end
      4:begin handoff_start<=1;handoff_pose_coefficient<=instruction[31:0];pc<=pc+1'b1;state<=FETCH;end
      5:begin classification_start<=1;pc<=pc+1'b1;state<=FETCH;end
      6:state<=SIDE_WAIT;
      7:begin
       if(instruction[31:0]>=12||instruction[3:0]!=next_block)fail(8'd5);
       else begin current_block<=instruction[3:0];pc<=pc+1'b1;state<=FETCH;end
      end
      8:begin bus_address<=instruction[59:52];poll_mask<=instruction[31:0];read_kind<=0;ar_sent<=0;state<=READ_BUS;end
      9:begin
       if(completed_blocks!=12'hfff||current_block!=11||!head_result_valid||head_result_epoch!==epoch)fail(8'd6);
       else begin
        result_class<=head_class_index;result_best_logit<=head_best_logit;
        result_camera<=camera;result_frame<=frame;result_epoch<=epoch;
        result_roi_index<=roi_index;result_context_generation<=context_generation;result_session<=network_session;result_sequence<=accepted_sequence;result_cycle<=cycle_counter;
        done<=1;state<=FINISHED;
       end
      end
      10:begin
       if(instruction[31:0]!=current_block||completed_blocks[current_block])fail(8'd7);
       else begin completed_blocks[current_block]<=1;next_block<=current_block+1'b1;pc<=pc+1'b1;state<=FETCH;end
      end
      default:fail(8'd8);
     endcase
    end
    WRITE_BUS:begin
     if(m_awvalid&&m_awready)aw_sent<=1;
     if(m_wvalid&&m_wready)w_sent<=1;
     if(m_bvalid)begin
      if(m_bresp!==2'b00)begin fail(8'd9);state<=FAILED;end
      else if(abort_pending||abort_now)state<=FAILED;
      else begin pc<=pc+1'b1;state<=FETCH;end
     end
    end
    READ_BUS:begin
     if(m_arvalid&&m_arready)ar_sent<=1;
     if(m_rvalid)begin
      if(m_rresp!==2'b00)begin fail(8'd10);state<=FAILED;end
      else if(abort_pending||abort_now)state<=FAILED;
      else if(read_kind==0)begin
       if(m_rdata!==poll_mask)begin fail(8'd11);state<=FAILED;end
       else begin pc<=pc+1'b1;state<=FETCH;end
      end else if(read_kind==1)begin
       if(m_rdata!==32'd0)begin fail(8'd12);state<=FAILED;end
       else begin bus_address<=poll_address;read_kind<=2;ar_sent<=0;end
      end else if((m_rdata&poll_mask)===poll_mask)begin pc<=pc+1'b1;state<=FETCH;end
      else begin bus_address<=8'h4c;read_kind<=1;ar_sent<=0;end
     end
    end
    SIDE_WAIT:begin
     if((instruction[31:0]==1&&handoff_ready)||
        (instruction[31:0]==2&&head_result_valid&&head_result_epoch===epoch))begin pc<=pc+1'b1;state<=FETCH;end
    end
    default:state<=FAILED;
   endcase
  end
 end
endmodule
