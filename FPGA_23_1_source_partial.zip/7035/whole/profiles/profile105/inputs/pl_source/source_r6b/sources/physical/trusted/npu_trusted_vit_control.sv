`timescale 1ns/1ps
// Real R12 sequence + authenticated static reader. The SINGLE V2 page service
// lives in the enclosing parent, shared with YOLO/frontend. No local SLH/cache.
module npu_trusted_vit_control(
 input wire clk,rst_n,prepare_seed,frontend_owner,request_valid,
 output wire request_ready,done,fault,busy,reader_quiescent,
 input wire model_authorized,external_cancel,pool_fault,
 input wire [31:0] session_epoch,frame_generation,roi_index,context_generation,network_session_id,
 input wire [7:0] camera_id,
 output wire trusted_authorized,trusted_cancel,
 output wire [31:0] trusted_epoch,
 input wire handoff_ready,handoff_fault,private_read_fault,
 output wire handoff_start,handoff_seed,capture_pose,capture_norm,private_reads_phase,
 output wire signed [31:0] handoff_pose_coefficient,
 output wire classification_start,classification_capture,
 input wire classifier_page_request,input wire [31:0] classifier_expected_page_index,
 output wire classifier_page_request_ready,classifier_cache_valid,
 output wire [31:0] classifier_cached_page_index,
 input wire classifier_cache_read,input wire [9:0] classifier_cache_read_addr,
 output wire classifier_cache_read_valid,output wire [31:0] classifier_cache_read_data,
 input wire classifier_fault,trusted_result_valid,input wire [7:0] trusted_class_index,
 input wire signed [63:0] trusted_best_logit,input wire [31:0] trusted_result_epoch,
 output wire [3:0] current_block,output wire [15:0] debug_pc,
 output wire result_valid,output wire [7:0] result_class,
 output wire signed [63:0] result_best_logit,
 output wire [7:0] result_camera,
 output wire [31:0] result_frame,result_epoch,result_sequence,result_roi_index,result_context_generation,result_session,
 output wire [63:0] result_cycle,
 output wire [1:0] service_phase,page_requests,cache_reads,
 output wire [63:0] expected_pages,output wire [19:0] cache_addresses,
 input wire [1:0] page_grants,read_grants,
 input wire cache_valid,input wire [31:0] cached_page_index,cache_read_data,
 output wire [7:0] m_awaddr,output wire m_awvalid,input wire m_awready,
 output wire [31:0] m_wdata,output wire [3:0] m_wstrb,output wire m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output wire [7:0] m_araddr,output wire m_arvalid,input wire m_arready,
 input wire [31:0] m_rdata,input wire [1:0] m_rresp,input wire m_rvalid,output wire m_rready,
 input wire [31:0] s_araddr,input wire [7:0] s_arlen,
 input wire [2:0] s_arsize,input wire [1:0] s_arburst,
 input wire s_arvalid,output wire s_arready,
 output wire [255:0] s_rdata,output wire [1:0] s_rresp,
 output wire s_rlast,s_rvalid,input wire s_rready
);
wire seq_busy,seq_fault,seq_cancel,seq_handoff,seq_pose,seq_norm,reader_fault;
wire signed [31:0] seq_coef;
wire [1:0] phase;
wire [8:0] expected_object;
wire [3:0] expected_kind,expected_block,expected_qkv_op;
wire [4:0] expected_dst,expected_stage;
wire kernel_request,kernel_request_ready,kernel_cache_read,kernel_cache_read_valid;
wire [31:0] kernel_expected_page_index;
wire [9:0] kernel_cache_read_addr;
wire [7:0] error_code;
assign busy=seq_busy;
assign handoff_start=prepare_seed||seq_handoff;
assign handoff_seed=frontend_owner;
assign handoff_pose_coefficient=frontend_owner?32'sd498899827:seq_coef;
assign capture_pose=frontend_owner||seq_pose;
assign capture_norm=frontend_owner||seq_norm;
assign trusted_authorized=model_authorized;
assign trusted_epoch=session_epoch;
assign trusted_cancel=seq_cancel||external_cancel;
assign fault=seq_fault||reader_fault||handoff_fault||private_read_fault||classifier_fault||pool_fault;
assign kernel_request_ready=page_grants[0];
assign classifier_page_request_ready=page_grants[1];
assign kernel_cache_read_valid=read_grants[0];
assign classifier_cache_read_valid=read_grants[1];
assign classifier_cache_valid=cache_valid;
assign classifier_cached_page_index=cached_page_index;
assign classifier_cache_read_data=cache_read_data;
assign service_phase=phase;
assign page_requests={classifier_page_request,kernel_request};
assign expected_pages={classifier_expected_page_index,kernel_expected_page_index};
assign cache_reads={classifier_cache_read,kernel_cache_read};
assign cache_addresses={classifier_cache_read_addr,kernel_cache_read_addr};
 npu_trusted_vit_sequence #(.PROGRAM_WORDS(5317)) u_sequence(
 .clk(clk),.rst_n(rst_n),.request_valid(request_valid),.request_ready(request_ready),.request_rejected(),
 .model_authorized(model_authorized),.session_epoch(session_epoch),.seed_ready(handoff_ready),
 .trusted_camera_id(camera_id),.trusted_frame_id(frame_generation),
 .trusted_roi_index(roi_index),.trusted_context_generation(context_generation),.trusted_session_id(network_session_id),
 .hardware_fault(external_cancel||pool_fault||reader_fault||handoff_fault||private_read_fault||classifier_fault),
 .handoff_ready(handoff_ready),.head_result_valid(trusted_result_valid),.head_result_epoch(trusted_result_epoch),
 .head_class_index(trusted_class_index),.head_best_logit(trusted_best_logit),
 .busy(seq_busy),.done(done),.fault(seq_fault),.error_code(error_code),
 .trusted_cancel(seq_cancel),.handoff_start(seq_handoff),.classification_start(classification_start),
 .handoff_pose_coefficient(seq_coef),.private_reads_phase(private_reads_phase),
 .capture_pose(seq_pose),.capture_norm(seq_norm),.classification_capture(classification_capture),
 .service_phase(phase),.expected_object(expected_object),.expected_kind(expected_kind),
 .expected_block(expected_block),.expected_qkv_op(expected_qkv_op),.expected_dst(expected_dst),.expected_stage(expected_stage),
 .result_roi_index(result_roi_index),.result_context_generation(result_context_generation),.result_session(result_session),.current_block(current_block),.completed_blocks(),.result_valid(result_valid),.result_class(result_class),
 .result_camera(result_camera),.result_best_logit(result_best_logit),.result_frame(result_frame),.result_epoch(result_epoch),.result_sequence(result_sequence),.result_cycle(result_cycle),.debug_pc(debug_pc),
 .m_awaddr(m_awaddr),.m_awvalid(m_awvalid),.m_awready(m_awready),.m_wdata(m_wdata),.m_wstrb(m_wstrb),.m_wvalid(m_wvalid),.m_wready(m_wready),
 .m_bresp(m_bresp),.m_bvalid(m_bvalid),.m_bready(m_bready),.m_araddr(m_araddr),.m_arvalid(m_arvalid),.m_arready(m_arready),
 .m_rdata(m_rdata),.m_rresp(m_rresp),.m_rvalid(m_rvalid),.m_rready(m_rready));
 npu_authenticated_axi_read reader(.clk(clk),.rst_n(rst_n),.clear(prepare_seed),.cancel(seq_cancel||external_cancel),
 .model_authorized(model_authorized),.session_epoch(session_epoch),.expected_object(expected_object),
 .expected_kind(expected_kind),.expected_block(expected_block),.expected_qkv_op(expected_qkv_op),.expected_dst(expected_dst),.expected_stage(expected_stage),
 .s_araddr(s_araddr),.s_arlen(s_arlen),.s_arsize(s_arsize),.s_arburst(s_arburst),.s_arvalid(s_arvalid),.s_arready(s_arready),
 .s_rdata(s_rdata),.s_rresp(s_rresp),.s_rlast(s_rlast),.s_rvalid(s_rvalid),.s_rready(s_rready),
 .page_request(kernel_request),.page_request_ready(kernel_request_ready),.expected_page_index(kernel_expected_page_index),
 .cache_valid(cache_valid),.cached_page_index(cached_page_index),.cache_read(kernel_cache_read),.cache_read_addr(kernel_cache_read_addr),
 .cache_read_valid(kernel_cache_read_valid),.cache_read_data(cache_read_data),.fault(reader_fault),.quiescent(reader_quiescent));
endmodule
