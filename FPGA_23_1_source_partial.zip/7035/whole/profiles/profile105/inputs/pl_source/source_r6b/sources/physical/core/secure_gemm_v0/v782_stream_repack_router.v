`timescale 1ns/1ps
module v782_stream_repack_router(
 input wire clk,input wire rst_n,input wire clear,
 input wire norm2_out_valid,input wire [15:0] norm2_out_addr,input wire signed [15:0] norm2_out_data,
 output reg fc1_a_wr_valid,output reg [15:0] fc1_a_wr_addr,output reg signed [15:0] fc1_a_wr_data,
 input wire gelu_out_valid,input wire [17:0] gelu_out_addr,input wire signed [7:0] gelu_out_data,
 input wire fc2_pad_active,output reg fc2_pad_done,output reg fc2_in_wr_valid,
 output reg [17:0] fc2_in_wr_addr,output reg signed [15:0] fc2_in_wr_data,
 output reg [31:0] stat_fc1_writes,output reg [31:0] stat_fc2_writes);
reg [7:0] ncol;reg [15:0] next_addr;reg pad_seen;
always @(posedge clk)begin
 if(!rst_n)begin fc1_a_wr_valid<=0;fc1_a_wr_addr<=0;fc1_a_wr_data<=0;fc2_pad_done<=0;
  fc2_in_wr_valid<=0;fc2_in_wr_addr<=0;fc2_in_wr_data<=0;stat_fc1_writes<=0;stat_fc2_writes<=0;
  ncol<=0;next_addr<=0;pad_seen<=0;end
 else begin fc1_a_wr_valid<=0;fc2_pad_done<=0;fc2_in_wr_valid<=0;
  if(clear)begin stat_fc1_writes<=0;stat_fc2_writes<=0;ncol<=0;next_addr<=0;pad_seen<=0;end
  else begin
   if(norm2_out_valid)begin fc1_a_wr_valid<=1;fc1_a_wr_addr<=next_addr;
    fc1_a_wr_data<=(stat_fc1_writes<32'd40352)?norm2_out_data:0;
    stat_fc1_writes<=stat_fc1_writes+1'b1;
    if(stat_fc1_writes<32'd39936)begin
     if(stat_fc1_writes==32'd39935)begin ncol<=0;next_addr<=16'd192;end
     else if(ncol==191)begin ncol<=0;next_addr<=next_addr+5;end
     else begin ncol<=ncol+1'b1;next_addr<=next_addr+1'b1;end
    end else if(stat_fc1_writes<32'd40352)begin
     if(stat_fc1_writes==32'd40351)begin ncol<=0;next_addr<=16'd40768;end
     else if(ncol==1)begin ncol<=0;next_addr<=next_addr+195;end
     else begin ncol<=1;next_addr<=next_addr+1'b1;end
    end else begin
     if(ncol==193)begin ncol<=0;next_addr<=next_addr+3;end
     else begin ncol<=ncol+1'b1;next_addr<=next_addr+1'b1;end
    end
   end
   if(fc2_pad_active&&!pad_seen)begin fc2_pad_done<=1;pad_seen<=1;end
   if(!fc2_pad_active)pad_seen<=0;
  end
 end
end
wire _unused=^norm2_out_addr^gelu_out_valid^gelu_out_addr^gelu_out_data;
endmodule
