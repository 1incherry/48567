`timescale 1ns/1ps

module v720_axi_qkv_full_attention_inner_nomemh_top (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,

    input  wire         qkv_bank_start,
    output wire         qkv_bank_done,

    input  wire         load_cmd_valid,
    output wire         load_cmd_ready,
    input  wire [1:0]   load_cmd_dst,
    input  wire [3:0]   load_cmd_block_id,
    input  wire [3:0]   load_cmd_op_id,
    input  wire [31:0]  load_cmd_axi_addr,
    input  wire [11:0]  load_cmd_local_addr,
    input  wire [15:0]  load_cmd_beats,
    input  wire [7:0]   load_cmd_burst_len_m1,
    output wire         load_done,

    input  wire         qkv_compute_start,
    input  wire [3:0]   qkv_compute_block_id,
    input  wire [3:0]   qkv_compute_op_id,
    output wire         qkv_compute_busy,
    output wire         qkv_compute_done,

    input  wire         qkt_start,
    input  wire [15:0]  qkt_a_base,
    input  wire [15:0]  qkt_b_base,
    input  wire [15:0]  qkt_scale_base,
    input  wire [31:0]  qkt_quant_base,
    input  wire         qkt_scale_wr_valid,
    input  wire [15:0]  qkt_scale_wr_addr,
    input  wire signed [31:0] qkt_scale_wr_data,
    output wire         qkt_busy,
    output wire         qkt_done,

    input  wire         softmax_start,
    input  wire [15:0]  row_max_base,
    input  wire [15:0]  row_sum_base,
    input  wire [15:0]  factor_base,
    input  wire [31:0]  prob_base,
    input  wire signed [31:0] softmax_x0,
    output wire         softmax_busy,
    output wire         softmax_done,

    input  wire         prob_bank_start,
    input  wire [15:0]  av_a_tile_base,
    output wire         prob_bank_done,

    input  wire         av_start,
    input  wire [15:0]  av_b_base,
    input  wire [15:0]  av_scale_base,
    input  wire [31:0]  av_quant_base,
    input  wire         av_scale_wr_valid,
    input  wire [15:0]  av_scale_wr_addr,
    input  wire signed [31:0] av_scale_wr_data,
    output wire         av_busy,
    output wire         av_done,
    output wire         av_ctx_tile_valid,
    output wire [15:0]  av_ctx_tile_addr,
    output wire [127:0] av_ctx_tile_data,

    output wire [31:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [255:0] m_axi_rdata,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,
    input  wire         m_axi_rlast,

    output wire [31:0]  stat_load_beats,
    output wire [31:0]  stat_load_errors,
    output wire [31:0]  stat_qkv_compute_cycles,
    output wire [31:0]  stat_qkv_compute_tiles,
    output wire [31:0]  stat_qkv_quant_items,
    output wire [31:0]  stat_bank_inputs,
    output wire [31:0]  stat_bank_q_inputs,
    output wire [31:0]  stat_bank_k_inputs,
    output wire [31:0]  stat_bank_v_inputs,
    output wire [31:0]  stat_qkt_tiles,
    output wire [31:0]  stat_qkt_cycles,
    output wire [31:0]  stat_softmax_score_tiles,
    output wire [31:0]  stat_softmax_rows,
    output wire [31:0]  stat_softmax_probs,
    output wire [31:0]  stat_prob_bank_writes,
    output wire [31:0]  stat_av_tiles,
    output wire [31:0]  stat_av_cycles
);

wire q_rd_en;
wire k_rd_en;
wire v_rd_en;
wire [15:0] q_rd_addr;
wire [15:0] k_rd_addr;
wire [15:0] v_rd_addr;
wire [255:0] q_rd_data;
wire [255:0] k_rd_data;
wire [255:0] v_rd_data;

wire qkt_score_tile_valid;
wire [15:0] qkt_score_tile_addr;
wire [127:0] qkt_score_tile_data;
wire sm_out_valid;
wire sm_out_ready;
wire [15:0] sm_out_addr;
wire signed [15:0] sm_out_data;
wire av_a_rd_en;
wire [15:0] av_a_rd_addr;
wire [255:0] av_a_rd_data;

wire [31:0] stat_qkv_stream_stall_cycles_unused;
wire [31:0] stat_bank_kind_errors_unused;
wire [31:0] stat_qkt_tile_reads_unused;
wire [31:0] stat_qkt_prefetches_unused;
wire [31:0] stat_qkt_underflows_unused;
wire [31:0] stat_qkt_quant_errors_unused;
wire [31:0] stat_qkt_scale_writes_unused;
wire [31:0] stat_qkt_scale_errors_unused;
wire [31:0] stat_softmax_stream_writes_unused;
wire [31:0] stat_softmax_errors_unused;
wire [31:0] stat_softmax_cycles_unused;
wire [31:0] stat_prob_tiles_checked_unused;
wire [31:0] stat_prob_bank_errors_unused;
wire [31:0] stat_av_tile_reads_unused;
wire [31:0] stat_av_prefetches_unused;
wire [31:0] stat_av_underflows_unused;
wire [31:0] stat_av_quant_errors_unused;
wire [31:0] stat_av_scale_writes_unused;
wire [31:0] stat_av_scale_errors_unused;

v717_axi_qkv_to_attention_bank_top_bramstyle u_qkv_bank (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .bank_start(qkv_bank_start),
    .bank_done(qkv_bank_done),
    .load_cmd_valid(load_cmd_valid),
    .load_cmd_ready(load_cmd_ready),
    .load_cmd_dst(load_cmd_dst),
    .load_cmd_block_id(load_cmd_block_id),
    .load_cmd_op_id(load_cmd_op_id),
    .load_cmd_axi_addr(load_cmd_axi_addr),
    .load_cmd_local_addr(load_cmd_local_addr),
    .load_cmd_beats(load_cmd_beats),
    .load_cmd_burst_len_m1(load_cmd_burst_len_m1),
    .load_done(load_done),
    .compute_start(qkv_compute_start),
    .compute_block_id(qkv_compute_block_id),
    .compute_op_id(qkv_compute_op_id),
    .compute_busy(qkv_compute_busy),
    .compute_done(qkv_compute_done),
    .m_axi_araddr(m_axi_araddr),
    .m_axi_arlen(m_axi_arlen),
    .m_axi_arsize(m_axi_arsize),
    .m_axi_arburst(m_axi_arburst),
    .m_axi_arvalid(m_axi_arvalid),
    .m_axi_arready(m_axi_arready),
    .m_axi_rdata(m_axi_rdata),
    .m_axi_rvalid(m_axi_rvalid),
    .m_axi_rready(m_axi_rready),
    .m_axi_rlast(m_axi_rlast),
    .q_rd_en(q_rd_en),
    .k_rd_en(k_rd_en),
    .v_rd_en(v_rd_en),
    .q_rd_addr(q_rd_addr),
    .k_rd_addr(k_rd_addr),
    .v_rd_addr(v_rd_addr),
    .q_rd_data(q_rd_data),
    .k_rd_data(k_rd_data),
    .v_rd_data(v_rd_data),
    .stat_load_beats(stat_load_beats),
    .stat_load_errors(stat_load_errors),
    .stat_compute_cycles(stat_qkv_compute_cycles),
    .stat_compute_tiles(stat_qkv_compute_tiles),
    .stat_quant_items(stat_qkv_quant_items),
    .stat_qkv_stream_stall_cycles(stat_qkv_stream_stall_cycles_unused),
    .stat_bank_inputs(stat_bank_inputs),
    .stat_bank_q_inputs(stat_bank_q_inputs),
    .stat_bank_k_inputs(stat_bank_k_inputs),
    .stat_bank_v_inputs(stat_bank_v_inputs),
    .stat_bank_kind_errors(stat_bank_kind_errors_unused)
);

v718_external_bank_qkt_banked_acc16_vecquant_score_tile_core_nomemh #(
    .M(200),
    .K(64),
    .N(200)
) u_qkt (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .start(qkt_start),
    .qkt_a_base(qkt_a_base),
    .qkt_b_base(qkt_b_base),
    .qkt_scale_base(qkt_scale_base),
    .qkt_quant_base(qkt_quant_base),
    .scale_wr_valid(qkt_scale_wr_valid),
    .scale_wr_addr(qkt_scale_wr_addr),
    .scale_wr_data(qkt_scale_wr_data),
    .ext_a_rd_en(q_rd_en),
    .ext_a_rd_addr(q_rd_addr),
    .ext_a_rd_data(q_rd_data),
    .ext_b_rd_en(k_rd_en),
    .ext_b_rd_addr(k_rd_addr),
    .ext_b_rd_data(k_rd_data),
    .busy(qkt_busy),
    .done(qkt_done),
    .stat_tiles(stat_qkt_tiles),
    .stat_tile_reads(stat_qkt_tile_reads_unused),
    .stat_prefetches(stat_qkt_prefetches_unused),
    .stat_underflows(stat_qkt_underflows_unused),
    .stat_quant_errors(stat_qkt_quant_errors_unused),
    .stat_scale_writes(stat_qkt_scale_writes_unused),
    .stat_scale_errors(stat_qkt_scale_errors_unused),
    .stat_cycles(stat_qkt_cycles),
    .stat_stage(),
    .out_tile_valid(qkt_score_tile_valid),
    .out_tile_addr(qkt_score_tile_addr),
    .out_tile_data(qkt_score_tile_data)
);

v719_unified_score_tile_bank_live_softmax_stream_c0_nomemh u_softmax (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .start(softmax_start),
    .row_max_base(row_max_base),
    .row_sum_base(row_sum_base),
    .factor_base(factor_base),
    .prob_base(prob_base),
    .cfg_x0(softmax_x0),
    .score_tile_valid(qkt_score_tile_valid),
    .score_tile_addr(qkt_score_tile_addr),
    .score_tile_data(qkt_score_tile_data),
    .out_ready(sm_out_ready),
    .busy(softmax_busy),
    .done(softmax_done),
    .out_valid(sm_out_valid),
    .out_addr(sm_out_addr),
    .out_data(sm_out_data),
    .stat_score_tiles(stat_softmax_score_tiles),
    .stat_rows(stat_softmax_rows),
    .stat_probs(stat_softmax_probs),
    .stat_stream_writes(stat_softmax_stream_writes_unused),
    .stat_errors(stat_softmax_errors_unused),
    .stat_cycles(stat_softmax_cycles_unused),
    .stat_stage()
);

v719_unified_prob_stream_to_av_tile_bank_nomemh u_prob_bank (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .start(prob_bank_start),
    .av_a_tile_base(av_a_tile_base),
    .in_valid(sm_out_valid),
    .in_ready(sm_out_ready),
    .in_addr(sm_out_addr),
    .in_data(sm_out_data),
    .busy(),
    .done(prob_bank_done),
    .stat_writes(stat_prob_bank_writes),
    .stat_tiles_checked(stat_prob_tiles_checked_unused),
    .stat_errors(stat_prob_bank_errors_unused),
    .stat_stage(),
    .rd_en(av_a_rd_en),
    .rd_addr(av_a_rd_addr),
    .rd_data(av_a_rd_data)
);

v718_external_b_bank_live_a_av_stream_core_nomemh #(
    .M(200),
    .K(200),
    .N(64)
) u_av (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .start(av_start),
    .av_b_base(av_b_base),
    .av_scale_base(av_scale_base),
    .av_quant_base(av_quant_base),
    .scale_wr_valid(av_scale_wr_valid),
    .scale_wr_addr(av_scale_wr_addr),
    .scale_wr_data(av_scale_wr_data),
    .live_a_rd_en(av_a_rd_en),
    .live_a_rd_addr(av_a_rd_addr),
    .live_a_rd_data(av_a_rd_data),
    .ext_b_rd_en(v_rd_en),
    .ext_b_rd_addr(v_rd_addr),
    .ext_b_rd_data(v_rd_data),
    .out_tile_valid(av_ctx_tile_valid),
    .out_tile_addr(av_ctx_tile_addr),
    .out_tile_data(av_ctx_tile_data),
    .busy(av_busy),
    .done(av_done),
    .stat_tiles(stat_av_tiles),
    .stat_tile_reads(stat_av_tile_reads_unused),
    .stat_prefetches(stat_av_prefetches_unused),
    .stat_underflows(stat_av_underflows_unused),
    .stat_quant_errors(stat_av_quant_errors_unused),
    .stat_scale_writes(stat_av_scale_writes_unused),
    .stat_scale_errors(stat_av_scale_errors_unused),
    .stat_cycles(stat_av_cycles),
    .stat_stage()
);

endmodule
