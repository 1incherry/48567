`timescale 1ns/1ps

module v717_axi_fed_qkv_stream_top_bramstyle (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,

    input  wire         load_cmd_valid,
    output wire         load_cmd_ready,
    input  wire [1:0]   load_cmd_dst,
    input  wire [3:0]   load_cmd_block_id,
    input  wire [3:0]   load_cmd_op_id,
    input  wire [31:0]  load_cmd_axi_addr,
    input  wire [11:0]  load_cmd_local_addr,
    input  wire [15:0]  load_cmd_beats,
    input  wire [7:0]   load_cmd_burst_len_m1,
    output wire         load_done,

    input  wire         compute_start,
    input  wire [3:0]   compute_block_id,
    input  wire [3:0]   compute_op_id,
    output wire         compute_busy,
    output wire         compute_done,

    output wire         qkv_out_valid,
    input  wire         qkv_out_ready,
    output wire [1:0]   qkv_out_kind,
    output wire [15:0]  qkv_out_addr,
    output wire signed [7:0] qkv_out_data,

    output wire [31:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [255:0] m_axi_rdata,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,
    input  wire         m_axi_rlast,

    output wire [31:0]  stat_load_cmds,
    output wire [31:0]  stat_load_beats,
    output wire [31:0]  stat_load_errors,
    output wire [31:0]  stat_compute_cycles,
    output wire [31:0]  stat_compute_tiles,
    output wire [31:0]  stat_quant_items,
    output wire [31:0]  stat_quant_checksum,
    output wire [31:0]  stat_stream_stall_cycles,
    output wire [31:0]  stat_bank_errors
);

wire loader_busy;
wire a_wr_valid;
wire [3:0] a_wr_block_id;
wire [11:0] a_wr_addr;
wire [255:0] a_wr_data;
wire b_wr_valid;
wire [3:0] b_wr_block_id;
wire [3:0] b_wr_op_id;
wire [9:0] b_wr_addr;
wire [255:0] b_wr_data;
wire scale_wr_valid;
wire [7:0] scale_wr_beat_addr;
wire [255:0] scale_wr_data;
wire [31:0] stat_unsupported_errors;
wire [3:0] stat_stage;

v711_axi256_qkv_loader u_loader (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .cmd_valid(load_cmd_valid),
    .cmd_ready(load_cmd_ready),
    .cmd_dst(load_cmd_dst),
    .cmd_block_id(load_cmd_block_id),
    .cmd_op_id(load_cmd_op_id),
    .cmd_axi_addr(load_cmd_axi_addr),
    .cmd_local_addr(load_cmd_local_addr),
    .cmd_beats(load_cmd_beats),
    .cmd_burst_len_m1(load_cmd_burst_len_m1),
    .busy(loader_busy),
    .done(load_done),
    .stat_cmds(stat_load_cmds),
    .stat_beats(stat_load_beats),
    .stat_errors(stat_load_errors),
    .stat_axi_inflight_peak(),
    .stat_a_max_addr(),
    .stat_b_max_addr(),
    .stat_scale_max_beat(),
    .m_axi_araddr(m_axi_araddr),
    .m_axi_arlen(m_axi_arlen),
    .m_axi_arsize(m_axi_arsize),
    .m_axi_arburst(m_axi_arburst),
    .m_axi_arvalid(m_axi_arvalid),
    .m_axi_arready(m_axi_arready),
    .m_axi_rdata(m_axi_rdata),
    .m_axi_rvalid(m_axi_rvalid),
    .m_axi_rready(m_axi_rready),
    .m_axi_rlast(m_axi_rlast),
    .a_wr_valid(a_wr_valid),
    .a_wr_block_id(a_wr_block_id),
    .a_wr_addr(a_wr_addr),
    .a_wr_data(a_wr_data),
    .b_wr_valid(b_wr_valid),
    .b_wr_block_id(b_wr_block_id),
    .b_wr_op_id(b_wr_op_id),
    .b_wr_addr(b_wr_addr),
    .b_wr_data(b_wr_data),
    .scale_wr_valid(scale_wr_valid),
    .scale_wr_beat_addr(scale_wr_beat_addr),
    .scale_wr_data(scale_wr_data)
);

v717_blockselect_allop_qkv_stream_core_bramstyle u_compute (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .start(compute_start),
    .block_id(compute_block_id),
    .op_id(compute_op_id),
    .a_wr_valid(a_wr_valid),
    .a_wr_block_id(a_wr_block_id),
    .a_wr_addr(a_wr_addr),
    .a_wr_data(a_wr_data),
    .b_wr_valid(b_wr_valid),
    .b_wr_block_id(b_wr_block_id),
    .b_wr_op_id(b_wr_op_id),
    .b_wr_addr(b_wr_addr),
    .b_wr_data(b_wr_data),
    .scale_wr_valid(scale_wr_valid),
    .scale_wr_beat_addr(scale_wr_beat_addr),
    .scale_wr_data(scale_wr_data),
    .out_valid(qkv_out_valid),
    .out_ready(qkv_out_ready),
    .out_kind(qkv_out_kind),
    .out_addr(qkv_out_addr),
    .out_data(qkv_out_data),
    .busy(compute_busy),
    .done(compute_done),
    .stat_cycles(stat_compute_cycles),
    .stat_tiles(stat_compute_tiles),
    .stat_bank_reads(),
    .stat_quant_items(stat_quant_items),
    .stat_quant_checksum(stat_quant_checksum),
    .stat_stream_stall_cycles(stat_stream_stall_cycles),
    .stat_bank_errors(stat_bank_errors),
    .stat_unsupported_errors(stat_unsupported_errors),
    .stat_stage(stat_stage)
);

endmodule
