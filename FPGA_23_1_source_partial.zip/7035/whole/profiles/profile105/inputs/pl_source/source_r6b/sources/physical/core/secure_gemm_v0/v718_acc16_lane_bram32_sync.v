`timescale 1ns/1ps

module v718_acc16_lane_bram32_sync #(
    parameter ADDR_W = 12,
    parameter DEPTH   = 2500,
    parameter FIT_MAX_DEPTH = 2048
) (
    input  wire             clk,
    input  wire             wr_en,
    input  wire [ADDR_W-1:0] wr_addr,
    input  wire [511:0]     wr_data,
    input  wire             rd_en,
    input  wire [ADDR_W-1:0] rd_addr,
    output wire [511:0]     rd_data
);

wire [31:0] rd0;
wire [31:0] rd1;
wire [31:0] rd2;
wire [31:0] rd3;
wire [31:0] rd4;
wire [31:0] rd5;
wire [31:0] rd6;
wire [31:0] rd7;
wire [31:0] rd8;
wire [31:0] rd9;
wire [31:0] rd10;
wire [31:0] rd11;
wire [31:0] rd12;
wire [31:0] rd13;
wire [31:0] rd14;
wire [31:0] rd15;

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank0 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 0*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd0)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank1 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 1*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd1)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank2 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 2*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd2)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank3 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 3*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd3)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank4 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 4*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd4)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank5 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 5*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd5)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank6 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 6*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd6)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank7 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 7*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd7)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank8 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 8*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd8)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank9 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 9*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd9)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank10 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 10*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd10)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank11 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 11*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd11)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank12 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 12*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd12)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank13 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 13*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd13)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank14 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 14*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd14)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(ADDR_W),
    .DEPTH(DEPTH),
    .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
) u_bank15 (
    .clk(clk),
    .wr_en(wr_en),
    .wr_addr(wr_addr),
    .wr_data(wr_data[511 - 15*32 -: 32]),
    .rd_en(rd_en),
    .rd_addr(rd_addr),
    .rd_data(rd15)
);

assign rd_data = {
    rd0, rd1, rd2, rd3,
    rd4, rd5, rd6, rd7,
    rd8, rd9, rd10, rd11,
    rd12, rd13, rd14, rd15
};

endmodule
