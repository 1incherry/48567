`timescale 1ns/1ps

// Load-command scoped authenticated read shell.
//
// One authenticated record covers the complete loader command rather than one
// AXI burst.  This matters for V790 because Block0 contains 33 load commands
// but 24,488 AR transactions.  The MAC input is:
//   header(semantic context, load address, total beats, destination,
//          local address) || data beats
// and therefore remains stable even when the loader changes burst splitting.
module v801_secure_stream_load_auth_2lane #(
    parameter DATA_WIDTH=256, parameter KEEP_WIDTH=DATA_WIDTH/8,
    parameter CTR_LANES=2,parameter CTR_SERIAL_HALVES=0,parameter MAC_SERIAL_CORE=0,
    parameter CTR_EXTERNAL_SERVICE=0,parameter MAC_EXTERNAL_SERVICE=0,
    parameter SERVICE_TAG_W=16
) (
    input wire clk,input wire rst_n,input wire clear,
    input wire crypto_enable,input wire auth_enable,
    input wire [127:0] crypto_key,input wire [127:0] auth_key,
    input wire [95:0] crypto_nonce,
    input wire load_fire,input wire [111:0] load_context,
    input wire common_auth_enable,input wire [127:0] common_object_context,
    input wire [7:0] common_dtype,input wire [7:0] common_role,
    input wire [7:0] common_key_id,
    input wire [31:0] load_addr,input wire [15:0] load_beats,
    input wire [7:0] load_dst,input wire [17:0] load_local_addr,
    input wire expected_valid,input wire [127:0] expected_tag,
    input wire ar_fire,output wire ar_ready,input wire [31:0] ar_addr,
    input wire s_valid,output wire s_ready,input wire [DATA_WIDTH-1:0] s_data,
    input wire [KEEP_WIDTH-1:0] s_keep,input wire s_last,
    output wire m_valid,input wire m_ready,output wire [DATA_WIDTH-1:0] m_data,
    output wire [KEEP_WIDTH-1:0] m_keep,output wire m_last,
    output wire [31:0] stat_beats,output wire [31:0] stat_stall_cycles,
    output reg auth_done,output reg auth_ok,output reg auth_fail,
    output reg [127:0] computed_tag,
    output wire service_client_fault,output wire[7:0]service_client_fault_code,
    output wire ctr_block_req_valid,input wire ctr_block_req_ready,
    output wire[127:0]ctr_block_req_key,output wire[127:0]ctr_block_req_data,
    output wire[SERVICE_TAG_W-1:0]ctr_block_req_tag,
    input wire ctr_block_rsp_valid,output wire ctr_block_rsp_ready,
    input wire[127:0]ctr_block_rsp_data,input wire[SERVICE_TAG_W-1:0]ctr_block_rsp_tag,
    output wire mac_block_req_valid,input wire mac_block_req_ready,
    output wire[127:0]mac_block_req_key,output wire[127:0]mac_block_req_data,
    output wire[SERVICE_TAG_W-1:0]mac_block_req_tag,
    input wire mac_block_rsp_valid,output wire mac_block_rsp_ready,
    input wire[127:0]mac_block_rsp_data,input wire[SERVICE_TAG_W-1:0]mac_block_rsp_tag
);
    // load_context = {model[15:0], operator[15:0], tensor[7:0], tile[7:0],
    //                 epoch[31:0], sequence[31:0]}.
    localparam [63:0] DOMAIN = 64'h563830314c4f4144; // "V801LOAD"
    localparam [63:0] COMMON_DOMAIN = 64'h563830364f424a54; // "V806OBJT"
    localparam [63:0] COMMON_META_DOMAIN = 64'h563830364d455441; // "V806META"
    reg common_auth_enable_reg;
    reg [127:0] common_object_context_reg;
    reg [7:0] common_dtype_reg,common_role_reg,common_key_id_reg;
    wire [255:0] header_block={DOMAIN,load_context,load_addr,load_beats,
                              load_dst,load_local_addr,6'd0};
    wire [255:0] common_header_block={COMMON_DOMAIN,common_object_context_reg,
                                      load_addr,load_beats,common_dtype_reg,common_role_reg};
    wire [255:0] common_header_block_start={COMMON_DOMAIN,common_object_context,
                                            load_addr,load_beats,common_dtype,common_role};
    wire [255:0] common_header1_block={COMMON_META_DOMAIN,crypto_nonce,
                                       common_key_id_reg,8'd1,16'd1,64'd0};
    wire ctr_ready;
    wire mac_busy,mac_done;
    wire [127:0] mac_tag;
    wire ctr_client_fault,mac_client_fault;
    wire[7:0]ctr_client_fault_code,mac_client_fault_code;
    assign service_client_fault=ctr_client_fault|mac_client_fault;
    assign service_client_fault_code=ctr_client_fault?ctr_client_fault_code:mac_client_fault_code;
    reg [127:0] chain_reg,expected_reg;
    reg [15:0] beats_expected,beats_seen;
    reg load_active,header_inflight,header_ready,last_pending,common_header_pending;
    wire count_available=(beats_seen<beats_expected);
    wire stream_can_accept=!auth_enable ||
                           (load_active&&header_ready&&count_available&&
                            !mac_busy&&!mac_done&&!last_pending);
    wire accept=s_valid&&s_ready;
    wire data_mac_start=accept&&auth_enable&&count_available;
    wire auth_load_idle=!load_active&&!header_inflight&&!mac_busy&&!last_pending;
    wire header_mac_start=load_fire&&auth_enable&&expected_valid&&auth_load_idle;
    wire common_header1_start=common_auth_enable_reg&&load_active&&common_header_pending&&
                              !mac_busy&&!mac_done;

    // Do not issue the first AR until the authenticated header has entered the
    // chain, and do not issue a following AR while a beat MAC is outstanding.
    assign ar_ready=!auth_enable ||
                    (load_active&&header_ready&&!mac_busy&&!mac_done&&!last_pending);

    generate if(CTR_EXTERNAL_SERVICE)begin:g_ctr_external
      v854_secure_stream_sm4_ctr_external #(.DATA_WIDTH(DATA_WIDTH),
       .KEEP_WIDTH(KEEP_WIDTH),.TAG_W(SERVICE_TAG_W))u_ctr(
          .clk(clk),.rst_n(rst_n),.clear(clear),.crypto_enable(crypto_enable),
          .crypto_key(crypto_key),.crypto_nonce(crypto_nonce),.cmd_fire(ar_fire),
          .cmd_addr(ar_addr),.s_valid(s_valid&&stream_can_accept),.s_ready(ctr_ready),
          .s_data(s_data),.s_keep(s_keep),.s_last(s_last),.m_valid(m_valid),
          .m_ready(m_ready),.m_data(m_data),.m_keep(m_keep),.m_last(m_last),
          .block_req_valid(ctr_block_req_valid),.block_req_ready(ctr_block_req_ready),
          .block_req_key(ctr_block_req_key),.block_req_data(ctr_block_req_data),
          .block_req_tag(ctr_block_req_tag),.block_rsp_valid(ctr_block_rsp_valid),
          .block_rsp_ready(ctr_block_rsp_ready),.block_rsp_data(ctr_block_rsp_data),
          .block_rsp_tag(ctr_block_rsp_tag),.fault(ctr_client_fault),
          .fault_code(ctr_client_fault_code),.stat_beats(stat_beats),
          .stat_stall_cycles(stat_stall_cycles));
    end else if(CTR_LANES==1&&CTR_SERIAL_HALVES==1)begin:g_ctr_serial
      assign ctr_block_req_valid=1'b0;assign ctr_block_req_key=128'd0;
      assign ctr_block_req_data=128'd0;assign ctr_block_req_tag={SERVICE_TAG_W{1'b0}};
      assign ctr_block_rsp_ready=1'b0;assign ctr_client_fault=1'b0;
      assign ctr_client_fault_code=8'd0;
      v829_secure_stream_sm4_ctr_serial #(.DATA_WIDTH(DATA_WIDTH),.KEEP_WIDTH(KEEP_WIDTH))u_ctr(
          .clk(clk),.rst_n(rst_n),.clear(clear),.crypto_enable(crypto_enable),
          .crypto_key(crypto_key),.crypto_nonce(crypto_nonce),.cmd_fire(ar_fire),
          .cmd_addr(ar_addr),.s_valid(s_valid&&stream_can_accept),.s_ready(ctr_ready),
          .s_data(s_data),.s_keep(s_keep),.s_last(s_last),.m_valid(m_valid),
          .m_ready(m_ready),.m_data(m_data),.m_keep(m_keep),.m_last(m_last),
          .stat_beats(stat_beats),.stat_stall_cycles(stat_stall_cycles));
    end else if(CTR_LANES==1)begin:g_ctr1
      assign ctr_block_req_valid=1'b0;assign ctr_block_req_key=128'd0;
      assign ctr_block_req_data=128'd0;assign ctr_block_req_tag={SERVICE_TAG_W{1'b0}};
      assign ctr_block_rsp_ready=1'b0;assign ctr_client_fault=1'b0;
      assign ctr_client_fault_code=8'd0;
`ifdef V901_CACHED_2R_CTR
      v788_secure_stream_sm4_ctr #(.DATA_WIDTH(DATA_WIDTH),.KEEP_WIDTH(KEEP_WIDTH),
       .CORE_ROUNDS_PER_CYCLE(2))u_ctr(
`else
      v788_secure_stream_sm4_ctr #(.DATA_WIDTH(DATA_WIDTH),.KEEP_WIDTH(KEEP_WIDTH))u_ctr(
`endif
          .clk(clk),.rst_n(rst_n),.clear(clear),.crypto_enable(crypto_enable),
          .crypto_key(crypto_key),.crypto_nonce(crypto_nonce),.cmd_fire(ar_fire),
          .cmd_addr(ar_addr),.s_valid(s_valid&&stream_can_accept),.s_ready(ctr_ready),
          .s_data(s_data),.s_keep(s_keep),.s_last(s_last),.m_valid(m_valid),
          .m_ready(m_ready),.m_data(m_data),.m_keep(m_keep),.m_last(m_last),
          .stat_beats(stat_beats),.stat_stall_cycles(stat_stall_cycles));
    end else begin:g_ctr2
      assign ctr_block_req_valid=1'b0;assign ctr_block_req_key=128'd0;
      assign ctr_block_req_data=128'd0;assign ctr_block_req_tag={SERVICE_TAG_W{1'b0}};
      assign ctr_block_rsp_ready=1'b0;assign ctr_client_fault=1'b0;
      assign ctr_client_fault_code=8'd0;
`ifdef V901_CACHED_2R_CTR
      v790_secure_stream_sm4_ctr_2lane #(.DATA_WIDTH(DATA_WIDTH),.KEEP_WIDTH(KEEP_WIDTH),
       .CORE_ROUNDS_PER_CYCLE(2))u_ctr(
`else
      v790_secure_stream_sm4_ctr_2lane #(.DATA_WIDTH(DATA_WIDTH),.KEEP_WIDTH(KEEP_WIDTH))u_ctr(
`endif
          .clk(clk),.rst_n(rst_n),.clear(clear),.crypto_enable(crypto_enable),
          .crypto_key(crypto_key),.crypto_nonce(crypto_nonce),.cmd_fire(ar_fire),
          .cmd_addr(ar_addr),.s_valid(s_valid&&stream_can_accept),.s_ready(ctr_ready),
          .s_data(s_data),.s_keep(s_keep),.s_last(s_last),.m_valid(m_valid),
          .m_ready(m_ready),.m_data(m_data),.m_keep(m_keep),.m_last(m_last),
          .stat_beats(stat_beats),.stat_stall_cycles(stat_stall_cycles));
    end endgenerate

    assign s_ready=stream_can_accept&&(crypto_enable?ctr_ready:m_ready);

    generate if(MAC_EXTERNAL_SERVICE)begin:g_mac_external
      v854_sm4_cbc_mac256_external #(.TAG_W(SERVICE_TAG_W))u_mac(
          .clk(clk),.rst_n(rst_n),.clear(clear),
          .start(header_mac_start||common_header1_start||data_mac_start),.key(auth_key),
          .chain_in(header_mac_start?128'd0:chain_reg),
          .data_in(header_mac_start ? (common_auth_enable ? common_header_block_start : header_block) :
                   (common_header1_start ? common_header1_block : s_data)),
          .busy(mac_busy),.done(mac_done),.tag_out(mac_tag),
          .block_req_valid(mac_block_req_valid),.block_req_ready(mac_block_req_ready),
          .block_req_key(mac_block_req_key),.block_req_data(mac_block_req_data),
          .block_req_tag(mac_block_req_tag),.block_rsp_valid(mac_block_rsp_valid),
          .block_rsp_ready(mac_block_rsp_ready),.block_rsp_data(mac_block_rsp_data),
          .block_rsp_tag(mac_block_rsp_tag),.fault(mac_client_fault),
          .fault_code(mac_client_fault_code));
    end else if(MAC_SERIAL_CORE==1)begin:g_mac_serial
      assign mac_block_req_valid=1'b0;assign mac_block_req_key=128'd0;
      assign mac_block_req_data=128'd0;assign mac_block_req_tag={SERVICE_TAG_W{1'b0}};
      assign mac_block_rsp_ready=1'b0;assign mac_client_fault=1'b0;
      assign mac_client_fault_code=8'd0;
      v830_sm4_cbc_mac256_serial u_mac(
          .clk(clk),.rst_n(rst_n),.clear(clear),
          .start(header_mac_start||common_header1_start||data_mac_start),.key(auth_key),
          .chain_in(header_mac_start?128'd0:chain_reg),
          .data_in(header_mac_start ? (common_auth_enable ? common_header_block_start : header_block) :
                   (common_header1_start ? common_header1_block : s_data)),
          .busy(mac_busy),.done(mac_done),.tag_out(mac_tag));
    end else begin:g_mac_dual
      assign mac_block_req_valid=1'b0;assign mac_block_req_key=128'd0;
      assign mac_block_req_data=128'd0;assign mac_block_req_tag={SERVICE_TAG_W{1'b0}};
      assign mac_block_rsp_ready=1'b0;assign mac_client_fault=1'b0;
      assign mac_client_fault_code=8'd0;
`ifdef V900_CACHED_4R_LOAD_MAC
      // 80 MHz throughput point: retain the cached round-key architecture,
      // but execute four data rounds per cycle.  This keeps key expansion off
      // the steady-state path and halves the CBC-MAC block cycles versus V899.
      v789_sm4_cbc_mac256 #(.CORE_ROUNDS_PER_CYCLE(4)) u_mac(
`elsif V899_CACHED_2R_LOAD_MAC
      // Throughput recovery after V897 timing closure: the V896 core expands
      // and caches the 32 round keys once per key, then executes two data
      // rounds per cycle.  CBC dependence still serializes the two 128-bit
      // halves, but steady-state latency falls from roughly 128 to 32 cycles
      // per 256-bit beat without adding independent MAC lanes.
      v789_sm4_cbc_mac256 #(.CORE_ROUNDS_PER_CYCLE(2)) u_mac(
`elsif V876_FAST_LOAD_MAC
      // Frequency-first authenticated-load MAC: the one-round core itself is
      // split into key-schedule and data phases, so only one S-box/linear layer
      // remains on either cycle.  This replaces the former four-round chain.
      v789_sm4_cbc_mac256 #(.CORE_ROUNDS_PER_CYCLE(1)) u_mac(
`else
      v789_sm4_cbc_mac256 u_mac(
`endif
          .clk(clk),.rst_n(rst_n),.clear(clear),
          .start(header_mac_start||common_header1_start||data_mac_start),.key(auth_key),
          .chain_in(header_mac_start?128'd0:chain_reg),
          .data_in(header_mac_start ? (common_auth_enable ? common_header_block_start : header_block) :
                   (common_header1_start ? common_header1_block : s_data)),
          .busy(mac_busy),.done(mac_done),.tag_out(mac_tag));
    end endgenerate

    always @(posedge clk)begin
        if(!rst_n||clear)begin
            chain_reg<=0;expected_reg<=0;beats_expected<=0;beats_seen<=0;
            load_active<=0;header_inflight<=0;header_ready<=0;last_pending<=0;common_header_pending<=0;
            common_auth_enable_reg<=0;common_object_context_reg<=0;
            common_dtype_reg<=0;common_role_reg<=0;common_key_id_reg<=0;
            auth_done<=0;auth_ok<=0;auth_fail<=0;computed_tag<=0;
        end else begin
            auth_done<=0;
            if(service_client_fault)begin
                auth_done<=1;auth_ok<=0;auth_fail<=1;load_active<=0;
                header_inflight<=0;header_ready<=0;last_pending<=0;
                common_header_pending<=0;
            end
            if(load_fire)begin
                if(auth_enable&&(!expected_valid||!auth_load_idle||load_beats==0))begin
                    // A missing context tag, overlapping command, or empty
                    // authenticated load is rejected before any AXI AR can
                    // leave the shell.
                    auth_done<=1;auth_ok<=0;auth_fail<=1;
                end else begin
                    chain_reg<=0;expected_reg<=expected_tag;beats_expected<=load_beats;
                    beats_seen<=0;load_active<=auth_enable;header_inflight<=auth_enable;
                    common_header_pending<=0;
                    common_auth_enable_reg<=common_auth_enable;
                    common_object_context_reg<=common_object_context;
                    common_dtype_reg<=common_dtype;common_role_reg<=common_role;
                    common_key_id_reg<=common_key_id;
                    header_ready<=!auth_enable;last_pending<=0;auth_ok<=!auth_enable;
                    auth_fail<=0;computed_tag<=0;
                end
            end
            if(accept&&auth_enable)begin
                if(!count_available)begin auth_fail<=1;load_active<=0;end
                else begin
                    beats_seen<=beats_seen+1'b1;
                    if(beats_seen+1'b1==beats_expected)last_pending<=1'b1;
                end
            end
            if(mac_done)begin
                chain_reg<=mac_tag;
                if(header_inflight)begin
                    header_inflight<=0;
                    if(common_auth_enable_reg)begin
                        common_header_pending<=1;header_ready<=0;
                    end else begin
                        header_ready<=1;
                    end
                end else if(common_header_pending)begin
                    common_header_pending<=0;header_ready<=1;
                end else if(load_active&&last_pending)begin
                    computed_tag<=mac_tag;auth_done<=1;load_active<=0;last_pending<=0;
                    if(mac_tag==expected_reg)begin auth_ok<=1;auth_fail<=0;end
                    else begin auth_ok<=0;auth_fail<=1;end
                end
            end
        end
    end
endmodule

// V830: the two halves of CBC-MAC are dependent, so one iterative SM4 core
// can process them serially without removing any true parallelism.
module v830_sm4_cbc_mac256_serial(
 input wire clk,input wire rst_n,input wire clear,input wire start,
 input wire[127:0]key,input wire[127:0]chain_in,input wire[255:0]data_in,
 output wire busy,output reg done,output reg[127:0]tag_out
);
localparam ST_IDLE=2'd0,ST_FIRST=2'd1,ST_SECOND=2'd2;
reg[1:0]state;reg active,core_start;reg[127:0]key_reg,core_input,second_block;
wire core_busy,core_done;wire[127:0]core_output;
assign busy=active;
v788_sm4_encrypt_iter u_core(.clk(clk),.rst_n(rst_n),.start(core_start),.key(key_reg),
 .block_in(core_input),.busy(core_busy),.done(core_done),.block_out(core_output));
always@(posedge clk)begin
 if(!rst_n)begin state<=ST_IDLE;active<=0;core_start<=0;key_reg<=0;core_input<=0;
  second_block<=0;done<=0;tag_out<=0;end
 else if(clear)begin state<=ST_IDLE;active<=0;core_start<=0;done<=0;end
 else begin
  core_start<=0;done<=0;
  if(start&&!active)begin active<=1;state<=ST_FIRST;key_reg<=key;
   core_input<=data_in[255:128]^chain_in;second_block<=data_in[127:0];core_start<=1;end
  else if(state==ST_FIRST&&core_done)begin core_input<=second_block^core_output;core_start<=1;state<=ST_SECOND;end
  else if(state==ST_SECOND&&core_done)begin tag_out<=core_output;active<=0;state<=ST_IDLE;done<=1;end
 end
end
endmodule

// V829: one iterative SM4 core serializes the lower and upper 128-bit halves
// of a 256-bit CTR beat.  This is intended for schedules whose authentication
// stage already admits no more than one beat per two SM4 operations.
module v829_secure_stream_sm4_ctr_serial #(
 parameter DATA_WIDTH=256,parameter KEEP_WIDTH=DATA_WIDTH/8
)(
 input wire clk,input wire rst_n,input wire clear,input wire crypto_enable,
 input wire[127:0]crypto_key,input wire[95:0]crypto_nonce,
 input wire cmd_fire,input wire[31:0]cmd_addr,input wire s_valid,output wire s_ready,
 input wire[DATA_WIDTH-1:0]s_data,input wire[KEEP_WIDTH-1:0]s_keep,input wire s_last,
 output wire m_valid,input wire m_ready,output wire[DATA_WIDTH-1:0]m_data,
 output wire[KEEP_WIDTH-1:0]m_keep,output wire m_last,
 output reg[31:0]stat_beats,output reg[31:0]stat_stall_cycles
);
localparam ST_IDLE=2'd0,ST_LO=2'd1,ST_HI=2'd2;
reg[1:0]state;reg[127:0]ctr_reg,beat_counter,core_input,ks_lo;
reg[255:0]payload_reg,out_data_reg;reg[KEEP_WIDTH-1:0]keep_reg;reg last_reg,out_valid_reg,core_start;
wire[127:0]cmd_counter={crypto_nonce,4'b0000,cmd_addr[31:4]};
wire[127:0]accept_counter=cmd_fire?cmd_counter:ctr_reg;
wire core_busy,core_done;wire[127:0]core_output;
wire encrypted_active=crypto_enable||(state!=ST_IDLE)||out_valid_reg;
wire encrypted_accept=crypto_enable&&s_valid&&s_ready;
assign s_ready=encrypted_active?((state==ST_IDLE)&&!out_valid_reg&&!core_busy):m_ready;
assign m_valid=encrypted_active?out_valid_reg:s_valid;
assign m_data=encrypted_active?out_data_reg:s_data;assign m_keep=encrypted_active?keep_reg:s_keep;
assign m_last=encrypted_active?last_reg:s_last;
v788_sm4_encrypt_iter u_core(.clk(clk),.rst_n(rst_n),.start(core_start),.key(crypto_key),
 .block_in(core_input),.busy(core_busy),.done(core_done),.block_out(core_output));
wire[255:0]serial_keystream={core_output,ks_lo};
integer bi;reg[255:0]serial_xor;
always@*begin serial_xor=payload_reg;for(bi=0;bi<KEEP_WIDTH;bi=bi+1)
 if(keep_reg[bi])serial_xor[bi*8+:8]=payload_reg[bi*8+:8]^serial_keystream[bi*8+:8];end
always@(posedge clk)begin
 if(!rst_n)begin state<=ST_IDLE;ctr_reg<=0;beat_counter<=0;core_input<=0;ks_lo<=0;
  payload_reg<=0;keep_reg<=0;last_reg<=0;out_valid_reg<=0;out_data_reg<=0;core_start<=0;
  stat_beats<=0;stat_stall_cycles<=0;end
 else if(clear)begin state<=ST_IDLE;ctr_reg<=0;out_valid_reg<=0;core_start<=0;stat_beats<=0;stat_stall_cycles<=0;end
 else begin
  core_start<=0;if(cmd_fire)ctr_reg<=cmd_counter;
  if(encrypted_accept)begin payload_reg<=s_data;keep_reg<=s_keep;last_reg<=s_last;
   beat_counter<=accept_counter;core_input<=accept_counter;core_start<=1;ctr_reg<=accept_counter+2;state<=ST_LO;end
  if(state==ST_LO&&core_done)begin ks_lo<=core_output;core_input<=beat_counter+1;core_start<=1;state<=ST_HI;end
  if(state==ST_HI&&core_done)begin out_data_reg<=serial_xor;out_valid_reg<=1;state<=ST_IDLE;end
  if(out_valid_reg&&m_ready)out_valid_reg<=0;
  if(s_valid&&s_ready)stat_beats<=stat_beats+1'b1;
  if(s_valid&&!s_ready)stat_stall_cycles<=stat_stall_cycles+1'b1;
 end
end
endmodule
