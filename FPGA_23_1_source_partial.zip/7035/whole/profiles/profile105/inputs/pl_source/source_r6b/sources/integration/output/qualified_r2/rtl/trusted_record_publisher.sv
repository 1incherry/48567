`timescale 1ns/1ps
// Captures the ACTUAL private PL bank one edge after its atomic commit. No PS
// input, key bits, tensors, frame configuration or classifier verdict injection.
module trusted_record_publisher(
 input wire clk,security_reset_n,authorization_live,frame_start,
 input wire record_commit,record_visible,
 input wire [31:0] record_camera,record_session,record_frame,record_epoch,
 input wire [127:0] record_key_session,input wire [2:0] record_count,
 input wire [895:0] record_rois,input wire [51:0] record_indices,input wire [511:0] record_results,
 input wire tx_ready,pixel_ready,
 output wire snapshot_valid,output reg [2047:0] snapshot_data,
 output wire admission_ready,quiescent,display_current_live,
 output reg fault,output reg [31:0] sequence_id
);
 reg pending,display_current;
 integer i;
 wire publish_live=authorization_live&&record_visible&&!frame_start&&!fault;
 assign snapshot_valid=pending&&publish_live&&record_count<=4&&tx_ready&&pixel_ready;
 assign admission_ready=!pending&&tx_ready&&pixel_ready&&!record_commit&&!fault;
 assign quiescent=!pending&&tx_ready&&pixel_ready;
 assign display_current_live=display_current&&publish_live;
 // High bits are transmitted first. The 256-byte body is fully specified.
 always @* begin
  snapshot_data=0;
  snapshot_data[2047-0*8-:32]=32'h4e545232; // NTR2
  snapshot_data[2047-4*8-:32]=32'h00020001; // version2 / PL-origin record
  snapshot_data[2047-8*8-:32]=sequence_id+1'b1;
  snapshot_data[2047-12*8-:32]=record_camera;
  snapshot_data[2047-16*8-:32]=record_session;
  snapshot_data[2047-20*8-:32]=record_frame;
  snapshot_data[2047-24*8-:32]=record_epoch;
  snapshot_data[2047-28*8-:32]={29'd0,record_count};
  snapshot_data[2047-32*8-:128]=record_key_session;
  // The ACTUAL private result bank already zeros every unused slot atomically.
  // Copy those protected bits; do not duplicate a per-bit count mask here.
  for(i=0;i<4;i=i+1)begin
   snapshot_data[2047-(48+i*28)*8-:224]=record_rois[i*224+:224];
   snapshot_data[2047-(160+i*2)*8-:16]={3'd0,record_indices[i*13+:13]};
   snapshot_data[2047-(168+i*16)*8-:128]=record_results[i*128+:128];
  end
 end
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin pending<=0;display_current<=0;fault<=0;sequence_id<=0;end
  else begin
   if(!authorization_live||!record_visible||frame_start)display_current<=0;
   if(pending&&!publish_live)pending<=0;
   if(pending&&record_visible&&record_count>4)begin fault<=1;pending<=0;end
   if(frame_start&&!admission_ready)fault<=1;
   if(snapshot_valid)begin pending<=0;display_current<=1;sequence_id<=sequence_id+1'b1;end
   if(record_commit)begin
    if(pending||sequence_id==32'hffffffff)fault<=1;
    else if(authorization_live&&!frame_start)begin pending<=1;display_current<=0;end
   end
  end
 end
endmodule
