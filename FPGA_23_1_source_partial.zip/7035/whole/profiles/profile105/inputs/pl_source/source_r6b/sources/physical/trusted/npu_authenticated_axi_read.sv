`timescale 1ns/1ps
// Kernel AXI read termination using ONLY the model service's private verified
// page. PS/DDR supplies proof bytes to that service, never valid/tag verdicts.
// expected_* are PL microcode outputs; no PS register path may drive them.
module npu_authenticated_axi_read #(
 parameter POLICY_FILE="static_read_policy.mem",
 parameter integer TIMEOUT_CYCLES=1000000
)(input wire clk,rst_n,clear,cancel,model_authorized,
 input wire [31:0] session_epoch,
 input wire [8:0] expected_object,
 input wire [3:0] expected_kind,expected_block,expected_qkv_op,
 input wire [4:0] expected_dst,expected_stage,
 input wire [31:0] s_araddr,input wire [7:0] s_arlen,
 input wire [2:0] s_arsize,input wire [1:0] s_arburst,
 input wire s_arvalid,output wire s_arready,
 output wire [255:0] s_rdata,output wire [1:0] s_rresp,
 output wire s_rlast,s_rvalid,input wire s_rready,
 output wire page_request,input wire page_request_ready,
 output wire [31:0] expected_page_index,
 input wire cache_valid,input wire [31:0] cached_page_index,
 output wire cache_read,output wire [9:0] cache_read_addr,
 input wire cache_read_valid,input wire [31:0] cache_read_data,
 output reg fault,output wire quiescent
);
 localparam IDLE=0,CHECK=1,PAGE=2,WORD_REQ=3,WORD_WAIT=4,REPLY=5;
 (* rom_style="block" *) reg [127:0] policy[0:511];
 initial $readmemh(POLICY_FILE,policy);
 reg [127:0] record;
 reg [2:0] state;
 reg [31:0] epoch,address,ticks,page;
 reg [8:0] object_id;
 reg [21:0] saved_context;
 reg [7:0] length,remaining;
 reg [2:0] size,word_lane;
 reg [1:0] burst;
 reg [9:0] word_address;
 reg bad,page_sent,page_wrap;
 reg [255:0] data;
 wire [21:0] current_context={expected_stage,expected_qkv_op,expected_dst,expected_block,expected_kind};
 wire live=(model_authorized===1'b1)&&(session_epoch===epoch)&&!cancel&&
           (expected_object===object_id)&&(current_context===saved_context);
 wire [32:0] offset={1'b0,address}-{1'b0,record[31:0]};
 wire [13:0] burst_bytes=({6'd0,length}+14'd1)*14'd32;
 wire [32:0] end_offset=offset+{19'd0,burst_bytes};
 wire [3:0] saved_kind=saved_context[3:0],saved_block=saved_context[7:4],saved_qkv=saved_context[16:13];
 wire [4:0] saved_dst=saved_context[12:8],saved_stage=saved_context[21:17];
 wire allowed=record[91]&&record[72:69]==saved_kind&&record[76:73]==saved_block&&
  record[81:77]==saved_dst&&record[85:82]==saved_qkv&&record[90:86]==saved_stage&&
  address>=record[31:0]&&end_offset<={9'd0,record[55:32]}&&
  address[4:0]==0&&size==5&&burst==1&&
  {2'd0,address[11:0]}+burst_bytes<=14'd4096;
 wire correct_page=(cache_valid===1'b1)&&(cached_page_index===page);
 wire [31:0] logical_memory_word={cache_read_data[7:0],cache_read_data[15:8],cache_read_data[23:16],cache_read_data[31:24]};
 assign quiescent=rst_n&&state==IDLE;
 assign s_arready=rst_n&&state==IDLE&&!clear;
 assign s_rvalid=rst_n&&state==REPLY;
 assign s_rdata=s_rvalid&&!bad&&live&&!clear?data:256'd0;
 assign s_rresp=bad||!live||clear?2'b10:2'b00;
 assign s_rlast=s_rvalid&&remaining==0;
 assign page_request=state==PAGE&&!page_sent&&!bad&&live&&!correct_page&&rst_n;
 assign expected_page_index=page;
 assign cache_read=state==WORD_REQ&&!bad&&live&&correct_page&&rst_n;
 assign cache_read_addr=word_address;
 always @(posedge clk)begin
  if(s_arvalid&&s_arready)record<=policy[expected_object];
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;epoch<=0;address<=0;ticks<=0;page<=0;object_id<=0;saved_context<=0;
   length<=0;remaining<=0;size<=0;word_lane<=0;burst<=0;word_address<=0;
   bad<=0;page_sent<=0;page_wrap<=0;data<=0;fault<=0;
  end else begin
   if(clear)begin if(state==IDLE)fault<=0;else begin fault<=1;bad<=1;end end
   if(state!=IDLE)begin
    ticks<=ticks+1'b1;
    if(!live||clear||ticks>=TIMEOUT_CYCLES)begin bad<=1;fault<=1;end
   end
   case(state)
    IDLE:if(s_arvalid&&s_arready)begin
     epoch<=session_epoch;object_id<=expected_object;saved_context<=current_context;
     address<=s_araddr;length<=s_arlen;remaining<=s_arlen;size<=s_arsize;burst<=s_arburst;
     bad<=fault||(model_authorized!==1'b1)||cancel;data<=0;ticks<=0;word_lane<=0;
     page_sent<=0;page_wrap<=0;state<=CHECK;
    end
    CHECK:begin
     if(bad||!live||clear||(allowed!==1'b1))begin bad<=1;fault<=1;state<=REPLY;end
     else begin page<={19'd0,record[68:56]}+(offset>>12);word_address<=offset[11:2];state<=PAGE;end
    end
    PAGE:begin
     if(bad||!live||clear)begin state<=REPLY;data<=0;end
     else if(correct_page)begin page_sent<=0;state<=WORD_REQ;end
     else if(page_request&&page_request_ready)page_sent<=1;
    end
    WORD_REQ:begin
     if(bad||!live||clear||!correct_page)begin bad<=1;fault<=1;state<=REPLY;data<=0;end
     else state<=WORD_WAIT;
    end
    WORD_WAIT:begin
     if(bad||!live||clear||!correct_page)begin bad<=1;fault<=1;state<=REPLY;data<=0;end
     else if(cache_read_valid)begin
      if(record[92])data[(7-word_lane)*32 +:32]<=logical_memory_word;
      else data[word_lane*32 +:32]<=logical_memory_word;
      word_address<=word_address+1'b1;
      if(word_address==1023)page_wrap<=1;
      if(word_lane==7)begin word_lane<=0;state<=REPLY;end
      else begin word_lane<=word_lane+1'b1;state<=WORD_REQ;end
     end
    end
    REPLY:if(s_rready)begin
     if(remaining==0)state<=IDLE;
     else begin
      remaining<=remaining-1'b1;data<=0;
      if(bad||!live||clear)state<=REPLY;
      else if(page_wrap)begin page<=page+1'b1;page_wrap<=0;state<=PAGE;end
      else state<=WORD_REQ;
     end
    end
    default:begin state<=IDLE;fault<=1;end
   endcase
  end
 end
endmodule
