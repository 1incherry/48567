`timescale 1ns/1ps
`define V787_FC1_B_LUTRAM_PREFETCH
`include "source_r6b/sources/physical/core/secure_gemm_v0/v787_distributed_i8_banks.v"
`include "source_r6b/sources/physical/core/v786_add_this_one_file.v"
