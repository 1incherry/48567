`timescale 1ns/1ps

module v711_axi256_qkv_loader (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,

    input  wire         cmd_valid,
    output wire         cmd_ready,
    input  wire [1:0]   cmd_dst,
    input  wire [3:0]   cmd_block_id,
    input  wire [3:0]   cmd_op_id,
    input  wire [31:0]  cmd_axi_addr,
    input  wire [11:0]  cmd_local_addr,
    input  wire [15:0]  cmd_beats,
    input  wire [7:0]   cmd_burst_len_m1,
    output reg          busy,
    output reg          done,
    output reg [31:0]   stat_cmds,
    output reg [31:0]   stat_beats,
    output reg [31:0]   stat_errors,
    output reg [31:0]   stat_axi_inflight_peak,
    output reg [31:0]   stat_a_max_addr,
    output reg [31:0]   stat_b_max_addr,
    output reg [31:0]   stat_scale_max_beat,

    output reg  [31:0]  m_axi_araddr,
    output reg  [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output reg          m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [255:0] m_axi_rdata,
    input  wire         m_axi_rvalid,
    output reg          m_axi_rready,
    input  wire         m_axi_rlast,

    output reg          a_wr_valid,
    output reg  [3:0]   a_wr_block_id,
    output reg  [11:0]  a_wr_addr,
    output reg  [255:0] a_wr_data,

    output reg          b_wr_valid,
    output reg  [3:0]   b_wr_block_id,
    output reg  [3:0]   b_wr_op_id,
    output reg  [9:0]   b_wr_addr,
    output reg  [255:0] b_wr_data,

    output reg          scale_wr_valid,
    output reg  [7:0]   scale_wr_beat_addr,
    output reg  [255:0] scale_wr_data
);

localparam DST_A     = 2'd0;
localparam DST_B     = 2'd1;
localparam DST_SCALE = 2'd2;

localparam ST_IDLE = 2'd0;
localparam ST_AR   = 2'd1;
localparam ST_R    = 2'd2;
localparam ST_DONE = 2'd3;

reg [1:0] state;
reg [1:0] active_dst;
reg [3:0] active_block_id;
reg [3:0] active_op_id;
reg [31:0] cur_axi_addr;
reg [11:0] cur_local_addr;
reg [15:0] remaining_beats;
reg [8:0] max_burst_beats;
reg [8:0] burst_beats;
reg [8:0] burst_left;
reg [31:0] inflight_beats;

assign cmd_ready = (state == ST_IDLE);
assign m_axi_arsize = 3'd5;
assign m_axi_arburst = 2'b01;

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        busy <= 1'b0;
        done <= 1'b0;
        stat_cmds <= 32'd0;
        stat_beats <= 32'd0;
        stat_errors <= 32'd0;
        stat_axi_inflight_peak <= 32'd0;
        stat_a_max_addr <= 32'd0;
        stat_b_max_addr <= 32'd0;
        stat_scale_max_beat <= 32'd0;
        m_axi_araddr <= 32'd0;
        m_axi_arlen <= 8'd0;
        m_axi_arvalid <= 1'b0;
        m_axi_rready <= 1'b0;
        a_wr_valid <= 1'b0;
        b_wr_valid <= 1'b0;
        scale_wr_valid <= 1'b0;
        a_wr_block_id <= 4'd0;
        b_wr_block_id <= 4'd0;
        b_wr_op_id <= 4'd0;
        a_wr_addr <= 12'd0;
        b_wr_addr <= 10'd0;
        scale_wr_beat_addr <= 8'd0;
        a_wr_data <= 256'd0;
        b_wr_data <= 256'd0;
        scale_wr_data <= 256'd0;
        active_dst <= 2'd0;
        active_block_id <= 4'd0;
        active_op_id <= 4'd0;
        cur_axi_addr <= 32'd0;
        cur_local_addr <= 12'd0;
        remaining_beats <= 16'd0;
        max_burst_beats <= 9'd1;
        burst_beats <= 9'd0;
        burst_left <= 9'd0;
        inflight_beats <= 32'd0;
    end else begin
        done <= 1'b0;
        a_wr_valid <= 1'b0;
        b_wr_valid <= 1'b0;
        scale_wr_valid <= 1'b0;

        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            done <= 1'b0;
            stat_cmds <= 32'd0;
            stat_beats <= 32'd0;
            stat_errors <= 32'd0;
            stat_axi_inflight_peak <= 32'd0;
            stat_a_max_addr <= 32'd0;
            stat_b_max_addr <= 32'd0;
            stat_scale_max_beat <= 32'd0;
            m_axi_arvalid <= 1'b0;
            m_axi_rready <= 1'b0;
            inflight_beats <= 32'd0;
        end else begin
            if (state == ST_IDLE) begin
                busy <= 1'b0;
                m_axi_arvalid <= 1'b0;
                m_axi_rready <= 1'b0;
                if (cmd_valid) begin
                    busy <= 1'b1;
                    active_dst <= cmd_dst;
                    active_block_id <= cmd_block_id;
                    active_op_id <= cmd_op_id;
                    cur_axi_addr <= cmd_axi_addr;
                    cur_local_addr <= cmd_local_addr;
                    remaining_beats <= cmd_beats;
                    max_burst_beats <= {1'b0, cmd_burst_len_m1} + 9'd1;
                    stat_cmds <= stat_cmds + 1'b1;
                    if ((cmd_beats == 16'd0) || (cmd_dst > DST_SCALE) ||
                        (cmd_block_id > 4'd11) || ((cmd_dst == DST_B) && (cmd_op_id > 4'd8))) begin
                        stat_errors <= stat_errors + 1'b1;
                        state <= ST_DONE;
                    end else begin
                        state <= ST_AR;
                    end
                end
            end else if (state == ST_AR) begin
                busy <= 1'b1;
                m_axi_rready <= 1'b0;
                if (!m_axi_arvalid) begin
                    m_axi_araddr <= cur_axi_addr;
                    if (remaining_beats > {7'd0, max_burst_beats})
                        burst_beats <= max_burst_beats;
                    else
                        burst_beats <= remaining_beats[8:0];
                    if (remaining_beats > {7'd0, max_burst_beats})
                        m_axi_arlen <= max_burst_beats[7:0] - 1'b1;
                    else
                        m_axi_arlen <= remaining_beats[7:0] - 1'b1;
                    m_axi_arvalid <= 1'b1;
                end
                if (m_axi_arvalid && m_axi_arready) begin
                    m_axi_arvalid <= 1'b0;
                    m_axi_rready <= 1'b1;
                    burst_left <= burst_beats;
                    inflight_beats <= {23'd0, burst_beats};
                    if ({23'd0, burst_beats} > stat_axi_inflight_peak)
                        stat_axi_inflight_peak <= {23'd0, burst_beats};
                    state <= ST_R;
                end
            end else if (state == ST_R) begin
                busy <= 1'b1;
                m_axi_rready <= 1'b1;
                // Consume an AXI beat only on a real VALID/READY handshake.
                // The normal implementation keeps READY high in ST_R, but
                // retaining the qualifier is required for legal downstream
                // stalls and prevents repeated local-bank writes while VALID
                // is held stable.
                if (m_axi_rvalid && m_axi_rready) begin
                    stat_beats <= stat_beats + 1'b1;
                    if (active_dst == DST_A) begin
                        a_wr_valid <= 1'b1;
                        a_wr_block_id <= active_block_id;
                        a_wr_addr <= cur_local_addr;
                        a_wr_data <= m_axi_rdata;
                        if ({20'd0, cur_local_addr} > stat_a_max_addr)
                            stat_a_max_addr <= {20'd0, cur_local_addr};
                    end else if (active_dst == DST_B) begin
                        b_wr_valid <= 1'b1;
                        b_wr_block_id <= active_block_id;
                        b_wr_op_id <= active_op_id;
                        b_wr_addr <= cur_local_addr[9:0];
                        b_wr_data <= m_axi_rdata;
                        if ({22'd0, cur_local_addr[9:0]} > stat_b_max_addr)
                            stat_b_max_addr <= {22'd0, cur_local_addr[9:0]};
                    end else begin
                        scale_wr_valid <= 1'b1;
                        scale_wr_beat_addr <= cur_local_addr[7:0];
                        scale_wr_data <= m_axi_rdata;
                        if ({24'd0, cur_local_addr[7:0]} > stat_scale_max_beat)
                            stat_scale_max_beat <= {24'd0, cur_local_addr[7:0]};
                    end

                    cur_axi_addr <= cur_axi_addr + 32'd32;
                    cur_local_addr <= cur_local_addr + 1'b1;
                    remaining_beats <= remaining_beats - 1'b1;
                    burst_left <= burst_left - 1'b1;
                    if (inflight_beats != 32'd0)
                        inflight_beats <= inflight_beats - 1'b1;

                    if ((burst_left == 9'd1) || m_axi_rlast) begin
                        m_axi_rready <= 1'b0;
                        if (remaining_beats == 16'd1)
                            state <= ST_DONE;
                        else
                            state <= ST_AR;
                    end
                end
            end else begin
                busy <= 1'b0;
                done <= 1'b1;
                m_axi_arvalid <= 1'b0;
                m_axi_rready <= 1'b0;
                state <= ST_IDLE;
            end
        end
    end
end

endmodule
