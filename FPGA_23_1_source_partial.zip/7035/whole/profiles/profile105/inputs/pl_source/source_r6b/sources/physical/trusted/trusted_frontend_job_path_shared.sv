`timescale 1ns/1ps
// PL NMS job -> bound ROI -> real authenticated frontend -> existing private seed/ViT.
// Consumer signals MUST be wired to the existing trusted ViT sequencer/handoff, never PS.
// This module adds no duplicate A/B, Norm, ViT private banks, SHA or SM4 core.
module trusted_frontend_job_path_shared #(parameter POLICY_ROM="model_object_policy_v2.mem",parameter [31:0] TIMEOUT_CYCLES=1000000000)(
input wire  clk,
input wire  rst_n,
input wire  authorized,
input wire  key_valid,
input wire [31:0] authorization_epoch,
input wire  job_valid,
output wire  job_ready,
input wire  job_cancel,
input wire [31:0] job_camera_id,
input wire [31:0] job_session,
input wire [31:0] job_frame,
input wire [31:0] job_epoch,
input wire [31:0] job_roi_index,
input wire [15:0] job_x,
input wire [15:0] job_y,
input wire [15:0] job_width,
input wire [15:0] job_height,
output wire  job_active,
output wire  job_quiescent,
output wire memory_quiet,
output wire seed_wait,
output wire frontend_busy,
output reg job_done,
output reg job_failed,
output reg [7:0] failure_code,
output wire  prepare_seed,
output wire  frontend_owner,
output wire  consumer_start,
output wire  consumer_cancel,
input wire  private_seed_ready,
input wire  private_seed_fault,
input wire  compute_quiescent,
input wire  consumer_ready,
input wire  consumer_active,
input wire  consumer_done,
input wire  consumer_fault,
input wire  consumer_quiescent,
input wire  consumer_result_valid,
input wire [31:0] consumer_result_frame,
input wire [31:0] consumer_result_epoch,
input wire [7:0] consumer_result_class,
input wire [63:0] consumer_result_logit,
output reg [7:0] result_class,
output reg [63:0] result_logit,
output wire  a_write,
output wire  b_write,
output wire  a_read,
output wire  b_read,
output wire [11:0] write_address,
output wire [11:0] a_address,
output wire [11:0] b_address,
output wire [255:0] write_data,
input wire [255:0] a_data,
input wire [255:0] b_data,
output wire  norm_clear,
output wire  norm_start,
output wire  norm_input_valid,
output wire [15:0] norm_input_address,
output wire [15:0] norm_input_data,
output wire  norm_scale_valid,
output wire  norm_bias_valid,
output wire [7:0] norm_param_address,
output wire [31:0] norm_param_data,
output wire  norm_ready,
input wire  norm_valid,
input wire  norm_done,
output wire [31:0] perf_total,
output wire [31:0] perf_param,
output wire [31:0] perf_resize,
output wire [31:0] perf_embed,
output wire [31:0] perf_norm,
output wire [31:0] perf_ar,
output wire [31:0] perf_aw,
input wire [15:0] norm_address,
input wire [15:0] norm_data,
output wire [31:0] M_AXI_ARADDR,
output wire [7:0] M_AXI_ARLEN,
output wire [2:0] M_AXI_ARSIZE,
output wire [1:0] M_AXI_ARBURST,
output wire  M_AXI_ARVALID,
input wire  M_AXI_ARREADY,
input wire [255:0] M_AXI_RDATA,
input wire [1:0] M_AXI_RRESP,
input wire  M_AXI_RLAST,
input wire  M_AXI_RVALID,
output wire  M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,
output wire [7:0] M_AXI_AWLEN,
output wire [2:0] M_AXI_AWSIZE,
output wire [1:0] M_AXI_AWBURST,
output wire  M_AXI_AWVALID,
input wire  M_AXI_AWREADY,
output wire [255:0] M_AXI_WDATA,
output wire [31:0] M_AXI_WSTRB,
output wire  M_AXI_WLAST,
output wire  M_AXI_WVALID,
input wire  M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,
input wire  M_AXI_BVALID,
output wire  M_AXI_BREADY,
output wire [31:0] context_generation,
output wire  generation_exhausted,
output wire  context_authorized,
output wire [31:0] context_camera_id,
output wire [31:0] context_session,
output wire [31:0] context_frame,
output wire [31:0] context_epoch,
output wire [31:0] context_roi_index,
output wire [15:0] context_roi_x,
output wire [15:0] context_roi_y,
output wire [15:0] context_roi_width,
output wire [15:0] context_roi_height,
output wire  exclusive_page_lock,
output wire  fetch_valid,
input wire  fetch_ready,
output wire [31:0] fetch_page_index,
output wire [31:0] fetch_page_address,
output wire [31:0] fetch_proof_address,
output wire  service_page_request,
input wire  service_page_ready,
output wire [31:0] service_expected_page,
input wire  service_page_done,
input wire  service_busy,
input wire  service_fault,
input wire  service_cache_valid,
input wire [31:0] service_cached_page,
output wire  service_cache_read,
output wire [9:0] service_cache_address,
input wire  service_cache_read_valid,
input wire [31:0] service_cache_read_data,
output wire  mac_request,
input wire  mac_ready,
output wire [127:0] mac_chain,
output wire [255:0] mac_data,
input wire  mac_response_valid,
input wire  mac_response_error,
input wire [127:0] mac_tag,
input wire  mac_quiescent
);
wire  f_busy;
wire  f_done;
wire  f_error;
wire  memory_context_quiet;
wire  memory_fault;
wire  bind_ready;
wire  bind_done;
wire  bind_verified;
wire  released;
wire  context_live;
wire  drain_cancel;
wire  producer_quiet;

localparam IDLE=0,BIND=1,LAUNCH=2,RUN=3,SEED=4,CONSUME=5,DRAIN=6;
reg [2:0] state;reg failed,consumer_started,consumer_seen_active,result_seen,terminal_seen;
reg [31:0] elapsed;
// Read-only observability for shared owner transfer; no FSM or math change.
assign seed_wait=state==SEED;
assign frontend_busy=f_busy;
assign context_live=context_authorized&&authorized&&key_valid&&authorization_epoch==context_epoch;
wire deadline_expired=elapsed>=TIMEOUT_CYCLES;
wire lifecycle_stop=job_cancel||!authorized||!key_valid||authorization_epoch!=context_epoch||deadline_expired;
wire stopping=job_cancel||!context_live||failed;
// A timeout/fault must close the actual producer/consumer START on that edge,
// before the sequential abort state is visible to the child.
wire launch_live=!stopping&&!deadline_expired&&!memory_fault&&
 (state==LAUNCH||(!private_seed_fault&&!f_error))&&(!consumer_started||!consumer_fault);
assign drain_cancel=job_cancel||state==DRAIN&&failed;
assign producer_quiet=!f_busy&&compute_quiescent&&consumer_quiescent;
assign job_ready=state==IDLE&&bind_ready&&authorized&&key_valid;
assign job_active=state!=IDLE;
assign job_quiescent=state==IDLE&&memory_context_quiet&&producer_quiet;
assign prepare_seed=state==LAUNCH&&launch_live;
// Keep the Norm mux with an aborted frontend until its actual clear/drain
// reaches the shared kernel. Ownership cannot jump on a software-style done.
assign frontend_owner=state==LAUNCH||state==RUN||state==SEED||state==DRAIN&&!consumer_started&&(f_busy||!compute_quiescent);
assign consumer_start=state==SEED&&private_seed_ready&&consumer_ready&&!consumer_done&&launch_live;
assign consumer_cancel=drain_cancel||state!=IDLE&&!context_live;
always @(posedge clk)begin
 if(!rst_n)begin state<=IDLE;failed<=0;elapsed<=0;consumer_started<=0;consumer_seen_active<=0;result_seen<=0;terminal_seen<=0;job_done<=0;job_failed<=0;failure_code<=0;result_class<=0;result_logit<=0;end
 else begin
  job_done<=0;job_failed<=0;
  if(state!=IDLE)elapsed<=elapsed+1;
  // Legacy producer/consumer errors can remain set until their next START.
  // LAUNCH must reach the real frontend before sampling its previous error;
  // the ViT fault likewise belongs to this job only after consumer START.
  if(state!=IDLE&&state!=BIND&&state!=DRAIN&&(stopping||memory_fault||state!=LAUNCH&&(private_seed_fault||f_error)||consumer_started&&consumer_fault||elapsed>=TIMEOUT_CYCLES))begin
   failed<=1;state<=DRAIN;failure_code<=job_cancel?8'h01:!context_live?8'h02:memory_fault?8'h03:state!=LAUNCH&&private_seed_fault?8'h04:state!=LAUNCH&&f_error?8'h05:consumer_started&&consumer_fault?8'h06:8'h07;
  end else case(state)
   IDLE:if(job_valid&&job_ready)begin state<=BIND;elapsed<=0;failed<=0;consumer_started<=0;consumer_seen_active<=0;result_seen<=0;terminal_seen<=0;failure_code<=0;result_class<=0;result_logit<=0;end
   BIND:if(bind_done)begin if(bind_verified&&!job_cancel)state<=LAUNCH;else begin failed<=1;failure_code<=8'h08;state<=DRAIN;end end
   LAUNCH:state<=RUN;
   RUN:if(f_done&&!f_busy&&memory_quiet)state<=SEED;
   SEED:if(consumer_start)begin consumer_started<=1;state<=CONSUME;end
   CONSUME:begin
    if(consumer_active)consumer_seen_active<=1;
    if(consumer_result_valid)begin
     if(consumer_result_epoch!=context_epoch||consumer_result_frame!=context_frame||result_seen)begin failed<=1;failure_code<=8'h09;state<=DRAIN;end
     else begin result_seen<=1;result_class<=consumer_result_class;result_logit<=consumer_result_logit;end
    end
    if(consumer_done&&consumer_seen_active)begin
     terminal_seen<=1;
     if(!result_seen&&!consumer_result_valid)begin failed<=1;failure_code<=8'h0a;end
     state<=DRAIN;
    end
   end
   DRAIN:begin
    // context_live intentionally drops during normal release. Global trust
    // revocation is separate and sticky throughout real memory/compute drain.
    if(lifecycle_stop)begin failed<=1;failure_code<=job_cancel?8'h01:deadline_expired?8'h07:8'h02;end
    if(released||memory_context_quiet&&producer_quiet)begin
     state<=IDLE;job_failed<=failed||!terminal_seen||lifecycle_stop;
     job_done<=!failed&&terminal_seen&&!lifecycle_stop;
    end
   end
   default:begin state<=DRAIN;failed<=1;failure_code<=8'hff;end
  endcase
 end
end

wire [1:0] F_M_AXI_ARPURPOSE;
wire [31:0] F_M_AXI_ARADDR;
wire [7:0] F_M_AXI_ARLEN;
wire [2:0] F_M_AXI_ARSIZE;
wire [1:0] F_M_AXI_ARBURST;
wire  F_M_AXI_ARVALID;
wire  F_M_AXI_ARREADY;
wire [255:0] F_M_AXI_RDATA;
wire [1:0] F_M_AXI_RRESP;
wire  F_M_AXI_RLAST;
wire  F_M_AXI_RVALID;
wire  F_M_AXI_RREADY;
wire [31:0] F_M_AXI_AWADDR;
wire [7:0] F_M_AXI_AWLEN;
wire [2:0] F_M_AXI_AWSIZE;
wire [1:0] F_M_AXI_AWBURST;
wire  F_M_AXI_AWVALID;
wire  F_M_AXI_AWREADY;
wire [255:0] F_M_AXI_WDATA;
wire [31:0] F_M_AXI_WSTRB;
wire  F_M_AXI_WLAST;
wire  F_M_AXI_WVALID;
wire  F_M_AXI_WREADY;
wire [1:0] F_M_AXI_BRESP;
wire  F_M_AXI_BVALID;
wire  F_M_AXI_BREADY;
trusted_frontend_ddr_engine #(.DISCARD_LEGACY_PRODUCTS(1)) frontend(.clk(clk),
.rst_n(rst_n),
.go(prepare_seed),
.cancel(drain_cancel),
.authorized(context_live),
.session_epoch(context_epoch),
.busy(f_busy),
.done(f_done),
.error(f_error),
.M_AXI_ARPURPOSE(F_M_AXI_ARPURPOSE),
.source_base(32'h22000000),
.source_stride(32'd5760),
.roi_xy({context_roi_y,context_roi_x}),
.roi_wh({context_roi_height,context_roi_width}),
.crop_base(32'h2c100000),
.temp_base(32'h2c000000),
.param_base(32'h29000000),
.seed_base(32'h27700000),
.pose_base(32'h27800000),
.x_base(32'h27900000),
.source_wh(32'h04380780),
.reserved(32'd0),
.M_AXI_ARADDR(F_M_AXI_ARADDR),
.M_AXI_ARLEN(F_M_AXI_ARLEN),
.M_AXI_ARSIZE(F_M_AXI_ARSIZE),
.M_AXI_ARBURST(F_M_AXI_ARBURST),
.M_AXI_ARVALID(F_M_AXI_ARVALID),
.M_AXI_ARREADY(F_M_AXI_ARREADY),
.M_AXI_RDATA(F_M_AXI_RDATA),
.M_AXI_RRESP(F_M_AXI_RRESP),
.M_AXI_RLAST(F_M_AXI_RLAST),
.M_AXI_RVALID(F_M_AXI_RVALID),
.M_AXI_RREADY(F_M_AXI_RREADY),
.M_AXI_AWADDR(F_M_AXI_AWADDR),
.M_AXI_AWLEN(F_M_AXI_AWLEN),
.M_AXI_AWSIZE(F_M_AXI_AWSIZE),
.M_AXI_AWBURST(F_M_AXI_AWBURST),
.M_AXI_AWVALID(F_M_AXI_AWVALID),
.M_AXI_AWREADY(F_M_AXI_AWREADY),
.M_AXI_WDATA(F_M_AXI_WDATA),
.M_AXI_WSTRB(F_M_AXI_WSTRB),
.M_AXI_WLAST(F_M_AXI_WLAST),
.M_AXI_WVALID(F_M_AXI_WVALID),
.M_AXI_WREADY(F_M_AXI_WREADY),
.M_AXI_BRESP(F_M_AXI_BRESP),
.M_AXI_BVALID(F_M_AXI_BVALID),
.M_AXI_BREADY(F_M_AXI_BREADY),
.a_write(a_write),
.b_write(b_write),
.a_read(a_read),
.b_read(b_read),
.write_address(write_address),
.a_address(a_address),
.b_address(b_address),
.write_data(write_data),
.a_data(a_data),
.b_data(b_data),
.norm_clear(norm_clear),
.norm_start(norm_start),
.norm_input_valid(norm_input_valid),
.norm_input_address(norm_input_address),
.norm_input_data(norm_input_data),
.norm_scale_valid(norm_scale_valid),
.norm_bias_valid(norm_bias_valid),
.norm_param_address(norm_param_address),
.norm_param_data(norm_param_data),
.norm_ready(norm_ready),
.norm_valid(norm_valid),
.norm_done(norm_done),
.perf_total(perf_total),
.perf_param(perf_param),
.perf_resize(perf_resize),
.perf_embed(perf_embed),
.perf_norm(perf_norm),
.perf_ar(perf_ar),
.perf_aw(perf_aw),
.norm_address(norm_address),
.norm_data(norm_data));
trusted_frontend_memory_path #(.POLICY_ROM(POLICY_ROM)) memory(.clk(clk),
.rst_n(rst_n),
.cancel(drain_cancel),
.authorized(authorized),
.key_valid(key_valid),
.authorization_epoch(authorization_epoch),
.producer_quiescent(producer_quiet),
.transaction_quiescent(memory_quiet),
.quiescent(memory_context_quiet),
.transaction_fault(memory_fault),
.S_AXI_ARPURPOSE(F_M_AXI_ARPURPOSE),
.S_AXI_ARADDR(F_M_AXI_ARADDR),
.S_AXI_ARLEN(F_M_AXI_ARLEN),
.S_AXI_ARSIZE(F_M_AXI_ARSIZE),
.S_AXI_ARBURST(F_M_AXI_ARBURST),
.S_AXI_ARVALID(F_M_AXI_ARVALID),
.S_AXI_ARREADY(F_M_AXI_ARREADY),
.S_AXI_RDATA(F_M_AXI_RDATA),
.S_AXI_RRESP(F_M_AXI_RRESP),
.S_AXI_RLAST(F_M_AXI_RLAST),
.S_AXI_RVALID(F_M_AXI_RVALID),
.S_AXI_RREADY(F_M_AXI_RREADY),
.S_AXI_AWADDR(F_M_AXI_AWADDR),
.S_AXI_AWLEN(F_M_AXI_AWLEN),
.S_AXI_AWSIZE(F_M_AXI_AWSIZE),
.S_AXI_AWBURST(F_M_AXI_AWBURST),
.S_AXI_AWVALID(F_M_AXI_AWVALID),
.S_AXI_AWREADY(F_M_AXI_AWREADY),
.S_AXI_WDATA(F_M_AXI_WDATA),
.S_AXI_WSTRB(F_M_AXI_WSTRB),
.S_AXI_WLAST(F_M_AXI_WLAST),
.S_AXI_WVALID(F_M_AXI_WVALID),
.S_AXI_WREADY(F_M_AXI_WREADY),
.S_AXI_BRESP(F_M_AXI_BRESP),
.S_AXI_BVALID(F_M_AXI_BVALID),
.S_AXI_BREADY(F_M_AXI_BREADY),
.M_AXI_ARADDR(M_AXI_ARADDR),
.M_AXI_ARLEN(M_AXI_ARLEN),
.M_AXI_ARSIZE(M_AXI_ARSIZE),
.M_AXI_ARBURST(M_AXI_ARBURST),
.M_AXI_ARVALID(M_AXI_ARVALID),
.M_AXI_ARREADY(M_AXI_ARREADY),
.M_AXI_RDATA(M_AXI_RDATA),
.M_AXI_RRESP(M_AXI_RRESP),
.M_AXI_RLAST(M_AXI_RLAST),
.M_AXI_RVALID(M_AXI_RVALID),
.M_AXI_RREADY(M_AXI_RREADY),
.M_AXI_AWADDR(M_AXI_AWADDR),
.M_AXI_AWLEN(M_AXI_AWLEN),
.M_AXI_AWSIZE(M_AXI_AWSIZE),
.M_AXI_AWBURST(M_AXI_AWBURST),
.M_AXI_AWVALID(M_AXI_AWVALID),
.M_AXI_AWREADY(M_AXI_AWREADY),
.M_AXI_WDATA(M_AXI_WDATA),
.M_AXI_WSTRB(M_AXI_WSTRB),
.M_AXI_WLAST(M_AXI_WLAST),
.M_AXI_WVALID(M_AXI_WVALID),
.M_AXI_WREADY(M_AXI_WREADY),
.M_AXI_BRESP(M_AXI_BRESP),
.M_AXI_BVALID(M_AXI_BVALID),
.M_AXI_BREADY(M_AXI_BREADY),
.bind_valid(job_valid&&job_ready),
.bind_ready(bind_ready),
.bind_done(bind_done),
.bind_verified(bind_verified),
.bind_camera_id(job_camera_id),
.bind_session(job_session),
.bind_frame(job_frame),
.bind_epoch(job_epoch),
.bind_roi_index(job_roi_index),
.bind_x(job_x),
.bind_y(job_y),
.bind_width(job_width),
.bind_height(job_height),
.release_context(state==DRAIN),
.released(released),
.context_generation(context_generation),
.generation_exhausted(generation_exhausted),
.context_authorized(context_authorized),
.context_camera_id(context_camera_id),
.context_session(context_session),
.context_frame(context_frame),
.context_epoch(context_epoch),
.context_roi_index(context_roi_index),
.context_roi_x(context_roi_x),
.context_roi_y(context_roi_y),
.context_roi_width(context_roi_width),
.context_roi_height(context_roi_height),
.exclusive_page_lock(exclusive_page_lock),
.fetch_valid(fetch_valid),
.fetch_ready(fetch_ready),
.fetch_page_index(fetch_page_index),
.fetch_page_address(fetch_page_address),
.fetch_proof_address(fetch_proof_address),
.service_page_request(service_page_request),
.service_page_ready(service_page_ready),
.service_expected_page(service_expected_page),
.service_page_done(service_page_done),
.service_busy(service_busy),
.service_fault(service_fault),
.service_cache_valid(service_cache_valid),
.service_cached_page(service_cached_page),
.service_cache_read(service_cache_read),
.service_cache_address(service_cache_address),
.service_cache_read_valid(service_cache_read_valid),
.service_cache_read_data(service_cache_read_data),
.mac_request(mac_request),
.mac_ready(mac_ready),
.mac_chain(mac_chain),
.mac_data(mac_data),
.mac_response_valid(mac_response_valid),
.mac_response_error(mac_response_error),
.mac_tag(mac_tag),
.mac_quiescent(mac_quiescent));
endmodule
