`timescale 1ns/1ps

module v723_live_ctx_concat_tile_bank_nomemh (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,

    input  wire         in_valid,
    input  wire [1:0]   in_head,
    input  wire [15:0]  in_tile_addr,
    input  wire [127:0] in_tile_data,

    input  wire         start,
    input  wire         out_ready,
    output reg          busy,
    output reg          done,
    output reg          out_valid,
    output reg  [15:0]  out_tile_addr,
    output reg  [255:0] out_tile_data,

    output reg [31:0]   stat_head0_tiles,
    output reg [31:0]   stat_head1_tiles,
    output reg [31:0]   stat_head2_tiles,
    output reg [31:0]   stat_out_tiles,
    output reg [31:0]   stat_errors,
    output reg [3:0]    stat_stage
);

localparam ROWS_REAL = 197;
localparam ROWS_PE_PAD = 200;
localparam ROWS_CONCAT = 208;
localparam HEAD_DIM = 64;
localparam IN_DIM = 196;
localparam TILE = 4;
localparam HEAD_COL_TILES = HEAD_DIM / TILE;
localparam OUT_COL_TILES = IN_DIM / TILE;
localparam OUT_ROW_TILES = ROWS_CONCAT / TILE;
localparam OUT_TILE_COUNT = OUT_ROW_TILES * OUT_COL_TILES;
localparam HEAD_TILE_DEPTH = (ROWS_PE_PAD / TILE) * HEAD_COL_TILES;

localparam ST_IDLE = 4'd0;
localparam ST_EMIT = 4'd1;
localparam ST_WAIT = 4'd2;
localparam ST_NEXT = 4'd3;
localparam ST_DONE = 4'd4;
localparam ST_WAIT_RD = 4'd5;

reg [5:0] emit_rt;
reg [5:0] emit_ct;
reg [15:0] src_tile_addr;
reg [127:0] src_tile_data;
reg [255:0] pack_data;
reg src_is_head;
reg src_is_const;
reg [1:0] src_head_sel;

wire [15:0] out_addr_next = emit_rt * OUT_COL_TILES[15:0] + emit_ct;
wire [15:0] head_addr_next = emit_rt * HEAD_COL_TILES[15:0] + emit_ct[3:0];
wire [15:0] head1_addr_next = emit_rt * HEAD_COL_TILES[15:0] + (emit_ct - 6'd16);
wire [15:0] head2_addr_next = emit_rt * HEAD_COL_TILES[15:0] + (emit_ct - 6'd32);
wire row_valid = (emit_rt < (ROWS_REAL + 3) / 4);
wire head_wr_in_range = in_valid && (in_tile_addr < HEAD_TILE_DEPTH[15:0]);
wire head0_wr_en = head_wr_in_range && (in_head == 2'd0);
wire head1_wr_en = head_wr_in_range && (in_head == 2'd1);
wire head2_wr_en = head_wr_in_range && (in_head == 2'd2);
reg head0_rd_en;
reg head1_rd_en;
reg head2_rd_en;
reg [9:0] head_rd_addr;
wire [127:0] head0_rd_data;
wire [127:0] head1_rd_data;
wire [127:0] head2_rd_data;
wire [127:0] src_head_data =
    (src_head_sel == 2'd0) ? head0_rd_data :
    (src_head_sel == 2'd1) ? head1_rd_data :
                             head2_rd_data;

v714_bram_sdp_sync #(
    .DATA_W(128),
    .ADDR_W(10),
    .DEPTH(HEAD_TILE_DEPTH)
) u_head0_bank (
    .clk(clk),
    .wr_en(head0_wr_en),
    .wr_addr(in_tile_addr[9:0]),
    .wr_data(in_tile_data),
    .rd_en(head0_rd_en),
    .rd_addr(head_rd_addr),
    .rd_data(head0_rd_data)
);

v714_bram_sdp_sync #(
    .DATA_W(128),
    .ADDR_W(10),
    .DEPTH(HEAD_TILE_DEPTH)
) u_head1_bank (
    .clk(clk),
    .wr_en(head1_wr_en),
    .wr_addr(in_tile_addr[9:0]),
    .wr_data(in_tile_data),
    .rd_en(head1_rd_en),
    .rd_addr(head_rd_addr),
    .rd_data(head1_rd_data)
);

v714_bram_sdp_sync #(
    .DATA_W(128),
    .ADDR_W(10),
    .DEPTH(HEAD_TILE_DEPTH)
) u_head2_bank (
    .clk(clk),
    .wr_en(head2_wr_en),
    .wr_addr(in_tile_addr[9:0]),
    .wr_data(in_tile_data),
    .rd_en(head2_rd_en),
    .rd_addr(head_rd_addr),
    .rd_data(head2_rd_data)
);

always @(posedge clk) begin
    if (!rst_n) begin
        busy <= 1'b0;
        done <= 1'b0;
        out_valid <= 1'b0;
        out_tile_addr <= 16'd0;
        out_tile_data <= 256'd0;
        stat_head0_tiles <= 32'd0;
        stat_head1_tiles <= 32'd0;
        stat_head2_tiles <= 32'd0;
        stat_out_tiles <= 32'd0;
        stat_errors <= 32'd0;
        stat_stage <= ST_IDLE;
        emit_rt <= 6'd0;
        emit_ct <= 6'd0;
        src_tile_addr <= 16'd0;
        src_tile_data <= 128'd0;
        pack_data <= 256'd0;
        src_is_head <= 1'b0;
        src_is_const <= 1'b0;
        src_head_sel <= 2'd0;
        head0_rd_en <= 1'b0;
        head1_rd_en <= 1'b0;
        head2_rd_en <= 1'b0;
        head_rd_addr <= 10'd0;
    end else begin
        done <= 1'b0;
        head0_rd_en <= 1'b0;
        head1_rd_en <= 1'b0;
        head2_rd_en <= 1'b0;
        stat_stage <= stat_stage;

        if (clear) begin
            busy <= 1'b0;
            done <= 1'b0;
            out_valid <= 1'b0;
            stat_head0_tiles <= 32'd0;
            stat_head1_tiles <= 32'd0;
            stat_head2_tiles <= 32'd0;
            stat_out_tiles <= 32'd0;
            stat_errors <= 32'd0;
            stat_stage <= ST_IDLE;
            emit_rt <= 6'd0;
            emit_ct <= 6'd0;
        end else begin
            if (in_valid) begin
                if (in_tile_addr < HEAD_TILE_DEPTH[15:0]) begin
                    if (in_head == 2'd0) begin
                        stat_head0_tiles <= stat_head0_tiles + 1'b1;
                    end else if (in_head == 2'd1) begin
                        stat_head1_tiles <= stat_head1_tiles + 1'b1;
                    end else if (in_head == 2'd2) begin
                        stat_head2_tiles <= stat_head2_tiles + 1'b1;
                    end else begin
                        stat_errors <= stat_errors + 1'b1;
                    end
                end else begin
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            if (out_valid && out_ready)
                out_valid <= 1'b0;

            case (stat_stage)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        emit_rt <= 6'd0;
                        emit_ct <= 6'd0;
                        stat_out_tiles <= 32'd0;
                        stat_errors <= stat_errors;
                        stat_stage <= ST_EMIT;
                    end
                end

                ST_EMIT: begin
                    out_tile_addr <= out_addr_next;
                    src_is_head <= 1'b0;
                    src_is_const <= 1'b0;
                    src_tile_addr <= 16'd0;
                    src_tile_data <= 128'd0;

                    if (emit_ct < 6'd16) begin
                        src_is_head <= row_valid;
                        src_head_sel <= 2'd0;
                        src_tile_addr <= head_addr_next;
                        head_rd_addr <= head_addr_next[9:0];
                        head0_rd_en <= row_valid;
                    end else if (emit_ct < 6'd32) begin
                        src_is_head <= row_valid;
                        src_head_sel <= 2'd1;
                        src_tile_addr <= head1_addr_next;
                        head_rd_addr <= head1_addr_next[9:0];
                        head1_rd_en <= row_valid;
                    end else if (emit_ct < 6'd48) begin
                        src_is_head <= row_valid;
                        src_head_sel <= 2'd2;
                        src_tile_addr <= head2_addr_next;
                        head_rd_addr <= head2_addr_next[9:0];
                        head2_rd_en <= row_valid;
                    end else begin
                        src_is_const <= 1'b1;
                    end
                    stat_stage <= ST_WAIT;
                end

                ST_WAIT: begin
                    if (src_is_head) begin
                        stat_stage <= ST_WAIT_RD;
                    end else if (src_is_const) begin
                        pack_data[255 - 0*16 -: 16]  <= 16'sd16384;
                        pack_data[255 - 1*16 -: 16]  <= 16'sd1;
                        pack_data[255 - 2*16 -: 16]  <= 16'sd0;
                        pack_data[255 - 3*16 -: 16]  <= 16'sd0;
                        pack_data[255 - 4*16 -: 16]  <= 16'sd16384;
                        pack_data[255 - 5*16 -: 16]  <= 16'sd1;
                        pack_data[255 - 6*16 -: 16]  <= 16'sd0;
                        pack_data[255 - 7*16 -: 16]  <= 16'sd0;
                        pack_data[255 - 8*16 -: 16]  <= 16'sd16384;
                        pack_data[255 - 9*16 -: 16]  <= 16'sd1;
                        pack_data[255 - 10*16 -: 16] <= 16'sd0;
                        pack_data[255 - 11*16 -: 16] <= 16'sd0;
                        pack_data[255 - 12*16 -: 16] <= 16'sd16384;
                        pack_data[255 - 13*16 -: 16] <= 16'sd1;
                        pack_data[255 - 14*16 -: 16] <= 16'sd0;
                        pack_data[255 - 15*16 -: 16] <= 16'sd0;
                        stat_stage <= ST_NEXT;
                    end else begin
                        pack_data <= 256'd0;
                        stat_stage <= ST_NEXT;
                    end
                end

                ST_WAIT_RD: begin
                    if (src_is_head) begin
                        pack_data[255 - 0*16 -: 16]  <= {{8{src_head_data[127 - 0*8]}}, src_head_data[127 - 0*8 -: 8]};
                        pack_data[255 - 1*16 -: 16]  <= {{8{src_head_data[127 - 1*8]}}, src_head_data[127 - 1*8 -: 8]};
                        pack_data[255 - 2*16 -: 16]  <= {{8{src_head_data[127 - 2*8]}}, src_head_data[127 - 2*8 -: 8]};
                        pack_data[255 - 3*16 -: 16]  <= {{8{src_head_data[127 - 3*8]}}, src_head_data[127 - 3*8 -: 8]};
                        pack_data[255 - 4*16 -: 16]  <= {{8{src_head_data[127 - 4*8]}}, src_head_data[127 - 4*8 -: 8]};
                        pack_data[255 - 5*16 -: 16]  <= {{8{src_head_data[127 - 5*8]}}, src_head_data[127 - 5*8 -: 8]};
                        pack_data[255 - 6*16 -: 16]  <= {{8{src_head_data[127 - 6*8]}}, src_head_data[127 - 6*8 -: 8]};
                        pack_data[255 - 7*16 -: 16]  <= {{8{src_head_data[127 - 7*8]}}, src_head_data[127 - 7*8 -: 8]};
                        pack_data[255 - 8*16 -: 16]  <= {{8{src_head_data[127 - 8*8]}}, src_head_data[127 - 8*8 -: 8]};
                        pack_data[255 - 9*16 -: 16]  <= {{8{src_head_data[127 - 9*8]}}, src_head_data[127 - 9*8 -: 8]};
                        pack_data[255 - 10*16 -: 16] <= {{8{src_head_data[127 - 10*8]}}, src_head_data[127 - 10*8 -: 8]};
                        pack_data[255 - 11*16 -: 16] <= {{8{src_head_data[127 - 11*8]}}, src_head_data[127 - 11*8 -: 8]};
                        pack_data[255 - 12*16 -: 16] <= {{8{src_head_data[127 - 12*8]}}, src_head_data[127 - 12*8 -: 8]};
                        pack_data[255 - 13*16 -: 16] <= {{8{src_head_data[127 - 13*8]}}, src_head_data[127 - 13*8 -: 8]};
                        pack_data[255 - 14*16 -: 16] <= {{8{src_head_data[127 - 14*8]}}, src_head_data[127 - 14*8 -: 8]};
                        pack_data[255 - 15*16 -: 16] <= {{8{src_head_data[127 - 15*8]}}, src_head_data[127 - 15*8 -: 8]};
                    end else begin
                        pack_data <= 256'd0;
                    end
                    stat_stage <= ST_NEXT;
                end

                ST_NEXT: begin
                    if (!out_valid) begin
                        out_valid <= 1'b1;
                        out_tile_data <= pack_data;
                        stat_out_tiles <= stat_out_tiles + 1'b1;
                        if (stat_out_tiles == OUT_TILE_COUNT[31:0] - 1'b1) begin
                            stat_stage <= ST_DONE;
                        end else if (emit_ct == OUT_COL_TILES[5:0] - 1'b1) begin
                            emit_ct <= 6'd0;
                            emit_rt <= emit_rt + 1'b1;
                            stat_stage <= ST_EMIT;
                        end else begin
                            emit_ct <= emit_ct + 1'b1;
                            stat_stage <= ST_EMIT;
                        end
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    stat_stage <= ST_IDLE;
                end

                default: begin
                    stat_stage <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule
