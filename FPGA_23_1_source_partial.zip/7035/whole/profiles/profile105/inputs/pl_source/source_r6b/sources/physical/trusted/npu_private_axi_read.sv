`timescale 1ns/1ps
// Terminate only the fixed INPUT / POSE read windows inside trusted PL.
// No external DDR transactions are generated. One outstanding AXI4 burst.
// Errors drain the accepted burst with SLVERR instead of wedging its master.
module npu_private_axi_read #(
 parameter [31:0] INPUT_BASE=32'h10e00000,
 parameter [31:0] POSE_BASE=32'h10e20000
)(
 input wire clk,rst_n,clear,cancel,authorized,
 input wire [31:0] session_epoch,
 input wire [31:0] s_araddr,input wire [7:0] s_arlen,
 input wire [2:0] s_arsize,input wire [1:0] s_arburst,
 input wire s_arvalid,output wire s_arready,
 output wire [255:0] s_rdata,output wire [1:0] s_rresp,
 output wire s_rlast,s_rvalid,input wire s_rready,
 input wire bank_valid,
 output wire bank_read_valid,output wire bank_read_pose,
 output wire [11:0] bank_read_beat,input wire bank_read_ready,
 input wire bank_result_valid,output wire bank_result_ready,
 input wire [255:0] bank_result_data,
 output reg fault
);
 localparam IDLE=0,REQUEST=1,WAIT_DATA=2,REPLY=3;
 reg [1:0] state;
 reg [31:0] epoch;
 reg [7:0] remaining;
 reg kind,bad;
 reg [11:0] beat;
 reg [255:0] data;
 wire live=(authorized===1'b1)&&(session_epoch===epoch)&&bank_valid&&!cancel;
 wire in_input=s_araddr>=INPUT_BASE&&s_araddr<INPUT_BASE+32'd78400;
 wire in_pose=s_araddr>=POSE_BASE&&s_araddr<POSE_BASE+32'd75648;
 wire [32:0] end_address={1'b0,s_araddr}+({25'd0,s_arlen}+33'd1)*33'd32;
 wire [32:0] region_end=in_pose?{1'b0,POSE_BASE}+33'd75648:{1'b0,INPUT_BASE}+33'd78400;
 wire [13:0] burst_bytes=({6'd0,s_arlen}+14'd1)*14'd32;
 wire request_ok=(authorized===1'b1)&&bank_valid&&!cancel&&!fault&&
  (^s_araddr!==1'bx)&&(^s_arlen!==1'bx)&&(in_input||in_pose)&&
  (s_araddr[4:0]===5'd0)&&(s_arsize===3'd5)&&(s_arburst===2'd1)&&
  end_address<=region_end&&({2'b0,s_araddr[11:0]}+burst_bytes<=14'd4096);
 assign s_arready=rst_n&&state==IDLE&&!clear;
 assign s_rvalid=rst_n&&state==REPLY;
 assign s_rdata=s_rvalid&&!bad&&live?data:256'd0;
 assign s_rresp=bad||!live?2'b10:2'b00;
 assign s_rlast=s_rvalid&&remaining==0;
 assign bank_read_valid=state==REQUEST&&!bad&&live&&rst_n;
 assign bank_read_pose=kind;
 assign bank_read_beat=beat;
 assign bank_result_ready=state==WAIT_DATA&&!bad&&live&&rst_n;
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;epoch<=0;remaining<=0;kind<=0;bad<=0;beat<=0;data<=0;fault<=0;end
  else begin
   if(clear)begin
    if(state==IDLE)fault<=0;
    else begin fault<=1;bad<=1;end
   end
   if(state!=IDLE&&(!live||clear))begin bad<=1;fault<=1;end
   case(state)
    IDLE:if(s_arvalid&&s_arready)begin
     epoch<=session_epoch;remaining<=s_arlen;kind<=in_pose;
     beat<=(s_araddr-(in_pose?POSE_BASE:INPUT_BASE))>>5;
     bad<=!request_ok;data<=0;
     if(request_ok)state<=REQUEST;
     else begin state<=REPLY;fault<=1;end
    end
    REQUEST:begin
     if(bad||!live||clear)begin state<=REPLY;data<=0;end
     else if(bank_read_ready)state<=WAIT_DATA;
    end
    WAIT_DATA:begin
     if(bad||!live||clear)begin state<=REPLY;data<=0;end
     else if(bank_result_valid)begin data<=bank_result_data;state<=REPLY;end
    end
    REPLY:if(s_rready)begin
     if(remaining==0)state<=IDLE;
     else begin remaining<=remaining-1'b1;beat<=beat+1'b1;state<=bad||!live||clear?REPLY:REQUEST;end
    end
    default:begin state<=IDLE;fault<=1;end
   endcase
  end
 end
endmodule
