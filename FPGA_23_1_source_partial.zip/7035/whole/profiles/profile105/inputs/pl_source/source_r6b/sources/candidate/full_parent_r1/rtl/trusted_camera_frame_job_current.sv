`timescale 1ns/1ps
// Production 640-only ingress. All control/context ports belong to trusted PL.
// Packet ports connect to nfr_packet_rx/control_tx, not to PS-controlled memory.
// No inference completion, address, shape, epoch or GO register is exposed here.
module trusted_camera_frame_job_current(
 output wire observation_capture_start,
 output wire [31:0] observation_next_session,observation_next_frame,output wire observation_next_exhausted,
 input wire clk,rst_n,authorized,key_valid,input wire [31:0] authorization_epoch,
 input wire trusted_go,trusted_stop,output wire go_ready,active,fault,quiescent,
 input wire packet_valid,input wire [383:0] packet_header,output wire packet_release,
 output wire payload_read,output wire [9:0] payload_address,
 input wire [7:0] payload_data,input wire payload_read_valid,
 output wire response_valid,input wire response_ready,output wire [7:0] response_kind,response_flags,
 output wire [31:0] response_offset,response_frame_crc,response_session_id,response_frame_id,response_total_bytes,
 output wire [15:0] response_width,response_height,
 output wire job_valid,input wire job_ready,output wire [31:0] job_session,job_frame,job_epoch,job_base,
 input wire job_done,input wire [31:0] job_done_session,job_done_frame,
 output wire job_cancel,input wire job_quiescent,job_fault,
 output wire sealed_letterbox_valid,output wire [31:0] sealed_session,sealed_frame,sealed_epoch,
 output wire [31:0] completed_frames,rejected_completions,committed_offset,received_crc,
 output wire request_valid,input wire request_ready,output wire request_write,
 output wire [31:0] request_session,request_frame,request_epoch,request_version,
 output wire [15:0] request_role,request_shape,
 output wire [31:0] request_address,request_tensor_mask,request_strobe,output wire [255:0] request_data,
 input wire response_verified_valid,output wire response_verified_ready,input wire response_error,guard_context_live,
 input wire [255:0] response_data,input wire guard_quiescent
);
 wire capture_begin_ready;
 wire coordinator_ready,coordinator_active,coordinator_fault,sink_start,sink_cancel,sink_consume_done;
 // Read-only actual accepted capture event; does not alter the ingress FSM.

 wire raw_start_ready,raw_busy,raw_ready,raw_fault,capture_ready,capture_quiet,capture_failed,producer_cancel;
 wire [31:0] session_id,frame_id,raw_frame,raw_base,raw_session,raw_frame_id,raw_total;
 wire [15:0] raw_width,raw_height;wire [7:0] raw_flags;
 wire unused_profile,unused_pattern,unused_bank,unused_display;
 assign observation_next_session=session_id+32'd1;
 assign observation_next_frame=frame_id+32'd1;
 assign observation_next_exhausted=session_id==32'hffffffff||frame_id==32'hffffffff;
 assign observation_capture_start=sink_start&&raw_start_ready&&capture_begin_ready&&authorized&&key_valid;
 wire [31:0] unused_display_base,unused_display_seq,letterbox_bytes;
 wire ca_valid,cw_valid,cw_last,cb_ready,ca_ready,cw_ready,cb_valid;
 wire [31:0] ca_addr;wire [7:0] ca_len,cw_strb;wire [2:0] ca_size;wire [1:0] ca_burst,cb_resp;
 wire [63:0] cw_data;
 wire bound=capture_ready&&sealed_session==session_id&&sealed_frame==frame_id&&
   sealed_epoch==authorization_epoch&&letterbox_bytes==307200&&authorized&&key_valid;
 wire coordinator_job_valid;
 assign go_ready=coordinator_ready&&capture_quiet&&authorized&&key_valid&&!trusted_stop;
 assign active=coordinator_active;
 assign fault=coordinator_fault||capture_failed;
 assign quiescent=!coordinator_active&&!raw_busy&&capture_quiet&&job_quiescent&&guard_quiescent;
 assign job_valid=coordinator_job_valid&&bound;
 assign sealed_letterbox_valid=bound;
 assign job_epoch=sealed_epoch;
 nfr_frame_coordinator coordinator(
  .clk(clk),.rst_n(rst_n),.go(trusted_go&&go_ready),.stop(trusted_stop),
  .profile1080(1'b0),.pattern(1'b0),.repeat_frames(1'b0),
  .go_ready(coordinator_ready),.active(coordinator_active),.fault(coordinator_fault),
  .sink_start(sink_start),.sink_cancel(sink_cancel),.sink_consume_done(sink_consume_done),
  .sink_start_ready(raw_start_ready&&capture_begin_ready&&authorized&&key_valid),
  .sink_busy(raw_busy||!capture_quiet),.sink_ready(bound),.sink_fault(raw_fault||capture_failed),
  .sink_profile1080(unused_profile),.sink_pattern(unused_pattern),.sink_display_bank(unused_bank),
  .session_id(session_id),.frame_id(frame_id),.sink_frame(raw_frame),.sink_base(raw_base),
  .job_valid(coordinator_job_valid),.job_ready(job_ready&&bound),.job_session(job_session),.job_frame(job_frame),.job_base(job_base),
  // Revoke/STOP and completion may arrive on the same edge. The diagnostic
  // coordinator retains its old behavior; this production fence must prevent
  // even its success counter from accepting an already-invalid completion.
  .job_done(job_done&&bound&&!trusted_stop&&!job_fault),.job_done_session(job_done_session),.job_done_frame(job_done_frame),
  .job_cancel(job_cancel),.job_quiescent(job_quiescent&&capture_quiet&&guard_quiescent),.job_fault(job_fault),
  .rejected_completions(rejected_completions),.completed_frames(completed_frames),
  .display_enable(unused_display),.display_base(unused_display_base),.display_seq(unused_display_seq),
  .display_ack_seq(32'd0),.display_active_base(32'd0),.display_fault(1'b0));
 nfr_frame_sink sink(
  .clk(clk),.rst_n(rst_n),.start(sink_start),.cancel(sink_cancel||producer_cancel),.consume_done(sink_consume_done),
  .profile1080(1'b0),.pattern(1'b0),.display_bank(1'b0),.request_session(session_id),.request_frame(frame_id),
  .start_ready(raw_start_ready),.busy(raw_busy),.frame_ready(raw_ready),.fault(raw_fault),
  .completed_frame(raw_frame),.committed_offset(committed_offset),.received_crc(received_crc),.frame_base(raw_base),
  .packet_valid(packet_valid),.packet_header(packet_header),.packet_release(packet_release),
  .payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
  .response_valid(response_valid),.response_ready(response_ready),.response_kind(response_kind),.response_offset(response_offset),.response_frame_crc(response_frame_crc),
  .response_session_id(response_session_id),.response_frame_id(response_frame_id),.response_total_bytes(response_total_bytes),
  .response_width(response_width),.response_height(response_height),.response_flags(response_flags),
  .session_id(raw_session),.frame_id(raw_frame_id),.total_bytes(raw_total),.width(raw_width),.height(raw_height),.flags(raw_flags),
  .m_awaddr(ca_addr),.m_awlen(ca_len),.m_awsize(ca_size),.m_awburst(ca_burst),.m_awvalid(ca_valid),.m_awready(ca_ready),
  .m_wdata(cw_data),.m_wstrb(cw_strb),.m_wlast(cw_last),.m_wvalid(cw_valid),.m_wready(cw_ready),
  .m_bresp(cb_resp),.m_bvalid(cb_valid),.m_bready(cb_ready));
 trusted_nfr_letterbox_parent capture(
  .clk(clk),.rst_n(rst_n),.cancel(sink_cancel),.authorized(authorized),.key_valid(key_valid),.authorization_epoch(authorization_epoch),
  .frame_begin(sink_start),.frame_begin_ready(capture_begin_ready),.trusted_session(session_id),.trusted_frame(frame_id),.trusted_epoch(authorization_epoch),
  .producer_frame_ready(raw_ready),.producer_session(raw_session),.producer_frame(raw_frame),
  .producer_cancel(producer_cancel),.frame_ready(capture_ready),.quiescent(capture_quiet),.failed(capture_failed),
  .result_session(sealed_session),.result_frame(sealed_frame),.result_epoch(sealed_epoch),.output_committed_bytes(letterbox_bytes),
  .CAM_AWADDR(ca_addr),.CAM_AWLEN(ca_len),.CAM_AWSIZE(ca_size),.CAM_AWBURST(ca_burst),.CAM_AWVALID(ca_valid),.CAM_AWREADY(ca_ready),
  .CAM_WDATA(cw_data),.CAM_WSTRB(cw_strb),.CAM_WLAST(cw_last),.CAM_WVALID(cw_valid),.CAM_WREADY(cw_ready),.CAM_BRESP(cb_resp),.CAM_BVALID(cb_valid),.CAM_BREADY(cb_ready),
  .PS_AWADDR(32'd0),.PS_AWVALID(1'b0),.PS_AWREADY(),.PS_WDATA(32'd0),.PS_WSTRB(4'd0),.PS_WVALID(1'b0),.PS_WREADY(),.PS_BRESP(),.PS_BVALID(),.PS_BREADY(1'b1),
  .PS_ARADDR(32'd0),.PS_ARVALID(1'b0),.PS_ARREADY(),.PS_RDATA(),.PS_RRESP(),.PS_RVALID(),.PS_RREADY(1'b1),
  .request_valid(request_valid),.request_ready(request_ready),.request_write(request_write),
  .request_session(request_session),.request_frame(request_frame),.request_epoch(request_epoch),.request_version(request_version),
  .request_role(request_role),.request_shape(request_shape),.request_address(request_address),.request_tensor_mask(request_tensor_mask),.request_strobe(request_strobe),.request_data(request_data),
  .response_valid(response_verified_valid),.response_ready(response_verified_ready),.response_error(response_error),.guard_context_live(guard_context_live),.response_data(response_data),.guard_quiescent(guard_quiescent));
endmodule
