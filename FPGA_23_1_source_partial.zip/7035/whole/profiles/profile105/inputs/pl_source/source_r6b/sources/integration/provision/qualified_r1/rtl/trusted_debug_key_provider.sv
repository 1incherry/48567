`timescale 1ns/1ps
// Volatile trusted-JTAG test provisioning. The command/payload inputs must be
// synchronous to clk and held until ack (a same-clock VIO supplies them).
// No PS/AXI port exists. Only security_reset_n may reset this state.
// A real fresh key must be supplied after every trusted cold reset/configure.
module trusted_debug_key_provider #(
 parameter integer TIMEOUT_CYCLES=1000000,
 parameter integer CLOSED_ROOT_BINDING=0,
 parameter integer ENABLE_ORDINARY_SLOT_REPLAY=0,
 parameter integer ENABLE_ORDINARY_AUTORUN=0
)(
 input wire clk,security_reset_n,
 input wire [31:0] debug_command,
 input wire [127:0] debug_key,debug_session_id,debug_key_fingerprint,
 input wire [31:0] debug_resume_epoch,
 input wire all_quiescent,controller_authorized,controller_key_session_valid,model_authorized,
 input wire [127:0] controller_session_id,controller_key_fingerprint,
 input wire [31:0] controller_epoch,
 input wire provision_ready,provision_accepted,provision_rejected,
 output wire provision_valid,trusted_fresh_key_ready,
 output wire [127:0] provision_session_id,provision_key_fingerprint,
 input wire resume_ready,resume_accepted,resume_rejected,
 output wire trusted_resume_valid,
 output wire [31:0] trusted_resume_epoch,
 output wire [127:0] trusted_resume_session_id,
 input wire ordinary_replay_ready,ordinary_replay_accepted,input wire[6:0]ordinary_replay_slot,
 input wire ordinary_replay_offer_live,input wire[31:0]ordinary_replay_offer_identity,
 output wire ordinary_replay_request,output wire[31:0]ordinary_replay_request_identity,
 input wire ordinary_autorun_ready,input wire[31:0]ordinary_autorun_model_epoch,
 output wire ordinary_autorun_start,output reg ordinary_autorun_stop,
 input wire trusted_job_ready,
 output wire trusted_job_request,output reg trusted_revoke,
 output reg [127:0] installed_key,
 output wire guard_key_valid,
 output wire [31:0] ack_word,status_word,last_sequence_word,
 output wire busy
);
 localparam IDLE=0,SAMPLE=1,CHECK=2,INSTALL=3,OFFER=4,WAIT_PROVISION=5,
  RESUME_OFFER=6,WAIT_RESUME=7,JOB_OFFER=8,BOOT=9,REPLAY_OFFER=10,AUTORUN_OFFER=11;
 reg [3:0] state;
 reg[31:0] bound_replay_offer_identity;
 wire replay_offer_binding_live=(ordinary_replay_offer_live&&ordinary_replay_offer_identity!=0&&ordinary_replay_offer_identity==bound_replay_offer_identity)===1'b1;
 assign ordinary_replay_request_identity=ENABLE_ORDINARY_SLOT_REPLAY!=0&&state==REPLAY_OFFER?bound_replay_offer_identity:32'd0;
 reg [31:0] sampled_command,sampled_epoch,ticks,sampled_model_epoch;
 reg [127:0] sampled_key,sampled_id,sampled_fingerprint;
 reg [127:0] installed_id,installed_fingerprint;
 reg installed_valid;
 reg [23:0] last_sequence,last_seen_sequence,ack_sequence;
 reg [7:0] ack_error;
 wire [23:0] incoming_sequence=debug_command[31:8];
 wire [7:0] operation=sampled_command[7:0];
 wire unchanged=debug_command==sampled_command&&debug_key==sampled_key&&
  debug_session_id==sampled_id&&debug_key_fingerprint==sampled_fingerprint&&debug_resume_epoch==sampled_epoch;
 wire binding_matches=installed_id==controller_session_id&&installed_fingerprint==controller_key_fingerprint;
 wire admission_live=ticks<TIMEOUT_CYCLES-1;
 // The closed actual reset controller changes its bound tuple only on this
 // provider's actual provision handshake. Accepted tuple equals installed
 // sample; rejection clears controller_key_session_valid. Generic callers
 // retain the original full combinational comparison by default.
 reg closed_binding_matches;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)closed_binding_matches<=0;
  else if(state==INSTALL&&all_quiescent&&!controller_authorized&&provision_ready)
   closed_binding_matches<=sampled_id==controller_session_id&&sampled_fingerprint==controller_key_fingerprint;
  else if(provision_valid&&provision_ready)closed_binding_matches<=1;
 end
 wire binding_effective=CLOSED_ROOT_BINDING!=0?closed_binding_matches:binding_matches;
 // synthesis translate_off
 always @(posedge clk or negedge clk)if(security_reset_n&&CLOSED_ROOT_BINDING!=0&&installed_valid&&controller_key_session_valid&&closed_binding_matches!==binding_matches)
  $fatal(1,"CLOSED_ROOT_BINDING_PRECONDITION_VIOLATED");
 // synthesis translate_on
 assign guard_key_valid=security_reset_n&&installed_valid&&controller_key_session_valid&&binding_effective;
 assign provision_valid=(state==OFFER||state==WAIT_PROVISION)&&admission_live;
 assign trusted_fresh_key_ready=provision_valid&&installed_valid&&
  installed_id==sampled_id&&installed_fingerprint==sampled_fingerprint;
 assign provision_session_id=sampled_id;
 assign provision_key_fingerprint=sampled_fingerprint;
 assign trusted_resume_valid=(state==RESUME_OFFER||state==WAIT_RESUME)&&admission_live;
 assign trusted_resume_epoch=sampled_epoch;
 assign trusted_resume_session_id=sampled_id;
 assign trusted_job_request=state==JOB_OFFER&&admission_live&&controller_authorized&&model_authorized&&guard_key_valid;
 assign ordinary_replay_request=ENABLE_ORDINARY_SLOT_REPLAY!=0&&state==REPLAY_OFFER&&admission_live&&controller_authorized&&model_authorized&&guard_key_valid&&replay_offer_binding_live;
 wire autorun_context_live=controller_authorized&&model_authorized&&guard_key_valid&&sampled_epoch==controller_epoch&&sampled_id==controller_session_id&&sampled_fingerprint==controller_key_fingerprint&&sampled_model_epoch==ordinary_autorun_model_epoch;
 assign ordinary_autorun_start=ENABLE_ORDINARY_AUTORUN!=0&&state==AUTORUN_OFFER&&admission_live&&autorun_context_live;
 assign busy=state!=IDLE;
 assign ack_word={ack_error,ack_sequence};
 assign last_sequence_word={8'd0,last_sequence};
 assign status_word={22'd0,ack_sequence!=0,trusted_job_ready,resume_ready,provision_ready,
  all_quiescent,model_authorized,controller_authorized,guard_key_valid,installed_valid,busy};
 task finish_command(input [7:0] error_code);
  begin ack_sequence<=sampled_command[31:8];ack_error<=error_code;state<=IDLE;bound_replay_offer_identity<=0;end
 endtask
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=BOOT;sampled_command<=0;sampled_epoch<=0;sampled_model_epoch<=0;ordinary_autorun_stop<=0;ticks<=0;bound_replay_offer_identity<=0;
   sampled_key<=0;sampled_id<=0;sampled_fingerprint<=0;
   installed_key<=0;installed_id<=0;installed_fingerprint<=0;installed_valid<=0;
   last_sequence<=0;last_seen_sequence<=0;ack_sequence<=0;ack_error<=0;trusted_revoke<=0;
  end else begin
   trusted_revoke<=0;ordinary_autorun_stop<=0;
   if(state!=IDLE)ticks<=ticks+1'b1;else ticks<=0;
   case(state)
    BOOT:begin
     // VIO has no security-POR input. Its outputs may retain a PREVIOUS boot
     // command and key payload when only this domain resets. Ignore that
     // retained command; require a NEW trusted-host commit after root reset.
     last_seen_sequence<=incoming_sequence;last_sequence<=incoming_sequence;
     state<=IDLE;ticks<=0;
    end
    IDLE:if(incoming_sequence!=last_seen_sequence)begin
     sampled_command<=debug_command;sampled_epoch<=debug_resume_epoch;sampled_model_epoch<=ordinary_autorun_model_epoch;
     sampled_key<=debug_key;sampled_id<=debug_session_id;sampled_fingerprint<=debug_key_fingerprint;
     last_seen_sequence<=incoming_sequence;ticks<=0;state<=SAMPLE;
    end
    SAMPLE:state<=CHECK;
    CHECK:begin
     // Separate payload writes precede the command commit. Never consume a
     // torn or changing payload or silently substitute a later command.
     if(!unchanged)finish_command(8'h09);
     else if(sampled_command[31:8]==0||sampled_command[31:8]<=last_sequence)finish_command(8'h08);
     else begin
      last_sequence<=sampled_command[31:8];
      case(operation)
       1:if(!all_quiescent||controller_authorized||!provision_ready)finish_command(8'h01);
         else if(sampled_key==0||sampled_id==0||sampled_fingerprint==0)finish_command(8'h02);
         else state<=INSTALL;
       2:if(!all_quiescent||!resume_ready||!guard_key_valid||
             sampled_epoch!=controller_epoch||sampled_id!=controller_session_id)finish_command(8'h04);
         else state<=RESUME_OFFER;
       3:if(!controller_authorized||!model_authorized||!guard_key_valid||!trusted_job_ready)finish_command(8'h06);
         else state<=JOB_OFFER;
       4:begin trusted_revoke<=1;finish_command(8'h00);end
       9:if(ENABLE_ORDINARY_SLOT_REPLAY==0)finish_command(8'h07);
         else if(!controller_authorized||!model_authorized||!guard_key_valid||!ordinary_replay_ready||ordinary_replay_offer_live!==1'b1||(ordinary_replay_offer_identity!=0)!==1'b1||sampled_epoch<1||sampled_epoch>100||sampled_epoch!={25'd0,ordinary_replay_slot})finish_command(8'h06);
         else begin bound_replay_offer_identity<=ordinary_replay_offer_identity;state<=REPLAY_OFFER;end
       10:if(ENABLE_ORDINARY_AUTORUN==0)finish_command(8'h07);
          else if(!autorun_context_live||!ordinary_autorun_ready)finish_command(8'h06);
          else state<=AUTORUN_OFFER;
       11:if(ENABLE_ORDINARY_AUTORUN==0)finish_command(8'h07);
          else begin ordinary_autorun_stop<=1;finish_command(8'h00);end
       default:finish_command(8'h07);
      endcase
     end
    end
    INSTALL:begin
     // Retain the OLD key unless every service is really idle at the exact
     // installing edge. The controller is still unauthorized in this window.
     if(!all_quiescent||controller_authorized||!provision_ready)finish_command(8'h01);
     else begin
      installed_key<=sampled_key;installed_id<=sampled_id;installed_fingerprint<=sampled_fingerprint;
      installed_valid<=1;state<=OFFER;
     end
    end
    OFFER:if(provision_accepted)finish_command(8'h00);
          else if(provision_rejected)begin installed_valid<=0;finish_command(8'h03);end
          else if(provision_ready)state<=WAIT_PROVISION;
    WAIT_PROVISION:if(provision_accepted)finish_command(8'h00);
          else if(provision_rejected)begin installed_valid<=0;finish_command(8'h03);end
    RESUME_OFFER:if(resume_accepted)finish_command(8'h00);
          else if(resume_rejected)finish_command(8'h05);
          else if(resume_ready)state<=WAIT_RESUME;
    WAIT_RESUME:if(resume_accepted)finish_command(8'h00);
          else if(resume_rejected)finish_command(8'h05);
    JOB_OFFER:if(!controller_authorized||!model_authorized||!guard_key_valid)finish_command(8'h06);
          else if(trusted_job_ready)finish_command(8'h00);
    AUTORUN_OFFER:if(!autorun_context_live)finish_command(8'h06);
          else if(ordinary_autorun_ready)finish_command(8'h00);
    REPLAY_OFFER:if(!controller_authorized||!model_authorized||!guard_key_valid)finish_command(8'h06);
          else if(ordinary_replay_accepted)finish_command(8'h00);
          else if(!replay_offer_binding_live)finish_command(8'h06);
    default:begin installed_valid<=0;trusted_revoke<=1;finish_command(8'hff);end
   endcase
   if(state!=IDLE&&ticks>=TIMEOUT_CYCLES-1)begin
    // Keep key bits for genuine in-flight drain; withdraw their validity.
    // Even a controller acceptance on this edge cannot enable a job.
    installed_valid<=0;trusted_revoke<=1;finish_command(8'h0a);
   end
  end
 end
endmodule
