`timescale 1ns/1ps

module v600_runtime_fc2_norm3_stream_c0 #(
    parameter INPUT_MEM = "",
    parameter SCALE_MEM = "",
    parameter BIAS_MEM = "",
    parameter MEAN_MEM = "",
    parameter FACTOR_MEM = "",
    parameter NORM_MEM = "",
    parameter NORM_EXT_MEM = ""
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire in_wr_valid,
    input  wire [15:0] in_wr_addr,
    input  wire signed [15:0] in_wr_data,
    input  wire scale_wr_valid,
    input  wire [7:0] scale_wr_addr,
    input  wire signed [31:0] scale_wr_data,
    input  wire bias_wr_valid,
    input  wire [7:0] bias_wr_addr,
    input  wire signed [31:0] bias_wr_data,
    input  wire start,
    input  wire out_ready,
    output reg  busy,
    output reg  done,
    output reg [31:0] stat_input_writes,
    output reg [31:0] stat_input_errors,
    output reg [31:0] stat_rows,
    output reg [31:0] stat_items,
    output reg [31:0] stat_mean_errors,
    output reg [31:0] stat_factor_errors,
    output reg [31:0] stat_norm_errors,
    output reg [31:0] stat_ext_errors,
    output reg        out_valid,
    output reg [15:0] out_addr,
    output reg signed [15:0] out_data,
    output reg [31:0] stat_stream_items
);

localparam ROWS_IN = 256;
localparam ROWS_PAD = 256;
localparam DIM = 192;
localparam DIM_EXT = 194;
localparam COUNT_IN = ROWS_IN * DIM;
localparam COUNT_PAD = ROWS_PAD * DIM;

localparam ST_IDLE       = 5'd0;
localparam ST_ROW_INIT   = 5'd1;
localparam ST_ACC        = 5'd2;
localparam ST_MEAN       = 5'd3;
localparam ST_NEWTON     = 5'd4;
localparam ST_FACTOR     = 5'd5;
localparam ST_NORM_LOAD  = 5'd6;
localparam ST_NORM_CALC  = 5'd7;
localparam ST_NORM_SCALE = 5'd8;
localparam ST_NORM_CLIP  = 5'd9;
localparam ST_NORM_CHECK = 5'd10;
localparam ST_NEXT_ROW   = 5'd11;
localparam ST_EXT_CHECK  = 5'd12;
localparam ST_DONE       = 5'd13;
localparam ST_ACC_WAIT   = 5'd14;
localparam ST_EXT_OUT    = 5'd15;
localparam ST_ACC_LAT    = 5'd16;
localparam ST_NORM_LAT   = 5'd17;
localparam ST_NEWTON_DIV    = 5'd18;
localparam ST_NEWTON_COMMIT = 5'd19;
localparam ST_FACTOR_DIV    = 5'd20;
localparam ST_FACTOR_COMMIT = 5'd21;
// Pipeline the variance expression so the 64-bit square, divide-by-DIM and
// subtraction do not become one DSP/carry-chain critical path.
localparam ST_MEAN_DIV      = 5'd22;
localparam ST_VAR_COMMIT    = 5'd23;
localparam ST_MEAN_DIV_WAIT = 5'd24;
localparam ST_MEAN_VALUE_DIV  = 5'd25;
localparam ST_MEAN_VALUE_WAIT = 5'd26;
// Separate the BRAM read/subtract from the 32x32 normalization multiply.
// The previous single state formed BRAM -> subtract -> two DSP48s -> 64-bit
// result in one cycle and was the worst post-placement path in V894.
localparam ST_NORM_MUL        = 5'd27;

reg [4:0] state;
reg [7:0] row;
reg [7:0] col;
reg [3:0] iter;

reg signed [15:0] x_r;
reg signed [31:0] scale_r;
reg signed [31:0] bias_r;
reg signed [31:0] mean_r;
reg signed [31:0] factor_r;
reg signed [31:0] std_r;
reg signed [31:0] div_r;
reg signed [63:0] sum_r;
reg signed [63:0] sq_sum_r;
reg signed [63:0] mean_sum_sq_r;
reg signed [63:0] var_r;
`ifdef V879_NORM3_RADIX16
reg [63:0] div_quotient_r;
wire r16_mean_div_w = (state == ST_MEAN_DIV);
wire r16_mean_value_div_w = (state == ST_MEAN_VALUE_DIV);
wire r16_start_valid_w = r16_mean_value_div_w || r16_mean_div_w ||
                         (((state == ST_NEWTON) || (state == ST_FACTOR)) &&
                          (std_r != 32'sd0));
wire r16_start_ready_w;
wire r16_finish_valid_w;
wire [63:0] r16_quotient_w;
wire [63:0] r16_remainder_w;
wire r16_divisor_zero_w;
wire [63:0] r16_mean_abs_w = sum_r[63] ? (~sum_r[63:0] + 64'd1) : sum_r[63:0];
wire [63:0] r16_dividend_w = r16_mean_value_div_w ? r16_mean_abs_w :
                             r16_mean_div_w ? mean_sum_sq_r[63:0] :
                             ((state == ST_FACTOR) ?
                              64'd2147483647 : var_r[63:0]);
wire [63:0] r16_divisor_w = (r16_mean_value_div_w || r16_mean_div_w) ? 64'd192 :
                            {32'd0,std_r[31:0]};

intdiv_restoring_compat #(.D_W(64)) u_norm3_r16_divider(
    .start_valid_i(r16_start_valid_w),
    .start_ready_o(r16_start_ready_w),
    .flush_i(clear),
    .signed_op_i(1'b0),
    .dividend_i(r16_dividend_w),
    .divisor_i(r16_divisor_w),
    .finish_valid_o(r16_finish_valid_w),
    .finish_ready_i(1'b1),
    .quotient_o(r16_quotient_w),
    .remainder_o(r16_remainder_w),
    .divisor_is_zero_o(r16_divisor_zero_w),
    .clk(clk),
    .rst_n(rst_n)
);
`endif
reg signed [63:0] norm_raw_r;
reg signed [31:0] norm_delta_r;
reg signed [63:0] scaled_r;
reg signed [15:0] norm_r;
reg signed [15:0] ext_r;
reg input_rd_en;
reg [15:0] input_rd_addr;
wire [15:0] input_rd_data_u;
wire signed [15:0] input_rd_data_s = $signed(input_rd_data_u);
reg scale_rd_en;
reg [7:0] scale_rd_addr;
wire [31:0] scale_rd_data_u;
wire signed [31:0] scale_rd_data_s = $signed(scale_rd_data_u);
reg bias_rd_en;
reg [7:0] bias_rd_addr;
wire [31:0] bias_rd_data_u;
wire signed [31:0] bias_rd_data_s = $signed(bias_rd_data_u);
reg norm_wr_en;
reg [15:0] norm_wr_addr;
reg signed [15:0] norm_wr_data;
reg norm_rd_en;
reg [15:0] norm_rd_addr;
wire [15:0] norm_rd_data_u;
wire signed [15:0] norm_rd_data_s = $signed(norm_rd_data_u);

wire in_wr_ok_i = in_wr_valid && (in_wr_addr < COUNT_IN[15:0]);
wire scale_wr_ok_i = scale_wr_valid && (scale_wr_addr < DIM[7:0]);
wire bias_wr_ok_i = bias_wr_valid && (bias_wr_addr < DIM[7:0]);

v714_bram_sdp_sync #(
    .DATA_W(16),
    .ADDR_W(16),
    .DEPTH(COUNT_IN),
    .FIT_MAX_DEPTH(COUNT_IN)
) u_input_mem (
    .clk(clk),
    .wr_en(in_wr_ok_i),
    .wr_addr(in_wr_addr),
    .wr_data(in_wr_data),
    .rd_en(input_rd_en),
    .rd_addr(input_rd_addr),
    .rd_data(input_rd_data_u)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(8),
    .DEPTH(DIM)
) u_scale_mem (
    .clk(clk),
    .wr_en(scale_wr_ok_i),
    .wr_addr(scale_wr_addr),
    .wr_data(scale_wr_data),
    .rd_en(scale_rd_en),
    .rd_addr(scale_rd_addr),
    .rd_data(scale_rd_data_u)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(8),
    .DEPTH(DIM)
) u_bias_mem (
    .clk(clk),
    .wr_en(bias_wr_ok_i),
    .wr_addr(bias_wr_addr),
    .wr_data(bias_wr_data),
    .rd_en(bias_rd_en),
    .rd_addr(bias_rd_addr),
    .rd_data(bias_rd_data_u)
);

// Dead bank removed: both enables are always zero; ST_EXT_OUT has no incoming state edge.
assign norm_rd_data_u=16'd0;


always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        row <= 8'd0;
        col <= 8'd0;
        iter <= 4'd0;
        x_r <= 16'sd0;
        scale_r <= 32'sd0;
        bias_r <= 32'sd0;
        mean_r <= 32'sd0;
        factor_r <= 32'sd0;
        std_r <= 32'sd0;
        div_r <= 32'sd0;
        sum_r <= 64'sd0;
        sq_sum_r <= 64'sd0;
        mean_sum_sq_r <= 64'sd0;
        var_r <= 64'sd0;
`ifdef V879_NORM3_RADIX16
        div_quotient_r <= 64'd0;
`endif
        norm_raw_r <= 64'sd0;
        norm_delta_r <= 32'sd0;
        scaled_r <= 64'sd0;
        norm_r <= 16'sd0;
        ext_r <= 16'sd0;
        input_rd_en <= 1'b0;
        input_rd_addr <= 16'd0;
        scale_rd_en <= 1'b0;
        scale_rd_addr <= 8'd0;
        bias_rd_en <= 1'b0;
        bias_rd_addr <= 8'd0;
        norm_wr_en <= 1'b0;
        norm_wr_addr <= 16'd0;
        norm_wr_data <= 16'sd0;
        norm_rd_en <= 1'b0;
        norm_rd_addr <= 16'd0;
        busy <= 1'b0;
        done <= 1'b0;
        stat_input_writes <= 32'd0;
        stat_input_errors <= 32'd0;
        stat_rows <= 32'd0;
        stat_items <= 32'd0;
        stat_mean_errors <= 32'd0;
        stat_factor_errors <= 32'd0;
        stat_norm_errors <= 32'd0;
        stat_ext_errors <= 32'd0;
        out_valid <= 1'b0;
        out_addr <= 16'd0;
        out_data <= 16'sd0;
        stat_stream_items <= 32'd0;
    end else begin
        done <= 1'b0;
        input_rd_en <= 1'b0;
        scale_rd_en <= 1'b0;
        bias_rd_en <= 1'b0;
        norm_wr_en <= 1'b0;
        norm_rd_en <= 1'b0;
        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            out_valid <= 1'b0;
            stat_input_writes <= 32'd0;
            stat_input_errors <= 32'd0;
            stat_rows <= 32'd0;
            stat_items <= 32'd0;
            stat_mean_errors <= 32'd0;
            stat_factor_errors <= 32'd0;
            stat_norm_errors <= 32'd0;
            stat_ext_errors <= 32'd0;
            stat_stream_items <= 32'd0;
        end else begin
            if (in_wr_valid) begin
                if (in_wr_addr < COUNT_IN[15:0]) begin
                    stat_input_writes <= stat_input_writes + 1'b1;
                end else begin
                    stat_input_errors <= stat_input_errors + 1'b1;
                end
            end

            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        row <= 8'd0;
                        col <= 8'd0;
                        stat_rows <= 32'd0;
                        stat_items <= 32'd0;
                        stat_mean_errors <= 32'd0;
                        stat_factor_errors <= 32'd0;
                        stat_norm_errors <= 32'd0;
                        stat_ext_errors <= 32'd0;
                        stat_stream_items <= 32'd0;
                        state <= ST_ROW_INIT;
                    end
                end

                ST_ROW_INIT: begin
                    col <= 8'd0;
                    sum_r <= 64'sd0;
                    sq_sum_r <= 64'sd0;
                    state <= ST_ACC;
                end

                ST_ACC: begin
                    input_rd_en <= 1'b1;
                    input_rd_addr <= row * DIM[15:0] + col;
                    state <= ST_ACC_LAT;
                end

                ST_ACC_LAT: begin
                    state <= ST_ACC_WAIT;
                end

                ST_ACC_WAIT: begin
                    x_r <= input_rd_data_s;
                    sum_r <= sum_r + input_rd_data_s;
                    sq_sum_r <= sq_sum_r + input_rd_data_s * input_rd_data_s;
                    if (col == DIM - 1) begin
                        col <= 8'd0;
                        state <= ST_MEAN;
                    end else begin
                        col <= col + 1'b1;
                        state <= ST_ACC;
                    end
                end

                ST_MEAN: begin
                    mean_sum_sq_r <= sum_r * sum_r;
`ifdef V879_NORM3_RADIX16
                    state <= ST_MEAN_VALUE_DIV;
`else
                    mean_r <= sum_r / DIM;
                    state <= ST_MEAN_DIV;
`endif
                end

                ST_MEAN_VALUE_DIV: begin
`ifdef V879_NORM3_RADIX16
                    if (r16_start_ready_w)
                        state <= ST_MEAN_VALUE_WAIT;
`else
                    mean_r <= sum_r / DIM;
                    state <= ST_MEAN_DIV;
`endif
                end

                ST_MEAN_VALUE_WAIT: begin
`ifdef V879_NORM3_RADIX16
                    if (r16_finish_valid_w) begin
                        if (sum_r[63])
                            mean_r <= -$signed(r16_quotient_w[31:0]);
                        else
                            mean_r <= $signed(r16_quotient_w[31:0]);
                        state <= ST_MEAN_DIV;
                    end
`else
                    state <= ST_MEAN_DIV;
`endif
                end

                ST_MEAN_DIV: begin
`ifdef V879_NORM3_RADIX16
                    if (r16_start_ready_w)
                        state <= ST_MEAN_DIV_WAIT;
`else
                    mean_sum_sq_r <= mean_sum_sq_r / DIM;
                    state <= ST_VAR_COMMIT;
`endif
                end

                ST_MEAN_DIV_WAIT: begin
`ifdef V879_NORM3_RADIX16
                    if (r16_finish_valid_w) begin
                        mean_sum_sq_r <= $signed(r16_quotient_w);
                        state <= ST_VAR_COMMIT;
                    end
`else
                    state <= ST_VAR_COMMIT;
`endif
                end

                ST_VAR_COMMIT: begin
                    var_r <= sq_sum_r - mean_sum_sq_r;
                    std_r <= 32'sd65536;
                    iter <= 4'd0;
                    state <= ST_NEWTON;
                end

                ST_NEWTON: begin
                    if (std_r == 32'sd0) begin
                        div_r <= 32'sd0;
                        std_r <= 32'sd0;
                        if (iter == 4'd9)
                            state <= ST_FACTOR;
                        else
                            iter <= iter + 1'b1;
                    end else begin
`ifdef V879_NORM3_RADIX16
                        if (r16_start_ready_w)
                            state <= ST_NEWTON_DIV;
`else
                        div_r <= var_r / std_r;
                        std_r <= (std_r + (var_r / std_r)) >>> 1;
                        if (iter == 4'd9) begin
                            state <= ST_FACTOR;
                        end else begin
                            iter <= iter + 1'b1;
                        end
`endif
                    end
                end

                ST_NEWTON_DIV: begin
`ifdef V879_NORM3_RADIX16
                    if (r16_finish_valid_w) begin
                        div_quotient_r <= r16_quotient_w;
                        state <= ST_NEWTON_COMMIT;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_NEWTON_COMMIT: begin
`ifdef V879_NORM3_RADIX16
                    div_r <= $signed(div_quotient_r[31:0]);
                    std_r <= ($signed(std_r) +
                              $signed(div_quotient_r[31:0])) >>> 1;
                    if (iter == 4'd9)
                        state <= ST_FACTOR;
                    else begin
                        iter <= iter + 1'b1;
                        state <= ST_NEWTON;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_FACTOR: begin
                    if (std_r == 32'sd0) begin
                        factor_r <= 32'sd0;
                        state <= ST_NORM_LOAD;
                    end else begin
`ifdef V879_NORM3_RADIX16
                        if (r16_start_ready_w)
                            state <= ST_FACTOR_DIV;
`else
                        factor_r <= 32'sd2147483647 / std_r;
                        state <= ST_NORM_LOAD;
`endif
                    end
                end

                ST_FACTOR_DIV: begin
`ifdef V879_NORM3_RADIX16
                    if (r16_finish_valid_w) begin
                        div_quotient_r <= r16_quotient_w;
                        state <= ST_FACTOR_COMMIT;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_FACTOR_COMMIT: begin
`ifdef V879_NORM3_RADIX16
                    factor_r <= $signed(div_quotient_r[31:0]);
                    state <= ST_NORM_LOAD;
`else
                    state <= ST_IDLE;
`endif
                end

                ST_NORM_LOAD: begin
                    input_rd_en <= 1'b1;
                    input_rd_addr <= row * DIM[15:0] + col;
                    scale_rd_en <= 1'b1;
                    scale_rd_addr <= col;
                    bias_rd_en <= 1'b1;
                    bias_rd_addr <= col;
                    state <= ST_NORM_LAT;
                end

                ST_NORM_LAT: begin
                    state <= ST_NORM_CALC;
                end

                ST_NORM_CALC: begin
                    x_r <= input_rd_data_s;
                    scale_r <= scale_rd_data_s;
                    bias_r <= bias_rd_data_s;
                    // Preserve the original 32-bit Verilog subtraction
                    // semantics, but register it before the multiplier.
                    norm_delta_r <= $signed(input_rd_data_s) - mean_r;
                    state <= ST_NORM_MUL;
                end

                ST_NORM_MUL: begin
                    norm_raw_r <= (norm_delta_r * factor_r) >>> 1;
                    state <= ST_NORM_SCALE;
                end

                ST_NORM_SCALE: begin
                    scaled_r <= ((norm_raw_r + bias_r) * scale_r) >>> 29;
                    state <= ST_NORM_CLIP;
                end

                ST_NORM_CLIP: begin
                    if (scaled_r > 64'sd127)
                        norm_r <= 16'sd127;
                    else if (scaled_r < -64'sd128)
                        norm_r <= -16'sd128;
                    else
                        norm_r <= scaled_r[15:0];
                    state <= ST_NORM_CHECK;
                end

                ST_NORM_CHECK: begin
                    // Hold each output until the downstream store adapter
                    // accepts it.  The previous implementation pulsed
                    // out_valid for one cycle and advanced unconditionally,
                    // which dropped beats whenever authenticated writeback
                    // applied backpressure.
                    if (!out_valid) begin
                        out_valid <= 1'b1;
                        out_addr <= row * DIM_EXT[15:0] + col;
                        out_data <= norm_r;
                    end else if (out_ready) begin
                        out_valid <= 1'b0;
                        stat_items <= stat_items + 1'b1;
                        stat_stream_items <= stat_stream_items + 1'b1;
                        if (col == DIM - 1) begin
                            state <= ST_NEXT_ROW;
                        end else begin
                            col <= col + 1'b1;
                            state <= ST_NORM_LOAD;
                        end
                    end
                end

                ST_NEXT_ROW: begin
                    stat_rows <= stat_rows + 1'b1;
                    // The external tensor is row-major with DIM_EXT=194,
                    // while the normalized input has DIM=192 values per
                    // row.  Emit the two deterministic extension values
                    // immediately after every real row; the old code
                    // deferred all extension values until after row 255,
                    // silently dropping them from each intermediate row in
                    // the AXI write stream.
                    col <= DIM[7:0];
                    state <= ST_EXT_CHECK;
                end

                ST_EXT_CHECK: begin
                    if (!out_valid) begin
                        if (col < DIM) begin
                            col <= DIM[7:0];
                        end else begin
                            if (col == DIM)
                                ext_r = 16'sd16384;
                            else
                                ext_r = 16'sd1;
                            out_valid <= 1'b1;
                            out_addr <= row * DIM_EXT + col;
                            out_data <= ext_r;
                        end
                    end else if (out_ready) begin
                        out_valid <= 1'b0;
                        stat_stream_items <= stat_stream_items + 1'b1;
                        if ((row == ROWS_PAD - 1) && (col == DIM_EXT - 1)) begin
                            state <= ST_DONE;
                        end else if (col == DIM_EXT - 1) begin
                            col <= 8'd0;
                            row <= row + 1'b1;
                            state <= ST_ROW_INIT;
                        end else begin
                            col <= col + 1'b1;
                        end
                    end
                end

                ST_EXT_OUT: begin
                    if (!out_valid) begin
                        ext_r = norm_rd_data_s;
                        out_valid <= 1'b1;
                        out_addr <= row * DIM_EXT + col;
                        out_data <= norm_rd_data_s;
                    end else if (out_ready) begin
                        out_valid <= 1'b0;
                        stat_stream_items <= stat_stream_items + 1'b1;
                        if ((row == ROWS_PAD - 1) && (col == DIM_EXT - 1)) begin
                            state <= ST_DONE;
                        end else if (col == DIM_EXT - 1) begin
                            col <= 8'd0;
                            row <= row + 1'b1;
                            state <= ST_EXT_CHECK;
                        end else begin
                            col <= col + 1'b1;
                            state <= ST_EXT_CHECK;
                        end
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule

