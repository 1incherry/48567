`timescale 1ns/1ps
// Runtime stimulus only. Feeds the actual requested frame over the NFR packet
// interface. All source bytes are native RGB565, not golden RGB/letterbox/head.
module full_chain_nfr_source #(
 parameter WIRE_FILE="source640.wire_rgb565.hex",parameter HEADER_FILE="wire_headers_base.hex"
)(
 input wire clk,rst_n,enable,
 input wire response_valid,input wire [7:0] response_kind,
 input wire [31:0] response_session,response_frame,response_offset,
 output reg packet_valid,output reg [383:0] packet_header,input wire packet_release,
 input wire payload_read,input wire [9:0] payload_address,
 output reg [7:0] payload_data,output reg payload_read_valid,
 output reg finished
);
reg [7:0] wire_bytes[0:614399];reg [383:0] headers[0:599];
integer packet_index;reg [31:0] session_id,frame_id;integer requested;
always @(posedge clk)begin
 payload_read_valid<=payload_read;
 if(payload_read)begin
  if(packet_index<0||packet_index>=600)$fatal(1,"NFR read without current packet");
  payload_data<=wire_bytes[packet_index*1024+payload_address];
 end
end
initial begin
 packet_valid=0;packet_header=0;payload_data=0;payload_read_valid=0;finished=0;packet_index=0;requested=0;
 $readmemh(WIRE_FILE,wire_bytes);$readmemh(HEADER_FILE,headers);
 wait(rst_n&&enable);
 do @(posedge clk);while(!(response_valid&&response_kind==1));
 session_id=response_session;frame_id=response_frame;requested=1;
 repeat(2)@(negedge clk);
 for(packet_index=0;packet_index<600;packet_index=packet_index+1)begin
  packet_header=headers[packet_index];packet_header[319:288]=session_id;packet_header[287:256]=frame_id;
  packet_valid=1;wait(packet_release);@(negedge clk);packet_valid=0;wait(!packet_release);
  repeat(4)@(negedge clk);
 end
 finished=1;
 $display("FULL_CHAIN_NFR_RUNTIME_SOURCE_SENT RGB565_bytes=614400 packets=600 actual_requested_session=%0d frame=%0d no_intermediate_seed=1",session_id,frame_id);
end
endmodule
