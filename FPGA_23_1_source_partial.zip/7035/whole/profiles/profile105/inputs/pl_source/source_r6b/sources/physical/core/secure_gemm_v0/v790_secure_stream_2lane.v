`timescale 1ns/1ps

// V790 throughput experiment: two independent V788 256-bit crypto lanes.
// A second beat can enter while the first beat's two SM4 cores are iterating.
// Ordering is preserved (lane0 output before lane1 output).
module v790_secure_stream_sm4_ctr_2lane #(
    parameter DATA_WIDTH=256, parameter KEEP_WIDTH=DATA_WIDTH/8,
    parameter CORE_ROUNDS_PER_CYCLE=1
) (
    input wire clk, input wire rst_n, input wire clear,
    input wire crypto_enable, input wire [127:0] crypto_key, input wire [95:0] crypto_nonce,
    input wire cmd_fire, input wire [31:0] cmd_addr,
    input wire s_valid, output wire s_ready, input wire [DATA_WIDTH-1:0] s_data,
    input wire [KEEP_WIDTH-1:0] s_keep, input wire s_last,
    output wire m_valid, input wire m_ready, output wire [DATA_WIDTH-1:0] m_data,
    output wire [KEEP_WIDTH-1:0] m_keep, output wire m_last,
    output wire [31:0] stat_beats, output wire [31:0] stat_stall_cycles
);
wire r0,r1,v0,v1;wire[DATA_WIDTH-1:0]d0,d1;
wire[KEEP_WIDTH-1:0]k0,k1;wire l0,l1;wire[31:0]b0,b1,s0,s1;
reg[1:0]order_count;reg order0,order1;reg[31:0]next_addr;
reg[31:0]stat_beats_reg,stat_stall_reg;
wire queue_space=(order_count<2);
wire choose0=crypto_enable&&queue_space&&r0;
wire choose1=crypto_enable&&queue_space&&!r0&&r1;
wire push=crypto_enable&&s_valid&&(choose0||choose1);
wire push_lane=choose1;
wire[31:0]accept_addr=cmd_fire?cmd_addr:next_addr;
wire head_valid=(order_count!=0);
wire head_lane=order0;
wire crypto_m_valid=head_valid&&(head_lane?v1:v0);
wire pop=crypto_enable&&crypto_m_valid&&m_ready;
wire lane0_m_ready=crypto_enable&&head_valid&&!head_lane&&m_ready;
wire lane1_m_ready=crypto_enable&&head_valid&&head_lane&&m_ready;

v788_secure_stream_sm4_ctr #(.DATA_WIDTH(DATA_WIDTH),.KEEP_WIDTH(KEEP_WIDTH),
 .CORE_ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_lane0 (
 .clk(clk),.rst_n(rst_n),.clear(clear),.crypto_enable(crypto_enable),.crypto_key(crypto_key),.crypto_nonce(crypto_nonce),
 .cmd_fire(push&&!push_lane),.cmd_addr(accept_addr),.s_valid(s_valid&&choose0),.s_ready(r0),.s_data(s_data),.s_keep(s_keep),.s_last(s_last),
 .m_valid(v0),.m_ready(lane0_m_ready),.m_data(d0),.m_keep(k0),.m_last(l0),.stat_beats(b0),.stat_stall_cycles(s0));
v788_secure_stream_sm4_ctr #(.DATA_WIDTH(DATA_WIDTH),.KEEP_WIDTH(KEEP_WIDTH),
 .CORE_ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_lane1 (
 .clk(clk),.rst_n(rst_n),.clear(clear),.crypto_enable(crypto_enable),.crypto_key(crypto_key),.crypto_nonce(crypto_nonce),
 .cmd_fire(push&&push_lane),.cmd_addr(accept_addr),.s_valid(s_valid&&choose1),.s_ready(r1),.s_data(s_data),.s_keep(s_keep),.s_last(s_last),
 .m_valid(v1),.m_ready(lane1_m_ready),.m_data(d1),.m_keep(k1),.m_last(l1),.stat_beats(b1),.stat_stall_cycles(s1));

assign s_ready=crypto_enable?(queue_space&&(r0||r1)):m_ready;
assign m_valid=crypto_enable?crypto_m_valid:s_valid;
assign m_data=crypto_enable?(head_lane?d1:d0):s_data;
assign m_keep=crypto_enable?(head_lane?k1:k0):s_keep;
assign m_last=crypto_enable?(head_lane?l1:l0):s_last;
assign stat_beats=stat_beats_reg;
assign stat_stall_cycles=stat_stall_reg;

always@(posedge clk)begin
 if(!rst_n||clear)begin
  order_count<=0;order0<=0;order1<=0;next_addr<=0;
  stat_beats_reg<=0;stat_stall_reg<=0;
 end else begin
  if(cmd_fire)next_addr<=cmd_addr;
  if(push)next_addr<=accept_addr+32'd32;
  case({push,pop})
   2'b10:begin
    if(order_count==0)order0<=push_lane;else order1<=push_lane;
    order_count<=order_count+1'b1;
   end
   2'b01:begin order0<=order1;order_count<=order_count-1'b1;end
   2'b11:begin
    if(order_count==1)order0<=push_lane;
    else begin order0<=order1;order1<=push_lane;end
   end
  endcase
  if(m_valid&&m_ready)stat_beats_reg<=stat_beats_reg+1'b1;
  if(m_valid&&!m_ready)stat_stall_reg<=stat_stall_reg+1'b1;
`ifdef V804_DEBUG_X
  if(push && (^s_data === 1'bx))
    $display("V804_X_V790_IN lane=%0d data=%064h next=%032h",push_lane,s_data,next_addr);
  if(pop && (^m_data === 1'bx))
    $display("V804_X_V790_OUT lane=%0d data=%064h order_count=%0d",head_lane,m_data,order_count);
`endif
 end
end
endmodule
