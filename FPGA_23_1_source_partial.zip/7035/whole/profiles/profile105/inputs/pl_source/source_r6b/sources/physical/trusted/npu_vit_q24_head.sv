`timescale 1ns/1ps
// Exact arithmetic replacement for classify_final() in the preserved PS app.
// Features and coefficients must come from protected PL producer/cache paths.
// This core alone does not authenticate them or create a trusted task context.
module npu_vit_q24_head #(
 parameter integer FEATURES=194,CLASSES=105,TIMEOUT_CYCLES=1048575
)(input wire clk,rst_n,start,cancel,
 input wire feature_valid,input wire signed [15:0] feature_data,output wire feature_ready,
 input wire bias_valid,input wire signed [31:0] bias_data,output wire bias_ready,
 input wire weight_valid,input wire signed [31:0] weight_data,output wire weight_ready,
 output wire busy,output reg done,fault,output reg [7:0] class_index,
 output reg signed [63:0] best_logit,output reg [31:0] elapsed_cycles,
 output reg logit_valid,output reg [7:0] logit_class,output reg signed [63:0] logit_data);
 localparam IDLE=0,FEATURE=1,BIAS=2,WEIGHT=3,ACCUMULATE=4,COMPARE=5,FINISH=6,FAILED=7;
 reg [2:0] state;reg [7:0] feature_index,current_class;
 (* ram_style="distributed" *) reg signed [15:0] features[0:FEATURES-1];
 reg signed [47:0] product;reg signed [63:0] sum;
 assign busy=state!=IDLE&&state!=FINISH&&state!=FAILED;
 assign feature_ready=state==FEATURE&&!cancel&&!start;
 assign bias_ready=state==BIAS&&!cancel&&!start;
 assign weight_ready=state==WEIGHT&&!cancel&&!start;
 always @(posedge clk)begin
  if(feature_valid&&feature_ready)features[feature_index]<=feature_data;
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;feature_index<=0;current_class<=0;product<=0;sum<=0;
   done<=0;fault<=0;class_index<=0;best_logit<=64'sh8000000000000000;elapsed_cycles<=0;
   logit_valid<=0;logit_class<=0;logit_data<=0;
  end else begin
   logit_valid<=0;
   if(cancel)begin state<=FAILED;fault<=1;done<=1;class_index<=0;best_logit<=0;end
   else if(start)begin
    state<=busy?FAILED:FEATURE;fault<=busy;done<=busy;
    feature_index<=0;current_class<=0;product<=0;sum<=0;class_index<=0;
    best_logit<=64'sh8000000000000000;elapsed_cycles<=0;
   end else if(busy&&elapsed_cycles>=TIMEOUT_CYCLES)begin
    state<=FAILED;done<=1;fault<=1;class_index<=0;best_logit<=0;
   end else begin
    if(busy)elapsed_cycles<=elapsed_cycles+1'b1;
    case(state)
     FEATURE:if(feature_valid&&feature_ready)begin
      if(feature_index==FEATURES-1)begin feature_index<=0;state<=BIAS;end
      else feature_index<=feature_index+1'b1;
     end
     BIAS:if(bias_valid&&bias_ready)begin
      sum<=$signed({{32{bias_data[31]}},bias_data})<<<14;feature_index<=0;state<=WEIGHT;
     end
     WEIGHT:if(weight_valid&&weight_ready)begin
      product<=weight_data*features[feature_index];state<=ACCUMULATE;
     end
     ACCUMULATE:begin
      sum<=sum+{{16{product[47]}},product};
      if(feature_index==FEATURES-1)state<=COMPARE;
      else begin feature_index<=feature_index+1'b1;state<=WEIGHT;end
     end
     COMPARE:begin
      logit_valid<=1;logit_class<=current_class;logit_data<=sum;
      if(current_class==0 || sum>best_logit)begin best_logit<=sum;class_index<=current_class;end
      if(current_class==CLASSES-1)begin state<=FINISH;done<=1;end
      else begin current_class<=current_class+1'b1;state<=BIAS;end
     end
     default:;
    endcase
   end
  end
 end
endmodule
