`timescale 1ns/1ps

`include "source_r6b/sources/physical/core/secure_gemm_v0/npu_norm2_fc1_shared_A.sv"



module v736_fullblock_nomemh_axi_lite_full_top #(

    parameter ENABLE_LIVE_CHAIN = 0,

    parameter AXI_ADDR_WIDTH = 32,

    parameter AXI_DATA_WIDTH = 256,

    parameter [AXI_ADDR_WIDTH-1:0] OUT_BASE_ADDR = 32'h0000_0000,

    parameter [15:0] NORM3_TOTAL_ITEMS = 16'd49664,
    parameter integer CLOSED_AUDIO_PRODUCER=0, parameter integer ENABLE_MIC_B=0

) (







    // These ports must be driven by trusted PL, never a PS CSR mirror.

    input wire trusted_authorized, trusted_cancel,

    input wire [31:0] trusted_epoch,

    input wire handoff_start, handoff_seed,

    input wire signed [31:0] handoff_pose_coefficient,

    input wire capture_pose, capture_norm, private_reads_phase,

    output wire handoff_ready, handoff_fault, private_read_fault,

    output wire trusted_fc2_valid, trusted_fc2_done,

    output wire [15:0] trusted_fc2_address,

    output wire signed [15:0] trusted_fc2_data,

    output wire trusted_norm_valid, trusted_norm_done,

    output wire [15:0] trusted_norm_address,

    output wire signed [15:0] trusted_norm_data,

    input wire classification_start, classification_capture,

    output wire classifier_page_request,

    input wire classifier_page_request_ready,

    output wire [31:0] classifier_expected_page_index,

    input wire classifier_cache_valid,

    input wire [31:0] classifier_cached_page_index,

    output wire classifier_cache_read,

    output wire [9:0] classifier_cache_read_addr,

    input wire classifier_cache_read_valid,

    input wire [31:0] classifier_cache_read_data,

    output wire classifier_norm_ready,classifier_busy,classifier_fault,

    output wire trusted_result_valid,

    output wire [7:0] trusted_class_index,

    output wire signed [63:0] trusted_best_logit,

    output wire [31:0] trusted_result_epoch,

    input wire frontend_owner,frontend_clear,frontend_start,

    input wire frontend_input_valid,

    input wire [15:0] frontend_input_address,

    input wire signed [15:0] frontend_input_data,

    input wire frontend_scale_valid,frontend_bias_valid,

    input wire [7:0] frontend_param_address,

    input wire signed [31:0] frontend_param_data,

    input wire frontend_ready,

    output wire frontend_valid,frontend_done,

    output wire [15:0] frontend_address,

    output wire signed [15:0] frontend_data,


    output wire observation_logit_valid,
    output wire [7:0] observation_logit_class,
    output wire [63:0] observation_logit_data,
    input wire security_reset_n,
        input wire audio_b_write,audio_b_read,input wire[11:0]audio_b_write_address,audio_b_read_address,
 input wire[255:0]audio_b_write_data,input wire audio_b_response_ready,
 output wire audio_b_write_accepted,audio_b_read_accepted,audio_b_read_response_valid,audio_b_drained,
 output wire[255:0]audio_b_read_data,
input wire audio_a_write,audio_a_read,
    input wire [11:0] audio_a_write_address,audio_a_read_address,
    input wire [255:0] audio_a_write_data,
    output wire [255:0] audio_a_read_data,
    output wire pool_protocol_violation,
input wire [2:0] pool_desired_stage,
    input wire pool_all_quiescent,pool_access_live,
    output wire [2:0] pool_committed_stage,
    output wire pool_owner_ready,pool_fault,pool_quiescent,pool_local_quiescent,
    input wire shared_owner,

    input wire shared_a_write,shared_b_write,

    input wire [11:0] shared_write_address,

    input wire [255:0] shared_write_data,

    input wire shared_a_read,shared_b_read,

    input wire [11:0] shared_a_address,shared_b_address,

    output wire [255:0] shared_a_data,shared_b_data,

    input  wire                         clk,

    input  wire                         rst_n,



    input  wire [7:0]                   S_AXIL_AWADDR,

    input  wire                         S_AXIL_AWVALID,

    output wire                         S_AXIL_AWREADY,

    input  wire [31:0]                  S_AXIL_WDATA,

    input  wire [3:0]                   S_AXIL_WSTRB,

    input  wire                         S_AXIL_WVALID,

    output wire                         S_AXIL_WREADY,

    output wire [1:0]                   S_AXIL_BRESP,

    output wire                         S_AXIL_BVALID,

    input  wire                         S_AXIL_BREADY,

    input  wire [7:0]                   S_AXIL_ARADDR,

    input  wire                         S_AXIL_ARVALID,

    output wire                         S_AXIL_ARREADY,

    output wire [31:0]                  S_AXIL_RDATA,

    output wire [1:0]                   S_AXIL_RRESP,

    output wire                         S_AXIL_RVALID,

    input  wire                         S_AXIL_RREADY,



    output wire [AXI_ADDR_WIDTH-1:0]    M_AXI_ARADDR,

    output wire [7:0]                   M_AXI_ARLEN,

    output wire [2:0]                   M_AXI_ARSIZE,

    output wire [1:0]                   M_AXI_ARBURST,

    output wire                         M_AXI_ARVALID,

    input  wire                         M_AXI_ARREADY,

    input  wire [AXI_DATA_WIDTH-1:0]    M_AXI_RDATA,

    input  wire [1:0]                   M_AXI_RRESP,

    input  wire                         M_AXI_RLAST,

    input  wire                         M_AXI_RVALID,

    output wire                         M_AXI_RREADY,



    output wire [AXI_ADDR_WIDTH-1:0]    M_AXI_AWADDR,

    output wire [7:0]                   M_AXI_AWLEN,

    output wire [2:0]                   M_AXI_AWSIZE,

    output wire [1:0]                   M_AXI_AWBURST,

    output wire                         M_AXI_AWVALID,

    input  wire                         M_AXI_AWREADY,

    output wire [AXI_DATA_WIDTH-1:0]    M_AXI_WDATA,

    output wire [AXI_DATA_WIDTH/8-1:0]  M_AXI_WSTRB,

    output wire                         M_AXI_WLAST,

    output wire                         M_AXI_WVALID,

    input  wire                         M_AXI_WREADY,

    input  wire [1:0]                   M_AXI_BRESP,

    input  wire                         M_AXI_BVALID,

    output wire                         M_AXI_BREADY,



    // Optional trusted data-authentication sideband.  These ports are active

    // under V799_BURST_AUTH or V801_LOAD_AUTH; legacy builds are unchanged.

    input  wire                         data_auth_enable,

    input  wire                         data_auth_expected_valid,

    input  wire [127:0]                 data_auth_expected_tag,

    input  wire [127:0]                 data_auth_mac_key,

    input  wire [111:0]                 data_auth_context,

    input  wire                         data_auth_common_enable,

    input  wire [127:0]                 data_auth_common_object_context,

    input  wire [7:0]                   data_auth_common_dtype,

    input  wire [7:0]                   data_auth_common_role,

    input  wire [7:0]                   data_auth_common_key_id,

    input  wire                         data_auth_secure_clear,

    output wire                         data_auth_done,

    output wire                         data_auth_ok,

    output wire                         data_auth_fail,



    output wire integration_busy,

    output wire [31:0]                  stat0,

    output wire [31:0]                  stat1,

    output wire [31:0]                  stat2,

    output wire [31:0]                  stat3

);



wire integration_loader_busy,integration_concat_busy,integration_outproj_busy,integration_norm2_busy;

wire store_fc2_select;

reg [15:0] capture_index;

reg [31:0] capture_drops;

wire clear_pulse;

wire shared_A_fault,private_handoff_fault;

assign handoff_fault=private_handoff_fault|shared_A_fault;

wire axil_clear_pulse;

// A trusted security clear must stop the complete datapath, not merely the

// authentication shell.  The runtime clear register remains available, while

// data_auth_secure_clear is the root-of-trust zeroize/abort path.

assign clear_pulse = axil_clear_pulse | data_auth_secure_clear;

wire load_start;

wire qkv_bank_start;

wire qkv_compute_start;

wire qkt_start;

wire softmax_start;

wire prob_bank_start;

wire av_start;

wire concat_start;

wire outproj_start;

wire norm2_start;

wire fc1_start;

wire gelu_start;

wire fc2_pad_start;

wire fc2_start;

wire norm3_start;

wire store_start;

wire [7:0] load_dst;

wire [31:0] load_axi_addr;

wire [17:0] load_local_addr;

wire [15:0] load_beats;

wire [7:0] load_burst_len_m1;

wire [3:0] qkv_block_id;

wire [3:0] qkv_op_id;

wire [1:0] current_head;

wire signed [31:0] softmax_x0;

wire signed [31:0] gelu_x0;

wire [1:0] prefetch_mode;

wire [1:0] security_mode;

wire [11:0] prefetch_window_cap;

wire [11:0] stage_budget_cap;

wire [11:0] window_guard_words;

wire [31:0] window_base_addr;

wire [15:0] window_stride_words;

wire [7:0] crypto_key_id;

wire [7:0] prefetch_ahead_beats;

wire [127:0] crypto_key;

wire [95:0] crypto_nonce;



wire qkv_loader_sel = (load_dst < 8'd3);

wire generic_loader_sel = !qkv_loader_sel;

wire qkv_load_done;

wire qkv_axi_load_done;

wire qkv_command_ready;

wire generic_command_ready;

wire generic_load_done;



wire [31:0] qkv_araddr;

wire [7:0] qkv_arlen;

wire [2:0] qkv_arsize;

wire [1:0] qkv_arburst;

wire qkv_arvalid;

wire qkv_rready;



wire [31:0] gen_araddr;

wire [7:0] gen_arlen;

wire [2:0] gen_arsize;

wire [1:0] gen_arburst;

wire gen_arvalid;

wire gen_rready;



wire [31:0] stat_load_beats;

wire [31:0] stat_load_errors;

wire [31:0] stat_qkv_compute_cycles;

wire [31:0] stat_qkv_compute_tiles;

wire [31:0] stat_qkv_quant_items;

wire [31:0] stat_bank_inputs;

wire [31:0] stat_qkt_tiles;

wire [31:0] stat_qkt_cycles;

wire [31:0] stat_softmax_rows;

wire [31:0] stat_av_tiles;

wire [31:0] stat_av_cycles;



wire qkv_compute_busy;

wire qkv_compute_done;

wire qkt_busy;

wire qkt_done;

wire softmax_busy;

wire softmax_done;

wire prob_bank_done;

wire av_busy;

wire av_done;

wire av_ctx_tile_valid;

wire [15:0] av_ctx_tile_addr;

wire [127:0] av_ctx_tile_data;



wire qkt_scale_wr_valid;

wire [15:0] qkt_scale_wr_addr;

wire signed [31:0] qkt_scale_wr_data;

wire av_scale_wr_valid;

wire [15:0] av_scale_wr_addr;

wire signed [31:0] av_scale_wr_data;



wire loader_outproj_a_wr_valid;

wire [11:0] loader_outproj_a_wr_addr;

wire [255:0] loader_outproj_a_wr_data;

wire loader_outproj_b_wr_valid;

wire [11:0] loader_outproj_b_wr_addr;

wire [255:0] loader_outproj_b_wr_data;

wire loader_outproj_scale_wr_valid;

wire [7:0] loader_outproj_scale_wr_addr;

wire signed [31:0] loader_outproj_scale_wr_data;

wire loader_outproj_residual_wr_valid;

wire [15:0] loader_outproj_residual_wr_addr;

wire signed [15:0] loader_outproj_residual_wr_data;

wire norm2_scale_wr_valid;

wire [7:0] norm2_scale_wr_addr;

wire signed [31:0] norm2_scale_wr_data;

wire norm2_bias_wr_valid;

wire [7:0] norm2_bias_wr_addr;

wire signed [31:0] norm2_bias_wr_data;

wire loader_fc1_a_wr_valid;

wire [15:0] loader_fc1_a_wr_addr;

wire signed [15:0] loader_fc1_a_wr_data;

wire fc1_b_wr_valid;

wire [17:0] fc1_b_wr_addr;

wire signed [15:0] fc1_b_wr_data;

wire fc1_scale_wr_valid;

wire [9:0] fc1_scale_wr_addr;

wire signed [31:0] fc1_scale_wr_data;

wire gelu_scale_wr_valid;

wire signed [31:0] gelu_scale_wr_data;

wire fc2_b_wr_valid;

wire [17:0] fc2_b_wr_addr;

wire signed [15:0] fc2_b_wr_data;

wire fc2_scale_wr_valid;

wire [7:0] fc2_scale_wr_addr;

wire signed [31:0] fc2_scale_wr_data;

wire fc2_add_scale_wr_valid;

wire signed [31:0] fc2_add_scale_wr_data;

wire fc2_residual_wr_valid;

wire [15:0] fc2_residual_wr_addr;

wire signed [15:0] fc2_residual_wr_data;

wire norm3_scale_wr_valid;

wire [7:0] norm3_scale_wr_addr;

wire signed [31:0] norm3_scale_wr_data;

wire norm3_bias_wr_valid;

wire [7:0] norm3_bias_wr_addr;

wire signed [31:0] norm3_bias_wr_data;



wire concat_done;

wire concat_out_valid;

wire [15:0] concat_out_tile_addr;

wire [255:0] concat_out_tile_data;

wire [31:0] concat_out_tiles;

wire [31:0] concat_errors;



wire outproj_a_wr_valid = concat_out_valid ? 1'b1 : loader_outproj_a_wr_valid;

wire [11:0] outproj_a_wr_addr = concat_out_valid ? concat_out_tile_addr[11:0] : loader_outproj_a_wr_addr;

wire [255:0] outproj_a_wr_data = concat_out_valid ? concat_out_tile_data : loader_outproj_a_wr_data;

wire linear_out_valid;

wire linear_out_ready;

wire [15:0] linear_out_addr;

wire signed [15:0] linear_out_data;

wire outproj_done;

wire [31:0] outproj_cycles;



wire norm2_out_valid;

wire [15:0] norm2_out_addr;

wire signed [15:0] norm2_out_data;

wire norm2_done;

wire [31:0] norm2_cycles;



wire router_fc1_a_wr_valid;

wire [15:0] router_fc1_a_wr_addr;

wire signed [15:0] router_fc1_a_wr_data;

wire fc1_a_wr_valid = router_fc1_a_wr_valid | loader_fc1_a_wr_valid;

wire [15:0] fc1_a_wr_addr = router_fc1_a_wr_valid ? router_fc1_a_wr_addr : loader_fc1_a_wr_addr;

wire signed [15:0] fc1_a_wr_data = router_fc1_a_wr_valid ? router_fc1_a_wr_data : loader_fc1_a_wr_data;



wire fc1_busy;

wire fc1_done;

wire fc1_out_valid;

wire [17:0] fc1_out_addr;

wire signed [7:0] fc1_out_data;

wire [31:0] fc1_cycles;



wire gelu_busy;

wire gelu_done;

wire gelu_out_valid;

wire [17:0] gelu_out_addr;

wire signed [7:0] gelu_out_data;

wire fc2_in_wr_ready;

wire [31:0] gelu_stream_items;



reg fc2_pad_active;

wire fc2_pad_done;

wire router_fc2_in_wr_valid;

wire [17:0] router_fc2_in_wr_addr;

wire signed [15:0] router_fc2_in_wr_data;

wire fc2_busy;

wire fc2_done;

wire fc2_out_valid;

wire [15:0] fc2_out_addr;

wire signed [15:0] fc2_out_data;

wire [31:0] fc2_stream_items;



wire norm3_busy;

wire norm3_done;

wire norm3_out_valid;

wire [15:0] norm3_out_addr;

wire signed [15:0] norm3_out_data;

wire [31:0] norm3_stream_items;



wire store_busy;

wire store_done;

wire store_stream_ready;

wire [31:0] stat_store_beats;

wire [31:0] stat_store_errors;

wire [31:0] stat_store_fifo_stall_cycles;

wire [7:0] stat_store_fifo_max_level;

wire [7:0] stat_store_fifo_level;



wire [4:0] gelu_group_level;

wire [4:0] gelu_group_max_level;

wire [31:0] gelu_input_blocked_cycles;

wire [31:0] gelu_output_stall_cycles;



reg [31:0] profile_axi_read_data_cycles;

reg [31:0] profile_axi_read_memory_wait_cycles;

reg [31:0] profile_axi_read_backpressure_cycles;

reg [31:0] profile_axi_write_data_cycles;

reg [31:0] profile_axi_write_backpressure_cycles;

reg [31:0] profile_pe_active_cycles;

wire profile_pe_busy = qkv_compute_busy || qkt_busy || av_busy || fc1_busy || fc2_busy;



wire [AXI_DATA_WIDTH-1:0] secure_read_data;

wire [AXI_DATA_WIDTH/8-1:0] secure_read_keep;

wire secure_read_valid;

wire secure_read_last;

wire selected_loader_rready = qkv_loader_sel ? qkv_rready : gen_rready;

wire [31:0] secure_read_beats;

wire [31:0] secure_read_stall_cycles;

wire secure_read_cmd_ready;

wire selected_loader_arvalid = qkv_loader_sel ? qkv_arvalid : gen_arvalid;



wire [AXI_DATA_WIDTH-1:0] store_axi_wdata;

wire [AXI_DATA_WIDTH/8-1:0] store_axi_wstrb;

wire store_axi_wlast;

wire store_axi_wvalid;

wire store_axi_wready;

wire [31:0] secure_write_beats;

wire [31:0] secure_write_stall_cycles;



wire [31:0] loader_stat_cmds;

wire [31:0] loader_stat_beats;

wire [31:0] loader_stat_items;

wire [31:0] loader_stat_errors;

wire [31:0] loader_stat_cycles;

wire [31:0] loader_stat_window_errors;

wire [31:0] loader_stat_window_peak_beats;

wire [31:0] loader_stat_last_cmd_faults;



wire guard_load_beats_over_cap = (load_beats > {4'd0, prefetch_window_cap});

wire guard_stage_over_cap = (stage_budget_cap != 12'd0) && (load_local_addr[11:0] > stage_budget_cap);

wire guard_security_key_missing = (security_mode != 2'd0) && (crypto_key_id == 8'd0);

wire guard_prefetch_disabled = (prefetch_mode == 2'd0);

// The mode fields are configuration state, not error counters. Earlier V77x

// packaged RTL concatenated them into stat3, so the normal prefetch_mode=1

// appeared as a false error value of 64. Only report active guard violations,

// and only when strict window-contract mode (prefetch_mode[1]) is selected.

wire [3:0] guard_fault_count =

    {3'd0, guard_prefetch_disabled} +

    {3'd0, guard_security_key_missing} +

    {3'd0, guard_stage_over_cap} +

    {3'd0, guard_load_beats_over_cap};

wire [31:0] stat_guard_errors = prefetch_mode[1] ? {28'd0, guard_fault_count} : 32'd0;





// Private handoff intercepts only reads selected by the trusted PL phase.

// Static parameter reads still need the authenticated page service upstream.

wire [31:0] private_inner_ARADDR;

wire [7:0] private_inner_ARLEN;

wire [2:0] private_inner_ARSIZE;

wire [1:0] private_inner_ARBURST;

wire private_inner_ARVALID,private_inner_ARREADY;

wire [255:0] private_inner_RDATA;

wire [1:0] private_inner_RRESP;

wire private_inner_RLAST,private_inner_RVALID,private_inner_RREADY;

wire local_arready,local_rlast,local_rvalid;

wire [255:0] local_rdata;

wire [1:0] local_rresp;

wire bank_req,bank_kind,bank_reqready,bank_rvalid,bank_rready;

wire [11:0] bank_beat;

wire [255:0] bank_rdata;

assign M_AXI_ARADDR=private_inner_ARADDR;

assign M_AXI_ARLEN=private_inner_ARLEN;

assign M_AXI_ARSIZE=private_inner_ARSIZE;

assign M_AXI_ARBURST=private_inner_ARBURST;

assign M_AXI_ARVALID=private_inner_ARVALID&&!private_reads_phase;

assign M_AXI_RREADY=private_inner_RREADY&&!private_reads_phase;

assign private_inner_ARREADY=private_reads_phase?local_arready:M_AXI_ARREADY;

assign private_inner_RDATA=private_reads_phase?local_rdata:M_AXI_RDATA;

assign private_inner_RRESP=private_reads_phase?local_rresp:M_AXI_RRESP;

assign private_inner_RLAST=private_reads_phase?local_rlast:M_AXI_RLAST;

assign private_inner_RVALID=private_reads_phase?local_rvalid:M_AXI_RVALID;

npu_vit_private_handoff u_private_handoff(

 .clk(clk),.rst_n(rst_n),.cancel(trusted_cancel),.authorized(trusted_authorized),

 .session_epoch(trusted_epoch),.start(handoff_start),.seed_mode(handoff_seed),

 .pose_coefficient(handoff_pose_coefficient),

 .pose_valid(capture_pose&&(handoff_seed?(frontend_input_valid&&frontend_input_address<37824):fc2_out_valid)),

 .pose_done(capture_pose&&(handoff_seed?frontend_start:fc2_done)),

 .pose_address(handoff_seed?frontend_input_address:fc2_out_addr),

 .pose_data(handoff_seed?frontend_input_data:fc2_out_data),

 .norm_valid(capture_norm&&norm3_out_valid&&(!frontend_owner||frontend_ready)),.norm_done(capture_norm&&norm3_done),

 .norm_address(norm3_out_addr),.norm_data(norm3_out_data),

 .ready(handoff_ready),.fault(private_handoff_fault),

 .read_valid(bank_req),.read_pose(bank_kind),.read_beat(bank_beat),.read_ready(bank_reqready),

 .result_valid(bank_rvalid),.result_ready(bank_rready),.result_data(bank_rdata));

npu_private_axi_read u_private_axi(

 .clk(clk),.rst_n(rst_n),.clear(handoff_start),.cancel(trusted_cancel),

 .authorized(trusted_authorized&&private_reads_phase),.session_epoch(trusted_epoch),

 .s_araddr(private_inner_ARADDR),.s_arlen(private_inner_ARLEN),

 .s_arsize(private_inner_ARSIZE),.s_arburst(private_inner_ARBURST),

 .s_arvalid(private_inner_ARVALID&&private_reads_phase),.s_arready(local_arready),

 .s_rdata(local_rdata),.s_rresp(local_rresp),.s_rlast(local_rlast),

 .s_rvalid(local_rvalid),.s_rready(private_inner_RREADY&&private_reads_phase),

 .bank_valid(handoff_ready),.bank_read_valid(bank_req),.bank_read_pose(bank_kind),

 .bank_read_beat(bank_beat),.bank_read_ready(bank_reqready),

 .bank_result_valid(bank_rvalid),.bank_result_ready(bank_rready),.bank_result_data(bank_rdata),

 .fault(private_read_fault));

assign trusted_fc2_valid=fc2_out_valid;

assign trusted_fc2_done=fc2_done;

assign trusted_fc2_address=fc2_out_addr;

assign trusted_fc2_data=fc2_out_data;

assign trusted_norm_valid=norm3_out_valid&&(!frontend_owner||frontend_ready);

assign trusted_norm_done=norm3_done;

assign trusted_norm_address=norm3_out_addr;

assign trusted_norm_data=norm3_out_data;

npu_vit_guarded_head u_trusted_classifier(

 // Synchronous reset on a fresh B00 preparation clears prior aborted-head

 // state. Later Block handoffs must not clear the final classification path.

 .clk(clk),.rst_n(rst_n&&!(handoff_start&&handoff_seed)),.start(classification_start),.cancel(trusted_cancel),

 .model_authorized(trusted_authorized),.session_epoch(trusted_epoch),

 .norm_valid(classification_capture&&norm3_out_valid),

 .norm_done(classification_capture&&norm3_done),.norm_ready(classifier_norm_ready),

 .norm_address(norm3_out_addr),.norm_data(norm3_out_data),

 .page_request(classifier_page_request),.page_request_ready(classifier_page_request_ready),

 .expected_page_index(classifier_expected_page_index),

 .cache_valid(classifier_cache_valid),.cached_page_index(classifier_cached_page_index),

 .cache_read(classifier_cache_read),.cache_read_addr(classifier_cache_read_addr),

 .cache_read_valid(classifier_cache_read_valid),.cache_read_data(classifier_cache_read_data),

 .busy(classifier_busy),.fault(classifier_fault),.result_valid(trusted_result_valid),

 .class_index(trusted_class_index),.best_logit(trusted_best_logit),.result_epoch(trusted_result_epoch),

 .logit_valid(observation_logit_valid),.logit_class(observation_logit_class),.logit_data(observation_logit_data));



assign private_inner_ARADDR = qkv_loader_sel ? qkv_araddr[AXI_ADDR_WIDTH-1:0] : gen_araddr[AXI_ADDR_WIDTH-1:0];

assign private_inner_ARLEN = qkv_loader_sel ? qkv_arlen : gen_arlen;

assign private_inner_ARSIZE = qkv_loader_sel ? qkv_arsize : gen_arsize;

assign private_inner_ARBURST = qkv_loader_sel ? qkv_arburst : gen_arburst;

assign private_inner_ARVALID = selected_loader_arvalid && secure_read_cmd_ready;



`ifdef V801_LOAD_AUTH

v801_secure_stream_load_auth_2lane #(

    .DATA_WIDTH(AXI_DATA_WIDTH),.KEEP_WIDTH(AXI_DATA_WIDTH/8)

)u_secure_read_shell(

    .clk(clk),.rst_n(rst_n),.clear(clear_pulse|data_auth_secure_clear),

    .crypto_enable(security_mode!=2'd0),.auth_enable(data_auth_enable),

    .crypto_key(crypto_key),.auth_key(data_auth_mac_key),.crypto_nonce(crypto_nonce),

    .load_fire(load_start),.load_context(data_auth_context),

    .common_auth_enable(data_auth_common_enable),

    .common_object_context(data_auth_common_object_context),

    .common_dtype(data_auth_common_dtype),.common_role(data_auth_common_role),

    .common_key_id(data_auth_common_key_id),

    .load_addr(load_axi_addr),.load_beats(load_beats),

    .load_dst(load_dst),.load_local_addr(load_local_addr),

    .expected_valid(data_auth_expected_valid),.expected_tag(data_auth_expected_tag),

    .ar_fire(private_inner_ARVALID&&private_inner_ARREADY),.ar_ready(secure_read_cmd_ready),.ar_addr(private_inner_ARADDR),

    .s_valid(private_inner_RVALID),.s_ready(private_inner_RREADY),.s_data(private_inner_RDATA),

    .s_keep({AXI_DATA_WIDTH/8{1'b1}}),.s_last(private_inner_RLAST),

    .m_valid(secure_read_valid),.m_ready(selected_loader_rready),.m_data(secure_read_data),

    .m_keep(secure_read_keep),.m_last(secure_read_last),.stat_beats(secure_read_beats),

    .stat_stall_cycles(secure_read_stall_cycles),.auth_done(data_auth_done),

    .auth_ok(data_auth_ok),.auth_fail(data_auth_fail),.computed_tag(),

    // External crypto-service ports are intentionally tied off in the

    // internal-core configuration.  Leaving these newer ports omitted makes

    // VCS report a partial instance and can create X/Z inputs if the generate

    // condition changes during a mixed-source build.

    .ctr_block_req_valid(),.ctr_block_req_key(),.ctr_block_req_data(),.ctr_block_req_tag(),

    .ctr_block_rsp_ready(),.ctr_block_req_ready(1'b0),.ctr_block_rsp_valid(1'b0),

    .ctr_block_rsp_data({128{1'b0}}),.ctr_block_rsp_tag({16{1'b0}}),

    .mac_block_req_valid(),.mac_block_req_key(),.mac_block_req_data(),.mac_block_req_tag(),

    .mac_block_rsp_ready(),.mac_block_req_ready(1'b0),.mac_block_rsp_valid(1'b0),

    .mac_block_rsp_data({128{1'b0}}),.mac_block_rsp_tag({16{1'b0}}));

`elsif V799_BURST_AUTH

v799_secure_stream_burst_auth_2lane #(

    .DATA_WIDTH(AXI_DATA_WIDTH), .KEEP_WIDTH(AXI_DATA_WIDTH/8)

) u_secure_read_shell (

    .clk(clk), .rst_n(rst_n), .clear(clear_pulse | data_auth_secure_clear),

    .crypto_enable(security_mode != 2'd0),

    // Keep auth_enable asserted even on a tag miss.  expected_valid is

    // reported by the wrapper as a sticky fault; using it to disable auth

    // would also reopen cmd_ready and let a following AR bypass the interlock.

    .auth_enable(data_auth_enable),

    .crypto_key(crypto_key), .crypto_nonce(crypto_nonce),

    .cmd_fire(private_inner_ARVALID && private_inner_ARREADY), .cmd_ready(secure_read_cmd_ready),

    .cmd_addr(private_inner_ARADDR), .expected_tag(data_auth_expected_tag),

    .s_valid(private_inner_RVALID), .s_ready(private_inner_RREADY), .s_data(private_inner_RDATA),

    .s_keep({AXI_DATA_WIDTH/8{1'b1}}), .s_last(private_inner_RLAST),

    .m_valid(secure_read_valid), .m_ready(selected_loader_rready),

    .m_data(secure_read_data), .m_keep(secure_read_keep), .m_last(secure_read_last),

    .stat_beats(secure_read_beats), .stat_stall_cycles(secure_read_stall_cycles),

    .auth_done(data_auth_done), .auth_ok(data_auth_ok),

    .auth_fail(data_auth_fail), .computed_tag()

);

`elsif V790_2LANE

assign secure_read_cmd_ready = 1'b1;

assign data_auth_done = 1'b0;

assign data_auth_ok = 1'b1;

assign data_auth_fail = 1'b0;

v790_secure_stream_sm4_ctr_2lane #(

    .DATA_WIDTH(AXI_DATA_WIDTH), .KEEP_WIDTH(AXI_DATA_WIDTH/8)

) u_secure_read_shell (

    .clk(clk), .rst_n(rst_n), .clear(clear_pulse), .crypto_enable(security_mode != 2'd0),

    .crypto_key(crypto_key), .crypto_nonce(crypto_nonce), .cmd_fire(private_inner_ARVALID && private_inner_ARREADY),

    .cmd_addr(private_inner_ARADDR), .s_valid(private_inner_RVALID), .s_ready(private_inner_RREADY), .s_data(private_inner_RDATA),

    .s_keep({AXI_DATA_WIDTH/8{1'b1}}), .s_last(private_inner_RLAST), .m_valid(secure_read_valid),

    .m_ready(selected_loader_rready), .m_data(secure_read_data), .m_keep(secure_read_keep),

    .m_last(secure_read_last), .stat_beats(secure_read_beats), .stat_stall_cycles(secure_read_stall_cycles)

);

`elsif V788_SM4_CTR

assign secure_read_cmd_ready = 1'b1;

assign data_auth_done = 1'b0;

assign data_auth_ok = 1'b1;

assign data_auth_fail = 1'b0;

v788_secure_stream_sm4_ctr #(

    .DATA_WIDTH(AXI_DATA_WIDTH),

    .KEEP_WIDTH(AXI_DATA_WIDTH/8)

) u_secure_read_shell (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .crypto_enable(security_mode != 2'd0),

    .crypto_key(crypto_key),

    .crypto_nonce(crypto_nonce),

    .cmd_fire(private_inner_ARVALID && private_inner_ARREADY),

    .cmd_addr(private_inner_ARADDR),

    .s_valid(private_inner_RVALID),

    .s_ready(private_inner_RREADY),

    .s_data(private_inner_RDATA),

    .s_keep({AXI_DATA_WIDTH/8{1'b1}}),

    .s_last(private_inner_RLAST),

    .m_valid(secure_read_valid),

    .m_ready(selected_loader_rready),

    .m_data(secure_read_data),

    .m_keep(secure_read_keep),

    .m_last(secure_read_last),

    .stat_beats(secure_read_beats),

    .stat_stall_cycles(secure_read_stall_cycles)

);

`else

assign secure_read_cmd_ready = 1'b1;

assign data_auth_done = 1'b0;

assign data_auth_ok = 1'b1;

assign data_auth_fail = 1'b0;

v786_secure_stream_passthrough #(

    .DATA_WIDTH(AXI_DATA_WIDTH),

    .KEEP_WIDTH(AXI_DATA_WIDTH/8)

) u_secure_read_shell (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .s_valid(private_inner_RVALID),

    .s_ready(private_inner_RREADY),

    .s_data(private_inner_RDATA),

    .s_keep({AXI_DATA_WIDTH/8{1'b1}}),

    .s_last(private_inner_RLAST),

    .m_valid(secure_read_valid),

    .m_ready(selected_loader_rready),

    .m_data(secure_read_data),

    .m_keep(secure_read_keep),

    .m_last(secure_read_last),

    .stat_beats(secure_read_beats),

    .stat_stall_cycles(secure_read_stall_cycles)

);

`endif



`ifdef V790_2LANE

v790_secure_stream_sm4_ctr_2lane #(

    .DATA_WIDTH(AXI_DATA_WIDTH), .KEEP_WIDTH(AXI_DATA_WIDTH/8)

) u_secure_write_shell (

    .clk(clk), .rst_n(rst_n), .clear(clear_pulse), .crypto_enable(security_mode != 2'd0),

    .crypto_key(crypto_key), .crypto_nonce(crypto_nonce), .cmd_fire(M_AXI_AWVALID && M_AXI_AWREADY),

    .cmd_addr(M_AXI_AWADDR), .s_valid(store_axi_wvalid), .s_ready(store_axi_wready), .s_data(store_axi_wdata),

    .s_keep(store_axi_wstrb), .s_last(store_axi_wlast), .m_valid(M_AXI_WVALID), .m_ready(M_AXI_WREADY),

    .m_data(M_AXI_WDATA), .m_keep(M_AXI_WSTRB), .m_last(M_AXI_WLAST), .stat_beats(secure_write_beats),

    .stat_stall_cycles(secure_write_stall_cycles)

);

`elsif V788_SM4_CTR

v788_secure_stream_sm4_ctr #(

    .DATA_WIDTH(AXI_DATA_WIDTH),

    .KEEP_WIDTH(AXI_DATA_WIDTH/8)

) u_secure_write_shell (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .crypto_enable(security_mode != 2'd0),

    .crypto_key(crypto_key),

    .crypto_nonce(crypto_nonce),

    .cmd_fire(M_AXI_AWVALID && M_AXI_AWREADY),

    .cmd_addr(M_AXI_AWADDR),

    .s_valid(store_axi_wvalid),

    .s_ready(store_axi_wready),

    .s_data(store_axi_wdata),

    .s_keep(store_axi_wstrb),

    .s_last(store_axi_wlast),

    .m_valid(M_AXI_WVALID),

    .m_ready(M_AXI_WREADY),

    .m_data(M_AXI_WDATA),

    .m_keep(M_AXI_WSTRB),

    .m_last(M_AXI_WLAST),

    .stat_beats(secure_write_beats),

    .stat_stall_cycles(secure_write_stall_cycles)

);

`else

v786_secure_stream_passthrough #(

    .DATA_WIDTH(AXI_DATA_WIDTH),

    .KEEP_WIDTH(AXI_DATA_WIDTH/8)

) u_secure_write_shell (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .s_valid(store_axi_wvalid),

    .s_ready(store_axi_wready),

    .s_data(store_axi_wdata),

    .s_keep(store_axi_wstrb),

    .s_last(store_axi_wlast),

    .m_valid(M_AXI_WVALID),

    .m_ready(M_AXI_WREADY),

    .m_data(M_AXI_WDATA),

    .m_keep(M_AXI_WSTRB),

    .m_last(M_AXI_WLAST),

    .stat_beats(secure_write_beats),

    .stat_stall_cycles(secure_write_stall_cycles)

);

`endif



assign integration_busy = integration_loader_busy | integration_concat_busy | integration_outproj_busy | integration_norm2_busy | qkv_compute_busy | qkt_busy | softmax_busy | av_busy | fc1_busy | gelu_busy | fc2_busy | norm3_busy | store_busy | !qkv_command_ready | !generic_command_ready | fc2_pad_active | load_start | qkv_compute_start | qkt_start | softmax_start | av_start | concat_start | outproj_start | norm2_start | fc1_start | gelu_start | fc2_start | norm3_start | store_start;

assign stat0 = {qkv_compute_busy, qkt_busy, softmax_busy, av_busy, store_busy, fc1_busy, gelu_busy, fc2_busy, norm3_busy, 23'd0};

assign stat1 = stat_qkv_compute_cycles + stat_qkt_cycles + stat_av_cycles + outproj_cycles + norm2_cycles + fc1_cycles;

assign stat2 = loader_stat_beats + stat_load_beats + stat_store_beats;

assign stat3 = loader_stat_errors + stat_load_errors + concat_errors + stat_store_errors + stat_guard_errors;



always @(posedge clk) begin

    if (!rst_n) begin

        profile_axi_read_data_cycles <= 32'd0;

        profile_axi_read_memory_wait_cycles <= 32'd0;

        profile_axi_read_backpressure_cycles <= 32'd0;

        profile_axi_write_data_cycles <= 32'd0;

        profile_axi_write_backpressure_cycles <= 32'd0;

        profile_pe_active_cycles <= 32'd0;

    end else if (clear_pulse) begin

        profile_axi_read_data_cycles <= 32'd0;

        profile_axi_read_memory_wait_cycles <= 32'd0;

        profile_axi_read_backpressure_cycles <= 32'd0;

        profile_axi_write_data_cycles <= 32'd0;

        profile_axi_write_backpressure_cycles <= 32'd0;

        profile_pe_active_cycles <= 32'd0;

    end else begin

        if (private_inner_RVALID && private_inner_RREADY)

            profile_axi_read_data_cycles <= profile_axi_read_data_cycles + 1'b1;

        if (private_inner_RREADY && !private_inner_RVALID)

            profile_axi_read_memory_wait_cycles <= profile_axi_read_memory_wait_cycles + 1'b1;

        if (private_inner_RVALID && !private_inner_RREADY)

            profile_axi_read_backpressure_cycles <= profile_axi_read_backpressure_cycles + 1'b1;

        if (M_AXI_WVALID && M_AXI_WREADY)

            profile_axi_write_data_cycles <= profile_axi_write_data_cycles + 1'b1;

        if (M_AXI_WVALID && !M_AXI_WREADY)

            profile_axi_write_backpressure_cycles <= profile_axi_write_backpressure_cycles + 1'b1;

        if (profile_pe_busy)

            profile_pe_active_cycles <= profile_pe_active_cycles + 1'b1;

    end

end



reg [31:0] debug_first_aw,debug_last_aw,debug_first_wdata,debug_first_wstrb;

reg [31:0] debug_aw_count,debug_b_count,debug_last_bresp;

reg debug_w_seen;

always @(posedge clk) begin

    if(!rst_n || clear_pulse) begin

        debug_first_aw<=0;debug_last_aw<=0;debug_first_wdata<=0;debug_first_wstrb<=0;

        debug_aw_count<=0;debug_b_count<=0;debug_last_bresp<=0;debug_w_seen<=0;

    end else begin

        if(M_AXI_AWVALID && M_AXI_AWREADY) begin

            if(debug_aw_count==0) debug_first_aw<=M_AXI_AWADDR;

            debug_last_aw<=M_AXI_AWADDR;debug_aw_count<=debug_aw_count+1'b1;

        end

        if(M_AXI_WVALID && M_AXI_WREADY && !debug_w_seen) begin

            debug_first_wdata<=M_AXI_WDATA[31:0];debug_first_wstrb<=M_AXI_WSTRB;

            debug_w_seen<=1;

        end

        if(M_AXI_BVALID && M_AXI_BREADY) begin

            debug_b_count<=debug_b_count+1'b1;debug_last_bresp<={30'd0,M_AXI_BRESP};

        end

    end

end



v735_axi_lite_stage_regs u_axil (

    .clk(clk),

    // Stage registers contain the data key, nonce and security mode.  Holding

    // their local reset during trusted clear provides actual zeroization.

    .rst_n(rst_n && !data_auth_secure_clear),

    .s_axil_awaddr(S_AXIL_AWADDR),

    .s_axil_awvalid(S_AXIL_AWVALID),

    .s_axil_awready(S_AXIL_AWREADY),

    .s_axil_wdata(S_AXIL_WDATA),

    .s_axil_wstrb(S_AXIL_WSTRB),

    .s_axil_wvalid(S_AXIL_WVALID),

    .s_axil_wready(S_AXIL_WREADY),

    .s_axil_bresp(S_AXIL_BRESP),

    .s_axil_bvalid(S_AXIL_BVALID),

    .s_axil_bready(S_AXIL_BREADY),

    .s_axil_araddr(S_AXIL_ARADDR),

    .s_axil_arvalid(S_AXIL_ARVALID),

    .s_axil_arready(S_AXIL_ARREADY),

    .s_axil_rdata(S_AXIL_RDATA),

    .s_axil_rresp(S_AXIL_RRESP),

    .s_axil_rvalid(S_AXIL_RVALID),

    .s_axil_rready(S_AXIL_RREADY),

    .clear_pulse(axil_clear_pulse),

    .load_start(load_start),

    .qkv_bank_start(qkv_bank_start),

    .qkv_compute_start(qkv_compute_start),

    .qkt_start(qkt_start),

    .softmax_start(softmax_start),

    .prob_bank_start(prob_bank_start),

    .av_start(av_start),

    .concat_start(concat_start),

    .outproj_start(outproj_start),

    .norm2_start(norm2_start),

    .fc1_start(fc1_start),

    .gelu_start(gelu_start),

    .fc2_pad_start(fc2_pad_start),

    .fc2_start(fc2_start),

    .norm3_start(norm3_start),

    .store_start(store_start),

    .load_dst(load_dst),

    .load_axi_addr(load_axi_addr),

    .load_local_addr(load_local_addr),

    .load_beats(load_beats),

    .load_burst_len_m1(load_burst_len_m1),

    .qkv_block_id(qkv_block_id),

    .qkv_op_id(qkv_op_id),

    .current_head(current_head),

    .softmax_x0(softmax_x0),

    .gelu_x0(gelu_x0),

    .prefetch_mode(prefetch_mode),

    .security_mode(security_mode),

    .prefetch_window_cap(prefetch_window_cap),

    .stage_budget_cap(stage_budget_cap),

    .window_guard_words(window_guard_words),

    .window_base_addr(window_base_addr),

    .window_stride_words(window_stride_words),

    .crypto_key_id(crypto_key_id),

    .prefetch_ahead_beats(prefetch_ahead_beats),

    .crypto_key(crypto_key),

    .crypto_nonce(crypto_nonce),

    .store_fc2_select(store_fc2_select),

    .capture_drops(capture_drops),

    .debug_first_aw(debug_first_aw),.debug_last_aw(debug_last_aw),

    .debug_first_wdata(debug_first_wdata),.debug_first_wstrb(debug_first_wstrb),

    .debug_aw_count(debug_aw_count),.debug_b_count(debug_b_count),.debug_last_bresp(debug_last_bresp),

    .done_events({store_done, norm3_done, fc2_done, fc2_pad_done,

                  gelu_done, fc1_done, norm2_done, outproj_done, concat_done,

                  av_done, prob_bank_done, softmax_done, qkt_done,

                  qkv_compute_done, qkv_load_done,

                  (qkv_axi_load_done || generic_load_done), axil_clear_pulse}),

    .load_ready({generic_command_ready, qkv_command_ready}),

    .status0(stat0),

    .status1(stat1),

    .status2(stat2),

    .status3(stat3),

    .status4(loader_stat_window_errors),

    .status5(loader_stat_window_peak_beats),

    .status6(loader_stat_last_cmd_faults),

    .status7(profile_axi_read_data_cycles),

    .status8(profile_axi_read_memory_wait_cycles),

    .status9(profile_axi_read_backpressure_cycles),

    .status10(profile_axi_write_data_cycles),

    .status11(profile_axi_write_backpressure_cycles),

    .status12(profile_pe_active_cycles),

    .status13({22'd0, gelu_group_max_level, gelu_group_level}),

    .status14(gelu_input_blocked_cycles),

    .status15(gelu_output_stall_cycles),

    .status16(stat_store_fifo_stall_cycles),

    .status17({16'd0, stat_store_fifo_max_level, stat_store_fifo_level}),

    .status18(secure_read_beats),

    .status19(secure_write_beats),

    .status20(secure_read_stall_cycles),

    .status21(secure_write_stall_cycles)

);



v720_axi_qkv_full_attention_inner_nomemh_top u_attention (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .qkv_bank_start(qkv_bank_start),

    .qkv_bank_done(qkv_load_done),

    .load_cmd_valid(load_start && qkv_loader_sel),

    .load_cmd_ready(qkv_command_ready),

    .load_cmd_dst(load_dst[1:0]),

    .load_cmd_block_id(qkv_block_id),

    .load_cmd_op_id(qkv_op_id),

    .load_cmd_axi_addr(load_axi_addr),

    .load_cmd_local_addr(load_local_addr[11:0]),

    .load_cmd_beats(load_beats),

    .load_cmd_burst_len_m1(load_burst_len_m1),

    .load_done(qkv_axi_load_done),

    .qkv_compute_start(qkv_compute_start),

    .qkv_compute_block_id(qkv_block_id),

    .qkv_compute_op_id(qkv_op_id),

    .qkv_compute_busy(qkv_compute_busy),

    .qkv_compute_done(qkv_compute_done),

    .qkt_start(qkt_start),

    .qkt_a_base(16'd0),

    .qkt_b_base(16'd0),

    .qkt_scale_base(current_head * 16'd200),

    .qkt_quant_base(current_head * 32'd40000),

    .qkt_scale_wr_valid(qkt_scale_wr_valid),

    .qkt_scale_wr_addr(qkt_scale_wr_addr),

    .qkt_scale_wr_data(qkt_scale_wr_data),

    .qkt_busy(qkt_busy),

    .qkt_done(qkt_done),

    .softmax_start(softmax_start),

    .row_max_base(current_head * 16'd200),

    .row_sum_base(current_head * 16'd200),

    .factor_base(current_head * 16'd200),

    .prob_base(current_head * 32'd40000),

    .softmax_x0(softmax_x0),

    .softmax_busy(softmax_busy),

    .softmax_done(softmax_done),

    .prob_bank_start(prob_bank_start),

    .av_a_tile_base(current_head * 16'd2500),

    .prob_bank_done(prob_bank_done),

    .av_start(av_start),

    .av_b_base(16'd0),

    .av_scale_base(current_head * 16'd64),

    .av_quant_base(current_head * 32'd12800),

    .av_scale_wr_valid(av_scale_wr_valid),

    .av_scale_wr_addr(av_scale_wr_addr),

    .av_scale_wr_data(av_scale_wr_data),

    .av_busy(av_busy),

    .av_done(av_done),

    .av_ctx_tile_valid(av_ctx_tile_valid),

    .av_ctx_tile_addr(av_ctx_tile_addr),

    .av_ctx_tile_data(av_ctx_tile_data),

    .m_axi_araddr(qkv_araddr),

    .m_axi_arlen(qkv_arlen),

    .m_axi_arsize(qkv_arsize),

    .m_axi_arburst(qkv_arburst),

    .m_axi_arvalid(qkv_arvalid),

    .m_axi_arready(private_inner_ARREADY && qkv_loader_sel && secure_read_cmd_ready),

    .m_axi_rdata(secure_read_data),

    .m_axi_rvalid(secure_read_valid && qkv_loader_sel),

    .m_axi_rready(qkv_rready),

    .m_axi_rlast(secure_read_last),

    .stat_load_beats(stat_load_beats),

    .stat_load_errors(stat_load_errors),

    .stat_qkv_compute_cycles(stat_qkv_compute_cycles),

    .stat_qkv_compute_tiles(stat_qkv_compute_tiles),

    .stat_qkv_quant_items(stat_qkv_quant_items),

    .stat_bank_inputs(stat_bank_inputs),

    .stat_bank_q_inputs(),

    .stat_bank_k_inputs(),

    .stat_bank_v_inputs(),

    .stat_qkt_tiles(stat_qkt_tiles),

    .stat_qkt_cycles(stat_qkt_cycles),

    .stat_softmax_score_tiles(),

    .stat_softmax_rows(stat_softmax_rows),

    .stat_softmax_probs(),

    .stat_prob_bank_writes(),

    .stat_av_tiles(stat_av_tiles),

    .stat_av_cycles(stat_av_cycles)

);



v735_axi_full_bank_loader u_loader (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .cmd_valid(load_start && generic_loader_sel),

    .cmd_ready(generic_command_ready),

    .cmd_dst(load_dst),

    .cmd_axi_addr(load_axi_addr),

    .cmd_local_addr(load_local_addr),

    .cmd_beats(load_beats),

    .cmd_burst_len_m1(load_burst_len_m1),

    .prefetch_mode(prefetch_mode),

    .security_mode(security_mode),

    .prefetch_window_cap(prefetch_window_cap),

    .stage_budget_cap(stage_budget_cap),

    .window_guard_words(window_guard_words),

    .window_base_addr(window_base_addr),

    .window_stride_words(window_stride_words),

    .crypto_key_id(crypto_key_id),

    .prefetch_ahead_beats(prefetch_ahead_beats),

    .busy(integration_loader_busy),

    .done(generic_load_done),

    .m_axi_araddr(gen_araddr),

    .m_axi_arlen(gen_arlen),

    .m_axi_arsize(gen_arsize),

    .m_axi_arburst(gen_arburst),

    .m_axi_arvalid(gen_arvalid),

    .m_axi_arready(private_inner_ARREADY && generic_loader_sel && secure_read_cmd_ready),

    .m_axi_rdata(secure_read_data),

    .m_axi_rvalid(secure_read_valid && generic_loader_sel),

    .m_axi_rready(gen_rready),

    .m_axi_rlast(secure_read_last),

    .outproj_a_wr_valid(loader_outproj_a_wr_valid),

    .outproj_a_wr_addr(loader_outproj_a_wr_addr),

    .outproj_a_wr_data(loader_outproj_a_wr_data),

    .outproj_b_wr_valid(loader_outproj_b_wr_valid),

    .outproj_b_wr_addr(loader_outproj_b_wr_addr),

    .outproj_b_wr_data(loader_outproj_b_wr_data),

    .outproj_scale_wr_valid(loader_outproj_scale_wr_valid),

    .outproj_scale_wr_addr(loader_outproj_scale_wr_addr),

    .outproj_scale_wr_data(loader_outproj_scale_wr_data),

    .outproj_residual_wr_valid(loader_outproj_residual_wr_valid),

    .outproj_residual_wr_addr(loader_outproj_residual_wr_addr),

    .outproj_residual_wr_data(loader_outproj_residual_wr_data),

    .norm2_scale_wr_valid(norm2_scale_wr_valid),

    .norm2_scale_wr_addr(norm2_scale_wr_addr),

    .norm2_scale_wr_data(norm2_scale_wr_data),

    .norm2_bias_wr_valid(norm2_bias_wr_valid),

    .norm2_bias_wr_addr(norm2_bias_wr_addr),

    .norm2_bias_wr_data(norm2_bias_wr_data),

    .fc1_a_wr_valid(loader_fc1_a_wr_valid),

    .fc1_a_wr_addr(loader_fc1_a_wr_addr),

    .fc1_a_wr_data(loader_fc1_a_wr_data),

    .fc1_b_wr_valid(fc1_b_wr_valid),

    .fc1_b_wr_addr(fc1_b_wr_addr),

    .fc1_b_wr_data(fc1_b_wr_data),

    .fc1_scale_wr_valid(fc1_scale_wr_valid),

    .fc1_scale_wr_addr(fc1_scale_wr_addr),

    .fc1_scale_wr_data(fc1_scale_wr_data),

    .gelu_scale_wr_valid(gelu_scale_wr_valid),

    .gelu_scale_wr_data(gelu_scale_wr_data),

    .fc2_b_wr_valid(fc2_b_wr_valid),

    .fc2_b_wr_addr(fc2_b_wr_addr),

    .fc2_b_wr_data(fc2_b_wr_data),

    .fc2_scale_wr_valid(fc2_scale_wr_valid),

    .fc2_scale_wr_addr(fc2_scale_wr_addr),

    .fc2_scale_wr_data(fc2_scale_wr_data),

    .fc2_add_scale_wr_valid(fc2_add_scale_wr_valid),

    .fc2_add_scale_wr_data(fc2_add_scale_wr_data),

    .fc2_residual_wr_valid(fc2_residual_wr_valid),

    .fc2_residual_wr_addr(fc2_residual_wr_addr),

    .fc2_residual_wr_data(fc2_residual_wr_data),

    .norm3_scale_wr_valid(norm3_scale_wr_valid),

    .norm3_scale_wr_addr(norm3_scale_wr_addr),

    .norm3_scale_wr_data(norm3_scale_wr_data),

    .norm3_bias_wr_valid(norm3_bias_wr_valid),

    .norm3_bias_wr_addr(norm3_bias_wr_addr),

    .norm3_bias_wr_data(norm3_bias_wr_data),

    .qkt_scale_wr_valid(qkt_scale_wr_valid),

    .qkt_scale_wr_addr(qkt_scale_wr_addr),

    .qkt_scale_wr_data(qkt_scale_wr_data),

    .av_scale_wr_valid(av_scale_wr_valid),

    .av_scale_wr_addr(av_scale_wr_addr),

    .av_scale_wr_data(av_scale_wr_data),

    .stat_cmds(loader_stat_cmds),

    .stat_beats(loader_stat_beats),

    .stat_items(loader_stat_items),

    .stat_errors(loader_stat_errors),

    .stat_cycles(loader_stat_cycles),

    .stat_active_dst(),

    .stat_axi_inflight_peak(),

    .stat_window_errors(loader_stat_window_errors),

    .stat_window_peak_beats(loader_stat_window_peak_beats),

    .stat_last_cmd_faults(loader_stat_last_cmd_faults)

);



v723_live_ctx_concat_tile_bank_nomemh u_concat (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .in_valid(av_ctx_tile_valid),

    .in_head(current_head),

    .in_tile_addr(av_ctx_tile_addr),

    .in_tile_data(av_ctx_tile_data),

    .start(concat_start),

    .out_ready(1'b1),

    .busy(integration_concat_busy),

    .done(concat_done),

    .out_valid(concat_out_valid),

    .out_tile_addr(concat_out_tile_addr),

    .out_tile_data(concat_out_tile_data),

    .stat_head0_tiles(),

    .stat_head1_tiles(),

    .stat_head2_tiles(),

    .stat_out_tiles(concat_out_tiles),

    .stat_errors(concat_errors),

    .stat_stage()

);



v724_live_concat_outproj_linear_add_nomemh #(.CLOSED_AUDIO_PRODUCER(CLOSED_AUDIO_PRODUCER),.ENABLE_MIC_B(ENABLE_MIC_B)) u_outproj (
    .security_reset_n(security_reset_n),.pool_desired_stage(pool_desired_stage),
        .audio_b_write(audio_b_write),.audio_b_read(audio_b_read),.audio_b_write_address(audio_b_write_address),.audio_b_read_address(audio_b_read_address),
 .audio_b_write_data(audio_b_write_data),.audio_b_response_ready(audio_b_response_ready),.audio_b_write_accepted(audio_b_write_accepted),.audio_b_read_accepted(audio_b_read_accepted),
 .audio_b_read_response_valid(audio_b_read_response_valid),.audio_b_drained(audio_b_drained),.audio_b_read_data(audio_b_read_data),
.audio_a_write(audio_a_write),.audio_a_read(audio_a_read),
    .audio_a_write_address(audio_a_write_address),.audio_a_read_address(audio_a_read_address),
    .audio_a_write_data(audio_a_write_data),.audio_a_read_data(audio_a_read_data),
    .pool_protocol_violation(pool_protocol_violation),
.pool_all_quiescent(pool_all_quiescent),.pool_access_live(pool_access_live),
    .pool_committed_stage(pool_committed_stage),.pool_owner_ready(pool_owner_ready),
    .pool_fault(pool_fault),.pool_quiescent(pool_quiescent),.pool_local_quiescent(pool_local_quiescent),

    .shared_owner(shared_owner),.shared_a_write(shared_a_write),.shared_b_write(shared_b_write),

    .shared_write_address(shared_write_address),.shared_write_data(shared_write_data),

    .shared_a_read(shared_a_read),.shared_b_read(shared_b_read),

    .shared_a_address(shared_a_address),.shared_b_address(shared_b_address),

    .shared_a_data(shared_a_data),.shared_b_data(shared_b_data),



    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .a_tile_wr_valid(outproj_a_wr_valid),

    .a_tile_wr_addr(outproj_a_wr_addr),

    .a_tile_wr_data(outproj_a_wr_data),

    .b_tile_wr_valid(loader_outproj_b_wr_valid),

    .b_tile_wr_addr(loader_outproj_b_wr_addr),

    .b_tile_wr_data(loader_outproj_b_wr_data),

    .scale_wr_valid(loader_outproj_scale_wr_valid),

    .scale_wr_addr(loader_outproj_scale_wr_addr),

    .scale_wr_data(loader_outproj_scale_wr_data),

    .residual_wr_valid(loader_outproj_residual_wr_valid),

    .residual_wr_addr(loader_outproj_residual_wr_addr),

    .residual_wr_data(loader_outproj_residual_wr_data),

    .start(outproj_start),

    .busy(integration_outproj_busy),

    .done(outproj_done),

    .linear_out_valid(linear_out_valid),

    .linear_out_ready(linear_out_ready),

    .linear_out_addr(linear_out_addr),

    .linear_out_data(linear_out_data),

    .stat_a_writes(),

    .stat_b_writes(),

    .stat_scale_writes(),

    .stat_residual_writes(),

    .stat_tiles(),

    .stat_linear_writes(),

    .stat_errors(),

    .stat_cycles(outproj_cycles),

    .stat_stage()

);



assign linear_out_ready = 1'b1;



wire shared_norm_rd_en;wire[7:0]shared_norm_rd_row,shared_norm_rd_col;wire[15:0]shared_norm_rd_addr,shared_norm_rd_data;
wire[15:0]shared_norm_clear_operand;

wire shared_fc1_rd_en;wire[223:0]shared_fc1_rd_addr_flat;wire[255:0]shared_fc1_rd_data;

wire shared_norm_ready,shared_fc1_ready;

wire shared_A_clear=clear_pulse||(handoff_start&&handoff_seed);

wire shared_compute_clear=clear_pulse||trusted_cancel||!trusted_authorized||shared_A_fault;

npu_norm2_fc1_shared_A #(.CLOSED_NORM2_CLEAR_OPERAND(1),.CLOSED_NORM2_OUTER_CLEAR(1)) u_norm2_fc1_shared_A(

 .clk(clk),.rst_n(rst_n),.clear(shared_A_clear),.authorized(trusted_authorized),.cancel(trusted_cancel),.session_epoch(trusted_epoch),

 .raw_start(outproj_start),.raw_done(outproj_done),.raw_wr_valid(linear_out_valid),.raw_wr_addr(linear_out_addr),.raw_wr_data(linear_out_data),

 .norm_start(norm2_start),.norm_done(norm2_done),.norm_wr_valid(fc1_a_wr_valid),.norm_wr_addr(fc1_a_wr_addr),.norm_wr_data(fc1_a_wr_data),

 .norm_rd_row(shared_norm_rd_row),.norm_rd_col(shared_norm_rd_col),.norm_rd_en(shared_norm_rd_en),.norm_rd_addr(shared_norm_rd_addr),.norm_rd_data(shared_norm_rd_data),.norm_rd_clear_operand(shared_norm_clear_operand),.norm_outer_clear(clear_pulse),.norm_clear_residual(handoff_start&&handoff_seed),

 .fc1_start(fc1_start),.fc1_done(fc1_done),.fc1_rd_en(shared_fc1_rd_en),.fc1_rd_addr_flat(shared_fc1_rd_addr_flat),.fc1_rd_data(shared_fc1_rd_data),

 .norm_ready(shared_norm_ready),.fc1_ready(shared_fc1_ready),.fault(shared_A_fault),.debug_phase(),.raw_count(),.norm_count());

v725_live_linear_add_norm2_nomemh #(.EXTERNAL_LINEAR(1)) u_norm2 (

 .linear_ext_rd_row(shared_norm_rd_row),.linear_ext_rd_col(shared_norm_rd_col),.linear_ext_rd_en(shared_norm_rd_en),.linear_ext_rd_addr(shared_norm_rd_addr),.linear_ext_rd_data(shared_norm_clear_operand),

    .clk(clk),

    .rst_n(rst_n),

    .clear(shared_compute_clear),

    .linear_add_wr_valid(linear_out_valid),

    .linear_add_wr_ready(),

    .linear_add_wr_addr(linear_out_addr),

    .linear_add_wr_data(linear_out_data),

    .scale_wr_valid(norm2_scale_wr_valid),

    .scale_wr_ready(),

    .scale_wr_addr(norm2_scale_wr_addr),

    .scale_wr_data(norm2_scale_wr_data),

    .bias_wr_valid(norm2_bias_wr_valid),

    .bias_wr_ready(),

    .bias_wr_addr(norm2_bias_wr_addr),

    .bias_wr_data(norm2_bias_wr_data),

    .start(norm2_start&&shared_norm_ready),

    .busy(integration_norm2_busy),

    .done(norm2_done),

    .out_valid(norm2_out_valid),

    .out_ready(1'b1),

    .out_addr(norm2_out_addr),

    .out_data(norm2_out_data),

    .stat_linear_add_writes(),

    .stat_scale_writes(),

    .stat_bias_writes(),

    .stat_rows(),

    .stat_items(),

    .stat_stream_items(),

    .stat_errors(),

    .stat_cycles(norm2_cycles),

    .stat_stage()

);



v729_runtime_abuf_fc1_tiledrain_nomemh #(.EXTERNAL_A(1)) u_fc1 (

 .a_external_rd_en(shared_fc1_rd_en),.a_external_rd_addr_flat(shared_fc1_rd_addr_flat),.a_external_rd_data(shared_fc1_rd_data),

    .clk(clk),

    .rst_n(rst_n),

    .clear(shared_compute_clear),

    .a_wr_valid(fc1_a_wr_valid),

    .a_wr_addr(fc1_a_wr_addr),

    .a_wr_data(fc1_a_wr_data),

    .b_wr_valid(fc1_b_wr_valid),

    .b_wr_addr(fc1_b_wr_addr),

    .b_wr_data(fc1_b_wr_data),

    .scale_wr_valid(fc1_scale_wr_valid),

    .scale_wr_addr(fc1_scale_wr_addr),

    .scale_wr_data(fc1_scale_wr_data),

    .start(fc1_start&&shared_fc1_ready),

    .busy(fc1_busy),

    .done(fc1_done),

    .stat_a_writes(),

    .stat_b_writes(),

    .stat_scale_writes(),

    .stat_input_errors(),

    .stat_tiles(),

    .stat_stream_items(),

    .stat_cycles(fc1_cycles),

    .stat_stage(),

    .out_valid(fc1_out_valid),

    .out_addr(fc1_out_addr),

    .out_data(fc1_out_data)

);



v784_fc1_gelu_rowgroup_pipeline u_gelu (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .in_wr_valid(fc1_out_valid),

    .in_wr_addr(fc1_out_addr),

    .in_wr_data(fc1_out_data),

    .scale_wr_valid(gelu_scale_wr_valid),

    .scale_wr_data(gelu_scale_wr_data),

    .constant_x0(gelu_x0),

    .start(gelu_start),

    .busy(gelu_busy),

    .done(gelu_done),

    .stat_input_writes(),

    .stat_input_errors(),

    .stat_rows(),

    .stat_items(),

    .stat_max_errors(),

    .stat_exp_errors(),

    .stat_gelu_errors(),

    .out_valid(gelu_out_valid),

    .out_addr(gelu_out_addr),

    .out_data(gelu_out_data),

    .out_ready(fc2_in_wr_ready),

    .stat_stream_items(gelu_stream_items),

    .stat_group_level(gelu_group_level),

    .stat_group_max_level(gelu_group_max_level),

    .stat_input_blocked_cycles(gelu_input_blocked_cycles),

    .stat_output_stall_cycles(gelu_output_stall_cycles)

);



v782_stream_repack_router u_router (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .norm2_out_valid(norm2_out_valid),

    .norm2_out_addr(norm2_out_addr),

    .norm2_out_data(norm2_out_data),

    .fc1_a_wr_valid(router_fc1_a_wr_valid),

    .fc1_a_wr_addr(router_fc1_a_wr_addr),

    .fc1_a_wr_data(router_fc1_a_wr_data),

    .gelu_out_valid(gelu_out_valid),

    .gelu_out_addr(gelu_out_addr),

    .gelu_out_data(gelu_out_data),

    .fc2_pad_active(fc2_pad_active),

    .fc2_pad_done(fc2_pad_done),

    .fc2_in_wr_valid(router_fc2_in_wr_valid),

    .fc2_in_wr_addr(router_fc2_in_wr_addr),

    .fc2_in_wr_data(router_fc2_in_wr_data),

    .stat_fc1_writes(),

    .stat_fc2_writes()

);



always @(posedge clk) begin

    if (!rst_n) begin

        fc2_pad_active <= 1'b0;

    end else begin

        if (clear_pulse || fc2_pad_done)

            fc2_pad_active <= 1'b0;

        else if (fc2_pad_start)

            fc2_pad_active <= 1'b1;

    end

end



v641_runtime_gelu_fc2_residual_tiledrain_stream_controller u_fc2 (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .in_wr_valid(gelu_out_valid),

    .in_wr_addr(gelu_out_addr),

    .in_wr_data({{8{gelu_out_data[7]}}, gelu_out_data}),

    .in_wr_ready(fc2_in_wr_ready),

    .b_wr_valid(fc2_b_wr_valid),

    .b_wr_addr(fc2_b_wr_addr),

    .b_wr_data(fc2_b_wr_data),

    .scale_wr_valid(fc2_scale_wr_valid),

    .scale_wr_addr(fc2_scale_wr_addr),

    .scale_wr_data(fc2_scale_wr_data),

    .add_scale_wr_valid(fc2_add_scale_wr_valid),

    .add_scale_wr_data(fc2_add_scale_wr_data),

    .residual_wr_valid(ENABLE_LIVE_CHAIN ? (linear_out_valid && linear_out_addr < 37824) : fc2_residual_wr_valid),

    .residual_wr_addr(ENABLE_LIVE_CHAIN ? linear_out_addr : fc2_residual_wr_addr),

    .residual_wr_data(ENABLE_LIVE_CHAIN ? linear_out_data : fc2_residual_wr_data),

    .start(fc2_start),

    .busy(fc2_busy),

    .done(fc2_done),

    .stat_input_writes(),

    .stat_input_errors(),

    .stat_tiles(),

    .stat_acc_errors(),

    .stat_quant_errors(),

    .stat_add_errors(),

    .out_valid(fc2_out_valid),

    .out_addr(fc2_out_addr),

    .out_data(fc2_out_data),

    .stat_stream_items(fc2_stream_items)

);



assign frontend_valid=norm3_out_valid;

assign frontend_address=norm3_out_addr;

assign frontend_data=norm3_out_data;

assign frontend_done=norm3_done;

v600_runtime_fc2_norm3_stream_c0 u_norm3 (

    .clk(clk),

    .rst_n(rst_n),

    .clear(frontend_owner ? frontend_clear : clear_pulse),

    .in_wr_valid(frontend_owner ? frontend_input_valid : fc2_out_valid),

    .in_wr_addr(frontend_owner ? frontend_input_address : fc2_out_addr),

    .in_wr_data(frontend_owner ? frontend_input_data : fc2_out_data),

    .scale_wr_valid(frontend_owner ? frontend_scale_valid : norm3_scale_wr_valid),

    .scale_wr_addr(frontend_owner ? frontend_param_address : norm3_scale_wr_addr),

    .scale_wr_data(frontend_owner ? frontend_param_data : norm3_scale_wr_data),

    .bias_wr_valid(frontend_owner ? frontend_bias_valid : norm3_bias_wr_valid),

    .bias_wr_addr(frontend_owner ? frontend_param_address : norm3_bias_wr_addr),

    .bias_wr_data(frontend_owner ? frontend_param_data : norm3_bias_wr_data),

    .start(frontend_owner ? frontend_start : norm3_start),

    .out_ready(frontend_owner ? frontend_ready : ((trusted_authorized && !trusted_cancel) ? 1'b1 : (store_stream_ready && !store_fc2_select))),

    .busy(norm3_busy),

    .done(norm3_done),

    .stat_input_writes(),

    .stat_input_errors(),

    .stat_rows(),

    .stat_items(),

    .stat_mean_errors(),

    .stat_factor_errors(),

    .stat_norm_errors(),

    .stat_ext_errors(),

    .out_valid(norm3_out_valid),

    .out_addr(norm3_out_addr),

    .out_data(norm3_out_data),

    .stat_stream_items(norm3_stream_items)

);



always @(posedge clk) begin

    if (!rst_n || clear_pulse) begin capture_index <= 0; capture_drops <= 0; end

    else if (store_start) begin capture_index <= 0; capture_drops <= 0; end

    else if (store_fc2_select && fc2_out_valid) begin

        if (store_stream_ready) capture_index <= capture_index + 1'b1;

        else capture_drops <= capture_drops + 1'b1;

    end

end



v637_norm3_stream_axi_store_adapter_cfgfifo #(

    .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),

    .AXI_DATA_WIDTH(AXI_DATA_WIDTH),

    .FIFO_DEPTH(16),

    .FIFO_ADDR_WIDTH(4),

    .BURST_BEATS(16)

) u_store (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear_pulse),

    .start(store_start),

    .out_base_addr(OUT_BASE_ADDR),

    .total_items(store_fc2_select ? 16'd49152 : NORM3_TOTAL_ITEMS),

    .busy(store_busy),

    .done(store_done),

    .stream_valid(store_fc2_select ? fc2_out_valid : norm3_out_valid),

    .stream_ready(store_stream_ready),

    .stream_addr(store_fc2_select ? capture_index : norm3_out_addr),

    .stream_data(store_fc2_select ? fc2_out_data : norm3_out_data),

    .M_AXI_ARADDR(),

    .M_AXI_ARLEN(),

    .M_AXI_ARSIZE(),

    .M_AXI_ARBURST(),

    .M_AXI_ARVALID(),

    .M_AXI_ARREADY(1'b1),

    .M_AXI_RDATA({AXI_DATA_WIDTH{1'b0}}),

    .M_AXI_RRESP(2'b00),

    .M_AXI_RLAST(1'b0),

    .M_AXI_RVALID(1'b0),

    .M_AXI_RREADY(),

    .M_AXI_AWADDR(M_AXI_AWADDR),

    .M_AXI_AWLEN(M_AXI_AWLEN),

    .M_AXI_AWSIZE(M_AXI_AWSIZE),

    .M_AXI_AWBURST(M_AXI_AWBURST),

    .M_AXI_AWVALID(M_AXI_AWVALID),

    .M_AXI_AWREADY(M_AXI_AWREADY),

    .M_AXI_WDATA(store_axi_wdata),

    .M_AXI_WSTRB(store_axi_wstrb),

    .M_AXI_WLAST(store_axi_wlast),

    .M_AXI_WVALID(store_axi_wvalid),

    .M_AXI_WREADY(store_axi_wready),

    .M_AXI_BRESP(M_AXI_BRESP),

    .M_AXI_BVALID(M_AXI_BVALID),

    .M_AXI_BREADY(M_AXI_BREADY),

    .stat_axi_write_cmds(),

    .stat_axi_write_beats(stat_store_beats),

    .stat_axi_errors(stat_store_errors),

    .stat_stream_items(),

    .stat_packed_beats(),

    .stat_fifo_stall_cycles(stat_store_fifo_stall_cycles),

    .stat_order_errors(),

    .stat_fifo_max_level(stat_store_fifo_max_level),

    .stat_fifo_level(stat_store_fifo_level)

);



endmodule

