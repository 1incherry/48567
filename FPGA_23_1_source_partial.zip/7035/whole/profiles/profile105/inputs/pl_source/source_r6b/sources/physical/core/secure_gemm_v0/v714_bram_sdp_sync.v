`timescale 1ns/1ps

module v714_bram_sdp_sync #(
    parameter DATA_W = 256,
    parameter ADDR_W = 12,
    parameter DEPTH  = 2450,
    parameter FIT_MAX_DEPTH = 3072
) (
    input  wire                  clk,
    input  wire                  wr_en,
    input  wire [ADDR_W-1:0]     wr_addr,
    input  wire [DATA_W-1:0]     wr_data,
    input  wire                  rd_en,
    input  wire [ADDR_W-1:0]     rd_addr,
    output wire [DATA_W-1:0]     rd_data
);

function integer v760_clog2;
    input integer value;
    integer v;
    begin
        v = value - 1;
        for (v760_clog2 = 0; v > 0; v760_clog2 = v760_clog2 + 1)
            v = v >> 1;
    end
endfunction

`ifdef V760_RESOURCE_FIT
`ifdef V77X_FIT_GLOBAL_DEPTH
localparam GLOBAL_FIT_DEPTH = `V77X_FIT_GLOBAL_DEPTH;
`else
localparam GLOBAL_FIT_DEPTH = FIT_MAX_DEPTH;
`endif
localparam FIT_CAP_DEPTH = (FIT_MAX_DEPTH > GLOBAL_FIT_DEPTH) ? GLOBAL_FIT_DEPTH : FIT_MAX_DEPTH;
localparam EFF_DEPTH = (DEPTH > FIT_CAP_DEPTH) ? FIT_CAP_DEPTH : DEPTH;
`else
localparam EFF_DEPTH = DEPTH;
`endif
localparam EFF_ADDR_W = v760_clog2(EFF_DEPTH);

wire [EFF_ADDR_W-1:0] wr_addr_eff = wr_addr[EFF_ADDR_W-1:0];
wire [EFF_ADDR_W-1:0] rd_addr_eff = rd_addr[EFF_ADDR_W-1:0];

// V921: shape-preserving segmented physical RAM; protocol and bounds unchanged.
v921_segmented_sdp #(.DATA_W(DATA_W),.ADDR_W(EFF_ADDR_W),.DEPTH(EFF_DEPTH)) u_storage(
 .clk(clk),.wr_en(wr_en),.wr_addr(wr_addr_eff),.wr_data(wr_data),
 .rd_en(rd_en),.rd_addr(rd_addr_eff),.rd_data(rd_data));

// synthesis translate_off
`ifdef V760_RESOURCE_FIT
always @(posedge clk) begin
    if (wr_en && (wr_addr >= EFF_DEPTH)) begin
        $display("[%0t] ERROR: v714_bram_sdp_sync write window overflow addr=%0d depth=%0d", $time, wr_addr, EFF_DEPTH);
        $stop;
    end
    if (rd_en && (rd_addr >= EFF_DEPTH)) begin
        $display("[%0t] ERROR: v714_bram_sdp_sync read window overflow addr=%0d depth=%0d", $time, rd_addr, EFF_DEPTH);
        $stop;
    end
end
`endif
// synthesis translate_on

endmodule

`timescale 1ns/1ps
// Audit prototype: preserve every location, data bit and synchronous read cycle.
// Separate a large non-power-of-two memory so inference need not round its full
// width up to the next power of two. Each leaf still uses the original RAM RTL.
module v921_segmented_sdp #(parameter DATA_W=16,ADDR_W=16,DEPTH=49152)(
 input wire clk,wr_en,input wire [ADDR_W-1:0] wr_addr,
 input wire [DATA_W-1:0] wr_data,input wire rd_en,
 input wire [ADDR_W-1:0] rd_addr,output wire [DATA_W-1:0] rd_data
);
 function integer floor_pow2;
  input integer n; integer p;
  begin p=1;while(p*2<=n)p=p*2;floor_pow2=p;end
 endfunction
 localparam CUT=floor_pow2(DEPTH);
 localparam OPTIMIZE=((DATA_W==16 && (DEPTH==49152 || DEPTH==2400)) ||
   (DATA_W==8 && (DEPTH==9264 || DEPTH==24576)) ||
   (DATA_W==256 && (DEPTH==2450 || DEPTH==2548 || DEPTH==2352)));
 generate if(!OPTIMIZE || DEPTH<=2048 || CUT==DEPTH) begin: leaf
  v921_sdp_leaf #(.DATA_W(DATA_W),.ADDR_W(ADDR_W),.DEPTH(DEPTH)) ram(
   .clk(clk),.wr_en(wr_en),.wr_addr(wr_addr),.wr_data(wr_data),
   .rd_en(rd_en),.rd_addr(rd_addr),.rd_data(rd_data));
 end else begin: split
  wire [DATA_W-1:0] lo_q,hi_q;
  wire [ADDR_W-1:0] wr_hi=wr_addr-CUT,rd_hi=rd_addr-CUT;
  reg hi_select;
  always @(posedge clk) if(rd_en)hi_select<=(rd_addr>=CUT);
  v921_segmented_sdp #(.DATA_W(DATA_W),.ADDR_W(ADDR_W),.DEPTH(CUT)) lo(
   .clk(clk),.wr_en(wr_en&&wr_addr<CUT),.wr_addr(wr_addr),.wr_data(wr_data),
   .rd_en(rd_en&&rd_addr<CUT),.rd_addr(rd_addr),.rd_data(lo_q));
  v921_segmented_sdp #(.DATA_W(DATA_W),.ADDR_W(ADDR_W),.DEPTH(DEPTH-CUT)) hi(
   .clk(clk),.wr_en(wr_en&&wr_addr>=CUT),.wr_addr(wr_hi),.wr_data(wr_data),
   .rd_en(rd_en&&rd_addr>=CUT),.rd_addr(rd_hi),.rd_data(hi_q));
  assign rd_data=hi_select?hi_q:lo_q;
 end endgenerate
endmodule


module v921_sdp_leaf #(parameter DATA_W=16,ADDR_W=16,DEPTH=49152)(
 input wire clk,wr_en,input wire [ADDR_W-1:0] wr_addr,
 input wire [DATA_W-1:0] wr_data,input wire rd_en,
 input wire [ADDR_W-1:0] rd_addr,output reg [DATA_W-1:0] rd_data);
 (* ram_style="block" *) reg [DATA_W-1:0] mem[0:DEPTH-1];
 always @(posedge clk) if(wr_en)mem[wr_addr]<=wr_data;
 always @(posedge clk) if(rd_en)rd_data<=mem[rd_addr];
endmodule
