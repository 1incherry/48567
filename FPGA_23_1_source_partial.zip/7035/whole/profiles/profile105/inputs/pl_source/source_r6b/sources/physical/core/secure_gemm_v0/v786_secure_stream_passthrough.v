`timescale 1ns/1ps

// V786 integration boundary for a future AEAD engine. This version is a
// zero-latency ready/valid passthrough. It does not encrypt data.
module v786_secure_stream_passthrough #(
    parameter DATA_WIDTH = 256,
    parameter KEEP_WIDTH = DATA_WIDTH / 8
) (
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  clear,
    input  wire                  s_valid,
    output wire                  s_ready,
    input  wire [DATA_WIDTH-1:0] s_data,
    input  wire [KEEP_WIDTH-1:0] s_keep,
    input  wire                  s_last,
    output wire                  m_valid,
    input  wire                  m_ready,
    output wire [DATA_WIDTH-1:0] m_data,
    output wire [KEEP_WIDTH-1:0] m_keep,
    output wire                  m_last,
    output reg  [31:0]           stat_beats,
    output reg  [31:0]           stat_stall_cycles
);

assign s_ready = m_ready;
assign m_valid = s_valid;
assign m_data = s_data;
assign m_keep = s_keep;
assign m_last = s_last;

always @(posedge clk) begin
    if (!rst_n) begin
        stat_beats <= 32'd0;
        stat_stall_cycles <= 32'd0;
    end else if (clear) begin
        stat_beats <= 32'd0;
        stat_stall_cycles <= 32'd0;
    end else begin
        if (s_valid && s_ready)
            stat_beats <= stat_beats + 1'b1;
        if (s_valid && !s_ready)
            stat_stall_cycles <= stat_stall_cycles + 1'b1;
    end
end

endmodule
