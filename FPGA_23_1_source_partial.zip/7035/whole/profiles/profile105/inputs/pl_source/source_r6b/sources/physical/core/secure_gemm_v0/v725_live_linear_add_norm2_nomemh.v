`timescale 1ns/1ps



module v725_live_linear_add_norm2_nomemh #(parameter EXTERNAL_LINEAR=0) (

    output wire[7:0]linear_ext_rd_row,linear_ext_rd_col,output wire linear_ext_rd_en,output wire[15:0]linear_ext_rd_addr,input wire[15:0]linear_ext_rd_data,

    input  wire clk,

    input  wire rst_n,

    input  wire clear,



    input  wire         linear_add_wr_valid,

    output reg          linear_add_wr_ready,

    input  wire [15:0]  linear_add_wr_addr,

    input  wire signed [15:0] linear_add_wr_data,



    input  wire         scale_wr_valid,

    output reg          scale_wr_ready,

    input  wire [7:0]   scale_wr_addr,

    input  wire signed [31:0] scale_wr_data,



    input  wire         bias_wr_valid,

    output reg          bias_wr_ready,

    input  wire [7:0]   bias_wr_addr,

    input  wire signed [31:0] bias_wr_data,



    input  wire         start,

    output reg          busy,

    output reg          done,



    output reg          out_valid,

    input  wire         out_ready,

    output reg [15:0]   out_addr,

    output reg signed [15:0] out_data,



    output reg [31:0]   stat_linear_add_writes,

    output reg [31:0]   stat_scale_writes,

    output reg [31:0]   stat_bias_writes,

    output reg [31:0]   stat_rows,

    output reg [31:0]   stat_items,

    output reg [31:0]   stat_stream_items,

    output reg [31:0]   stat_errors,

    output reg [31:0]   stat_cycles,

    output reg [4:0]    stat_stage

);



localparam ROWS_IN = 208;

localparam ROWS_PAD = 256;

localparam DIM = 192;

localparam DIM_EXT = 194;

localparam COUNT = ROWS_IN * DIM;

localparam COUNT_PAD = ROWS_PAD * DIM;



localparam ST_IDLE       = 5'd0;

localparam ST_ROW_INIT   = 5'd1;

localparam ST_ACC_REQ    = 5'd2;

localparam ST_ACC_WAIT   = 5'd3;

localparam ST_MEAN       = 5'd4;

localparam ST_NEWTON     = 5'd5;

localparam ST_FACTOR     = 5'd6;

localparam ST_NORM_REQ   = 5'd7;

localparam ST_NORM_CALC  = 5'd8;

localparam ST_NORM_SCALE = 5'd9;

localparam ST_NORM_CLIP  = 5'd10;

localparam ST_NORM_CHECK = 5'd11;

localparam ST_NEXT_ROW   = 5'd12;

localparam ST_EXT_CHECK  = 5'd13;

localparam ST_DONE       = 5'd14;

localparam ST_EXT_LINEAR = 5'd15;

localparam ST_EXT_PAD    = 5'd16;

localparam ST_ACC_LAT    = 5'd17;

localparam ST_NORM_LAT   = 5'd18;

localparam ST_EXT_LINEAR_LAT = 5'd19;

localparam ST_EXT_PAD_LAT    = 5'd20;

localparam ST_NEWTON_DIV     = 5'd21;

localparam ST_NEWTON_COMMIT  = 5'd22;

localparam ST_FACTOR_DIV     = 5'd23;

localparam ST_FACTOR_COMMIT  = 5'd24;

// Keep the wide square, constant divide and variance subtraction on separate

// cycles.  Combining all three operations in ST_MEAN synthesized into a

// three-DSP chain followed by roughly fifty CARRY4 levels on 7-series.

localparam ST_MEAN_DIV       = 5'd25;

localparam ST_VAR_COMMIT     = 5'd26;

localparam ST_MEAN_DIV_WAIT  = 5'd27;

localparam ST_MEAN_VALUE_DIV  = 5'd28;

localparam ST_MEAN_VALUE_WAIT = 5'd29;

localparam ST_EXT_PAD_EMIT = 5'd30;
localparam ST_NORM_PRODUCT = 5'd31;



reg [4:0] state;

reg [7:0] row;

reg [7:0] col;

reg [3:0] iter;



reg signed [15:0] x_r;

reg signed [31:0] scale_r;

reg signed [31:0] bias_r;

reg signed [31:0] mean_r;

reg signed [31:0] factor_r;

reg signed [31:0] std_r;

reg signed [31:0] div_r;

// Fixed 192-value int16 row: exact bounds [-6291456,6291264].
reg signed [23:0] sum_acc_r;
wire signed [63:0] sum_r={{40{sum_acc_r[23]}},sum_acc_r};

// 192 * (-32768)^2 = 206158430208 fits signed39; signed38 does not.
reg signed [38:0] square_acc_r;
wire signed [63:0] sq_sum_r={{25{square_acc_r[38]}},square_acc_r};

reg signed [63:0] mean_sum_sq_r;

reg signed [63:0] var_r;

reg signed [63:0] norm_raw_r;
// Preserve the original 64-bit expression width; this register splits
// BRAM read + signed subtraction from the multiplier on the 100 MHz path.
reg signed [63:0] norm_diff_r;

reg signed [63:0] scaled_r;

reg signed [15:0] norm_r;

reg signed [15:0] ext_r;

// Shared unsigned restoring divider.  Norm2's variance and Newton estimate

// are non-negative, so this preserves Verilog's positive signed-division

// truncation while replacing a synthesized 64/32 combinational divider with

// one compare/subtract step per cycle.

reg [63:0] div_dividend_r;

reg [31:0] div_divisor_r;

reg [63:0] div_quotient_r;

reg [32:0] div_remainder_r;

reg [5:0] div_bit_r;

wire [32:0] div_shift_w = {div_remainder_r[31:0],

                           div_dividend_r[div_bit_r]};

wire div_subtract_w = div_shift_w >= {1'b0,div_divisor_r};

`ifdef V878_NORM2_RADIX16

wire r16_mean_div_w = (state == ST_MEAN_DIV);

wire r16_mean_value_div_w = (state == ST_MEAN_VALUE_DIV);

wire r16_start_valid_w = r16_mean_value_div_w || r16_mean_div_w ||

                         (((state == ST_NEWTON) || (state == ST_FACTOR)) &&

                          (std_r != 32'sd0));

wire r16_start_ready_w,r16_finish_valid_w;

wire [63:0] r16_quotient_w,r16_remainder_w;

wire r16_divisor_zero_w;

wire [63:0] r16_mean_abs_w = sum_r[63] ? (~sum_r[63:0] + 64'd1) : sum_r[63:0];

wire [63:0] r16_dividend_w = r16_mean_value_div_w ? r16_mean_abs_w :

                             r16_mean_div_w ? mean_sum_sq_r[63:0] :

                             ((state == ST_FACTOR) ?

                              64'd2147483647 : var_r[63:0]);

wire [63:0] r16_divisor_w = (r16_mean_value_div_w || r16_mean_div_w) ? 64'd192 :

                            {32'd0,std_r[31:0]};

intdiv_restoring_compat #(.D_W(64)) u_norm2_r16_divider(

    .start_valid_i(r16_start_valid_w),.start_ready_o(r16_start_ready_w),

    .flush_i(clear),.signed_op_i(1'b0),

    .dividend_i(r16_dividend_w),.divisor_i(r16_divisor_w),

    .finish_valid_o(r16_finish_valid_w),.finish_ready_i(1'b1),

    .quotient_o(r16_quotient_w),.remainder_o(r16_remainder_w),

    .divisor_is_zero_o(r16_divisor_zero_w),.clk(clk),.rst_n(rst_n));

`endif

reg linear_rd_en;

reg [15:0] linear_rd_addr;reg[7:0]linear_rd_row,linear_rd_col;

wire [15:0] linear_rd_data_u;

wire signed [15:0] linear_rd_data_s = $signed(linear_rd_data_u);

reg scale_rd_en;

reg [7:0] scale_rd_addr;

wire [31:0] scale_rd_data_u;

wire signed [31:0] scale_rd_data_s = $signed(scale_rd_data_u);

reg bias_rd_en;

reg [7:0] bias_rd_addr;

wire [31:0] bias_rd_data_u;

wire signed [31:0] bias_rd_data_s = $signed(bias_rd_data_u);



wire [15:0] linear_idx = row * DIM[15:0] + col;

wire [15:0] ext_idx = row * DIM_EXT[15:0] + col;

wire linear_add_wr_en_i = linear_add_wr_valid && (linear_add_wr_addr < COUNT[15:0]);

wire scale_wr_en_i = scale_wr_valid && (scale_wr_addr < DIM[7:0]);

wire bias_wr_en_i = bias_wr_valid && (bias_wr_addr < DIM[7:0]);



assign linear_ext_rd_row=linear_rd_row;assign linear_ext_rd_col=linear_rd_col;
assign linear_ext_rd_en=linear_rd_en;

assign linear_ext_rd_addr=linear_rd_addr;

generate if(EXTERNAL_LINEAR)begin: shared_linear

 assign linear_rd_data_u=linear_ext_rd_data;

end else begin: original_linear

`ifdef V859_NORM2_LINEAR_LUTRAM

v859_distributed_sdp_sync #(

`else

v714_bram_sdp_sync #(

`endif

    .DATA_W(16),

    .ADDR_W(16),

    .DEPTH(COUNT),

    .FIT_MAX_DEPTH(COUNT)

) u_linear_add_mem (

    .clk(clk),

    .wr_en(linear_add_wr_en_i),

    .wr_addr(linear_add_wr_addr),

    .wr_data(linear_add_wr_data),

    .rd_en(linear_rd_en),

    .rd_addr(linear_rd_addr),

    .rd_data(linear_rd_data_u)

);



end endgenerate



v714_bram_sdp_sync #(

    .DATA_W(32),

    .ADDR_W(8),

    .DEPTH(DIM)

) u_scale_mem (

    .clk(clk),

    .wr_en(scale_wr_en_i),

    .wr_addr(scale_wr_addr),

    .wr_data(scale_wr_data),

    .rd_en(scale_rd_en),

    .rd_addr(scale_rd_addr),

    .rd_data(scale_rd_data_u)

);



v714_bram_sdp_sync #(

    .DATA_W(32),

    .ADDR_W(8),

    .DEPTH(DIM)

) u_bias_mem (

    .clk(clk),

    .wr_en(bias_wr_en_i),

    .wr_addr(bias_wr_addr),

    .wr_data(bias_wr_data),

    .rd_en(bias_rd_en),

    .rd_addr(bias_rd_addr),

    .rd_data(bias_rd_data_u)

);



always @(posedge clk) begin

    if (!rst_n) begin

        linear_add_wr_ready <= 1'b1;

        scale_wr_ready <= 1'b1;

        bias_wr_ready <= 1'b1;

        state <= ST_IDLE;

        row <= 8'd0;

        col <= 8'd0;

        iter <= 4'd0;

        x_r <= 16'sd0;

        scale_r <= 32'sd0;

        bias_r <= 32'sd0;

        mean_r <= 32'sd0;

        factor_r <= 32'sd0;

        std_r <= 32'sd0;

        div_r <= 32'sd0;

        sum_acc_r <= 64'sd0;

        square_acc_r <= 64'sd0;

        mean_sum_sq_r <= 64'sd0;

        var_r <= 64'sd0;

        norm_raw_r <= 64'sd0;
        norm_diff_r <= 64'sd0;

        scaled_r <= 64'sd0;

        norm_r <= 16'sd0;

        ext_r <= 16'sd0;

        div_dividend_r <= 64'd0;

        div_divisor_r <= 32'd0;

        div_quotient_r <= 64'd0;

        div_remainder_r <= 33'd0;

        div_bit_r <= 6'd0;

        linear_rd_en <= 1'b0;

        linear_rd_addr <= 16'd0;linear_rd_row<=0;linear_rd_col<=0;

        scale_rd_en <= 1'b0;

        scale_rd_addr <= 8'd0;

        bias_rd_en <= 1'b0;

        bias_rd_addr <= 8'd0;

        busy <= 1'b0;

        done <= 1'b0;

        out_valid <= 1'b0;

        out_addr <= 16'd0;

        out_data <= 16'sd0;

        stat_linear_add_writes <= 32'd0;

        stat_scale_writes <= 32'd0;

        stat_bias_writes <= 32'd0;

        stat_rows <= 32'd0;

        stat_items <= 32'd0;

        stat_stream_items <= 32'd0;

        stat_errors <= 32'd0;

        stat_cycles <= 32'd0;

        stat_stage <= ST_IDLE;

    end else begin

        done <= 1'b0;

        out_valid <= 1'b0;

        linear_add_wr_ready <= 1'b1;

        scale_wr_ready <= 1'b1;

        bias_wr_ready <= 1'b1;

        linear_rd_en <= 1'b0;

        scale_rd_en <= 1'b0;

        bias_rd_en <= 1'b0;



        if (busy)

            stat_cycles <= stat_cycles + 1'b1;



        if (clear) begin

            state <= ST_IDLE;

            busy <= 1'b0;

            stat_rows <= 32'd0;

            stat_items <= 32'd0;

            stat_stream_items <= 32'd0;

            stat_errors <= 32'd0;

            stat_cycles <= 32'd0;

            stat_stage <= ST_IDLE;

        end else begin

            if (linear_add_wr_valid) begin

                if (linear_add_wr_addr < COUNT[15:0]) begin

                    stat_linear_add_writes <= stat_linear_add_writes + 1'b1;

                end else begin

                    stat_errors <= stat_errors + 1'b1;

                end

            end



            if (scale_wr_valid) begin

                if (scale_wr_addr < DIM[7:0]) begin

                    stat_scale_writes <= stat_scale_writes + 1'b1;

                end else begin

                    stat_errors <= stat_errors + 1'b1;

                end

            end



            if (bias_wr_valid) begin

                if (bias_wr_addr < DIM[7:0]) begin

                    stat_bias_writes <= stat_bias_writes + 1'b1;

                end else begin

                    stat_errors <= stat_errors + 1'b1;

                end

            end



            case (state)

                ST_IDLE: begin

                    busy <= 1'b0;

                    if (start) begin

                        busy <= 1'b1;

                        row <= 8'd0;

                        col <= 8'd0;

                        iter <= 4'd0;

                        stat_rows <= 32'd0;

                        stat_items <= 32'd0;

                        stat_stream_items <= 32'd0;

                        stat_stage <= ST_ROW_INIT;

                        state <= ST_ROW_INIT;

                    end

                end



                ST_ROW_INIT: begin

                    col <= 8'd0;

                    sum_acc_r <= 64'sd0;

                    square_acc_r <= 64'sd0;

                    stat_stage <= ST_ACC_REQ;

                    state <= ST_ACC_REQ;

                end



                ST_ACC_REQ: begin

                    linear_rd_en <= 1'b1;

                    linear_rd_addr <= linear_idx;linear_rd_row<=row;linear_rd_col<=col;

                    stat_stage <= ST_ACC_LAT;

                    state <= ST_ACC_LAT;

                end



                ST_ACC_LAT: begin

                    stat_stage <= ST_ACC_WAIT;

                    state <= ST_ACC_WAIT;

                end



                ST_ACC_WAIT: begin

                    x_r <= linear_rd_data_s;

                    sum_acc_r <= sum_r + linear_rd_data_s;

                    square_acc_r <= sq_sum_r + linear_rd_data_s * linear_rd_data_s;

                    if (col == DIM - 1) begin

                        col <= 8'd0;

                        stat_stage <= ST_MEAN;

                        state <= ST_MEAN;

                    end else begin

                        col <= col + 1'b1;

                        stat_stage <= ST_ACC_REQ;

                        state <= ST_ACC_REQ;

                    end

                end



                ST_MEAN: begin

                    mean_sum_sq_r <= sum_r * sum_r;

`ifdef V878_NORM2_RADIX16

                    stat_stage <= ST_MEAN_VALUE_DIV;

                    state <= ST_MEAN_VALUE_DIV;

`else

                    mean_r <= sum_r / DIM;

                    stat_stage <= ST_MEAN_DIV;

                    state <= ST_MEAN_DIV;

`endif

                end



                ST_MEAN_VALUE_DIV: begin

`ifdef V878_NORM2_RADIX16

                    if (r16_start_ready_w) begin

                        stat_stage <= ST_MEAN_VALUE_WAIT;

                        state <= ST_MEAN_VALUE_WAIT;

                    end

`else

                    mean_r <= sum_r / DIM;

                    stat_stage <= ST_MEAN_DIV;

                    state <= ST_MEAN_DIV;

`endif

                end



                ST_MEAN_VALUE_WAIT: begin

`ifdef V878_NORM2_RADIX16

                    if (r16_finish_valid_w) begin

                        if (sum_r[63])

                            mean_r <= -$signed(r16_quotient_w[31:0]);

                        else

                            mean_r <= $signed(r16_quotient_w[31:0]);

                        stat_stage <= ST_MEAN_DIV;

                        state <= ST_MEAN_DIV;

                    end

`else

                    stat_stage <= ST_MEAN_DIV;

                    state <= ST_MEAN_DIV;

`endif

                end



                ST_MEAN_DIV: begin

`ifdef V878_NORM2_RADIX16

                    if (r16_start_ready_w) begin

                        stat_stage <= ST_MEAN_DIV_WAIT;

                        state <= ST_MEAN_DIV_WAIT;

                    end

`else

                    mean_sum_sq_r <= mean_sum_sq_r / DIM;

                    stat_stage <= ST_VAR_COMMIT;

                    state <= ST_VAR_COMMIT;

`endif

                end



                ST_MEAN_DIV_WAIT: begin

`ifdef V878_NORM2_RADIX16

                    if (r16_finish_valid_w) begin

                        mean_sum_sq_r <= $signed(r16_quotient_w);

                        stat_stage <= ST_VAR_COMMIT;

                        state <= ST_VAR_COMMIT;

                    end

`else

                    stat_stage <= ST_VAR_COMMIT;

                    state <= ST_VAR_COMMIT;

`endif

                end



                ST_VAR_COMMIT: begin

                    var_r <= sq_sum_r - mean_sum_sq_r;

                    std_r <= 32'sd65536;

                    iter <= 4'd0;

                    stat_stage <= ST_NEWTON;

                    state <= ST_NEWTON;

                end



                ST_NEWTON: begin

                    if (std_r == 32'sd0) begin

                        div_r <= 32'sd0;

                        std_r <= 32'sd0;

                        if (iter == 4'd9) begin

                            stat_stage <= ST_FACTOR;

                            state <= ST_FACTOR;

                        end else begin

                            iter <= iter + 1'b1;

                        end

                    end else begin

`ifdef V878_NORM2_RADIX16

                        if (r16_start_ready_w) begin

                            stat_stage <= ST_NEWTON_DIV;

                            state <= ST_NEWTON_DIV;

                        end

`else

                        div_dividend_r <= var_r[63:0];

                        div_divisor_r <= std_r[31:0];

                        div_quotient_r <= 64'd0;

                        div_remainder_r <= 33'd0;

                        div_bit_r <= 6'd63;

                        stat_stage <= ST_NEWTON_DIV;

                        state <= ST_NEWTON_DIV;

`endif

                    end

                end



                ST_NEWTON_DIV: begin

`ifdef V878_NORM2_RADIX16

                    if (r16_finish_valid_w) begin

                        div_quotient_r <= r16_quotient_w;

                        stat_stage <= ST_NEWTON_COMMIT;

                        state <= ST_NEWTON_COMMIT;

                    end

`else

                    if (div_subtract_w) begin

                        div_remainder_r <= div_shift_w - {1'b0,div_divisor_r};

                        div_quotient_r[div_bit_r] <= 1'b1;

                    end else begin

                        div_remainder_r <= div_shift_w;

                        div_quotient_r[div_bit_r] <= 1'b0;

                    end

                    if (div_bit_r == 0) begin

                        stat_stage <= ST_NEWTON_COMMIT;

                        state <= ST_NEWTON_COMMIT;

                    end else begin

                        div_bit_r <= div_bit_r - 1'b1;

                    end

`endif

                end



                ST_NEWTON_COMMIT: begin

                    div_r <= $signed(div_quotient_r[31:0]);

                    // Divide by two is an arithmetic shift, not a general

                    // divider; keep this path free of a '/' operator.

                    std_r <= ($signed(std_r) + $signed(div_quotient_r[31:0])) >>> 1;

                    if (iter == 4'd9) begin

                        stat_stage <= ST_FACTOR;

                        state <= ST_FACTOR;

                    end else begin

                        iter <= iter + 1'b1;

                        stat_stage <= ST_NEWTON;

                        state <= ST_NEWTON;

                    end

                end



                ST_FACTOR: begin

                    if (std_r == 32'sd0) begin

                        factor_r <= 32'sd0;

                        stat_stage <= ST_NORM_REQ;

                        state <= ST_NORM_REQ;

                    end else begin

`ifdef V878_NORM2_RADIX16

                        if (r16_start_ready_w) begin

                            stat_stage <= ST_FACTOR_DIV;

                            state <= ST_FACTOR_DIV;

                        end

`else

                        div_dividend_r <= 64'd2147483647;

                        div_divisor_r <= std_r[31:0];

                        div_quotient_r <= 64'd0;

                        div_remainder_r <= 33'd0;

                        div_bit_r <= 6'd63;

                        stat_stage <= ST_FACTOR_DIV;

                        state <= ST_FACTOR_DIV;

`endif

                    end

                end



                ST_FACTOR_DIV: begin

`ifdef V878_NORM2_RADIX16

                    if (r16_finish_valid_w) begin

                        div_quotient_r <= r16_quotient_w;

                        stat_stage <= ST_FACTOR_COMMIT;

                        state <= ST_FACTOR_COMMIT;

                    end

`else

                    if (div_subtract_w) begin

                        div_remainder_r <= div_shift_w - {1'b0,div_divisor_r};

                        div_quotient_r[div_bit_r] <= 1'b1;

                    end else begin

                        div_remainder_r <= div_shift_w;

                        div_quotient_r[div_bit_r] <= 1'b0;

                    end

                    if (div_bit_r == 0) begin

                        stat_stage <= ST_FACTOR_COMMIT;

                        state <= ST_FACTOR_COMMIT;

                    end else begin

                        div_bit_r <= div_bit_r - 1'b1;

                    end

`endif

                end



                ST_FACTOR_COMMIT: begin

                    factor_r <= $signed(div_quotient_r[31:0]);

                    stat_stage <= ST_NORM_REQ;

                    state <= ST_NORM_REQ;

                end



                ST_NORM_REQ: begin

                    linear_rd_en <= 1'b1;

                    linear_rd_addr <= linear_idx;linear_rd_row<=row;linear_rd_col<=col;

                    scale_rd_en <= 1'b1;

                    scale_rd_addr <= col;

                    bias_rd_en <= 1'b1;

                    bias_rd_addr <= col;

                    stat_stage <= ST_NORM_LAT;

                    state <= ST_NORM_LAT;

                end



                ST_NORM_LAT: begin

                    stat_stage <= ST_NORM_CALC;

                    state <= ST_NORM_CALC;

                end



                ST_NORM_CALC: begin

                    x_r <= linear_rd_data_s;

                    scale_r <= scale_rd_data_s;

                    bias_r <= bias_rd_data_s;

                    norm_diff_r <= $signed(linear_rd_data_s) - $signed(mean_r);
                    stat_stage <= ST_NORM_PRODUCT;
                    state <= ST_NORM_PRODUCT;
                end

                ST_NORM_PRODUCT: begin
                    norm_raw_r <= (norm_diff_r * factor_r) >>> 1;

                    stat_stage <= ST_NORM_SCALE;

                    state <= ST_NORM_SCALE;

                end



                ST_NORM_SCALE: begin

                    scaled_r <= ((norm_raw_r + bias_r) * scale_r) >>> 29;

                    stat_stage <= ST_NORM_CLIP;

                    state <= ST_NORM_CLIP;

                end



                ST_NORM_CLIP: begin

                    if (scaled_r > 64'sd32767)

                        norm_r <= 16'sh7fff;

                    else if (scaled_r < -64'sd32768)

                        norm_r <= 16'sh8000;

                    else

                        norm_r <= scaled_r[15:0];

                    stat_stage <= ST_NORM_CHECK;

                    state <= ST_NORM_CHECK;

                end



                ST_NORM_CHECK: begin

                    out_valid <= 1'b1;

                    out_addr <= row * DIM_EXT[15:0] + col;

                    out_data <= norm_r;

                    stat_items <= stat_items + 1'b1;

                    stat_stream_items <= stat_stream_items + 1'b1;

                    if (col == DIM - 1) begin

                        stat_stage <= ST_NEXT_ROW;

                        state <= ST_NEXT_ROW;

                    end else begin

                        col <= col + 1'b1;

                        stat_stage <= ST_NORM_REQ;

                        state <= ST_NORM_REQ;

                    end

                end



                ST_NEXT_ROW: begin

                    stat_rows <= stat_rows + 1'b1;

                    if (row == ROWS_IN - 1) begin

                        row <= 8'd0;

                        col <= 8'd0;

                        stat_stage <= ST_EXT_CHECK;

                        state <= ST_EXT_CHECK;

                    end else begin

                        row <= row + 1'b1;

                        stat_stage <= ST_ROW_INIT;

                        state <= ST_ROW_INIT;

                    end

                end



                ST_EXT_CHECK: begin

                    if (col < DIM) begin

                        if (row < ROWS_IN) begin

                            col <= DIM[7:0];

                            stat_stage <= ST_EXT_CHECK;

                            state <= ST_EXT_CHECK;

                        end else begin

                            scale_rd_en <= 1'b1;

                            scale_rd_addr <= col;

                            bias_rd_en <= 1'b1;

                            bias_rd_addr <= col;

                            stat_stage <= ST_EXT_PAD_LAT;

                            state <= ST_EXT_PAD_LAT;

                        end

                    end else if (col == DIM) begin

                        ext_r <= 16'sd16384;

                        out_valid <= 1'b1;

                        out_addr <= ext_idx;

                        out_data <= 16'sd16384;

                        stat_stream_items <= stat_stream_items + 1'b1;

                    end else begin

                        ext_r <= 16'sd1;

                        out_valid <= 1'b1;

                        out_addr <= ext_idx;

                        out_data <= 16'sd1;

                        stat_stream_items <= stat_stream_items + 1'b1;

                    end



                    if (col >= DIM) begin

                        if ((row == ROWS_PAD - 1) && (col == DIM_EXT - 1)) begin

                            stat_stage <= ST_DONE;

                            state <= ST_DONE;

                        end else if (col == DIM_EXT - 1) begin

                            col <= 8'd0;

                            row <= row + 1'b1;

                        end else begin

                            col <= col + 1'b1;

                        end

                    end

                end



                ST_EXT_LINEAR_LAT: begin

                    stat_stage <= ST_EXT_LINEAR;

                    state <= ST_EXT_LINEAR;

                end



                ST_EXT_LINEAR: begin

                    ext_r <= linear_rd_data_s;

                    out_valid <= 1'b1;

                    out_addr <= ext_idx;

                    out_data <= linear_rd_data_s;

                    stat_stream_items <= stat_stream_items + 1'b1;

                    if ((row == ROWS_PAD - 1) && (col == DIM_EXT - 1)) begin

                        stat_stage <= ST_DONE;

                        state <= ST_DONE;

                    end else if (col == DIM_EXT - 1) begin

                        col <= 8'd0;

                        row <= row + 1'b1;

                        stat_stage <= ST_EXT_CHECK;

                        state <= ST_EXT_CHECK;

                    end else begin

                        col <= col + 1'b1;

                        stat_stage <= ST_EXT_CHECK;

                        state <= ST_EXT_CHECK;

                    end

                end



                ST_EXT_PAD_LAT: begin

                    stat_stage <= ST_EXT_PAD;

                    state <= ST_EXT_PAD;

                end



                ST_EXT_PAD: begin

                    // Same signed 64-bit expression, now captured before clip.

                    // This breaks the BRAM -> DSP cascade -> saturation path.

                    scaled_r <= (bias_rd_data_s * scale_rd_data_s) >>> 29;

                    stat_stage <= ST_EXT_PAD_EMIT;

                    state <= ST_EXT_PAD_EMIT;

                end



                ST_EXT_PAD_EMIT: begin

                    if (scaled_r > 64'sd32767)

                        ext_r = 16'sh7fff;

                    else if (scaled_r < -64'sd32768)

                        ext_r = 16'sh8000;

                    else

                        ext_r = scaled_r[15:0];

                    out_valid <= 1'b1;

                    out_addr <= ext_idx;

                    out_data <= ext_r;

                    stat_stream_items <= stat_stream_items + 1'b1;

                    if ((row == ROWS_PAD - 1) && (col == DIM_EXT - 1)) begin

                        stat_stage <= ST_DONE;

                        state <= ST_DONE;

                    end else if (col == DIM_EXT - 1) begin

                        col <= 8'd0;

                        row <= row + 1'b1;

                        stat_stage <= ST_EXT_CHECK;

                        state <= ST_EXT_CHECK;

                    end else begin

                        col <= col + 1'b1;

                        stat_stage <= ST_EXT_CHECK;

                        state <= ST_EXT_CHECK;

                    end

                end



                ST_DONE: begin

                    busy <= 1'b0;

                    done <= 1'b1;

                    stat_stage <= ST_IDLE;

                    state <= ST_IDLE;

                end



                default: begin

                    stat_stage <= ST_IDLE;

                    state <= ST_IDLE;

                end

            endcase

        end

    end

end



endmodule

