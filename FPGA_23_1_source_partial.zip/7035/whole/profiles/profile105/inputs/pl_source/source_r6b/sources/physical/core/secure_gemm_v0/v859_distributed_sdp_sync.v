`timescale 1ns/1ps

// Synchronous simple-dual-port distributed RAM used by the V859-compressed
// secure build.  The registered read interface matches v714_bram_sdp_sync.
module v859_distributed_sdp_sync #(
    parameter DATA_W = 16,
    parameter ADDR_W = 16,
    parameter DEPTH  = 39936,
    parameter FIT_MAX_DEPTH = DEPTH
) (
    input  wire                  clk,
    input  wire                  wr_en,
    input  wire [ADDR_W-1:0]     wr_addr,
    input  wire [DATA_W-1:0]     wr_data,
    input  wire                  rd_en,
    input  wire [ADDR_W-1:0]     rd_addr,
    output reg  [DATA_W-1:0]     rd_data
);

function integer v859_clog2;
    input integer value;
    integer v;
    begin
        v = value - 1;
        for (v859_clog2 = 0; v > 0; v859_clog2 = v859_clog2 + 1)
            v = v >> 1;
    end
endfunction

`ifdef V760_RESOURCE_FIT
`ifdef V77X_FIT_GLOBAL_DEPTH
localparam GLOBAL_FIT_DEPTH = `V77X_FIT_GLOBAL_DEPTH;
`else
localparam GLOBAL_FIT_DEPTH = FIT_MAX_DEPTH;
`endif
localparam FIT_CAP_DEPTH = (FIT_MAX_DEPTH > GLOBAL_FIT_DEPTH) ? GLOBAL_FIT_DEPTH : FIT_MAX_DEPTH;
localparam EFF_DEPTH = (DEPTH > FIT_CAP_DEPTH) ? FIT_CAP_DEPTH : DEPTH;
`else
localparam EFF_DEPTH = DEPTH;
`endif
localparam EFF_ADDR_W = v859_clog2(EFF_DEPTH);

wire [EFF_ADDR_W-1:0] wr_addr_eff = wr_addr[EFF_ADDR_W-1:0];
wire [EFF_ADDR_W-1:0] rd_addr_eff = rd_addr[EFF_ADDR_W-1:0];

(* ram_style = "distributed" *) reg [DATA_W-1:0] mem [0:EFF_DEPTH-1];

// synthesis translate_off
`ifdef V760_RESOURCE_FIT
always @(posedge clk) begin
    if (wr_en && (wr_addr >= EFF_DEPTH)) begin
        $display("[%0t] ERROR: v859_distributed_sdp_sync write window overflow addr=%0d depth=%0d", $time, wr_addr, EFF_DEPTH);
        $stop;
    end
    if (rd_en && (rd_addr >= EFF_DEPTH)) begin
        $display("[%0t] ERROR: v859_distributed_sdp_sync read window overflow addr=%0d depth=%0d", $time, rd_addr, EFF_DEPTH);
        $stop;
    end
end
`endif
// synthesis translate_on

always @(posedge clk) begin
    if (wr_en)
        mem[wr_addr_eff] <= wr_data;
end

always @(posedge clk) begin
    if (rd_en)
        rd_data <= mem[rd_addr_eff];
end

endmodule
