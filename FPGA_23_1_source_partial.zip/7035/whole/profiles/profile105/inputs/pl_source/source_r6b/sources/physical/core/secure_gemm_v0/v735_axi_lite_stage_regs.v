`timescale 1ns/1ps

module v735_axi_lite_stage_regs (
    input  wire        clk,
    input  wire        rst_n,

    input  wire [7:0]  s_axil_awaddr,
    input  wire        s_axil_awvalid,
    output reg         s_axil_awready,
    input  wire [31:0] s_axil_wdata,
    input  wire [3:0]  s_axil_wstrb,
    input  wire        s_axil_wvalid,
    output reg         s_axil_wready,
    output reg [1:0]   s_axil_bresp,
    output reg         s_axil_bvalid,
    input  wire        s_axil_bready,
    input  wire [7:0]  s_axil_araddr,
    input  wire        s_axil_arvalid,
    output reg         s_axil_arready,
    output reg [31:0]  s_axil_rdata,
    output reg [1:0]   s_axil_rresp,
    output reg         s_axil_rvalid,
    input  wire        s_axil_rready,

    output reg         store_fc2_select,
    input wire [31:0] capture_drops,
    input wire [31:0] debug_first_aw,
    input wire [31:0] debug_last_aw,
    input wire [31:0] debug_first_wdata,
    input wire [31:0] debug_first_wstrb,
    input wire [31:0] debug_aw_count,
    input wire [31:0] debug_b_count,
    input wire [31:0] debug_last_bresp,
    output reg         clear_pulse,
    output reg         load_start,
    output reg         qkv_bank_start,
    output reg         qkv_compute_start,
    output reg         qkt_start,
    output reg         softmax_start,
    output reg         prob_bank_start,
    output reg         av_start,
    output reg         concat_start,
    output reg         outproj_start,
    output reg         norm2_start,
    output reg         fc1_start,
    output reg         gelu_start,
    output reg         fc2_pad_start,
    output reg         fc2_start,
    output reg         norm3_start,
    output reg         store_start,

    output reg  [7:0]  load_dst,
    output reg  [31:0] load_axi_addr,
    output reg  [17:0] load_local_addr,
    output reg  [15:0] load_beats,
    output reg  [7:0]  load_burst_len_m1,
    output reg  [3:0]  qkv_block_id,
    output reg  [3:0]  qkv_op_id,
    output reg  [1:0]  current_head,
    output reg signed [31:0] softmax_x0,
    output reg signed [31:0] gelu_x0,
    output reg  [1:0]  prefetch_mode,
    output reg  [1:0]  security_mode,
    output reg  [11:0] prefetch_window_cap,
    output reg  [11:0] stage_budget_cap,
    output reg  [11:0] window_guard_words,
    output reg [31:0]  window_base_addr,
    output reg [15:0]  window_stride_words,
    output reg  [7:0]  crypto_key_id,
    output reg  [7:0]  prefetch_ahead_beats,
    output reg [127:0] crypto_key,
    output reg  [95:0] crypto_nonce,

    // Software completion extension: sticky done, W1C, ready, API identity.
    input  wire [16:0] done_events,
    input  wire [1:0]  load_ready,

    input  wire [31:0] status0,
    input  wire [31:0] status1,
    input  wire [31:0] status2,
    input  wire [31:0] status3,
    input  wire [31:0] status4,
    input  wire [31:0] status5,
    input  wire [31:0] status6,
    input  wire [31:0] status7,
    input  wire [31:0] status8,
    input  wire [31:0] status9,
    input  wire [31:0] status10,
    input  wire [31:0] status11,
    input  wire [31:0] status12,
    input  wire [31:0] status13,
    input  wire [31:0] status14,
    input  wire [31:0] status15,
    input  wire [31:0] status16,
    input  wire [31:0] status17,
    input  wire [31:0] status18,
    input  wire [31:0] status19,
    input  wire [31:0] status20,
    input  wire [31:0] status21
);

reg [16:0] done_latched;
reg [16:0] done_previous;
wire [16:0] done_rising = done_events & ~done_previous;
reg [7:0] awaddr_r;
reg aw_hold_r, w_hold_r;
reg [31:0] wdata_r;
reg [3:0] wstrb_r;
wire aw_accept = s_axil_awvalid && s_axil_awready;
wire w_accept  = s_axil_wvalid && s_axil_wready;
wire wr_have_aw = aw_hold_r || aw_accept;
wire wr_have_w  = w_hold_r  || w_accept;
wire wr_fire = !s_axil_bvalid && wr_have_aw && wr_have_w;
wire [7:0] wr_addr = aw_hold_r ? awaddr_r : s_axil_awaddr;
wire [31:0] wr_data = w_hold_r ? wdata_r : s_axil_wdata;
wire [3:0] wr_strb = w_hold_r ? wstrb_r : s_axil_wstrb;
wire [31:0] wr_mask = {{8{wr_strb[3]}},{8{wr_strb[2]}},
                       {8{wr_strb[1]}},{8{wr_strb[0]}}};
wire [31:0] wr_pulse = wr_data & wr_mask;

// A one-cycle completion is retained until software acknowledges it.
// Rising-edge capture also supports internal done signals held until restart.
// New events win over a simultaneous W1C. Global clear discards previous events.
always @(posedge clk) begin
    if (!rst_n)
        done_previous <= 17'd0;
    else
        done_previous <= done_events;
    if (!rst_n)
        done_latched <= 17'd0;
    else if (clear_pulse)
        done_latched <= {16'd0, done_events[0]};
    else
        done_latched <= (done_latched & ~((wr_fire && wr_addr[7:2] == 6'd45)
                          ? wr_pulse[16:0] : 17'd0)) | done_rising;
end

always @(posedge clk) begin
    if (!rst_n) begin
        s_axil_awready <= 1'b0;
        s_axil_wready <= 1'b0;
        s_axil_bresp <= 2'b00;
        s_axil_bvalid <= 1'b0;
        s_axil_arready <= 1'b0;
        s_axil_rdata <= 32'd0;
        s_axil_rresp <= 2'b00;
        s_axil_rvalid <= 1'b0;
        awaddr_r <= 8'd0;
        aw_hold_r <= 1'b0;
        w_hold_r <= 1'b0;
        wdata_r <= 32'd0;
        wstrb_r <= 4'd0;
        store_fc2_select <= 1'b0;
        clear_pulse <= 1'b0;
        load_start <= 1'b0;
        qkv_bank_start <= 1'b0;
        qkv_compute_start <= 1'b0;
        qkt_start <= 1'b0;
        softmax_start <= 1'b0;
        prob_bank_start <= 1'b0;
        av_start <= 1'b0;
        concat_start <= 1'b0;
        outproj_start <= 1'b0;
        norm2_start <= 1'b0;
        fc1_start <= 1'b0;
        gelu_start <= 1'b0;
        fc2_pad_start <= 1'b0;
        fc2_start <= 1'b0;
        norm3_start <= 1'b0;
        store_start <= 1'b0;
        load_dst <= 8'd0;
        load_axi_addr <= 32'd0;
        load_local_addr <= 18'd0;
        load_beats <= 16'd0;
        load_burst_len_m1 <= 8'd15;
        qkv_block_id <= 4'd0;
        qkv_op_id <= 4'd0;
        current_head <= 2'd0;
        softmax_x0 <= -32'sd9;
        gelu_x0 <= -32'sd6;
        prefetch_mode <= 2'd1;
        security_mode <= 2'd0;
`ifdef V780_WINDOW3072_BLOCK0
        prefetch_window_cap <= 12'd3072;
`else
        prefetch_window_cap <= 12'd1024;
`endif
        stage_budget_cap <= 12'd0;
        window_guard_words <= 12'd32;
        window_base_addr <= 32'd0;
        window_stride_words <= 16'd0;
        crypto_key_id <= 8'd0;
        prefetch_ahead_beats <= 8'd4;
        crypto_key <= 128'd0;
        crypto_nonce <= 96'd0;
    end else begin
        clear_pulse <= 1'b0;
        load_start <= 1'b0;
        qkv_bank_start <= 1'b0;
        qkv_compute_start <= 1'b0;
        qkt_start <= 1'b0;
        softmax_start <= 1'b0;
        prob_bank_start <= 1'b0;
        av_start <= 1'b0;
        concat_start <= 1'b0;
        outproj_start <= 1'b0;
        norm2_start <= 1'b0;
        fc1_start <= 1'b0;
        gelu_start <= 1'b0;
        fc2_pad_start <= 1'b0;
        fc2_start <= 1'b0;
        norm3_start <= 1'b0;
        store_start <= 1'b0;

        s_axil_awready <= !aw_hold_r && !s_axil_bvalid;
        s_axil_wready <= !w_hold_r && !s_axil_bvalid;
        s_axil_arready <= 1'b0;

        if (s_axil_bvalid && s_axil_bready)
            s_axil_bvalid <= 1'b0;
        if (s_axil_rvalid && s_axil_rready)
            s_axil_rvalid <= 1'b0;

        if (aw_accept) begin
            awaddr_r <= s_axil_awaddr;
            aw_hold_r <= 1'b1;
        end
        if (w_accept) begin
            wdata_r <= s_axil_wdata;
            wstrb_r <= s_axil_wstrb;
            w_hold_r <= 1'b1;
        end

        if (wr_fire) begin
            s_axil_bvalid <= 1'b1;
            s_axil_bresp <= 2'b00;
            aw_hold_r <= 1'b0;
            w_hold_r <= 1'b0;
            if (wr_addr[7:2] == 6'd0) begin
                clear_pulse <= wr_pulse[0]; load_start <= wr_pulse[1];
                qkv_bank_start <= wr_pulse[2]; qkv_compute_start <= wr_pulse[3];
                qkt_start <= wr_pulse[4]; softmax_start <= wr_pulse[5];
                prob_bank_start <= wr_pulse[6]; av_start <= wr_pulse[7];
                concat_start <= wr_pulse[8]; outproj_start <= wr_pulse[9];
                norm2_start <= wr_pulse[10]; fc1_start <= wr_pulse[11];
                gelu_start <= wr_pulse[12]; fc2_pad_start <= wr_pulse[13];
                fc2_start <= wr_pulse[14]; norm3_start <= wr_pulse[15];
                store_start <= wr_pulse[16];
            end else if (wr_addr[7:2] == 6'd48) begin
                if(wr_strb[0]) store_fc2_select <= wr_data[0];
            end else if (wr_addr[7:2] == 6'd1) begin
                if(wr_strb[0]) load_dst <= wr_data[7:0];
                if(wr_strb[1]) current_head <= wr_data[9:8];
            end else if (wr_addr[7:2] == 6'd2) begin
                load_axi_addr <= (load_axi_addr & ~wr_mask) | (wr_data & wr_mask);
            end else if (wr_addr[7:2] == 6'd3) begin
                load_local_addr <= (load_local_addr & ~wr_mask[17:0]) | (wr_data[17:0] & wr_mask[17:0]);
            end else if (wr_addr[7:2] == 6'd4) begin
                if(wr_strb[0]) load_beats[7:0] <= wr_data[7:0];
                if(wr_strb[1]) load_beats[15:8] <= wr_data[15:8];
                if(wr_strb[2]) load_burst_len_m1 <= wr_data[23:16];
            end else if (wr_addr[7:2] == 6'd5) begin
                if(wr_strb[0]) begin qkv_block_id <= wr_data[3:0]; qkv_op_id <= wr_data[7:4]; end
            end else if (wr_addr[7:2] == 6'd6) begin
                softmax_x0 <= (softmax_x0 & ~wr_mask) | (wr_data & wr_mask);
            end else if (wr_addr[7:2] == 6'd7) begin
                gelu_x0 <= (gelu_x0 & ~wr_mask) | (wr_data & wr_mask);
            end else if (wr_addr[7:2] == 6'd8) begin
                if(wr_strb[0]) begin prefetch_mode<=wr_data[1:0];security_mode<=wr_data[3:2];end
                if(wr_strb[1]) crypto_key_id<=wr_data[15:8];
                if(wr_strb[2]) prefetch_ahead_beats<=wr_data[23:16];
            end else if (wr_addr[7:2] == 6'd9) begin
                if(wr_strb[0]) prefetch_window_cap[7:0]<=wr_data[7:0];
                if(wr_strb[1]) prefetch_window_cap[11:8]<=wr_data[11:8];
                if(wr_strb[2]) stage_budget_cap[7:0]<=wr_data[23:16];
                if(wr_strb[3]) stage_budget_cap[11:8]<=wr_data[27:24];
            end else if (wr_addr[7:2] == 6'd10) begin
                if(wr_strb[0]) window_guard_words[7:0]<=wr_data[7:0];
                if(wr_strb[1]) window_guard_words[11:8]<=wr_data[11:8];
            end else if (wr_addr[7:2] == 6'd11) begin
                window_base_addr <= (window_base_addr & ~wr_mask) | (wr_data & wr_mask);
            end else if (wr_addr[7:2] == 6'd12) begin
                if(wr_strb[0]) window_stride_words[7:0]<=wr_data[7:0];
                if(wr_strb[1]) window_stride_words[15:8]<=wr_data[15:8];
            end else if (wr_addr[7:2] == 6'd38) begin
                crypto_key[127:96] <= (crypto_key[127:96]&~wr_mask)|(wr_data&wr_mask);
            end else if (wr_addr[7:2] == 6'd39) begin
                crypto_key[95:64] <= (crypto_key[95:64]&~wr_mask)|(wr_data&wr_mask);
            end else if (wr_addr[7:2] == 6'd40) begin
                crypto_key[63:32] <= (crypto_key[63:32]&~wr_mask)|(wr_data&wr_mask);
            end else if (wr_addr[7:2] == 6'd41) begin
                crypto_key[31:0] <= (crypto_key[31:0]&~wr_mask)|(wr_data&wr_mask);
            end else if (wr_addr[7:2] == 6'd42) begin
                crypto_nonce[95:64] <= (crypto_nonce[95:64]&~wr_mask)|(wr_data&wr_mask);
            end else if (wr_addr[7:2] == 6'd43) begin
                crypto_nonce[63:32] <= (crypto_nonce[63:32]&~wr_mask)|(wr_data&wr_mask);
            end else if (wr_addr[7:2] == 6'd44) begin
                crypto_nonce[31:0] <= (crypto_nonce[31:0]&~wr_mask)|(wr_data&wr_mask);
            end
        end

        if (!s_axil_rvalid && s_axil_arvalid) begin
            s_axil_arready <= 1'b1;
            s_axil_rvalid <= 1'b1;
            s_axil_rresp <= 2'b00;
            if (s_axil_araddr[7:2] == 6'd0)
                s_axil_rdata <= {15'd0, store_start, norm3_start, fc2_start, fc2_pad_start, gelu_start, fc1_start, norm2_start, outproj_start, concat_start, av_start, prob_bank_start, softmax_start, qkt_start, qkv_compute_start, qkv_bank_start, load_start, clear_pulse};
            else if (s_axil_araddr[7:2] == 6'd1)
                s_axil_rdata <= {22'd0, current_head, load_dst};
            else if (s_axil_araddr[7:2] == 6'd2)
                s_axil_rdata <= load_axi_addr;
            else if (s_axil_araddr[7:2] == 6'd3)
                s_axil_rdata <= {14'd0, load_local_addr};
            else if (s_axil_araddr[7:2] == 6'd4)
                s_axil_rdata <= {8'd0, load_burst_len_m1, load_beats};
            else if (s_axil_araddr[7:2] == 6'd5)
                s_axil_rdata <= {24'd0, qkv_op_id, qkv_block_id};
            else if (s_axil_araddr[7:2] == 6'd6)
                s_axil_rdata <= softmax_x0;
            else if (s_axil_araddr[7:2] == 6'd7)
                s_axil_rdata <= gelu_x0;
            else if (s_axil_araddr[7:2] == 6'd8)
                s_axil_rdata <= {4'd0, prefetch_ahead_beats, crypto_key_id, 8'd0, security_mode, prefetch_mode};
            else if (s_axil_araddr[7:2] == 6'd9)
                s_axil_rdata <= {8'd0, stage_budget_cap, prefetch_window_cap};
            else if (s_axil_araddr[7:2] == 6'd10)
                s_axil_rdata <= {20'd0, window_guard_words};
            else if (s_axil_araddr[7:2] == 6'd11)
                s_axil_rdata <= window_base_addr;
            else if (s_axil_araddr[7:2] == 6'd12)
                s_axil_rdata <= {16'd0, window_stride_words};
            else if (s_axil_araddr[7:2] == 6'd16)
                s_axil_rdata <= status0;
            else if (s_axil_araddr[7:2] == 6'd17)
                s_axil_rdata <= status1;
            else if (s_axil_araddr[7:2] == 6'd18)
                s_axil_rdata <= status2;
            else if (s_axil_araddr[7:2] == 6'd19)
                s_axil_rdata <= status3;
            else if (s_axil_araddr[7:2] == 6'd20)
                s_axil_rdata <= status4;
            else if (s_axil_araddr[7:2] == 6'd21)
                s_axil_rdata <= status5;
            else if (s_axil_araddr[7:2] == 6'd22)
                s_axil_rdata <= status6;
            else if (s_axil_araddr[7:2] == 6'd23)
                s_axil_rdata <= status7;
            else if (s_axil_araddr[7:2] == 6'd24)
                s_axil_rdata <= status8;
            else if (s_axil_araddr[7:2] == 6'd25)
                s_axil_rdata <= status9;
            else if (s_axil_araddr[7:2] == 6'd26)
                s_axil_rdata <= status10;
            else if (s_axil_araddr[7:2] == 6'd27)
                s_axil_rdata <= status11;
            else if (s_axil_araddr[7:2] == 6'd28)
                s_axil_rdata <= status12;
            else if (s_axil_araddr[7:2] == 6'd29)
                s_axil_rdata <= status13;
            else if (s_axil_araddr[7:2] == 6'd30)
                s_axil_rdata <= status14;
            else if (s_axil_araddr[7:2] == 6'd31)
                s_axil_rdata <= status15;
            else if (s_axil_araddr[7:2] == 6'd32)
                s_axil_rdata <= status16;
            else if (s_axil_araddr[7:2] == 6'd33)
                s_axil_rdata <= status17;
            else if (s_axil_araddr[7:2] == 6'd34)
                s_axil_rdata <= status18;
            else if (s_axil_araddr[7:2] == 6'd35)
                s_axil_rdata <= status19;
            else if (s_axil_araddr[7:2] == 6'd36)
                s_axil_rdata <= status20;
            else if (s_axil_araddr[7:2] == 6'd37)
                s_axil_rdata <= status21;
            else if (s_axil_araddr[7:2] == 6'd38)
                s_axil_rdata <= 32'd0;
            else if (s_axil_araddr[7:2] == 6'd39)
                s_axil_rdata <= 32'd0;
            else if (s_axil_araddr[7:2] == 6'd40)
                s_axil_rdata <= 32'd0;
            else if (s_axil_araddr[7:2] == 6'd41)
                s_axil_rdata <= 32'd0;
            else if (s_axil_araddr[7:2] == 6'd42)
                s_axil_rdata <= crypto_nonce[95:64];
            else if (s_axil_araddr[7:2] == 6'd43)
                s_axil_rdata <= crypto_nonce[63:32];
            else if (s_axil_araddr[7:2] == 6'd44)
                s_axil_rdata <= crypto_nonce[31:0];
            else if (s_axil_araddr[7:2] == 6'd45)
                s_axil_rdata <= {15'd0, done_latched};
            else if (s_axil_araddr[7:2] == 6'd46)
                s_axil_rdata <= {30'd0, load_ready};
            else if (s_axil_araddr[7:2] == 6'd47)
                s_axil_rdata <= 32'h4E50_5531;
            else if (s_axil_araddr[7:2] == 6'd48)
                s_axil_rdata <= {31'd0,store_fc2_select};
            else if (s_axil_araddr[7:2] == 6'd49)
                s_axil_rdata <= capture_drops;
            else if (s_axil_araddr[7:2] == 6'd50)
                s_axil_rdata <= 32'h43484E31; // CHN1 capability
            else if (s_axil_araddr[7:2] == 6'd51)
                s_axil_rdata <= 32'h44424732; // DBG2
            else if (s_axil_araddr[7:2] == 6'd52)
                s_axil_rdata <= debug_first_aw;
            else if (s_axil_araddr[7:2] == 6'd53)
                s_axil_rdata <= debug_last_aw;
            else if (s_axil_araddr[7:2] == 6'd54)
                s_axil_rdata <= debug_first_wdata;
            else if (s_axil_araddr[7:2] == 6'd55)
                s_axil_rdata <= debug_first_wstrb;
            else if (s_axil_araddr[7:2] == 6'd56)
                s_axil_rdata <= debug_aw_count;
            else if (s_axil_araddr[7:2] == 6'd57)
                s_axil_rdata <= debug_b_count;
            else if (s_axil_araddr[7:2] == 6'd58)
                s_axil_rdata <= debug_last_bresp;
            else
                s_axil_rdata <= 32'd0;
        end
    end
end

endmodule
