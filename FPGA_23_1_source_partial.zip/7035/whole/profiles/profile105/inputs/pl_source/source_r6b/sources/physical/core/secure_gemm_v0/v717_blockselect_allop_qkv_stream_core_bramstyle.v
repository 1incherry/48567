`timescale 1ns/1ps

module v717_blockselect_allop_qkv_stream_core_bramstyle (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,
    input  wire         start,
    input  wire [3:0]   block_id,
    input  wire [3:0]   op_id,
    input  wire         a_wr_valid,
    input  wire [3:0]   a_wr_block_id,
    input  wire [11:0]  a_wr_addr,
    input  wire [255:0] a_wr_data,
    input  wire         b_wr_valid,
    input  wire [3:0]   b_wr_block_id,
    input  wire [3:0]   b_wr_op_id,
    input  wire [9:0]   b_wr_addr,
    input  wire [255:0] b_wr_data,
    input  wire         scale_wr_valid,
    input  wire [7:0]   scale_wr_beat_addr,
    input  wire [255:0] scale_wr_data,
    output reg          out_valid,
    input  wire         out_ready,
    output reg [1:0]    out_kind,
    output reg [15:0]   out_addr,
    output reg signed [7:0] out_data,
    output reg          busy,
    output reg          done,
    output reg [31:0]   stat_cycles,
    output reg [31:0]   stat_tiles,
    output reg [31:0]   stat_bank_reads,
    output reg [31:0]   stat_quant_items,
    output reg [31:0]   stat_quant_checksum,
    output reg [31:0]   stat_stream_stall_cycles,
    output reg [31:0]   stat_bank_errors,
    output reg [31:0]   stat_unsupported_errors,
    output reg [3:0]    stat_stage
);

localparam SEQ = 200;
localparam IN_DIM = 196;
localparam OUT_DIM = 64;
localparam TILE = 4;
localparam OUT_SIZE = SEQ * OUT_DIM;
localparam A_K_TILES = IN_DIM / TILE;
localparam B_N_TILES = OUT_DIM / TILE;
localparam ACC_BANK_DEPTH = (SEQ / TILE) * (OUT_DIM / TILE);

localparam ST_IDLE       = 4'd0;
localparam ST_ACC_RD     = 4'd1;
localparam ST_BANK_REQ   = 4'd2;
localparam ST_BANK_WAIT  = 4'd3;
localparam ST_FIRE       = 4'd4;
localparam ST_WAIT_PE    = 4'd5;
localparam ST_ACC        = 4'd6;
localparam ST_NEXT       = 4'd7;
localparam ST_QUANT_RD   = 4'd8;
localparam ST_QUANT_CALC = 4'd9;
localparam ST_QUANT_SEND = 4'd10;
localparam ST_DONE       = 4'd11;
localparam ST_ACC_WAIT   = 4'd12;
localparam ST_QUANT_WAIT = 4'd13;
localparam ST_QUANT_MUL  = 4'd14;
localparam ST_QUANT_PACK = 4'd15;

reg [3:0] active_block;
reg [3:0] active_op;
reg [10:0] active_scale_base;
reg [7:0] rt;
reg [6:0] ct;
reg [8:0] kt;
reg [13:0] idx;
reg pe_in_valid;
reg [255:0] pe_a_flat;
reg [255:0] pe_b_flat;
reg bank_req_valid;
reg [11:0] bank_a_addr;
reg [9:0] bank_b_addr;
reg acc_bank_rd_en;
reg acc_bank_wr_en;
reg [9:0] acc_bank_addr;
reg [511:0] acc_bank_wr_data;
wire [511:0] acc_bank_rd_data;
wire signed [31:0] acc_bank_lane0  = acc_bank_rd_data[511 - 0*32 -: 32];
wire signed [31:0] acc_bank_lane1  = acc_bank_rd_data[511 - 1*32 -: 32];
wire signed [31:0] acc_bank_lane2  = acc_bank_rd_data[511 - 2*32 -: 32];
wire signed [31:0] acc_bank_lane3  = acc_bank_rd_data[511 - 3*32 -: 32];
wire signed [31:0] acc_bank_lane4  = acc_bank_rd_data[511 - 4*32 -: 32];
wire signed [31:0] acc_bank_lane5  = acc_bank_rd_data[511 - 5*32 -: 32];
wire signed [31:0] acc_bank_lane6  = acc_bank_rd_data[511 - 6*32 -: 32];
wire signed [31:0] acc_bank_lane7  = acc_bank_rd_data[511 - 7*32 -: 32];
wire signed [31:0] acc_bank_lane8  = acc_bank_rd_data[511 - 8*32 -: 32];
wire signed [31:0] acc_bank_lane9  = acc_bank_rd_data[511 - 9*32 -: 32];
wire signed [31:0] acc_bank_lane10 = acc_bank_rd_data[511 - 10*32 -: 32];
wire signed [31:0] acc_bank_lane11 = acc_bank_rd_data[511 - 11*32 -: 32];
wire signed [31:0] acc_bank_lane12 = acc_bank_rd_data[511 - 12*32 -: 32];
wire signed [31:0] acc_bank_lane13 = acc_bank_rd_data[511 - 13*32 -: 32];
wire signed [31:0] acc_bank_lane14 = acc_bank_rd_data[511 - 14*32 -: 32];
wire signed [31:0] acc_bank_lane15 = acc_bank_rd_data[511 - 15*32 -: 32];
reg signed [31:0] quant_acc_data;
reg signed [31:0] quant_scale_data;
reg signed [63:0] quant_product_r;
reg signed [31:0] acc_lane0;
reg signed [31:0] acc_lane1;
reg signed [31:0] acc_lane2;
reg signed [31:0] acc_lane3;
reg signed [31:0] acc_lane4;
reg signed [31:0] acc_lane5;
reg signed [31:0] acc_lane6;
reg signed [31:0] acc_lane7;
reg signed [31:0] acc_lane8;
reg signed [31:0] acc_lane9;
reg signed [31:0] acc_lane10;
reg signed [31:0] acc_lane11;
reg signed [31:0] acc_lane12;
reg signed [31:0] acc_lane13;
reg signed [31:0] acc_lane14;
reg signed [31:0] acc_lane15;

wire bank_req_ready;
wire bank_resp_valid;
wire [255:0] bank_a_data;
wire [255:0] bank_b_data;
wire bank_resp_error;
wire bank_wr_error;
wire [31:0] bank_stat_reads;
wire [31:0] bank_stat_errors;
wire [31:0] bank_stat_a_writes;
wire [31:0] bank_stat_b_writes;

wire pe_in_ready;
wire pe_out_valid;
wire [511:0] pe_c_flat;
wire [31:0] pe_stat_tiles;

wire signed [31:0] scale_rd_data;
wire scale_wr_error;
wire [31:0] scale_stat_writes;
wire [31:0] scale_stat_errors;

wire request_supported = (block_id <= 4'd11) && (op_id <= 4'd8);
wire [4:0] request_entry = {1'b0, op_id};
wire [10:0] request_scale_base = {request_entry, 6'd0};
wire [10:0] scale_rd_addr = active_scale_base + idx[5:0];
wire [9:0] acc_wr_addr = {rt[7:2], ct[5:2]};
wire [3:0] quant_bank_sel = {idx[7:6], idx[1:0]};
wire [9:0] quant_bank_addr = {idx[13:8], idx[5:2]};
wire signed [31:0] quant_acc_selected =
    (quant_bank_sel == 4'd0)  ? acc_bank_lane0  :
    (quant_bank_sel == 4'd1)  ? acc_bank_lane1  :
    (quant_bank_sel == 4'd2)  ? acc_bank_lane2  :
    (quant_bank_sel == 4'd3)  ? acc_bank_lane3  :
    (quant_bank_sel == 4'd4)  ? acc_bank_lane4  :
    (quant_bank_sel == 4'd5)  ? acc_bank_lane5  :
    (quant_bank_sel == 4'd6)  ? acc_bank_lane6  :
    (quant_bank_sel == 4'd7)  ? acc_bank_lane7  :
    (quant_bank_sel == 4'd8)  ? acc_bank_lane8  :
    (quant_bank_sel == 4'd9)  ? acc_bank_lane9  :
    (quant_bank_sel == 4'd10) ? acc_bank_lane10 :
    (quant_bank_sel == 4'd11) ? acc_bank_lane11 :
    (quant_bank_sel == 4'd12) ? acc_bank_lane12 :
    (quant_bank_sel == 4'd13) ? acc_bank_lane13 :
    (quant_bank_sel == 4'd14) ? acc_bank_lane14 :
                                acc_bank_lane15;
wire signed [7:0] quant_r_next =
    (quant_product_r > 64'sd127)  ? 8'sh7f :
    (quant_product_r < -64'sd128) ? -8'sd128 :
                                   quant_product_r[7:0];

wire [1:0] active_out_kind =
    ((active_op == 4'd0) || (active_op == 4'd3) || (active_op == 4'd6)) ? 2'd0 :
    ((active_op == 4'd1) || (active_op == 4'd4) || (active_op == 4'd7)) ? 2'd1 :
                                                                           2'd2;

v718_acc16_lane_bram32_sync #(
    .ADDR_W(10),
    .DEPTH(ACC_BANK_DEPTH)
) u_acc_bank (
    .clk(clk),
    .wr_en(acc_bank_wr_en),
    .wr_addr(acc_bank_addr),
    .wr_data(acc_bank_wr_data),
    .rd_en(acc_bank_rd_en),
    .rd_addr(acc_bank_addr),
    .rd_data(acc_bank_rd_data)
);

v714_blockselect_qkv_tile_bank_bramstyle u_bank (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .a_wr_valid(a_wr_valid),
    .a_wr_block_id(a_wr_block_id),
    .a_wr_addr(a_wr_addr),
    .a_wr_data(a_wr_data),
    .b_wr_valid(b_wr_valid),
    .b_wr_block_id(b_wr_block_id),
    .b_wr_op_id(b_wr_op_id),
    .b_wr_addr(b_wr_addr),
    .b_wr_data(b_wr_data),
    .req_valid(bank_req_valid),
    .req_ready(bank_req_ready),
    .block_id(active_block),
    .op_id(active_op),
    .a_addr(bank_a_addr),
    .b_addr(bank_b_addr),
    .resp_valid(bank_resp_valid),
    .resp_ready(1'b1),
    .a_data(bank_a_data),
    .b_data(bank_b_data),
    .resp_error(bank_resp_error),
    .wr_error(bank_wr_error),
    .stat_reads(bank_stat_reads),
    .stat_a_writes(bank_stat_a_writes),
    .stat_b_writes(bank_stat_b_writes),
    .stat_errors(bank_stat_errors)
);

v714_qkv_scale_buffer_bramstyle u_scale (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .wr_valid(scale_wr_valid),
    .wr_beat_addr(scale_wr_beat_addr),
    .wr_data(scale_wr_data),
    .wr_error(scale_wr_error),
    .stat_writes(scale_stat_writes),
    .stat_errors(scale_stat_errors),
    .rd_addr(scale_rd_addr),
    .rd_data(scale_rd_data)
);

v285_pe4x4_int16_tile_core #(.PIPELINED_ARITHMETIC(1)) u_pe (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .in_valid(pe_in_valid),
    .in_ready(pe_in_ready),
    .a_flat(pe_a_flat),
    .b_flat(pe_b_flat),
    .out_valid(pe_out_valid),
    .out_ready(1'b1),
    .c_flat(pe_c_flat),
    .stat_tiles(pe_stat_tiles)
);

always @(posedge clk) begin
    if (!rst_n) begin
        busy <= 1'b0;
        done <= 1'b0;
        out_valid <= 1'b0;
        out_kind <= 2'd0;
        out_addr <= 16'd0;
        out_data <= 8'sd0;
        stat_cycles <= 32'd0;
        stat_tiles <= 32'd0;
        stat_bank_reads <= 32'd0;
        stat_quant_items <= 32'd0;
        stat_quant_checksum <= 32'd0;
        stat_stream_stall_cycles <= 32'd0;
        stat_bank_errors <= 32'd0;
        stat_unsupported_errors <= 32'd0;
        stat_stage <= ST_IDLE;
        active_block <= 4'd0;
        active_op <= 4'd0;
        active_scale_base <= 11'd0;
        rt <= 8'd0;
        ct <= 7'd0;
        kt <= 9'd0;
        idx <= 14'd0;
        pe_in_valid <= 1'b0;
        pe_a_flat <= 256'd0;
        pe_b_flat <= 256'd0;
        bank_req_valid <= 1'b0;
        bank_a_addr <= 12'd0;
        bank_b_addr <= 10'd0;
        acc_bank_rd_en <= 1'b0;
        acc_bank_wr_en <= 1'b0;
        acc_bank_addr <= 10'd0;
        acc_bank_wr_data <= 512'd0;
        quant_acc_data <= 32'sd0;
        quant_scale_data <= 32'sd0;
        quant_product_r <= 64'sd0;
        acc_lane0 <= 32'sd0;
        acc_lane1 <= 32'sd0;
        acc_lane2 <= 32'sd0;
        acc_lane3 <= 32'sd0;
        acc_lane4 <= 32'sd0;
        acc_lane5 <= 32'sd0;
        acc_lane6 <= 32'sd0;
        acc_lane7 <= 32'sd0;
        acc_lane8 <= 32'sd0;
        acc_lane9 <= 32'sd0;
        acc_lane10 <= 32'sd0;
        acc_lane11 <= 32'sd0;
        acc_lane12 <= 32'sd0;
        acc_lane13 <= 32'sd0;
        acc_lane14 <= 32'sd0;
        acc_lane15 <= 32'sd0;
    end else begin
        done <= 1'b0;
        pe_in_valid <= 1'b0;
        acc_bank_rd_en <= 1'b0;
        acc_bank_wr_en <= 1'b0;

        if (out_valid && out_ready)
            out_valid <= 1'b0;

        if (busy)
            stat_cycles <= stat_cycles + 1'b1;

        if (clear) begin
            busy <= 1'b0;
            done <= 1'b0;
            out_valid <= 1'b0;
            stat_cycles <= 32'd0;
            stat_tiles <= 32'd0;
            stat_bank_reads <= 32'd0;
            stat_quant_items <= 32'd0;
            stat_quant_checksum <= 32'd0;
            stat_stream_stall_cycles <= 32'd0;
            stat_bank_errors <= 32'd0;
            stat_unsupported_errors <= 32'd0;
            stat_stage <= ST_IDLE;
            bank_req_valid <= 1'b0;
        end else begin
            case (stat_stage)
                ST_IDLE: begin
                    busy <= 1'b0;
                    bank_req_valid <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        active_block <= block_id;
                        active_op <= op_id;
                        active_scale_base <= request_scale_base;
                        rt <= 8'd0;
                        ct <= 7'd0;
                        kt <= 9'd0;
                        idx <= 14'd0;
                        stat_cycles <= 32'd0;
                        stat_tiles <= 32'd0;
                        stat_bank_reads <= 32'd0;
                        stat_quant_items <= 32'd0;
                        stat_quant_checksum <= 32'd0;
                        stat_stream_stall_cycles <= 32'd0;
                        stat_bank_errors <= 32'd0;
                        stat_unsupported_errors <= 32'd0;
                        if (request_supported)
                            stat_stage <= ST_BANK_REQ;
                        else begin
                            stat_unsupported_errors <= 32'd1;
                            stat_stage <= ST_DONE;
                        end
                    end
                end

                ST_BANK_REQ: begin
                    bank_a_addr <= (rt[7:2] * A_K_TILES[11:0]) + kt[8:2];
                    bank_b_addr <= (kt[8:2] * B_N_TILES[9:0]) + ct[6:2];
                    bank_req_valid <= 1'b1;
                    if (bank_req_ready) begin
                        stat_bank_reads <= stat_bank_reads + 1'b1;
                        stat_stage <= ST_BANK_WAIT;
                    end
                end

                ST_BANK_WAIT: begin
                    bank_req_valid <= 1'b0;
                    if (bank_resp_valid) begin
                        pe_a_flat <= bank_a_data;
                        pe_b_flat <= bank_b_data;
                        if (bank_resp_error)
                            stat_bank_errors <= stat_bank_errors + 1'b1;
                        stat_stage <= ST_FIRE;
                    end
                end

                ST_FIRE: begin
                    if (pe_in_ready) begin
                        pe_in_valid <= 1'b1;
                        stat_stage <= ST_WAIT_PE;
                    end
                end

                ST_WAIT_PE: begin
                    if (pe_out_valid)
                        stat_stage <= ST_ACC_RD;
                end

                ST_ACC_RD: begin
                    if (kt == 9'd0) begin
                        acc_lane0 <= 32'sd0;
                        acc_lane1 <= 32'sd0;
                        acc_lane2 <= 32'sd0;
                        acc_lane3 <= 32'sd0;
                        acc_lane4 <= 32'sd0;
                        acc_lane5 <= 32'sd0;
                        acc_lane6 <= 32'sd0;
                        acc_lane7 <= 32'sd0;
                        acc_lane8 <= 32'sd0;
                        acc_lane9 <= 32'sd0;
                        acc_lane10 <= 32'sd0;
                        acc_lane11 <= 32'sd0;
                        acc_lane12 <= 32'sd0;
                        acc_lane13 <= 32'sd0;
                        acc_lane14 <= 32'sd0;
                        acc_lane15 <= 32'sd0;
                        stat_stage <= ST_ACC;
                    end else begin
                        acc_bank_rd_en <= 1'b1;
                        acc_bank_addr <= acc_wr_addr;
                        stat_stage <= ST_ACC_WAIT;
                    end
                end

                ST_ACC_WAIT: begin
                    stat_stage <= ST_ACC;
                end

                ST_ACC: begin
                    acc_bank_wr_en <= 1'b1;
                    acc_bank_addr <= acc_wr_addr;
                    acc_bank_wr_data <= {
                        ((kt == 9'd0) ? acc_lane0  : acc_bank_lane0)  + pe_c_flat[511 - 0*32 -: 32],
                        ((kt == 9'd0) ? acc_lane1  : acc_bank_lane1)  + pe_c_flat[511 - 1*32 -: 32],
                        ((kt == 9'd0) ? acc_lane2  : acc_bank_lane2)  + pe_c_flat[511 - 2*32 -: 32],
                        ((kt == 9'd0) ? acc_lane3  : acc_bank_lane3)  + pe_c_flat[511 - 3*32 -: 32],
                        ((kt == 9'd0) ? acc_lane4  : acc_bank_lane4)  + pe_c_flat[511 - 4*32 -: 32],
                        ((kt == 9'd0) ? acc_lane5  : acc_bank_lane5)  + pe_c_flat[511 - 5*32 -: 32],
                        ((kt == 9'd0) ? acc_lane6  : acc_bank_lane6)  + pe_c_flat[511 - 6*32 -: 32],
                        ((kt == 9'd0) ? acc_lane7  : acc_bank_lane7)  + pe_c_flat[511 - 7*32 -: 32],
                        ((kt == 9'd0) ? acc_lane8  : acc_bank_lane8)  + pe_c_flat[511 - 8*32 -: 32],
                        ((kt == 9'd0) ? acc_lane9  : acc_bank_lane9)  + pe_c_flat[511 - 9*32 -: 32],
                        ((kt == 9'd0) ? acc_lane10 : acc_bank_lane10) + pe_c_flat[511 - 10*32 -: 32],
                        ((kt == 9'd0) ? acc_lane11 : acc_bank_lane11) + pe_c_flat[511 - 11*32 -: 32],
                        ((kt == 9'd0) ? acc_lane12 : acc_bank_lane12) + pe_c_flat[511 - 12*32 -: 32],
                        ((kt == 9'd0) ? acc_lane13 : acc_bank_lane13) + pe_c_flat[511 - 13*32 -: 32],
                        ((kt == 9'd0) ? acc_lane14 : acc_bank_lane14) + pe_c_flat[511 - 14*32 -: 32],
                        ((kt == 9'd0) ? acc_lane15 : acc_bank_lane15) + pe_c_flat[511 - 15*32 -: 32]
                    };
                    stat_tiles <= stat_tiles + 1'b1;
                    stat_stage <= ST_NEXT;
                end

                ST_NEXT: begin
                    if (kt < IN_DIM - TILE) begin
                        kt <= kt + 9'd4;
                        stat_stage <= ST_BANK_REQ;
                    end else begin
                        kt <= 9'd0;
                        if (ct < OUT_DIM - TILE) begin
                            ct <= ct + 7'd4;
                            stat_stage <= ST_BANK_REQ;
                        end else begin
                            ct <= 7'd0;
                            if (rt < SEQ - TILE) begin
                                rt <= rt + 8'd4;
                                stat_stage <= ST_BANK_REQ;
                            end else begin
                                idx <= 14'd0;
                                stat_stage <= ST_QUANT_RD;
                            end
                        end
                    end
                end

                ST_QUANT_RD: begin
                    acc_bank_rd_en <= 1'b1;
                    acc_bank_addr <= quant_bank_addr;
                    stat_stage <= ST_QUANT_WAIT;
                end

                ST_QUANT_WAIT: begin
                    stat_stage <= ST_QUANT_CALC;
                end

                ST_QUANT_CALC: begin
                    // Capture both BRAM/LUT-selected operands.  This removes
                    // BRAM -> lane mux -> two DSP48s -> clamp from one cycle.
                    quant_acc_data <= quant_acc_selected;
                    quant_scale_data <= scale_rd_data;
                    stat_stage <= ST_QUANT_MUL;
                end

                ST_QUANT_MUL: begin
                    quant_product_r <= (quant_acc_data * quant_scale_data) >>> 29;
                    stat_stage <= ST_QUANT_PACK;
                end

                ST_QUANT_PACK: begin
                    out_valid <= 1'b1;
                    out_kind <= active_out_kind;
                    out_addr <= {2'd0, idx};
                    out_data <= quant_r_next;
                    stat_quant_checksum <= {stat_quant_checksum[30:0], stat_quant_checksum[31]} ^
                                           {24'd0, quant_r_next};
                    stat_stage <= ST_QUANT_SEND;
                end

                ST_QUANT_SEND: begin
                    if (out_valid && out_ready) begin
                        stat_quant_items <= stat_quant_items + 1'b1;
                        if (idx == OUT_SIZE[13:0] - 1'b1)
                            stat_stage <= ST_DONE;
                        else begin
                            idx <= idx + 1'b1;
                            stat_stage <= ST_QUANT_RD;
                        end
                    end else begin
                        stat_stream_stall_cycles <= stat_stream_stall_cycles + 1'b1;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    bank_req_valid <= 1'b0;
                    stat_stage <= ST_IDLE;
                end

                default: begin
                    stat_stage <= ST_IDLE;
                    busy <= 1'b0;
                    bank_req_valid <= 1'b0;
                end
            endcase
        end
    end
end

endmodule
