`timescale 1ns/1ps

module v719_tile16_lane_bram16_sync #(
    parameter ADDR_W = 12,
    parameter DEPTH  = 2500,
    parameter FIT_MAX_DEPTH = 2048
) (
    input  wire              clk,
    input  wire [15:0]       wr_lane_en,
    input  wire [ADDR_W-1:0] wr_addr,
    input  wire [255:0]      wr_data,
    input  wire              rd_en,
    input  wire [ADDR_W-1:0] rd_addr,
    output wire [255:0]      rd_data
);

wire [15:0] rd0;
wire [15:0] rd1;
wire [15:0] rd2;
wire [15:0] rd3;
wire [15:0] rd4;
wire [15:0] rd5;
wire [15:0] rd6;
wire [15:0] rd7;
wire [15:0] rd8;
wire [15:0] rd9;
wire [15:0] rd10;
wire [15:0] rd11;
wire [15:0] rd12;
wire [15:0] rd13;
wire [15:0] rd14;
wire [15:0] rd15;

v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank0  (.clk(clk), .wr_en(wr_lane_en[0]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 0*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd0));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank1  (.clk(clk), .wr_en(wr_lane_en[1]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 1*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd1));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank2  (.clk(clk), .wr_en(wr_lane_en[2]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 2*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd2));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank3  (.clk(clk), .wr_en(wr_lane_en[3]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 3*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd3));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank4  (.clk(clk), .wr_en(wr_lane_en[4]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 4*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd4));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank5  (.clk(clk), .wr_en(wr_lane_en[5]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 5*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd5));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank6  (.clk(clk), .wr_en(wr_lane_en[6]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 6*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd6));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank7  (.clk(clk), .wr_en(wr_lane_en[7]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 7*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd7));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank8  (.clk(clk), .wr_en(wr_lane_en[8]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 8*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd8));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank9  (.clk(clk), .wr_en(wr_lane_en[9]),  .wr_addr(wr_addr), .wr_data(wr_data[255 - 9*16 -: 16]),  .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd9));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank10 (.clk(clk), .wr_en(wr_lane_en[10]), .wr_addr(wr_addr), .wr_data(wr_data[255 - 10*16 -: 16]), .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd10));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank11 (.clk(clk), .wr_en(wr_lane_en[11]), .wr_addr(wr_addr), .wr_data(wr_data[255 - 11*16 -: 16]), .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd11));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank12 (.clk(clk), .wr_en(wr_lane_en[12]), .wr_addr(wr_addr), .wr_data(wr_data[255 - 12*16 -: 16]), .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd12));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank13 (.clk(clk), .wr_en(wr_lane_en[13]), .wr_addr(wr_addr), .wr_data(wr_data[255 - 13*16 -: 16]), .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd13));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank14 (.clk(clk), .wr_en(wr_lane_en[14]), .wr_addr(wr_addr), .wr_data(wr_data[255 - 14*16 -: 16]), .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd14));
v714_bram_sdp_sync #(.DATA_W(16), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(FIT_MAX_DEPTH)) u_bank15 (.clk(clk), .wr_en(wr_lane_en[15]), .wr_addr(wr_addr), .wr_data(wr_data[255 - 15*16 -: 16]), .rd_en(rd_en), .rd_addr(rd_addr), .rd_data(rd15));

assign rd_data = {
    rd0,  rd1,  rd2,  rd3,
    rd4,  rd5,  rd6,  rd7,
    rd8,  rd9,  rd10, rd11,
    rd12, rd13, rd14, rd15
};

endmodule
