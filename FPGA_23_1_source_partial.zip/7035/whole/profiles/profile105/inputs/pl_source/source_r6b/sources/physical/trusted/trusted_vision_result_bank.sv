`timescale 1ns/1ps
// Atomic private PL result register bank. No PS write/read side effect, no RAM,
// no crypto/key material; key_session_id is the trusted provider's public ID.
// All inputs on commit_* are internal trusted-controller wires. Visible output
// is zero unless current authorization, epoch and key session still match.
module trusted_vision_result_bank #(
 parameter [31:0] CAMERA_ID=32'd0,parameter integer CLASS_COUNT=105
)(
 input wire clk,security_reset_n,authorized,key_valid,cancel,trusted_clear_fault,
 input wire [31:0] authorization_epoch,input wire [127:0] key_session_id,
 input wire commit_valid,output wire commit_ready,output reg commit_pulse,output reg fault,
 input wire [31:0] commit_camera,commit_session,commit_frame,commit_epoch,
 input wire [2:0] commit_count,input wire [895:0] commit_rois,
 input wire [51:0] commit_indices,input wire [511:0] commit_results,
 output wire visible,output wire [31:0] camera_id,session_id,frame_id,epoch,
 output wire [127:0] result_key_session,
 output wire [2:0] count,output wire [895:0] rois,
 output wire [51:0] indices,output wire [511:0] results
);
reg valid;
reg [31:0] stored_camera,stored_session,stored_frame,stored_epoch;
reg [127:0] stored_key_session;
reg [2:0] stored_count;reg [895:0] stored_rois;reg [51:0] stored_indices;reg [511:0] stored_results;
wire trusted_now=authorized&&key_valid&&!cancel&&key_session_id!=0;
reg payload_ok;integer i,j;reg [223:0] roi;reg [127:0] result_word;reg [31:0] previous_generation;
always @*begin
 payload_ok=commit_camera==CAMERA_ID&&commit_session!=0&&commit_frame!=0&&commit_epoch==authorization_epoch&&commit_count<=4;
 roi=0;result_word=0;previous_generation=0;
 for(i=0;i<4;i=i+1)if(i<commit_count)begin
  roi=commit_rois[i*224+:224];result_word=commit_results[i*128+:128];
  if(roi[175:160]>=roi[191:176]||roi[207:192]>=roi[223:208]||roi[191:176]>1920||roi[223:208]>1080||commit_indices[i*13+:13]>=6300)payload_ok=0;
  if(result_word[127:96]==0||result_word[127:96]<=previous_generation||result_word[95:88]>=CLASS_COUNT||result_word[87:64]!=0)payload_ok=0;
  previous_generation=result_word[127:96];
  for(j=0;j<i;j=j+1)if(commit_indices[i*13+:13]==commit_indices[j*13+:13])payload_ok=0;
 end
end
assign commit_ready=security_reset_n&&trusted_now&&!fault&&payload_ok;
assign visible=security_reset_n&&valid&&!fault&&trusted_now&&authorization_epoch==stored_epoch&&key_session_id==stored_key_session;
assign camera_id=visible?stored_camera:32'd0;assign session_id=visible?stored_session:32'd0;assign frame_id=visible?stored_frame:32'd0;assign epoch=visible?stored_epoch:32'd0;
assign result_key_session=visible?stored_key_session:128'd0;
assign count=visible?stored_count:3'd0;assign rois=visible?stored_rois:896'd0;assign indices=visible?stored_indices:52'd0;assign results=visible?stored_results:512'd0;
always @(posedge clk)begin
 if(!security_reset_n)begin
  valid<=0;fault<=0;commit_pulse<=0;stored_camera<=0;stored_session<=0;stored_frame<=0;stored_epoch<=0;stored_key_session<=0;stored_count<=0;stored_rois<=0;stored_indices<=0;stored_results<=0;
 end else begin
  commit_pulse<=0;
  if(trusted_clear_fault)fault<=0;
  if(!trusted_now||valid&&(authorization_epoch!=stored_epoch||key_session_id!=stored_key_session))valid<=0;
  if(commit_valid&&trusted_now&&!payload_ok)fault<=1;
  if(commit_valid&&commit_ready)begin
   valid<=1;commit_pulse<=1;stored_camera<=commit_camera;stored_session<=commit_session;stored_frame<=commit_frame;stored_epoch<=commit_epoch;stored_key_session<=key_session_id;stored_count<=commit_count;
   for(integer k=0;k<4;k=k+1)begin
    stored_rois[k*224+:224]<=k<commit_count?commit_rois[k*224+:224]:224'd0;
    stored_indices[k*13+:13]<=k<commit_count?commit_indices[k*13+:13]:13'd0;
    stored_results[k*128+:128]<=k<commit_count?commit_results[k*128+:128]:128'd0;
   end
  end
 end
end
endmodule
