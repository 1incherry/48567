`timescale 1ns/1ps

// V787 experiment: keep the large FC1 B weight bank in distributed RAM so
// XC7Z035 BRAM can be reserved for tensors that cannot be streamed.  The
// interface and synchronous read timing match the V783 compact BRAM bank.
module v787_dist_sdp_sync #(
    parameter DATA_W = 8,
    parameter ADDR_W = 14,
    parameter DEPTH = 9408
) (
    input  wire                  clk,
    input  wire                  wr_en,
    input  wire [ADDR_W-1:0]     wr_addr,
    input  wire [DATA_W-1:0]     wr_data,
    input  wire                  rd_en,
    input  wire [ADDR_W-1:0]     rd_addr,
    output reg  [DATA_W-1:0]     rd_data
);

(* ram_style = "distributed" *) reg [DATA_W-1:0] mem [0:DEPTH-1];

always @(posedge clk) begin
    if (wr_en)
        mem[wr_addr] <= wr_data;
    if (rd_en)
        rd_data <= mem[rd_addr];
end

endmodule

module v787_lane16_i8_special_multiaddr_dist_sync #(
    parameter ADDR_W = 14,
    parameter DEPTH = 9408,
    parameter SPECIAL_TILE_BASE = 9216,
    parameter SPECIAL_DEPTH = 192
) (
    input  wire                    clk,
    input  wire [15:0]             wr_lane_en,
    input  wire [ADDR_W-1:0]       wr_addr,
    input  wire signed [15:0]      wr_data,
    input  wire                    rd_en,
    input  wire [16*ADDR_W-1:0]    rd_addr_flat,
    output wire [255:0]            rd_data
);

genvar lane;
generate
    for (lane = 0; lane < 16; lane = lane + 1) begin : g_lane
        wire [ADDR_W-1:0] lane_rd_addr =
            rd_addr_flat[16*ADDR_W - lane*ADDR_W - 1 -: ADDR_W];
        wire [7:0] lane_low8;

        v787_dist_sdp_sync #(
            .DATA_W(8), .ADDR_W(ADDR_W), .DEPTH(DEPTH)
        ) u_low_i8 (
            .clk(clk),
            .wr_en(wr_lane_en[lane]),
            .wr_addr(wr_addr),
            .wr_data(wr_data[7:0]),
            .rd_en(rd_en),
            .rd_addr(lane_rd_addr),
            .rd_data(lane_low8)
        );

        if ((lane >= 4) && (lane < 8)) begin : g_special_hi
            wire wr_special = (wr_addr >= SPECIAL_TILE_BASE) &&
                              (wr_addr < SPECIAL_TILE_BASE + SPECIAL_DEPTH);
            wire rd_special = (lane_rd_addr >= SPECIAL_TILE_BASE) &&
                              (lane_rd_addr < SPECIAL_TILE_BASE + SPECIAL_DEPTH);
            wire [ADDR_W-1:0] wr_hi_addr = wr_addr - SPECIAL_TILE_BASE;
            wire [ADDR_W-1:0] rd_hi_addr = lane_rd_addr - SPECIAL_TILE_BASE;
            wire [7:0] lane_high8;
            reg rd_special_r;

            v787_dist_sdp_sync #(
                .DATA_W(8), .ADDR_W(ADDR_W), .DEPTH(SPECIAL_DEPTH)
            ) u_high_i8 (
                .clk(clk),
                .wr_en(wr_lane_en[lane] && wr_special),
                .wr_addr(wr_hi_addr),
                .wr_data(wr_data[15:8]),
                .rd_en(rd_en && rd_special),
                .rd_addr(rd_hi_addr),
                .rd_data(lane_high8)
            );

            always @(posedge clk) begin
                if (rd_en)
                    rd_special_r <= rd_special;
            end

            assign rd_data[255 - lane*16 -: 16] = rd_special_r ?
                {lane_high8, lane_low8} : {{8{lane_low8[7]}}, lane_low8};
        end else begin : g_plain
            assign rd_data[255 - lane*16 -: 16] =
                {{8{lane_low8[7]}}, lane_low8};
        end
    end
endgenerate

endmodule

// One-cycle write latency is relocated from the parent into 256-word shards.
// Explicit local registers bound the LUTRAM write-address and data fanout.
// No new architectural write latency and no extra BRAM are introduced.
module npu_fc1_segmented_dist_bank #(
 parameter ADDR_W=14, DEPTH=9408, SPECIAL_TILE_BASE=9216, SPECIAL_DEPTH=192
)(
 input wire clk, rst_n, clear,
 input wire[15:0]wr_lane_en,
 input wire[ADDR_W-1:0]wr_addr,
 input wire signed[15:0]wr_data,
 input wire rd_en,
 input wire[16*ADDR_W-1:0]rd_addr_flat,
 output wire[255:0]rd_data
);
 localparam SHARD_WORDS=512, SHARDS=(DEPTH+511)/512;
 genvar l,s;
 generate for(l=0;l<16;l=l+1)begin:g_lane
  wire[ADDR_W-1:0]ra=rd_addr_flat[16*ADDR_W-l*ADDR_W-1 -:ADDR_W];
  reg[ADDR_W-10:0]read_shard;
  wire[15:0]q[0:SHARDS-1];
  // Explicit 8192+1216 split avoids rounding a 9408-word RAM up to 16384.
  // Architectural write latency and synchronous read latency are unchanged.
  localparam BRAM_WORDS=DEPTH;
  wire [7:0] block_q;
  if(BRAM_WORDS>0)begin:g_block_prefix
   wire [7:0] segment_q[0:1];reg segment_select;
   always @(posedge clk)if(rd_en)segment_select<=ra>=8192;
   for(genvar k=0;k<2;k=k+1)begin:g_segment
    localparam BASE=k==0?0:8192;
    localparam WORDS=k==0?8192:BRAM_WORDS-8192;
    localparam AW=k==0?13:11;
    (* ram_style="block" *) reg [7:0] mem [0:WORDS-1];
    reg local_valid;reg [AW-1:0]local_addr;reg [7:0]local_data;
    reg [7:0]read_q;
    wire [AW-1:0]read_address=ra-BASE;
    always @(posedge clk)begin
     if(!rst_n||clear)begin local_valid<=0;local_addr<=0;local_data<=0;end
     else begin local_valid<=wr_lane_en[l]&&(wr_addr>=BASE)&&(wr_addr<BASE+WORDS);local_addr<=wr_addr-BASE;local_data<=wr_data[7:0];end
     if(local_valid)mem[local_addr]<=local_data;
     if(rd_en&&ra>=BASE&&ra<BASE+WORDS)read_q<=mem[read_address];
    end
    assign segment_q[k]=read_q;
   end
   assign block_q=segment_q[segment_select];
  end else assign block_q=0;
  always @(posedge clk)if(rd_en)read_shard<=ra>>9;
  for(s=0;s<SHARDS;s=s+1)begin:g_shard
   localparam WORDS=(s==SHARDS-1)?DEPTH-s*512:512;
   localparam HAS_HI=(l>=4 && l<8 && s*512>=SPECIAL_TILE_BASE && s*512<SPECIAL_TILE_BASE+SPECIAL_DEPTH);
   localparam WIDTH=HAS_HI?16:8;
   if(s*512<BRAM_WORDS)begin:g_prefix_result
    if(HAS_HI)begin:g_special_high
     // Four 192-word high-byte tails retain exact signed16 bias data.
     // The same existing one-cycle architectural write pipeline is retained.
     (* ram_style="distributed" *)reg[7:0]mem_hi[0:WORDS-1];
     reg local_valid;reg[8:0]local_addr;reg[7:0]local_data,read_hi;
     always @(posedge clk)begin
      if(!rst_n||clear)begin local_valid<=0;local_addr<=0;local_data<=0;end
      else begin local_valid<=wr_lane_en[l]&&((wr_addr>>9)==s)&&(wr_addr<s*512+WORDS);local_addr<=wr_addr[8:0];local_data<=wr_data[15:8];end
      if(local_valid)mem_hi[local_addr]<=local_data;
      if(rd_en)read_hi<=mem_hi[ra[8:0]];
     end
     assign q[s]={read_hi,block_q};
    end else assign q[s]={{8{block_q[7]}},block_q};
   end else begin:g_distributed
   (* ram_style="distributed" *) reg[WIDTH-1:0]mem[0:WORDS-1];
   (* dont_touch="true" *)reg[8:0]local_addr;
   (* dont_touch="true" *)reg[WIDTH-1:0]local_data;
   reg local_valid;
   reg[WIDTH-1:0]read_q;
   always @(posedge clk)begin
    if(!rst_n||clear)begin local_valid<=0;local_addr<=0;local_data<=0;end
    else begin
     local_valid<=wr_lane_en[l] && ((wr_addr>>9)==s) && (wr_addr<s*512+WORDS);
     local_addr<=wr_addr[8:0];local_data<=wr_data[WIDTH-1:0];
    end
    if(local_valid)mem[local_addr]<=local_data;
    if(rd_en)read_q<=mem[ra[8:0]];
   end
   if(HAS_HI)assign q[s]=read_q;
   else assign q[s]={{8{read_q[7]}},read_q};
   end
  end
  assign rd_data[255-l*16 -:16]=q[read_shard];
 end endgenerate
endmodule

