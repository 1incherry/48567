`timescale 1ns/1ps

module v718_external_bank_qkt_banked_acc16_vecquant_score_tile_core_nomemh_legacy #(
    parameter M = 200,
    parameter K = 200,
    parameter N = 64
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire start,
    input  wire [15:0] qkt_a_base,
    input  wire [15:0] qkt_b_base,
    input  wire [15:0] qkt_scale_base,
    input  wire [31:0] qkt_quant_base,
    input  wire scale_wr_valid,
    input  wire [15:0] scale_wr_addr,
    input  wire signed [31:0] scale_wr_data,
    output wire ext_a_rd_en,
    output wire [15:0] ext_a_rd_addr,
    input  wire [255:0] ext_a_rd_data,
    output wire ext_b_rd_en,
    output wire [15:0] ext_b_rd_addr,
    input  wire [255:0] ext_b_rd_data,
    output reg  busy,
    output reg  done,
    output reg [31:0] stat_tiles,
    output reg [31:0] stat_tile_reads,
    output reg [31:0] stat_prefetches,
    output reg [31:0] stat_underflows,
    output reg [31:0] stat_quant_errors,
    output reg [31:0] stat_scale_writes,
    output reg [31:0] stat_scale_errors,
    output reg [31:0] stat_cycles,
    output reg [4:0]  stat_stage,
    output reg        out_tile_valid,
    output reg [15:0] out_tile_addr,
    output reg [127:0] out_tile_data
);

localparam TILE = 4;
localparam OUT_SIZE = M*N;
localparam M_TILES = M/TILE;
localparam N_TILES = N/TILE;
localparam K_TILES = K/TILE;
localparam OUT_TILE_COUNT = M_TILES*N_TILES;
localparam A_TILE_DEPTH = M_TILES*K_TILES;
localparam B_TILE_DEPTH = K_TILES*N_TILES;
localparam A_TILE_ALL_DEPTH = A_TILE_DEPTH * 3;
localparam B_TILE_ALL_DEPTH = B_TILE_DEPTH * 3;
localparam SCALE_ALL_DEPTH = N * 3;
localparam QUANT_ALL_DEPTH = OUT_SIZE * 3;
localparam TOTAL_TILES = M_TILES*N_TILES*K_TILES;

localparam ST_IDLE           = 5'd0;
localparam ST_CLEAR_ACC      = 5'd1;
localparam ST_REQ_CUR        = 5'd2;
localparam ST_WAIT_CUR       = 5'd3;
localparam ST_CAP_CUR_REQ_N  = 5'd4;
localparam ST_WAIT_NEXT      = 5'd5;
localparam ST_CAP_NEXT       = 5'd6;
localparam ST_FIRE           = 5'd7;
localparam ST_WAIT_PE        = 5'd8;
localparam ST_ACC_REQ        = 5'd9;
localparam ST_ACC_READ       = 5'd10;
localparam ST_ACC_WRITE      = 5'd11;
localparam ST_NEXT           = 5'd12;
localparam ST_WAIT_FOLLOW    = 5'd13;
localparam ST_CAP_FOLLOW     = 5'd14;
localparam ST_QUANT_INIT     = 5'd15;
localparam ST_QUANT_REQ      = 5'd16;
localparam ST_QUANT_READ     = 5'd17;
localparam ST_QUANT_CALC     = 5'd18;
localparam ST_DONE           = 5'd19;

reg [4:0] state;
reg [15:0] mt;
reg [15:0] nt;
reg [15:0] kt;
reg [15:0] next_mt;
reg [15:0] next_nt;
reg [15:0] next_kt;
reg [15:0] idx;
reg [15:0] clear_idx;

reg pe_in_valid;
reg [255:0] pe_a_flat;
reg [255:0] pe_b_flat;
wire pe_in_ready;
wire pe_out_valid;
wire [511:0] pe_c_flat;
wire [31:0] pe_stat_tiles;

reg a_rd_en;
reg b_rd_en;
reg [15:0] a_rd_addr;
reg [15:0] b_rd_addr;
wire [255:0] a_rd_data;
wire [255:0] b_rd_data;
wire [15:0] a_phys_addr;
wire [15:0] b_phys_addr;
assign a_phys_addr = qkt_a_base + a_rd_addr;
assign b_phys_addr = qkt_b_base + b_rd_addr;
assign ext_a_rd_en = a_rd_en;
assign ext_a_rd_addr = a_phys_addr;
assign a_rd_data = ext_a_rd_data;
assign ext_b_rd_en = b_rd_en;
assign ext_b_rd_addr = b_phys_addr;
assign b_rd_data = ext_b_rd_data;
reg [255:0] curr_a_slot;
reg [255:0] curr_b_slot;
reg [255:0] next_a_slot;
reg [255:0] next_b_slot;
reg curr_slot_valid;
reg next_slot_valid;
reg follow_pending;

reg signed [31:0] acc0_r;
reg signed [31:0] acc1_r;
reg signed [31:0] acc2_r;
reg signed [31:0] acc3_r;
reg signed [31:0] acc4_r;
reg signed [31:0] acc5_r;
reg signed [31:0] acc6_r;
reg signed [31:0] acc7_r;
reg signed [31:0] acc8_r;
reg signed [31:0] acc9_r;
reg signed [31:0] acc10_r;
reg signed [31:0] acc11_r;
reg signed [31:0] acc12_r;
reg signed [31:0] acc13_r;
reg signed [31:0] acc14_r;
reg signed [31:0] acc15_r;

reg acc_bank_rd_en;
reg acc_bank_wr_en;
reg [11:0] acc_bank_addr;
reg [511:0] acc_bank_wr_data;
wire [511:0] acc_bank_rd_data;
wire signed [31:0] acc_bank_lane0  = acc_bank_rd_data[511 - 0*32 -: 32];
wire signed [31:0] acc_bank_lane1  = acc_bank_rd_data[511 - 1*32 -: 32];
wire signed [31:0] acc_bank_lane2  = acc_bank_rd_data[511 - 2*32 -: 32];
wire signed [31:0] acc_bank_lane3  = acc_bank_rd_data[511 - 3*32 -: 32];
wire signed [31:0] acc_bank_lane4  = acc_bank_rd_data[511 - 4*32 -: 32];
wire signed [31:0] acc_bank_lane5  = acc_bank_rd_data[511 - 5*32 -: 32];
wire signed [31:0] acc_bank_lane6  = acc_bank_rd_data[511 - 6*32 -: 32];
wire signed [31:0] acc_bank_lane7  = acc_bank_rd_data[511 - 7*32 -: 32];
wire signed [31:0] acc_bank_lane8  = acc_bank_rd_data[511 - 8*32 -: 32];
wire signed [31:0] acc_bank_lane9  = acc_bank_rd_data[511 - 9*32 -: 32];
wire signed [31:0] acc_bank_lane10 = acc_bank_rd_data[511 - 10*32 -: 32];
wire signed [31:0] acc_bank_lane11 = acc_bank_rd_data[511 - 11*32 -: 32];
wire signed [31:0] acc_bank_lane12 = acc_bank_rd_data[511 - 12*32 -: 32];
wire signed [31:0] acc_bank_lane13 = acc_bank_rd_data[511 - 13*32 -: 32];
wire signed [31:0] acc_bank_lane14 = acc_bank_rd_data[511 - 14*32 -: 32];
wire signed [31:0] acc_bank_lane15 = acc_bank_rd_data[511 - 15*32 -: 32];

reg signed [31:0] pe_c0;
reg signed [31:0] pe_c1;
reg signed [31:0] pe_c2;
reg signed [31:0] pe_c3;
reg signed [31:0] pe_c4;
reg signed [31:0] pe_c5;
reg signed [31:0] pe_c6;
reg signed [31:0] pe_c7;
reg signed [31:0] pe_c8;
reg signed [31:0] pe_c9;
reg signed [31:0] pe_c10;
reg signed [31:0] pe_c11;
reg signed [31:0] pe_c12;
reg signed [31:0] pe_c13;
reg signed [31:0] pe_c14;
reg signed [31:0] pe_c15;

reg [15:0] acc_tile_addr;
reg [15:0] quant_tile_addr;
reg signed [31:0] scale_mem [0:SCALE_ALL_DEPTH-1];
reg signed [63:0] quant_wide;
reg signed [7:0] quant_r;
reg [15:0] qtile_m;
reg [15:0] qtile_n;
reg [127:0] quant_tile_pack;

v718_acc16_lane_bram32_sync #(
    .ADDR_W(12),
    .DEPTH(OUT_TILE_COUNT),
    .FIT_MAX_DEPTH(OUT_TILE_COUNT)
) u_acc_bank (
    .clk(clk),
    .wr_en(acc_bank_wr_en),
    .wr_addr(acc_bank_addr),
    .wr_data(acc_bank_wr_data),
    .rd_en(acc_bank_rd_en),
    .rd_addr(acc_bank_addr),
    .rd_data(acc_bank_rd_data)
);

v285_pe4x4_int16_tile_core u_pe (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .in_valid(pe_in_valid),
    .in_ready(pe_in_ready),
    .a_flat(pe_a_flat),
    .b_flat(pe_b_flat),
    .out_valid(pe_out_valid),
    .out_ready(1'b1),
    .c_flat(pe_c_flat),
    .stat_tiles(pe_stat_tiles)
);

always @(posedge clk) begin
    if (scale_wr_valid && (scale_wr_addr < SCALE_ALL_DEPTH[15:0]))
        scale_mem[scale_wr_addr] <= scale_wr_data;
end

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        mt <= 16'd0;
        nt <= 16'd0;
        kt <= 16'd0;
        next_mt <= 16'd0;
        next_nt <= 16'd0;
        next_kt <= 16'd0;
        idx <= 16'd0;
        clear_idx <= 16'd0;
        pe_in_valid <= 1'b0;
        pe_a_flat <= 256'd0;
        pe_b_flat <= 256'd0;
        a_rd_en <= 1'b0;
        b_rd_en <= 1'b0;
        a_rd_addr <= 16'd0;
        b_rd_addr <= 16'd0;
        curr_a_slot <= 256'd0;
        curr_b_slot <= 256'd0;
        next_a_slot <= 256'd0;
        next_b_slot <= 256'd0;
        curr_slot_valid <= 1'b0;
        next_slot_valid <= 1'b0;
        follow_pending <= 1'b0;
        acc_tile_addr <= 16'd0;
        quant_tile_addr <= 16'd0;
        acc_bank_rd_en <= 1'b0;
        acc_bank_wr_en <= 1'b0;
        acc_bank_addr <= 12'd0;
        acc_bank_wr_data <= 512'd0;
        qtile_m <= 16'd0;
        qtile_n <= 16'd0;
        busy <= 1'b0;
        done <= 1'b0;
        stat_tiles <= 32'd0;
        stat_tile_reads <= 32'd0;
        stat_prefetches <= 32'd0;
        stat_underflows <= 32'd0;
        stat_quant_errors <= 32'd0;
        stat_scale_writes <= 32'd0;
        stat_scale_errors <= 32'd0;
        stat_cycles <= 32'd0;
        stat_stage <= ST_IDLE;
        out_tile_valid <= 1'b0;
        out_tile_addr <= 16'd0;
        out_tile_data <= 128'd0;
        quant_tile_pack <= 128'd0;
    end else begin
        done <= 1'b0;
        pe_in_valid <= 1'b0;
        out_tile_valid <= 1'b0;
        a_rd_en <= 1'b0;
        b_rd_en <= 1'b0;
        acc_bank_rd_en <= 1'b0;
        acc_bank_wr_en <= 1'b0;
        stat_stage <= state;
        if (busy)
            stat_cycles <= stat_cycles + 1'b1;

        if (scale_wr_valid) begin
            if (scale_wr_addr < SCALE_ALL_DEPTH[15:0]) begin
                stat_scale_writes <= stat_scale_writes + 1'b1;
            end else begin
                stat_scale_errors <= stat_scale_errors + 1'b1;
            end
        end

        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            stat_tiles <= 32'd0;
            stat_tile_reads <= 32'd0;
            stat_prefetches <= 32'd0;
            stat_underflows <= 32'd0;
            stat_quant_errors <= 32'd0;
            stat_scale_writes <= 32'd0;
            stat_scale_errors <= 32'd0;
            stat_cycles <= 32'd0;
        end else begin
            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        mt <= 16'd0;
                        nt <= 16'd0;
                        kt <= 16'd0;
                        next_mt <= 16'd0;
                        next_nt <= 16'd0;
                        next_kt <= TILE[15:0];
                        idx <= 16'd0;
                        clear_idx <= 16'd0;
                        curr_slot_valid <= 1'b0;
                        next_slot_valid <= 1'b0;
                        follow_pending <= 1'b0;
                        stat_tiles <= 32'd0;
                        stat_tile_reads <= 32'd0;
                        stat_prefetches <= 32'd0;
                        stat_underflows <= 32'd0;
                        stat_quant_errors <= 32'd0;
                        stat_cycles <= 32'd0;
                        out_tile_valid <= 1'b0;
                        state <= ST_REQ_CUR;
                    end
                end

                ST_REQ_CUR: begin
                    a_rd_en <= 1'b1;
                    b_rd_en <= 1'b1;
                    a_rd_addr <= 16'd0;
                    b_rd_addr <= 16'd0;
                    state <= ST_WAIT_CUR;
                end

                ST_WAIT_CUR: begin
                    state <= ST_CAP_CUR_REQ_N;
                end

                ST_CAP_CUR_REQ_N: begin
                    curr_a_slot <= a_rd_data;
                    curr_b_slot <= b_rd_data;
                    curr_slot_valid <= 1'b1;
                    a_rd_en <= 1'b1;
                    b_rd_en <= 1'b1;
                    a_rd_addr <= 16'd1;
                    b_rd_addr <= N_TILES[15:0];
                    stat_tile_reads <= stat_tile_reads + 32'd1;
                    stat_prefetches <= stat_prefetches + 32'd1;
                    state <= ST_WAIT_NEXT;
                end

                ST_WAIT_NEXT: begin
                    state <= ST_CAP_NEXT;
                end

                ST_CAP_NEXT: begin
                    next_a_slot <= a_rd_data;
                    next_b_slot <= b_rd_data;
                    next_slot_valid <= 1'b1;
                    stat_tile_reads <= stat_tile_reads + 32'd1;
                    stat_prefetches <= stat_prefetches + 32'd1;
                    state <= ST_FIRE;
                end

                ST_FIRE: begin
                    if (pe_in_ready) begin
                        if (!curr_slot_valid)
                            stat_underflows <= stat_underflows + 1'b1;
                        pe_a_flat <= curr_a_slot;
                        pe_b_flat <= curr_b_slot;
                        pe_in_valid <= 1'b1;
                        state <= ST_WAIT_PE;
                    end
                end

                ST_WAIT_PE: begin
                    if (pe_out_valid) begin
                        pe_c0 <= pe_c_flat[511 - 0*32 -: 32];
                        pe_c1 <= pe_c_flat[511 - 1*32 -: 32];
                        pe_c2 <= pe_c_flat[511 - 2*32 -: 32];
                        pe_c3 <= pe_c_flat[511 - 3*32 -: 32];
                        pe_c4 <= pe_c_flat[511 - 4*32 -: 32];
                        pe_c5 <= pe_c_flat[511 - 5*32 -: 32];
                        pe_c6 <= pe_c_flat[511 - 6*32 -: 32];
                        pe_c7 <= pe_c_flat[511 - 7*32 -: 32];
                        pe_c8 <= pe_c_flat[511 - 8*32 -: 32];
                        pe_c9 <= pe_c_flat[511 - 9*32 -: 32];
                        pe_c10 <= pe_c_flat[511 - 10*32 -: 32];
                        pe_c11 <= pe_c_flat[511 - 11*32 -: 32];
                        pe_c12 <= pe_c_flat[511 - 12*32 -: 32];
                        pe_c13 <= pe_c_flat[511 - 13*32 -: 32];
                        pe_c14 <= pe_c_flat[511 - 14*32 -: 32];
                        pe_c15 <= pe_c_flat[511 - 15*32 -: 32];
                        acc_tile_addr <= (mt[15:2] * N_TILES[15:0]) + nt[15:2];
                        state <= ST_ACC_REQ;
                    end
                end

                ST_ACC_REQ: begin
                    acc_bank_rd_en <= 1'b1;
                    acc_bank_addr <= acc_tile_addr[11:0];
                    state <= ST_ACC_READ;
                end

                ST_ACC_READ: begin
                    state <= ST_ACC_WRITE;
                end

                ST_ACC_WRITE: begin
                    acc_bank_wr_en <= 1'b1;
                    acc_bank_addr <= acc_tile_addr[11:0];
                    acc_bank_wr_data <= {
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane0)  + pe_c0,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane1)  + pe_c1,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane2)  + pe_c2,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane3)  + pe_c3,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane4)  + pe_c4,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane5)  + pe_c5,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane6)  + pe_c6,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane7)  + pe_c7,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane8)  + pe_c8,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane9)  + pe_c9,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane10) + pe_c10,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane11) + pe_c11,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane12) + pe_c12,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane13) + pe_c13,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane14) + pe_c14,
                        ((kt == 16'd0) ? 32'sd0 : acc_bank_lane15) + pe_c15
                    };
                    stat_tiles <= stat_tiles + 1'b1;
                    state <= ST_NEXT;
                end

                ST_NEXT: begin
                    if (stat_tiles == TOTAL_TILES[31:0]) begin
                        idx <= 16'd0;
                        state <= ST_QUANT_INIT;
                    end else begin
                        mt <= next_mt;
                        nt <= next_nt;
                        kt <= next_kt;
                        curr_a_slot <= next_a_slot;
                        curr_b_slot <= next_b_slot;
                        curr_slot_valid <= next_slot_valid;
                        follow_pending <= 1'b1;
                        if (next_kt < K - TILE) begin
                            a_rd_addr <= (next_mt[15:2] * K_TILES[15:0]) + ((next_kt + TILE[15:0]) >> 2);
                            b_rd_addr <= (((next_kt + TILE[15:0]) >> 2) * N_TILES[15:0]) + next_nt[15:2];
                            next_kt <= next_kt + TILE[15:0];
                        end else begin
                            next_kt <= 16'd0;
                            if (next_nt < N - TILE) begin
                                a_rd_addr <= (next_mt[15:2] * K_TILES[15:0]);
                                b_rd_addr <= ((next_nt + TILE[15:0]) >> 2);
                                next_nt <= next_nt + TILE[15:0];
                            end else begin
                                next_nt <= 16'd0;
                                if (next_mt < M - TILE) begin
                                    a_rd_addr <= (((next_mt + TILE[15:0]) >> 2) * K_TILES[15:0]);
                                    b_rd_addr <= 16'd0;
                                    next_mt <= next_mt + TILE[15:0];
                                end else begin
                                    follow_pending <= 1'b0;
                                end
                            end
                        end
                        a_rd_en <= 1'b1;
                        b_rd_en <= 1'b1;
                        next_slot_valid <= 1'b0;
                        state <= ST_WAIT_FOLLOW;
                    end
                end

                ST_WAIT_FOLLOW: begin
                    state <= ST_CAP_FOLLOW;
                end

                ST_CAP_FOLLOW: begin
                    if (follow_pending) begin
                        next_a_slot <= a_rd_data;
                        next_b_slot <= b_rd_data;
                        next_slot_valid <= 1'b1;
                        stat_tile_reads <= stat_tile_reads + 1'b1;
                        stat_prefetches <= stat_prefetches + 1'b1;
                    end else begin
                        next_slot_valid <= 1'b0;
                    end
                    state <= ST_FIRE;
                end

                ST_QUANT_INIT: begin
                    idx <= 16'd0;
                    qtile_m <= 16'd0;
                    qtile_n <= 16'd0;
                    state <= ST_QUANT_REQ;
                end

                ST_QUANT_REQ: begin
                    quant_tile_addr <= qtile_m * N_TILES[15:0] + qtile_n;
                    acc_bank_rd_en <= 1'b1;
                    acc_bank_addr <= qtile_m * N_TILES[15:0] + qtile_n;
                    state <= ST_QUANT_READ;
                end

                ST_QUANT_READ: begin
                    state <= ST_QUANT_CALC;
                end

                ST_QUANT_CALC: begin
                    quant_wide = (acc_bank_lane0 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd0]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 0*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane1 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd1]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 1*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane2 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd2]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 2*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane3 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd3]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 3*8 -: 8] = quant_r;

                    quant_wide = (acc_bank_lane4 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd0]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 4*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane5 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd1]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 5*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane6 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd2]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 6*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane7 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd3]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 7*8 -: 8] = quant_r;

                    quant_wide = (acc_bank_lane8 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd0]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 8*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane9 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd1]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 9*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane10 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd2]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 10*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane11 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd3]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 11*8 -: 8] = quant_r;

                    quant_wide = (acc_bank_lane12 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd0]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 12*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane13 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd1]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 13*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane14 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd2]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 14*8 -: 8] = quant_r;
                    quant_wide = (acc_bank_lane15 * scale_mem[qkt_scale_base + (qtile_n << 2) + 16'd3]) >>> 29;
                    if (quant_wide > 64'sd127) quant_r = 8'sh7f; else if (quant_wide < -64'sd128) quant_r = -8'sd128; else quant_r = quant_wide[7:0];
                    quant_tile_pack[127 - 15*8 -: 8] = quant_r;

                    out_tile_valid <= 1'b1;
                    out_tile_addr <= quant_tile_addr;
                    out_tile_data <= quant_tile_pack;
                    if (idx == OUT_TILE_COUNT[15:0] - 1'b1)
                        state <= ST_DONE;
                    else begin
                        idx <= idx + 1'b1;
                        if (qtile_n == N_TILES[15:0] - 1'b1) begin
                            qtile_n <= 16'd0;
                            qtile_m <= qtile_m + 1'b1;
                        end else begin
                            qtile_n <= qtile_n + 1'b1;
                        end
                        state <= ST_QUANT_REQ;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule

