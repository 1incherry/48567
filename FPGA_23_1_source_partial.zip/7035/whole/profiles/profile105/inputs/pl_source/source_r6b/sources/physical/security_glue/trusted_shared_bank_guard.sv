`timescale 1ns/1ps
// Final PHYSICAL A/B RAM entrance. desired_stage is trusted PL, never PS CSR.
// No added read-data pipeline: the existing RAM remains 1-cycle read+hold.
// External YOLO/frontend mutual exclusion must be enforced before this port.
module trusted_shared_bank_guard #(
 parameter integer A_WORDS=2548,B_WORDS=2352,
 parameter integer CLOSED_AUDIO_PRODUCER=0, parameter integer ENABLE_MIC_B=0,parameter integer MIC_WORDS=2000
)(
 input wire clk,security_reset_n,
 input wire [2:0] desired_stage,input wire all_quiescent,bank_access_live,
 input wire internal_a_wr,internal_b_wr,
 input wire [11:0] internal_a_write_addr,internal_b_write_addr,
 input wire [255:0] internal_a_write_data,internal_b_write_data,
 input wire internal_a_rd,internal_b_rd,
 input wire [11:0] internal_a_read_addr,internal_b_read_addr,
 input wire external_a_wr,external_b_wr,
 input wire [11:0] external_write_addr,input wire [255:0] external_write_data,
 input wire external_a_rd,external_b_rd,
 input wire [11:0] external_a_read_addr,external_b_read_addr,
 input wire audio_b_wr,audio_b_rd,input wire[11:0]audio_b_write_addr,audio_b_read_addr,input wire[255:0]audio_b_write_data,
 input wire audio_b_response_ready,output wire audio_b_write_accepted,audio_b_read_accepted,audio_b_read_response_valid,audio_b_drained,
 input wire audio_a_wr,audio_a_rd,
 input wire [11:0] audio_a_write_addr,audio_a_read_addr,
 input wire [255:0] audio_a_write_data,
 output wire protocol_violation,
 output reg [2:0] committed_stage,
 output wire owner_ready,output reg bank_fault,output wire guard_quiescent,guard_local_quiescent,
 output wire ram_a_wr_en,ram_b_wr_en,
 output wire [11:0] ram_a_write_addr,ram_b_write_addr,
 output wire [255:0] ram_a_write_data,ram_b_write_data,
 output wire ram_a_rd_en,ram_b_rd_en,
 output wire [11:0] ram_a_read_addr,ram_b_read_addr
);
 wire internal_request=internal_a_wr||internal_b_wr||internal_a_rd||internal_b_rd;
 wire external_request=external_a_wr||external_b_wr||external_a_rd||external_b_rd;
 wire audio_request=audio_a_wr||audio_a_rd;
 wire mic_request=ENABLE_MIC_B!=0&&(audio_b_wr||audio_b_rd);
 reg mic_response_valid;
 wire any_request=internal_request||external_request||audio_request||mic_request;
 wire internal_owner=committed_stage==1;
 wire external_owner=committed_stage==2||committed_stage==3;
 wire audio_owner=committed_stage==4;
 wire inactive_request=(internal_request&&!internal_owner)||(external_request&&!external_owner)||(CLOSED_AUDIO_PRODUCER==0&&audio_request&&!audio_owner);
 wire range_fault=
  (internal_a_wr&&internal_a_write_addr>=A_WORDS)||(internal_b_wr&&internal_b_write_addr>=B_WORDS)||
  (internal_a_rd&&internal_a_read_addr>=A_WORDS)||(internal_b_rd&&internal_b_read_addr>=B_WORDS)||
  (external_a_wr&&external_write_addr>=A_WORDS)||(external_b_wr&&external_write_addr>=B_WORDS)||
  (external_a_rd&&external_a_read_addr>=A_WORDS)||(external_b_rd&&external_b_read_addr>=B_WORDS)||
  (CLOSED_AUDIO_PRODUCER==0&&((audio_a_wr&&audio_a_write_addr>=2048)||(audio_a_rd&&audio_a_read_addr>=2048)));
 wire mic_violation=ENABLE_MIC_B!=0&&((mic_request&&!audio_owner)||(audio_b_wr&&(audio_b_write_addr>=MIC_WORDS||audio_b_write_addr>=B_WORDS))||(audio_b_rd&&(audio_b_read_addr>=MIC_WORDS||audio_b_read_addr>=B_WORDS)));
 wire violation=inactive_request||range_fault||desired_stage>4||mic_violation;
 assign protocol_violation=violation;
 // Revocation/cancel closes the physical entrance on this same edge. It is
 // not itself a protocol fault; inactive/range violations still latch fault.
 wire access_allowed=security_reset_n&&bank_access_live&&!bank_fault&&!violation;
 assign ram_a_wr_en=access_allowed&&(internal_owner?internal_a_wr:audio_owner?audio_a_wr:external_owner&&external_a_wr);
 assign ram_b_wr_en=access_allowed&&(internal_owner?internal_b_wr:(ENABLE_MIC_B!=0&&audio_owner)?audio_b_wr:external_owner&&external_b_wr);
 assign ram_a_rd_en=access_allowed&&(internal_owner?internal_a_rd:audio_owner?audio_a_rd:external_owner&&external_a_rd);
 assign ram_b_rd_en=access_allowed&&(internal_owner?internal_b_rd:(ENABLE_MIC_B!=0&&audio_owner)?(audio_b_rd&&!mic_response_valid):external_owner&&external_b_rd);
 assign ram_a_write_addr=internal_owner?internal_a_write_addr:audio_owner?audio_a_write_addr:external_write_addr;
 assign ram_b_write_addr=internal_owner?internal_b_write_addr:(ENABLE_MIC_B!=0&&audio_owner)?audio_b_write_addr:external_write_addr;
 assign ram_a_write_data=internal_owner?internal_a_write_data:audio_owner?audio_a_write_data:external_write_data;
 assign ram_b_write_data=internal_owner?internal_b_write_data:(ENABLE_MIC_B!=0&&audio_owner)?audio_b_write_data:external_write_data;
 assign ram_a_read_addr=internal_owner?internal_a_read_addr:audio_owner?audio_a_read_addr:external_a_read_addr;
 assign ram_b_read_addr=internal_owner?internal_b_read_addr:(ENABLE_MIC_B!=0&&audio_owner)?audio_b_read_addr:external_b_read_addr;
 // Closed audio producer is the actual native arbiter, whose public read/write
 // always include grant=(this committed stage==4&&!bank_fault) and the exact
 // <1024 or [1024,2048) address range. Its own violation/fault remains unchanged.
 // This only folds two identically false duplicated final-entrance predicates.
`ifndef SYNTHESIS
 always @(posedge clk or negedge clk)if(security_reset_n&&CLOSED_AUDIO_PRODUCER!=0)
  if((audio_request&&!audio_owner)||(audio_a_wr&&audio_a_write_addr>=2048)||(audio_a_rd&&audio_a_read_addr>=2048))
   $fatal(1,"CLOSED_AUDIO_PRODUCER_PRECONDITION_VIOLATED");
`endif
 // One held real B response. SRAM read occurs only on actual accepted edge.
 assign audio_b_write_accepted=ENABLE_MIC_B!=0&&audio_owner&&ram_b_wr_en;
 assign audio_b_read_accepted=ENABLE_MIC_B!=0&&audio_owner&&ram_b_rd_en;
 assign audio_b_read_response_valid=ENABLE_MIC_B!=0&&mic_response_valid;
 assign audio_b_drained=!mic_response_valid&&!audio_b_write_accepted&&!audio_b_read_accepted;
 always@(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)mic_response_valid<=0;
  else begin
   if(mic_response_valid&&audio_b_response_ready)mic_response_valid<=0;
   if(audio_b_read_accepted)mic_response_valid<=1;
  end
 end
 reg previous_read,quiet_previous;
 wire quiet_now=all_quiescent&&!any_request&&!previous_read&&!mic_response_valid;
 // Physical quiet remains observable on a sticky fault, enabling safe system
 // drain/inspection; owner changes and all new accesses remain forbidden.
 assign guard_quiescent=security_reset_n&&quiet_now;
 // Outer-only clone predicate; public ownership/drain guard stays unchanged.
 assign guard_local_quiescent=security_reset_n&&!any_request&&!previous_read&&!mic_response_valid;
 assign owner_ready=security_reset_n&&!bank_fault&&!violation&&quiet_now&&quiet_previous;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin committed_stage<=0;bank_fault<=0;previous_read<=0;quiet_previous<=0;end
  else begin
   previous_read<=ram_a_rd_en||ram_b_rd_en;
   quiet_previous<=quiet_now;
   if(violation)bank_fault<=1;
   if(owner_ready)committed_stage<=desired_stage;
  end
 end
// synthesis translate_off
 initial if(MIC_WORDS!=2000||MIC_WORDS>B_WORDS)$fatal(1,"EXACT_AUDIO2S_B_CAPACITY_REQUIRED");
 // synthesis translate_on
endmodule
