`timescale 1ns/1ps

module v637_norm3_stream_axi_store_adapter_cfgfifo #(
    parameter AXI_ADDR_WIDTH = 16,
    parameter AXI_DATA_WIDTH = 256,
    parameter FIFO_DEPTH     = 8,
    parameter FIFO_ADDR_WIDTH = 3,
    parameter BURST_BEATS    = 8
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         clear,
    input  wire                         start,
    input  wire [AXI_ADDR_WIDTH-1:0]    out_base_addr,
    input  wire [15:0]                  total_items,
    output reg                          busy,
    output reg                          done,

    input  wire                         stream_valid,
    output wire                         stream_ready,
    input  wire [15:0]                  stream_addr,
    input  wire signed [15:0]           stream_data,

    output wire [AXI_ADDR_WIDTH-1:0]    M_AXI_ARADDR,
    output wire [7:0]                   M_AXI_ARLEN,
    output wire [2:0]                   M_AXI_ARSIZE,
    output wire [1:0]                   M_AXI_ARBURST,
    output wire                         M_AXI_ARVALID,
    input  wire                         M_AXI_ARREADY,
    input  wire [AXI_DATA_WIDTH-1:0]    M_AXI_RDATA,
    input  wire [1:0]                   M_AXI_RRESP,
    input  wire                         M_AXI_RLAST,
    input  wire                         M_AXI_RVALID,
    output wire                         M_AXI_RREADY,

    output wire [AXI_ADDR_WIDTH-1:0]    M_AXI_AWADDR,
    output wire [7:0]                   M_AXI_AWLEN,
    output wire [2:0]                   M_AXI_AWSIZE,
    output wire [1:0]                   M_AXI_AWBURST,
    output wire                         M_AXI_AWVALID,
    input  wire                         M_AXI_AWREADY,
    output wire [AXI_DATA_WIDTH-1:0]    M_AXI_WDATA,
    output wire [AXI_DATA_WIDTH/8-1:0]  M_AXI_WSTRB,
    output wire                         M_AXI_WLAST,
    output wire                         M_AXI_WVALID,
    input  wire                         M_AXI_WREADY,
    input  wire [1:0]                   M_AXI_BRESP,
    input  wire                         M_AXI_BVALID,
    output wire                         M_AXI_BREADY,

    output wire [31:0]                  stat_axi_write_cmds,
    output wire [31:0]                  stat_axi_write_beats,
    output wire [31:0]                  stat_axi_errors,
    output reg  [31:0]                  stat_stream_items,
    output reg  [31:0]                  stat_packed_beats,
    output reg  [31:0]                  stat_fifo_stall_cycles,
    output reg  [31:0]                  stat_order_errors,
    output reg  [7:0]                   stat_fifo_max_level,
    output wire [7:0]                   stat_fifo_level
);

localparam LANES = AXI_DATA_WIDTH / 16;
localparam FIFO_COUNT_WIDTH = FIFO_ADDR_WIDTH + 1;
localparam [FIFO_COUNT_WIDTH-1:0] FIFO_DEPTH_LEVEL = FIFO_DEPTH;

reg store_cmd_valid;
wire store_cmd_ready;
wire [15:0] store_cmd_beats;
wire store_data_ready;
reg [15:0] expected_addr;
reg [15:0] items_left;
reg [15:0] command_written_beats;
reg [3:0] pack_lane;
reg [AXI_DATA_WIDTH-1:0] pack_word;
reg [AXI_DATA_WIDTH-1:0] packed_word;
reg [FIFO_ADDR_WIDTH-1:0] fifo_wr_ptr;
reg [FIFO_ADDR_WIDTH-1:0] fifo_rd_ptr;
reg [FIFO_COUNT_WIDTH-1:0] fifo_count;
reg [AXI_DATA_WIDTH-1:0] fifo_mem [0:FIFO_DEPTH-1];
wire fifo_empty;
wire fifo_full;
wire stream_fire;
wire packing_last_item;
wire packing_last_lane;
wire packing_emit;
wire store_data_valid;
wire [AXI_DATA_WIDTH-1:0] store_data;
wire store_data_last;
wire load_busy_unused;
wire store_busy;
wire [7:0] store_active_tag_unused;
wire load_done_unused;
wire store_done_pulse;
wire [31:0] stat_read_cmds_unused;
wire [31:0] stat_read_beats_unused;
wire [31:0] stat_backpressure_unused;

// FIFO_DEPTH is not required to be a power of two (the Block0 instance uses
// depth 3).  Keep the ring pointers in the actual memory range instead of
// allowing the natural binary counter to address fifo_mem[FIFO_DEPTH].
function [FIFO_ADDR_WIDTH-1:0] fifo_ptr_inc;
    input [FIFO_ADDR_WIDTH-1:0] ptr;
    begin
        if (ptr == FIFO_DEPTH-1)
            fifo_ptr_inc = {FIFO_ADDR_WIDTH{1'b0}};
        else
            fifo_ptr_inc = ptr + 1'b1;
    end
endfunction

assign fifo_empty = (fifo_count == {FIFO_COUNT_WIDTH{1'b0}});
assign fifo_full = (fifo_count == FIFO_DEPTH_LEVEL);
assign stat_fifo_level = fifo_count;
assign stream_ready = busy && !fifo_full && (items_left != 16'd0);
assign stream_fire = stream_valid && stream_ready;
assign packing_last_item = (items_left == 16'd1);
assign packing_last_lane = (pack_lane == LANES[3:0] - 1'b1);
assign packing_emit = stream_fire && (packing_last_item || packing_last_lane);
assign store_cmd_beats = (total_items[3:0] == 4'd0) ? (total_items >> 4) : ((total_items >> 4) + 1'b1);
assign store_data_valid = !fifo_empty;
assign store_data_last = (command_written_beats + 1'b1 == store_cmd_beats);
assign store_data = fifo_mem[fifo_rd_ptr];

v626_axi_like_load_store_shell #(
    .AXI_ADDR_WIDTH(AXI_ADDR_WIDTH),
    .AXI_DATA_WIDTH(AXI_DATA_WIDTH),
    .BURST_BEATS(BURST_BEATS)
) u_store_shell (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .load_cmd_valid(1'b0),
    .load_cmd_ready(),
    .load_cmd_addr({AXI_ADDR_WIDTH{1'b0}}),
    .load_cmd_beats(16'd0),
    .load_cmd_tag(8'd0),
    .load_data_valid(),
    .load_data_ready(1'b1),
    .load_data(),
    .load_data_tag(),
    .load_data_last(),
    .store_cmd_valid(store_cmd_valid),
    .store_cmd_ready(store_cmd_ready),
    .store_cmd_addr(out_base_addr),
    .store_cmd_beats(store_cmd_beats),
    .store_cmd_tag(8'h63),
    .store_data_valid(store_data_valid),
    .store_data_ready(store_data_ready),
    .store_data(store_data),
    .store_data_last(store_data_last),
    .M_AXI_ARADDR(M_AXI_ARADDR),
    .M_AXI_ARLEN(M_AXI_ARLEN),
    .M_AXI_ARSIZE(M_AXI_ARSIZE),
    .M_AXI_ARBURST(M_AXI_ARBURST),
    .M_AXI_ARVALID(M_AXI_ARVALID),
    .M_AXI_ARREADY(M_AXI_ARREADY),
    .M_AXI_RDATA(M_AXI_RDATA),
    .M_AXI_RRESP(M_AXI_RRESP),
    .M_AXI_RLAST(M_AXI_RLAST),
    .M_AXI_RVALID(M_AXI_RVALID),
    .M_AXI_RREADY(M_AXI_RREADY),
    .M_AXI_AWADDR(M_AXI_AWADDR),
    .M_AXI_AWLEN(M_AXI_AWLEN),
    .M_AXI_AWSIZE(M_AXI_AWSIZE),
    .M_AXI_AWBURST(M_AXI_AWBURST),
    .M_AXI_AWVALID(M_AXI_AWVALID),
    .M_AXI_AWREADY(M_AXI_AWREADY),
    .M_AXI_WDATA(M_AXI_WDATA),
    .M_AXI_WSTRB(M_AXI_WSTRB),
    .M_AXI_WLAST(M_AXI_WLAST),
    .M_AXI_WVALID(M_AXI_WVALID),
    .M_AXI_WREADY(M_AXI_WREADY),
    .M_AXI_BRESP(M_AXI_BRESP),
    .M_AXI_BVALID(M_AXI_BVALID),
    .M_AXI_BREADY(M_AXI_BREADY),
    .load_busy(load_busy_unused),
    .store_busy(store_busy),
    .store_active_tag(store_active_tag_unused),
    .load_done_pulse(load_done_unused),
    .store_done_pulse(store_done_pulse),
    .stat_read_cmds(stat_read_cmds_unused),
    .stat_read_beats(stat_read_beats_unused),
    .stat_write_cmds(stat_axi_write_cmds),
    .stat_write_beats(stat_axi_write_beats),
    .stat_backpressure_cycles(stat_backpressure_unused),
    .stat_errors(stat_axi_errors)
);

always @(posedge clk) begin
    if (!rst_n) begin
        busy <= 1'b0;
        done <= 1'b0;
        store_cmd_valid <= 1'b0;
        expected_addr <= 16'd0;
        items_left <= 16'd0;
        command_written_beats <= 16'd0;
        pack_lane <= 4'd0;
        pack_word <= {AXI_DATA_WIDTH{1'b0}};
        fifo_wr_ptr <= {FIFO_ADDR_WIDTH{1'b0}};
        fifo_rd_ptr <= {FIFO_ADDR_WIDTH{1'b0}};
        fifo_count <= {FIFO_COUNT_WIDTH{1'b0}};
        stat_stream_items <= 32'd0;
        stat_packed_beats <= 32'd0;
        stat_fifo_stall_cycles <= 32'd0;
        stat_order_errors <= 32'd0;
        stat_fifo_max_level <= 8'd0;
    end else begin
        done <= 1'b0;

        if (clear) begin
            busy <= 1'b0;
            done <= 1'b0;
            store_cmd_valid <= 1'b0;
            expected_addr <= 16'd0;
            items_left <= 16'd0;
            command_written_beats <= 16'd0;
            pack_lane <= 4'd0;
            pack_word <= {AXI_DATA_WIDTH{1'b0}};
            fifo_wr_ptr <= {FIFO_ADDR_WIDTH{1'b0}};
            fifo_rd_ptr <= {FIFO_ADDR_WIDTH{1'b0}};
            fifo_count <= {FIFO_COUNT_WIDTH{1'b0}};
            stat_stream_items <= 32'd0;
            stat_packed_beats <= 32'd0;
            stat_fifo_stall_cycles <= 32'd0;
            stat_order_errors <= 32'd0;
            stat_fifo_max_level <= 8'd0;
        end else begin
            if (!busy && start) begin
                busy <= 1'b1;
                store_cmd_valid <= (total_items != 16'd0);
                expected_addr <= 16'd0;
                items_left <= total_items;
                command_written_beats <= 16'd0;
                pack_lane <= 4'd0;
                pack_word <= {AXI_DATA_WIDTH{1'b0}};
                fifo_wr_ptr <= {FIFO_ADDR_WIDTH{1'b0}};
                fifo_rd_ptr <= {FIFO_ADDR_WIDTH{1'b0}};
                fifo_count <= {FIFO_COUNT_WIDTH{1'b0}};
                stat_stream_items <= 32'd0;
                stat_packed_beats <= 32'd0;
                stat_fifo_stall_cycles <= 32'd0;
                stat_order_errors <= 32'd0;
                stat_fifo_max_level <= 8'd0;
                if (total_items == 16'd0)
                    done <= 1'b1;
            end

            if (store_cmd_valid && store_cmd_ready)
                store_cmd_valid <= 1'b0;

            if (busy && stream_valid && !stream_ready && (items_left != 16'd0))
                stat_fifo_stall_cycles <= stat_fifo_stall_cycles + 1'b1;

             if (stream_fire) begin
`ifdef V804_DEBUG_X
                 if (^stream_data === 1'bx)
                     $display("V804_X_V637_IN addr=%0d data=%04h lane=%0d items_left=%0d",stream_addr,stream_data,pack_lane,items_left);
`endif
                 packed_word = pack_word;
                if (pack_lane == 4'd0)
                    packed_word[255:240] = stream_data;
                else if (pack_lane == 4'd1)
                    packed_word[239:224] = stream_data;
                else if (pack_lane == 4'd2)
                    packed_word[223:208] = stream_data;
                else if (pack_lane == 4'd3)
                    packed_word[207:192] = stream_data;
                else if (pack_lane == 4'd4)
                    packed_word[191:176] = stream_data;
                else if (pack_lane == 4'd5)
                    packed_word[175:160] = stream_data;
                else if (pack_lane == 4'd6)
                    packed_word[159:144] = stream_data;
                else if (pack_lane == 4'd7)
                    packed_word[143:128] = stream_data;
                else if (pack_lane == 4'd8)
                    packed_word[127:112] = stream_data;
                else if (pack_lane == 4'd9)
                    packed_word[111:96] = stream_data;
                else if (pack_lane == 4'd10)
                    packed_word[95:80] = stream_data;
                else if (pack_lane == 4'd11)
                    packed_word[79:64] = stream_data;
                else if (pack_lane == 4'd12)
                    packed_word[63:48] = stream_data;
                else if (pack_lane == 4'd13)
                    packed_word[47:32] = stream_data;
                else if (pack_lane == 4'd14)
                    packed_word[31:16] = stream_data;
                else
                    packed_word[15:0] = stream_data;

                if (stream_addr != expected_addr)
                    stat_order_errors <= stat_order_errors + 1'b1;
                expected_addr <= expected_addr + 1'b1;
                items_left <= items_left - 1'b1;
                stat_stream_items <= stat_stream_items + 1'b1;

                if (packing_emit) begin
                    fifo_mem[fifo_wr_ptr] <= packed_word;
                    fifo_wr_ptr <= fifo_ptr_inc(fifo_wr_ptr);
                    stat_packed_beats <= stat_packed_beats + 1'b1;
                    pack_word <= {AXI_DATA_WIDTH{1'b0}};
                    pack_lane <= 4'd0;
                end else begin
                    pack_word <= packed_word;
                    pack_lane <= pack_lane + 1'b1;
                end
            end

             if (store_data_valid && store_data_ready) begin
                 command_written_beats <= command_written_beats + 1'b1;
`ifdef V804_DEBUG_X
                 if (^store_data === 1'bx)
                     $display("V804_X_V637_FIFO_OUT data=%064h rd_ptr=%0d wr_ptr=%0d count=%0d",store_data,fifo_rd_ptr,fifo_wr_ptr,fifo_count);
`endif
                 fifo_rd_ptr <= fifo_ptr_inc(fifo_rd_ptr);
            end

            if (packing_emit && !(store_data_valid && store_data_ready)) begin
                fifo_count <= fifo_count + 1'b1;
                if ((fifo_count + 1'b1) > stat_fifo_max_level)
                    stat_fifo_max_level <= fifo_count + 1'b1;
            end else if (!packing_emit && (store_data_valid && store_data_ready)) begin
                fifo_count <= fifo_count - 1'b1;
            end

            if (store_done_pulse) begin
                busy <= 1'b0;
                done <= 1'b1;
            end
        end
    end
end

endmodule
