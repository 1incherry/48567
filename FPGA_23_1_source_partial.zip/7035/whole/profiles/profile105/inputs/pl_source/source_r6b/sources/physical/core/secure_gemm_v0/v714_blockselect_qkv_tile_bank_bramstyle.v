`timescale 1ns/1ps

module v714_blockselect_qkv_tile_bank_bramstyle (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,

    input  wire         a_wr_valid,
    input  wire [3:0]   a_wr_block_id,
    input  wire [11:0]  a_wr_addr,
    input  wire [255:0] a_wr_data,

    input  wire         b_wr_valid,
    input  wire [3:0]   b_wr_block_id,
    input  wire [3:0]   b_wr_op_id,
    input  wire [9:0]   b_wr_addr,
    input  wire [255:0] b_wr_data,

    input  wire         req_valid,
    output wire         req_ready,
    input  wire [3:0]   block_id,
    input  wire [3:0]   op_id,
    input  wire [11:0]  a_addr,
    input  wire [9:0]   b_addr,
    output reg          resp_valid,
    input  wire         resp_ready,
    output reg [255:0]  a_data,
    output reg [255:0]  b_data,
    output reg          resp_error,
    output reg          wr_error,
    output reg [31:0]   stat_reads,
    output reg [31:0]   stat_a_writes,
    output reg [31:0]   stat_b_writes,
    output reg [31:0]   stat_errors
);

wire a_wr_legal = a_wr_valid && (a_wr_block_id <= 4'd11) && (a_wr_addr <= 12'd2449);
wire b_wr_legal = b_wr_valid && (b_wr_block_id <= 4'd11) && (b_wr_op_id <= 4'd8) && (b_wr_addr <= 10'd783);
wire req_legal = req_valid && (block_id <= 4'd11) && (op_id <= 4'd8) &&
                 (a_addr <= 12'd2449) && (b_addr <= 10'd783);

wire [12:0] a_wr_base = 13'd0;
wire [12:0] a_rd_base = 13'd0;
wire [12:0] a_wr_flat_addr = a_wr_base + {1'b0, a_wr_addr};
wire [12:0] a_rd_flat_addr = req_legal ? (a_rd_base + {1'b0, a_addr}) : 13'd0;

// V781 keeps only the current Q/K/V projection's B tile bank resident.
// Software/TB must load one 784-tile B payload immediately before launching
// that op. The op id remains part of the command/scoreboard contract, but no
// longer selects one of nine physical copies.
wire [9:0] b_wr_flat_addr = b_wr_addr;
wire [9:0] b_rd_flat_addr = req_legal ? b_addr : 10'd0;

wire [255:0] a_rd_q;
wire [255:0] b_rd_q;
reg req_pending;
reg req_error_pending;

assign req_ready = !resp_valid && !req_pending;

v714_bram_sdp_sync #(
    .DATA_W(256),
    .ADDR_W(13),
    .DEPTH(2450),
    .FIT_MAX_DEPTH(2450)
) u_a_bank (
    .clk(clk),
    .wr_en(a_wr_legal),
    .wr_addr(a_wr_flat_addr),
    .wr_data(a_wr_data),
    .rd_en(req_valid && req_ready),
    .rd_addr(a_rd_flat_addr),
    .rd_data(a_rd_q)
);

v714_bram_sdp_sync #(
    .DATA_W(256),
    .ADDR_W(10),
    .DEPTH(784),
    .FIT_MAX_DEPTH(784)
) u_b_bank (
    .clk(clk),
    .wr_en(b_wr_legal),
    .wr_addr(b_wr_flat_addr),
    .wr_data(b_wr_data),
    .rd_en(req_valid && req_ready),
    .rd_addr(b_rd_flat_addr),
    .rd_data(b_rd_q)
);

always @(posedge clk) begin
    if (!rst_n) begin
        resp_valid <= 1'b0;
        a_data <= 256'd0;
        b_data <= 256'd0;
        resp_error <= 1'b0;
        wr_error <= 1'b0;
        stat_reads <= 32'd0;
        stat_a_writes <= 32'd0;
        stat_b_writes <= 32'd0;
        stat_errors <= 32'd0;
        req_pending <= 1'b0;
        req_error_pending <= 1'b0;
    end else begin
        if (clear) begin
            resp_valid <= 1'b0;
            resp_error <= 1'b0;
            wr_error <= 1'b0;
            stat_reads <= 32'd0;
            stat_a_writes <= 32'd0;
            stat_b_writes <= 32'd0;
            stat_errors <= 32'd0;
            req_pending <= 1'b0;
            req_error_pending <= 1'b0;
        end else begin
            wr_error <= 1'b0;

            if (resp_valid && resp_ready)
                resp_valid <= 1'b0;

            if (a_wr_valid) begin
                if (a_wr_legal)
                    stat_a_writes <= stat_a_writes + 1'b1;
                else begin
                    wr_error <= 1'b1;
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            if (b_wr_valid) begin
                if (b_wr_legal)
                    stat_b_writes <= stat_b_writes + 1'b1;
                else begin
                    wr_error <= 1'b1;
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            if (req_valid && req_ready) begin
                stat_reads <= stat_reads + 1'b1;
                req_pending <= 1'b1;
                req_error_pending <= !req_legal;
                if (!req_legal)
                    stat_errors <= stat_errors + 1'b1;
            end else begin
                req_pending <= 1'b0;
            end

            if (req_pending) begin
                resp_valid <= 1'b1;
                resp_error <= req_error_pending;
                a_data <= a_rd_q;
                b_data <= b_rd_q;
            end
        end
    end
end

endmodule
