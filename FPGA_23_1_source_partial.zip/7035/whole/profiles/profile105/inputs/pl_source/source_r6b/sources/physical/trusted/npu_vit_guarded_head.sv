`timescale 1ns/1ps
// B11 Norm3 -> exact Q24 head -> epoch-bound result. The page/cache ports
// connect ONLY to npu_model_security_service, not PS-produced valid flags.
// Fixed policy binding: object291 weights (leaves2899..2918), object292 bias
// (leaf2919). This cache client requires exclusive ownership during a task.
// All ports are in one clock domain; CDC must be supplied at a 100/50MHz edge.
module npu_vit_guarded_head #(
 parameter integer TIMEOUT_CYCLES=20000000
)(input wire clk,rst_n,start,cancel,model_authorized,
 input wire [31:0] session_epoch,
 input wire norm_valid,norm_done,output wire norm_ready,input wire [15:0] norm_address,
 input wire signed [15:0] norm_data,
 output wire page_request,input wire page_request_ready,
 output wire [31:0] expected_page_index,
 input wire cache_valid,input wire [31:0] cached_page_index,
 output wire cache_read,output wire [9:0] cache_read_addr,
 input wire cache_read_valid,input wire [31:0] cache_read_data,
 output wire busy,result_valid,output reg fault,
 output wire [7:0] class_index,output wire signed [63:0] best_logit,
 output wire [31:0] result_epoch,
 output wire logit_valid,output wire [7:0] logit_class,output wire signed [63:0] logit_data
);
 reg active,finished,norm_sealed,bias_loaded,head_start;
 reg [31:0] epoch,ticks;
 reg [15:0] norm_count,weight_count;
 reg [6:0] bias_fill,bias_class;
 (* ram_style="distributed" *) reg signed [31:0] bias_ram[0:104];
 reg requested_page,word_pending,weight_held;
 reg signed [31:0] weight_word;
 wire head_feature_ready,head_bias_ready,head_weight_ready,head_busy,head_done,head_fault;
 wire live=(model_authorized===1'b1)&&(session_epoch===epoch)&&!cancel;
 wire current=active&&live&&!fault&&!start&&rst_n;
 wire [31:0] needed_page=bias_loaded?32'd2899+{26'd0,weight_count[15:10]}:32'd2919;
 wire correct_page=(cache_valid===1'b1)&&(cached_page_index===needed_page);
 assign expected_page_index=needed_page;
 assign page_request=current&&!finished&&!requested_page&&!word_pending&&!weight_held&&!correct_page&&
                     (!bias_loaded||weight_count<20370);
 assign cache_read=current&&!finished&&!word_pending&&!weight_held&&correct_page&&
                   (!bias_loaded||(head_weight_ready&&weight_count<20370));
 assign cache_read_addr=bias_loaded?weight_count[9:0]:{3'd0,bias_fill};
 wire signed [31:0] logical_word={cache_read_data[7:0],cache_read_data[15:8],cache_read_data[23:16],cache_read_data[31:24]};
 wire [7:0] head_class,raw_logit_class;
 wire signed [63:0] head_best,raw_logit;
 wire raw_logit_valid;
 wire feed_feature=current&&norm_valid&&norm_count<194&&(norm_address===norm_count);
 wire feed_bias=current&&bias_loaded&&head_bias_ready&&bias_class<105;
 wire feed_weight=current&&weight_held;
 npu_vit_q24_head #(.TIMEOUT_CYCLES(TIMEOUT_CYCLES)) math(
  .clk(clk),.rst_n(rst_n),.start(head_start),
  .cancel(cancel||fault||(active&&!live)),
  .feature_valid(feed_feature),.feature_ready(head_feature_ready),.feature_data(norm_data),
  .bias_valid(feed_bias),.bias_ready(head_bias_ready),.bias_data(bias_ram[bias_class]),
  .weight_valid(feed_weight),.weight_ready(head_weight_ready),.weight_data(weight_word),
  .busy(head_busy),.done(head_done),.fault(head_fault),.class_index(head_class),.best_logit(head_best),
  .elapsed_cycles(),.logit_valid(raw_logit_valid),.logit_class(raw_logit_class),.logit_data(raw_logit));
 assign busy=active&&!finished&&!fault;
 assign norm_ready=current&&!head_start&&!norm_sealed&&(norm_count>=194||head_feature_ready);
 assign result_valid=active&&finished&&!fault&&live&&rst_n&&!start;
 assign class_index=result_valid?head_class:8'd0;
 assign best_logit=result_valid?head_best:64'sd0;
 assign result_epoch=result_valid?epoch:32'd0;
 // Logits are a diagnostic stream, not early authorization of a result.
 assign logit_valid=current&&raw_logit_valid;
 assign logit_class=logit_valid?raw_logit_class:0;
 assign logit_data=logit_valid?raw_logit:0;
 always @(posedge clk)begin
  if(current&&word_pending&&cache_read_valid&&correct_page&&!bias_loaded)
   bias_ram[bias_fill]<=logical_word;
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   active<=0;finished<=0;norm_sealed<=0;bias_loaded<=0;head_start<=0;epoch<=0;ticks<=0;
   norm_count<=0;weight_count<=0;bias_fill<=0;bias_class<=0;
   requested_page<=0;word_pending<=0;weight_held<=0;weight_word<=0;fault<=0;
  end else if(cancel||(active&&!live))begin
   active<=0;finished<=0;head_start<=0;word_pending<=0;weight_held<=0;requested_page<=0;fault<=1;
  end else if(start)begin
   if((model_authorized!==1'b1)||busy)begin active<=0;finished<=0;head_start<=0;fault<=1;end
   else begin
    active<=1;finished<=0;norm_sealed<=0;bias_loaded<=0;head_start<=1;epoch<=session_epoch;ticks<=0;
    norm_count<=0;weight_count<=0;bias_fill<=0;bias_class<=0;
    requested_page<=0;word_pending<=0;weight_held<=0;fault<=0;
   end
  end else if(active&&!fault)begin
   head_start<=0;
   if(!finished)begin
    ticks<=ticks+1'b1;
    if(ticks>=TIMEOUT_CYCLES||(!head_start&&head_fault))fault<=1;
    if(norm_valid)begin
     if(norm_sealed||(norm_address!==norm_count)||norm_count>=49664||
        (norm_count<194&&!head_feature_ready))fault<=1;
     else norm_count<=norm_count+1'b1;
    end
    if(norm_done)begin
     if(norm_sealed||norm_count+((norm_valid&&(norm_address===norm_count))?16'd1:16'd0)!=49664)fault<=1;
     else norm_sealed<=1;
    end
    if(page_request&&page_request_ready)requested_page<=1;
    if(correct_page)requested_page<=0;
    if(cache_read)word_pending<=1;
    if(word_pending&&cache_read_valid)begin
     word_pending<=0;
     if(!correct_page)fault<=1;
     else if(!bias_loaded)begin
      if(bias_fill==104)begin bias_loaded<=1;bias_fill<=0;end
      else bias_fill<=bias_fill+1'b1;
     end else begin weight_word<=logical_word;weight_held<=1;end
    end
    if(feed_bias&&head_bias_ready)bias_class<=bias_class+1'b1;
    if(feed_weight&&head_weight_ready)begin weight_held<=0;weight_count<=weight_count+1'b1;end
    if(norm_sealed&&head_done&&!head_fault&&weight_count==20370&&bias_class==105)finished<=1;
   end else if(norm_valid||norm_done)fault<=1;
  end
 end
endmodule
