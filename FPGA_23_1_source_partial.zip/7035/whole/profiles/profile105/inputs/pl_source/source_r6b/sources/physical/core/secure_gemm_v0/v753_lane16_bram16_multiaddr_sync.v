`timescale 1ns/1ps

module v753_lane16_bram16_multiaddr_sync #(
    parameter ADDR_W = 14,
    parameter DEPTH  = 9408,
    parameter FIT_MAX_DEPTH = 2048
) (
    input  wire                    clk,
    input  wire [15:0]             wr_lane_en,
    input  wire [ADDR_W-1:0]       wr_addr,
    input  wire [15:0]             wr_data,
    input  wire                    rd_en,
    input  wire [16*ADDR_W-1:0]    rd_addr_flat,
    output wire [255:0]            rd_data
);

genvar gi;
generate
    for (gi = 0; gi < 16; gi = gi + 1) begin : g_lane
        wire [15:0] lane_rd_data;
        v714_bram_sdp_sync #(
            .DATA_W(16),
            .ADDR_W(ADDR_W),
            .DEPTH(DEPTH),
            .FIT_MAX_DEPTH(FIT_MAX_DEPTH)
        ) u_lane_bram (
            .clk(clk),
            .wr_en(wr_lane_en[gi]),
            .wr_addr(wr_addr),
            .wr_data(wr_data),
            .rd_en(rd_en),
            .rd_addr(rd_addr_flat[16*ADDR_W - gi*ADDR_W - 1 -: ADDR_W]),
            .rd_data(lane_rd_data)
        );

        assign rd_data[255 - gi*16 -: 16] = lane_rd_data;
    end
endgenerate

endmodule
