`timescale 1ns/1ps
// Trusted producer -> private inter-block state. No PS write port exists.
// start, seed_mode, coefficient and epoch MUST be owned by the PL sequencer.
// seed_mode preserves the frontend's B00 zero-padding rule; later Norm1 uses
// actual rows 197..199, exactly as the frozen PS make_input implementation.
module npu_vit_private_handoff (
 input wire clk, rst_n, cancel, authorized,
 input wire [31:0] session_epoch,
 input wire start, seed_mode,
 input wire signed [31:0] pose_coefficient,
 input wire pose_valid, pose_done,
 input wire [15:0] pose_address,
 input wire signed [15:0] pose_data,
 input wire norm_valid, norm_done,
 input wire [15:0] norm_address,
 input wire signed [15:0] norm_data,
 output wire ready,
 output reg fault,
 // One 256-bit beat, matching the original reversed pack16 lane ordering.
 input wire read_valid, read_pose,
 input wire [11:0] read_beat,
 output wire read_ready,
 output wire result_valid,
 input wire result_ready,
 output wire [255:0] result_data
);
 reg active, sealed, seed, pose_end, norm_end;
 reg [31:0] epoch;
 reg signed [31:0] coef;
 reg [15:0] pose_count, norm_count;
 reg product_valid;
 reg signed [47:0] product;
 reg [15:0] product_address;
 // Separate arithmetic saturation from the wide physical RAM distribution.
 reg clipped_valid;
 reg signed [15:0] clipped_data;
 reg [15:0] clipped_address;
 wire [18:0] bank_write_pending;
 wire pose_write_pending=product_valid||clipped_valid||(|bank_write_pending);
 wire signed [47:0] shifted=product>>>29;
 wire signed [15:0] clipped=shifted>48'sd32767 ? 16'sd32767 :
                                shifted< -48'sd32768 ? -16'sd32768 : shifted[15:0];
 wire live=(authorized===1'b1)&&(session_epoch===epoch);
 wire accept_pose=active&&!sealed&&!pose_end&&!fault&&live&&!cancel&&!start&&pose_valid;
 wire accept_norm=active&&!sealed&&!norm_end&&!fault&&live&&!cancel&&!start&&norm_valid;
 // The FC2 stream emits 4x4 tiles, but its address already names row-major
 // storage. Check that exact producer order instead of trusting addresses.
 reg[15:0]tiled_pose_address;
 reg[5:0]tile_column;
 wire[15:0]expected_pose=seed?pose_count:tiled_pose_address;
 wire pose_ok=accept_pose&&(pose_address===expected_pose)&&
                           pose_count<(seed?16'd37824:16'd49152);
 wire norm_ok=accept_norm&&(norm_address===norm_count)&&norm_count<16'd49664;
 reg[7:0]norm_row,norm_col;
 // RAMs have synchronous reads and no reset loop: both infer BRAM. Validity
 // is reset/revoked; uninitialized or stale cells cannot be read externally.
 reg [15:0] memory_read_address;
 reg memory_read_pose;
 wire signed [15:0] pose_read_data,norm_read_data;
 wire signed [15:0] memory_read_data=memory_read_pose?pose_read_data:norm_read_data;
 wire signed [15:0] pose_bank_data[0:18],norm_bank_data[0:18];
 genvar bank;
 generate for(bank=0;bank<19;bank=bank+1)begin: private_banks
  // Explicit 2048x16 banks avoid Vivado rounding each 38k array to 64k.
  (* ram_style="block" *) reg signed [15:0] pose_ram[0:2047];
  (* ram_style="block" *) reg signed [15:0] norm_ram[0:2047];
  reg signed [15:0] p_read,n_read;
  // A local registered write port keeps the final data-to-BRAM path inside
  // this bank. Data/address need no reset; the validity is revoked atomically.
  reg bank_write_valid;
  reg signed [15:0] bank_write_data;
  reg [10:0] bank_write_address;
  assign bank_write_pending[bank]=bank_write_valid;
  always @(posedge clk)begin
   if(!rst_n||cancel||!live||fault||start) bank_write_valid<=0;
   else begin
    bank_write_valid<=clipped_valid&&(clipped_address[15:11]==bank);
    if(clipped_valid&&clipped_address[15:11]==bank)begin
     bank_write_data<=clipped_data;bank_write_address<=clipped_address[10:0];
    end
   end
  end
  always @(posedge clk)begin
   if(bank_write_valid&&live&&!fault&&!cancel&&!start&&rst_n)
    pose_ram[bank_write_address]<=bank_write_data;
   p_read<=pose_ram[memory_read_address[10:0]];
  end
  always @(posedge clk)begin
   if(norm_ok&&norm_address<16'd38800&&norm_address[15:11]==bank)
    norm_ram[norm_address[10:0]]<=(seed&&norm_row>=197&&norm_col<192)?16'sd0:norm_data;
   n_read<=norm_ram[memory_read_address[10:0]];
  end
  assign pose_bank_data[bank]=p_read;
  assign norm_bank_data[bank]=n_read;
 end endgenerate
 assign pose_read_data=pose_bank_data[memory_read_address[15:11]];
 assign norm_read_data=norm_bank_data[memory_read_address[15:11]];
 reg reading, response;
 reg [1:0] read_state;
 reg [4:0] lane;
 reg selected_pose;
 reg [11:0] beat;
 reg [255:0] assembled;
 reg use_constant;
 reg signed [15:0] constant_value;
 wire [15:0] selected_row=(beat/12'd49)*4+{13'd0,lane[3:2]};
 wire [15:0] selected_col=(beat%12'd49)*4+{13'd0,lane[1:0]};
 assign ready=active&&sealed&&!fault&&live&&!cancel&&!start&&rst_n;
 assign read_ready=ready&&!reading&&!response;
 assign result_valid=response&&ready;
 assign result_data=result_valid?assembled:256'd0;
 always @(posedge clk) begin
  if(!rst_n) begin
   active<=0;sealed<=0;seed<=0;pose_end<=0;norm_end<=0;epoch<=0;coef<=0;
   pose_count<=0;norm_count<=0;tiled_pose_address<=0;tile_column<=0;norm_row<=0;norm_col<=0;product_valid<=0;clipped_valid<=0;product<=0;product_address<=0;clipped_data<=0;clipped_address<=0;
   reading<=0;response<=0;read_state<=0;lane<=0;selected_pose<=0;beat<=0;
   assembled<=0;memory_read_address<=0;memory_read_pose<=0;fault<=0;
   use_constant<=0;constant_value<=0;
  end else if(cancel||(active&&!live)) begin
   active<=0;sealed<=0;product_valid<=0;clipped_valid<=0;reading<=0;response<=0;fault<=1;
  end else if(start) begin
   // A fresh generation can replace only an idle/sealed generation. Active
   // collection or outstanding reads cannot be overwritten by another start.
   if((authorized!==1'b1)||(active&&!sealed)||reading||response) begin
    active<=0;sealed<=0;product_valid<=0;clipped_valid<=0;reading<=0;response<=0;fault<=1;
   end else begin
    active<=1;sealed<=0;seed<=seed_mode;epoch<=session_epoch;coef<=pose_coefficient;
    pose_end<=0;norm_end<=0;pose_count<=0;norm_count<=0;tiled_pose_address<=0;tile_column<=0;norm_row<=0;norm_col<=0;product_valid<=0;clipped_valid<=0;fault<=0;
   end
  end else if(fault) begin
   active<=0;sealed<=0;product_valid<=0;clipped_valid<=0;reading<=0;response<=0;
  end else begin
   product_valid<=0;clipped_valid<=product_valid;
   if(product_valid)begin clipped_data<=clipped;clipped_address<=product_address;end
   if(active&&!sealed) begin
    if(pose_valid) begin
     if(!pose_ok) fault<=1;
     else begin
      pose_count<=pose_count+1'b1;
      // Exact 4x4 tile order, avoiding general divide/remainder logic.
      if(pose_count[1:0]!=3)tiled_pose_address<=tiled_pose_address+1'b1;
      else if(pose_count[3:2]!=3)tiled_pose_address<=tiled_pose_address+16'd189;
      else if(tile_column==47)begin tiled_pose_address<=tiled_pose_address+1'b1;tile_column<=0;end
      else begin tiled_pose_address<=tiled_pose_address-16'd575;tile_column<=tile_column+1'b1;end
      if(pose_address<37824) begin
       product_valid<=1;product<=pose_data*coef;product_address<=pose_address;
      end
     end
    end
    if(norm_valid) begin
     if(!norm_ok) fault<=1;
     else begin
      norm_count<=norm_count+1'b1;
      if(norm_col==193)begin norm_col<=0;norm_row<=norm_row+1'b1;end else norm_col<=norm_col+1'b1;
     end
    end
    if(pose_done) begin
     if(pose_end||pose_count+(pose_ok?16'd1:16'd0)!=(seed?16'd37824:16'd49152)) fault<=1;
     else pose_end<=1;
    end
    if(norm_done) begin
     if(norm_end||norm_count+(norm_ok?16'd1:16'd0)!=16'd49664) fault<=1;
     else norm_end<=1;
    end
    if(pose_end&&norm_end&&!pose_write_pending) sealed<=1;
   end else if(active&&(pose_valid||norm_valid||pose_done||norm_done)) fault<=1;
   if(response&&result_ready) response<=0;
   if(read_valid&&read_ready) begin
    if((read_pose!==1'b0&&read_pose!==1'b1)||
       (^read_beat===1'bx)||read_beat>=(read_pose?12'd2364:12'd2450)) fault<=1;
    else begin
     reading<=1;read_state<=0;lane<=0;beat<=read_beat;selected_pose<=read_pose;
     assembled<=0;
    end
   end
   if(reading) begin
    case(read_state)
     0: begin
      memory_read_pose<=selected_pose;
      memory_read_address<=selected_pose?{beat,lane[3:0]}:
                           selected_col>=194?16'd0:selected_row*16'd194+selected_col;
      use_constant<=!selected_pose&&selected_col>=194;
      constant_value<=selected_col==194?16'sd16384:16'sd1;
      read_state<=1;
     end
     1: read_state<=2; // synchronous RAM read completes here
     2: begin
      assembled[255-lane*16 -:16]<=use_constant?constant_value:memory_read_data;
      if(lane==15) begin reading<=0;response<=1;end
      else begin lane<=lane+1'b1;read_state<=0;end
     end
     default: begin fault<=1;reading<=0;response<=0;end
    endcase
   end
  end
 end
endmodule
