`timescale 1ns/1ps
// Inputs must be wired directly to the fixed-key PL verifier, not CPU registers.
// This authorizes a static model package only; it does not authorize descriptors,
// intermediate tensors, classifier results or FPGA reconfiguration.
module npu_model_authority_v2 #(
 parameter [63:0] MODEL_ID=64'h4e50554156533031,
 parameter [63:0] MIN_VERSION=64'd4,
 parameter [31:0] BLOB_BASE=32'h30000000,
 parameter [31:0] BLOB_BYTES=32'd100626432,
 parameter [255:0] POLICY_SHA256=256'h4d7a781e0a105a8ec5945d9906c0e6197d1132639ba44096f509f8b80828fafa
, parameter integer PRIVATE_AUTH_COFACTOR=0)(input wire clk,rst_n,
 input wire verify_begin,revoke,verification_done,signature_valid,
 input wire [7:0] verification_error,input wire [767:0] verified_message,
 output wire model_authorized,output reg [255:0] model_root,
 output reg [63:0] model_version,output reg [31:0] session_epoch,
 output reg policy_done,output reg [7:0] policy_error,
 output wire control_policy_authority_ff,
 input wire private_verify_begin,private_revoke,output wire private_model_authorized
);
wire private_authorized_expression;

 reg pending,authorized;reg [63:0] highest_version;
 // revoke is a held denial level; verify_begin is a trusted accepted-request
 // event from manifest_start && manifest_ready. Do not edge-detect their OR:
 // revoke->accepted verify without an idle edge and adjacent accepted begins
 // must each retain their own epoch event. Cancellation wins simultaneous start.
 reg revoke_seen;
 wire revoke_event=revoke&&!revoke_seen;
 wire verify_event=verify_begin&&!revoke;
 wire epoch_event=revoke_event||verify_event;
 always @(posedge clk)begin
  if(!rst_n)revoke_seen<=0;
  else revoke_seen<=revoke;
 end
 wire [63:0] candidate_version=verified_message[639:576];
 wire format_ok=verified_message[767:736]==32'h4e534d31 &&
                verified_message[735:720]==16'd1 && verified_message[719:704]==16'd0;
 wire policy_ok=format_ok && verified_message[703:640]==MODEL_ID &&
                candidate_version>=MIN_VERSION && candidate_version>=highest_version &&
                verified_message[575:544]==BLOB_BASE && verified_message[543:512]==BLOB_BYTES &&
                verified_message[511:256]!=0 && verified_message[255:0]==POLICY_SHA256;
 // Immediate revocation also blocks a consumer on the same clock edge as START.
 assign control_policy_authority_ff=authorized;
 assign model_authorized=rst_n && authorized && !verify_begin && !revoke;
 always @(posedge clk)begin
  if(!rst_n)begin
   pending<=0;authorized<=0;model_root<=0;model_version<=0;highest_version<=MIN_VERSION;
   session_epoch<=0;policy_done<=0;policy_error<=0;
  end else if(revoke || verify_begin)begin
   pending<=verify_begin&&!revoke;authorized<=0;model_root<=0;model_version<=0;
   policy_done<=revoke;policy_error<=revoke?8'hc1:0;
   // Saturate rather than wrap. A reset requires a new verified manifest.
   if(epoch_event)begin
    if(session_epoch!=32'hffffffff)session_epoch<=session_epoch+1'b1;
    else begin pending<=0;policy_done<=1;policy_error<=8'hc2;end
   end else if(session_epoch==32'hffffffff&&policy_error==8'hc2)begin
    // A later held revoke must not overwrite exhausted C2 with ordinary C1.
    pending<=0;policy_done<=1;policy_error<=8'hc2;
   end
  end else if(verification_done && pending)begin
   pending<=0;policy_done<=1;authorized<=0;model_root<=0;model_version<=0;
   if(signature_valid!==1'b1 || verification_error!==8'h00)policy_error<=8'hc3;
   else if(policy_ok!==1'b1)policy_error<=8'hc4;
   else begin
    authorized<=1;model_root<=verified_message[511:256];model_version<=candidate_version;
    highest_version<=candidate_version;policy_error<=0;
   end
  end
 end
 // highest_version is only session-local. Cold-boot rollback floor is the
 // configuration parameter MIN_VERSION; no persistent anti-rollback claim.

assign private_authorized_expression=rst_n && authorized && !private_verify_begin && !private_revoke;
assign private_model_authorized=PRIVATE_AUTH_COFACTOR!=0?private_authorized_expression:model_authorized;
endmodule
