`timescale 1ns/1ps
// Comparison-only observer. Golden data has no output port and cannot reach DUT.
// norm3_* must be the actual sequence-selected block Norm3 stream, excluding
// frontend first Norm1, never a PS snapshot or synthetic replay stream.
module full_chain_vit_scoreboard #(
 parameter NORM_FILE="expected_norm3.hex",parameter LOGIT_FILE="expected_head_logits.hex",
 parameter WINNER_FILE="expected_winner.hex",parameter integer DUMP_BINARY=1
)(
 input wire clk,rst_n,start,finish,
 input wire [31:0] camera_id,session_id,frame_id,epoch,roi_index,generation,
 input wire [3:0] block_index,input wire norm3_valid,norm3_done,
 input wire [15:0] norm3_address,norm3_data,
 input wire logit_valid,input wire [7:0] logit_class,input wire [63:0] logit_data,
 input wire result_valid,input wire [7:0] result_class,input wire [63:0] result_logit,
 output reg checked
);
reg [15:0] gold_norm[0:595967];reg [63:0] gold_logit[0:104],gold_winner[0:1];
reg running,winner_seen;integer blocks,values,logits,total,fd_norm,fd_logits;
reg [31:0] bound_camera,bound_session,bound_frame,bound_epoch,bound_roi,bound_generation;
initial begin
 $readmemh(NORM_FILE,gold_norm);$readmemh(LOGIT_FILE,gold_logit);$readmemh(WINNER_FILE,gold_winner);
 fd_norm=0;fd_logits=0;
 if(DUMP_BINARY)begin fd_norm=$fopen("full_chain_actual_norm3.bin","wb");fd_logits=$fopen("full_chain_actual_logits.txt","w");if(!fd_norm||!fd_logits)$fatal(1,"scoreboard dump open");end
end
always @(posedge clk)begin
 if(!rst_n)begin running<=0;winner_seen<=0;checked<=0;blocks<=0;values<=0;logits<=0;total<=0;bound_camera<=0;bound_session<=0;bound_frame<=0;bound_epoch<=0;bound_roi<=0;bound_generation<=0;end
 else begin
  if(start)begin
   if(running)$fatal(1,"scoreboard overlapping actual NN jobs");
   running<=1;winner_seen<=0;checked<=0;blocks<=0;values<=0;logits<=0;total<=0;
   bound_camera<=camera_id;bound_session<=session_id;bound_frame<=frame_id;bound_epoch<=epoch;bound_roi<=roi_index;bound_generation<=generation;
   if(generation==0)$fatal(1,"NN started without authenticated producer generation");
  end
  if(running)begin
   if(camera_id!==bound_camera||session_id!==bound_session||frame_id!==bound_frame||epoch!==bound_epoch||roi_index!==bound_roi||generation!==bound_generation)$fatal(1,"NN context changed during actual compute");
   if(norm3_valid)begin
    if(blocks>=12||block_index!==blocks||norm3_address!==values||values>=49664)$fatal(1,"Norm3 order actual block=%0d/%0d address=%0d/%0d",block_index,blocks,norm3_address,values);
    if(norm3_data!==gold_norm[blocks*49664+values])$fatal(1,"Norm3 int16 diff block=%0d address=%0d actual=%h expected=%h",blocks,values,norm3_data,gold_norm[blocks*49664+values]);
    if(norm3_data[15:8]!==gold_norm[blocks*49664+values][15:8])$fatal(1,"Norm3 high8 diff");
    if(DUMP_BINARY)$fwrite(fd_norm,"%c%c",norm3_data[7:0],norm3_data[15:8]);
    values<=values+1;total<=total+1;
   end
   if(norm3_done)begin
    if(values+(norm3_valid?1:0)!=49664||block_index!==blocks)$fatal(1,"Norm3 block incomplete");
    $display("FULL_CHAIN_TRUE_NORM3_EXACT block=%0d int16=49664 hi8=49664",blocks);
    blocks<=blocks+1;values<=0;
   end
   if(logit_valid)begin
    if(logits>=105||logit_class!==logits||logit_data!==gold_logit[logits])$fatal(1,"True classifier logit diff index=%0d actual=%0d gold=%0d",logits,logit_data,gold_logit[logits]);
    if(DUMP_BINARY)$fdisplay(fd_logits,"%0d %0d",logits,$signed(logit_data));
    logits<=logits+1;
   end
   if(result_valid)begin
    winner_seen<=1;
    if(result_class!==gold_winner[0][7:0]||result_logit!==gold_winner[1])$fatal(1,"True classifier winner diff");
   end
   if(finish)begin
    if(blocks!=12||total!=595968||logits!=105||!(winner_seen||result_valid))$fatal(1,"True NN finish incomplete blocks=%0d total=%0d logits=%0d resultvalid=%b",blocks,total,logits,result_valid);
    checked<=1;running<=0;
    $display("FULL_CHAIN_ACTUAL_VIT_PASS norm3_int16=595968 hi8=595968 logits=105 class=%0d camera=%0d session=%0d original_frame=%0d epoch=%0d ROI=%0d generation=%0d no_reference_override=1",gold_winner[0][7:0],bound_camera,bound_session,bound_frame,bound_epoch,bound_roi,bound_generation);
    if(DUMP_BINARY)begin $fflush(fd_norm);$fflush(fd_logits);end
   end
  end
 end
end
endmodule
