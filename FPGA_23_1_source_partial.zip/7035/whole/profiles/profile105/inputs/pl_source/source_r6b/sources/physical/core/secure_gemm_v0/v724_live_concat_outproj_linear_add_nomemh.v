`timescale 1ns/1ps

module v724_live_concat_outproj_linear_add_nomemh_legacy (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,

    input  wire         a_tile_wr_valid,
    input  wire [11:0]  a_tile_wr_addr,
    input  wire [255:0] a_tile_wr_data,

    input  wire         b_tile_wr_valid,
    input  wire [11:0]  b_tile_wr_addr,
    input  wire [255:0] b_tile_wr_data,

    input  wire         scale_wr_valid,
    input  wire [7:0]   scale_wr_addr,
    input  wire signed [31:0] scale_wr_data,

    input  wire         residual_wr_valid,
    input  wire [15:0]  residual_wr_addr,
    input  wire signed [15:0] residual_wr_data,

    input  wire         start,
    output reg          busy,
    output reg          done,

    output reg          linear_out_valid,
    input  wire         linear_out_ready,
    output reg [15:0]   linear_out_addr,
    output reg signed [15:0] linear_out_data,

    output reg [31:0]   stat_a_writes,
    output reg [31:0]   stat_b_writes,
    output reg [31:0]   stat_scale_writes,
    output reg [31:0]   stat_residual_writes,
    output reg [31:0]   stat_tiles,
    output reg [31:0]   stat_linear_writes,
    output reg [31:0]   stat_errors,
    output reg [31:0]   stat_cycles,
    output reg [4:0]    stat_stage
);

localparam ROWS = 208;
localparam ROWS_REAL = 197;
localparam IN_DIM = 196;
localparam OUT_DIM = 192;
localparam TILE = 4;
localparam ROW_TILES = ROWS / TILE;
localparam K_TILES = IN_DIM / TILE;
localparam OUT_COL_TILES = OUT_DIM / TILE;
localparam A_TILE_DEPTH = ROW_TILES * K_TILES;
localparam B_TILE_DEPTH = K_TILES * OUT_COL_TILES;
localparam OUT_SIZE = ROWS * OUT_DIM;
localparam RESIDUAL_SIZE = ROWS_REAL * OUT_DIM;
localparam TOTAL_GEMM_TILES = ROW_TILES * OUT_COL_TILES * K_TILES;
localparam OUT_ACC_DEPTH = ROW_TILES * OUT_COL_TILES;
localparam RES_ROW_TILES = (ROWS_REAL + TILE - 1) / TILE;
localparam RES_BANK_DEPTH = RES_ROW_TILES * OUT_COL_TILES;

localparam ST_IDLE       = 5'd0;
localparam ST_ACC_RD     = 5'd1;
localparam ST_LOAD       = 5'd2;
localparam ST_FIRE       = 5'd3;
localparam ST_WAIT_PE    = 5'd4;
localparam ST_ACC        = 5'd5;
localparam ST_NEXT       = 5'd6;
localparam ST_QUANT      = 5'd7;
localparam ST_DONE       = 5'd8;
localparam ST_QUANT_RD   = 5'd9;
localparam ST_LOAD_WAIT  = 5'd10;
localparam ST_ACC_WAIT   = 5'd11;
localparam ST_QUANT_WAIT = 5'd12;
localparam ST_LOAD_CAPTURE = 5'd13;

reg signed [31:0] scale_mem [0:OUT_DIM-1];

reg pe_in_valid;
wire pe_in_ready;
wire pe_out_valid;
wire [511:0] pe_c_flat;
wire [31:0] pe_stat_tiles;
reg [255:0] pe_a_flat;
reg [255:0] pe_b_flat;
reg a_tile_rd_en;
reg b_tile_rd_en;
reg [11:0] a_tile_rd_addr_r;
reg [11:0] b_tile_rd_addr_r;
wire [255:0] a_tile_rd_data;
wire [255:0] b_tile_rd_data;
reg residual_rd_en;
reg [11:0] residual_rd_addr_r;
wire [255:0] residual_rd_data;

reg [5:0] rtile;
reg [5:0] ctile;
reg [5:0] ktile;
reg [15:0] clear_idx;
reg [15:0] acc_idx;
reg [15:0] q_idx;
reg [3:0] lane_idx;
reg signed [31:0] acc_read_r;
reg signed [15:0] residual_read_r;
reg signed [31:0] acc_lane0;
reg signed [31:0] acc_lane1;
reg signed [31:0] acc_lane2;
reg signed [31:0] acc_lane3;
reg signed [31:0] acc_lane4;
reg signed [31:0] acc_lane5;
reg signed [31:0] acc_lane6;
reg signed [31:0] acc_lane7;
reg signed [31:0] acc_lane8;
reg signed [31:0] acc_lane9;
reg signed [31:0] acc_lane10;
reg signed [31:0] acc_lane11;
reg signed [31:0] acc_lane12;
reg signed [31:0] acc_lane13;
reg signed [31:0] acc_lane14;
reg signed [31:0] acc_lane15;
reg acc_bank_rd_en;
reg acc_bank_wr_en;
reg [11:0] acc_bank_addr;
reg [511:0] acc_bank_wr_data;
wire [511:0] acc_bank_rd_data;
wire signed [31:0] acc_bank_lane0  = acc_bank_rd_data[511 - 0*32 -: 32];
wire signed [31:0] acc_bank_lane1  = acc_bank_rd_data[511 - 1*32 -: 32];
wire signed [31:0] acc_bank_lane2  = acc_bank_rd_data[511 - 2*32 -: 32];
wire signed [31:0] acc_bank_lane3  = acc_bank_rd_data[511 - 3*32 -: 32];
wire signed [31:0] acc_bank_lane4  = acc_bank_rd_data[511 - 4*32 -: 32];
wire signed [31:0] acc_bank_lane5  = acc_bank_rd_data[511 - 5*32 -: 32];
wire signed [31:0] acc_bank_lane6  = acc_bank_rd_data[511 - 6*32 -: 32];
wire signed [31:0] acc_bank_lane7  = acc_bank_rd_data[511 - 7*32 -: 32];
wire signed [31:0] acc_bank_lane8  = acc_bank_rd_data[511 - 8*32 -: 32];
wire signed [31:0] acc_bank_lane9  = acc_bank_rd_data[511 - 9*32 -: 32];
wire signed [31:0] acc_bank_lane10 = acc_bank_rd_data[511 - 10*32 -: 32];
wire signed [31:0] acc_bank_lane11 = acc_bank_rd_data[511 - 11*32 -: 32];
wire signed [31:0] acc_bank_lane12 = acc_bank_rd_data[511 - 12*32 -: 32];
wire signed [31:0] acc_bank_lane13 = acc_bank_rd_data[511 - 13*32 -: 32];
wire signed [31:0] acc_bank_lane14 = acc_bank_rd_data[511 - 14*32 -: 32];
wire signed [31:0] acc_bank_lane15 = acc_bank_rd_data[511 - 15*32 -: 32];
wire [15:0] q_row_i = q_idx / OUT_DIM[15:0];
wire [15:0] q_col_i = q_idx % OUT_DIM[15:0];
wire [3:0] q_lane_i = {q_row_i[1:0], q_col_i[1:0]};
wire [11:0] q_tile_addr_i = q_row_i[15:2] * OUT_COL_TILES[11:0] + q_col_i[15:2];
wire signed [31:0] acc_q_read =
    (q_lane_i == 4'd0)  ? acc_bank_lane0  :
    (q_lane_i == 4'd1)  ? acc_bank_lane1  :
    (q_lane_i == 4'd2)  ? acc_bank_lane2  :
    (q_lane_i == 4'd3)  ? acc_bank_lane3  :
    (q_lane_i == 4'd4)  ? acc_bank_lane4  :
    (q_lane_i == 4'd5)  ? acc_bank_lane5  :
    (q_lane_i == 4'd6)  ? acc_bank_lane6  :
    (q_lane_i == 4'd7)  ? acc_bank_lane7  :
    (q_lane_i == 4'd8)  ? acc_bank_lane8  :
    (q_lane_i == 4'd9)  ? acc_bank_lane9  :
    (q_lane_i == 4'd10) ? acc_bank_lane10 :
    (q_lane_i == 4'd11) ? acc_bank_lane11 :
    (q_lane_i == 4'd12) ? acc_bank_lane12 :
    (q_lane_i == 4'd13) ? acc_bank_lane13 :
    (q_lane_i == 4'd14) ? acc_bank_lane14 :
                          acc_bank_lane15;
reg signed [63:0] quant_wide;
reg signed [15:0] quant_r;
reg signed [16:0] add_wide;
reg signed [15:0] add_r;
reg [7:0] q_row;
reg [7:0] q_col;
reg [15:0] out_addr_r;

wire [15:0] a_tile_rd_addr = rtile * K_TILES[15:0] + ktile;
wire [15:0] b_tile_rd_addr = ktile * OUT_COL_TILES[15:0] + ctile;
wire [15:0] out_base_addr = (rtile << 2) * OUT_DIM[15:0] + (ctile << 2);
wire [11:0] acc_tile_addr = rtile * OUT_COL_TILES[11:0] + ctile;
wire [15:0] residual_wr_row = residual_wr_addr / OUT_DIM[15:0];
wire [15:0] residual_wr_col = residual_wr_addr % OUT_DIM[15:0];
wire [3:0] residual_wr_lane = {residual_wr_row[1:0], residual_wr_col[1:0]};
wire [11:0] residual_wr_tile_addr = residual_wr_row[15:2] * OUT_COL_TILES[11:0] + residual_wr_col[15:2];
wire a_tile_wr_en_i = a_tile_wr_valid && (a_tile_wr_addr < A_TILE_DEPTH[11:0]);
wire b_tile_wr_en_i = b_tile_wr_valid && (b_tile_wr_addr < B_TILE_DEPTH[11:0]);
wire residual_wr_ok_i = residual_wr_valid && (residual_wr_addr < RESIDUAL_SIZE[15:0]);
wire [15:0] residual_wr_lane_en_i = residual_wr_ok_i ? (16'h0001 << residual_wr_lane) : 16'h0000;
wire [255:0] residual_wr_data_pack_i = {16{residual_wr_data}};
wire signed [15:0] residual_q_read =
    (q_lane_i == 4'd0)  ? $signed(residual_rd_data[255 - 0*16 -: 16])  :
    (q_lane_i == 4'd1)  ? $signed(residual_rd_data[255 - 1*16 -: 16])  :
    (q_lane_i == 4'd2)  ? $signed(residual_rd_data[255 - 2*16 -: 16])  :
    (q_lane_i == 4'd3)  ? $signed(residual_rd_data[255 - 3*16 -: 16])  :
    (q_lane_i == 4'd4)  ? $signed(residual_rd_data[255 - 4*16 -: 16])  :
    (q_lane_i == 4'd5)  ? $signed(residual_rd_data[255 - 5*16 -: 16])  :
    (q_lane_i == 4'd6)  ? $signed(residual_rd_data[255 - 6*16 -: 16])  :
    (q_lane_i == 4'd7)  ? $signed(residual_rd_data[255 - 7*16 -: 16])  :
    (q_lane_i == 4'd8)  ? $signed(residual_rd_data[255 - 8*16 -: 16])  :
    (q_lane_i == 4'd9)  ? $signed(residual_rd_data[255 - 9*16 -: 16])  :
    (q_lane_i == 4'd10) ? $signed(residual_rd_data[255 - 10*16 -: 16]) :
    (q_lane_i == 4'd11) ? $signed(residual_rd_data[255 - 11*16 -: 16]) :
    (q_lane_i == 4'd12) ? $signed(residual_rd_data[255 - 12*16 -: 16]) :
    (q_lane_i == 4'd13) ? $signed(residual_rd_data[255 - 13*16 -: 16]) :
    (q_lane_i == 4'd14) ? $signed(residual_rd_data[255 - 14*16 -: 16]) :
                          $signed(residual_rd_data[255 - 15*16 -: 16]);

always @(posedge clk) begin
    if (scale_wr_valid && (scale_wr_addr < OUT_DIM[7:0]))
        scale_mem[scale_wr_addr] <= scale_wr_data;
end

v718_acc16_lane_bram32_sync #(
    .ADDR_W(12),
    .DEPTH(OUT_ACC_DEPTH),
    .FIT_MAX_DEPTH(OUT_ACC_DEPTH)
) u_acc_bank (
    .clk(clk),
    .wr_en(acc_bank_wr_en),
    .wr_addr(acc_bank_addr),
    .wr_data(acc_bank_wr_data),
    .rd_en(acc_bank_rd_en),
    .rd_addr(acc_bank_addr),
    .rd_data(acc_bank_rd_data)
);

v714_bram_sdp_sync #(
    .DATA_W(256),
    .ADDR_W(12),
    .DEPTH(A_TILE_DEPTH),
    .FIT_MAX_DEPTH(A_TILE_DEPTH)
) u_a_tile_bank (
    .clk(clk),
    .wr_en(a_tile_wr_en_i),
    .wr_addr(a_tile_wr_addr),
    .wr_data(a_tile_wr_data),
    .rd_en(a_tile_rd_en),
    .rd_addr(a_tile_rd_addr_r),
    .rd_data(a_tile_rd_data)
);

v714_bram_sdp_sync #(
    .DATA_W(256),
    .ADDR_W(12),
    .DEPTH(B_TILE_DEPTH),
    .FIT_MAX_DEPTH(B_TILE_DEPTH)
) u_b_tile_bank (
    .clk(clk),
    .wr_en(b_tile_wr_en_i),
    .wr_addr(b_tile_wr_addr),
    .wr_data(b_tile_wr_data),
    .rd_en(b_tile_rd_en),
    .rd_addr(b_tile_rd_addr_r),
    .rd_data(b_tile_rd_data)
);

v719_tile16_lane_bram16_sync #(
    .ADDR_W(12),
    .DEPTH(RES_BANK_DEPTH),
    .FIT_MAX_DEPTH(RES_BANK_DEPTH)
) u_residual_bank (
    .clk(clk),
    .wr_lane_en(residual_wr_lane_en_i),
    .wr_addr(residual_wr_tile_addr),
    .wr_data(residual_wr_data_pack_i),
    .rd_en(residual_rd_en),
    .rd_addr(residual_rd_addr_r),
    .rd_data(residual_rd_data)
);

v285_pe4x4_int16_tile_core u_pe (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .in_valid(pe_in_valid),
    .in_ready(pe_in_ready),
    .a_flat(pe_a_flat),
    .b_flat(pe_b_flat),
    .out_valid(pe_out_valid),
    .out_ready(1'b1),
    .c_flat(pe_c_flat),
    .stat_tiles(pe_stat_tiles)
);

always @(posedge clk) begin
    if (!rst_n) begin
        busy <= 1'b0;
        done <= 1'b0;
        linear_out_valid <= 1'b0;
        linear_out_addr <= 16'd0;
        linear_out_data <= 16'sd0;
        stat_a_writes <= 32'd0;
        stat_b_writes <= 32'd0;
        stat_scale_writes <= 32'd0;
        stat_residual_writes <= 32'd0;
        stat_tiles <= 32'd0;
        stat_linear_writes <= 32'd0;
        stat_errors <= 32'd0;
        stat_cycles <= 32'd0;
        stat_stage <= ST_IDLE;
        pe_in_valid <= 1'b0;
        pe_a_flat <= 256'd0;
        pe_b_flat <= 256'd0;
        a_tile_rd_en <= 1'b0;
        b_tile_rd_en <= 1'b0;
        a_tile_rd_addr_r <= 12'd0;
        b_tile_rd_addr_r <= 12'd0;
        residual_rd_en <= 1'b0;
        residual_rd_addr_r <= 12'd0;
        rtile <= 6'd0;
        ctile <= 6'd0;
        ktile <= 6'd0;
        clear_idx <= 16'd0;
        acc_idx <= 16'd0;
        q_idx <= 16'd0;
        lane_idx <= 4'd0;
        acc_read_r <= 32'sd0;
        residual_read_r <= 16'sd0;
        acc_lane0 <= 32'sd0;
        acc_lane1 <= 32'sd0;
        acc_lane2 <= 32'sd0;
        acc_lane3 <= 32'sd0;
        acc_lane4 <= 32'sd0;
        acc_lane5 <= 32'sd0;
        acc_lane6 <= 32'sd0;
        acc_lane7 <= 32'sd0;
        acc_lane8 <= 32'sd0;
        acc_lane9 <= 32'sd0;
        acc_lane10 <= 32'sd0;
        acc_lane11 <= 32'sd0;
        acc_lane12 <= 32'sd0;
        acc_lane13 <= 32'sd0;
        acc_lane14 <= 32'sd0;
        acc_lane15 <= 32'sd0;
        acc_bank_rd_en <= 1'b0;
        acc_bank_wr_en <= 1'b0;
        acc_bank_addr <= 12'd0;
        acc_bank_wr_data <= 512'd0;
        quant_wide <= 64'sd0;
        quant_r <= 16'sd0;
        add_wide <= 17'sd0;
        add_r <= 16'sd0;
        q_row <= 8'd0;
        q_col <= 8'd0;
        out_addr_r <= 16'd0;
    end else begin
        done <= 1'b0;
        pe_in_valid <= 1'b0;
        a_tile_rd_en <= 1'b0;
        b_tile_rd_en <= 1'b0;
        residual_rd_en <= 1'b0;

        if (linear_out_valid && linear_out_ready)
            linear_out_valid <= 1'b0;

        if (busy)
            stat_cycles <= stat_cycles + 1'b1;

        acc_bank_rd_en <= 1'b0;
        acc_bank_wr_en <= 1'b0;

        if (clear) begin
            busy <= 1'b0;
            done <= 1'b0;
            linear_out_valid <= 1'b0;
            stat_a_writes <= 32'd0;
            stat_b_writes <= 32'd0;
            stat_scale_writes <= 32'd0;
            stat_residual_writes <= 32'd0;
            stat_tiles <= 32'd0;
            stat_linear_writes <= 32'd0;
            stat_errors <= 32'd0;
            stat_cycles <= 32'd0;
            stat_stage <= ST_IDLE;
        end else begin
            if (a_tile_wr_valid) begin
                if (a_tile_wr_addr < A_TILE_DEPTH[11:0]) begin
                    stat_a_writes <= stat_a_writes + 1'b1;
                end else begin
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            if (b_tile_wr_valid) begin
                if (b_tile_wr_addr < B_TILE_DEPTH[11:0]) begin
                    stat_b_writes <= stat_b_writes + 1'b1;
                end else begin
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            if (scale_wr_valid) begin
                if (scale_wr_addr < OUT_DIM[7:0]) begin
                    stat_scale_writes <= stat_scale_writes + 1'b1;
                end else begin
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            if (residual_wr_valid) begin
                if (residual_wr_addr < RESIDUAL_SIZE[15:0]) begin
                    stat_residual_writes <= stat_residual_writes + 1'b1;
                end else begin
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            case (stat_stage)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        rtile <= 6'd0;
                        ctile <= 6'd0;
                        ktile <= 6'd0;
                        clear_idx <= 16'd0;
                        q_idx <= 16'd0;
                        q_row <= 8'd0;
                        q_col <= 8'd0;
                        stat_tiles <= 32'd0;
                        stat_linear_writes <= 32'd0;
                        stat_cycles <= 32'd0;
                        stat_stage <= ST_LOAD;
                    end
                end

                ST_LOAD: begin
                    a_tile_rd_en <= 1'b1;
                    b_tile_rd_en <= 1'b1;
                    a_tile_rd_addr_r <= a_tile_rd_addr[11:0];
                    b_tile_rd_addr_r <= b_tile_rd_addr[11:0];
                    stat_stage <= ST_LOAD_WAIT;
                end

                ST_LOAD_WAIT: begin
                    stat_stage <= ST_LOAD_CAPTURE;
                end

                ST_LOAD_CAPTURE: begin
                    pe_a_flat <= a_tile_rd_data;
                    pe_b_flat <= b_tile_rd_data;
                    stat_stage <= ST_FIRE;
                end

                ST_FIRE: begin
                    if (pe_in_ready) begin
                        pe_in_valid <= 1'b1;
                        stat_stage <= ST_WAIT_PE;
                    end
                end

                ST_WAIT_PE: begin
                    if (pe_out_valid) begin
                        acc_idx <= {4'd0, acc_tile_addr};
                        acc_bank_rd_en <= 1'b1;
                        acc_bank_addr <= acc_tile_addr;
                        stat_stage <= ST_ACC_WAIT;
                    end
                end

                ST_ACC_WAIT: begin
                    stat_stage <= ST_ACC_RD;
                end

                ST_ACC_RD: begin
                        if (ktile == 6'd0) begin
                            acc_lane0 <= 32'sd0;
                            acc_lane1 <= 32'sd0;
                            acc_lane2 <= 32'sd0;
                            acc_lane3 <= 32'sd0;
                            acc_lane4 <= 32'sd0;
                            acc_lane5 <= 32'sd0;
                            acc_lane6 <= 32'sd0;
                            acc_lane7 <= 32'sd0;
                            acc_lane8 <= 32'sd0;
                            acc_lane9 <= 32'sd0;
                            acc_lane10 <= 32'sd0;
                            acc_lane11 <= 32'sd0;
                            acc_lane12 <= 32'sd0;
                            acc_lane13 <= 32'sd0;
                            acc_lane14 <= 32'sd0;
                            acc_lane15 <= 32'sd0;
                        end else begin
                            acc_lane0 <= acc_bank_lane0;
                            acc_lane1 <= acc_bank_lane1;
                            acc_lane2 <= acc_bank_lane2;
                            acc_lane3 <= acc_bank_lane3;
                            acc_lane4 <= acc_bank_lane4;
                            acc_lane5 <= acc_bank_lane5;
                            acc_lane6 <= acc_bank_lane6;
                            acc_lane7 <= acc_bank_lane7;
                            acc_lane8 <= acc_bank_lane8;
                            acc_lane9 <= acc_bank_lane9;
                            acc_lane10 <= acc_bank_lane10;
                            acc_lane11 <= acc_bank_lane11;
                            acc_lane12 <= acc_bank_lane12;
                            acc_lane13 <= acc_bank_lane13;
                            acc_lane14 <= acc_bank_lane14;
                            acc_lane15 <= acc_bank_lane15;
                        end
                        stat_stage <= ST_ACC;
                end

                ST_ACC: begin
                    acc_bank_wr_en <= 1'b1;
                    acc_bank_addr <= acc_tile_addr;
                    acc_bank_wr_data <= {
                        acc_lane0  + pe_c_flat[511 - 0*32 -: 32],
                        acc_lane1  + pe_c_flat[511 - 1*32 -: 32],
                        acc_lane2  + pe_c_flat[511 - 2*32 -: 32],
                        acc_lane3  + pe_c_flat[511 - 3*32 -: 32],
                        acc_lane4  + pe_c_flat[511 - 4*32 -: 32],
                        acc_lane5  + pe_c_flat[511 - 5*32 -: 32],
                        acc_lane6  + pe_c_flat[511 - 6*32 -: 32],
                        acc_lane7  + pe_c_flat[511 - 7*32 -: 32],
                        acc_lane8  + pe_c_flat[511 - 8*32 -: 32],
                        acc_lane9  + pe_c_flat[511 - 9*32 -: 32],
                        acc_lane10 + pe_c_flat[511 - 10*32 -: 32],
                        acc_lane11 + pe_c_flat[511 - 11*32 -: 32],
                        acc_lane12 + pe_c_flat[511 - 12*32 -: 32],
                        acc_lane13 + pe_c_flat[511 - 13*32 -: 32],
                        acc_lane14 + pe_c_flat[511 - 14*32 -: 32],
                        acc_lane15 + pe_c_flat[511 - 15*32 -: 32]
                    };
                    stat_tiles <= stat_tiles + 1'b1;
                    stat_stage <= ST_NEXT;
                end

                ST_NEXT: begin
                    if (ktile < K_TILES[5:0] - 1'b1) begin
                        ktile <= ktile + 1'b1;
                        stat_stage <= ST_LOAD;
                    end else begin
                        ktile <= 6'd0;
                        if (ctile < OUT_COL_TILES[5:0] - 1'b1) begin
                            ctile <= ctile + 1'b1;
                            stat_stage <= ST_LOAD;
                        end else begin
                            ctile <= 6'd0;
                            if (rtile < ROW_TILES[5:0] - 1'b1) begin
                                rtile <= rtile + 1'b1;
                                stat_stage <= ST_LOAD;
                            end else begin
                                stat_stage <= ST_QUANT_RD;
                            end
                        end
                    end
                end

                ST_QUANT_RD: begin
                    if (!linear_out_valid) begin
                        q_row <= q_row_i[7:0];
                        q_col <= q_col_i[7:0];
                        out_addr_r <= q_idx;
                        acc_bank_rd_en <= 1'b1;
                        acc_bank_addr <= q_tile_addr_i;
                        residual_rd_en <= (q_row_i < ROWS_REAL[15:0]);
                        residual_rd_addr_r <= (q_row_i < ROWS_REAL[15:0]) ? q_tile_addr_i : 12'd0;
                        stat_stage <= ST_QUANT_WAIT;
                    end
                end

                ST_QUANT_WAIT: begin
                    stat_stage <= ST_QUANT;
                end

                ST_QUANT: begin
                    if (!linear_out_valid) begin
                        quant_wide = (acc_q_read * scale_mem[q_col]) >>> 29;
                        if (quant_wide > 64'sd32767)
                            quant_r = 16'sh7fff;
                        else if (quant_wide < -64'sd32768)
                            quant_r = 16'sh8000;
                        else
                            quant_r = quant_wide[15:0];

                        residual_read_r <= (q_row < ROWS_REAL[7:0]) ? residual_q_read : 16'sd0;
                        add_wide = quant_r + ((q_row < ROWS_REAL[7:0]) ? residual_q_read : 16'sd0);

                        if (add_wide > 17'sd32767)
                            add_r = 16'sh7fff;
                        else if (add_wide < -17'sd32768)
                            add_r = 16'sh8000;
                        else
                            add_r = add_wide[15:0];

                        linear_out_valid <= 1'b1;
                        linear_out_addr <= out_addr_r;
                        linear_out_data <= add_r;

                        if (linear_out_ready) begin
                            stat_linear_writes <= stat_linear_writes + 1'b1;
                            if (q_idx == OUT_SIZE[15:0] - 1'b1) begin
                                stat_stage <= ST_DONE;
                            end else begin
                                q_idx <= q_idx + 1'b1;
                                stat_stage <= ST_QUANT_RD;
                            end
                        end
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    stat_stage <= ST_IDLE;
                end

                default: begin
                    stat_stage <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule
