`timescale 1ns/1ps
// Independent edge-time observer. It has no authority, job, result or DDR outputs.
// Connect snapshot inputs to the actual metrics instance, not another model.
module full_chain_metrics_scoreboard(
 input wire clk,security_reset_n,authorization_live,
 input wire frame_start,ingress_done,yolo_start,yolo_done,
 input wire frontend_start,nn_start,head_start,nn_done,
 input wire [31:0] roi_index,input wire record_commit,abort,
 input wire page_input_wait,mac_busy,pool_wait,
 input wire snapshot_valid,measurement_fault,
 input wire [63:0] total_cycles,ingress_cycles,yolo_cycles,
 input wire [255:0] frontend_cycles,nn_cycles,head_cycles,
 input wire [63:0] page_input_wait_cycles,mac_busy_cycles,pool_wait_cycles,
 input wire [3:0] roi_measured,output reg checked
);
longint unsigned clock_edge,frame_edge,yolo_edge,frontend_edge[0:3],nn_edge[0:3],head_edge[0:3];
longint unsigned gold_total,gold_ingress,gold_yolo,gold_frontend[0:3],gold_nn[0:3],gold_head[0:3];
longint unsigned gold_page_wait,gold_mac_busy,gold_pool_wait;
reg active,pending,ingress_open,yolo_open,nn_open,ingress_armed,yolo_armed,nn_armed;
reg accepted_ingress_end,accepted_yolo_end,accepted_nn_end;reg [3:0] gold_roi;integer i;
always @(posedge clk)begin
 if(!security_reset_n)begin
  clock_edge=0;frame_edge=0;yolo_edge=0;active=0;pending=0;checked=0;ingress_open=0;yolo_open=0;nn_open=0;ingress_armed=0;yolo_armed=0;nn_armed=0;accepted_ingress_end=0;accepted_yolo_end=0;accepted_nn_end=0;
  gold_total=0;gold_ingress=0;gold_yolo=0;gold_roi=0;
  gold_page_wait=0;gold_mac_busy=0;gold_pool_wait=0;
  for(i=0;i<4;i=i+1)begin frontend_edge[i]=0;nn_edge[i]=0;head_edge[i]=0;gold_frontend[i]=0;gold_nn[i]=0;gold_head[i]=0;end
 end else begin
  clock_edge=clock_edge+1;
  if(abort||!authorization_live)begin active=0;pending=0;checked=0;ingress_open=0;yolo_open=0;nn_open=0;end
  else if(frame_start)begin
   if(active)$fatal(1,"metrics observer overlapping frame");
   active=1;pending=0;checked=0;frame_edge=clock_edge;gold_total=0;gold_ingress=0;gold_yolo=0;gold_roi=0;ingress_open=1;ingress_armed=!ingress_done;yolo_open=0;nn_open=0;
   gold_page_wait=0;gold_mac_busy=0;gold_pool_wait=0;
   for(i=0;i<4;i=i+1)begin gold_frontend[i]=0;gold_nn[i]=0;gold_head[i]=0;end
  end else if(active)begin
   accepted_ingress_end=ingress_open&&ingress_armed&&ingress_done;
   accepted_yolo_end=yolo_open&&yolo_armed&&yolo_done;
   accepted_nn_end=nn_open&&nn_armed&&nn_done;
   if(ingress_open&&!ingress_done)ingress_armed=1;
   if(yolo_open&&!yolo_done)yolo_armed=1;
   if(nn_open&&!nn_done)nn_armed=1;
   if(page_input_wait)gold_page_wait=gold_page_wait+1;
   if(mac_busy)gold_mac_busy=gold_mac_busy+1;
   if(pool_wait)gold_pool_wait=gold_pool_wait+1;
   if(accepted_ingress_end)begin gold_ingress=clock_edge-frame_edge;ingress_open=0;end
   if(yolo_start)begin yolo_edge=clock_edge;yolo_open=1;yolo_armed=!yolo_done;end
   if(accepted_yolo_end)begin gold_yolo=clock_edge-yolo_edge;yolo_open=0;end
   if(frontend_start||nn_start||head_start||accepted_nn_end)begin
    if(roi_index>=4)$fatal(1,"metrics observer invalid ROI=%0d",roi_index);
    if(frontend_start)frontend_edge[roi_index]=clock_edge;
    if(nn_start)begin gold_frontend[roi_index]=clock_edge-frontend_edge[roi_index];nn_edge[roi_index]=clock_edge;nn_open=1;nn_armed=!nn_done;end
    if(head_start)head_edge[roi_index]=clock_edge;
    if(accepted_nn_end)begin gold_nn[roi_index]=clock_edge-nn_edge[roi_index];gold_head[roi_index]=clock_edge-head_edge[roi_index];gold_roi[roi_index]=1;nn_open=0;end
   end
   if(record_commit)begin
    if(accepted_ingress_end||yolo_start||accepted_yolo_end||frontend_start||nn_start||head_start||accepted_nn_end)$fatal(1,"metrics record commit overlaps accepted stage event");
    gold_total=clock_edge-frame_edge;active=0;pending=1;
   end
  end
 end
end
always @(negedge clk)begin
 if(security_reset_n&&pending)begin
  if(!snapshot_valid||measurement_fault)$fatal(1,"real metrics did not publish valid independent snapshot");
  if(total_cycles!==gold_total||ingress_cycles!==gold_ingress||yolo_cycles!==gold_yolo||roi_measured!==gold_roi)$fatal(1,"real metrics phase interval/ROI mismatch total=%0d/%0d ingress=%0d/%0d YOLO=%0d/%0d ROI=%h/%h",total_cycles,gold_total,ingress_cycles,gold_ingress,yolo_cycles,gold_yolo,roi_measured,gold_roi);
  if(page_input_wait_cycles!==gold_page_wait||mac_busy_cycles!==gold_mac_busy||pool_wait_cycles!==gold_pool_wait)$fatal(1,"real metrics overlapping wait counters mismatch");
  for(i=0;i<4;i=i+1)begin
   if(frontend_cycles[i*64+:64]!==gold_frontend[i]||nn_cycles[i*64+:64]!==gold_nn[i]||head_cycles[i*64+:64]!==gold_head[i])$fatal(1,"real metrics ROI%0d intervals mismatch",i);
   if(gold_roi[i])$display("FULL_CHAIN_REAL_METRICS_ROI_EDGE_EXACT ROI=%0d frontend=%0d NN_including_head=%0d head_subset=%0d",i,gold_frontend[i],gold_nn[i],gold_head[i]);
  end
  $display("FULL_CHAIN_REAL_METRICS_EDGE_EXACT total=%0d ingress=%0d YOLO=%0d ROI_mask=%h wait_page=%0d mac_busy=%0d pool_wait=%0d",gold_total,gold_ingress,gold_yolo,gold_roi,gold_page_wait,gold_mac_busy,gold_pool_wait);
  checked=1;pending=0;
 end
end
endmodule
