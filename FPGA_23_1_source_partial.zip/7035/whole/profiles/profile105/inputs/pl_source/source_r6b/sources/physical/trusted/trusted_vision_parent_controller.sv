`timescale 1ns/1ps
// Security-domain lifecycle only: real sealed ingress -> whole YOLO/NMS ->
// per-ROI frontend+actual ViT consumer -> one atomic private PL result commit.
// No child completion timer, no PS configuration, no memory or crypto core.
module trusted_vision_parent_controller #(
 parameter integer CLASS_COUNT=105,
 parameter [31:0] CAMERA_ID=32'd0,
 // Independent whole-frame budget; frozen child watchdogs remain 1B each.
 parameter [63:0] FRAME_TIMEOUT_CYCLES=64'd6000000000
)(
 input wire clk,rst_n,authorized,key_valid,job_cancel,
 input wire [31:0] authorization_epoch,
 input wire job_valid,output wire job_ready,
 input wire [31:0] job_camera_id,job_session,job_frame,job_epoch,
 output wire active,quiescent,actors_quiescent,output wire [63:0] frame_elapsed_cycles,output reg job_done,job_failed,
 output reg [7:0] failure_code,
 output reg [31:0] bound_camera,bound_session,bound_frame,bound_epoch,
 // Child quiet is real AXI/lease/MAC/compute quiescence, not just !active.
 input wire resources_quiescent,
 output wire yolo_valid,input wire yolo_ready,
 output wire yolo_cancel,input wire yolo_active,yolo_done,yolo_failed,yolo_quiescent,
 input wire [31:0] yolo_result_session,yolo_result_frame,yolo_result_epoch,
 input wire [2:0] yolo_selected_count,
 input wire [895:0] yolo_selected_data,input wire [51:0] yolo_selected_indices,
 output wire frontend_valid,input wire frontend_ready,
 output wire frontend_cancel,input wire frontend_active,frontend_done,frontend_failed,frontend_quiescent,
 output wire [31:0] frontend_roi_index,
 output wire [15:0] frontend_x,frontend_y,frontend_width,frontend_height,
 input wire [31:0] frontend_camera,frontend_session,frontend_frame,frontend_epoch,
 input wire [31:0] frontend_result_roi,frontend_generation,
 input wire [15:0] frontend_result_x,frontend_result_y,frontend_result_width,frontend_result_height,
 input wire [7:0] frontend_class,input wire [63:0] frontend_logit,
 // ready must mean an actual atomic trusted PL register commit (or authenticated
 // data+tag commit), never a PS acknowledgment. No record appears before all ROIs.
 output wire record_valid,input wire record_ready,
 output wire [2:0] record_count,output wire [895:0] record_rois,
 output wire [51:0] record_indices,output wire [511:0] record_results
);
localparam IDLE=0,Y_OFFER=1,Y_RUN=2,Y_DRAIN=3,F_OFFER=4,F_RUN=5,F_DRAIN=6,COMMIT=7,FINISH=8,ABORT=9;
reg [3:0] state;
reg [63:0] elapsed;
reg [31:0] last_generation;
reg [2:0] count;
reg [1:0] slot;
reg [895:0] rois;
reg [51:0] indices;
reg [511:0] results;
reg seen_active,terminal_seen;
wire live=authorized&&key_valid&&!job_cancel&&authorization_epoch==bound_epoch;
wire admission_live=live&&elapsed<FRAME_TIMEOUT_CYCLES;
wire all_quiet=yolo_quiescent&&frontend_quiescent&&resources_quiescent;
wire [223:0] roi=rois[slot*224+:224];
wire [15:0] rx=roi[175:160],ry=roi[207:192];
wire [15:0] rw=roi[191:176]-roi[175:160],rh=roi[223:208]-roi[207:192];
assign active=state!=IDLE;
assign frame_elapsed_cycles=elapsed;
assign quiescent=state==IDLE&&all_quiet;
// Independent local actor gate; public quiescent still requires all resources.
assign actors_quiescent=state==IDLE&&yolo_quiescent&&frontend_quiescent;
assign job_ready=quiescent&&authorized&&key_valid&&!job_cancel&&job_epoch==authorization_epoch&&job_camera_id==CAMERA_ID;
assign yolo_valid=state==Y_OFFER&&admission_live;
assign frontend_valid=state==F_OFFER&&admission_live;
assign yolo_cancel=state==ABORT||state!=IDLE&&!live;
assign frontend_cancel=state==ABORT||state!=IDLE&&!live;
assign frontend_roi_index={30'd0,slot};
assign frontend_x=rx;assign frontend_y=ry;assign frontend_width=rw;assign frontend_height=rh;
assign record_valid=state==COMMIT&&admission_live;
assign record_count=count;assign record_rois=rois;assign record_indices=indices;assign record_results=results;
integer i,j;
reg selection_ok;
reg [223:0] ri;
always @* begin
 selection_ok=yolo_selected_count<=4;
 ri=0;
 for(i=0;i<4;i=i+1)if(i<yolo_selected_count)begin
  ri=yolo_selected_data[i*224+:224];
  if(ri[175:160]>=ri[191:176]||ri[207:192]>=ri[223:208]||ri[191:176]>1920||ri[223:208]>1080||yolo_selected_indices[i*13+:13]>=6300)selection_ok=0;
  for(j=0;j<i;j=j+1)if(yolo_selected_indices[i*13+:13]==yolo_selected_indices[j*13+:13])selection_ok=0;
 end
end
wire frontend_binding_ok=frontend_camera==bound_camera&&frontend_session==bound_session&&frontend_frame==bound_frame&&frontend_epoch==bound_epoch&&frontend_result_roi=={30'd0,slot}&&frontend_result_x==rx&&frontend_result_y==ry&&frontend_result_width==rw&&frontend_result_height==rh&&frontend_generation!=0&&frontend_generation>last_generation&&frontend_class<CLASS_COUNT;
always @(posedge clk)begin
 if(!rst_n)begin
  state<=IDLE;elapsed<=0;count<=0;slot<=0;rois<=0;indices<=0;results<=0;seen_active<=0;terminal_seen<=0;last_generation<=0;
  job_done<=0;job_failed<=0;failure_code<=0;bound_camera<=0;bound_session<=0;bound_frame<=0;bound_epoch<=0;
 end else begin
  job_done<=0;job_failed<=0;
  if(state!=IDLE&&elapsed!=64'hffffffffffffffff)elapsed<=elapsed+1;
  // All same-edge revoke/STOP/timeout combinations dominate done and commit.
  if(state!=IDLE&&state!=ABORT&&(!live||elapsed>=FRAME_TIMEOUT_CYCLES))begin
   state<=ABORT;failure_code<=!live?8'h01:8'h02;
  end else case(state)
   IDLE:if(job_valid&&job_ready)begin
    bound_camera<=job_camera_id;bound_session<=job_session;bound_frame<=job_frame;bound_epoch<=job_epoch;
    state<=Y_OFFER;elapsed<=0;count<=0;slot<=0;rois<=0;indices<=0;results<=0;seen_active<=0;terminal_seen<=0;last_generation<=0;failure_code<=0;
   end
   Y_OFFER:if(yolo_valid&&yolo_ready)begin state<=Y_RUN;seen_active<=0;terminal_seen<=0;end
   Y_RUN:begin
    if(yolo_active)seen_active<=1;
    if(yolo_failed)begin state<=ABORT;failure_code<=8'h10;end
    else if(yolo_done)begin
     if(!seen_active||yolo_result_session!=bound_session||yolo_result_frame!=bound_frame||yolo_result_epoch!=bound_epoch||!selection_ok)begin state<=ABORT;failure_code<=8'h11;end
     else begin count<=yolo_selected_count;rois<=yolo_selected_data;indices<=yolo_selected_indices;state<=Y_DRAIN;terminal_seen<=1;end
    end
   end
   Y_DRAIN:if(yolo_failed)begin state<=ABORT;failure_code<=8'h12;end
    else if(all_quiet)begin state<=count==0?COMMIT:F_OFFER;slot<=0;seen_active<=0;terminal_seen<=0;end
   F_OFFER:if(frontend_valid&&frontend_ready)begin state<=F_RUN;seen_active<=0;terminal_seen<=0;end
   F_RUN:begin
    if(frontend_active)seen_active<=1;
    if(frontend_failed)begin state<=ABORT;failure_code<=8'h20;end
    else if(frontend_done)begin
     if(!seen_active||!frontend_binding_ok)begin state<=ABORT;failure_code<=8'h21;end
     else begin results[slot*128+:128]<={frontend_generation,frontend_class,24'd0,frontend_logit};last_generation<=frontend_generation;terminal_seen<=1;state<=F_DRAIN;end
    end
   end
   F_DRAIN:if(frontend_failed)begin state<=ABORT;failure_code<=8'h22;end
    else if(all_quiet)begin
     if({1'b0,slot}+1>=count)state<=COMMIT;
     else begin slot<=slot+1;state<=F_OFFER;seen_active<=0;terminal_seen<=0;end
    end
   COMMIT:if(record_valid&&record_ready)state<=FINISH;
   FINISH:if(all_quiet)begin job_done<=1;state<=IDLE;end
   ABORT:if(all_quiet)begin job_failed<=1;state<=IDLE;end
   default:begin state<=ABORT;failure_code<=8'hff;end
  endcase
 end
end
endmodule
