`timescale 1ns/1ps

module v719_unified_prob_stream_to_av_tile_bank_nomemh #(
    parameter ROWS = 200,
    parameter COLS = 200,
    parameter TILE = 4,
    parameter TILE_DEPTH = 2500
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire start,
    input  wire [15:0] av_a_tile_base,
    input  wire in_valid,
    output wire in_ready,
    input  wire [15:0] in_addr,
    input  wire signed [15:0] in_data,
    output reg  busy,
    output reg  done,
    output reg [31:0] stat_writes,
    output reg [31:0] stat_tiles_checked,
    output reg [31:0] stat_errors,
    output reg [3:0]  stat_stage,
    input  wire rd_en,
    input  wire [15:0] rd_addr,
    output wire [255:0] rd_data
);

localparam COL_TILES = COLS / TILE;
localparam TOTAL_ELEMS = ROWS * COLS;

localparam ST_IDLE  = 4'd0;
localparam ST_LOAD  = 4'd1;
localparam ST_DONE  = 4'd2;

reg [3:0] state;
wire [15:0] row_i = in_addr / COLS[15:0];
wire [15:0] col_i = in_addr % COLS[15:0];
wire [11:0] tile_wr_addr = (row_i[15:2] * COL_TILES[11:0]) + col_i[15:2];
wire [3:0] tile_wr_lane = {row_i[1:0], col_i[1:0]};
wire [11:0] rd_addr_i = rd_addr[11:0];
wire write_active = (state == ST_LOAD) && in_valid;
wire [15:0] tile_wr_lane_en =
    write_active ? (16'h0001 << tile_wr_lane) : 16'h0000;
wire [255:0] tile_wr_word = {
    in_data, in_data, in_data, in_data,
    in_data, in_data, in_data, in_data,
    in_data, in_data, in_data, in_data,
    in_data, in_data, in_data, in_data
};

assign in_ready = (state == ST_LOAD);

v719_tile16_lane_bram16_sync #(
    .ADDR_W(12),
    .DEPTH(TILE_DEPTH),
    .FIT_MAX_DEPTH(TILE_DEPTH)
) u_tile_bank (
    .clk(clk),
    .wr_lane_en(tile_wr_lane_en),
    .wr_addr(tile_wr_addr),
    .wr_data(tile_wr_word),
    .rd_en(rd_en),
    .rd_addr(rd_addr_i),
    .rd_data(rd_data)
);

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        busy <= 1'b0;
        done <= 1'b0;
        stat_writes <= 32'd0;
        stat_tiles_checked <= 32'd0;
        stat_errors <= 32'd0;
        stat_stage <= ST_IDLE;
    end else begin
        done <= 1'b0;
        stat_stage <= state;
        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
                stat_writes <= 32'd0;
            stat_tiles_checked <= 32'd0;
            stat_errors <= 32'd0;
        end else begin
            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                                        stat_writes <= 32'd0;
                        stat_tiles_checked <= 32'd0;
                        stat_errors <= 32'd0;
                        state <= ST_LOAD;
                    end
                end

                ST_LOAD: begin
                    if (in_valid) begin
                        stat_writes <= stat_writes + 1'b1;
                        if (in_addr == TOTAL_ELEMS[15:0] - 1'b1)
                            state <= ST_DONE;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule

