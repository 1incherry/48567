`timescale 1ns/1ps

// V784: overlap FC1 production with GELU consumption.
//
// FC1 drains one 4x768 row group in tiled order.  Two 4-row ping-pong
// windows retain that order-independent input while GELU processes the older
// group in row-major order.  The arithmetic below is intentionally identical
// to v598_runtime_fc1_gelu_stream_c0; only the storage lifetime and scheduling
// are changed.
module v784_fc1_gelu_rowgroup_pipeline #(
    parameter signed [31:0] CONSTANT_X0 = -32'sd6
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire in_wr_valid,
    input  wire [17:0] in_wr_addr,
    input  wire signed [7:0] in_wr_data,
    input  wire scale_wr_valid,
    input  wire signed [31:0] scale_wr_data,
    input  wire signed [31:0] constant_x0,
    input  wire start,
    output reg  busy,
    output reg  done,
    output reg [31:0] stat_input_writes,
    output reg [31:0] stat_input_errors,
    output reg [31:0] stat_rows,
    output reg [31:0] stat_items,
    output reg [31:0] stat_max_errors,
    output reg [31:0] stat_exp_errors,
    output reg [31:0] stat_gelu_errors,
    output reg        out_valid,
    output reg [17:0] out_addr,
    output reg signed [7:0] out_data,
    input  wire       out_ready,
    output reg [31:0] stat_stream_items,
    output wire [4:0] stat_group_level,
    output reg  [4:0] stat_group_max_level,
    output reg [31:0] stat_input_blocked_cycles,
    output reg [31:0] stat_output_stall_cycles
);

localparam SEQ = 256;
localparam DIM = 768;
localparam ROWS_PER_GROUP = 4;
localparam GROUP_ITEMS = ROWS_PER_GROUP * DIM;
localparam GROUPS = SEQ / ROWS_PER_GROUP;
// The radix-16 GELU path adds bounded per-element latency.  Thirty-two slots
// absorb the resulting FC1/GELU burst skew without requiring an upstream
// ready signal (the legacy stream is valid-only at this boundary).
localparam WINDOW_SLOTS = 32;
localparam SLOT_DEPTH = WINDOW_SLOTS * DIM;
localparam SLOT_ADDR_W = 15;
localparam COUNT = SEQ * DIM;

localparam ST_IDLE             = 5'd0;
localparam ST_FIND_MAX         = 5'd1;
localparam ST_FIND_MAX_WAIT    = 5'd2;
localparam ST_FIND_MAX_CAPTURE = 5'd3;
localparam ST_EXP_PREP         = 5'd4;
localparam ST_EXP_AFFINE       = 5'd5;
localparam ST_EXP_QR           = 5'd6;
localparam ST_EXP_OUT          = 5'd7;
localparam ST_ELEM_LOAD        = 5'd8;
localparam ST_ELEM_WAIT        = 5'd9;
localparam ST_ELEM_CAPTURE     = 5'd10;
localparam ST_GELU_FACTOR      = 5'd11;
localparam ST_GELU_RAW         = 5'd12;
localparam ST_GELU_SCALE       = 5'd13;
localparam ST_GELU_CLIP        = 5'd14;
localparam ST_GELU_CHECK       = 5'd15;
localparam ST_NEXT_ROW         = 5'd16;
localparam ST_GROUP_DONE       = 5'd17;
localparam ST_EXP_DIV          = 5'd18;
localparam ST_GELU_FACTOR_DIV  = 5'd19;
localparam ST_GELU_SIGMOID     = 5'd20;

reg [4:0] state;
reg [5:0] process_group;
reg [1:0] process_row;
reg [9:0] col;
reg       exp_mode;
reg       start_seen;
reg       all_complete;

reg [12:0] fill_count [0:WINDOW_SLOTS-1];
reg [WINDOW_SLOTS-1:0] group_full;
integer slot_i;

wire [5:0] group_level_full_w =
    {5'd0, group_full[0]}  + {5'd0, group_full[1]}  +
    {5'd0, group_full[2]}  + {5'd0, group_full[3]}  +
    {5'd0, group_full[4]}  + {5'd0, group_full[5]}  +
    {5'd0, group_full[6]}  + {5'd0, group_full[7]}  +
    {5'd0, group_full[8]}  + {5'd0, group_full[9]}  +
    {5'd0, group_full[10]} + {5'd0, group_full[11]} +
    {5'd0, group_full[12]} + {5'd0, group_full[13]} +
    {5'd0, group_full[14]} + {5'd0, group_full[15]} +
    {5'd0, group_full[16]} + {5'd0, group_full[17]} +
    {5'd0, group_full[18]} + {5'd0, group_full[19]} +
    {5'd0, group_full[20]} + {5'd0, group_full[21]} +
    {5'd0, group_full[22]} + {5'd0, group_full[23]} +
    {5'd0, group_full[24]} + {5'd0, group_full[25]} +
    {5'd0, group_full[26]} + {5'd0, group_full[27]} +
    {5'd0, group_full[28]} + {5'd0, group_full[29]} +
    {5'd0, group_full[30]} + {5'd0, group_full[31]};
wire [4:0] group_level_w = group_level_full_w[5] ? 5'd31 :
                           group_level_full_w[4:0];
assign stat_group_level = group_level_w;

wire [5:0] input_group = in_wr_addr / GROUP_ITEMS;
wire [11:0] input_group_offset = in_wr_addr % GROUP_ITEMS;
wire [1:0] input_row = input_group_offset / DIM;
wire [9:0] input_col = input_group_offset % DIM;
wire [4:0] input_slot = input_group[4:0];
wire [4:0] process_slot = process_group[4:0];
wire input_addr_ok = in_wr_addr < COUNT;
wire input_buffer_busy = group_full[input_slot] ||
                         ((state != ST_IDLE) && (process_slot == input_slot));
wire [SLOT_ADDR_W-1:0] input_mem_addr = input_slot * DIM + input_col;
wire wr_en_r0 = in_wr_valid && input_addr_ok && !input_buffer_busy && (input_row == 2'd0);
wire wr_en_r1 = in_wr_valid && input_addr_ok && !input_buffer_busy && (input_row == 2'd1);
wire wr_en_r2 = in_wr_valid && input_addr_ok && !input_buffer_busy && (input_row == 2'd2);
wire wr_en_r3 = in_wr_valid && input_addr_ok && !input_buffer_busy && (input_row == 2'd3);

reg input_rd_en;
reg [SLOT_ADDR_W-1:0] input_rd_addr;
wire [7:0] rd_r0, rd_r1, rd_r2, rd_r3;
wire signed [7:0] input_rd_data_s =
    (process_row == 2'd0) ? $signed(rd_r0) :
    (process_row == 2'd1) ? $signed(rd_r1) :
    (process_row == 2'd2) ? $signed(rd_r2) : $signed(rd_r3);
wire rd_en_r0 = input_rd_en && (process_row == 2'd0);
wire rd_en_r1 = input_rd_en && (process_row == 2'd1);
wire rd_en_r2 = input_rd_en && (process_row == 2'd2);
wire rd_en_r3 = input_rd_en && (process_row == 2'd3);

v714_bram_sdp_sync #(.DATA_W(8),.ADDR_W(SLOT_ADDR_W),.DEPTH(SLOT_DEPTH),.FIT_MAX_DEPTH(SLOT_DEPTH)) u_row0(
 .clk(clk),.wr_en(wr_en_r0),.wr_addr(input_mem_addr),.wr_data(in_wr_data),.rd_en(rd_en_r0),.rd_addr(input_rd_addr),.rd_data(rd_r0));
v714_bram_sdp_sync #(.DATA_W(8),.ADDR_W(SLOT_ADDR_W),.DEPTH(SLOT_DEPTH),.FIT_MAX_DEPTH(SLOT_DEPTH)) u_row1(
 .clk(clk),.wr_en(wr_en_r1),.wr_addr(input_mem_addr),.wr_data(in_wr_data),.rd_en(rd_en_r1),.rd_addr(input_rd_addr),.rd_data(rd_r1));
v714_bram_sdp_sync #(.DATA_W(8),.ADDR_W(SLOT_ADDR_W),.DEPTH(SLOT_DEPTH),.FIT_MAX_DEPTH(SLOT_DEPTH)) u_row2(
 .clk(clk),.wr_en(wr_en_r2),.wr_addr(input_mem_addr),.wr_data(in_wr_data),.rd_en(rd_en_r2),.rd_addr(input_rd_addr),.rd_data(rd_r2));
v714_bram_sdp_sync #(.DATA_W(8),.ADDR_W(SLOT_ADDR_W),.DEPTH(SLOT_DEPTH),.FIT_MAX_DEPTH(SLOT_DEPTH)) u_row3(
 .clk(clk),.wr_en(wr_en_r3),.wr_addr(input_mem_addr),.wr_data(in_wr_data),.rd_en(rd_en_r3),.rd_addr(input_rd_addr),.rd_data(rd_r3));

reg signed [31:0] max_r;
reg signed [31:0] x_r;
reg signed [31:0] pre_x_r;
reg signed [31:0] exp_x_r;
reg signed [31:0] exp_affine_r;
reg signed [31:0] exp_q_r;
reg signed [31:0] exp_r_r;
reg signed [31:0] exp_value_r;
reg signed [31:0] exp_max_r;
reg signed [31:0] exp_sum_r;
reg signed [31:0] factor_r;
reg signed [31:0] sigmoid_r;
reg signed [63:0] raw_r;
reg signed [63:0] quant_wide_r;
reg signed [7:0] quant_r;
reg signed [31:0] scale_r;
wire signed [31:0] min_exp_x_w = (constant_x0 <<< 4) + (constant_x0 <<< 3) - constant_x0;

`ifdef V882_GELU_RADIX16
wire signed [31:0] exp_affine_clamped_w =
    (exp_affine_r < min_exp_x_w) ? min_exp_x_w : exp_affine_r;
wire signed [31:0] gelu_exp_sum_w = exp_value_r + exp_max_r;
wire gelu_r16_start_valid_w =
    ((state == ST_EXP_QR) && (constant_x0 != 32'sd0)) ||
    ((state == ST_GELU_FACTOR) && (gelu_exp_sum_w > 32'sd0));
wire gelu_r16_start_ready_w;
wire gelu_r16_finish_valid_w;
wire [31:0] gelu_r16_quotient_w;
wire [31:0] gelu_r16_remainder_w;
wire gelu_r16_divisor_zero_w;
wire gelu_r16_signed_w = (state == ST_EXP_QR);
wire [31:0] gelu_r16_dividend_w = (state == ST_GELU_FACTOR) ?
                                  32'd2147483647 : exp_affine_clamped_w;
wire [31:0] gelu_r16_divisor_w = (state == ST_GELU_FACTOR) ?
                                 gelu_exp_sum_w : constant_x0;

intdiv_r16_plus #(.D_W(32)) u_gelu_r16_divider(
    .start_valid_i(gelu_r16_start_valid_w),
    .start_ready_o(gelu_r16_start_ready_w),
    .flush_i(clear),
    .signed_op_i(gelu_r16_signed_w),
    .dividend_i(gelu_r16_dividend_w),
    .divisor_i(gelu_r16_divisor_w),
    .finish_valid_o(gelu_r16_finish_valid_w),
    .finish_ready_i(1'b1),
    .quotient_o(gelu_r16_quotient_w),
    .remainder_o(gelu_r16_remainder_w),
    .divisor_is_zero_o(gelu_r16_divisor_zero_w),
    .clk(clk),
    .rst_n(rst_n)
);
`endif

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        process_group <= 6'd0;
        process_row <= 2'd0;
        col <= 10'd0;
        exp_mode <= 1'b0;
        start_seen <= 1'b0;
        all_complete <= 1'b0;
        group_full <= {WINDOW_SLOTS{1'b0}};
        for (slot_i = 0; slot_i < WINDOW_SLOTS; slot_i = slot_i + 1)
            fill_count[slot_i] <= 13'd0;
        input_rd_en <= 1'b0;
        input_rd_addr <= {SLOT_ADDR_W{1'b0}};
        max_r <= -32'sd2147483648;
        x_r <= 32'sd0;
        pre_x_r <= 32'sd0;
        exp_x_r <= 32'sd0;
        exp_affine_r <= 32'sd0;
        exp_q_r <= 32'sd0;
        exp_r_r <= 32'sd0;
        exp_value_r <= 32'sd0;
        exp_max_r <= 32'sd0;
        exp_sum_r <= 32'sd0;
        factor_r <= 32'sd0;
        sigmoid_r <= 32'sd0;
        raw_r <= 64'sd0;
        quant_wide_r <= 64'sd0;
        quant_r <= 8'sd0;
        scale_r <= 32'sd0;
        busy <= 1'b0;
        done <= 1'b0;
        stat_input_writes <= 32'd0;
        stat_input_errors <= 32'd0;
        stat_rows <= 32'd0;
        stat_items <= 32'd0;
        stat_max_errors <= 32'd0;
        stat_exp_errors <= 32'd0;
        stat_gelu_errors <= 32'd0;
        out_valid <= 1'b0;
        out_addr <= 18'd0;
        out_data <= 8'sd0;
        stat_stream_items <= 32'd0;
        stat_group_max_level <= 5'd0;
        stat_input_blocked_cycles <= 32'd0;
        stat_output_stall_cycles <= 32'd0;
    end else begin
        done <= 1'b0;
        out_valid <= 1'b0;
        input_rd_en <= 1'b0;
        busy <= (state != ST_IDLE) || (|group_full) || start_seen;

        if (scale_wr_valid)
            scale_r <= scale_wr_data;
        if (start)
            start_seen <= 1'b1;

        if (group_level_w > stat_group_max_level)
            stat_group_max_level <= group_level_w;
        if (in_wr_valid && input_buffer_busy)
            stat_input_blocked_cycles <= stat_input_blocked_cycles + 1'b1;
        if ((state == ST_GELU_CHECK) && !out_ready)
            stat_output_stall_cycles <= stat_output_stall_cycles + 1'b1;

        if (clear) begin
            state <= ST_IDLE;
            process_group <= 6'd0;
            process_row <= 2'd0;
            col <= 10'd0;
            start_seen <= 1'b0;
            all_complete <= 1'b0;
            group_full <= {WINDOW_SLOTS{1'b0}};
            for (slot_i = 0; slot_i < WINDOW_SLOTS; slot_i = slot_i + 1)
                fill_count[slot_i] <= 13'd0;
            busy <= 1'b0;
            stat_input_writes <= 32'd0;
            stat_input_errors <= 32'd0;
            stat_rows <= 32'd0;
            stat_items <= 32'd0;
            stat_max_errors <= 32'd0;
            stat_exp_errors <= 32'd0;
            stat_gelu_errors <= 32'd0;
            stat_stream_items <= 32'd0;
            stat_group_max_level <= 5'd0;
            stat_input_blocked_cycles <= 32'd0;
            stat_output_stall_cycles <= 32'd0;
        end else begin
            if (in_wr_valid) begin
                if (!input_addr_ok || input_buffer_busy) begin
                    stat_input_errors <= stat_input_errors + 1'b1;
                end else begin
                    stat_input_writes <= stat_input_writes + 1'b1;
                    if (fill_count[input_slot] == GROUP_ITEMS - 1) begin
                        fill_count[input_slot] <= GROUP_ITEMS;
                        group_full[input_slot] <= 1'b1;
                    end else begin
                        fill_count[input_slot] <= fill_count[input_slot] + 1'b1;
                    end
                end
            end

            if ((state == ST_IDLE) && !all_complete) begin
                if (group_full[process_slot]) begin
                    process_row <= 2'd0;
                    col <= 10'd0;
                    max_r <= -32'sd2147483648;
                    state <= ST_FIND_MAX;
                end
            end

            case (state)
                ST_IDLE: begin
                    if (all_complete && (start_seen || start)) begin
                        done <= 1'b1;
                        start_seen <= 1'b0;
                    end
                end

                ST_FIND_MAX: begin
                    input_rd_en <= 1'b1;
                    input_rd_addr <= process_slot * DIM + col;
                    state <= ST_FIND_MAX_WAIT;
                end

                ST_FIND_MAX_WAIT: begin
                    state <= ST_FIND_MAX_CAPTURE;
                end

                ST_FIND_MAX_CAPTURE: begin
                    if (input_rd_data_s > max_r)
                        max_r <= input_rd_data_s;
                    if (col == DIM - 1) begin
                        max_r <= (input_rd_data_s > max_r) ? input_rd_data_s : max_r;
                        exp_mode <= 1'b0;
                        exp_x_r <= -1 * ((input_rd_data_s > max_r) ? input_rd_data_s : max_r);
                        state <= ST_EXP_PREP;
                    end else begin
                        col <= col + 1'b1;
                        state <= ST_FIND_MAX;
                    end
                end

                ST_EXP_PREP: begin
                    state <= ST_EXP_AFFINE;
                end

                ST_EXP_AFFINE: begin
                    exp_affine_r <= exp_x_r + (exp_x_r >>> 1) - (exp_x_r >>> 4);
                    state <= ST_EXP_QR;
                end

                ST_EXP_QR: begin
                    if (exp_affine_r < min_exp_x_w)
                        exp_affine_r <= min_exp_x_w;
`ifdef V882_GELU_RADIX16
                    if (constant_x0 == 32'sd0) begin
                        exp_q_r <= 32'sd0;
                        exp_r_r <= exp_affine_clamped_w;
                        stat_exp_errors <= stat_exp_errors + 1'b1;
                        state <= ST_EXP_OUT;
                    end else if (gelu_r16_start_ready_w) begin
                        state <= ST_EXP_DIV;
                    end
`else
                    exp_q_r <= (exp_affine_r < min_exp_x_w ? min_exp_x_w : exp_affine_r) / constant_x0;
                    exp_r_r <= (exp_affine_r < min_exp_x_w ? min_exp_x_w : exp_affine_r) -
                               constant_x0 * ((exp_affine_r < min_exp_x_w ? min_exp_x_w : exp_affine_r) / constant_x0);
                    state <= ST_EXP_OUT;
`endif
                end

                ST_EXP_DIV: begin
`ifdef V882_GELU_RADIX16
                    if (gelu_r16_finish_valid_w) begin
                        exp_q_r <= $signed(gelu_r16_quotient_w);
                        exp_r_r <= $signed(gelu_r16_remainder_w);
                        if (gelu_r16_divisor_zero_w)
                            stat_exp_errors <= stat_exp_errors + 1'b1;
                        state <= ST_EXP_OUT;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_EXP_OUT: begin
                    exp_value_r <= (((exp_q_r[31:5] == 0 && exp_q_r[4:0] <= 5'd23) ? (((exp_r_r >>> 1) - constant_x0) <<< (5'd23 - exp_q_r[4:0])) : 32'sd0));
                    if ((((exp_q_r[31:5] == 0 && exp_q_r[4:0] <= 5'd23) ? (((exp_r_r >>> 1) - constant_x0) <<< (5'd23 - exp_q_r[4:0])) : 32'sd0)) < 0)
                        exp_value_r <= 32'sd0;
                    if (!exp_mode) begin
                        exp_max_r <= ((((exp_q_r[31:5] == 0 && exp_q_r[4:0] <= 5'd23) ? (((exp_r_r >>> 1) - constant_x0) <<< (5'd23 - exp_q_r[4:0])) : 32'sd0)) < 0) ?
                                     32'sd0 : (((exp_q_r[31:5] == 0 && exp_q_r[4:0] <= 5'd23) ? (((exp_r_r >>> 1) - constant_x0) <<< (5'd23 - exp_q_r[4:0])) : 32'sd0));
                        col <= 10'd0;
                        state <= ST_ELEM_LOAD;
                    end else begin
                        state <= ST_GELU_FACTOR;
                    end
                end

                ST_ELEM_LOAD: begin
                    input_rd_en <= 1'b1;
                    input_rd_addr <= process_slot * DIM + col;
                    state <= ST_ELEM_WAIT;
                end

                ST_ELEM_WAIT: begin
                    state <= ST_ELEM_CAPTURE;
                end

                ST_ELEM_CAPTURE: begin
                    x_r <= input_rd_data_s;
                    pre_x_r <= input_rd_data_s;
                    exp_x_r <= input_rd_data_s - max_r;
                    exp_mode <= 1'b1;
                    state <= ST_EXP_PREP;
                end

                ST_GELU_FACTOR: begin
                    exp_sum_r <= exp_value_r + exp_max_r;
                    if ((exp_value_r + exp_max_r) <= 0) begin
                        factor_r <= 32'sd0;
                        state <= ST_GELU_SIGMOID;
                    end else begin
`ifdef V882_GELU_RADIX16
                        if (gelu_r16_start_ready_w)
                            state <= ST_GELU_FACTOR_DIV;
`else
                        factor_r <= 32'sd2147483647 / (exp_value_r + exp_max_r);
                        state <= ST_GELU_SIGMOID;
`endif
                    end
                end

                ST_GELU_FACTOR_DIV: begin
`ifdef V882_GELU_RADIX16
                    if (gelu_r16_finish_valid_w) begin
                        factor_r <= $signed(gelu_r16_quotient_w);
                        if (gelu_r16_divisor_zero_w)
                            stat_gelu_errors <= stat_gelu_errors + 1'b1;
                        state <= ST_GELU_SIGMOID;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_GELU_SIGMOID: begin
                    sigmoid_r <= (exp_value_r * factor_r) >>> 24;
                    state <= ST_GELU_RAW;
                end

                ST_GELU_RAW: begin
                    raw_r <= pre_x_r * sigmoid_r;
                    state <= ST_GELU_SCALE;
                end

                ST_GELU_SCALE: begin
                    quant_wide_r <= (raw_r * scale_r) >>> 29;
                    state <= ST_GELU_CLIP;
                end

                ST_GELU_CLIP: begin
                    if (quant_wide_r > 64'sd127)
                        quant_r <= 8'sh7f;
                    else if (quant_wide_r < -64'sd128)
                        quant_r <= 8'sh80;
                    else
                        quant_r <= quant_wide_r[7:0];
                    state <= ST_GELU_CHECK;
                end

                ST_GELU_CHECK: begin
                    if (out_ready) begin
                        stat_items <= stat_items + 1'b1;
                        out_valid <= 1'b1;
                        out_addr <= process_group * GROUP_ITEMS + process_row * DIM + col;
                        out_data <= quant_r;
                        stat_stream_items <= stat_stream_items + 1'b1;
                        if (col == DIM - 1)
                            state <= ST_NEXT_ROW;
                        else begin
                            col <= col + 1'b1;
                            state <= ST_ELEM_LOAD;
                        end
                    end
                end

                ST_NEXT_ROW: begin
                    stat_rows <= stat_rows + 1'b1;
                    if (process_row == ROWS_PER_GROUP - 1) begin
                        state <= ST_GROUP_DONE;
                    end else begin
                        process_row <= process_row + 1'b1;
                        col <= 10'd0;
                        max_r <= -32'sd2147483648;
                        state <= ST_FIND_MAX;
                    end
                end

                ST_GROUP_DONE: begin
                    group_full[process_slot] <= 1'b0;
                    fill_count[process_slot] <= 13'd0;
                    if (process_group == GROUPS - 1) begin
                        all_complete <= 1'b1;
                        if (start_seen || start) begin
                            done <= 1'b1;
                            start_seen <= 1'b0;
                        end
                    end else begin
                        process_group <= process_group + 1'b1;
                    end
                    state <= ST_IDLE;
                end

                default: state <= ST_IDLE;
            endcase
        end
    end
end

wire _unused = ^x_r ^ ^exp_sum_r ^ ^sigmoid_r ^ CONSTANT_X0[0];

endmodule
