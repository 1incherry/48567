`timescale 1ns/1ps

module v641_runtime_gelu_fc2_residual_tiledrain_stream_controller_legacy #(
    parameter A_GOLDEN_MEM = "",
    parameter B_MEM = "",
    parameter ACC_MEM = "",
    parameter SCALE_MEM = "",
    parameter ADD_SCALE_MEM = "",
    parameter RESIDUAL_MEM = "",
    parameter QUANT_MEM = "",
    parameter ADD_MEM = ""
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire in_wr_valid,
    input  wire [17:0] in_wr_addr,
    input  wire signed [15:0] in_wr_data,
    input  wire b_wr_valid,
    input  wire [17:0] b_wr_addr,
    input  wire signed [15:0] b_wr_data,
    input  wire scale_wr_valid,
    input  wire [7:0] scale_wr_addr,
    input  wire signed [31:0] scale_wr_data,
    input  wire add_scale_wr_valid,
    input  wire signed [31:0] add_scale_wr_data,
    input  wire residual_wr_valid,
    input  wire [15:0] residual_wr_addr,
    input  wire signed [15:0] residual_wr_data,
    input  wire start,
    output reg  busy,
    output reg  done,
    output reg [31:0] stat_input_writes,
    output reg [31:0] stat_input_errors,
    output reg [31:0] stat_tiles,
    output reg [31:0] stat_acc_errors,
    output reg [31:0] stat_quant_errors,
    output reg [31:0] stat_add_errors,
    output reg        out_valid,
    output reg [15:0] out_addr,
    output reg signed [15:0] out_data,
    output reg [31:0] stat_stream_items
);

localparam ROWS = 256;
localparam ROWS_REAL = 197;
localparam IN_DIM = 770;
localparam OUT_DIM = 192;
localparam TILE = 4;
localparam RESIDUAL_COUNT = ROWS_REAL * OUT_DIM;
localparam K_TILES = (IN_DIM + TILE - 1) / TILE;
localparam OUT_COL_TILES = OUT_DIM / TILE;
localparam ROW_TILES = ROWS / TILE;
localparam A_TILE_DEPTH = ROW_TILES * K_TILES;
localparam B_TILE_DEPTH = K_TILES * OUT_COL_TILES;
localparam RES_ROW_TILES = (ROWS_REAL + TILE - 1) / TILE;
localparam RES_TILE_DEPTH = RES_ROW_TILES * OUT_COL_TILES;

localparam ST_IDLE       = 4'd0;
localparam ST_LOAD       = 4'd1;
localparam ST_FIRE       = 4'd2;
localparam ST_WAIT       = 4'd3;
localparam ST_ACC        = 4'd4;
localparam ST_NEXT       = 4'd5;
localparam ST_QUANT_INIT = 4'd6;
localparam ST_QUANT      = 4'd7;
localparam ST_DONE       = 4'd8;
localparam ST_LOAD_WAIT  = 4'd9;
localparam ST_QUANT_REQ  = 4'd10;
localparam ST_LOAD_CAPTURE = 4'd11;
localparam ST_QUANT_WAIT   = 4'd12;

reg [3:0] state;
reg [7:0] rt;
reg [7:0] ct;
reg [9:0] kt;
reg [15:0] idx;
reg [7:0] q_row;
reg [7:0] q_col;

reg pe_in_valid;
wire pe_in_ready;
wire pe_out_valid;
wire [511:0] pe_c_flat;
wire [31:0] pe_stat_tiles;
reg [255:0] pe_a_flat;
reg [255:0] pe_b_flat;

reg a_tile_rd_en;
reg b_tile_rd_en;
reg [13:0] a_tile_rd_addr;
reg [13:0] b_tile_rd_addr;
wire [255:0] a_tile_rd_data;
wire [255:0] b_tile_rd_data;
reg scale_rd_en;
reg [7:0] scale_rd_addr;
wire [31:0] scale_rd_data_u;
wire signed [31:0] scale_rd_data_s = $signed(scale_rd_data_u);
reg signed [31:0] add_scale_r;
reg residual_rd_en;
reg [13:0] residual_rd_addr;
wire [255:0] residual_rd_data;
reg signed [31:0] acc_tile [0:15];

reg signed [63:0] quant_wide;
reg signed [15:0] quant_r;
reg signed [63:0] residual_wide;
reg signed [15:0] residual_r;
reg signed [16:0] add_wide;
reg signed [15:0] add_r;
reg signed [31:0] acc_next;
reg [4:0] acc_error_incr;
reg [15:0] lane_addr;
reg [7:0] lane_row;
reg [7:0] lane_col;
integer i;

wire [17:0] a_wr_row_i = in_wr_addr / IN_DIM;
wire [17:0] a_wr_col_i = in_wr_addr % IN_DIM;
wire [3:0] a_wr_lane_i = {a_wr_row_i[1:0], a_wr_col_i[1:0]};
wire [13:0] a_wr_tile_addr_i = a_wr_row_i[17:2] * K_TILES[13:0] + a_wr_col_i[17:2];
wire a_wr_ok_i = in_wr_valid && (in_wr_addr < (ROWS*IN_DIM));
wire [15:0] a_wr_lane_en_i = a_wr_ok_i ? (16'h0001 << a_wr_lane_i) : 16'h0000;

wire [17:0] b_wr_row_i = b_wr_addr / OUT_DIM;
wire [17:0] b_wr_col_i = b_wr_addr % OUT_DIM;
wire [3:0] b_wr_lane_i = {b_wr_row_i[1:0], b_wr_col_i[1:0]};
wire [13:0] b_wr_tile_addr_i = b_wr_row_i[17:2] * OUT_COL_TILES[13:0] + b_wr_col_i[17:2];
wire b_wr_ok_i = b_wr_valid && (b_wr_addr < (IN_DIM*OUT_DIM));
wire [15:0] b_wr_lane_en_i = b_wr_ok_i ? (16'h0001 << b_wr_lane_i) : 16'h0000;

wire [15:0] residual_wr_row_i = residual_wr_addr / OUT_DIM[15:0];
wire [15:0] residual_wr_col_i = residual_wr_addr % OUT_DIM[15:0];
wire [3:0] residual_wr_lane_i = {residual_wr_row_i[1:0], residual_wr_col_i[1:0]};
wire [13:0] residual_wr_tile_addr_i = residual_wr_row_i[15:2] * OUT_COL_TILES[13:0] + residual_wr_col_i[15:2];
wire residual_wr_ok_i = residual_wr_valid && (residual_wr_addr < RESIDUAL_COUNT[15:0]);
wire [15:0] residual_wr_lane_en_i = residual_wr_ok_i ? (16'h0001 << residual_wr_lane_i) : 16'h0000;
wire [255:0] residual_wr_data_pack_i = {16{residual_wr_data}};
wire signed [15:0] residual_lane_read_i =
    (idx[3:0] == 4'd0)  ? $signed(residual_rd_data[255 - 0*16 -: 16])  :
    (idx[3:0] == 4'd1)  ? $signed(residual_rd_data[255 - 1*16 -: 16])  :
    (idx[3:0] == 4'd2)  ? $signed(residual_rd_data[255 - 2*16 -: 16])  :
    (idx[3:0] == 4'd3)  ? $signed(residual_rd_data[255 - 3*16 -: 16])  :
    (idx[3:0] == 4'd4)  ? $signed(residual_rd_data[255 - 4*16 -: 16])  :
    (idx[3:0] == 4'd5)  ? $signed(residual_rd_data[255 - 5*16 -: 16])  :
    (idx[3:0] == 4'd6)  ? $signed(residual_rd_data[255 - 6*16 -: 16])  :
    (idx[3:0] == 4'd7)  ? $signed(residual_rd_data[255 - 7*16 -: 16])  :
    (idx[3:0] == 4'd8)  ? $signed(residual_rd_data[255 - 8*16 -: 16])  :
    (idx[3:0] == 4'd9)  ? $signed(residual_rd_data[255 - 9*16 -: 16])  :
    (idx[3:0] == 4'd10) ? $signed(residual_rd_data[255 - 10*16 -: 16]) :
    (idx[3:0] == 4'd11) ? $signed(residual_rd_data[255 - 11*16 -: 16]) :
    (idx[3:0] == 4'd12) ? $signed(residual_rd_data[255 - 12*16 -: 16]) :
    (idx[3:0] == 4'd13) ? $signed(residual_rd_data[255 - 13*16 -: 16]) :
    (idx[3:0] == 4'd14) ? $signed(residual_rd_data[255 - 14*16 -: 16]) :
                          $signed(residual_rd_data[255 - 15*16 -: 16]);
wire scale_wr_ok_i = scale_wr_valid && (scale_wr_addr < OUT_DIM[7:0]);

v285_pe4x4_int16_tile_core #(.PIPELINED_ARITHMETIC(1)) u_pe (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .in_valid(pe_in_valid),
    .in_ready(pe_in_ready),
    .a_flat(pe_a_flat),
    .b_flat(pe_b_flat),
    .out_valid(pe_out_valid),
    .out_ready(1'b1),
    .c_flat(pe_c_flat),
    .stat_tiles(pe_stat_tiles)
);

v719_tile16_lane_bram16_sync #(
    .ADDR_W(14),
    .DEPTH(A_TILE_DEPTH),
    .FIT_MAX_DEPTH(A_TILE_DEPTH)
) u_a_tile_bank (
    .clk(clk),
    .wr_lane_en(a_wr_lane_en_i),
    .wr_addr(a_wr_tile_addr_i),
    .wr_data({16{in_wr_data}}),
    .rd_en(a_tile_rd_en),
    .rd_addr(a_tile_rd_addr),
    .rd_data(a_tile_rd_data)
);

v719_tile16_lane_bram16_sync #(
    .ADDR_W(14),
    .DEPTH(B_TILE_DEPTH),
    .FIT_MAX_DEPTH(B_TILE_DEPTH)
) u_b_tile_bank (
    .clk(clk),
    .wr_lane_en(b_wr_lane_en_i),
    .wr_addr(b_wr_tile_addr_i),
    .wr_data({16{b_wr_data}}),
    .rd_en(b_tile_rd_en),
    .rd_addr(b_tile_rd_addr),
    .rd_data(b_tile_rd_data)
);

v714_bram_sdp_sync #(
    .DATA_W(32),
    .ADDR_W(8),
    .DEPTH(OUT_DIM)
) u_scale_mem (
    .clk(clk),
    .wr_en(scale_wr_ok_i),
    .wr_addr(scale_wr_addr),
    .wr_data(scale_wr_data),
    .rd_en(scale_rd_en),
    .rd_addr(scale_rd_addr),
    .rd_data(scale_rd_data_u)
);

v719_tile16_lane_bram16_sync #(
    .ADDR_W(14),
    .DEPTH(RES_TILE_DEPTH),
    .FIT_MAX_DEPTH(RES_TILE_DEPTH)
) u_residual_bank (
    .clk(clk),
    .wr_lane_en(residual_wr_lane_en_i),
    .wr_addr(residual_wr_tile_addr_i),
    .wr_data(residual_wr_data_pack_i),
    .rd_en(residual_rd_en),
    .rd_addr(residual_rd_addr),
    .rd_data(residual_rd_data)
);

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        rt <= 8'd0;
        ct <= 8'd0;
        kt <= 10'd0;
        idx <= 16'd0;
        q_row <= 8'd0;
        q_col <= 8'd0;
        pe_in_valid <= 1'b0;
        pe_a_flat <= 256'd0;
        pe_b_flat <= 256'd0;
        a_tile_rd_en <= 1'b0;
        b_tile_rd_en <= 1'b0;
        a_tile_rd_addr <= 14'd0;
        b_tile_rd_addr <= 14'd0;
        scale_rd_en <= 1'b0;
        scale_rd_addr <= 8'd0;
        add_scale_r <= 32'sd0;
        residual_rd_en <= 1'b0;
        residual_rd_addr <= 14'd0;
        quant_wide <= 64'sd0;
        quant_r <= 16'sd0;
        residual_wide <= 64'sd0;
        residual_r <= 16'sd0;
        add_wide <= 17'sd0;
        add_r <= 16'sd0;
        acc_next <= 32'sd0;
        acc_error_incr <= 5'd0;
        lane_addr <= 16'd0;
        lane_row <= 8'd0;
        lane_col <= 8'd0;
        busy <= 1'b0;
        done <= 1'b0;
        stat_input_writes <= 32'd0;
        stat_input_errors <= 32'd0;
        stat_tiles <= 32'd0;
        stat_acc_errors <= 32'd0;
        stat_quant_errors <= 32'd0;
        stat_add_errors <= 32'd0;
        out_valid <= 1'b0;
        out_addr <= 16'd0;
        out_data <= 16'sd0;
        stat_stream_items <= 32'd0;
        for (i = 0; i < 16; i = i + 1)
            acc_tile[i] <= 32'sd0;
    end else begin
        done <= 1'b0;
        pe_in_valid <= 1'b0;
        out_valid <= 1'b0;
        a_tile_rd_en <= 1'b0;
        b_tile_rd_en <= 1'b0;
        scale_rd_en <= 1'b0;
        residual_rd_en <= 1'b0;
        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            stat_input_writes <= 32'd0;
            stat_input_errors <= 32'd0;
            stat_tiles <= 32'd0;
            stat_acc_errors <= 32'd0;
            stat_quant_errors <= 32'd0;
            stat_add_errors <= 32'd0;
            stat_stream_items <= 32'd0;
        end else begin
            if (in_wr_valid) begin
                if (in_wr_addr < (ROWS*IN_DIM)) begin
                    stat_input_writes <= stat_input_writes + 1'b1;
                end else begin
                    stat_input_errors <= stat_input_errors + 1'b1;
                end
            end

            if (add_scale_wr_valid)
                add_scale_r <= add_scale_wr_data;

            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        rt <= 8'd0;
                        ct <= 8'd0;
                        kt <= 10'd0;
                        idx <= 16'd0;
                        q_row <= 8'd0;
                        q_col <= 8'd0;
                        stat_tiles <= 32'd0;
                        stat_acc_errors <= 32'd0;
                        stat_quant_errors <= 32'd0;
                        stat_add_errors <= 32'd0;
                        stat_stream_items <= 32'd0;
                        state <= ST_LOAD;
                    end
                end

                ST_LOAD: begin
                    a_tile_rd_en <= 1'b1;
                    b_tile_rd_en <= 1'b1;
                    a_tile_rd_addr <= rt[7:2] * K_TILES[13:0] + kt[9:2];
                    b_tile_rd_addr <= kt[9:2] * OUT_COL_TILES[13:0] + ct[7:2];
                    state <= ST_LOAD_WAIT;
                end

                ST_LOAD_WAIT: begin
                    state <= ST_LOAD_CAPTURE;
                end

                ST_LOAD_CAPTURE: begin
                    for (i = 0; i < 16; i = i + 1) begin
                        pe_a_flat[255 - i*16 -: 16] <= ((rt + (i / 4) < ROWS_REAL) && (kt + (i % 4) < IN_DIM)) ? a_tile_rd_data[255 - i*16 -: 16] : 16'sd0;
                        pe_b_flat[255 - i*16 -: 16] <= (kt + (i / 4) < IN_DIM) ? b_tile_rd_data[255 - i*16 -: 16] : 16'sd0;
                    end
                    state <= ST_FIRE;
                end

                ST_FIRE: begin
                    if (pe_in_ready) begin
                        pe_in_valid <= 1'b1;
                        state <= ST_WAIT;
                    end
                end

                ST_WAIT: begin
                    if (pe_out_valid) begin
                        idx <= 16'd0;
                        state <= ST_ACC;
                    end
                end

                ST_ACC: begin
                    acc_error_incr = 5'd0;
                    for (i = 0; i < 16; i = i + 1) begin
                        if (kt == 10'd0)
                            acc_next = pe_c_flat[511 - i*32 -: 32];
                        else
                            acc_next = acc_tile[i] + pe_c_flat[511 - i*32 -: 32];
                        acc_tile[i] <= acc_next;
                    end
                    stat_acc_errors <= stat_acc_errors + acc_error_incr;
                    stat_tiles <= stat_tiles + 1'b1;
                    state <= ST_NEXT;
                end

                ST_NEXT: begin
                    if (kt < IN_DIM - TILE) begin
                        kt <= kt + 10'd4;
                        state <= ST_LOAD;
                    end else begin
                        kt <= 10'd0;
                        idx <= 16'd0;
                        state <= ST_QUANT_REQ;
                    end
                end

                ST_QUANT_INIT: begin
                    idx <= 16'd0;
                    q_row <= 8'd0;
                    q_col <= 8'd0;
                    state <= ST_QUANT_REQ;
                end

                ST_QUANT_REQ: begin
                    lane_row = rt + (idx / 4);
                    lane_col = ct + (idx % 4);
                    lane_addr = lane_row * OUT_DIM + lane_col;
                    scale_rd_en <= 1'b1;
                    scale_rd_addr <= lane_col;
                    if (lane_row < ROWS_REAL) begin
                        residual_rd_en <= 1'b1;
                        residual_rd_addr <= lane_row[7:2] * OUT_COL_TILES[13:0] + lane_col[7:2];
                    end else begin
                        residual_rd_en <= 1'b0;
                        residual_rd_addr <= 14'd0;
                    end
                    state <= ST_QUANT_WAIT;
                end

                ST_QUANT_WAIT: begin
                    state <= ST_QUANT;
                end

                ST_QUANT: begin
                    lane_row = rt + (idx / 4);
                    lane_col = ct + (idx % 4);
                    lane_addr = lane_row * OUT_DIM + lane_col;
                    quant_wide = (acc_tile[idx[3:0]] * scale_rd_data_s) >>> 29;
                    if (quant_wide > 64'sd32767)
                        quant_r = 16'sh7fff;
                    else if (quant_wide < -64'sd32768)
                        quant_r = 16'sh8000;
                    else

                    if (lane_row < ROWS_REAL) begin
                        residual_wide = (residual_lane_read_i * add_scale_r) >>> 29;
                        if (residual_wide > 64'sd32767)
                            residual_r = 16'sh7fff;
                        else if (residual_wide < -64'sd32768)
                            residual_r = 16'sh8000;
                        else
                            residual_r = residual_wide[15:0];
                        add_wide = quant_r + residual_r;
                    end else begin
                        add_wide = quant_r;
                    end

                    if (add_wide > 17'sd32767)
                        add_r = 16'sh7fff;
                    else if (add_wide < -17'sd32768)
                        add_r = 16'sh8000;
                    else
                        add_r = add_wide[15:0];

                    out_valid <= 1'b1;
                    out_addr <= lane_addr;
                    out_data <= add_r;
                    stat_stream_items <= stat_stream_items + 1'b1;

                    if (idx == 16'd15) begin
                        if (ct < OUT_DIM - TILE) begin
                            ct <= ct + 8'd4;
                            state <= ST_LOAD;
                        end else begin
                            ct <= 8'd0;
                            if (rt < ROWS - TILE) begin
                                rt <= rt + 8'd4;
                                state <= ST_LOAD;
                            end else begin
                                state <= ST_DONE;
                            end
                        end
                    end else begin
                        idx <= idx + 1'b1;
                        state <= ST_QUANT_REQ;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule
