`timescale 1ns/1ps
`define V783_COMPACT_INT8_STORAGE
`define V784_FC1_GELU_ROWGROUP_PIPELINE
`include "source_r6b/sources/physical/core/v781_add_this_one_file.v"
