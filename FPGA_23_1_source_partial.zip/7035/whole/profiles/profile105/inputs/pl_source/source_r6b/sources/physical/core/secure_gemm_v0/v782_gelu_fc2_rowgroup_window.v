`timescale 1ns/1ps

// V782 FC2 row-group window. GELU is back-pressured after four rows, FC2
// consumes that 4x768 window, and the same 193 tile locations are reused.
module v641_runtime_gelu_fc2_residual_tiledrain_stream_controller #(
 parameter A_GOLDEN_MEM="",parameter B_MEM="",parameter ACC_MEM="",parameter SCALE_MEM="",
 parameter ADD_SCALE_MEM="",parameter RESIDUAL_MEM="",parameter QUANT_MEM="",parameter ADD_MEM=""
)(
 input wire clk,input wire rst_n,input wire clear,
 input wire in_wr_valid,input wire [17:0] in_wr_addr,input wire signed [15:0] in_wr_data,
 output wire in_wr_ready,
 input wire b_wr_valid,input wire [17:0] b_wr_addr,input wire signed [15:0] b_wr_data,
 input wire scale_wr_valid,input wire [7:0] scale_wr_addr,input wire signed [31:0] scale_wr_data,
 input wire add_scale_wr_valid,input wire signed [31:0] add_scale_wr_data,
 input wire residual_wr_valid,input wire [15:0] residual_wr_addr,input wire signed [15:0] residual_wr_data,
 input wire start,output reg busy,output reg done,
 output reg [31:0] stat_input_writes,output reg [31:0] stat_input_errors,output reg [31:0] stat_tiles,
 output reg [31:0] stat_acc_errors,output reg [31:0] stat_quant_errors,output reg [31:0] stat_add_errors,
 output reg out_valid,output reg [15:0] out_addr,output reg signed [15:0] out_data,
 output reg [31:0] stat_stream_items
);
localparam ROWS=256,ROWS_REAL=197,IN_REAL=768,IN_DIM=770,OUT_DIM=192,TILE=4;
localparam K_TILES=193,REAL_K_TILES=192,OUT_COL_TILES=48,RES_ROW_TILES=50,RES_TILE_DEPTH=2400;
localparam B_TILE_DEPTH=K_TILES*OUT_COL_TILES;
localparam ST_FILL=0,ST_LOAD=1,ST_WAIT=2,ST_CAPTURE=3,ST_FIRE=4,ST_PE_WAIT=5;
localparam ST_ACC=6,ST_QREQ=7,ST_QWAIT=8,ST_QUANT=9;
localparam ST_QCLAMP=10,ST_QADD=11,ST_QOUT=12,ST_QPRODUCT=13;
reg [3:0] state;
reg [5:0] group_idx;
reg [1:0] cap_row;
reg [9:0] cap_col,kt;
reg [7:0] ct;
reg [4:0] lane_idx;
reg buffer_full,all_complete,start_pending;
reg pe_in_valid,a_rd_en,b_rd_en,residual_rd_en,scale_rd_en;
reg [7:0] scale_rd_addr;
reg [7:0] b_dummy;
reg [13:0] a_rd_addr,b_rd_addr,residual_rd_addr;
wire [255:0] a_rd_data,b_rd_data,residual_rd_data;
wire [16*14-1:0] b_rd_addr_flat_repl={16{b_rd_addr}};
wire [31:0] scale_rd_data_u;
wire signed [31:0] scale_rd_data_s=$signed(scale_rd_data_u);
wire pe_in_ready,pe_out_valid;
wire [511:0] pe_c_flat;
wire [31:0] pe_stat_tiles;
reg [255:0] pe_a_flat,pe_b_flat;
reg signed [31:0] acc_tile[0:15];
reg signed [31:0] add_scale_r;
reg signed [63:0] quant_wide,residual_wide;
// Capture synchronous BRAM lane selection and coefficient at the original
// quantization boundary, then multiply on the following cycle. Preserve
// signed64 context, arithmetic shift and clipping exactly.
reg signed [31:0] quant_acc_pipe,quant_scale_pipe,residual_scale_pipe;
reg signed [15:0] residual_lane_pipe;
reg residual_real_pipe;
reg signed [15:0] quant_r,residual_r,add_r;
reg signed [16:0] add_wide;
integer i;

wire accept=in_wr_valid&&in_wr_ready;
wire [3:0] cap_lane={cap_row,cap_col[1:0]};
wire [15:0] cap_lane_en=accept?(16'h1<<cap_lane):0;
wire [17:0] b_row=b_wr_addr/OUT_DIM;
wire [17:0] b_col=b_wr_addr%OUT_DIM;
wire [3:0] b_lane={b_row[1:0],b_col[1:0]};
wire [13:0] b_tile_addr=b_row[17:2]*OUT_COL_TILES+b_col[17:2];
wire [15:0] b_lane_en=(b_wr_valid&&b_wr_addr<IN_DIM*OUT_DIM)?(16'h1<<b_lane):0;
wire [15:0] res_row=residual_wr_addr/OUT_DIM;
wire [15:0] res_col=residual_wr_addr%OUT_DIM;
wire [3:0] res_lane={res_row[1:0],res_col[1:0]};
wire [13:0] res_tile_addr=res_row[15:2]*OUT_COL_TILES+res_col[15:2];
wire [15:0] res_lane_en=(residual_wr_valid&&residual_wr_addr<ROWS_REAL*OUT_DIM)?(16'h1<<res_lane):0;
wire [7:0] global_row=(group_idx<<2)+(lane_idx>>2);
wire [7:0] lane_col=(ct)+(lane_idx[1:0]);
wire [15:0] lane_addr=global_row*OUT_DIM+lane_col;
wire signed [15:0] residual_lane=
 (lane_idx==0)?$signed(residual_rd_data[255-0*16 -:16]):(lane_idx==1)?$signed(residual_rd_data[255-1*16 -:16]):
 (lane_idx==2)?$signed(residual_rd_data[255-2*16 -:16]):(lane_idx==3)?$signed(residual_rd_data[255-3*16 -:16]):
 (lane_idx==4)?$signed(residual_rd_data[255-4*16 -:16]):(lane_idx==5)?$signed(residual_rd_data[255-5*16 -:16]):
 (lane_idx==6)?$signed(residual_rd_data[255-6*16 -:16]):(lane_idx==7)?$signed(residual_rd_data[255-7*16 -:16]):
 (lane_idx==8)?$signed(residual_rd_data[255-8*16 -:16]):(lane_idx==9)?$signed(residual_rd_data[255-9*16 -:16]):
 (lane_idx==10)?$signed(residual_rd_data[255-10*16 -:16]):(lane_idx==11)?$signed(residual_rd_data[255-11*16 -:16]):
 (lane_idx==12)?$signed(residual_rd_data[255-12*16 -:16]):(lane_idx==13)?$signed(residual_rd_data[255-13*16 -:16]):
 (lane_idx==14)?$signed(residual_rd_data[255-14*16 -:16]):$signed(residual_rd_data[15:0]);
assign in_wr_ready=(state==ST_FILL)&&!buffer_full&&!all_complete;

v783_tile16_lane_i8_sync #(.ADDR_W(8),.DEPTH(REAL_K_TILES)) u_a_tile_bank(
 .clk(clk),.wr_lane_en(cap_lane_en),.wr_addr(cap_col[9:2]),.wr_data({16{in_wr_data}}),
 .rd_en(a_rd_en),.rd_addr(a_rd_addr[7:0]),.rd_data(a_rd_data));
v783_lane16_i8_special_multiaddr_sync #(.ADDR_W(14),.DEPTH(B_TILE_DEPTH),
 .SPECIAL_TILE_BASE(9216),.SPECIAL_DEPTH(OUT_COL_TILES)) u_b_tile_bank(
 .clk(clk),.wr_lane_en(b_lane_en),.wr_addr(b_tile_addr),.wr_data(b_wr_data),
 .rd_en(b_rd_en),.rd_addr_flat(b_rd_addr_flat_repl),.rd_data(b_rd_data));
v714_bram_sdp_sync #(.DATA_W(32),.ADDR_W(8),.DEPTH(OUT_DIM)) u_scale_mem(
 .clk(clk),.wr_en(scale_wr_valid&&scale_wr_addr<OUT_DIM),.wr_addr(scale_wr_addr),.wr_data(scale_wr_data),
 .rd_en(scale_rd_en),.rd_addr(scale_rd_addr),.rd_data(scale_rd_data_u));
v719_tile16_lane_bram16_sync #(.ADDR_W(14),.DEPTH(RES_TILE_DEPTH),.FIT_MAX_DEPTH(RES_TILE_DEPTH)) u_residual_bank(
 .clk(clk),.wr_lane_en(res_lane_en),.wr_addr(res_tile_addr),.wr_data({16{residual_wr_data}}),
 .rd_en(residual_rd_en),.rd_addr(residual_rd_addr),.rd_data(residual_rd_data));
v285_pe4x4_int16_tile_core u_pe(.clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(pe_in_valid),.in_ready(pe_in_ready),
 .a_flat(pe_a_flat),.b_flat(pe_b_flat),.out_valid(pe_out_valid),.out_ready(1'b1),.c_flat(pe_c_flat),.stat_tiles(pe_stat_tiles));

always @(posedge clk) begin
 if(!rst_n) begin
  state<=ST_FILL;group_idx<=0;cap_row<=0;cap_col<=0;kt<=0;ct<=0;lane_idx<=0;buffer_full<=0;all_complete<=0;
  start_pending<=0;busy<=0;done<=0;pe_in_valid<=0;a_rd_en<=0;b_rd_en<=0;residual_rd_en<=0;scale_rd_en<=0;
  a_rd_addr<=0;b_rd_addr<=0;residual_rd_addr<=0;scale_rd_addr<=0;pe_a_flat<=0;pe_b_flat<=0;add_scale_r<=0;
  quant_acc_pipe<=0;quant_scale_pipe<=0;residual_scale_pipe<=0;residual_lane_pipe<=0;residual_real_pipe<=0;
  quant_wide<=0;residual_wide<=0;quant_r<=0;residual_r<=0;add_wide<=0;add_r<=0;
  stat_input_writes<=0;stat_input_errors<=0;stat_tiles<=0;stat_acc_errors<=0;stat_quant_errors<=0;
  stat_add_errors<=0;out_valid<=0;out_addr<=0;out_data<=0;stat_stream_items<=0;
  for(i=0;i<16;i=i+1) acc_tile[i]<=0;
 end else begin
  done<=0;out_valid<=0;pe_in_valid<=0;a_rd_en<=0;b_rd_en<=0;residual_rd_en<=0;scale_rd_en<=0;
  busy<=(state!=ST_FILL)||buffer_full||start_pending;
  if(add_scale_wr_valid)add_scale_r<=add_scale_wr_data;
  if(start) begin if(all_complete)done<=1;else start_pending<=1;end
  if(clear) begin state<=ST_FILL;group_idx<=0;cap_row<=0;cap_col<=0;kt<=0;ct<=0;lane_idx<=0;buffer_full<=0;
   all_complete<=0;start_pending<=0;busy<=0;stat_input_writes<=0;stat_input_errors<=0;stat_tiles<=0;
   stat_acc_errors<=0;stat_quant_errors<=0;stat_add_errors<=0;stat_stream_items<=0;
  end else begin
   if(in_wr_valid&&!in_wr_ready)stat_input_errors<=stat_input_errors+1'b1;
   if(accept) begin
    stat_input_writes<=stat_input_writes+1'b1;
    if(cap_col==IN_REAL-1) begin cap_col<=0;if(cap_row==3) begin cap_row<=0;buffer_full<=1;end else cap_row<=cap_row+1'b1;end
    else cap_col<=cap_col+1'b1;
   end
   case(state)
    ST_FILL: if(buffer_full) begin kt<=0;ct<=0;lane_idx<=0;state<=ST_LOAD;end
    ST_LOAD: begin b_rd_en<=1;b_rd_addr<=kt*OUT_COL_TILES+(ct>>2);
     if(kt<REAL_K_TILES)begin a_rd_en<=1;a_rd_addr<=kt;end state<=ST_WAIT;end
    ST_WAIT:state<=ST_CAPTURE;
    ST_CAPTURE: begin
     for(i=0;i<16;i=i+1) begin
      if(((group_idx<<2)+(i/4))>=ROWS_REAL)pe_a_flat[255-i*16 -:16]<=0;
      else if(kt<REAL_K_TILES)pe_a_flat[255-i*16 -:16]<=a_rd_data[255-i*16 -:16];
      else if((i%4)==0)pe_a_flat[255-i*16 -:16]<=16'sd16384;
      else if((i%4)==1)pe_a_flat[255-i*16 -:16]<=16'sd1;
      else pe_a_flat[255-i*16 -:16]<=0;
      if((kt<REAL_K_TILES)||((i/4)<2))pe_b_flat[255-i*16 -:16]<=b_rd_data[255-i*16 -:16];
      else pe_b_flat[255-i*16 -:16]<=0;
     end state<=ST_FIRE;
    end
    ST_FIRE:if(pe_in_ready)begin pe_in_valid<=1;state<=ST_PE_WAIT;end
    ST_PE_WAIT:if(pe_out_valid)state<=ST_ACC;
    ST_ACC:begin
     for(i=0;i<16;i=i+1)acc_tile[i]<=(kt==0)?$signed(pe_c_flat[511-i*32 -:32]):acc_tile[i]+$signed(pe_c_flat[511-i*32 -:32]);
     stat_tiles<=stat_tiles+1'b1;
     if(kt==K_TILES-1)begin kt<=0;lane_idx<=0;state<=ST_QREQ;end else begin kt<=kt+1'b1;state<=ST_LOAD;end
    end
    ST_QREQ:begin scale_rd_en<=1;scale_rd_addr<=lane_col;residual_rd_en<=global_row<ROWS_REAL;
     residual_rd_addr<=group_idx*OUT_COL_TILES+(ct>>2);state<=ST_QWAIT;end
    ST_QWAIT:state<=ST_QUANT;
    ST_QUANT:begin
     quant_acc_pipe<=acc_tile[lane_idx];quant_scale_pipe<=scale_rd_data_s;
     residual_lane_pipe<=residual_lane;residual_scale_pipe<=add_scale_r;
     residual_real_pipe<=global_row<ROWS_REAL;
     state<=ST_QPRODUCT;
    end
    ST_QPRODUCT:begin
     quant_wide<=(quant_acc_pipe*quant_scale_pipe)>>>29;
     if(residual_real_pipe)residual_wide<=(residual_lane_pipe*residual_scale_pipe)>>>29;else residual_wide<=0;
     state<=ST_QCLAMP;
    end
    ST_QCLAMP:begin
     if(quant_wide>32767)quant_r<=16'sh7fff;else if(quant_wide < -32768)quant_r<=16'sh8000;else quant_r<=quant_wide[15:0];
     if(residual_wide>32767)residual_r<=16'sh7fff;else if(residual_wide < -32768)residual_r<=16'sh8000;else residual_r<=residual_wide[15:0];
     state<=ST_QADD;
    end
    ST_QADD:begin add_wide<=quant_r+residual_r;state<=ST_QOUT;end
    ST_QOUT:begin
     if(add_wide>32767)add_r=16'sh7fff;else if(add_wide < -32768)add_r=16'sh8000;else add_r=add_wide[15:0];
     out_valid<=1;out_addr<=lane_addr;out_data<=add_r;stat_stream_items<=stat_stream_items+1'b1;
     if(lane_idx==15)begin lane_idx<=0;if(ct==OUT_DIM-TILE)begin ct<=0;buffer_full<=0;
       if(group_idx==63)begin all_complete<=1;if(start_pending)begin done<=1;start_pending<=0;end end else group_idx<=group_idx+1'b1;
       state<=ST_FILL;end else begin ct<=ct+TILE;state<=ST_LOAD;end end
     else begin lane_idx<=lane_idx+1'b1;state<=ST_QREQ;end
    end
    default:state<=ST_FILL;
   endcase
  end
 end
end
wire _unused=^in_wr_addr^b_dummy;
endmodule
