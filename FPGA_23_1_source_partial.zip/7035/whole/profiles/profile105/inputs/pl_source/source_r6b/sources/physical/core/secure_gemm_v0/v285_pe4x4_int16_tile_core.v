`timescale 1ns/1ps

module v893_pe4x4_int16_tile_core_pipelined (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          clear,
    input  wire          in_valid,
    output wire          in_ready,
    input  wire [255:0]  a_flat,
    input  wire [255:0]  b_flat,
    output reg           out_valid,
    input  wire          out_ready,
    output wire [511:0]  c_flat,
    output reg [31:0]    stat_tiles
);

localparam ST_IDLE          = 3'd0;
localparam ST_K0_MUL        = 3'd1;
localparam ST_K0_ADD_K1_MUL = 3'd2;
localparam ST_K1_PAIR       = 3'd3;
localparam ST_K1_COMMIT     = 3'd4;
localparam ST_DONE          = 3'd5;

reg [2:0] state;
reg signed [15:0] a_mem [0:15];
reg signed [15:0] b_mem [0:15];
reg signed [31:0] prod0_r [0:15];
reg signed [31:0] prod1_r [0:15];
reg signed [31:0] pair_sum_r [0:15];
reg signed [31:0] c_mem [0:15];
reg signed [15:0] mul_a0 [0:3],mul_a1 [0:3],mul_b0 [0:3],mul_b1 [0:3];
reg mul_valid;
integer i,j;

assign in_ready = (state == ST_IDLE);
assign c_flat = {
    c_mem[0], c_mem[1], c_mem[2], c_mem[3],
    c_mem[4], c_mem[5], c_mem[6], c_mem[7],
    c_mem[8], c_mem[9], c_mem[10], c_mem[11],
    c_mem[12], c_mem[13], c_mem[14], c_mem[15]
};

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        out_valid <= 1'b0;
        stat_tiles <= 32'd0;
        mul_valid <= 1'b0;
        for (i = 0; i < 16; i = i + 1) begin
            a_mem[i] <= 16'sd0;
            b_mem[i] <= 16'sd0;
            prod0_r[i] <= 32'sd0;
            prod1_r[i] <= 32'sd0;
            pair_sum_r[i] <= 32'sd0;
            c_mem[i] <= 32'sd0;
        end
    end else begin
        if (clear) begin
            state <= ST_IDLE;
            out_valid <= 1'b0;
            stat_tiles <= 32'd0;
            mul_valid <= 1'b0;
            for (i = 0; i < 16; i = i + 1) begin
                prod0_r[i] <= 32'sd0;
                prod1_r[i] <= 32'sd0;
                pair_sum_r[i] <= 32'sd0;
                c_mem[i] <= 32'sd0;
            end
        end else begin
            mul_valid <= 1'b0;
            if (mul_valid) begin
                for (i=0;i<16;i=i+1) begin
                    prod0_r[i] <= mul_a0[i/4] * mul_b0[i%4];
                    prod1_r[i] <= mul_a1[i/4] * mul_b1[i%4];
                end
            end
            if (state == ST_IDLE) begin
                out_valid <= 1'b0;
                if (in_valid) begin
                    for (i = 0; i < 16; i = i + 1) begin
                        a_mem[i] <= a_flat[255 - i*16 -: 16];
                        b_mem[i] <= b_flat[255 - i*16 -: 16];
                        prod0_r[i] <= 32'sd0;
                        prod1_r[i] <= 32'sd0;
                        pair_sum_r[i] <= 32'sd0;
                        c_mem[i] <= 32'sd0;
                    end
                    mul_valid <= 1'b1;
                    for (j=0;j<4;j=j+1) begin
                        mul_a0[j] <= a_flat[255-(j*4)*16-:16];
                        mul_a1[j] <= a_flat[255-(j*4+1)*16-:16];
                        mul_b0[j] <= b_flat[255-j*16-:16];
                        mul_b1[j] <= b_flat[255-(j+4)*16-:16];
                    end
                    state <= ST_K0_MUL;
                end
            end else if (state == ST_K0_MUL) begin
                mul_valid <= 1'b1;
                for (j=0;j<4;j=j+1) begin
                    mul_a0[j] <= a_mem[j*4+2];mul_a1[j] <= a_mem[j*4+3];
                    mul_b0[j] <= b_mem[8+j];mul_b1[j] <= b_mem[12+j];
                end
                state <= ST_K0_ADD_K1_MUL;
            end else if (state == ST_K0_ADD_K1_MUL) begin
                for (i = 0; i < 16; i = i + 1)
                    c_mem[i] <= prod0_r[i] + prod1_r[i];
                state <= ST_K1_PAIR;
            end else if (state == ST_K1_PAIR) begin
                for (i = 0; i < 16; i = i + 1)
                    pair_sum_r[i] <= prod0_r[i] + prod1_r[i];
                state <= ST_K1_COMMIT;
            end else if (state == ST_K1_COMMIT) begin
                for (i = 0; i < 16; i = i + 1)
                    c_mem[i] <= c_mem[i] + pair_sum_r[i];
                state <= ST_DONE;
            end else begin
                if (!out_valid) begin
                    out_valid <= 1'b1;
                end else if (out_ready) begin
                    out_valid <= 1'b0;
                    stat_tiles <= stat_tiles + 1'b1;
                    state <= ST_IDLE;
                end
            end
        end
    end
end

endmodule

// Legacy two-compute-cycle PE retained for every stage except the routed
// OutProj hotspot.  Keeping the original module name avoids a global latency
// penalty in QKV/QKT/AV/FC1 users of this shared primitive.
module v285_pe4x4_int16_tile_core_original (
    input  wire          clk,
    input  wire          rst_n,
    input  wire          clear,
    input  wire          in_valid,
    output wire          in_ready,
    input  wire [255:0]  a_flat,
    input  wire [255:0]  b_flat,
    output reg           out_valid,
    input  wire          out_ready,
    output wire [511:0]  c_flat,
    output reg [31:0]    stat_tiles
);

localparam ST_IDLE = 2'd0;
localparam ST_K0   = 2'd1;
localparam ST_K1   = 2'd2;
localparam ST_DONE = 2'd3;

reg [1:0] state;
reg signed [15:0] a_mem [0:15];
reg signed [15:0] b_mem [0:15];
reg signed [31:0] c_mem [0:15];
integer i;

assign in_ready = (state == ST_IDLE);
assign c_flat = {
    c_mem[0], c_mem[1], c_mem[2], c_mem[3],
    c_mem[4], c_mem[5], c_mem[6], c_mem[7],
    c_mem[8], c_mem[9], c_mem[10], c_mem[11],
    c_mem[12], c_mem[13], c_mem[14], c_mem[15]
};

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        out_valid <= 1'b0;
        stat_tiles <= 32'd0;
        for (i = 0; i < 16; i = i + 1) begin
            a_mem[i] <= 16'sd0;
            b_mem[i] <= 16'sd0;
            c_mem[i] <= 32'sd0;
        end
    end else begin
        if (clear) begin
            state <= ST_IDLE;
            out_valid <= 1'b0;
            stat_tiles <= 32'd0;
            for (i = 0; i < 16; i = i + 1)
                c_mem[i] <= 32'sd0;
        end else begin
            if (state == ST_IDLE) begin
                out_valid <= 1'b0;
                if (in_valid) begin
                    for (i = 0; i < 16; i = i + 1) begin
                        a_mem[i] <= a_flat[255 - i*16 -: 16];
                        b_mem[i] <= b_flat[255 - i*16 -: 16];
                        c_mem[i] <= 32'sd0;
                    end
                    state <= ST_K0;
                end
            end else if (state == ST_K0) begin
                c_mem[0]  <= a_mem[0]  * b_mem[0]  + a_mem[1]  * b_mem[4];
                c_mem[1]  <= a_mem[0]  * b_mem[1]  + a_mem[1]  * b_mem[5];
                c_mem[2]  <= a_mem[0]  * b_mem[2]  + a_mem[1]  * b_mem[6];
                c_mem[3]  <= a_mem[0]  * b_mem[3]  + a_mem[1]  * b_mem[7];
                c_mem[4]  <= a_mem[4]  * b_mem[0]  + a_mem[5]  * b_mem[4];
                c_mem[5]  <= a_mem[4]  * b_mem[1]  + a_mem[5]  * b_mem[5];
                c_mem[6]  <= a_mem[4]  * b_mem[2]  + a_mem[5]  * b_mem[6];
                c_mem[7]  <= a_mem[4]  * b_mem[3]  + a_mem[5]  * b_mem[7];
                c_mem[8]  <= a_mem[8]  * b_mem[0]  + a_mem[9]  * b_mem[4];
                c_mem[9]  <= a_mem[8]  * b_mem[1]  + a_mem[9]  * b_mem[5];
                c_mem[10] <= a_mem[8]  * b_mem[2]  + a_mem[9]  * b_mem[6];
                c_mem[11] <= a_mem[8]  * b_mem[3]  + a_mem[9]  * b_mem[7];
                c_mem[12] <= a_mem[12] * b_mem[0]  + a_mem[13] * b_mem[4];
                c_mem[13] <= a_mem[12] * b_mem[1]  + a_mem[13] * b_mem[5];
                c_mem[14] <= a_mem[12] * b_mem[2]  + a_mem[13] * b_mem[6];
                c_mem[15] <= a_mem[12] * b_mem[3]  + a_mem[13] * b_mem[7];
                state <= ST_K1;
            end else if (state == ST_K1) begin
                c_mem[0]  <= c_mem[0]  + a_mem[2]  * b_mem[8]  + a_mem[3]  * b_mem[12];
                c_mem[1]  <= c_mem[1]  + a_mem[2]  * b_mem[9]  + a_mem[3]  * b_mem[13];
                c_mem[2]  <= c_mem[2]  + a_mem[2]  * b_mem[10] + a_mem[3]  * b_mem[14];
                c_mem[3]  <= c_mem[3]  + a_mem[2]  * b_mem[11] + a_mem[3]  * b_mem[15];
                c_mem[4]  <= c_mem[4]  + a_mem[6]  * b_mem[8]  + a_mem[7]  * b_mem[12];
                c_mem[5]  <= c_mem[5]  + a_mem[6]  * b_mem[9]  + a_mem[7]  * b_mem[13];
                c_mem[6]  <= c_mem[6]  + a_mem[6]  * b_mem[10] + a_mem[7]  * b_mem[14];
                c_mem[7]  <= c_mem[7]  + a_mem[6]  * b_mem[11] + a_mem[7]  * b_mem[15];
                c_mem[8]  <= c_mem[8]  + a_mem[10] * b_mem[8]  + a_mem[11] * b_mem[12];
                c_mem[9]  <= c_mem[9]  + a_mem[10] * b_mem[9]  + a_mem[11] * b_mem[13];
                c_mem[10] <= c_mem[10] + a_mem[10] * b_mem[10] + a_mem[11] * b_mem[14];
                c_mem[11] <= c_mem[11] + a_mem[10] * b_mem[11] + a_mem[11] * b_mem[15];
                c_mem[12] <= c_mem[12] + a_mem[14] * b_mem[8]  + a_mem[15] * b_mem[12];
                c_mem[13] <= c_mem[13] + a_mem[14] * b_mem[9]  + a_mem[15] * b_mem[13];
                c_mem[14] <= c_mem[14] + a_mem[14] * b_mem[10] + a_mem[15] * b_mem[14];
                c_mem[15] <= c_mem[15] + a_mem[14] * b_mem[11] + a_mem[15] * b_mem[15];
                state <= ST_DONE;
            end else begin
                if (!out_valid) begin
                    out_valid <= 1'b1;
                end else if (out_ready) begin
                    out_valid <= 1'b0;
                    stat_tiles <= stat_tiles + 1'b1;
                    state <= ST_IDLE;
                end
            end
        end
    end
end

endmodule

// Default0 preserves the exact original public cycle behavior. Actual hot
// callers opt into separated products/pair/accumulate stages and wait VALID.
module v285_pe4x4_int16_tile_core #(parameter integer PIPELINED_ARITHMETIC=0)(
 input wire clk,rst_n,clear,in_valid,output wire in_ready,
 input wire[255:0]a_flat,b_flat,output wire out_valid,input wire out_ready,
 output wire[511:0]c_flat,output wire[31:0]stat_tiles
);
 generate if(PIPELINED_ARITHMETIC==0)begin:g_original
  v285_pe4x4_int16_tile_core_original u_original(.clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(in_valid),.in_ready(in_ready),.a_flat(a_flat),.b_flat(b_flat),.out_valid(out_valid),.out_ready(out_ready),.c_flat(c_flat),.stat_tiles(stat_tiles));
 end else begin:g_pipeline
  v893_pe4x4_int16_tile_core_pipelined u_pipeline(.clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(in_valid),.in_ready(in_ready),.a_flat(a_flat),.b_flat(b_flat),.out_valid(out_valid),.out_ready(out_ready),.c_flat(c_flat),.stat_tiles(stat_tiles));
 end endgenerate
endmodule
