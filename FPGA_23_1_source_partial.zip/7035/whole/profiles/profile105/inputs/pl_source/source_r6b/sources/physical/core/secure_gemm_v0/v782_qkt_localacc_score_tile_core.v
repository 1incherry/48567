`timescale 1ns/1ps

// V782 local-accumulator QK^T engine.  Only one 4x4 output tile remains live;
// the quantized score tile is emitted immediately after its K reduction.
module v718_external_bank_qkt_banked_acc16_vecquant_score_tile_core_nomemh #(
    parameter M = 200,
    parameter K = 200,
    parameter N = 64
) (
    input wire clk, input wire rst_n, input wire clear, input wire start,
    input wire [15:0] qkt_a_base, input wire [15:0] qkt_b_base,
    input wire [15:0] qkt_scale_base, input wire [31:0] qkt_quant_base,
    input wire scale_wr_valid, input wire [15:0] scale_wr_addr,
    input wire signed [31:0] scale_wr_data,
    output wire ext_a_rd_en, output wire [15:0] ext_a_rd_addr,
    input wire [255:0] ext_a_rd_data,
    output wire ext_b_rd_en, output wire [15:0] ext_b_rd_addr,
    input wire [255:0] ext_b_rd_data,
    output reg busy, output reg done,
    output reg [31:0] stat_tiles, output reg [31:0] stat_tile_reads,
    output reg [31:0] stat_prefetches, output reg [31:0] stat_underflows,
    output reg [31:0] stat_quant_errors, output reg [31:0] stat_scale_writes,
    output reg [31:0] stat_scale_errors, output reg [31:0] stat_cycles,
    output reg [4:0] stat_stage,
    output reg out_tile_valid, output reg [15:0] out_tile_addr,
    output reg [127:0] out_tile_data
);

localparam TILE=4, M_TILES=M/TILE, N_TILES=N/TILE, K_TILES=K/TILE;
localparam SCALE_ALL_DEPTH=N*3;
localparam ST_IDLE=0, ST_LOAD=1, ST_WAIT=2, ST_CAPTURE=3, ST_FIRE=4;
localparam ST_PE_WAIT=5, ST_ACC=6, ST_QUANT_MUL=7, ST_QUANT_PACK=8, ST_DONE=9;
localparam ST_QUANT_PREP=10, ST_QUANT_PIPE=11;

reg [3:0] state;
reg [5:0] mt, nt, kt;
reg pe_in_valid, a_rd_en, b_rd_en;
reg [15:0] a_rd_addr, b_rd_addr;
reg [255:0] pe_a_flat, pe_b_flat;
wire pe_in_ready, pe_out_valid;
wire [511:0] pe_c_flat;
wire [31:0] pe_stat_tiles;
reg signed [31:0] acc_tile [0:15];
reg signed [31:0] scale_mem [0:SCALE_ALL_DEPTH-1];
reg signed [63:0] quant_wide;
reg signed [7:0] quant_r;
reg [127:0] quant_pack;
reg signed [63:0] quant_lane [0:15];
reg signed [31:0] quant_acc_operand [0:15];
reg signed [31:0] quant_scale_operand [0:3];
reg signed [31:0] quant_scale_pipe [0:3];
reg signed [31:0] quant_acc_pipe [0:15];
integer i;

assign ext_a_rd_en=a_rd_en;
assign ext_b_rd_en=b_rd_en;
assign ext_a_rd_addr=qkt_a_base+a_rd_addr;
assign ext_b_rd_addr=qkt_b_base+b_rd_addr;

v893_pe4x4_int16_tile_core_pipelined u_pe(
    .clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(pe_in_valid),
    .in_ready(pe_in_ready),.a_flat(pe_a_flat),.b_flat(pe_b_flat),
    .out_valid(pe_out_valid),.out_ready(1'b1),.c_flat(pe_c_flat),
    .stat_tiles(pe_stat_tiles));

always @(posedge clk) begin
    if(scale_wr_valid && scale_wr_addr<SCALE_ALL_DEPTH)
        scale_mem[scale_wr_addr]<=scale_wr_data;
end

always @(posedge clk) begin
    if(!rst_n) begin
        state<=ST_IDLE; mt<=0; nt<=0; kt<=0; pe_in_valid<=0;
        a_rd_en<=0; b_rd_en<=0; a_rd_addr<=0; b_rd_addr<=0;
        pe_a_flat<=0; pe_b_flat<=0; busy<=0; done<=0;
        stat_tiles<=0; stat_tile_reads<=0; stat_prefetches<=0;
        stat_underflows<=0; stat_quant_errors<=0; stat_scale_writes<=0;
        stat_scale_errors<=0; stat_cycles<=0; stat_stage<=ST_IDLE;
        out_tile_valid<=0; out_tile_addr<=0; out_tile_data<=0; quant_pack<=0;
        for(i=0;i<16;i=i+1) begin
            acc_tile[i]<=0;
            quant_lane[i]<=0;
            quant_acc_operand[i]<=0;
            quant_acc_pipe[i]<=0;
        end
        for(i=0;i<4;i=i+1) begin
            quant_scale_operand[i]<=0;
            quant_scale_pipe[i]<=0;
        end
    end else begin
        done<=0; out_tile_valid<=0; pe_in_valid<=0; a_rd_en<=0; b_rd_en<=0;
        stat_stage<=state;
        if(busy) stat_cycles<=stat_cycles+1'b1;
        if(scale_wr_valid) begin
            if(scale_wr_addr<SCALE_ALL_DEPTH) stat_scale_writes<=stat_scale_writes+1'b1;
            else stat_scale_errors<=stat_scale_errors+1'b1;
        end
        if(clear) begin
            state<=ST_IDLE; busy<=0; stat_tiles<=0; stat_tile_reads<=0;
            stat_prefetches<=0; stat_underflows<=0; stat_quant_errors<=0;
            stat_scale_writes<=0; stat_scale_errors<=0; stat_cycles<=0;
        end else case(state)
            ST_IDLE: begin
                busy<=0;
                if(start) begin
                    busy<=1; mt<=0; nt<=0; kt<=0; stat_tiles<=0;
                    stat_tile_reads<=0; stat_prefetches<=0; stat_underflows<=0;
                    stat_quant_errors<=0; stat_cycles<=0; state<=ST_LOAD;
                end
            end
            ST_LOAD: begin
                a_rd_en<=1; b_rd_en<=1;
                a_rd_addr<=mt*K_TILES+kt;
                b_rd_addr<=kt*N_TILES+nt;
                state<=ST_WAIT;
            end
            ST_WAIT: state<=ST_CAPTURE;
            ST_CAPTURE: begin
                pe_a_flat<=ext_a_rd_data; pe_b_flat<=ext_b_rd_data;
                stat_tile_reads<=stat_tile_reads+1'b1; state<=ST_FIRE;
            end
            ST_FIRE: if(pe_in_ready) begin pe_in_valid<=1; state<=ST_PE_WAIT; end
            ST_PE_WAIT: if(pe_out_valid) state<=ST_ACC;
            ST_ACC: begin
                for(i=0;i<16;i=i+1)
                    acc_tile[i] <= (kt==0) ? $signed(pe_c_flat[511-i*32 -: 32]) :
                        acc_tile[i]+$signed(pe_c_flat[511-i*32 -: 32]);
                stat_tiles<=stat_tiles+1'b1;
                if(kt==K_TILES-1) begin kt<=0; state<=ST_QUANT_PREP; end
                else begin kt<=kt+1'b1; state<=ST_LOAD; end
            end
            // Register the accumulator and asynchronous LUTRAM scale reads
            // before the DSP multipliers.  This removes nt -> scale address ->
            // LUTRAM -> DSP48 cascade from the V894 critical path.
            ST_QUANT_PREP: begin
                for(i=0;i<16;i=i+1)
                    quant_acc_operand[i] <= acc_tile[i];
                quant_scale_operand[0] <= scale_mem[qkt_scale_base+(nt<<2)+0];
                quant_scale_operand[1] <= scale_mem[qkt_scale_base+(nt<<2)+1];
                quant_scale_operand[2] <= scale_mem[qkt_scale_base+(nt<<2)+2];
                quant_scale_operand[3] <= scale_mem[qkt_scale_base+(nt<<2)+3];
                state<=ST_QUANT_PIPE;
            end
            ST_QUANT_PIPE: begin
                for(i=0;i<16;i=i+1) quant_acc_pipe[i]<=quant_acc_operand[i];
                for(i=0;i<4;i=i+1) quant_scale_pipe[i]<=quant_scale_operand[i];
                state<=ST_QUANT_MUL;
            end
            // Register all 16 scaled products.  This lets Vivado use the DSP
            // output registers and removes the multiplier/shift/saturation/
            // packing chain from the out_tile_data endpoint.
            ST_QUANT_MUL: begin
                for(i=0;i<16;i=i+1) begin
                    quant_lane[i] <=
                        (quant_acc_pipe[i]*quant_scale_pipe[i%4])>>>29;
                end
                state<=ST_QUANT_PACK;
            end
            ST_QUANT_PACK: begin
                for(i=0;i<16;i=i+1) begin
                    quant_wide=quant_lane[i];
                    if(quant_wide>127) quant_r=8'sh7f;
                    else if(quant_wide < -128) quant_r=8'sh80;
                    else quant_r=quant_wide[7:0];
                    quant_pack[127-i*8 -: 8]=quant_r;
                end
                out_tile_valid<=1; out_tile_addr<=mt*N_TILES+nt;
                out_tile_data<=quant_pack;
                if(nt==N_TILES-1) begin
                    nt<=0;
                    if(mt==M_TILES-1) state<=ST_DONE;
                    else begin mt<=mt+1'b1; state<=ST_LOAD; end
                end else begin nt<=nt+1'b1; state<=ST_LOAD; end
            end
            ST_DONE: begin busy<=0; done<=1; state<=ST_IDLE; end
            default: state<=ST_IDLE;
        endcase
    end
end

wire _unused_qbase=^qkt_quant_base;
endmodule
