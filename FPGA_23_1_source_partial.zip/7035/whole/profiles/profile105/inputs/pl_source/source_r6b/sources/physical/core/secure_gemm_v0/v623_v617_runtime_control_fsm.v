`timescale 1ns/1ps

module v623_v617_runtime_control_fsm (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        clear,
    input  wire        start,
    output reg         busy,
    output reg         done,
    output reg [31:0]  stat_cycle_count,
    output reg [31:0]  stat_errors,
    output reg [7:0]   stat_stage,
    output reg [1:0]   current_head,
    output reg         clear_all,
    output reg         concat_clear,
    output reg         qkv_start,
    output reg         qkt_start,
    output reg         sm_start,
    output reg         pack_start,
    output reg         av_start,
    output reg         concat_start,
    output reg         outproj_start,
    output reg         norm2_start,
    output reg         fc1_start,
    output reg         gelu_start,
    output reg         fc2_start,
    output reg         norm3_start,
    output reg [15:0]  q_base,
    output reg [15:0]  k_base,
    output reg [15:0]  v_base,
    output reg [15:0]  qkt_scale_base,
    output reg [31:0]  qkt_quant_base,
    output reg [15:0]  row_max_base,
    output reg [15:0]  row_sum_base,
    output reg [15:0]  factor_base,
    output reg [31:0]  prob_base,
    output reg [15:0]  av_a_tile_base,
    output reg [15:0]  av_scale_base,
    output reg [31:0]  av_quant_base,
    output reg         desc_in_valid,
    input  wire        desc_in_ready,
    output reg [63:0]  desc_in_word,
    input  wire        external_desc_enable,
    input  wire        external_desc_valid,
    output wire        external_desc_ready,
    input  wire [63:0] external_desc_word,
    input  wire        proj_done,
    input  wire        qkv_done,
    input  wire        qkt_done,
    input  wire        pack_done,
    input  wire        av_done,
    input  wire        concat_done,
    input  wire        outproj_done,
    input  wire        norm2_done,
    input  wire        fc1_done,
    input  wire        gelu_done,
    output reg         fc2_pad_active,
    input  wire        fc2_pad_done,
    input  wire        fc2_done,
    input  wire        norm3_done,
    input  wire [31:0] proj_desc_errors,
    input  wire [31:0] proj_quant_errors,
    input  wire [31:0] qkv_errors,
    input  wire [31:0] qkt_errors,
    input  wire [31:0] sm_errors,
    input  wire [31:0] pack_errors,
    input  wire [31:0] av_errors,
    input  wire [31:0] concat_errors,
    input  wire [31:0] outproj_errors,
    input  wire [31:0] norm2_errors,
    input  wire [31:0] fc1_errors,
    input  wire [31:0] gelu_errors,
    input  wire [31:0] fc2_errors,
    input  wire [31:0] norm3_errors,
    output reg [31:0]  stat_external_desc_stall_cycles
);

localparam ST_IDLE             = 8'd0;
localparam ST_CONCAT_CLR_HI    = 8'd1;
localparam ST_CONCAT_CLR_LO    = 8'd2;
localparam ST_HEAD_SETUP       = 8'd3;
localparam ST_HEAD_CLR_HI      = 8'd4;
localparam ST_HEAD_CLR_LO      = 8'd5;
localparam ST_QKV_START        = 8'd6;
localparam ST_DESC_SEND        = 8'd7;
localparam ST_DESC_ADVANCE     = 8'd8;
localparam ST_PROJ_QKV_WAIT    = 8'd9;
localparam ST_QKT_START        = 8'd10;
localparam ST_QKT_WAIT         = 8'd11;
localparam ST_SM_PACK_START    = 8'd12;
localparam ST_PACK_WAIT        = 8'd13;
localparam ST_AV_START         = 8'd14;
localparam ST_AV_WAIT          = 8'd15;
localparam ST_HEAD_NEXT        = 8'd16;
localparam ST_CONCAT_START     = 8'd17;
localparam ST_CONCAT_WAIT      = 8'd18;
localparam ST_OUTPROJ_START    = 8'd19;
localparam ST_OUTPROJ_WAIT     = 8'd20;
localparam ST_NORM2_START      = 8'd21;
localparam ST_NORM2_WAIT       = 8'd22;
localparam ST_FC1_START        = 8'd23;
localparam ST_FC1_WAIT         = 8'd24;
localparam ST_GELU_START       = 8'd25;
localparam ST_GELU_WAIT        = 8'd26;
localparam ST_FC2_PAD_START    = 8'd27;
localparam ST_FC2_PAD_WAIT     = 8'd28;
localparam ST_FC2_START        = 8'd29;
localparam ST_FC2_WAIT         = 8'd30;
localparam ST_NORM3_START      = 8'd31;
localparam ST_NORM3_WAIT       = 8'd32;
localparam ST_DONE             = 8'd33;

reg [7:0] state;
reg [3:0] desc_idx;
reg [1:0] desc_count;

assign external_desc_ready = external_desc_enable && (state == ST_DESC_SEND) && desc_in_ready;

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        busy <= 1'b0;
        done <= 1'b0;
        stat_cycle_count <= 32'd0;
        stat_errors <= 32'd0;
        stat_stage <= ST_IDLE;
        current_head <= 2'd0;
        clear_all <= 1'b0;
        concat_clear <= 1'b0;
        qkv_start <= 1'b0;
        qkt_start <= 1'b0;
        sm_start <= 1'b0;
        pack_start <= 1'b0;
        av_start <= 1'b0;
        concat_start <= 1'b0;
        outproj_start <= 1'b0;
        norm2_start <= 1'b0;
        fc1_start <= 1'b0;
        gelu_start <= 1'b0;
        fc2_start <= 1'b0;
        norm3_start <= 1'b0;
        q_base <= 16'd0;
        k_base <= 16'd0;
        v_base <= 16'd0;
        qkt_scale_base <= 16'd0;
        qkt_quant_base <= 32'd0;
        row_max_base <= 16'd0;
        row_sum_base <= 16'd0;
        factor_base <= 16'd0;
        prob_base <= 32'd0;
        av_a_tile_base <= 16'd0;
        av_scale_base <= 16'd0;
        av_quant_base <= 32'd0;
        desc_in_valid <= 1'b0;
        desc_in_word <= 64'd0;
        desc_idx <= 4'd0;
        desc_count <= 2'd0;
        fc2_pad_active <= 1'b0;
        stat_external_desc_stall_cycles <= 32'd0;
    end else begin
        done <= 1'b0;
        clear_all <= 1'b0;
        concat_clear <= 1'b0;
        qkv_start <= 1'b0;
        qkt_start <= 1'b0;
        sm_start <= 1'b0;
        pack_start <= 1'b0;
        av_start <= 1'b0;
        concat_start <= 1'b0;
        outproj_start <= 1'b0;
        norm2_start <= 1'b0;
        fc1_start <= 1'b0;
        gelu_start <= 1'b0;
        fc2_start <= 1'b0;
        norm3_start <= 1'b0;
        fc2_pad_active <= 1'b0;
        stat_stage <= state;
        if (busy)
            stat_cycle_count <= stat_cycle_count + 1'b1;

        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            stat_cycle_count <= 32'd0;
            stat_errors <= 32'd0;
            desc_in_valid <= 1'b0;
            desc_in_word <= 64'd0;
            current_head <= 2'd0;
            desc_idx <= 4'd0;
            desc_count <= 2'd0;
            stat_external_desc_stall_cycles <= 32'd0;
        end else begin
            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    desc_in_valid <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        stat_cycle_count <= 32'd0;
                        stat_errors <= 32'd0;
                        stat_external_desc_stall_cycles <= 32'd0;
                        current_head <= 2'd0;
                        state <= ST_CONCAT_CLR_HI;
                    end
                end

                ST_CONCAT_CLR_HI: begin
                    concat_clear <= 1'b1;
                    state <= ST_CONCAT_CLR_LO;
                end

                ST_CONCAT_CLR_LO: begin
                    concat_clear <= 1'b0;
                    state <= ST_HEAD_SETUP;
                end

                ST_HEAD_SETUP: begin
                    q_base <= current_head * 16'd800;
                    k_base <= current_head * 16'd800;
                    v_base <= current_head * 16'd800;
                    qkt_scale_base <= current_head * 16'd200;
                    qkt_quant_base <= current_head * 32'd40000;
                    row_max_base <= current_head * 16'd200;
                    row_sum_base <= current_head * 16'd200;
                    factor_base <= current_head * 16'd200;
                    prob_base <= current_head * 32'd40000;
                    av_a_tile_base <= current_head * 16'd2500;
                    av_scale_base <= current_head * 16'd64;
                    av_quant_base <= current_head * 32'd12800;
                    desc_idx <= {2'd0, current_head} * 4'd3;
                    desc_count <= 2'd0;
                    state <= ST_HEAD_CLR_HI;
                end

                ST_HEAD_CLR_HI: begin
                    clear_all <= 1'b1;
                    state <= ST_HEAD_CLR_LO;
                end

                ST_HEAD_CLR_LO: begin
                    clear_all <= 1'b0;
                    state <= ST_QKV_START;
                end

                ST_QKV_START: begin
                    qkv_start <= 1'b1;
                    state <= ST_DESC_SEND;
                end

                ST_DESC_SEND: begin
                    if (external_desc_enable) begin
                        desc_in_valid <= external_desc_valid;
                        desc_in_word <= external_desc_word;
                        if (!external_desc_valid)
                            stat_external_desc_stall_cycles <= stat_external_desc_stall_cycles + 1'b1;
                        if (external_desc_valid && desc_in_ready)
                            state <= ST_DESC_ADVANCE;
                    end else begin
                        desc_in_valid <= 1'b1;
                        if (desc_idx == 4'd0)
                            desc_in_word <= 64'h1001010203011000;
                        else if (desc_idx == 4'd1)
                            desc_in_word <= 64'h1041010203011001;
                        else if (desc_idx == 4'd2)
                            desc_in_word <= 64'h1081010203011002;
                        else if (desc_idx == 4'd3)
                            desc_in_word <= 64'h1101010203011003;
                        else if (desc_idx == 4'd4)
                            desc_in_word <= 64'h1141010203011004;
                        else if (desc_idx == 4'd5)
                            desc_in_word <= 64'h1181010203011005;
                        else if (desc_idx == 4'd6)
                            desc_in_word <= 64'h1201010203011006;
                        else if (desc_idx == 4'd7)
                            desc_in_word <= 64'h1241010203011007;
                        else
                            desc_in_word <= 64'h1281010203011008;
                        if (desc_in_ready)
                            state <= ST_DESC_ADVANCE;
                    end
                end

                ST_DESC_ADVANCE: begin
                    desc_in_valid <= 1'b0;
                    if (desc_count == 2'd2)
                        state <= ST_PROJ_QKV_WAIT;
                    else begin
                        desc_count <= desc_count + 1'b1;
                        desc_idx <= desc_idx + 1'b1;
                        state <= ST_DESC_SEND;
                    end
                end

                ST_PROJ_QKV_WAIT: begin
                    if (proj_done && qkv_done) begin
                        if ((|proj_desc_errors) || (|proj_quant_errors) || (|qkv_errors))
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_QKT_START;
                    end
                end

                ST_QKT_START: begin
                    qkt_start <= 1'b1;
                    state <= ST_QKT_WAIT;
                end

                ST_QKT_WAIT: begin
                    if (qkt_done) begin
                        if (|qkt_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_SM_PACK_START;
                    end
                end

                ST_SM_PACK_START: begin
                    sm_start <= 1'b1;
                    pack_start <= 1'b1;
                    state <= ST_PACK_WAIT;
                end

                ST_PACK_WAIT: begin
                    if (pack_done) begin
                        if ((|sm_errors) || (|pack_errors))
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_AV_START;
                    end
                end

                ST_AV_START: begin
                    av_start <= 1'b1;
                    state <= ST_AV_WAIT;
                end

                ST_AV_WAIT: begin
                    if (av_done) begin
                        if (|av_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_HEAD_NEXT;
                    end
                end

                ST_HEAD_NEXT: begin
                    if (current_head == 2'd2)
                        state <= ST_CONCAT_START;
                    else begin
                        current_head <= current_head + 1'b1;
                        state <= ST_HEAD_SETUP;
                    end
                end

                ST_CONCAT_START: begin
                    concat_start <= 1'b1;
                    state <= ST_CONCAT_WAIT;
                end

                ST_CONCAT_WAIT: begin
                    if (concat_done) begin
                        if (|concat_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_OUTPROJ_START;
                    end
                end

                ST_OUTPROJ_START: begin
                    outproj_start <= 1'b1;
                    state <= ST_OUTPROJ_WAIT;
                end

                ST_OUTPROJ_WAIT: begin
                    if (outproj_done) begin
                        if (|outproj_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_NORM2_START;
                    end
                end

                ST_NORM2_START: begin
                    norm2_start <= 1'b1;
                    state <= ST_NORM2_WAIT;
                end

                ST_NORM2_WAIT: begin
                    if (norm2_done) begin
                        if (|norm2_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_FC1_START;
                    end
                end

                ST_FC1_START: begin
                    fc1_start <= 1'b1;
                    state <= ST_FC1_WAIT;
                end

                ST_FC1_WAIT: begin
                    if (fc1_done) begin
                        if (|fc1_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_GELU_START;
                    end
                end

                ST_GELU_START: begin
                    gelu_start <= 1'b1;
                    state <= ST_GELU_WAIT;
                end

                ST_GELU_WAIT: begin
                    if (gelu_done) begin
                        if (|gelu_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_FC2_PAD_START;
                    end
                end

                ST_FC2_PAD_START: begin
                    fc2_pad_active <= 1'b1;
                    state <= ST_FC2_PAD_WAIT;
                end

                ST_FC2_PAD_WAIT: begin
                    fc2_pad_active <= 1'b1;
                    if (fc2_pad_done)
                        state <= ST_FC2_START;
                end

                ST_FC2_START: begin
                    fc2_start <= 1'b1;
                    state <= ST_FC2_WAIT;
                end

                ST_FC2_WAIT: begin
                    if (fc2_done) begin
                        if (|fc2_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_NORM3_START;
                    end
                end

                ST_NORM3_START: begin
                    norm3_start <= 1'b1;
                    state <= ST_NORM3_WAIT;
                end

                ST_NORM3_WAIT: begin
                    if (norm3_done) begin
                        if (|norm3_errors)
                            stat_errors <= stat_errors + 1'b1;
                        state <= ST_DONE;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                    busy <= 1'b0;
                    desc_in_valid <= 1'b0;
                end
            endcase
        end
    end
end

endmodule

module v623_v617_stream_repack_router (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        clear,
    input  wire        norm2_out_valid,
    input  wire [15:0] norm2_out_addr,
    input  wire signed [15:0] norm2_out_data,
    output reg         fc1_a_wr_valid,
    output reg [15:0]  fc1_a_wr_addr,
    output reg signed [15:0] fc1_a_wr_data,
    input  wire        gelu_out_valid,
    input  wire [17:0] gelu_out_addr,
    input  wire signed [7:0] gelu_out_data,
    input  wire        fc2_pad_active,
    output reg         fc2_pad_done,
    output reg         fc2_in_wr_valid,
    output reg [17:0]  fc2_in_wr_addr,
    output reg signed [15:0] fc2_in_wr_data,
    output reg [31:0]  stat_fc1_writes,
    output reg [31:0]  stat_fc2_writes
);

reg [7:0] pad_row;
reg       pad_phase;
reg       pad_running;

wire [15:0] norm2_row;
wire [15:0] norm2_col;
wire [17:0] gelu_row;
wire [17:0] gelu_col;

assign norm2_row = norm2_out_addr / 16'd194;
assign norm2_col = norm2_out_addr % 16'd194;
assign gelu_row = gelu_out_addr / 18'd768;
assign gelu_col = gelu_out_addr % 18'd768;

always @(posedge clk) begin
    if (!rst_n) begin
        fc1_a_wr_valid <= 1'b0;
        fc1_a_wr_addr <= 16'd0;
        fc1_a_wr_data <= 16'sd0;
        fc2_pad_done <= 1'b0;
        fc2_in_wr_valid <= 1'b0;
        fc2_in_wr_addr <= 18'd0;
        fc2_in_wr_data <= 16'sd0;
        stat_fc1_writes <= 32'd0;
        stat_fc2_writes <= 32'd0;
        pad_row <= 8'd0;
        pad_phase <= 1'b0;
        pad_running <= 1'b0;
    end else begin
        fc1_a_wr_valid <= 1'b0;
        fc2_in_wr_valid <= 1'b0;
        fc2_pad_done <= 1'b0;

        if (clear) begin
            stat_fc1_writes <= 32'd0;
            stat_fc2_writes <= 32'd0;
            pad_row <= 8'd0;
            pad_phase <= 1'b0;
            pad_running <= 1'b0;
        end else begin
            if (norm2_out_valid) begin
                fc1_a_wr_valid <= 1'b1;
                fc1_a_wr_addr <= norm2_row * 16'd196 + norm2_col;
                if (norm2_row < 16'd208)
                    fc1_a_wr_data <= norm2_out_data;
                else
                    fc1_a_wr_data <= 16'sd0;
                stat_fc1_writes <= stat_fc1_writes + 1'b1;
            end

            if (fc2_pad_active) begin
                if (!pad_running) begin
                    pad_running <= 1'b1;
                    pad_row <= 8'd0;
                    pad_phase <= 1'b0;
                end else if (pad_row < 8'd197) begin
                    fc2_in_wr_valid <= 1'b1;
                    if (!pad_phase) begin
                        fc2_in_wr_addr <= pad_row * 18'd770 + 18'd768;
                        fc2_in_wr_data <= 16'sd16384;
                        pad_phase <= 1'b1;
                    end else begin
                        fc2_in_wr_addr <= pad_row * 18'd770 + 18'd769;
                        fc2_in_wr_data <= 16'sd1;
                        pad_phase <= 1'b0;
                        pad_row <= pad_row + 1'b1;
                    end
                    stat_fc2_writes <= stat_fc2_writes + 1'b1;
                end else begin
                    fc2_pad_done <= 1'b1;
                    pad_running <= 1'b0;
                end
            end else if (gelu_out_valid && (gelu_row < 18'd197)) begin
                fc2_in_wr_valid <= 1'b1;
                fc2_in_wr_addr <= gelu_row * 18'd770 + gelu_col;
                fc2_in_wr_data <= {{8{gelu_out_data[7]}}, gelu_out_data};
                stat_fc2_writes <= stat_fc2_writes + 1'b1;
            end
        end
    end
end

endmodule
