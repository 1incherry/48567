`timescale 1ns/1ps
`define V788_SM4_CTR
`include "source_r6b/sources/physical/core/secure_gemm_v0/v788_sm4_ctr_stream.v"
`include "source_r6b/sources/physical/core/v787_add_this_one_file.v"
