`timescale 1ns/1ps

module v626_axi_like_load_store_shell #(
    parameter AXI_ADDR_WIDTH = 32,
    parameter AXI_DATA_WIDTH = 256,
    parameter BURST_BEATS    = 16
) (
    input  wire                         clk,
    input  wire                         rst_n,
    input  wire                         clear,

    input  wire                         load_cmd_valid,
    output wire                         load_cmd_ready,
    input  wire [AXI_ADDR_WIDTH-1:0]    load_cmd_addr,
    input  wire [15:0]                  load_cmd_beats,
    input  wire [7:0]                   load_cmd_tag,

    output wire                         load_data_valid,
    input  wire                         load_data_ready,
    output wire [AXI_DATA_WIDTH-1:0]    load_data,
    output wire [7:0]                   load_data_tag,
    output wire                         load_data_last,

    input  wire                         store_cmd_valid,
    output wire                         store_cmd_ready,
    input  wire [AXI_ADDR_WIDTH-1:0]    store_cmd_addr,
    input  wire [15:0]                  store_cmd_beats,
    input  wire [7:0]                   store_cmd_tag,

    input  wire                         store_data_valid,
    output wire                         store_data_ready,
    input  wire [AXI_DATA_WIDTH-1:0]    store_data,
    input  wire                         store_data_last,

    output reg  [AXI_ADDR_WIDTH-1:0]    M_AXI_ARADDR,
    output reg  [7:0]                   M_AXI_ARLEN,
    output wire [2:0]                   M_AXI_ARSIZE,
    output wire [1:0]                   M_AXI_ARBURST,
    output reg                          M_AXI_ARVALID,
    input  wire                         M_AXI_ARREADY,
    input  wire [AXI_DATA_WIDTH-1:0]    M_AXI_RDATA,
    input  wire [1:0]                   M_AXI_RRESP,
    input  wire                         M_AXI_RLAST,
    input  wire                         M_AXI_RVALID,
    output wire                         M_AXI_RREADY,

    output reg  [AXI_ADDR_WIDTH-1:0]    M_AXI_AWADDR,
    output reg  [7:0]                   M_AXI_AWLEN,
    output wire [2:0]                   M_AXI_AWSIZE,
    output wire [1:0]                   M_AXI_AWBURST,
    output reg                          M_AXI_AWVALID,
    input  wire                         M_AXI_AWREADY,
    output wire [AXI_DATA_WIDTH-1:0]    M_AXI_WDATA,
    output wire [AXI_DATA_WIDTH/8-1:0]  M_AXI_WSTRB,
    output wire                         M_AXI_WLAST,
    output wire                         M_AXI_WVALID,
    input  wire                         M_AXI_WREADY,
    input  wire [1:0]                   M_AXI_BRESP,
    input  wire                         M_AXI_BVALID,
    output reg                          M_AXI_BREADY,

    output wire                         load_busy,
    output wire                         store_busy,
    output wire [7:0]                   store_active_tag,
    output reg                          load_done_pulse,
    output reg                          store_done_pulse,
    output reg  [31:0]                  stat_read_cmds,
    output reg  [31:0]                  stat_read_beats,
    output reg  [31:0]                  stat_write_cmds,
    output reg  [31:0]                  stat_write_beats,
    output reg  [31:0]                  stat_backpressure_cycles,
    output wire [31:0]                  stat_errors
);

localparam AXI_BYTES = AXI_DATA_WIDTH / 8;
localparam [15:0] AXI_BYTES_U16 = AXI_BYTES[15:0];
localparam [15:0] BURST_BEATS_U16 = BURST_BEATS[15:0];
localparam AXI_SIZE_256 = 3'd5;

localparam RD_IDLE = 2'd0;
localparam RD_ADDR = 2'd1;
localparam RD_DATA = 2'd2;

localparam WR_IDLE = 2'd0;
localparam WR_ADDR = 2'd1;
localparam WR_DATA = 2'd2;
localparam WR_RESP = 2'd3;

reg [1:0] rd_state;
reg [AXI_ADDR_WIDTH-1:0] rd_addr;
reg [15:0] rd_beats_left;
reg [15:0] rd_burst_beats;
reg [7:0]  rd_tag;

reg [1:0] wr_state;
reg [AXI_ADDR_WIDTH-1:0] wr_addr;
reg [15:0] wr_beats_left;
reg [15:0] wr_burst_beats;
reg [15:0] wr_burst_sent;
reg [7:0]  wr_tag;
reg [31:0] stat_read_errors;
reg [31:0] stat_write_errors;

assign stat_errors = stat_read_errors + stat_write_errors;

assign M_AXI_ARSIZE  = AXI_SIZE_256;
assign M_AXI_ARBURST = 2'b01;
assign M_AXI_AWSIZE  = AXI_SIZE_256;
assign M_AXI_AWBURST = 2'b01;

assign load_cmd_ready = (rd_state == RD_IDLE);
assign store_cmd_ready = (wr_state == WR_IDLE);
assign load_busy = (rd_state != RD_IDLE);
assign store_busy = (wr_state != WR_IDLE);
assign store_active_tag = wr_tag;

assign load_data_valid = (rd_state == RD_DATA) && M_AXI_RVALID;
assign load_data = M_AXI_RDATA;
assign load_data_tag = rd_tag;
assign load_data_last = (rd_state == RD_DATA) && M_AXI_RVALID && (rd_beats_left == 16'd1);
assign M_AXI_RREADY = (rd_state == RD_DATA) && load_data_ready;

assign store_data_ready = (wr_state == WR_DATA) && M_AXI_WREADY;
assign M_AXI_WVALID = (wr_state == WR_DATA) && store_data_valid;
assign M_AXI_WDATA = store_data;
assign M_AXI_WSTRB = {AXI_DATA_WIDTH/8{1'b1}};
assign M_AXI_WLAST = (wr_state == WR_DATA) && (wr_burst_sent + 1'b1 == wr_burst_beats);

always @(posedge clk) begin
    if (!rst_n) begin
        rd_state <= RD_IDLE;
        rd_addr <= {AXI_ADDR_WIDTH{1'b0}};
        rd_beats_left <= 16'd0;
        rd_burst_beats <= 16'd0;
        rd_tag <= 8'd0;
        M_AXI_ARADDR <= {AXI_ADDR_WIDTH{1'b0}};
        M_AXI_ARLEN <= 8'd0;
        M_AXI_ARVALID <= 1'b0;
        load_done_pulse <= 1'b0;
        stat_read_cmds <= 32'd0;
        stat_read_beats <= 32'd0;
        stat_backpressure_cycles <= 32'd0;
        stat_read_errors <= 32'd0;
    end else begin
        load_done_pulse <= 1'b0;

        if (clear) begin
            rd_state <= RD_IDLE;
            rd_addr <= {AXI_ADDR_WIDTH{1'b0}};
            rd_beats_left <= 16'd0;
            rd_burst_beats <= 16'd0;
            rd_tag <= 8'd0;
            M_AXI_ARVALID <= 1'b0;
            load_done_pulse <= 1'b0;
            stat_read_cmds <= 32'd0;
            stat_read_beats <= 32'd0;
            stat_backpressure_cycles <= 32'd0;
            stat_read_errors <= 32'd0;
        end else begin
            if ((rd_state == RD_DATA) && M_AXI_RVALID && !load_data_ready)
                stat_backpressure_cycles <= stat_backpressure_cycles + 1'b1;

            if ((rd_state == RD_IDLE) && load_cmd_valid) begin
                rd_addr <= load_cmd_addr;
                rd_beats_left <= load_cmd_beats;
                rd_tag <= load_cmd_tag;
                stat_read_cmds <= stat_read_cmds + 1'b1;
                if (load_cmd_beats == 16'd0) begin
                    load_done_pulse <= 1'b1;
                end else begin
                    rd_state <= RD_ADDR;
                end
            end else if (rd_state == RD_ADDR) begin
                if (!M_AXI_ARVALID) begin
                    M_AXI_ARADDR <= rd_addr;
                    if (rd_beats_left > BURST_BEATS_U16)
                        rd_burst_beats <= BURST_BEATS_U16;
                    else
                        rd_burst_beats <= rd_beats_left;
                    if (rd_beats_left > BURST_BEATS_U16)
                        M_AXI_ARLEN <= BURST_BEATS_U16[7:0] - 1'b1;
                    else
                        M_AXI_ARLEN <= rd_beats_left[7:0] - 1'b1;
                    M_AXI_ARVALID <= 1'b1;
                end
                if (M_AXI_ARVALID && M_AXI_ARREADY) begin
                    M_AXI_ARVALID <= 1'b0;
                    rd_state <= RD_DATA;
                end
            end else if (rd_state == RD_DATA) begin
                if (M_AXI_RVALID && load_data_ready) begin
                    stat_read_beats <= stat_read_beats + 1'b1;
                    if (M_AXI_RRESP != 2'b00)
                        stat_read_errors <= stat_read_errors + 1'b1;
                    if (rd_beats_left != 16'd0)
                        rd_beats_left <= rd_beats_left - 1'b1;
                    if (M_AXI_RLAST) begin
                        if (rd_beats_left <= 16'd1) begin
                            rd_state <= RD_IDLE;
                            load_done_pulse <= 1'b1;
                        end else begin
                            rd_addr <= rd_addr + (rd_burst_beats * AXI_BYTES_U16);
                            rd_state <= RD_ADDR;
                        end
                    end
                end
            end
        end
    end
end

always @(posedge clk) begin
    if (!rst_n) begin
        wr_state <= WR_IDLE;
        wr_addr <= {AXI_ADDR_WIDTH{1'b0}};
        wr_beats_left <= 16'd0;
        wr_burst_beats <= 16'd0;
        wr_burst_sent <= 16'd0;
        wr_tag <= 8'd0;
        M_AXI_AWADDR <= {AXI_ADDR_WIDTH{1'b0}};
        M_AXI_AWLEN <= 8'd0;
        M_AXI_AWVALID <= 1'b0;
        M_AXI_BREADY <= 1'b0;
        store_done_pulse <= 1'b0;
        stat_write_cmds <= 32'd0;
        stat_write_beats <= 32'd0;
        stat_write_errors <= 32'd0;
    end else begin
        store_done_pulse <= 1'b0;

        if (clear) begin
            wr_state <= WR_IDLE;
            wr_addr <= {AXI_ADDR_WIDTH{1'b0}};
            wr_beats_left <= 16'd0;
            wr_burst_beats <= 16'd0;
            wr_burst_sent <= 16'd0;
            wr_tag <= 8'd0;
            M_AXI_AWVALID <= 1'b0;
            M_AXI_BREADY <= 1'b0;
            store_done_pulse <= 1'b0;
            stat_write_cmds <= 32'd0;
            stat_write_beats <= 32'd0;
            stat_write_errors <= 32'd0;
        end else begin
            if ((wr_state == WR_IDLE) && store_cmd_valid) begin
                wr_addr <= store_cmd_addr;
                wr_beats_left <= store_cmd_beats;
                wr_tag <= store_cmd_tag;
                stat_write_cmds <= stat_write_cmds + 1'b1;
                if (store_cmd_beats == 16'd0) begin
                    store_done_pulse <= 1'b1;
                end else begin
                    wr_state <= WR_ADDR;
                end
            end else if (wr_state == WR_ADDR) begin
                if (!M_AXI_AWVALID) begin
                    M_AXI_AWADDR <= wr_addr;
                    if (wr_beats_left > BURST_BEATS_U16)
                        wr_burst_beats <= BURST_BEATS_U16;
                    else
                        wr_burst_beats <= wr_beats_left;
                    if (wr_beats_left > BURST_BEATS_U16)
                        M_AXI_AWLEN <= BURST_BEATS_U16[7:0] - 1'b1;
                    else
                        M_AXI_AWLEN <= wr_beats_left[7:0] - 1'b1;
                    M_AXI_AWVALID <= 1'b1;
                end
                if (M_AXI_AWVALID && M_AXI_AWREADY) begin
                    M_AXI_AWVALID <= 1'b0;
                    wr_burst_sent <= 16'd0;
                    wr_state <= WR_DATA;
                end
            end else if (wr_state == WR_DATA) begin
                if (store_data_valid && M_AXI_WREADY) begin
                    stat_write_beats <= stat_write_beats + 1'b1;
                    if (wr_beats_left != 16'd0)
                        wr_beats_left <= wr_beats_left - 1'b1;
                    if (store_data_last && (wr_beats_left != 16'd1))
                        stat_write_errors <= stat_write_errors + 1'b1;
                    if (wr_burst_sent + 1'b1 == wr_burst_beats) begin
                        M_AXI_BREADY <= 1'b1;
                        wr_state <= WR_RESP;
                    end else begin
                        wr_burst_sent <= wr_burst_sent + 1'b1;
                    end
                end
            end else if (wr_state == WR_RESP) begin
                if (M_AXI_BVALID && M_AXI_BREADY) begin
                    M_AXI_BREADY <= 1'b0;
                    if (M_AXI_BRESP != 2'b00)
                        stat_write_errors <= stat_write_errors + 1'b1;
                    if (wr_beats_left == 16'd0) begin
                        wr_state <= WR_IDLE;
                        store_done_pulse <= 1'b1;
                    end else begin
                        wr_addr <= wr_addr + (wr_burst_beats * AXI_BYTES_U16);
                        wr_state <= WR_ADDR;
                    end
                end
            end
        end
    end
end

endmodule
