`timescale 1ns/1ps



module v729_runtime_abuf_fc1_tiledrain_nomemh #(parameter EXTERNAL_A=0) (

    output wire a_external_rd_en,output wire[223:0]a_external_rd_addr_flat,input wire[255:0]a_external_rd_data,

    input  wire clk,

    input  wire rst_n,

    input  wire clear,



    input  wire a_wr_valid,

    input  wire [15:0] a_wr_addr,

    input  wire signed [15:0] a_wr_data,



    input  wire b_wr_valid,

    input  wire [17:0] b_wr_addr,

    input  wire signed [15:0] b_wr_data,



    input  wire scale_wr_valid,

    input  wire [9:0] scale_wr_addr,

    input  wire signed [31:0] scale_wr_data,



    input  wire start,

    output reg  busy,

    output reg  done,



    output reg [31:0] stat_a_writes,

    output reg [31:0] stat_b_writes,

    output reg [31:0] stat_scale_writes,

    output reg [31:0] stat_input_errors,

    output reg [31:0] stat_tiles,

    output reg [31:0] stat_stream_items,

    output reg [31:0] stat_cycles,

    output reg [3:0]  stat_stage,



    output reg        out_valid,

    output reg [17:0] out_addr,

    output reg signed [7:0] out_data

);



localparam SEQ = 256;

localparam IN_DIM = 196;

localparam IN_REAL = 194;

localparam OUT_DIM = 768;

localparam TILE = 4;

localparam A_COUNT = SEQ * IN_DIM;

localparam B_COUNT = IN_DIM * OUT_DIM;

localparam K_TILES = IN_DIM / TILE;

localparam REAL_K_TILES = 48;

localparam OUT_COL_TILES = OUT_DIM / TILE;

localparam A_TILE_DEPTH = (SEQ / TILE) * REAL_K_TILES;

localparam B_TILE_DEPTH = K_TILES * OUT_COL_TILES;



localparam ST_IDLE  = 4'd0;

localparam ST_LOAD  = 4'd1;

localparam ST_FIRE  = 4'd2;

localparam ST_WAIT  = 4'd3;

localparam ST_ACC   = 4'd4;

localparam ST_NEXT  = 4'd5;

localparam ST_QUANT = 4'd6;

localparam ST_DONE  = 4'd7;

localparam ST_LOAD_WAIT = 4'd8;

localparam ST_QUANT_REQ = 4'd9;

localparam ST_LOAD_CAPTURE = 4'd10;

localparam ST_QUANT_WAIT = 4'd11;

localparam ST_QUANT_CLAMP = 4'd12;

localparam ST_QUANT_OUT = 4'd13;



reg [3:0] state;

reg [7:0] rt;

reg [9:0] ct;

reg [7:0] kt;

reg [17:0] idx;



reg pe_in_valid;

wire pe_in_ready;

wire pe_out_valid;

wire [511:0] pe_c_flat;

wire [31:0] pe_stat_tiles;

reg [255:0] pe_a_flat;

reg [255:0] pe_b_flat;

reg a_bank_rd_en;

reg b_bank_rd_en;

reg [16*14-1:0] a_bank_rd_addr_flat;

reg [16*14-1:0] b_bank_rd_addr_flat;

wire [255:0] a_bank_rd_data;

wire [255:0] b_bank_rd_data;

reg [15:0] a_lane_valid_r;

reg [15:0] b_lane_valid_r;

reg [255:0] b_prefetch_data;

reg [15:0] b_prefetch_lane_valid;

reg [7:0] b_prefetch_kt;

reg [9:0] b_prefetch_ct;

reg b_prefetch_valid;

reg b_prefetch_wait;

reg scale_rd_en;

reg [9:0] scale_rd_addr;

wire [31:0] scale_rd_data_u;

wire signed [31:0] scale_rd_data_s = $signed(scale_rd_data_u);

reg signed [31:0] acc_tile [0:15];



reg signed [63:0] quant_wide;

reg signed [7:0] quant_r;

reg signed [31:0] acc_next;

reg [17:0] lane_addr;

reg [9:0] lane_col;

integer i;



wire a_wr_ok_i = a_wr_valid && (a_wr_addr < A_COUNT[15:0]);

wire b_wr_ok_i = b_wr_valid && (b_wr_addr < B_COUNT[17:0]);

wire scale_wr_ok_i = scale_wr_valid && (scale_wr_addr < OUT_DIM[9:0]);

wire [15:0] a_wr_row_i = a_wr_addr / IN_DIM;

wire [15:0] a_wr_col_i = a_wr_addr % IN_DIM;

wire [17:0] b_wr_row_i = b_wr_addr / OUT_DIM;

wire [17:0] b_wr_col_i = b_wr_addr % OUT_DIM;

wire [3:0] a_wr_lane_i = {a_wr_row_i[1:0], a_wr_col_i[1:0]};

wire [3:0] b_wr_lane_i = {b_wr_row_i[1:0], b_wr_col_i[1:0]};

wire [13:0] a_wr_tile_addr_i = a_wr_row_i[15:2] * REAL_K_TILES[13:0] + a_wr_col_i[15:2];

wire [13:0] b_wr_tile_addr_i = b_wr_row_i[17:2] * OUT_COL_TILES[13:0] + b_wr_col_i[17:2];

wire [15:0] a_wr_lane_en_i = (a_wr_ok_i && (a_wr_col_i < 16'd192)) ?

                              (16'h0001 << a_wr_lane_i) : 16'h0000;

wire [15:0] b_wr_lane_en_i = b_wr_ok_i ? (16'h0001 << b_wr_lane_i) : 16'h0000;

wire [13:0] a_rd_tile_addr_i = rt[7:2] * REAL_K_TILES[13:0] + kt[7:2];

wire [13:0] b_rd_tile_addr_i = kt[7:2] * OUT_COL_TILES[13:0] + ct[9:2];

wire [7:0] b_next_kt_i = (kt < IN_DIM - TILE) ? (kt + TILE) : 8'd0;

wire [9:0] b_next_ct_i = (kt < IN_DIM - TILE) ? ct :

                          ((ct < OUT_DIM - TILE) ? (ct + TILE) : 10'd0);

wire b_next_exists_i = (kt < IN_DIM - TILE) ||

                       (ct < OUT_DIM - TILE) ||

                       (rt < SEQ - TILE);

wire [13:0] b_next_tile_addr_i =

    b_next_kt_i[7:2] * OUT_COL_TILES[13:0] + b_next_ct_i[9:2];

wire use_b_prefetch_i = b_prefetch_valid &&

                        (b_prefetch_kt == kt) &&

                        (b_prefetch_ct == ct);



// Local write-decode pipeline.  The loader address previously drove the

// distributed B-bank address comparators and sixteen replicated write enables

// directly across the device.  Registering the fully decoded request beside

// the bank preserves one write/cycle throughput while cutting that route.

reg [15:0] b_bank_wr_lane_en_r;

// V908 routed-timing repair: the final v902 signoff report showed that one

// bit of this address register directly drove roughly 35k distributed-RAM

// address pins.  The worst path had zero logic levels and 98% route delay.

// MAX_FANOUT requests register replication without changing the one-write-per-

// cycle protocol or adding another architectural pipeline stage.

(* MAX_FANOUT = 256 *) reg [13:0] b_bank_wr_tile_addr_r;

reg signed [15:0] b_bank_wr_data_r;



always @(posedge clk) begin

    if (!rst_n || clear) begin

        b_bank_wr_lane_en_r <= 16'd0;

        b_bank_wr_tile_addr_r <= 14'd0;

        b_bank_wr_data_r <= 16'sd0;

    end else begin

        b_bank_wr_lane_en_r <= b_wr_lane_en_i;

        b_bank_wr_tile_addr_r <= b_wr_tile_addr_i;

        b_bank_wr_data_r <= b_wr_data;

    end

end



// Norm2 is INT16, not bounded to INT8. In particular -129 must not wrap to

// +127. Keep full precision and the same synchronous read latency; weights

// and genuinely INT8 activations elsewhere retain their compact storage.

assign a_external_rd_en=a_bank_rd_en;

assign a_external_rd_addr_flat=a_bank_rd_addr_flat;

generate if(EXTERNAL_A)begin: shared_a

 assign a_bank_rd_data=a_external_rd_data;

end else begin: original_a

v753_lane16_bram16_multiaddr_sync #(

    .ADDR_W(14),

    .DEPTH(A_TILE_DEPTH),

    .FIT_MAX_DEPTH(A_TILE_DEPTH)

) u_a_bank (

    .clk(clk),

    .wr_lane_en(a_wr_lane_en_i),

    .wr_addr(a_wr_tile_addr_i),

    .wr_data(a_wr_data),

    .rd_en(a_bank_rd_en),

    .rd_addr_flat(a_bank_rd_addr_flat),

    .rd_data(a_bank_rd_data)

);



end endgenerate



npu_fc1_segmented_dist_bank #(

    .ADDR_W(14),

    .DEPTH(B_TILE_DEPTH),

    .SPECIAL_TILE_BASE(9216),

    .SPECIAL_DEPTH(OUT_COL_TILES)

) u_b_bank (

    .clk(clk),

    .rst_n(rst_n), .clear(clear),
    .wr_lane_en(b_wr_lane_en_i),

    .wr_addr(b_wr_tile_addr_i),

    .wr_data(b_wr_data),

    .rd_en(b_bank_rd_en),

    .rd_addr_flat(b_bank_rd_addr_flat),

    .rd_data(b_bank_rd_data)

);



v714_bram_sdp_sync #(

    .DATA_W(32),

    .ADDR_W(10),

    .DEPTH(OUT_DIM)

) u_scale_mem (

    .clk(clk),

    .wr_en(scale_wr_ok_i),

    .wr_addr(scale_wr_addr),

    .wr_data(scale_wr_data),

    .rd_en(scale_rd_en),

    .rd_addr(scale_rd_addr),

    .rd_data(scale_rd_data_u)

);



v285_pe4x4_int16_tile_core #(.PIPELINED_ARITHMETIC(1)) u_pe (

    .clk(clk),

    .rst_n(rst_n),

    .clear(clear),

    .in_valid(pe_in_valid),

    .in_ready(pe_in_ready),

    .a_flat(pe_a_flat),

    .b_flat(pe_b_flat),

    .out_valid(pe_out_valid),

    .out_ready(1'b1),

    .c_flat(pe_c_flat),

    .stat_tiles(pe_stat_tiles)

);



always @(posedge clk) begin

    if (!rst_n) begin

        state <= ST_IDLE;

        rt <= 8'd0;

        ct <= 10'd0;

        kt <= 8'd0;

        idx <= 18'd0;

        pe_in_valid <= 1'b0;

        pe_a_flat <= 256'd0;

        pe_b_flat <= 256'd0;

        a_bank_rd_en <= 1'b0;

        b_bank_rd_en <= 1'b0;

        a_bank_rd_addr_flat <= {16*14{1'b0}};

        b_bank_rd_addr_flat <= {16*14{1'b0}};

        a_lane_valid_r <= 16'd0;

        b_lane_valid_r <= 16'd0;

        b_prefetch_data <= 256'd0;

        b_prefetch_lane_valid <= 16'd0;

        b_prefetch_kt <= 8'd0;

        b_prefetch_ct <= 10'd0;

        b_prefetch_valid <= 1'b0;

        b_prefetch_wait <= 1'b0;

        scale_rd_en <= 1'b0;

        scale_rd_addr <= 10'd0;

        quant_wide <= 64'sd0;

        quant_r <= 8'sd0;

        acc_next <= 32'sd0;

        lane_addr <= 18'd0;

        lane_col <= 10'd0;

        busy <= 1'b0;

        done <= 1'b0;

        stat_a_writes <= 32'd0;

        stat_b_writes <= 32'd0;

        stat_scale_writes <= 32'd0;

        stat_input_errors <= 32'd0;

        stat_tiles <= 32'd0;

        stat_stream_items <= 32'd0;

        stat_cycles <= 32'd0;

        stat_stage <= ST_IDLE;

        out_valid <= 1'b0;

        out_addr <= 18'd0;

        out_data <= 8'sd0;

        for (i = 0; i < 16; i = i + 1)

            acc_tile[i] <= 32'sd0;

    end else begin

        done <= 1'b0;

        pe_in_valid <= 1'b0;

        out_valid <= 1'b0;

        a_bank_rd_en <= 1'b0;

        b_bank_rd_en <= 1'b0;

        scale_rd_en <= 1'b0;

        stat_stage <= state;



        if (busy)

            stat_cycles <= stat_cycles + 1'b1;



        if (clear) begin

            state <= ST_IDLE;

            busy <= 1'b0;

            stat_a_writes <= 32'd0;

            stat_b_writes <= 32'd0;

            stat_scale_writes <= 32'd0;

            stat_input_errors <= 32'd0;

            stat_tiles <= 32'd0;

            stat_stream_items <= 32'd0;

            stat_cycles <= 32'd0;

            stat_stage <= ST_IDLE;

            b_prefetch_valid <= 1'b0;

            b_prefetch_wait <= 1'b0;

        end else begin

            if (a_wr_valid) begin

                if (a_wr_addr < A_COUNT[15:0]) begin

                    stat_a_writes <= stat_a_writes + 1'b1;

                end else begin

                    stat_input_errors <= stat_input_errors + 1'b1;

                end

            end



            if (b_wr_valid) begin

                if (b_wr_addr < B_COUNT[17:0]) begin

                    stat_b_writes <= stat_b_writes + 1'b1;

                end else begin

                    stat_input_errors <= stat_input_errors + 1'b1;

                end

            end



            if (scale_wr_valid) begin

                if (scale_wr_addr < OUT_DIM[9:0]) begin

                    stat_scale_writes <= stat_scale_writes + 1'b1;

                end else begin

                    stat_input_errors <= stat_input_errors + 1'b1;

                end

            end



            case (state)

                ST_IDLE: begin

                    busy <= 1'b0;

                    if (start) begin

                        busy <= 1'b1;

                        rt <= 8'd0;

                        ct <= 10'd0;

                        kt <= 8'd0;

                        idx <= 18'd0;

                        stat_tiles <= 32'd0;

                        stat_stream_items <= 32'd0;

                        stat_cycles <= 32'd0;

                        b_prefetch_valid <= 1'b0;

                        b_prefetch_wait <= 1'b0;

                        state <= ST_LOAD;

                    end

                end



                ST_LOAD: begin

                    for (i = 0; i < 16; i = i + 1) begin

                        if ((rt + (i / 4) < SEQ) && (kt < 8'd192))

                            a_bank_rd_addr_flat[16*14 - i*14 - 1 -: 14] <= a_rd_tile_addr_i;

                        else

                            a_bank_rd_addr_flat[16*14 - i*14 - 1 -: 14] <= 14'd0;

                        a_lane_valid_r[i] <= (rt + (i / 4) < 208);



                        if (!use_b_prefetch_i) begin

                            if ((kt + (i / 4) < IN_DIM) && (ct + (i % 4) < OUT_DIM))

                                b_bank_rd_addr_flat[16*14 - i*14 - 1 -: 14] <= b_rd_tile_addr_i;

                            else

                                b_bank_rd_addr_flat[16*14 - i*14 - 1 -: 14] <= 14'd0;

                            b_lane_valid_r[i] <= ((kt + (i / 4) < IN_DIM) && (ct + (i % 4) < OUT_DIM));

                        end else begin

                            b_lane_valid_r[i] <= b_prefetch_lane_valid[i];

                        end

                    end

                    a_bank_rd_en <= 1'b1;

                    b_bank_rd_en <= !use_b_prefetch_i;

                    state <= ST_LOAD_WAIT;

                end



                ST_LOAD_WAIT: begin

                    state <= ST_LOAD_CAPTURE;

                end



                ST_LOAD_CAPTURE: begin

                    for (i = 0; i < 16; i = i + 1) begin

                        if (!a_lane_valid_r[i])

                            pe_a_flat[255 - i*16 -: 16] <= 16'sd0;

                        else if (kt < 8'd192)

                            pe_a_flat[255 - i*16 -: 16] <= a_bank_rd_data[255 - i*16 -: 16];

                        else if ((i % 4) == 0)

                            pe_a_flat[255 - i*16 -: 16] <= 16'sd16384;

                        else if ((i % 4) == 1)

                            pe_a_flat[255 - i*16 -: 16] <= 16'sd1;

                        else

                            pe_a_flat[255 - i*16 -: 16] <= 16'sd0;

                        pe_b_flat[255 - i*16 -: 16] <= b_lane_valid_r[i] ?

                            (use_b_prefetch_i ? b_prefetch_data[255 - i*16 -: 16] :

                                                b_bank_rd_data[255 - i*16 -: 16]) : 16'sd0;

                    end

                    if (use_b_prefetch_i)

                        b_prefetch_valid <= 1'b0;

                    state <= ST_FIRE;

                end



                ST_FIRE: begin

                    if (pe_in_ready) begin

                        pe_in_valid <= 1'b1;

                        if (b_next_exists_i) begin

                            for (i = 0; i < 16; i = i + 1) begin

                                b_bank_rd_addr_flat[16*14 - i*14 - 1 -: 14] <=

                                    ((b_next_kt_i + (i / 4) < IN_DIM) &&

                                     (b_next_ct_i + (i % 4) < OUT_DIM)) ?

                                        b_next_tile_addr_i : 14'd0;

                                b_prefetch_lane_valid[i] <=

                                    ((b_next_kt_i + (i / 4) < IN_DIM) &&

                                     (b_next_ct_i + (i % 4) < OUT_DIM));

                            end

                            b_bank_rd_en <= 1'b1;

                            b_prefetch_kt <= b_next_kt_i;

                            b_prefetch_ct <= b_next_ct_i;

                            b_prefetch_wait <= 1'b1;

                        end

                        state <= ST_WAIT;

                    end

                end



                ST_WAIT: begin

                    if (b_prefetch_wait) begin

                        b_prefetch_wait <= 1'b0;

                    end else if (!b_prefetch_valid && b_next_exists_i) begin

                        b_prefetch_data <= b_bank_rd_data;

                        b_prefetch_valid <= 1'b1;

                    end

                    if (pe_out_valid)

                        state <= ST_ACC;

                end



                ST_ACC: begin

                    for (i = 0; i < 16; i = i + 1) begin

                        if (kt == 8'd0)

                            acc_next = pe_c_flat[511 - i*32 -: 32];

                        else

                            acc_next = acc_tile[i] + pe_c_flat[511 - i*32 -: 32];

                        acc_tile[i] <= acc_next;

                    end

                    stat_tiles <= stat_tiles + 1'b1;

                    state <= ST_NEXT;

                end



                ST_NEXT: begin

                    if (kt < IN_DIM - TILE) begin

                        kt <= kt + 8'd4;

                        state <= ST_LOAD;

                    end else begin

                        kt <= 8'd0;

                        idx <= 18'd0;

                        state <= ST_QUANT_REQ;

                    end

                end



                ST_QUANT_REQ: begin

                    lane_col = ct + (idx % 4);

                    lane_addr = (rt + (idx / 4)) * OUT_DIM + lane_col;

                    scale_rd_en <= 1'b1;

                    scale_rd_addr <= lane_col;

                    state <= ST_QUANT_WAIT;

                end



                ST_QUANT_WAIT: begin

                    state <= ST_QUANT;

                end



                ST_QUANT: begin

                    quant_wide <= (acc_tile[idx[3:0]] * scale_rd_data_s) >>> 29;

                    state <= ST_QUANT_CLAMP;

                end



                ST_QUANT_CLAMP: begin

                    if (quant_wide > 64'sd127)

                        quant_r <= 8'sh7f;

                    else if (quant_wide < -64'sd128)

                        quant_r <= 8'sh80;

                    else

                        quant_r <= quant_wide[7:0];

                    state <= ST_QUANT_OUT;

                end



                ST_QUANT_OUT: begin

                    out_valid <= 1'b1;

                    out_addr <= lane_addr;

                    out_data <= quant_r;

                    stat_stream_items <= stat_stream_items + 1'b1;

                    if (idx == 18'd15) begin

                        if (ct < OUT_DIM - TILE) begin

                            ct <= ct + 10'd4;

                            state <= ST_LOAD;

                        end else begin

                            ct <= 10'd0;

                            if (rt < SEQ - TILE) begin

                                rt <= rt + TILE;

                                state <= ST_LOAD;

                            end else begin

                                state <= ST_DONE;

                            end

                        end

                    end else begin

                        idx <= idx + 1'b1;

                        state <= ST_QUANT_REQ;

                    end

                end



                ST_DONE: begin

                    busy <= 1'b0;

                    done <= 1'b1;

                    state <= ST_IDLE;

                end



                default: begin

                    state <= ST_IDLE;

                end

            endcase

        end

    end

end



endmodule

