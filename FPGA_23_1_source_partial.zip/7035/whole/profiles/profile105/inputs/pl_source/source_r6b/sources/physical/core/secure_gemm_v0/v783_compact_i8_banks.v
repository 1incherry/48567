`timescale 1ns/1ps

// Sixteen independent signed-int8 banks with independent read addresses.
// The external interface stays INT16; values are sign-extended on read.
module v783_lane16_i8_multiaddr_sync #(
    parameter ADDR_W = 14,
    parameter DEPTH = 3072
) (
    input  wire                    clk,
    input  wire [15:0]             wr_lane_en,
    input  wire [ADDR_W-1:0]       wr_addr,
    input  wire signed [15:0]      wr_data,
    input  wire                    rd_en,
    input  wire [16*ADDR_W-1:0]    rd_addr_flat,
    output wire [255:0]            rd_data
);
genvar gi;
generate
    for (gi = 0; gi < 16; gi = gi + 1) begin : g_lane
        wire [7:0] lane_rd8;
        wire [ADDR_W-1:0] lane_rd_addr =
            rd_addr_flat[16*ADDR_W - gi*ADDR_W - 1 -: ADDR_W];
        v714_bram_sdp_sync #(
            .DATA_W(8), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(DEPTH)
        ) u_lane_i8 (
            .clk(clk),
            .wr_en(wr_lane_en[gi]),
            .wr_addr(wr_addr),
            .wr_data(wr_data[7:0]),
            .rd_en(rd_en),
            .rd_addr(lane_rd_addr),
            .rd_data(lane_rd8)
        );
        assign rd_data[255 - gi*16 -: 16] = {{8{lane_rd8[7]}}, lane_rd8};
    end
endgenerate
endmodule

// Common-address variant used by row-group windows and Q/K/V tile banks.
module v783_tile16_lane_i8_sync #(parameter ADDR_W=10, parameter DEPTH=800)(
 input wire clk, input wire [15:0] wr_lane_en,
 input wire [ADDR_W-1:0] wr_addr, input wire [255:0] wr_data,
 input wire rd_en, input wire [ADDR_W-1:0] rd_addr,
 output wire [255:0] rd_data
);
 genvar g,b;
 generate for(g=0;g<4;g=g+1) begin: bank
  (* ram_style="block" *) reg [31:0] mem[0:DEPTH-1];
  reg [31:0] q;
  integer k;
  always @(posedge clk) begin
   for(k=0;k<4;k=k+1)
    if(wr_lane_en[g*4+k])
     mem[wr_addr][k*8+:8] <= wr_data[247-(g*4+k)*16-:8];
   if(rd_en) q <= mem[rd_addr];
  end
  for(b=0;b<4;b=b+1) begin: lane
   assign rd_data[255-(g*4+b)*16-:16] =
     {{8{q[b*8+7]}},q[b*8+:8]};
  end
 end endgenerate
endmodule


// FC1/FC2 weights are INT8 for every real multiplication row.  Only the
// bias/helper row (lane group 4..7 in the final K tile) needs the original
// high byte.  Keeping four short high-byte banks preserves exact INT16 math
// while roughly halving the large resident weight-bank capacity.
module v783_lane16_i8_special_multiaddr_sync #(
    parameter ADDR_W = 14,
    parameter DEPTH = 9408,
    parameter SPECIAL_TILE_BASE = 9216,
    parameter SPECIAL_DEPTH = 192
) (
    input  wire                    clk,
    input  wire [15:0]             wr_lane_en,
    input  wire [ADDR_W-1:0]       wr_addr,
    input  wire signed [15:0]      wr_data,
    input  wire                    rd_en,
    input  wire [16*ADDR_W-1:0]    rd_addr_flat,
    output wire [255:0]            rd_data
);
genvar gk;
generate
    for (gk = 0; gk < 16; gk = gk + 1) begin : g_lane
        wire [ADDR_W-1:0] lane_rd_addr =
            rd_addr_flat[16*ADDR_W - gk*ADDR_W - 1 -: ADDR_W];
        wire [7:0] lane_low8;
        v714_bram_sdp_sync #(
            .DATA_W(8), .ADDR_W(ADDR_W), .DEPTH(DEPTH), .FIT_MAX_DEPTH(DEPTH)
        ) u_low_i8 (
            .clk(clk),
            .wr_en(wr_lane_en[gk]),
            .wr_addr(wr_addr),
            .wr_data(wr_data[7:0]),
            .rd_en(rd_en),
            .rd_addr(lane_rd_addr),
            .rd_data(lane_low8)
        );

        if ((gk >= 4) && (gk < 8)) begin : g_special_hi
            wire wr_special = (wr_addr >= SPECIAL_TILE_BASE) &&
                              (wr_addr < SPECIAL_TILE_BASE + SPECIAL_DEPTH);
            wire rd_special = (lane_rd_addr >= SPECIAL_TILE_BASE) &&
                              (lane_rd_addr < SPECIAL_TILE_BASE + SPECIAL_DEPTH);
            wire [ADDR_W-1:0] wr_hi_addr = wr_addr - SPECIAL_TILE_BASE;
            wire [ADDR_W-1:0] rd_hi_addr = lane_rd_addr - SPECIAL_TILE_BASE;
            wire [7:0] lane_high8;
            reg rd_special_r;
            v714_bram_sdp_sync #(
                .DATA_W(8), .ADDR_W(ADDR_W), .DEPTH(SPECIAL_DEPTH),
                .FIT_MAX_DEPTH(SPECIAL_DEPTH)
            ) u_high_i8 (
                .clk(clk),
                .wr_en(wr_lane_en[gk] && wr_special),
                .wr_addr(wr_hi_addr),
                .wr_data(wr_data[15:8]),
                .rd_en(rd_en && rd_special),
                .rd_addr(rd_hi_addr),
                .rd_data(lane_high8)
            );
            always @(posedge clk) begin
                if (rd_en)
                    rd_special_r <= rd_special;
            end
            assign rd_data[255 - gk*16 -: 16] = rd_special_r ?
                {lane_high8, lane_low8} : {{8{lane_low8[7]}}, lane_low8};
        end else begin : g_plain
            assign rd_data[255 - gk*16 -: 16] = {{8{lane_low8[7]}}, lane_low8};
        end
    end
endgenerate
endmodule
