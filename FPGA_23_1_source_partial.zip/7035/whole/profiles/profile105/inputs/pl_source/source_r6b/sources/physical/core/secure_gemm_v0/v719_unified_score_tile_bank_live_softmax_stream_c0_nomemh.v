`timescale 1ns/1ps

module v719_unified_score_tile_bank_live_softmax_stream_c0_nomemh #(
    parameter ROWS = 200,
    parameter ROWS_REAL = 197,
    parameter COL_REAL = 197,
    parameter COL_PAD = 200,
    parameter TILE_DEPTH = 2500,
    parameter signed [31:0] X0 = -32'sd9,
    parameter signed [31:0] MIN_EXP_X = -32'sd135
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire start,
    input  wire [15:0] row_max_base,
    input  wire [15:0] row_sum_base,
    input  wire [15:0] factor_base,
    input  wire [31:0] prob_base,
    input  wire signed [31:0] cfg_x0,
    input  wire score_tile_valid,
    input  wire [15:0] score_tile_addr,
    input  wire [127:0] score_tile_data,
    input  wire out_ready,
    output reg  busy,
    output reg  done,
    output reg  out_valid,
    output reg [15:0] out_addr,
    output reg signed [15:0] out_data,
    output reg [31:0] stat_score_tiles,
    output reg [31:0] stat_rows,
    output reg [31:0] stat_probs,
    output reg [31:0] stat_stream_writes,
    output reg [31:0] stat_errors,
    output reg [31:0] stat_cycles,
    output reg [5:0]  stat_stage
);

localparam COL_TILES = COL_PAD / 4;
localparam ST_IDLE       = 6'd0;
localparam ST_ROW_INIT   = 6'd1;
localparam ST_MAX_REQ    = 6'd2;
localparam ST_MAX_READ   = 6'd3;
localparam ST_MAX_USE    = 6'd4;
localparam ST_EXP_REQ    = 6'd5;
localparam ST_EXP_READ   = 6'd6;
localparam ST_EXP_AFFINE = 6'd7;
localparam ST_EXP_QR     = 6'd8;
localparam ST_EXP_VAL    = 6'd9;
localparam ST_FACTOR     = 6'd10;
localparam ST_CHECK_ROW  = 6'd11;
localparam ST_PROB_CALC  = 6'd12;
localparam ST_PROB_SEND  = 6'd13;
localparam ST_NEXT_ROW   = 6'd14;
localparam ST_DONE       = 6'd15;
localparam ST_EXP_WAIT   = 6'd16;
localparam ST_EXP_DIV    = 6'd17;
localparam ST_EXP_COMMIT = 6'd18;
localparam ST_FACTOR_DIV = 6'd19;

reg [5:0] state;
reg [7:0] row;
reg [7:0] col;
reg [15:0] score_read_addr;
reg [3:0] score_lane;
reg [127:0] score_tile_word;
reg signed [7:0] score_r;

reg score_bank_rd_en;
reg [11:0] score_bank_rd_addr;
wire [127:0] score_bank_rd_data;
reg signed [31:0] exp_mem [0:COL_REAL-1];

reg signed [31:0] max_r;
reg signed [31:0] max_candidate_r;
reg signed [31:0] diff_r;
reg signed [31:0] affine_r;
reg signed [31:0] q_r;
reg signed [31:0] r_r;
reg signed [31:0] row_sum_r;
reg signed [31:0] factor_r;
reg signed [31:0] min_exp_x_r;
`ifdef V881_SOFTMAX_RADIX16
wire signed [31:0] affine_calc_w = diff_r + (diff_r >>> 1) - (diff_r >>> 4);
wire signed [31:0] affine_clamped_w =
    (affine_calc_w < min_exp_x_r) ? min_exp_x_r : affine_calc_w;
wire r16_start_valid_w =
    ((state == ST_EXP_VAL) && (cfg_x0 != 32'sd0)) ||
    ((state == ST_FACTOR) && (row_sum_r != 32'sd0));
wire r16_start_ready_w;
wire r16_finish_valid_w;
wire [31:0] r16_quotient_w;
wire [31:0] r16_remainder_w;
wire r16_divisor_zero_w;
wire r16_signed_w = (state == ST_EXP_VAL);
wire [31:0] r16_dividend_w = (state == ST_FACTOR) ?
                             32'd2147483647 : affine_clamped_w;
wire [31:0] r16_divisor_w = (state == ST_FACTOR) ?
                            row_sum_r : cfg_x0;

intdiv_r16_plus #(.D_W(32)) u_softmax_r16_divider(
    .start_valid_i(r16_start_valid_w),
    .start_ready_o(r16_start_ready_w),
    .flush_i(clear),
    .signed_op_i(r16_signed_w),
    .dividend_i(r16_dividend_w),
    .divisor_i(r16_divisor_w),
    .finish_valid_o(r16_finish_valid_w),
    .finish_ready_i(1'b1),
    .quotient_o(r16_quotient_w),
    .remainder_o(r16_remainder_w),
    .divisor_is_zero_o(r16_divisor_zero_w),
    .clk(clk),
    .rst_n(rst_n)
);
`endif
reg signed [31:0] prob_r;
reg [15:0] prob_addr_r;

v714_bram_sdp_sync #(
    .DATA_W(128),
    .ADDR_W(12),
    .DEPTH(TILE_DEPTH),
    .FIT_MAX_DEPTH(TILE_DEPTH)
) u_score_bank (
    .clk(clk),
    .wr_en(score_tile_valid),
    .wr_addr(score_tile_addr[11:0]),
    .wr_data(score_tile_data),
    .rd_en(score_bank_rd_en),
    .rd_addr(score_bank_rd_addr),
    .rd_data(score_bank_rd_data)
);

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        row <= 8'd0;
        col <= 8'd0;
        score_read_addr <= 16'd0;
        score_bank_rd_en <= 1'b0;
        score_bank_rd_addr <= 12'd0;
        score_lane <= 4'd0;
        score_tile_word <= 128'd0;
        score_r <= 8'sd0;
        max_r <= -32'sd2147483648;
        max_candidate_r <= 32'sd0;
        diff_r <= 32'sd0;
        affine_r <= 32'sd0;
        q_r <= 32'sd0;
        r_r <= 32'sd0;
        row_sum_r <= 32'sd0;
        factor_r <= 32'sd0;
        prob_r <= 32'sd0;
        min_exp_x_r <= -32'sd135;
        prob_addr_r <= 16'd0;
        busy <= 1'b0;
        done <= 1'b0;
        out_valid <= 1'b0;
        out_addr <= 16'd0;
        out_data <= 16'sd0;
        stat_score_tiles <= 32'd0;
        stat_rows <= 32'd0;
        stat_probs <= 32'd0;
        stat_stream_writes <= 32'd0;
        stat_errors <= 32'd0;
        stat_cycles <= 32'd0;
        stat_stage <= ST_IDLE;
    end else begin
        done <= 1'b0;
        score_bank_rd_en <= 1'b0;
        stat_stage <= state;
        if (busy)
            stat_cycles <= stat_cycles + 1'b1;

        if (score_tile_valid) begin
            stat_score_tiles <= stat_score_tiles + 1'b1;
        end

        if (out_valid && out_ready) begin
            out_valid <= 1'b0;
            stat_stream_writes <= stat_stream_writes + 1'b1;
        end

        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            out_valid <= 1'b0;
            stat_score_tiles <= 32'd0;
            stat_rows <= 32'd0;
            stat_probs <= 32'd0;
            stat_stream_writes <= 32'd0;
            stat_errors <= 32'd0;
            stat_cycles <= 32'd0;
        end else begin
            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        row <= 8'd0;
                        col <= 8'd0;
                        out_valid <= 1'b0;
                        min_exp_x_r <= (cfg_x0 <<< 4) - cfg_x0;
                        stat_rows <= 32'd0;
                        stat_probs <= 32'd0;
                        stat_stream_writes <= 32'd0;
                        stat_errors <= 32'd0;
                        stat_cycles <= 32'd0;
                        state <= ST_ROW_INIT;
                    end
                end

                ST_ROW_INIT: begin
                    col <= 8'd0;
                    max_r <= -32'sd2147483648;
                    row_sum_r <= 32'sd0;
                    factor_r <= 32'sd0;
                    if (row < ROWS_REAL)
                        state <= ST_MAX_REQ;
                    else
                        state <= ST_CHECK_ROW;
                end

                ST_MAX_REQ: begin
                    score_read_addr <= (row[7:2] * COL_TILES[15:0]) + col[7:2];
                    score_bank_rd_en <= 1'b1;
                    score_bank_rd_addr <= (row[7:2] * COL_TILES[11:0]) + col[7:2];
                    score_lane <= {row[1:0], col[1:0]};
                    state <= ST_MAX_READ;
                end

                ST_MAX_READ: begin
                    state <= ST_MAX_USE;
                end

                ST_MAX_USE: begin
                    case (score_lane)
                        4'd0: score_r <= score_bank_rd_data[127 - 0*8 -: 8];
                        4'd1: score_r <= score_bank_rd_data[127 - 1*8 -: 8];
                        4'd2: score_r <= score_bank_rd_data[127 - 2*8 -: 8];
                        4'd3: score_r <= score_bank_rd_data[127 - 3*8 -: 8];
                        4'd4: score_r <= score_bank_rd_data[127 - 4*8 -: 8];
                        4'd5: score_r <= score_bank_rd_data[127 - 5*8 -: 8];
                        4'd6: score_r <= score_bank_rd_data[127 - 6*8 -: 8];
                        4'd7: score_r <= score_bank_rd_data[127 - 7*8 -: 8];
                        4'd8: score_r <= score_bank_rd_data[127 - 8*8 -: 8];
                        4'd9: score_r <= score_bank_rd_data[127 - 9*8 -: 8];
                        4'd10: score_r <= score_bank_rd_data[127 - 10*8 -: 8];
                        4'd11: score_r <= score_bank_rd_data[127 - 11*8 -: 8];
                        4'd12: score_r <= score_bank_rd_data[127 - 12*8 -: 8];
                        4'd13: score_r <= score_bank_rd_data[127 - 13*8 -: 8];
                        4'd14: score_r <= score_bank_rd_data[127 - 14*8 -: 8];
                        default: score_r <= score_bank_rd_data[127 - 15*8 -: 8];
                    endcase
                    state <= ST_EXP_REQ;
                end

                ST_EXP_REQ: begin
                    if ($signed(score_r) > max_r)
                        max_r <= $signed(score_r);
                    if (col == COL_REAL - 1) begin
                        if ($signed(score_r) > max_r)
                            max_candidate_r <= $signed(score_r);
                        else
                            max_candidate_r <= max_r;
                        col <= 8'd0;
                        state <= ST_EXP_READ;
                    end else begin
                        col <= col + 1'b1;
                        state <= ST_MAX_REQ;
                    end
                end

                ST_EXP_READ: begin
                    score_read_addr <= (row[7:2] * COL_TILES[15:0]) + col[7:2];
                    score_lane <= {row[1:0], col[1:0]};
                    score_bank_rd_en <= 1'b1;
                    score_bank_rd_addr <= (row[7:2] * COL_TILES[11:0]) + col[7:2];
                    state <= ST_EXP_WAIT;
                end

                ST_EXP_WAIT: begin
                    state <= ST_EXP_AFFINE;
                end

                ST_EXP_AFFINE: begin
                    case (score_lane)
                        4'd0: score_r <= score_bank_rd_data[127 - 0*8 -: 8];
                        4'd1: score_r <= score_bank_rd_data[127 - 1*8 -: 8];
                        4'd2: score_r <= score_bank_rd_data[127 - 2*8 -: 8];
                        4'd3: score_r <= score_bank_rd_data[127 - 3*8 -: 8];
                        4'd4: score_r <= score_bank_rd_data[127 - 4*8 -: 8];
                        4'd5: score_r <= score_bank_rd_data[127 - 5*8 -: 8];
                        4'd6: score_r <= score_bank_rd_data[127 - 6*8 -: 8];
                        4'd7: score_r <= score_bank_rd_data[127 - 7*8 -: 8];
                        4'd8: score_r <= score_bank_rd_data[127 - 8*8 -: 8];
                        4'd9: score_r <= score_bank_rd_data[127 - 9*8 -: 8];
                        4'd10: score_r <= score_bank_rd_data[127 - 10*8 -: 8];
                        4'd11: score_r <= score_bank_rd_data[127 - 11*8 -: 8];
                        4'd12: score_r <= score_bank_rd_data[127 - 12*8 -: 8];
                        4'd13: score_r <= score_bank_rd_data[127 - 13*8 -: 8];
                        4'd14: score_r <= score_bank_rd_data[127 - 14*8 -: 8];
                        default: score_r <= score_bank_rd_data[127 - 15*8 -: 8];
                    endcase
                    if (col == 8'd0)
                        max_r <= max_candidate_r;
                    state <= ST_EXP_QR;
                end

                ST_EXP_QR: begin
                    diff_r <= $signed(score_r) - max_r;
                    state <= ST_EXP_VAL;
                end

                ST_EXP_VAL: begin
`ifdef V881_SOFTMAX_RADIX16
                    affine_r <= affine_clamped_w;
                    if (cfg_x0 == 32'sd0) begin
                        q_r <= 32'sd0;
                        r_r <= affine_clamped_w;
                        state <= ST_EXP_COMMIT;
                    end else if (r16_start_ready_w) begin
                        state <= ST_EXP_DIV;
                    end
`else
                    affine_r = diff_r + (diff_r >>> 1) - (diff_r >>> 4);
                    if (affine_r < min_exp_x_r)
                        affine_r = min_exp_x_r;
                    q_r = affine_r / cfg_x0;
                    r_r = affine_r - cfg_x0 * q_r;
                    if ((((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r)) < 0)
                        exp_mem[col] <= 32'sd0;
                    else
                        exp_mem[col] <= ((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r);
                    row_sum_r <= row_sum_r + (((((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r)) < 0) ?
                                               32'sd0 :
                                               (((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r)));
                    if (col == COL_REAL - 1) begin
                        state <= ST_FACTOR;
                    end else begin
                        col <= col + 1'b1;
                        state <= ST_EXP_READ;
                    end
`endif
                end

                ST_EXP_DIV: begin
`ifdef V881_SOFTMAX_RADIX16
                    if (r16_finish_valid_w) begin
                        q_r <= $signed(r16_quotient_w);
                        r_r <= $signed(r16_remainder_w);
                        state <= ST_EXP_COMMIT;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_EXP_COMMIT: begin
`ifdef V881_SOFTMAX_RADIX16
                    if ((((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r)) < 0)
                        exp_mem[col] <= 32'sd0;
                    else
                        exp_mem[col] <= ((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r);
                    row_sum_r <= row_sum_r +
                        (((((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r)) < 0) ?
                         32'sd0 :
                         (((r_r >>> 1) - cfg_x0) <<< (32'd15 - q_r)));
                    if (col == COL_REAL - 1)
                        state <= ST_FACTOR;
                    else begin
                        col <= col + 1'b1;
                        state <= ST_EXP_READ;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_FACTOR: begin
                    if (row_sum_r == 32'sd0) begin
                        factor_r <= 32'sd0;
                        state <= ST_CHECK_ROW;
                    end else begin
`ifdef V881_SOFTMAX_RADIX16
                        if (r16_start_ready_w)
                            state <= ST_FACTOR_DIV;
`else
                        factor_r <= 32'sd2147483647 / row_sum_r;
                        state <= ST_CHECK_ROW;
`endif
                    end
                end

                ST_FACTOR_DIV: begin
`ifdef V881_SOFTMAX_RADIX16
                    if (r16_finish_valid_w) begin
                        factor_r <= $signed(r16_quotient_w);
                        state <= ST_CHECK_ROW;
                    end
`else
                    state <= ST_IDLE;
`endif
                end

                ST_CHECK_ROW: begin
                    col <= 8'd0;
                    state <= ST_PROB_CALC;
                end

                ST_PROB_CALC: begin
                    prob_addr_r <= row * COL_PAD[15:0] + col;
                    if ((row < ROWS_REAL) && (col < COL_REAL))
                        prob_r <= (exp_mem[col] * factor_r) >>> 16;
                    else
                        prob_r <= 32'sd0;
                    state <= ST_PROB_SEND;
                end

                ST_PROB_SEND: begin
                    if (!out_valid) begin
                        out_valid <= 1'b1;
                        out_addr <= prob_addr_r;
                        out_data <= prob_r[15:0];
                        stat_probs <= stat_probs + 1'b1;
                        if (col == COL_PAD - 1) begin
                            state <= ST_NEXT_ROW;
                        end else begin
                            col <= col + 1'b1;
                            state <= ST_PROB_CALC;
                        end
                    end
                end

                ST_NEXT_ROW: begin
                    stat_rows <= stat_rows + 1'b1;
                    if (row == ROWS - 1) begin
                        state <= ST_DONE;
                    end else begin
                        row <= row + 1'b1;
                        state <= ST_ROW_INIT;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule

