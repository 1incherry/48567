`timescale 1ns/1ps
// Simulation DDR only. Initially EMPTY, never loads golden tensors, raw camera
// images, legacy activation snapshots or precomputed authentication tags.
// Accepted DUT writes are the sole source of runtime memory contents.
module full_chain_axi_memory(
 input wire clk,rst_n,
 input wire [31:0] araddr,input wire [7:0] arlen,input wire [2:0] arsize,input wire [1:0] arburst,
 input wire arvalid,output wire arready,output reg [255:0] rdata,output wire [1:0] rresp,
 output reg rlast,rvalid,input wire rready,
 input wire [31:0] awaddr,input wire [7:0] awlen,input wire [2:0] awsize,input wire [1:0] awburst,
 input wire awvalid,output wire awready,input wire [255:0] wdata,input wire [31:0] wstrb,
 input wire wlast,wvalid,output wire wready,output wire [1:0] bresp,output reg bvalid,input wire bready,
 output wire quiescent,output reg [63:0] read_beats,write_beats,b_responses
);
reg [255:0] memory[longint unsigned];
reg [63:0] cycles;
integer rd_left,wr_left,b_delay;
longint unsigned rd_index,wr_index;
reg [255:0] word_value;
assign arready=rd_left==0&&!rvalid&&cycles%7!=0;
assign awready=wr_left==0&&!bvalid&&b_delay==0&&cycles%11!=0;
assign wready=wr_left!=0&&!bvalid&&b_delay==0&&cycles%5!=0;
assign rresp=0;assign bresp=0;
assign quiescent=rd_left==0&&wr_left==0&&!rvalid&&!bvalid&&b_delay==0&&!arvalid&&!awvalid&&!wvalid;
initial begin cycles=0;read_beats=0;write_beats=0;b_responses=0;rd_left=0;wr_left=0;b_delay=0;rvalid=0;rlast=0;bvalid=0;rdata=0;rd_index=0;wr_index=0;end
always @(posedge clk)begin
 cycles<=cycles+1;
 if(!rst_n)begin rd_left<=0;wr_left<=0;b_delay<=0;rvalid<=0;rlast<=0;bvalid<=0;end
 else begin
  if(arvalid&&arready)begin
   if(arsize!=5||arburst!=1||araddr[4:0]!=0||{1'b0,araddr[11:0]}+(({5'd0,arlen}+1)<<5)>4096)$fatal(1,"full parent AXI read envelope %h len=%0d",araddr,arlen);
   rd_left<=arlen+1;rd_index<=araddr>>5;
  end
  if(!rvalid&&rd_left>0&&cycles%3!=0)begin
   if(!memory.exists(rd_index))$fatal(1,"FULL_CHAIN_DDR_READ_UNINITIALIZED %08h: runtime data/tag was not actually produced",rd_index<<5);
   rdata<=memory[rd_index];rvalid<=1;rlast<=rd_left==1;
  end else if(rvalid&&rready)begin
   read_beats<=read_beats+1;rd_left<=rd_left-1;
   if(rd_left==1)begin rvalid<=0;rlast<=0;end
   else begin
    if(!memory.exists(rd_index+1))$fatal(1,"FULL_CHAIN_DDR_READ_UNINITIALIZED next=%08h",(rd_index+1)<<5);
    rd_index<=rd_index+1;rdata<=memory[rd_index+1];rlast<=rd_left==2;
   end
  end
  if(awvalid&&awready)begin
   if(awsize!=5||awburst!=1||awaddr[4:0]!=0||{1'b0,awaddr[11:0]}+(({5'd0,awlen}+1)<<5)>4096)$fatal(1,"full parent AXI write envelope %h len=%0d",awaddr,awlen);
   wr_left<=awlen+1;wr_index<=awaddr>>5;
  end
  if(wvalid&&wready)begin
   if(wlast!==(wr_left==1))$fatal(1,"full parent AXI WLAST/count");
   word_value=memory.exists(wr_index)?memory[wr_index]:256'd0;
   for(integer by=0;by<32;by=by+1)if(wstrb[by])word_value[by*8+:8]=wdata[by*8+:8];
   memory[wr_index]=word_value;write_beats<=write_beats+1;wr_left<=wr_left-1;wr_index<=wr_index+1;
   if(wr_left==1)b_delay<=3;
  end
  if(b_delay>0)begin b_delay<=b_delay-1;if(b_delay==1)bvalid<=1;end
  if(bvalid&&bready)begin bvalid<=0;b_responses<=b_responses+1;end
 end
end
// Golden files are read ONLY by this observer task after the actual graph
// stage completes. They are not copied into the runtime memory dictionary.
reg [255:0] comparison_data[0:51199],comparison_meta[0:51199];
task check_snapshot(input integer op,input [31:0] address,input integer bytes_count,input integer channels,input integer channel_stride,input string data_file,input string meta_file);
 integer ch,j,logical_offset,actual_slot,gold_slot,channel_bytes,physical;reg [7:0] got,want;reg [31:0] meta_address;
 begin
  channel_bytes=bytes_count/channels;
  $readmemh(data_file,comparison_data,0,(bytes_count+31)/32-1);
  $readmemh(meta_file,comparison_meta,0,channels*((channel_bytes+31)/32)-1);
  for(ch=0;ch<channels;ch=ch+1)begin
   for(j=0;j<channel_bytes;j=j+1)begin
    physical=address+ch*channel_stride+j;actual_slot=physical>>5;logical_offset=ch*channel_bytes+j;
    if(!memory.exists(actual_slot))$fatal(1,"missing actual snapshot op%0d addr%h",op,physical);
    got=memory[actual_slot][physical[4:0]*8+:8];want=comparison_data[logical_offset>>5][(logical_offset%32)*8+:8];
    if(got!==want)$fatal(1,"FULL_CHAIN_ORIGINAL_PY_DIFF op=%0d byte=%0d address=%08x got=%02x want=%02x",op,logical_offset,physical,got,want);
   end
   for(j=0;j<channel_bytes;j=j+32)begin
    physical=address+ch*channel_stride+j;gold_slot=ch*((channel_bytes+31)/32)+(j>>5);
    meta_address=physical>=32'h2c000000 ? 32'h35000000+(physical-32'h2c000000):physical>=32'h22000000 ? 32'h34100000+(physical-32'h22000000):32'h34000000+(physical-32'h21000000);
    if(!memory.exists(meta_address>>5)||memory[meta_address>>5]!==comparison_meta[gold_slot])$fatal(1,"FULL_CHAIN_INDEPENDENT_MAC_DIFF op=%0d address=%08x",op,physical);
   end
  end
  $display("FULL_CHAIN_SNAPSHOT_PY_AND_MAC_EXACT op=%0d bytes=%0d cycles=%0d",op,bytes_count,cycles);
 end
endtask
endmodule
