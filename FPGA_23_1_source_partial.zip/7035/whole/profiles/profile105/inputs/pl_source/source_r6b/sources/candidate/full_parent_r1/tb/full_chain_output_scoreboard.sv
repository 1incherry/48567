`timescale 1ns/1ps
// Actual output pipeline, fed exclusively by the actual protected result bank.
// Expected wire bytes are an observer transformation of the real bank; the
// main full-chain scoreboard independently checks that bank against Python.
module full_chain_output_scoreboard(
 input wire clk,security_reset_n,authorization_live,frame_start,
 input wire record_commit,record_visible,
 input wire [31:0] record_camera,record_session,record_frame,record_epoch,
 input wire [127:0] record_key_session,input wire [2:0] record_count,
 input wire [895:0] record_rois,input wire [51:0] record_indices,input wire [511:0] record_results,
 output wire admission_ready,quiescent,fault,output reg checked
);
reg tx_clk=0,pixel_clk=0;
always #4 tx_clk=~tx_clk;
always #6.734 pixel_clk=~pixel_clk;
wire [7:0]tx_data;wire tx_valid,tx_last;reg tx_ready=0;
reg [11:0]pixel_x=0,pixel_y=0;
wire [23:0]overlay_rgb;wire overlay_hs,overlay_vs,overlay_de;
integer tx_cycle=0;
always @(negedge tx_clk)begin tx_cycle=tx_cycle+1;tx_ready=tx_cycle%7!=0&&tx_cycle%13!=0;end
always @(posedge pixel_clk)begin
 if(!security_reset_n)begin pixel_x<=0;pixel_y<=0;end
 else if(pixel_x==1649)begin pixel_x<=0;pixel_y<=pixel_y==749?0:pixel_y+1'b1;end
 else pixel_x<=pixel_x+1'b1;
end
trusted_record_outputs u_actual_outputs(
 .clk(clk),.security_reset_n(security_reset_n),.authorization_live(authorization_live),.frame_start(frame_start),
 .record_commit(record_commit),.record_visible(record_visible),.record_camera(record_camera),.record_session(record_session),.record_frame(record_frame),.record_epoch(record_epoch),
 .record_key_session(record_key_session),.record_count(record_count),.record_rois(record_rois),.record_indices(record_indices),.record_results(record_results),
 .admission_ready(admission_ready),.quiescent(quiescent),.fault(fault),
 .tx_clk(tx_clk),.tx_reset_n(security_reset_n),.tx_data(tx_data),.tx_valid(tx_valid),.tx_last(tx_last),.tx_ready(tx_ready),
 .pixel_clk(pixel_clk),.pixel_reset_n(security_reset_n),.pixel_x(pixel_x),.pixel_y(pixel_y),.pixel_rgb(24'h123456),
 .pixel_hs(pixel_x<40),.pixel_vs(pixel_y<5),.pixel_de(pixel_x<1280&&pixel_y<720),
 .overlay_rgb(overlay_rgb),.overlay_hs(overlay_hs),.overlay_vs(overlay_vs),.overlay_de(overlay_de));
reg [2159:0]expected_report;
reg [2047:0]expected_body;
reg captured=0,tx_checked=0,pixel_checked=0,report_pending=0;
integer byte_count=0,i,fd;
initial begin checked=0;expected_report=0;expected_body=0;fd=$fopen("full_chain_actual_result_report.bin","wb");if(!fd)$fatal(1,"actual output dump open failed");end
always @(posedge clk)if(security_reset_n&&record_commit)report_pending<=1;
always @(negedge clk)begin
 if(security_reset_n&&report_pending&&record_visible&&!captured)begin
  expected_body=0;
  expected_body[2047-0*8-:32]=32'h4e545232;
  expected_body[2047-4*8-:32]=32'h00020001;
  expected_body[2047-8*8-:32]=1;
  expected_body[2047-12*8-:32]=record_camera;
  expected_body[2047-16*8-:32]=record_session;
  expected_body[2047-20*8-:32]=record_frame;
  expected_body[2047-24*8-:32]=record_epoch;
  expected_body[2047-28*8-:32]={29'd0,record_count};
  expected_body[2047-32*8-:128]=record_key_session;
  for(i=0;i<4;i=i+1)if(i<record_count)begin
   expected_body[2047-(48+28*i)*8-:224]=record_rois[i*224+:224];
   expected_body[2047-(160+2*i)*8-:16]={3'd0,record_indices[i*13+:13]};
   expected_body[2047-(168+16*i)*8-:128]=record_results[i*128+:128];
  end
  expected_report={112'h02505258310002505258703588b6,expected_body};captured=1;
 end
 if(security_reset_n&&tx_checked&&pixel_checked&&quiescent&&!checked)begin
  if(!authorization_live||!record_visible||fault)$fatal(1,"actual output result no longer current or faulted");
  checked=1;$fflush(fd);
  $display("FULL_CHAIN_ACTUAL_BANK_PUBLISH_CDC_SERIALIZER_PASS Ethernet_bytes=270 original_camera=%0d session=%0d frame=%0d epoch=%0d ROI_count=%0d generation=%0d class=%0d logit=%0d actual_pixel_snapshot=1 no_PS_labels=1",record_camera,record_session,record_frame,record_epoch,record_count,record_results[127:96],record_results[95:88],$signed(record_results[63:0]));
 end
end
always @(posedge tx_clk)if(security_reset_n&&tx_valid&&tx_ready)begin
 if(!captured||byte_count>=270||tx_data!==expected_report[2159-byte_count*8-:8]||tx_last!==(byte_count==269))$fatal(1,"real protected result Ethernet diff byte=%0d actual=%h",byte_count,tx_data);
 $fwrite(fd,"%c",tx_data);byte_count=byte_count+1;
 if(tx_last)begin if(byte_count!=270)$fatal(1,"real output report length");tx_checked=1;end
end
always @(posedge pixel_clk)if(security_reset_n&&u_actual_outputs.pixel_label_valid)begin
 if(!captured||u_actual_outputs.pixel_body!==expected_body)$fatal(1,"actual pixel CDC result snapshot differs from protected bank");
 pixel_checked=1;
end
endmodule
