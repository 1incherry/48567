`timescale 1ns/1ps

// One physical 16-lane FC1 A bank. No shadow linear_add tensor.

module npu_norm2_fc1_shared_A #(parameter integer CLOSED_NORM2_CLEAR_OPERAND=0,parameter integer CLOSED_NORM2_OUTER_CLEAR=0)(

 input wire clk,rst_n,clear,authorized,cancel,input wire[31:0]session_epoch,

 input wire raw_start,raw_done,raw_wr_valid,input wire[15:0]raw_wr_addr,raw_wr_data,

 input wire norm_start,norm_done,norm_wr_valid,input wire[15:0]norm_wr_addr,norm_wr_data,

 input wire norm_rd_en,input wire[7:0]norm_rd_row,norm_rd_col,input wire[15:0]norm_rd_addr,output wire[15:0]norm_rd_data,

 input wire fc1_start,fc1_done,fc1_rd_en,input wire[223:0]fc1_rd_addr_flat,output wire[255:0]fc1_rd_data,

 output wire norm_ready,fc1_ready,output reg fault,

 output wire[2:0]debug_phase,output reg[15:0]raw_count,norm_count,

 output wire[15:0]norm_rd_clear_operand,input wire norm_outer_clear,norm_clear_residual

);

 localparam IDLE=0,RAW=1,RAW_SEALED=2,NORM=3,NORM_SEALED=4,FC1=5,RETIRED=6,FAILED=7;

 reg[2:0]phase;reg[31:0]epoch;reg[5:0]raw_rtile,raw_ctile;reg[3:0]raw_drain_lane;reg raw_done_seen,norm_done_seen;reg[15:0]norm_expected_addr;reg[7:0]norm_expected_col,norm_write_row;

 wire live=(authorized===1'b1)&&(session_epoch===epoch)&&(cancel===1'b0)&&(clear===1'b0)&&(fault===1'b0)&&(rst_n===1'b1);

 wire[15:0]raw_expected_addr=(raw_rtile*4+(raw_drain_lane>>2))*192+raw_ctile*4+raw_drain_lane[1:0];

 wire raw_ok=live&&phase==RAW&&raw_wr_valid&&(raw_wr_addr===raw_expected_addr)&&raw_count<39936&&!norm_wr_valid;

 wire norm_ok=live&&phase==NORM&&norm_wr_valid&&(norm_wr_addr===norm_expected_addr)&&norm_wr_addr<50176&&norm_count<49664&&!raw_wr_valid;

 wire[15:0]raw_row=raw_rtile*4+(raw_drain_lane>>2),raw_col=raw_ctile*4+raw_drain_lane[1:0];

 wire[15:0]norm_row={8'd0,norm_write_row};
 wire[15:0]norm_col=(norm_count>=39936&&norm_count<40352)?16'd192+norm_expected_col:{8'd0,norm_expected_col};

 wire[15:0]read_row={8'd0,norm_rd_row},read_col={8'd0,norm_rd_col};
 wire[15:0]read_linear_check=read_row*16'd192+read_col;

 wire[3:0]raw_lane=raw_drain_lane,norm_lane={norm_row[1:0],norm_col[1:0]};

 wire[3:0]read_lane={read_row[1:0],read_col[1:0]};

 wire[13:0]raw_tile=raw_rtile*48+raw_ctile;

 wire[13:0]norm_tile=(norm_row>>2)*48+(norm_col>>2);

 wire[13:0]read_tile=(read_row>>2)*48+(read_col>>2);

 wire role_start=raw_start||norm_start||fc1_start;

 wire[15:0]bank_we=role_start?16'b0:raw_ok?(16'h1<<raw_lane):

   (norm_ok&&norm_col<192)?(16'h1<<norm_lane):16'b0;

 wire[13:0]bank_wa=raw_ok?raw_tile:norm_tile;

 wire[15:0]bank_wd=raw_ok?raw_wr_data:norm_wr_data;

 wire norm_read=live&&!role_start&&phase==NORM&&norm_rd_en&&(^norm_rd_addr!==1'bx)&&(norm_rd_addr===read_linear_check)&&norm_rd_row<208&&norm_rd_col<192&&norm_rd_addr<39936;

 integer bound_lane;reg fc1_address_ok;

 always @*begin fc1_address_ok=1;for(bound_lane=0;bound_lane<16;bound_lane=bound_lane+1)

  if((^fc1_rd_addr_flat[223-bound_lane*14 -:14]===1'bx)||fc1_rd_addr_flat[223-bound_lane*14 -:14]>=3072)fc1_address_ok=0;end

 wire fc1_read=live&&!role_start&&phase==FC1&&fc1_rd_en&&fc1_address_ok;

 wire[223:0]bank_ra=norm_read?{16{read_tile}}:fc1_rd_addr_flat;

 wire[255:0]bank_q;reg[3:0]selected_lane;reg norm_response_valid,fc1_response_valid;

 v753_lane16_bram16_multiaddr_sync #(.ADDR_W(14),.DEPTH(3072),.FIT_MAX_DEPTH(3072)) u_a_bank(

  .clk(clk),.wr_lane_en(bank_we),.wr_addr(bank_wa),.wr_data(bank_wd),

  .rd_en(norm_read||fc1_read),.rd_addr_flat(bank_ra),.rd_data(bank_q));

 always @(posedge clk)if(norm_read)selected_lane<=read_lane;

 always @(posedge clk)begin

  if(!rst_n||clear||!live)begin norm_response_valid<=0;fc1_response_valid<=0;end

  else begin norm_response_valid<=norm_read;fc1_response_valid<=fc1_read;end

 end

 assign norm_rd_data=(live&&phase==NORM&&norm_response_valid)?bank_q[255-selected_lane*16 -:16]:16'b0;

 wire norm_clear_controls_known=((authorized===1'b0)||(authorized===1'b1))&&((cancel===1'b0)||(cancel===1'b1));
 // Closed consumer contract: clear=norm_outer_clear||norm_clear_residual,
 // and the only consuming Norm2 has norm_outer_clear in its highest clear.
 // Public read masks, bank clear/state/zeroization and all RAM controls retain
 // the original clear. Unknown outer-clear uses the exact old private path.
 wire norm_outer_clear_known=(norm_outer_clear===1'b0)||(norm_outer_clear===1'b1);
 wire norm_operand_read_clear=(CLOSED_NORM2_OUTER_CLEAR!=0&&norm_outer_clear_known)?norm_clear_residual:clear;
 wire norm_clear_operand_live=(session_epoch===epoch)&&(norm_operand_read_clear===1'b0)&&(fault===1'b0)&&(rst_n===1'b1);
 wire[15:0]norm_clear_operand_fast=(norm_clear_operand_live&&phase==NORM&&norm_response_valid)?bank_q[255-selected_lane*16 -:16]:16'b0;
 assign norm_rd_clear_operand=(CLOSED_NORM2_CLEAR_OPERAND!=0&&norm_clear_controls_known)?norm_clear_operand_fast:norm_rd_data;

 assign fc1_rd_data=(live&&phase==FC1&&fc1_response_valid)?bank_q:256'b0;

 assign norm_ready=live&&phase==RAW_SEALED;

 assign fc1_ready=live&&phase==NORM_SEALED;

 assign debug_phase=phase;

 always @(posedge clk)begin

  if(!rst_n||clear)begin phase<=IDLE;epoch<=0;fault<=0;raw_rtile<=0;raw_ctile<=0;raw_drain_lane<=0;raw_count<=0;norm_count<=0;raw_done_seen<=0;norm_done_seen<=0;norm_expected_addr<=0;norm_expected_col<=0;norm_write_row<=0;end

  else if(phase!=IDLE&&phase!=FAILED&&((authorized!==1'b1)||(session_epoch!==epoch)||cancel))begin

   phase<=FAILED;fault<=1;raw_done_seen<=0;norm_done_seen<=0;

  end else if(!fault)begin

   if(raw_start)begin

    if((phase==IDLE||phase==RETIRED)&&(authorized===1'b1)&&(cancel===1'b0)&&(^session_epoch!==1'bx))begin

     phase<=RAW;epoch<=session_epoch;raw_count<=0;raw_rtile<=0;raw_ctile<=0;raw_drain_lane<=0;norm_count<=0;raw_done_seen<=0;norm_done_seen<=0;

    end else begin phase<=FAILED;fault<=1;end

   end

   if(raw_wr_valid)begin

    if(!raw_ok||norm_wr_valid)begin phase<=FAILED;fault<=1;end

    else begin raw_count<=raw_count+1'b1;

     if(raw_drain_lane==15)begin raw_drain_lane<=0;if(raw_ctile==47)begin raw_ctile<=0;raw_rtile<=raw_rtile+1'b1;end else raw_ctile<=raw_ctile+1'b1;end

     else raw_drain_lane<=raw_drain_lane+1'b1;

    end

   end

   if(raw_done)begin if(phase!=RAW)begin phase<=FAILED;fault<=1;end else raw_done_seen<=1;end

   if(phase==RAW&&raw_done_seen&&!raw_wr_valid)begin

    if(raw_count==39936)phase<=RAW_SEALED;else begin phase<=FAILED;fault<=1;end

   end

   if(norm_start)begin

    if(norm_ready)begin phase<=NORM;norm_count<=0;norm_done_seen<=0;norm_expected_addr<=0;norm_expected_col<=0;norm_write_row<=0;end

    else begin phase<=FAILED;fault<=1;end

   end

   if(norm_rd_en&&!norm_read)begin phase<=FAILED;fault<=1;end

   if(norm_wr_valid)begin

    if(!norm_ok||raw_wr_valid)begin phase<=FAILED;fault<=1;end

    else begin

     norm_count<=norm_count+1'b1;

     if(norm_count<39936)begin

      if(norm_count==39935)begin norm_write_row<=0;norm_expected_col<=0;norm_expected_addr<=192;end

      else if(norm_expected_col==191)begin norm_write_row<=norm_write_row+1'b1;norm_expected_col<=0;norm_expected_addr<=norm_expected_addr+5;end

      else begin norm_expected_col<=norm_expected_col+1'b1;norm_expected_addr<=norm_expected_addr+1'b1;end

     end else if(norm_count<40352)begin

      if(norm_count==40351)begin norm_write_row<=208;norm_expected_col<=0;norm_expected_addr<=40768;end

      else if(norm_expected_col==1)begin norm_write_row<=norm_write_row+1'b1;norm_expected_col<=0;norm_expected_addr<=norm_expected_addr+195;end

      else begin norm_expected_col<=1;norm_expected_addr<=norm_expected_addr+1'b1;end

     end else begin

      if(norm_expected_col==193)begin norm_write_row<=norm_write_row+1'b1;norm_expected_col<=0;norm_expected_addr<=norm_expected_addr+3;end

      else begin norm_expected_col<=norm_expected_col+1'b1;norm_expected_addr<=norm_expected_addr+1'b1;end

     end

    end

   end

   if(norm_done)begin if(phase!=NORM)begin phase<=FAILED;fault<=1;end else norm_done_seen<=1;end

   if(phase==NORM&&norm_done_seen&&!norm_wr_valid)begin

    if(norm_count==49664)phase<=NORM_SEALED;

    // Last output can still be in the existing router pipeline; wait for it.

   end

   if(fc1_start)begin if(fc1_ready)phase<=FC1;else begin phase<=FAILED;fault<=1;end end

   if(fc1_rd_en&&!fc1_read)begin phase<=FAILED;fault<=1;end

   if(fc1_done)begin if(phase==FC1)phase<=RETIRED;else begin phase<=FAILED;fault<=1;end end

  end

 end

endmodule

