`timescale 1ns/1ps

module v717_qkv_stream_to_attention_tile_banks_nomemh #(
    parameter ROWS = 200,
    parameter HEAD_DIM = 64,
    parameter TILE_DEPTH = 800
) (
    input  wire clk,
    input  wire rst_n,
    input  wire clear,
    input  wire start,
    input  wire in_valid,
    output wire in_ready,
    input  wire [1:0] in_kind,
    input  wire [15:0] in_addr,
    input  wire signed [7:0] in_data,
    output reg busy,
    output reg done,
    output reg [31:0] stat_inputs,
    output reg [31:0] stat_q_inputs,
    output reg [31:0] stat_k_inputs,
    output reg [31:0] stat_v_inputs,
    output reg [31:0] stat_kind_errors,
    output reg [3:0] stat_stage,
    input  wire q_rd_en,
    input  wire k_rd_en,
    input  wire v_rd_en,
    input  wire [15:0] q_rd_addr,
    input  wire [15:0] k_rd_addr,
    input  wire [15:0] v_rd_addr,
    output wire [255:0] q_rd_data,
    output wire [255:0] k_rd_data,
    output wire [255:0] v_rd_data
);

localparam TOTAL_ELEMS = ROWS * HEAD_DIM;
localparam COL_TILES = HEAD_DIM / 4;
localparam ROW_TILES = ROWS / 4;
localparam EXPECTED_INPUTS = TOTAL_ELEMS * 3;

localparam ST_IDLE = 4'd0;
localparam ST_LOAD = 4'd1;
localparam ST_DONE = 4'd2;

reg [3:0] state;
wire [9:0] qv_wr_addr = ({6'd0, in_addr[15:8]} * COL_TILES[9:0]) + {6'd0, in_addr[5:2]};
wire [9:0] k_wr_addr = ({6'd0, in_addr[5:2]} * ROW_TILES[9:0]) + {4'd0, in_addr[15:8]};
wire [3:0] qv_wr_lane = {in_addr[7:6], in_addr[1:0]};
wire [3:0] k_wr_lane = {in_addr[1:0], in_addr[7:6]};
wire [15:0] in_data_i16 = {{8{in_data[7]}}, in_data};
wire [9:0] q_rd_addr_i = q_rd_addr[9:0];
wire [9:0] k_rd_addr_i = k_rd_addr[9:0];
wire [9:0] v_rd_addr_i = v_rd_addr[9:0];
wire write_active = (state == ST_LOAD) && in_valid;
wire [255:0] wr_word = {
    in_data_i16, in_data_i16, in_data_i16, in_data_i16,
    in_data_i16, in_data_i16, in_data_i16, in_data_i16,
    in_data_i16, in_data_i16, in_data_i16, in_data_i16,
    in_data_i16, in_data_i16, in_data_i16, in_data_i16
};
wire [15:0] q_wr_lane_en = (write_active && (in_kind == 2'd0)) ? (16'h0001 << qv_wr_lane) : 16'h0000;
wire [15:0] k_wr_lane_en = (write_active && (in_kind == 2'd1)) ? (16'h0001 << k_wr_lane)  : 16'h0000;
wire [15:0] v_wr_lane_en = (write_active && (in_kind == 2'd2)) ? (16'h0001 << qv_wr_lane) : 16'h0000;

assign in_ready = (state == ST_LOAD);

v783_tile16_lane_i8_sync #(
    .ADDR_W(10),
    .DEPTH(TILE_DEPTH)
) u_q_bank (
    .clk(clk),
    .wr_lane_en(q_wr_lane_en),
    .wr_addr(qv_wr_addr),
    .wr_data(wr_word),
    .rd_en(q_rd_en),
    .rd_addr(q_rd_addr_i),
    .rd_data(q_rd_data)
);

v783_tile16_lane_i8_sync #(
    .ADDR_W(10),
    .DEPTH(TILE_DEPTH)
) u_k_bank (
    .clk(clk),
    .wr_lane_en(k_wr_lane_en),
    .wr_addr(k_wr_addr),
    .wr_data(wr_word),
    .rd_en(k_rd_en),
    .rd_addr(k_rd_addr_i),
    .rd_data(k_rd_data)
);

v783_tile16_lane_i8_sync #(
    .ADDR_W(10),
    .DEPTH(TILE_DEPTH)
) u_v_bank (
    .clk(clk),
    .wr_lane_en(v_wr_lane_en),
    .wr_addr(qv_wr_addr),
    .wr_data(wr_word),
    .rd_en(v_rd_en),
    .rd_addr(v_rd_addr_i),
    .rd_data(v_rd_data)
);

always @(posedge clk) begin
    if (!rst_n) begin
        state <= ST_IDLE;
        busy <= 1'b0;
        done <= 1'b0;
        stat_inputs <= 32'd0;
        stat_q_inputs <= 32'd0;
        stat_k_inputs <= 32'd0;
        stat_v_inputs <= 32'd0;
        stat_kind_errors <= 32'd0;
        stat_stage <= ST_IDLE;
    end else begin
        done <= 1'b0;
        stat_stage <= state;

        if (clear) begin
            state <= ST_IDLE;
            busy <= 1'b0;
            done <= 1'b0;
            stat_inputs <= 32'd0;
            stat_q_inputs <= 32'd0;
            stat_k_inputs <= 32'd0;
            stat_v_inputs <= 32'd0;
            stat_kind_errors <= 32'd0;
        end else begin
            case (state)
                ST_IDLE: begin
                    busy <= 1'b0;
                    if (start) begin
                        busy <= 1'b1;
                        stat_inputs <= 32'd0;
                        stat_q_inputs <= 32'd0;
                        stat_k_inputs <= 32'd0;
                        stat_v_inputs <= 32'd0;
                        stat_kind_errors <= 32'd0;
                        state <= ST_LOAD;
                    end
                end

                ST_LOAD: begin
                    if (in_valid) begin
                        if (in_kind == 2'd0) begin
                            stat_q_inputs <= stat_q_inputs + 1'b1;
                        end else if (in_kind == 2'd1) begin
                            stat_k_inputs <= stat_k_inputs + 1'b1;
                        end else if (in_kind == 2'd2) begin
                            stat_v_inputs <= stat_v_inputs + 1'b1;
                        end else begin
                            stat_kind_errors <= stat_kind_errors + 1'b1;
                        end

                        stat_inputs <= stat_inputs + 1'b1;
                        if (stat_inputs == EXPECTED_INPUTS[31:0] - 1'b1)
                            state <= ST_DONE;
                    end
                end

                ST_DONE: begin
                    busy <= 1'b0;
                    done <= 1'b1;
                    state <= ST_IDLE;
                end

                default: begin
                    state <= ST_IDLE;
                end
            endcase
        end
    end
end

endmodule
