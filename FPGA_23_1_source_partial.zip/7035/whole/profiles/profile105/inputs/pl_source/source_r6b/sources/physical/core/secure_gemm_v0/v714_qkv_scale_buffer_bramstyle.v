`timescale 1ns/1ps

module v714_qkv_scale_buffer_bramstyle (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,
    input  wire         wr_valid,
    input  wire [7:0]   wr_beat_addr,
    input  wire [255:0] wr_data,
    output reg          wr_error,
    output reg [31:0]   stat_writes,
    output reg [31:0]   stat_errors,
    input  wire [10:0]  rd_addr,
    output wire signed [31:0] rd_data
);

wire wr_legal = wr_valid && (wr_beat_addr <= 8'd215);
wire [7:0] rd_beat_addr = rd_addr[10:3];
wire [2:0] rd_lane = rd_addr[2:0];
wire [255:0] rd_beat_data;
reg [2:0] rd_lane_q;

v714_bram_sdp_sync #(
    .DATA_W(256),
    .ADDR_W(8),
    .DEPTH(216)
) u_scale_bank (
    .clk(clk),
    .wr_en(wr_legal),
    .wr_addr(wr_beat_addr),
    .wr_data(wr_data),
    .rd_en(1'b1),
    .rd_addr(rd_beat_addr),
    .rd_data(rd_beat_data)
);

always @(posedge clk) begin
    if (!rst_n) begin
        wr_error <= 1'b0;
        stat_writes <= 32'd0;
        stat_errors <= 32'd0;
        rd_lane_q <= 3'd0;
    end else begin
        if (clear) begin
            wr_error <= 1'b0;
            stat_writes <= 32'd0;
            stat_errors <= 32'd0;
            rd_lane_q <= 3'd0;
        end else begin
            wr_error <= 1'b0;
            if (wr_valid) begin
                if (wr_legal)
                    stat_writes <= stat_writes + 1'b1;
                else begin
                    wr_error <= 1'b1;
                    stat_errors <= stat_errors + 1'b1;
                end
            end

            rd_lane_q <= rd_lane;
        end
    end
end

assign rd_data =
    (rd_lane_q == 3'd0) ? rd_beat_data[255 - 0*32 -: 32] :
    (rd_lane_q == 3'd1) ? rd_beat_data[255 - 1*32 -: 32] :
    (rd_lane_q == 3'd2) ? rd_beat_data[255 - 2*32 -: 32] :
    (rd_lane_q == 3'd3) ? rd_beat_data[255 - 3*32 -: 32] :
    (rd_lane_q == 3'd4) ? rd_beat_data[255 - 4*32 -: 32] :
    (rd_lane_q == 3'd5) ? rd_beat_data[255 - 5*32 -: 32] :
    (rd_lane_q == 3'd6) ? rd_beat_data[255 - 6*32 -: 32] :
                          rd_beat_data[255 - 7*32 -: 32];

endmodule
