`timescale 1ns/1ps

// V782 output projection: one 4x4 accumulator tile is retained and drained
// immediately.  This removes the former 52x48x16x32-bit output accumulator.
module v724_live_concat_outproj_linear_add_nomemh #(parameter integer CLOSED_AUDIO_PRODUCER=0, parameter integer ENABLE_MIC_B=0) (


    input wire security_reset_n,
        input wire audio_b_write,audio_b_read,input wire[11:0]audio_b_write_address,audio_b_read_address,
 input wire[255:0]audio_b_write_data,input wire audio_b_response_ready,
 output wire audio_b_write_accepted,audio_b_read_accepted,audio_b_read_response_valid,audio_b_drained,
 output wire[255:0]audio_b_read_data,
input wire audio_a_write,audio_a_read,
    input wire [11:0] audio_a_write_address,audio_a_read_address,
    input wire [255:0] audio_a_write_data,
    output wire [255:0] audio_a_read_data,
    output wire pool_protocol_violation,
input wire [2:0] pool_desired_stage,
    input wire pool_all_quiescent,pool_access_live,
    output wire [2:0] pool_committed_stage,
    output wire pool_owner_ready,pool_fault,pool_quiescent,pool_local_quiescent,
    input wire shared_owner,
    input wire shared_a_write,shared_b_write,
    input wire [11:0] shared_write_address,
    input wire [255:0] shared_write_data,
    input wire shared_a_read,shared_b_read,
    input wire [11:0] shared_a_address,shared_b_address,
    output wire [255:0] shared_a_data,shared_b_data,
    input wire clk,input wire rst_n,input wire clear,
    input wire a_tile_wr_valid,input wire [11:0] a_tile_wr_addr,input wire [255:0] a_tile_wr_data,
    input wire b_tile_wr_valid,input wire [11:0] b_tile_wr_addr,input wire [255:0] b_tile_wr_data,
    input wire scale_wr_valid,input wire [7:0] scale_wr_addr,input wire signed [31:0] scale_wr_data,
    input wire residual_wr_valid,input wire [15:0] residual_wr_addr,input wire signed [15:0] residual_wr_data,
    input wire start,output reg busy,output reg done,
    output reg linear_out_valid,input wire linear_out_ready,
    output reg [15:0] linear_out_addr,output reg signed [15:0] linear_out_data,
    output reg [31:0] stat_a_writes,output reg [31:0] stat_b_writes,
    output reg [31:0] stat_scale_writes,output reg [31:0] stat_residual_writes,
    output reg [31:0] stat_tiles,output reg [31:0] stat_linear_writes,
    output reg [31:0] stat_errors,output reg [31:0] stat_cycles,
    output reg [4:0] stat_stage
);
localparam ROWS=208,ROWS_REAL=197,IN_DIM=196,OUT_DIM=192,TILE=4;
localparam ROW_TILES=52,K_TILES=49,OUT_COL_TILES=48;
localparam A_TILE_DEPTH=ROW_TILES*K_TILES,B_TILE_DEPTH=K_TILES*OUT_COL_TILES;
localparam RESIDUAL_SIZE=ROWS_REAL*OUT_DIM,RES_ROW_TILES=50;
localparam RES_BANK_DEPTH=RES_ROW_TILES*OUT_COL_TILES;
localparam ST_IDLE=0,ST_LOAD=1,ST_WAIT=2,ST_CAPTURE=3,ST_FIRE=4;
localparam ST_PE_WAIT=5,ST_ACC=6,ST_QREQ=7,ST_QWAIT=8,ST_QUANT=9,ST_DONE=10;
localparam ST_QCLAMP=11,ST_QADD=12,ST_QOUT=13;

reg [4:0] state;
reg [5:0] rtile,ctile,ktile;
reg [4:0] lane_idx;
reg pe_in_valid,a_tile_rd_en,b_tile_rd_en,residual_rd_en;
reg [11:0] a_tile_rd_addr_r,b_tile_rd_addr_r,residual_rd_addr_r;
wire [255:0] a_tile_rd_data,b_tile_rd_data,residual_rd_data;
wire pe_in_ready,pe_out_valid;
wire [511:0] pe_c_flat;
wire [31:0] pe_stat_tiles;
reg [255:0] pe_a_flat,pe_b_flat;
reg signed [31:0] acc_tile[0:15];
reg signed [31:0] scale_mem[0:OUT_DIM-1];
reg signed [63:0] quant_wide;
reg signed [15:0] quant_r,residual_r,add_r;
reg signed [16:0] add_wide;
integer i;

wire [15:0] residual_wr_row=residual_wr_addr/OUT_DIM;
wire [15:0] residual_wr_col=residual_wr_addr%OUT_DIM;
wire [3:0] residual_wr_lane={residual_wr_row[1:0],residual_wr_col[1:0]};
wire [11:0] residual_wr_tile_addr=residual_wr_row[15:2]*OUT_COL_TILES+residual_wr_col[15:2];
wire [15:0] residual_wr_lane_en=(residual_wr_valid && residual_wr_addr<RESIDUAL_SIZE)?(16'h1<<residual_wr_lane):0;
wire signed [15:0] residual_lane=
    (lane_idx==0)?$signed(residual_rd_data[255-0*16 -:16]):
    (lane_idx==1)?$signed(residual_rd_data[255-1*16 -:16]):
    (lane_idx==2)?$signed(residual_rd_data[255-2*16 -:16]):
    (lane_idx==3)?$signed(residual_rd_data[255-3*16 -:16]):
    (lane_idx==4)?$signed(residual_rd_data[255-4*16 -:16]):
    (lane_idx==5)?$signed(residual_rd_data[255-5*16 -:16]):
    (lane_idx==6)?$signed(residual_rd_data[255-6*16 -:16]):
    (lane_idx==7)?$signed(residual_rd_data[255-7*16 -:16]):
    (lane_idx==8)?$signed(residual_rd_data[255-8*16 -:16]):
    (lane_idx==9)?$signed(residual_rd_data[255-9*16 -:16]):
    (lane_idx==10)?$signed(residual_rd_data[255-10*16 -:16]):
    (lane_idx==11)?$signed(residual_rd_data[255-11*16 -:16]):
    (lane_idx==12)?$signed(residual_rd_data[255-12*16 -:16]):
    (lane_idx==13)?$signed(residual_rd_data[255-13*16 -:16]):
    (lane_idx==14)?$signed(residual_rd_data[255-14*16 -:16]):$signed(residual_rd_data[15:0]);
wire [7:0] lane_row=(rtile<<2)+(lane_idx>>2);
wire [7:0] lane_col=(ctile<<2)+lane_idx[1:0];
wire [15:0] lane_addr=lane_row*OUT_DIM+lane_col;
// Compatibility/debug aliases used by the established Block0 difftest.
wire signed [31:0] acc_read_r=acc_tile[lane_idx];
wire signed [15:0] residual_read_r=residual_lane;
wire [7:0] q_row=lane_row;
wire [7:0] q_col=lane_col;
wire [11:0] q_tile_addr_i=rtile*OUT_COL_TILES+ctile;
wire [3:0] q_lane_i=lane_idx[3:0];

assign shared_a_data=a_tile_rd_data;
assign audio_a_read_data=a_tile_rd_data;
assign audio_b_read_data=audio_b_read_response_valid?b_tile_rd_data:256'd0;
assign shared_b_data=b_tile_rd_data;
always @(posedge clk) if(scale_wr_valid && scale_wr_addr<OUT_DIM) scale_mem[scale_wr_addr]<=scale_wr_data;

wire ram_a_we,ram_b_we,ram_a_re,ram_b_re;
wire [11:0] ram_a_wa,ram_b_wa,ram_a_ra,ram_b_ra;
wire [255:0] ram_a_wd,ram_b_wd;
trusted_shared_bank_guard #(.A_WORDS(A_TILE_DEPTH),.B_WORDS(B_TILE_DEPTH),.CLOSED_AUDIO_PRODUCER(CLOSED_AUDIO_PRODUCER),.ENABLE_MIC_B(ENABLE_MIC_B)) u_pool_guard(
 .clk(clk),.security_reset_n(security_reset_n),.desired_stage(pool_desired_stage),
 .all_quiescent(pool_all_quiescent),.bank_access_live(pool_access_live),
  .audio_b_wr(audio_b_write),.audio_b_rd(audio_b_read),.audio_b_write_addr(audio_b_write_address),.audio_b_read_addr(audio_b_read_address),.audio_b_write_data(audio_b_write_data),
 .audio_b_response_ready(audio_b_response_ready),.audio_b_write_accepted(audio_b_write_accepted),.audio_b_read_accepted(audio_b_read_accepted),.audio_b_read_response_valid(audio_b_read_response_valid),.audio_b_drained(audio_b_drained),
.audio_a_wr(audio_a_write),.audio_a_rd(audio_a_read),
 .audio_a_write_addr(audio_a_write_address),.audio_a_read_addr(audio_a_read_address),
 .audio_a_write_data(audio_a_write_data),.protocol_violation(pool_protocol_violation),
 // Unmasked requests are intentional: guards must detect hidden masters and
 // real out-of-range attempts, rather than only checking already-masked data.
 .internal_a_wr(a_tile_wr_valid),.internal_b_wr(b_tile_wr_valid),
 .internal_a_write_addr(a_tile_wr_addr),.internal_b_write_addr(b_tile_wr_addr),
 .internal_a_write_data(a_tile_wr_data),.internal_b_write_data(b_tile_wr_data),
 .internal_a_rd(a_tile_rd_en),.internal_b_rd(b_tile_rd_en),
 .internal_a_read_addr(a_tile_rd_addr_r),.internal_b_read_addr(b_tile_rd_addr_r),
 .external_a_wr(shared_a_write),.external_b_wr(shared_b_write),
 .external_write_addr(shared_write_address),.external_write_data(shared_write_data),
 .external_a_rd(shared_a_read),.external_b_rd(shared_b_read),
 .external_a_read_addr(shared_a_address),.external_b_read_addr(shared_b_address),
 .committed_stage(pool_committed_stage),.owner_ready(pool_owner_ready),
 .bank_fault(pool_fault),.guard_quiescent(pool_quiescent),.guard_local_quiescent(pool_local_quiescent),
 .ram_a_wr_en(ram_a_we),.ram_b_wr_en(ram_b_we),
 .ram_a_write_addr(ram_a_wa),.ram_b_write_addr(ram_b_wa),
 .ram_a_write_data(ram_a_wd),.ram_b_write_data(ram_b_wd),
 .ram_a_rd_en(ram_a_re),.ram_b_rd_en(ram_b_re),
 .ram_a_read_addr(ram_a_ra),.ram_b_read_addr(ram_b_ra));
v714_bram_sdp_sync #(.DATA_W(256),.ADDR_W(12),.DEPTH(A_TILE_DEPTH),.FIT_MAX_DEPTH(A_TILE_DEPTH)) u_a_tile_bank(
 .clk(clk),.wr_en(ram_a_we),.wr_addr(ram_a_wa),.wr_data(ram_a_wd),
 .rd_en(ram_a_re),.rd_addr(ram_a_ra),.rd_data(a_tile_rd_data));
v714_bram_sdp_sync #(.DATA_W(256),.ADDR_W(12),.DEPTH(B_TILE_DEPTH),.FIT_MAX_DEPTH(B_TILE_DEPTH)) u_b_tile_bank(
 .clk(clk),.wr_en(ram_b_we),.wr_addr(ram_b_wa),.wr_data(ram_b_wd),
 .rd_en(ram_b_re),.rd_addr(ram_b_ra),.rd_data(b_tile_rd_data));
v719_tile16_lane_bram16_sync #(.ADDR_W(12),.DEPTH(RES_BANK_DEPTH),.FIT_MAX_DEPTH(RES_BANK_DEPTH)) u_residual_bank(
 .clk(clk),.wr_lane_en(residual_wr_lane_en),.wr_addr(residual_wr_tile_addr),.wr_data({16{residual_wr_data}}),
 .rd_en(residual_rd_en),.rd_addr(residual_rd_addr_r),.rd_data(residual_rd_data));
v893_pe4x4_int16_tile_core_pipelined u_pe(.clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(pe_in_valid),.in_ready(pe_in_ready),
 .a_flat(pe_a_flat),.b_flat(pe_b_flat),.out_valid(pe_out_valid),.out_ready(1'b1),.c_flat(pe_c_flat),.stat_tiles(pe_stat_tiles));

always @(posedge clk) begin
 if(!rst_n) begin
  state<=ST_IDLE;rtile<=0;ctile<=0;ktile<=0;lane_idx<=0;busy<=0;done<=0;linear_out_valid<=0;
  linear_out_addr<=0;linear_out_data<=0;pe_in_valid<=0;a_tile_rd_en<=0;b_tile_rd_en<=0;residual_rd_en<=0;
  a_tile_rd_addr_r<=0;b_tile_rd_addr_r<=0;residual_rd_addr_r<=0;pe_a_flat<=0;pe_b_flat<=0;
  quant_wide<=0;quant_r<=0;residual_r<=0;add_wide<=0;add_r<=0;
  stat_a_writes<=0;stat_b_writes<=0;stat_scale_writes<=0;stat_residual_writes<=0;stat_tiles<=0;
  stat_linear_writes<=0;stat_errors<=0;stat_cycles<=0;stat_stage<=ST_IDLE;
  for(i=0;i<16;i=i+1) acc_tile[i]<=0;
 end else begin
  done<=0;pe_in_valid<=0;a_tile_rd_en<=0;b_tile_rd_en<=0;residual_rd_en<=0;stat_stage<=state;
  if(linear_out_valid && linear_out_ready) linear_out_valid<=0;
  if(busy) stat_cycles<=stat_cycles+1'b1;
  if(clear) begin state<=ST_IDLE;busy<=0;linear_out_valid<=0;stat_a_writes<=0;stat_b_writes<=0;
   stat_scale_writes<=0;stat_residual_writes<=0;stat_tiles<=0;stat_linear_writes<=0;stat_errors<=0;stat_cycles<=0;
  end else begin
   if(a_tile_wr_valid) if(a_tile_wr_addr<A_TILE_DEPTH) stat_a_writes<=stat_a_writes+1'b1; else stat_errors<=stat_errors+1'b1;
   if(b_tile_wr_valid) if(b_tile_wr_addr<B_TILE_DEPTH) stat_b_writes<=stat_b_writes+1'b1; else stat_errors<=stat_errors+1'b1;
   if(scale_wr_valid) if(scale_wr_addr<OUT_DIM) stat_scale_writes<=stat_scale_writes+1'b1; else stat_errors<=stat_errors+1'b1;
   if(residual_wr_valid) if(residual_wr_addr<RESIDUAL_SIZE) stat_residual_writes<=stat_residual_writes+1'b1; else stat_errors<=stat_errors+1'b1;
   case(state)
    ST_IDLE: begin busy<=0;if(start) begin busy<=1;rtile<=0;ctile<=0;ktile<=0;lane_idx<=0;
     stat_tiles<=0;stat_linear_writes<=0;stat_cycles<=0;state<=ST_LOAD;end end
    ST_LOAD: begin a_tile_rd_en<=1;b_tile_rd_en<=1;a_tile_rd_addr_r<=rtile*K_TILES+ktile;
     b_tile_rd_addr_r<=ktile*OUT_COL_TILES+ctile;state<=ST_WAIT;end
    ST_WAIT: state<=ST_CAPTURE;
    ST_CAPTURE: begin pe_a_flat<=a_tile_rd_data;pe_b_flat<=b_tile_rd_data;state<=ST_FIRE;end
    ST_FIRE: if(pe_in_ready) begin pe_in_valid<=1;state<=ST_PE_WAIT;end
    ST_PE_WAIT: if(pe_out_valid) state<=ST_ACC;
    ST_ACC: begin
     for(i=0;i<16;i=i+1) acc_tile[i]<=(ktile==0)?$signed(pe_c_flat[511-i*32 -:32]):acc_tile[i]+$signed(pe_c_flat[511-i*32 -:32]);
     stat_tiles<=stat_tiles+1'b1;
     if(ktile==K_TILES-1) begin ktile<=0;lane_idx<=0;state<=ST_QREQ;end else begin ktile<=ktile+1'b1;state<=ST_LOAD;end
    end
    ST_QREQ: begin residual_rd_en<=lane_row<ROWS_REAL;residual_rd_addr_r<=rtile*OUT_COL_TILES+ctile;state<=ST_QWAIT;end
    ST_QWAIT: state<=ST_QUANT;
    ST_QUANT: begin
     quant_wide<=(acc_tile[lane_idx]*scale_mem[lane_col])>>>29;
     residual_r<=(lane_row<ROWS_REAL)?residual_lane:0;
     state<=ST_QCLAMP;
    end
    ST_QCLAMP: begin
     if(quant_wide>32767) quant_r<=16'sh7fff;else if(quant_wide < -32768) quant_r<=16'sh8000;else quant_r<=quant_wide[15:0];
     state<=ST_QADD;
    end
    ST_QADD: begin add_wide<=quant_r+residual_r;state<=ST_QOUT;end
    ST_QOUT: if(!linear_out_valid || linear_out_ready) begin
     if(add_wide>32767)add_r=16'sh7fff;else if(add_wide < -32768)add_r=16'sh8000;else add_r=add_wide[15:0];
     linear_out_valid<=1;linear_out_addr<=lane_addr;linear_out_data<=add_r;stat_linear_writes<=stat_linear_writes+1'b1;
     if(lane_idx==15) begin lane_idx<=0;if(ctile==OUT_COL_TILES-1) begin ctile<=0;
      if(rtile==ROW_TILES-1) state<=ST_DONE;else begin rtile<=rtile+1'b1;state<=ST_LOAD;end
     end else begin ctile<=ctile+1'b1;state<=ST_LOAD;end end else begin lane_idx<=lane_idx+1'b1;state<=ST_QREQ;end
    end
    ST_DONE: begin busy<=0;done<=1;state<=ST_IDLE;end
    default:state<=ST_IDLE;
   endcase
  end
 end
end
endmodule
