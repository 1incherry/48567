`timescale 1ns/1ps

module v736_fullblock_nomemh_axi_pin_slim_top (
    input  wire        clk,
    input  wire        rst_n,
    input  wire [63:0] aaa,
    output wire        led
);

wire [7:0] s_awaddr = aaa[7:0];
wire s_awvalid = aaa[8];
wire s_awready;
wire [31:0] s_wdata = {aaa[31:0]};
wire [3:0] s_wstrb = aaa[35:32];
wire s_wvalid = aaa[36];
wire s_wready;
wire [1:0] s_bresp;
wire s_bvalid;
wire s_bready = aaa[37];
wire [7:0] s_araddr = aaa[45:38];
wire s_arvalid = aaa[46];
wire s_arready;
wire [31:0] s_rdata;
wire [1:0] s_rresp;
wire s_rvalid;
wire s_rready = aaa[47];

wire [31:0] araddr;
wire [7:0] arlen;
wire [2:0] arsize;
wire [1:0] arburst;
wire arvalid;
wire arready = aaa[48];
wire [255:0] rdata = {4{aaa}};
wire [1:0] rresp = aaa[50:49];
wire rlast = aaa[51];
wire rvalid = aaa[52];
wire rready;

wire [31:0] awaddr;
wire [7:0] awlen;
wire [2:0] awsize;
wire [1:0] awburst;
wire awvalid;
wire awready = aaa[53];
wire [255:0] wdata;
wire [31:0] wstrb;
wire wlast;
wire wvalid;
wire wready = aaa[54];
wire [1:0] bresp = aaa[56:55];
wire bvalid = aaa[57];
wire bready;
wire [31:0] stat0;
wire [31:0] stat1;
wire [31:0] stat2;
wire [31:0] stat3;

(* keep_hierarchy = "yes" *)
v736_fullblock_nomemh_axi_lite_full_top u_top (
    .clk(clk),
    .rst_n(rst_n),
    .S_AXIL_AWADDR(s_awaddr),
    .S_AXIL_AWVALID(s_awvalid),
    .S_AXIL_AWREADY(s_awready),
    .S_AXIL_WDATA(s_wdata),
    .S_AXIL_WSTRB(s_wstrb),
    .S_AXIL_WVALID(s_wvalid),
    .S_AXIL_WREADY(s_wready),
    .S_AXIL_BRESP(s_bresp),
    .S_AXIL_BVALID(s_bvalid),
    .S_AXIL_BREADY(s_bready),
    .S_AXIL_ARADDR(s_araddr),
    .S_AXIL_ARVALID(s_arvalid),
    .S_AXIL_ARREADY(s_arready),
    .S_AXIL_RDATA(s_rdata),
    .S_AXIL_RRESP(s_rresp),
    .S_AXIL_RVALID(s_rvalid),
    .S_AXIL_RREADY(s_rready),
    .M_AXI_ARADDR(araddr),
    .M_AXI_ARLEN(arlen),
    .M_AXI_ARSIZE(arsize),
    .M_AXI_ARBURST(arburst),
    .M_AXI_ARVALID(arvalid),
    .M_AXI_ARREADY(arready),
    .M_AXI_RDATA(rdata),
    .M_AXI_RRESP(rresp),
    .M_AXI_RLAST(rlast),
    .M_AXI_RVALID(rvalid),
    .M_AXI_RREADY(rready),
    .M_AXI_AWADDR(awaddr),
    .M_AXI_AWLEN(awlen),
    .M_AXI_AWSIZE(awsize),
    .M_AXI_AWBURST(awburst),
    .M_AXI_AWVALID(awvalid),
    .M_AXI_AWREADY(awready),
    .M_AXI_WDATA(wdata),
    .M_AXI_WSTRB(wstrb),
    .M_AXI_WLAST(wlast),
    .M_AXI_WVALID(wvalid),
    .M_AXI_WREADY(wready),
    .M_AXI_BRESP(bresp),
    .M_AXI_BVALID(bvalid),
    .M_AXI_BREADY(bready),
    .stat0(stat0),
    .stat1(stat1),
    .stat2(stat2),
    .stat3(stat3)
);

assign led = (^aaa) ^ s_awready ^ s_wready ^ (^s_bresp) ^ s_bvalid ^
             s_arready ^ (^s_rdata) ^ (^s_rresp) ^ s_rvalid ^
             (^araddr) ^ (^arlen) ^ (^arsize) ^ (^arburst) ^ arvalid ^
             rready ^ (^awaddr) ^ (^awlen) ^ (^awsize) ^ (^awburst) ^
             awvalid ^ (^wdata) ^ (^wstrb) ^ wlast ^ wvalid ^ bready ^
             (^stat0) ^ (^stat1) ^ (^stat2) ^ (^stat3);

endmodule
