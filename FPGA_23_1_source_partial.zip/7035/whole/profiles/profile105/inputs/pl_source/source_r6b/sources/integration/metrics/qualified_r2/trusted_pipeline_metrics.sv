`timescale 1ns/1ps
// Read-only diagnostic timing. No authority, launch, ownership or DDR outputs.
// Durations are edge-to-edge clock intervals; NN includes its classifier head.
module trusted_pipeline_metrics(
 input wire clk,security_reset_n,authorization_live,
 input wire frame_start,ingress_done,yolo_start,yolo_done,
 input wire frontend_start,nn_start,head_start,nn_done,
 input wire [31:0] roi_index,
 input wire record_commit,abort,
 input wire page_input_wait,mac_busy,pool_wait,
 output wire snapshot_valid,output reg measurement_fault,
 output reg [63:0] total_cycles,ingress_cycles,yolo_cycles,
 output reg [255:0] frontend_cycles,nn_cycles,head_cycles,
 output reg [63:0] page_input_wait_cycles,mac_busy_cycles,pool_wait_cycles,
 output reg [3:0] roi_measured,
 output reg [31:0] sequence_id
);

 // Readonly metrics input boundary. No security/result/owner signal is delayed.
 reg m_input_valid_q;
 reg m_authorization_live_q,m_frame_start_q,m_ingress_done_q,m_yolo_start_q,m_yolo_done_q,m_frontend_start_q,m_nn_start_q,m_head_start_q,m_nn_done_q,m_record_commit_q,m_abort_q,m_page_input_wait_q,m_mac_busy_q,m_pool_wait_q;
 reg[31:0]m_roi_index_q;
 always@(posedge clk)begin
  if(!security_reset_n)begin
   m_input_valid_q<=0;
   m_authorization_live_q<=0;
   m_frame_start_q<=0;
   m_ingress_done_q<=0;
   m_yolo_start_q<=0;
   m_yolo_done_q<=0;
   m_frontend_start_q<=0;
   m_nn_start_q<=0;
   m_head_start_q<=0;
   m_nn_done_q<=0;
   m_record_commit_q<=0;
   m_abort_q<=0;
   m_page_input_wait_q<=0;
   m_mac_busy_q<=0;
   m_pool_wait_q<=0;
   m_roi_index_q<=0;
  end else begin
   m_input_valid_q<=1;
   m_authorization_live_q<=authorization_live;
   m_frame_start_q<=frame_start;
   m_ingress_done_q<=ingress_done;
   m_yolo_start_q<=yolo_start;
   m_yolo_done_q<=yolo_done;
   m_frontend_start_q<=frontend_start;
   m_nn_start_q<=nn_start;
   m_head_start_q<=head_start;
   m_nn_done_q<=nn_done;
   m_record_commit_q<=record_commit;
   m_abort_q<=abort;
   m_page_input_wait_q<=page_input_wait;
   m_mac_busy_q<=mac_busy;
   m_pool_wait_q<=pool_wait;
   m_roi_index_q<=roi_index;
  end
 end
 reg active,stored_valid,ingress_open,yolo_open,yolo_finished,frontend_open,nn_open,head_open;
 reg [1:0] active_roi;
 reg [63:0] ticks,yolo_tick,frontend_tick,nn_tick,head_tick;
 reg [63:0] live_ingress,live_yolo,live_page_wait,live_mac_busy,live_pool_wait;
 reg [255:0] live_frontend,live_nn,live_head;
 reg [3:0] live_roi;
 reg ingress_armed,yolo_armed,nn_armed;
 wire [63:0] now_tick=ticks+64'd1;
 wire stop=m_abort_q||!m_authorization_live_q;
 // Actual child completions may remain asserted in FINISHED until the next
 // accepted job. Consume the first completion only while its window is open.
 wire ingress_end=m_ingress_done_q&&ingress_open&&ingress_armed;
 wire yolo_end=m_yolo_done_q&&yolo_open&&yolo_armed;
 wire nn_end=m_nn_done_q&&nn_open&&nn_armed;
 assign snapshot_valid=stored_valid&&!measurement_fault&&security_reset_n&&m_input_valid_q&&authorization_live&&!abort&&!frame_start&&m_authorization_live_q&&!m_abort_q&&!m_frame_start_q;
 always @(posedge clk)begin
  if(!security_reset_n||!m_input_valid_q)begin
   active<=0;stored_valid<=0;measurement_fault<=0;sequence_id<=0;
   ingress_armed<=0;yolo_armed<=0;nn_armed<=0;
   ingress_open<=0;yolo_open<=0;yolo_finished<=0;frontend_open<=0;nn_open<=0;head_open<=0;active_roi<=0;
   ticks<=0;yolo_tick<=0;frontend_tick<=0;nn_tick<=0;head_tick<=0;
   live_ingress<=0;live_yolo<=0;live_page_wait<=0;live_mac_busy<=0;live_pool_wait<=0;
   live_frontend<=0;live_nn<=0;live_head<=0;live_roi<=0;
   total_cycles<=0;ingress_cycles<=0;yolo_cycles<=0;frontend_cycles<=0;nn_cycles<=0;head_cycles<=0;
   page_input_wait_cycles<=0;mac_busy_cycles<=0;pool_wait_cycles<=0;roi_measured<=0;
  end else if(stop)begin
   active<=0;stored_valid<=0;
   ingress_open<=0;yolo_open<=0;frontend_open<=0;nn_open<=0;head_open<=0;
  end else if(m_frame_start_q)begin
   active<=1;stored_valid<=0;measurement_fault<=active;sequence_id<=sequence_id+1'b1;
   ingress_armed<=!m_ingress_done_q;yolo_armed<=0;nn_armed<=0;
   ingress_open<=1;yolo_open<=0;yolo_finished<=0;frontend_open<=0;nn_open<=0;head_open<=0;
   ticks<=0;live_ingress<=0;live_yolo<=0;live_page_wait<=0;live_mac_busy<=0;live_pool_wait<=0;
   live_frontend<=0;live_nn<=0;live_head<=0;live_roi<=0;
  end else if(active)begin
   ticks<=now_tick;
   if(ingress_open&&!m_ingress_done_q)ingress_armed<=1;
   if(yolo_open&&!m_yolo_done_q)yolo_armed<=1;
   if(nn_open&&!m_nn_done_q)nn_armed<=1;
   if(m_page_input_wait_q)live_page_wait<=live_page_wait+1'b1;
   if(m_mac_busy_q)live_mac_busy<=live_mac_busy+1'b1;
   if(m_pool_wait_q)live_pool_wait<=live_pool_wait+1'b1;
   if(ingress_end)begin
    ingress_open<=0;live_ingress<=now_tick;
   end
   if(m_yolo_start_q)begin
    if(yolo_open||yolo_finished||(!ingress_end&&ingress_open))measurement_fault<=1;
    yolo_open<=1;yolo_tick<=now_tick;yolo_armed<=!m_yolo_done_q;
   end
   if(yolo_end)begin
    yolo_open<=0;yolo_finished<=1;live_yolo<=now_tick-yolo_tick;
   end
   if(m_frontend_start_q)begin
    if(m_roi_index_q>=4||(!yolo_finished&&!yolo_end)||frontend_open||nn_open||head_open||live_roi[m_roi_index_q[1:0]])measurement_fault<=1;
    active_roi<=m_roi_index_q[1:0];frontend_open<=1;frontend_tick<=now_tick;
   end
   if(m_nn_start_q)begin
    if(!frontend_open||nn_open||head_open||m_roi_index_q>=4||m_roi_index_q[1:0]!=active_roi)measurement_fault<=1;
    frontend_open<=0;live_frontend[active_roi*64+:64]<=now_tick-frontend_tick;
    nn_open<=1;nn_tick<=now_tick;nn_armed<=!m_nn_done_q;
   end
   if(m_head_start_q)begin
    if(!nn_open||head_open||m_roi_index_q>=4||m_roi_index_q[1:0]!=active_roi)measurement_fault<=1;
    head_open<=1;head_tick<=now_tick;
   end
   if(nn_end)begin
    if(!nn_open||!head_open||m_roi_index_q>=4||m_roi_index_q[1:0]!=active_roi)measurement_fault<=1;
    nn_open<=0;head_open<=0;live_nn[active_roi*64+:64]<=now_tick-nn_tick;
    live_head[active_roi*64+:64]<=now_tick-head_tick;live_roi[active_roi]<=1;
   end
   if(m_record_commit_q)begin
    if(ingress_open||!yolo_finished||yolo_open||frontend_open||nn_open||head_open||
       measurement_fault||nn_end||ingress_end||yolo_end||
       m_yolo_start_q||m_frontend_start_q||m_nn_start_q||m_head_start_q)begin
     // Do not publish a stale NBA value when commit coincides with a phase end.
     // Actual resultbank commits after all stage completion handshakes.
     measurement_fault<=1;stored_valid<=0;
    end else begin
     total_cycles<=now_tick;ingress_cycles<=live_ingress;yolo_cycles<=live_yolo;
     frontend_cycles<=live_frontend;nn_cycles<=live_nn;head_cycles<=live_head;roi_measured<=live_roi;
     page_input_wait_cycles<=live_page_wait+{63'd0,m_page_input_wait_q};
     mac_busy_cycles<=live_mac_busy+{63'd0,m_mac_busy_q};pool_wait_cycles<=live_pool_wait+{63'd0,m_pool_wait_q};
     stored_valid<=1;
    end
    active<=0;
   end
  end
 end
endmodule
