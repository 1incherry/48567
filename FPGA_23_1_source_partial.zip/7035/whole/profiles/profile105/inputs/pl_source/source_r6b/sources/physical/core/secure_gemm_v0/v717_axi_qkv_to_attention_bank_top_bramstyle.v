`timescale 1ns/1ps

module v717_axi_qkv_to_attention_bank_top_bramstyle (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,

    input  wire         bank_start,
    output wire         bank_done,

    input  wire         load_cmd_valid,
    output wire         load_cmd_ready,
    input  wire [1:0]   load_cmd_dst,
    input  wire [3:0]   load_cmd_block_id,
    input  wire [3:0]   load_cmd_op_id,
    input  wire [31:0]  load_cmd_axi_addr,
    input  wire [11:0]  load_cmd_local_addr,
    input  wire [15:0]  load_cmd_beats,
    input  wire [7:0]   load_cmd_burst_len_m1,
    output wire         load_done,

    input  wire         compute_start,
    input  wire [3:0]   compute_block_id,
    input  wire [3:0]   compute_op_id,
    output wire         compute_busy,
    output wire         compute_done,

    output wire [31:0]  m_axi_araddr,
    output wire [7:0]   m_axi_arlen,
    output wire [2:0]   m_axi_arsize,
    output wire [1:0]   m_axi_arburst,
    output wire         m_axi_arvalid,
    input  wire         m_axi_arready,
    input  wire [255:0] m_axi_rdata,
    input  wire         m_axi_rvalid,
    output wire         m_axi_rready,
    input  wire         m_axi_rlast,

    input  wire         q_rd_en,
    input  wire         k_rd_en,
    input  wire         v_rd_en,
    input  wire [15:0]  q_rd_addr,
    input  wire [15:0]  k_rd_addr,
    input  wire [15:0]  v_rd_addr,
    output wire [255:0] q_rd_data,
    output wire [255:0] k_rd_data,
    output wire [255:0] v_rd_data,

    output wire [31:0]  stat_load_beats,
    output wire [31:0]  stat_load_errors,
    output wire [31:0]  stat_compute_cycles,
    output wire [31:0]  stat_compute_tiles,
    output wire [31:0]  stat_quant_items,
    output wire [31:0]  stat_qkv_stream_stall_cycles,
    output wire [31:0]  stat_bank_inputs,
    output wire [31:0]  stat_bank_q_inputs,
    output wire [31:0]  stat_bank_k_inputs,
    output wire [31:0]  stat_bank_v_inputs,
    output wire [31:0]  stat_bank_kind_errors
);

wire qkv_out_valid;
wire qkv_out_ready;
wire [1:0] qkv_out_kind;
wire [15:0] qkv_out_addr;
wire signed [7:0] qkv_out_data;
wire [31:0] stat_load_cmds_unused;
wire [31:0] stat_quant_checksum_unused;
wire [31:0] stat_qkv_bank_errors_unused;
wire bank_busy_unused;

v717_axi_fed_qkv_stream_top_bramstyle u_qkv (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .load_cmd_valid(load_cmd_valid),
    .load_cmd_ready(load_cmd_ready),
    .load_cmd_dst(load_cmd_dst),
    .load_cmd_block_id(load_cmd_block_id),
    .load_cmd_op_id(load_cmd_op_id),
    .load_cmd_axi_addr(load_cmd_axi_addr),
    .load_cmd_local_addr(load_cmd_local_addr),
    .load_cmd_beats(load_cmd_beats),
    .load_cmd_burst_len_m1(load_cmd_burst_len_m1),
    .load_done(load_done),
    .compute_start(compute_start),
    .compute_block_id(compute_block_id),
    .compute_op_id(compute_op_id),
    .compute_busy(compute_busy),
    .compute_done(compute_done),
    .qkv_out_valid(qkv_out_valid),
    .qkv_out_ready(qkv_out_ready),
    .qkv_out_kind(qkv_out_kind),
    .qkv_out_addr(qkv_out_addr),
    .qkv_out_data(qkv_out_data),
    .m_axi_araddr(m_axi_araddr),
    .m_axi_arlen(m_axi_arlen),
    .m_axi_arsize(m_axi_arsize),
    .m_axi_arburst(m_axi_arburst),
    .m_axi_arvalid(m_axi_arvalid),
    .m_axi_arready(m_axi_arready),
    .m_axi_rdata(m_axi_rdata),
    .m_axi_rvalid(m_axi_rvalid),
    .m_axi_rready(m_axi_rready),
    .m_axi_rlast(m_axi_rlast),
    .stat_load_cmds(stat_load_cmds_unused),
    .stat_load_beats(stat_load_beats),
    .stat_load_errors(stat_load_errors),
    .stat_compute_cycles(stat_compute_cycles),
    .stat_compute_tiles(stat_compute_tiles),
    .stat_quant_items(stat_quant_items),
    .stat_quant_checksum(stat_quant_checksum_unused),
    .stat_stream_stall_cycles(stat_qkv_stream_stall_cycles),
    .stat_bank_errors(stat_qkv_bank_errors_unused)
);

v717_qkv_stream_to_attention_tile_banks_nomemh u_bank (
    .clk(clk),
    .rst_n(rst_n),
    .clear(clear),
    .start(bank_start),
    .in_valid(qkv_out_valid),
    .in_ready(qkv_out_ready),
    .in_kind(qkv_out_kind),
    .in_addr(qkv_out_addr),
    .in_data(qkv_out_data),
    .busy(bank_busy_unused),
    .done(bank_done),
    .stat_inputs(stat_bank_inputs),
    .stat_q_inputs(stat_bank_q_inputs),
    .stat_k_inputs(stat_bank_k_inputs),
    .stat_v_inputs(stat_bank_v_inputs),
    .stat_kind_errors(stat_bank_kind_errors),
    .stat_stage(),
    .q_rd_en(q_rd_en),
    .k_rd_en(k_rd_en),
    .v_rd_en(v_rd_en),
    .q_rd_addr(q_rd_addr),
    .k_rd_addr(k_rd_addr),
    .v_rd_addr(v_rd_addr),
    .q_rd_data(q_rd_data),
    .k_rd_data(k_rd_data),
    .v_rd_data(v_rd_data)
);

endmodule

