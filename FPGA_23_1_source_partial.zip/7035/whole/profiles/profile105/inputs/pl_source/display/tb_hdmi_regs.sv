`timescale 1ns/1ps
module tb_hdmi_regs;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0;reg [31:0] awaddr=0,wdata=0,araddr=0;reg [3:0] wstrb=15;
 reg awvalid=0,wvalid=0,bready=0,arvalid=0,rready=0;
 wire awready,wready,arready,bvalid,rvalid;wire [1:0] bresp,rresp;wire [31:0] rdata,pending_base,pending_seq;wire enable;
 reg [31:0] ack_seq=0;
 hdmi_scan_regs d(.clk(clk),.rst_n(rst_n),.awaddr(awaddr),.wdata(wdata),.araddr(araddr),.wstrb(wstrb),
 .awvalid(awvalid),.wvalid(wvalid),.bready(bready),.arvalid(arvalid),.rready(rready),
 .awready(awready),.wready(wready),.arready(arready),.bvalid(bvalid),.rvalid(rvalid),.bresp(bresp),.rresp(rresp),.rdata(rdata),
 .enable(enable),.pending_base(pending_base),.pending_seq(pending_seq),.ack_seq(ack_seq),.active_base(32'h26000000),
 .frames(32'd17),.underflows(32'b0),.axi_errors(32'b0),.frame_crc(32'h12345678),.locked(1'b1),.stream_idle(1'b0));
 task automatic write_reg(input [31:0] a,v,input integer order,input [1:0] response);
  begin
   fork
    begin repeat(order==1?4:0)@(negedge clk);awaddr=a;awvalid=1;do @(posedge clk);while(!awready);@(negedge clk);awvalid=0;end
    begin repeat(order==2?4:0)@(negedge clk);wdata=v;wvalid=1;do @(posedge clk);while(!wready);@(negedge clk);wvalid=0;end
   join
   wait(bvalid);if(bresp!=response)$fatal(1,"Write response mismatch %x",a);
   repeat(3)begin @(posedge clk);#1;if(!bvalid||bresp!=response)$fatal(1,"B response changed under stall");end
   @(negedge clk);bready=1;@(negedge clk);bready=0;
  end
 endtask
 task automatic read_reg(input [31:0] a,v,input [1:0] response);
  begin
   @(negedge clk);araddr=a;arvalid=1;do @(posedge clk);while(!arready);@(negedge clk);arvalid=0;
   wait(rvalid);if(rresp!=response||rdata!=v)$fatal(1,"Read mismatch %x got %x",a,rdata);
   repeat(3)begin @(posedge clk);#1;if(!rvalid||rdata!=v)$fatal(1,"R response changed under stall");end
   @(negedge clk);rready=1;@(negedge clk);rready=0;
  end
 endtask
 initial begin
  #30;rst_n=1;
  read_reg(0,32'h48444d31,0);
  write_reg(8,32'h26600000,1,0);
  if(pending_base!=32'h26000000)$fatal(1,"Staged address escaped before commit");
  write_reg(12,1,2,0);if(pending_base!=32'h26600000||pending_seq!=1)$fatal(1,"Atomic commit failed");
  write_reg(4,1,0,0);
  write_reg(12,2,1,2); // Unacknowledged sequence cannot be replaced.
  ack_seq=1;write_reg(8,32'h26000000,2,0);
  if(pending_base!=32'h26600000)$fatal(1,"Uncommitted address changed active request");
  write_reg(12,2,0,0);if(pending_base!=32'h26000000)$fatal(1,"Second commit failed");
  write_reg(8,32'hdeadbeef,0,2);wstrb=1;write_reg(4,0,0,2);wstrb=15;
  read_reg(4,1,0);read_reg(32'h28,32'h12345678,0);read_reg(32'h40,0,2);
  $display("HDMI_REGS_PASS AW/W both orders, B/R stalls, atomic base/seq, pending guard, address and WSTRB rejection");$finish;
 end
 initial begin #20000;$fatal(1,"Timeout");end
endmodule

