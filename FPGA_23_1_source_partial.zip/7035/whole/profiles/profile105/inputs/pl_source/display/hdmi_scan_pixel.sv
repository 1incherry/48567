`timescale 1ns/1ps
module hdmi_scan_pixel #(
 parameter WIDTH=1280,HEIGHT=720,HTOTAL=1650,VTOTAL=750,
 parameter HSTART=1390,HEND=1430,VSTART=725,VEND=730
)(
 input wire clk,rst_n,enable,primed,fifo_busy,fifo_empty,
 input wire [63:0] fifo_data,output wire fifo_read,
 output reg [23:0] rgb,output reg hs,vs,de,
 output reg [11:0] pixel_x,pixel_y,
 output reg done_toggle,output reg fault,output reg [31:0] frames,crc_result
);
 reg [11:0] x,y;reg running;
 (* ASYNC_REG="TRUE" *) reg [2:0] enable_sync,primed_sync;
 reg [31:0] crc;
 wire active=x<WIDTH&&y<HEIGHT;
 wire [31:0] px=x[0]?fifo_data[63:32]:fifo_data[31:0];
 wire take=active&&running&&!fifo_empty&&!fifo_busy&&!fault;
 assign fifo_read=take&&x[0];
 function automatic [31:0] crc_byte(input [31:0] c,input [7:0] d);
  reg [31:0] v;integer b;
  begin v=c^d;for(b=0;b<8;b=b+1)v=v[0]?(v>>1)^32'hedb88320:v>>1;crc_byte=v;end
 endfunction
 wire [31:0] crc_next=crc_byte(crc_byte(crc_byte(crc,px[7:0]),px[15:8]),px[23:16]);
 always @(posedge clk)begin
  if(!rst_n)begin
   x<=0;y<=0;pixel_x<=0;pixel_y<=0;running<=0;enable_sync<=0;primed_sync<=0;rgb<=0;hs<=0;vs<=0;de<=0;
   crc<=32'hffffffff;crc_result<=0;done_toggle<=0;fault<=0;frames<=0;
  end else begin
   enable_sync<={enable_sync[1:0],enable};primed_sync<={primed_sync[1:0],primed};
   pixel_x<=x;pixel_y<=y;
   hs<=x>=HSTART&&x<HEND;vs<=y>=VSTART&&y<VEND;de<=active;
   if(take)begin rgb<={px[7:0],px[15:8],px[23:16]};crc<=crc_next;end
   else if(active&&!running)rgb<={x[8:1],y[8:1],8'h40}; // Idle raster, not inference evidence.
   else rgb<=0;
   if(active&&running&&(fifo_empty||fifo_busy))fault<=1;
   if(!enable_sync[2])begin running<=0;fault<=0;end
   if(x==HTOTAL-1)begin x<=0;if(y==VTOTAL-1)y<=0;else y<=y+1;end else x<=x+1;
   if(x==HTOTAL-1&&y==VTOTAL-1)begin
    running<=enable_sync[2]&&primed_sync[2]&&!fault&&!fifo_busy;
    crc<=32'hffffffff;
   end
   if(x==WIDTH-1&&y==HEIGHT-1&&running&&!fault&&take)begin
    done_toggle<=!done_toggle;frames<=frames+1;crc_result<=~crc_next;
   end
  end
 end
endmodule
