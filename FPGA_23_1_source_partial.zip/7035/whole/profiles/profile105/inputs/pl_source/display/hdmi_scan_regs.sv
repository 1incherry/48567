`timescale 1ns/1ps
module hdmi_scan_regs #(parameter integer ENABLE_C3_EN_RESET=0,parameter integer ENABLE_PS_NORMAL_TASK_REQUEST=0,parameter integer ENABLE_MIC_RAW_DIAGNOSTICS=0)(
 input wire clk,rst_n,
 input wire [31:0] awaddr,wdata,araddr,input wire [3:0] wstrb,
 input wire awvalid,wvalid,bready,arvalid,rready,
 output wire awready,wready,arready,output reg bvalid,rvalid,
 output reg [1:0] bresp,rresp,output reg [31:0] rdata,
 output reg enable,output reg [31:0] pending_base,pending_seq,
 input wire [31:0] ack_seq,active_base,frames,underflows,axi_errors,frame_crc,
 input wire locked,input wire stream_idle,
 output wire normal_request_valid,output wire[31:0]normal_request_command,normal_request_epoch,normal_request_model,
 output wire[3:0]normal_request_strobes,input wire[7:0]normal_request_error,
 input wire[31:0]normal_result_word,normal_status_word,
 input wire[223:0]normal_witness_words,
 input wire[511:0]mic_raw_diagnostic_words,
 output wire c3_reset_accept,
 input wire c3_reset_busy,c3_en_observed_high,
 input wire [31:0] c3_reset_accepted_count,c3_reset_completed_count
);
 reg [31:0] rejected_c3_busy;
 reg[31:0]normal_staged_epoch,normal_staged_model;
 reg ah,wh;reg [7:0] addr;reg [31:0] data,staged_base;reg [3:0] strobes;
 // Complete accepted AW/W only; no registered command gap or B replay.
 assign c3_reset_accept=(ENABLE_C3_EN_RESET!=0)&&rst_n&&ah&&wh&&!bvalid&&
  strobes==4'hf&&addr==8'h44&&data==32'h43535231&&!c3_reset_busy;
 assign normal_request_valid=ENABLE_PS_NORMAL_TASK_REQUEST!=0&&rst_n&&ah&&wh&&!bvalid&&addr==8'h6c;
 assign normal_request_command=data;assign normal_request_epoch=normal_staged_epoch;assign normal_request_model=normal_staged_model;assign normal_request_strobes=strobes;
 assign awready=!ah&&!bvalid;assign wready=!wh&&!bvalid;assign arready=!rvalid;
 always @(posedge clk)begin
  if(!rst_n)begin
   rejected_c3_busy<=0;normal_staged_epoch<=0;normal_staged_model<=0;
   ah<=0;wh<=0;bvalid<=0;rvalid<=0;bresp<=0;rresp<=0;rdata<=0;
   enable<=0;pending_base<=32'h27000000;staged_base<=32'h27000000;pending_seq<=0;addr<=0;data<=0;strobes<=0;
  end else begin
   if(awready&&awvalid)begin ah<=1;addr<=awaddr[7:0];end
   if(wready&&wvalid)begin wh<=1;data<=wdata;strobes<=wstrb;end
   if(bvalid&&bready)bvalid<=0;
   if(ah&&wh&&!bvalid)begin
    ah<=0;wh<=0;bvalid<=1;bresp<=0;
    if(strobes!=15)bresp<=2;
    else case(addr)
     8'h04:enable<=data[0];
     8'h08:if(data==32'h27000000||data==32'h27800000)staged_base<=data;else bresp<=2;
     8'h0c:if(data!=0&&(pending_seq==ack_seq||!enable)&&(!enable||data!=pending_seq))begin
      pending_seq<=data;pending_base<=staged_base;
     end else bresp<=2;
     8'h64:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)normal_staged_epoch<=data;else bresp<=2;
     8'h68:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)normal_staged_model<=data;else bresp<=2;
     8'h6c:if(ENABLE_PS_NORMAL_TASK_REQUEST==0)bresp<=2; // Logical dispositions are in normal_result_word, never ARM data-abort.
     8'h44:begin
      if(ENABLE_C3_EN_RESET==0 || data!=32'h43535231 || c3_reset_busy)bresp<=2;
      if(ENABLE_C3_EN_RESET!=0 && data==32'h43535231 && c3_reset_busy)rejected_c3_busy<=rejected_c3_busy+1'b1;
     end
     default:bresp<=2;
    endcase
   end
   if(rvalid&&rready)rvalid<=0;
   if(arready&&arvalid)begin
    rvalid<=1;rresp<=0;
    case(araddr[7:0])
     8'h00:rdata<=32'h48444d31;
     8'h04:rdata<={31'b0,enable};8'h08:rdata<=staged_base;8'h0c:rdata<=pending_seq;
     8'h10:rdata<=ack_seq;8'h14:rdata<=active_base;8'h18:rdata<=frames;
     8'h1c:rdata<=underflows;8'h20:rdata<=axi_errors;
     8'h24:rdata<={30'b0,stream_idle,locked};8'h28:rdata<=frame_crc;
     8'h30:rdata<=1280;8'h34:rdata<=720;8'h38:rdata<=5120;
     8'h78:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_witness_words[0+:32];else begin rdata<=0;rresp<=2;end
     8'h7c:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_witness_words[32+:32];else begin rdata<=0;rresp<=2;end
     8'h80:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_witness_words[64+:32];else begin rdata<=0;rresp<=2;end
     8'h84:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_witness_words[96+:32];else begin rdata<=0;rresp<=2;end
     8'h88:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_witness_words[128+:32];else begin rdata<=0;rresp<=2;end
     8'h8c:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_witness_words[160+:32];else begin rdata<=0;rresp<=2;end
     8'h90:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_witness_words[192+:32];else begin rdata<=0;rresp<=2;end
     8'h94:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[0+:32];else begin rdata<=0;rresp<=2;end
     8'h98:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[32+:32];else begin rdata<=0;rresp<=2;end
     8'h9c:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[64+:32];else begin rdata<=0;rresp<=2;end
     8'ha0:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[96+:32];else begin rdata<=0;rresp<=2;end
     8'ha4:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[128+:32];else begin rdata<=0;rresp<=2;end
     8'ha8:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[160+:32];else begin rdata<=0;rresp<=2;end
     8'hac:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[192+:32];else begin rdata<=0;rresp<=2;end
     8'hb0:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[224+:32];else begin rdata<=0;rresp<=2;end
     8'hb4:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[256+:32];else begin rdata<=0;rresp<=2;end
     8'hb8:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[288+:32];else begin rdata<=0;rresp<=2;end
     8'hbc:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[320+:32];else begin rdata<=0;rresp<=2;end
     8'hc0:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[352+:32];else begin rdata<=0;rresp<=2;end
     8'hc4:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[384+:32];else begin rdata<=0;rresp<=2;end
     8'hc8:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[416+:32];else begin rdata<=0;rresp<=2;end
     8'hcc:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[448+:32];else begin rdata<=0;rresp<=2;end
     8'hd0:if(ENABLE_MIC_RAW_DIAGNOSTICS!=0)rdata<=mic_raw_diagnostic_words[480+:32];else begin rdata<=0;rresp<=2;end
     8'h60:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=32'h56534331;else begin rdata<=0;rresp<=2;end
     8'h64:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_staged_epoch;else begin rdata<=0;rresp<=2;end
     8'h68:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_staged_model;else begin rdata<=0;rresp<=2;end
     8'h6c:begin rdata<=0;rresp<=2;end
     8'h70:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_result_word;else begin rdata<=0;rresp<=2;end
     8'h74:if(ENABLE_PS_NORMAL_TASK_REQUEST!=0)rdata<=normal_status_word;else begin rdata<=0;rresp<=2;end
     8'h40:if(ENABLE_C3_EN_RESET!=0)rdata<=32'h43535231;else begin rdata<=0;rresp<=2;end
     8'h44:begin rdata<=0;rresp<=2;end // command is write-only
     8'h48:if(ENABLE_C3_EN_RESET!=0)rdata<={30'd0,c3_en_observed_high,c3_reset_busy};else begin rdata<=0;rresp<=2;end
     8'h4c:if(ENABLE_C3_EN_RESET!=0)rdata<=c3_reset_accepted_count;else begin rdata<=0;rresp<=2;end
     8'h50:if(ENABLE_C3_EN_RESET!=0)rdata<=c3_reset_completed_count;else begin rdata<=0;rresp<=2;end
     8'h54:if(ENABLE_C3_EN_RESET!=0)rdata<=rejected_c3_busy;else begin rdata<=0;rresp<=2;end
     8'h58:if(ENABLE_C3_EN_RESET!=0)rdata<=32'h00010000;else begin rdata<=0;rresp<=2;end
     default:begin rdata<=0;rresp<=2;end
    endcase
   end
  end
 end
endmodule
