// Same-clock control boundary for a future QHD1 display consumer.
// Not a DDR reader or an HDMI transmitter. See INTEGRATION.md.
// Publisher must hold all pending fields until this sequence is acknowledged.
module qhd_frame_commit (
    input  wire        clk,
    input  wire        rst_n,
    input  wire        consumer_enabled,
    input  wire        pending_valid,
    input  wire [31:0] pending_sequence,
    input  wire [31:0] pending_address,
    input  wire [31:0] pending_width,
    input  wire [31:0] pending_height,
    input  wire [31:0] pending_stride,
    input  wire [31:0] pending_format,
    // Pulse in vblank, after the previous-frame DMA and stream FIFO drain.
    input  wire        frame_boundary,
    input  wire        pipeline_idle,
    output reg         active_valid,
    output reg  [31:0] active_address,
    output reg  [31:0] active_sequence,
    output reg         ack_pulse,
    output reg  [31:0] ack_sequence,
    output reg         reject_pulse
);
    localparam [31:0] RGB3 = 32'h52474233;
    wire config_ok = (pending_address == 32'h26000000 ||
                      pending_address == 32'h26600000) &&
                     pending_width == 1920 && pending_height == 1080 &&
                     pending_stride == 5760 && pending_format == RGB3;
    always @(posedge clk) begin
        if (!rst_n) begin
            active_valid <= 0;
            active_address <= 0;
            active_sequence <= 0;
            ack_sequence <= 0;
            ack_pulse <= 0;
            reject_pulse <= 0;
        end else begin
            ack_pulse <= 0;
            reject_pulse <= 0;
            if (consumer_enabled && pending_valid && frame_boundary && pipeline_idle &&
                (!active_valid || pending_sequence != active_sequence)) begin
                if (config_ok) begin
                    active_valid <= 1;
                    active_address <= pending_address;
                    active_sequence <= pending_sequence;
                    ack_sequence <= pending_sequence;
                    ack_pulse <= 1;
                end else begin
                    reject_pulse <= 1;
                end
            end
        end
    end
endmodule
