`timescale 1ns/1ps
module tb_hdmi_fault;
 reg clk=0,pix=0;always #5 clk=~clk;always #7 pix=~pix;
 reg rst_n=0,enable=0;reg [31:0] pending_base=32'h26000000,pending_seq=1;
 wire done,fault,primed,idle,frst;wire [31:0] ack,base,errors,araddr;
 wire arvalid,rready,fw,fr;reg arready=0,rv=0,rl=0;reg [63:0] rd;reg [1:0] resp=0;
 wire [63:0] fd;wire [23:0] rgb;wire hs,vs,de;wire [31:0] frames,crc;
 reg [63:0] queue[0:255];integer wrn=0,rdn=0;
 wire [11:0] count=wrn-rdn;wire empty=wrn==rdn;
 wire [63:0] qdata=queue[rdn%256];reg inject_empty=0;
 hdmi_scan_dma #(.FRAME_BYTES(512),.FIFO_DEPTH(256),.PRIME_WORDS(16),.BURST_BEATS(16)) d(
  .clk(clk),.rst_n(rst_n),.enable(enable),.pending_base(pending_base),.pending_seq(pending_seq),
  .pixel_done_toggle(done),.pixel_fault(fault),.ack_seq(ack),.active_base(base),.axi_errors(errors),
  .stream_idle(idle),.fifo_reset(frst),.primed(primed),.araddr(araddr),.arvalid(arvalid),.arready(arready),
  .rdata(rd),.rresp(resp),.rlast(rl),.rvalid(rv),.rready(rready),.fifo_data(fd),.fifo_write(fw),
  .fifo_full(count>=256),.fifo_busy(1'b0),.fifo_count(count));
 hdmi_scan_pixel #(.WIDTH(32),.HEIGHT(4),.HTOTAL(48),.VTOTAL(8),.HSTART(36),.HEND(40),.VSTART(5),.VEND(6)) p(
  .clk(pix),.rst_n(rst_n),.enable(enable),.primed(primed),.fifo_busy(1'b0),.fifo_empty(empty||inject_empty),.fifo_data(qdata),
  .fifo_read(fr),.rgb(rgb),.hs(hs),.vs(vs),.de(de),.done_toggle(done),.fault(fault),.frames(frames),.crc_result(crc));
 function automatic [31:0] sample(input [31:0] addr);
  reg [31:0] n;reg bank;begin bank=addr>=32'h26600000;n=(addr-(bank?32'h26600000:32'h26000000))/4;
   sample={8'b0,8'(n*7+bank*91),8'(n*3+bank*19),8'(n+bank*37)};end
 endfunction
 integer cyc=0,beat=0;reg inflight=0;reg [31:0] req;
 always @(negedge clk)begin
  cyc=cyc+1;arready=!inflight&&(cyc%5!=0);
  if(!inflight)rv=0;
  else if(!rv||(rv&&rready))begin
   rv=(cyc%4!=0);rd={sample(req+beat*8+4),sample(req+beat*8)};rl=beat==15;
  end
 end
 always @(posedge clk)begin
  if(arvalid&&arready)begin
   if(inflight||araddr[6:0]!=0||araddr[11:0]>3968)$fatal(1,"Bad AXI request");
   inflight<=1;beat<=0;req<=araddr;
  end
  if(rv&&rready)begin if(rl)inflight<=0;else beat<=beat+1;end
  if(frst)wrn<=0;else if(fw)begin queue[wrn%256]<=fd;wrn<=wrn+1;end
 end
 integer checked=0,passframes=0;reg [31:0] expected,framebase;reg [31:0] software_crc=32'hffffffff;
 function automatic [31:0] crc_byte(input [31:0] c,input [7:0] b);
  reg [31:0] v;integer j;begin v=c^b;for(j=0;j<8;j=j+1)v=v[0]?(v>>1)^32'hedb88320:v>>1;crc_byte=v;end
 endfunction
 always @(posedge pix)begin
  if(frst)rdn<=0;else if(fr)rdn<=rdn+1;
  if(p.x==0&&p.y==0)begin framebase=base;checked=0;software_crc=32'hffffffff;end
  if(p.take)begin
   expected=sample(framebase+checked*4);
   if(p.px!==expected)$fatal(1,"Pixel mismatch n=%d got=%x expected=%x",checked,p.px,expected);
   software_crc=crc_byte(crc_byte(crc_byte(software_crc,expected[7:0]),expected[15:8]),expected[23:16]);checked=checked+1;
   if(checked==128)begin
    #1;if(crc!==~software_crc)$fatal(1,"Frame CRC mismatch");
    passframes=passframes+1;$display("PIXEL_FRAME_PASS %d base=%x crc=%x",passframes,framebase,crc);
   end
  end
 end
 initial begin
  #100;rst_n=1;#40;enable=1;
  wait(passframes==2);@(negedge clk);pending_base=32'h26600000;pending_seq=2;
  wait(ack==2);if(base!=32'h26600000)$fatal(1,"Wrong committed base");
  wait(passframes==5);if(fault||errors)$fatal(1,"Unexpected DMA/pixel fault");
  wait(p.take&&p.x==8&&p.y==0);@(negedge pix);inject_empty=1;
  wait(fault);wait(d.state==5);@(negedge clk);enable=0;wait(idle);#100;
  inject_empty=0;#100;enable=1;wait(passframes==6);
  if(fault||errors)$fatal(1,"Fault recovery failed");
  @(negedge clk);enable=0;wait(idle);#100;
  $display("HDMI_UNDERFLOW_RECOVERY_PASS fail-closed stop, explicit disable/drain and reenable");$finish;
 end
 initial begin #200000;$fatal(1,"Timeout");end
endmodule
