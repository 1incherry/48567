`timescale 1ns/1ps
module tb_qhd_frame_commit;
    reg clk=0; always #5 clk=~clk;
    reg rst_n=0, enabled=0, valid=0, boundary=0, idle=1;
    reg [31:0] seq=1, addr=32'h26000000, width=1920, height=1080;
    reg [31:0] stride=5760, format=32'h52474233;
    wire active, ack, reject;
    wire [31:0] active_addr, active_seq, ack_seq;
    qhd_frame_commit dut(clk,rst_n,enabled,valid,seq,addr,width,height,stride,
                         format,boundary,idle,active,active_addr,active_seq,ack,ack_seq,reject);
    task tick; begin @(posedge clk); #1; end endtask
    task check(input bit pass, input [511:0] message);
        if (!pass) $fatal(1,"%0s",message);
    endtask
    initial begin
        tick(); rst_n=1; valid=1; boundary=1;
        tick(); check(!ack && !active,"disabled consumer acknowledged");
        enabled=1; boundary=0;
        tick(); check(!ack && !active,"committed outside vblank");
        boundary=1; idle=0;
        tick(); check(!ack && !active,"committed with DMA in flight");
        idle=1;
        tick(); check(ack && active && active_addr==addr && ack_seq==1,"first commit failed");
        tick(); check(!ack,"same sequence acknowledged twice");
        // Publisher prepares the other framebuffer; the active pair must stay atomic.
        seq=2; addr=32'h26600000; boundary=0;
        tick(); check(!ack && active_seq==1 && active_addr==32'h26000000,"torn active frame");
        boundary=1; stride=5759;
        tick(); check(reject && !ack && active_seq==1,"bad stride accepted");
        stride=5760; addr=32'h22000000;
        tick(); check(reject && !ack && active_seq==1,"non-display buffer accepted");
        addr=32'h26600000;
        tick(); check(ack && active_seq==2 && ack_seq==2 && active_addr==addr,"second commit failed");
        // Full 32-bit sequence, including wrap, is compared without signed ordering.
        seq=32'hffffffff; addr=32'h26000000;
        tick(); check(ack && ack_seq==32'hffffffff,"high sequence lost");
        seq=0; addr=32'h26600000;
        tick(); check(ack && ack_seq==0 && active_seq==0,"wrapped sequence lost");
        enabled=0; seq=1;
        tick(); check(!ack && active_seq==0,"disabled swap accepted");
        $display("QHD_FRAME_COMMIT_PASS"); $finish;
    end
endmodule
