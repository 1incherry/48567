`timescale 1ns/1ps
module hdmi_quad_top #(parameter integer ENABLE_C3_EN_RESET=0,parameter integer ENABLE_PS_NORMAL_TASK_REQUEST=0,parameter integer ENABLE_MIC_RAW_DIAGNOSTICS=0)(
 input wire clk,ref200,rst_n,
 output wire normal_request_valid,output wire[31:0]normal_request_command,normal_request_epoch,normal_request_model,
 output wire[3:0]normal_request_strobes,input wire[7:0]normal_request_error,
 input wire[31:0]normal_result_word,normal_status_word,
 input wire[223:0]normal_witness_words,
 input wire[511:0]mic_raw_diagnostic_words,
 output wire c3_reset_accept,input wire c3_reset_busy,c3_en_observed_high,
 input wire [31:0] c3_reset_accepted_count,c3_reset_completed_count,
 output wire[31:0] observation_ack_seq,observation_active_base,observation_frames,output wire observation_healthy,
 output wire trusted_pixel_clk,trusted_pixel_reset_n,
 output wire [11:0] trusted_pixel_x,trusted_pixel_y,
 output wire [23:0] trusted_pixel_rgb,output wire trusted_pixel_hs,trusted_pixel_vs,trusted_pixel_de,
 input wire [23:0] trusted_overlay_rgb,input wire trusted_overlay_hs,trusted_overlay_vs,trusted_overlay_de,
 input wire [31:0] c_awaddr,c_wdata,c_araddr,input wire [3:0] c_wstrb,
 input wire c_awvalid,c_wvalid,c_bready,c_arvalid,c_rready,
 output wire c_awready,c_wready,c_arready,c_bvalid,c_rvalid,
 output wire [1:0] c_bresp,c_rresp,output wire [31:0] c_rdata,
 output wire [31:0] m_araddr,output wire m_arvalid,input wire m_arready,
 input wire [63:0] m_rdata,input wire [1:0] m_rresp,input wire m_rlast,m_rvalid,
 output wire m_rready,
 output wire HDMI_CLK_P,HDMI_CLK_N,HDMI_D0_P,HDMI_D0_N,
 output wire HDMI_D1_P,HDMI_D1_N,HDMI_D2_P,HDMI_D2_N,HDMI_TX_POWER_EN
);
 wire pixel_raw,serial_raw,fb_raw,pixel_clk,serial_clk,locked,ref200_global;
 BUFG vref(.I(ref200),.O(ref200_global));
 MMCME2_ADV #(.CLKIN1_PERIOD(5.0),.DIVCLK_DIVIDE(10),.CLKFBOUT_MULT_F(37.125),
  .CLKOUT0_DIVIDE_F(10.0),.CLKOUT1_DIVIDE(2),.COMPENSATION("INTERNAL")) video_mmcm(
  .CLKIN1(ref200_global),.CLKIN2(1'b0),.CLKINSEL(1'b1),.CLKFBIN(fb_raw),.RST(!rst_n),.PWRDWN(1'b0),
  .DADDR(7'b0),.DCLK(1'b0),.DEN(1'b0),.DI(16'b0),.DWE(1'b0),.PSCLK(1'b0),.PSEN(1'b0),.PSINCDEC(1'b0),
  .CLKFBOUT(fb_raw),.CLKOUT0(pixel_raw),.CLKOUT1(serial_raw),.LOCKED(locked));
 BUFG vpix(.I(pixel_raw),.O(pixel_clk));BUFG vserial(.I(serial_raw),.O(serial_clk));
 (* ASYNC_REG="TRUE" *) reg [3:0] pixel_reset=15;
 always @(posedge pixel_clk or negedge rst_n)begin
  if(!rst_n)pixel_reset<=15;else if(!locked)pixel_reset<=15;else pixel_reset<={pixel_reset[2:0],1'b0};
 end
 wire enable,primed,stream_idle,done_toggle,pixel_fault;
 wire [31:0] pending_base,pending_seq,ack_seq,active_base,axi_errors;
 wire fifo_reset,fifo_write,fifo_read,fifo_full,fifo_empty,wr_busy,rd_busy;
 wire [63:0] fifo_din,fifo_dout;wire [11:0] fifo_count;
 wire [23:0] rgb;wire hs,vs,de;wire [31:0] pixel_frames,pixel_crc;
 reg [31:0] frames,crc_result,underflows;
 (* ASYNC_REG="TRUE" *) reg [3:0] done_sync;
 (* ASYNC_REG="TRUE" *) reg [2:0] fault_sync,lock_sync;
 reg last_done,last_fault;
 always @(posedge clk)begin
  if(!rst_n)begin
   done_sync<=0;fault_sync<=0;lock_sync<=0;last_done<=0;last_fault<=0;
   frames<=0;crc_result<=0;underflows<=0;
  end else begin
   done_sync<={done_sync[2:0],done_toggle};fault_sync<={fault_sync[1:0],pixel_fault};lock_sync<={lock_sync[1:0],locked};
   if(done_sync[3]!=last_done)begin last_done<=done_sync[3];frames<=pixel_frames;crc_result<=pixel_crc;end
   last_fault<=fault_sync[2];if(enable&&fault_sync[2]&&!last_fault)underflows<=underflows+1;
  end
 end
 // These observations are already in the control clock domain.
 assign observation_ack_seq=ack_seq;assign observation_active_base=active_base;assign observation_frames=frames;
 assign observation_healthy=lock_sync[2]&&underflows==0&&axi_errors==0;
 hdmi_scan_regs #(.ENABLE_C3_EN_RESET(ENABLE_C3_EN_RESET),.ENABLE_PS_NORMAL_TASK_REQUEST(ENABLE_PS_NORMAL_TASK_REQUEST),.ENABLE_MIC_RAW_DIAGNOSTICS(ENABLE_MIC_RAW_DIAGNOSTICS)) regs(
  .mic_raw_diagnostic_words(mic_raw_diagnostic_words),
  .normal_request_valid(normal_request_valid),.normal_request_command(normal_request_command),.normal_request_epoch(normal_request_epoch),.normal_request_model(normal_request_model),
  .normal_request_strobes(normal_request_strobes),.normal_request_error(normal_request_error),.normal_result_word(normal_result_word),.normal_status_word(normal_status_word),.normal_witness_words(normal_witness_words),
  .c3_reset_accept(c3_reset_accept),.c3_reset_busy(c3_reset_busy),.c3_en_observed_high(c3_en_observed_high),
  .c3_reset_accepted_count(c3_reset_accepted_count),.c3_reset_completed_count(c3_reset_completed_count),.clk(clk),.rst_n(rst_n),.awaddr(c_awaddr),.wdata(c_wdata),.araddr(c_araddr),.wstrb(c_wstrb),
  .awvalid(c_awvalid),.wvalid(c_wvalid),.bready(c_bready),.arvalid(c_arvalid),.rready(c_rready),
  .awready(c_awready),.wready(c_wready),.arready(c_arready),.bvalid(c_bvalid),.rvalid(c_rvalid),
  .bresp(c_bresp),.rresp(c_rresp),.rdata(c_rdata),.enable(enable),.pending_base(pending_base),.pending_seq(pending_seq),
  .ack_seq(ack_seq),.active_base(active_base),.frames(frames),.underflows(underflows),.axi_errors(axi_errors),
  .frame_crc(crc_result),.locked(lock_sync[2]),.stream_idle(stream_idle));
 hdmi_scan_dma dma(.clk(clk),.rst_n(rst_n),.enable(enable),.pending_base(pending_base),.pending_seq(pending_seq),
  .pixel_done_toggle(done_toggle),.pixel_fault(pixel_fault),.ack_seq(ack_seq),.active_base(active_base),.axi_errors(axi_errors),
  .stream_idle(stream_idle),.fifo_reset(fifo_reset),.primed(primed),.araddr(m_araddr),.arvalid(m_arvalid),.arready(m_arready),
  .rdata(m_rdata),.rresp(m_rresp),.rlast(m_rlast),.rvalid(m_rvalid),.rready(m_rready),
  .fifo_data(fifo_din),.fifo_write(fifo_write),.fifo_full(fifo_full),.fifo_busy(wr_busy),.fifo_count(fifo_count));
 xpm_fifo_async #(.FIFO_MEMORY_TYPE("block"),.FIFO_WRITE_DEPTH(2048),.WRITE_DATA_WIDTH(64),.READ_DATA_WIDTH(64),
  .READ_MODE("fwft"),.FIFO_READ_LATENCY(0),.CDC_SYNC_STAGES(2),.WR_DATA_COUNT_WIDTH(12),.RD_DATA_COUNT_WIDTH(12),
  .USE_ADV_FEATURES("0707"),.DOUT_RESET_VALUE("0"),.ECC_MODE("no_ecc")) pixels(
  .rst(fifo_reset),.wr_clk(clk),.wr_en(fifo_write),.din(fifo_din),.full(fifo_full),.wr_rst_busy(wr_busy),.wr_data_count(fifo_count),
  .rd_clk(pixel_clk),.rd_en(fifo_read),.dout(fifo_dout),.empty(fifo_empty),.rd_rst_busy(rd_busy),
  .sleep(1'b0),.injectsbiterr(1'b0),.injectdbiterr(1'b0));
 hdmi_scan_pixel scan(.clk(pixel_clk),.rst_n(!pixel_reset[3]),.enable(enable),.primed(primed),.fifo_busy(rd_busy),.fifo_empty(fifo_empty),
  .fifo_data(fifo_dout),.fifo_read(fifo_read),.pixel_x(trusted_pixel_x),.pixel_y(trusted_pixel_y),.rgb(rgb),.hs(hs),.vs(vs),.de(de),
  .done_toggle(done_toggle),.fault(pixel_fault),.frames(pixel_frames),.crc_result(pixel_crc));
 HDMI_FPGA_ML transmitter(.PXLCLK_I(pixel_clk),.PXLCLK_5X_I(serial_clk),.LOCKED_I(locked),.RST_N(!pixel_reset[3]),
  .VGA_HS(trusted_overlay_hs),.VGA_VS(trusted_overlay_vs),.VGA_DE(trusted_overlay_de),.VGA_RGB(trusted_overlay_rgb),
  .HDMI_CLK_P(HDMI_CLK_P),.HDMI_CLK_N(HDMI_CLK_N),.HDMI_D0_P(HDMI_D0_P),.HDMI_D0_N(HDMI_D0_N),
  .HDMI_D1_P(HDMI_D1_P),.HDMI_D1_N(HDMI_D1_N),.HDMI_D2_P(HDMI_D2_P),.HDMI_D2_N(HDMI_D2_N));
 assign trusted_pixel_clk=pixel_clk;
 assign trusted_pixel_reset_n=!pixel_reset[3];
 assign trusted_pixel_rgb=rgb;assign trusted_pixel_hs=hs;assign trusted_pixel_vs=vs;assign trusted_pixel_de=de;
 assign HDMI_TX_POWER_EN=locked;
endmodule
