`timescale 1ns/1ps
// One bounded 2KiB burst at a time; SmartConnect splits it for the PS AXI3 port.
// 2KiB alignment never crosses 4KiB. Reserve space for the entire burst.
// A new framebuffer is accepted only after the previous frame has been both
// read from DDR and consumed by the pixel domain. ACK permits reuse of old DDR.
module hdmi_scan_dma #(
 parameter FRAME_BYTES=1280*720*4,parameter FIFO_DEPTH=2048,parameter PRIME_WORDS=1024,
 parameter BURST_BEATS=256
)(
 input wire clk,rst_n,enable,input wire [31:0] pending_base,pending_seq,
 input wire pixel_done_toggle,pixel_fault,
 output reg [31:0] ack_seq,active_base,axi_errors,
 output wire stream_idle,output wire fifo_reset,output reg primed,
 output reg [31:0] araddr,output reg arvalid,input wire arready,
 input wire [63:0] rdata,input wire [1:0] rresp,input wire rlast,rvalid,
 output wire rready,output wire [63:0] fifo_data,output wire fifo_write,
 input wire fifo_full,fifo_busy,input wire [11:0] fifo_count
);
 localparam IDLE=0,ISSUE=1,DATA=2,WAIT_PIXEL=3,BEGIN_FRAME=4,STOP=5;
 reg [2:0] state;reg [31:0] offset;reg [8:0] beats;
 (* ASYNC_REG="TRUE" *) reg [2:0] done_sync,fault_sync;
 reg last_done;
 assign stream_idle=state==IDLE;
 assign fifo_reset=!rst_n||state==IDLE;
 assign rready=state==DATA&&((!enable||fault_sync[2])||(!fifo_full&&!fifo_busy));
 assign fifo_data=rdata;assign fifo_write=rvalid&&rready&&enable&&!fault_sync[2];
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;offset<=0;beats<=0;araddr<=0;arvalid<=0;ack_seq<=0;
   active_base<=0;axi_errors<=0;primed<=0;done_sync<=0;fault_sync<=0;last_done<=0;
  end else begin
   done_sync<={done_sync[1:0],pixel_done_toggle};fault_sync<={fault_sync[1:0],pixel_fault};
   if(fifo_count>=PRIME_WORDS&&state!=IDLE)primed<=1;
   case(state)
    IDLE:begin
     arvalid<=0;primed<=0;last_done<=done_sync[2];
     if(enable&&pending_seq!=0)begin
      active_base<=pending_base;ack_seq<=pending_seq;offset<=0;state<=BEGIN_FRAME;
     end
    end
    BEGIN_FRAME:if(!enable||fault_sync[2])state<=STOP;
      else if(!fifo_busy)state<=ISSUE;
    ISSUE:begin
     if(arvalid)begin if(arready)begin arvalid<=0;beats<=0;state<=DATA;end end
     else if(!enable||fault_sync[2])state<=STOP;
     else if(fifo_count<=FIFO_DEPTH-BURST_BEATS-16&&!fifo_busy)begin araddr<=active_base+offset;arvalid<=1;end
    end
    DATA:if(rvalid&&rready)begin
     if(rresp!=0||rlast!=(beats==BURST_BEATS-1))axi_errors<=axi_errors+1;
     if(rlast)begin
      offset<=offset+BURST_BEATS*8;
      if(!enable||fault_sync[2]||axi_errors!=0||rresp!=0||beats!=BURST_BEATS-1)state<=STOP;
      else if(offset+BURST_BEATS*8==FRAME_BYTES)state<=WAIT_PIXEL;
      else state<=ISSUE;
     end else beats<=beats+1;
    end
    WAIT_PIXEL:begin
     if(!enable||fault_sync[2])state<=STOP;
     else if(done_sync[2]!=last_done)begin
      last_done<=done_sync[2];offset<=0;
      // Pixel frame end is followed by vertical blank. FIFO has drained.
      active_base<=pending_base;ack_seq<=pending_seq;state<=BEGIN_FRAME;
     end
    end
    STOP:if(!enable)state<=IDLE; // Fault is sticky until explicit disable.
    default:state<=IDLE;
   endcase
  end
 end
endmodule
