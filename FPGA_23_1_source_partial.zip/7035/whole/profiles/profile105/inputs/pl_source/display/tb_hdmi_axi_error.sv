`timescale 1ns/1ps
module tb_hdmi_axi_error;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,enable=0,arready=0,rv=0,rl=0;reg [1:0] resp=0;
 wire [31:0] ack,base,errors,addr;wire idle,reset_fifo,primed,av,rr,fw;wire [63:0] fd;
 hdmi_scan_dma #(.FRAME_BYTES(512),.BURST_BEATS(16),.PRIME_WORDS(16)) d(
 .clk(clk),.rst_n(rst_n),.enable(enable),.pending_base(32'h26000000),.pending_seq(32'd1),
 .pixel_done_toggle(1'b0),.pixel_fault(1'b0),.ack_seq(ack),.active_base(base),.axi_errors(errors),
 .stream_idle(idle),.fifo_reset(reset_fifo),.primed(primed),.araddr(addr),.arvalid(av),.arready(arready),
 .rdata(64'b0),.rresp(resp),.rlast(rl),.rvalid(rv),.rready(rr),.fifo_data(fd),.fifo_write(fw),
 .fifo_full(1'b0),.fifo_busy(1'b0),.fifo_count(12'b0));
 integer n,requests=0;
 always @(posedge clk)if(av&&arready)requests=requests+1;
 initial begin
  #30;rst_n=1;enable=1;wait(av);@(negedge clk);arready=1;@(negedge clk);arready=0;
  for(n=0;n<16;n=n+1)begin
   @(negedge clk);rv=1;rl=n==15;resp=n==5?2:0;
   @(posedge clk);if(!rr)$fatal(1,"Unexpected data backpressure");
  end
  @(negedge clk);rv=0;rl=0;resp=0;repeat(10)@(posedge clk);
  if(errors!=1||d.state!=5||requests!=1||av)$fatal(1,"Middle-beat AXI error did not stop DMA");
  @(negedge clk);enable=0;wait(idle);#20;
  $display("HDMI_AXI_ERROR_PASS middle-beat error held through final OK beat; DMA stopped and drained");$finish;
 end
 initial begin #20000;$fatal(1,"Timeout");end
endmodule
