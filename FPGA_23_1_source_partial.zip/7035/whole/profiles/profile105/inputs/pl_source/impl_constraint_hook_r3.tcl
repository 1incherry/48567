set base [file normalize [file dirname [info script]]]
source $base/physical_constraints/constrain_record_cdc.tcl
constrain_trusted_record_cdc u_outputs/tx_cdc 10.000 8.000
source $base/physical_constraints/constrain_pixel_fifo_cdc.tcl
constrain_trusted_pixel_fifo_cdc u_outputs/pixel_cdc
constrain_trusted_record_overlay u_outputs/overlay
# Only explicitly asynchronous reset synchronizer CLR/PRE pins are excepted.
# Downstream security-reset fanout/recovery and every D path remain timed.
foreach {path count} {
 u_trusted_clock/reset100_pipe_reg* 3
 u_trusted_clock/reset50_pipe_reg* 3
 u_system/u_root/root_release_reg* 3
 u_system/u_root/ps_release_reg* 2
} {
 set cells [get_cells -hier -filter [format {NAME =~ "%s"} $path]]
 if {[llength $cells]!=$count} {error "RESET_SYNC_COUNT $path wanted=$count actual=[llength $cells]"}
 set pins [get_pins -of_objects $cells -filter {REF_PIN_NAME == CLR || REF_PIN_NAME == PRE}]
 if {[llength $pins]!=$count} {error "RESET_SYNC_PIN_COUNT $path"}
 set_false_path -to $pins
 puts "PRECISE_ASYNC_RESET_SYNC $path count=[llength $pins]"
}
source $base/check_native_nfr_cdc_r3.tcl
source $base/check_hdmi_cdc.tcl
report_drc -checks LUTLP-1 -file $base/loop_check_preopt.rpt
report_clocks -file $base/clocks_impl_input.rpt
check_timing -verbose -file $base/check_timing_impl_input.rpt
write_xdc -force $base/actual_impl_constraints.xdc
puts ACTUAL_COMPLETE_PROJECT_CONSTRAINT_HOOK_FINISHED
