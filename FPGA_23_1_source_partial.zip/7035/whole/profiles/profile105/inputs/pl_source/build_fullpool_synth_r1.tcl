set base [file dirname [file normalize [info script]]]
if {[version -short] ne "2023.1"} {error "This candidate requires Vivado 2023.1"}
set_param general.maxThreads 2
if {[file exists $base/project_fullpool_r1]} {error "Use a fresh run directory; candidate project already exists"}
create_project npu_hp0 $base/project_fullpool_r1 -part xc7z035ffg900-2
set_property SOURCE_MGMT_MODE None [current_project]
source $base/ps_existing.tcl
foreach name {M_AXI_GP0 S_AXI_HP0 S_AXI_HP0_FIFO_CTRL} {
    delete_bd_objs [get_bd_intf_ports $name]
}
foreach name {M_AXI_GP0_ACLK S_AXI_HP0_ACLK IRQ_F2P} {
    delete_bd_objs [get_bd_ports $name]
}
set ps [get_bd_cells processing_system7_0]
set trusted_clock [create_bd_port -dir I -type clk TRUSTED_CLK100]
set_property CONFIG.FREQ_HZ 100000000 $trusted_clock
set trusted_reset [create_bd_port -dir I -type rst TRUSTED_RESETN]
set_property CONFIG.POLARITY ACTIVE_LOW $trusted_reset
set_property -dict [list CONFIG.PCW_FPGA0_PERIPHERAL_FREQMHZ {100} CONFIG.PCW_FCLK0_PERIPHERAL_CLKSRC {IO PLL} CONFIG.PCW_USE_FABRIC_INTERRUPT {0} CONFIG.PCW_USE_S_AXI_HP1 {1}] $ps
set hp [create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect:1.0 hp_bridge]
set ctrl [create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect:1.0 ctrl_bridge]
foreach cell [list $hp $ctrl] {set_property -dict [list CONFIG.NUM_SI {1} CONFIG.NUM_MI {1}] $cell}
set npu [create_bd_intf_port -mode Slave -vlnv xilinx.com:interface:aximm_rtl:1.0 S_NPU_AXI]
set_property -dict [list CONFIG.PROTOCOL {AXI4} CONFIG.ADDR_WIDTH {32} CONFIG.DATA_WIDTH {256} CONFIG.ID_WIDTH {0} CONFIG.HAS_BURST {1} CONFIG.HAS_LOCK {0} CONFIG.HAS_CACHE {1} CONFIG.HAS_PROT {1} CONFIG.HAS_QOS {0} CONFIG.HAS_REGION {0} CONFIG.NUM_READ_OUTSTANDING {1} CONFIG.NUM_WRITE_OUTSTANDING {1} CONFIG.MAX_BURST_LENGTH {16} CONFIG.FREQ_HZ {100000000}] $npu
set ctl [create_bd_intf_port -mode Master -vlnv xilinx.com:interface:aximm_rtl:1.0 M_NPU_CTRL]
set_property -dict [list CONFIG.PROTOCOL {AXI4LITE} CONFIG.ADDR_WIDTH {32} CONFIG.DATA_WIDTH {32} CONFIG.FREQ_HZ {100000000}] $ctl
connect_bd_intf_net $npu [get_bd_intf_pins hp_bridge/S00_AXI]
connect_bd_intf_net [get_bd_intf_pins hp_bridge/M00_AXI] [get_bd_intf_pins processing_system7_0/S_AXI_HP0]
connect_bd_intf_net [get_bd_intf_pins processing_system7_0/M_AXI_GP0] [get_bd_intf_pins ctrl_bridge/S00_AXI]
connect_bd_intf_net [get_bd_intf_pins ctrl_bridge/M00_AXI] $ctl
connect_bd_net $trusted_clock [get_bd_pins hp_bridge/aclk] [get_bd_pins ctrl_bridge/aclk] [get_bd_pins processing_system7_0/S_AXI_HP0_ACLK] [get_bd_pins processing_system7_0/M_AXI_GP0_ACLK]
set rst [create_bd_cell -type ip -vlnv xilinx.com:ip:proc_sys_reset:5.0 reset_sync]
connect_bd_net $trusted_clock [get_bd_pins reset_sync/slowest_sync_clk]
set_property CONFIG.C_EXT_RESET_HIGH 0 $rst
connect_bd_net $trusted_reset [get_bd_pins reset_sync/ext_reset_in]
set one [create_bd_cell -type ip -vlnv xilinx.com:ip:xlconstant:1.1 constant_one]
set_property -dict [list CONFIG.CONST_WIDTH {1} CONFIG.CONST_VAL {1}] $one
connect_bd_net [get_bd_pins constant_one/dout] [get_bd_pins reset_sync/dcm_locked]
connect_bd_net [get_bd_pins reset_sync/interconnect_aresetn] [get_bd_pins hp_bridge/aresetn] [get_bd_pins ctrl_bridge/aresetn]
set reset_port [create_bd_port -dir O -type rst NPU_ARESETN]
set_property CONFIG.POLARITY ACTIVE_LOW $reset_port
connect_bd_net [get_bd_pins reset_sync/peripheral_aresetn] $reset_port
set actual_freq 100000000
# The unused exported PS clock still needs metadata matching its PS pin.
set_property CONFIG.FREQ_HZ [get_property CONFIG.FREQ_HZ [get_bd_pins processing_system7_0/FCLK_CLK0]] [get_bd_ports FCLK_CLK0]
puts "ACTUAL_CORE_FREQ_HZ=$actual_freq"
set f [open $base/actual_core_freq.txt w];puts $f $actual_freq;close $f
set_property CONFIG.FREQ_HZ $actual_freq [get_bd_intf_ports S_NPU_AXI]
set_property CONFIG.FREQ_HZ $actual_freq [get_bd_intf_ports M_NPU_CTRL]
set_property CONFIG.FREQ_HZ $actual_freq $trusted_clock
set_property CONFIG.ASSOCIATED_BUSIF {S_NPU_AXI:M_NPU_CTRL} $trusted_clock
set_property CONFIG.ASSOCIATED_RESET NPU_ARESETN $trusted_clock
assign_bd_address -offset 0x43C01000 -range 0x00001000 -target_address_space [get_bd_addr_spaces processing_system7_0/Data] [get_bd_addr_segs M_NPU_CTRL/Reg] -force
assign_bd_address -offset 0x00000000 -range 0x40000000 -target_address_space [get_bd_addr_spaces S_NPU_AXI] [get_bd_addr_segs processing_system7_0/S_AXI_HP0/HP0_DDR_LOWOCM] -force

# Independent display port; NPU ownership and control address stay unchanged.
set hdmi_hp [create_bd_cell -type ip -vlnv xilinx.com:ip:smartconnect:1.0 hdmi_hp_bridge]
set_property -dict [list CONFIG.NUM_SI {1} CONFIG.NUM_MI {1}] $hdmi_hp
set_property CONFIG.NUM_MI {5} $ctrl
set video [create_bd_intf_port -mode Slave -vlnv xilinx.com:interface:aximm_rtl:1.0 S_HDMI_AXI]
set_property -dict [list CONFIG.PROTOCOL {AXI4} CONFIG.ADDR_WIDTH {32} CONFIG.DATA_WIDTH {64} CONFIG.ID_WIDTH {0} CONFIG.HAS_BURST {1} CONFIG.HAS_LOCK {0} CONFIG.HAS_CACHE {1} CONFIG.HAS_PROT {1} CONFIG.HAS_QOS {0} CONFIG.HAS_REGION {0} CONFIG.NUM_READ_OUTSTANDING {1} CONFIG.NUM_WRITE_OUTSTANDING {1} CONFIG.MAX_BURST_LENGTH {256} CONFIG.FREQ_HZ $actual_freq] $video
set vidctl [create_bd_intf_port -mode Master -vlnv xilinx.com:interface:aximm_rtl:1.0 M_HDMI_CTRL]
set_property -dict [list CONFIG.PROTOCOL {AXI4LITE} CONFIG.ADDR_WIDTH {32} CONFIG.DATA_WIDTH {32} CONFIG.FREQ_HZ $actual_freq] $vidctl
connect_bd_intf_net $video [get_bd_intf_pins hdmi_hp_bridge/S00_AXI]
connect_bd_intf_net [get_bd_intf_pins hdmi_hp_bridge/M00_AXI] [get_bd_intf_pins processing_system7_0/S_AXI_HP1]
connect_bd_intf_net [get_bd_intf_pins ctrl_bridge/M01_AXI] $vidctl
connect_bd_net $trusted_clock [get_bd_pins hdmi_hp_bridge/aclk] [get_bd_pins processing_system7_0/S_AXI_HP1_ACLK]
connect_bd_net [get_bd_pins reset_sync/interconnect_aresetn] [get_bd_pins hdmi_hp_bridge/aresetn]
assign_bd_address -offset 0x43C02000 -range 0x00001000 -target_address_space [get_bd_addr_spaces processing_system7_0/Data] [get_bd_addr_segs M_HDMI_CTRL/Reg] -force
assign_bd_address -offset 0x00000000 -range 0x40000000 -target_address_space [get_bd_addr_spaces S_HDMI_AXI] [get_bd_addr_segs processing_system7_0/S_AXI_HP1/HP1_DDR_LOWOCM] -force
set_property CONFIG.ASSOCIATED_BUSIF {S_NPU_AXI:M_NPU_CTRL:S_HDMI_AXI:M_HDMI_CTRL} $trusted_clock

set audctl [create_bd_intf_port -mode Master -vlnv xilinx.com:interface:aximm_rtl:1.0 M_AUDIO_CTRL]
set_property -dict [list CONFIG.PROTOCOL {AXI4LITE} CONFIG.ADDR_WIDTH {32} CONFIG.DATA_WIDTH {32} CONFIG.FREQ_HZ $actual_freq] $audctl
connect_bd_intf_net [get_bd_intf_pins ctrl_bridge/M02_AXI] $audctl
assign_bd_address -offset 0x44000000 -range 0x00200000 -target_address_space [get_bd_addr_spaces processing_system7_0/Data] [get_bd_addr_segs M_AUDIO_CTRL/Reg] -force
set_property CONFIG.ASSOCIATED_BUSIF {S_NPU_AXI:M_NPU_CTRL:S_HDMI_AXI:M_HDMI_CTRL:M_AUDIO_CTRL} $trusted_clock
set ec [create_bd_port -dir I -type clk ETH_CLK125]
set_property -dict [list CONFIG.FREQ_HZ 125000000 CONFIG.ASSOCIATED_BUSIF M_ETH_CTRL CONFIG.ASSOCIATED_RESET ETH_ARESETN] $ec
set er [create_bd_port -dir I -type rst ETH_ARESETN];set_property CONFIG.POLARITY ACTIVE_LOW $er
set ethctl [create_bd_intf_port -mode Master -vlnv xilinx.com:interface:aximm_rtl:1.0 M_ETH_CTRL]
set_property -dict [list CONFIG.PROTOCOL {AXI4LITE} CONFIG.ADDR_WIDTH {32} CONFIG.DATA_WIDTH {32} CONFIG.FREQ_HZ 125000000] $ethctl
set ecdc [create_bd_cell -type ip -vlnv xilinx.com:ip:axi_clock_converter:2.1 eth_ctrl_cdc]
set_property -dict [list CONFIG.PROTOCOL AXI4LITE CONFIG.ADDR_WIDTH 32 CONFIG.DATA_WIDTH 32 CONFIG.ACLK_ASYNC 1] $ecdc
connect_bd_intf_net [get_bd_intf_pins ctrl_bridge/M03_AXI] [get_bd_intf_pins eth_ctrl_cdc/S_AXI]
connect_bd_intf_net [get_bd_intf_pins eth_ctrl_cdc/M_AXI] $ethctl
connect_bd_net $trusted_clock [get_bd_pins eth_ctrl_cdc/s_axi_aclk]
connect_bd_net [get_bd_pins reset_sync/peripheral_aresetn] [get_bd_pins eth_ctrl_cdc/s_axi_aresetn]
connect_bd_net $ec [get_bd_pins eth_ctrl_cdc/m_axi_aclk]
connect_bd_net $er [get_bd_pins eth_ctrl_cdc/m_axi_aresetn]
assign_bd_address -offset 0x43c03000 -range 0x00001000 -target_address_space [get_bd_addr_spaces processing_system7_0/Data] [get_bd_addr_segs M_ETH_CTRL/Reg] -force
# Singleton V2 feeder and actual SLH/cache run on the same trusted 100MHz clock.
set sc [create_bd_port -dir I -type clk SEC_CLK50]
set_property CONFIG.FREQ_HZ 100000000 $sc
set sr [create_bd_port -dir I -type rst SEC_RESETN]
set_property CONFIG.POLARITY ACTIVE_LOW $sr
set sec [create_bd_intf_port -mode Master -vlnv xilinx.com:interface:aximm_rtl:1.0 M_SLH_CTRL]
set_property -dict [list CONFIG.PROTOCOL AXI4LITE CONFIG.ADDR_WIDTH 32 CONFIG.DATA_WIDTH 32 CONFIG.FREQ_HZ 100000000] $sec
set_property CONFIG.ASSOCIATED_BUSIF M_SLH_CTRL $sc
set_property CONFIG.ASSOCIATED_RESET SEC_RESETN $sc
set cdc [create_bd_cell -type ip -vlnv xilinx.com:ip:axi_clock_converter:2.1 slh_ctrl_cdc]
set_property -dict [list CONFIG.PROTOCOL AXI4LITE CONFIG.ADDR_WIDTH 32 CONFIG.DATA_WIDTH 32 CONFIG.ACLK_ASYNC 1] $cdc
connect_bd_intf_net [get_bd_intf_pins ctrl_bridge/M04_AXI] [get_bd_intf_pins slh_ctrl_cdc/S_AXI]
connect_bd_intf_net [get_bd_intf_pins slh_ctrl_cdc/M_AXI] $sec
connect_bd_net $trusted_clock [get_bd_pins slh_ctrl_cdc/s_axi_aclk]
connect_bd_net [get_bd_pins reset_sync/peripheral_aresetn] [get_bd_pins slh_ctrl_cdc/s_axi_aresetn]
connect_bd_net $sc [get_bd_pins slh_ctrl_cdc/m_axi_aclk]
connect_bd_net $sr [get_bd_pins slh_ctrl_cdc/m_axi_aresetn]
assign_bd_address -offset 0x43C04000 -range 0x00001000 -target_address_space [get_bd_addr_spaces processing_system7_0/Data] [get_bd_addr_segs M_SLH_CTRL/Reg] -force

validate_bd_design
save_bd_design
generate_target all [get_files design_1.bd]
make_wrapper -files [get_files design_1.bd] -top
add_files -norecurse $base/project_fullpool_r1/npu_hp0.gen/sources_1/bd/design_1/hdl/design_1_wrapper.v


# Actual VIO zero-default IP; no key-valid tie or PS provisioning CSR.
source $base/provision/create_vio.tcl
create_ip_run [get_files -all */npu_trusted_provision_vio.xci]
launch_runs npu_trusted_provision_vio_synth_1 -jobs 1
wait_on_run npu_trusted_provision_vio_synth_1
if {[get_property PROGRESS [get_runs npu_trusted_provision_vio_synth_1]] ne "100%"} {error "Actual provision VIO synthesis failed"}
add_files -norecurse $base/npu_hp0_top.sv
add_files [glob $base/ethernet/rtl/*.sv]
add_files [glob $base/ethernet/vendor/*.v]
add_files [glob $base/transport/*.sv]
add_files [glob $base/display/hdmi/*.vhd]
foreach q [glob $base/display/hdmi_*.sv] {add_files -norecurse $q}
add_files -fileset constrs_1 $base/trusted_clock_root.xdc
set_property PROCESSING_ORDER EARLY [get_files *trusted_clock_root.xdc]
add_files -fileset constrs_1 $base/ethernet/7035.xdc
add_files -fileset constrs_1 $base/ethernet/ethernet_targeted_cdc.xdc
add_files -fileset constrs_1 $base/display/constraints/hdmi_j2_tx_candidate.xdc
add_files -fileset constrs_1 $base/display/constraints/hdmi_cdc.xdc
add_files -fileset constrs_1 $base/physical_constraints/nfr_cdc.xdc
foreach pat {*7035.xdc *ethernet_targeted_cdc.xdc *hdmi_cdc.xdc *nfr_cdc.xdc} {
 set ff [get_files $pat]
 set_property USED_IN_SYNTHESIS false $ff
 set_property PROCESSING_ORDER LATE $ff
}
set_property XPM_LIBRARIES {XPM_CDC XPM_MEMORY XPM_FIFO} [current_project]
set_property include_dirs [list $base $base/source_r6b/sources/physical/core $base/source_r6b/sources/physical/core/secure_gemm_v0 $base/source_r1/sources/integration/source/audio/rtl $base/source_r1/sources/integration/source/audio/rtl/audio $base/source_r1/sources/audio/compute_r1/rtl $base/source_r1/sources/audio_head/qualified_r1/vendor/HardFloat-1/source $base/source_r1/sources/audio_head/qualified_r1/vendor/HardFloat-1/source/RISCV $base/core $base/core/secure_gemm_v0 $base/support $base/audio/rtl $base/new_yolo/security_v2] [get_filesets sources_1]
set_property verilog_define {SLH_SHA256_UNROLL1 V801_LOAD_AUTH V876_FAST_LOAD_MAC V878_NORM2_RADIX16 V879_NORM3_RADIX16 V881_SOFTMAX_RADIX16 V882_GELU_RADIX16} [get_filesets sources_1]
set_property top npu_hp0_top [get_filesets sources_1]
set_property STEPS.SYNTH_DESIGN.ARGS.FLATTEN_HIERARCHY rebuilt [get_runs synth_1]
foreach q [glob $base/*.mem $base/*.hex $base/model/*.hex] {add_files -norecurse $q}
update_compile_order -fileset sources_1
set sd $base/project_fullpool_r1/npu_hp0.runs/synth_1
file mkdir $sd/model
foreach q [glob $base/*.mem $base/*.hex] {file copy -force $q $sd/}
foreach q [glob $base/model/*.hex] {file copy -force $q $sd/model/}
launch_runs synth_1 -jobs 1
wait_on_run synth_1
if {[get_property PROGRESS [get_runs synth_1]] ne "100%"} {error "Complete-system synthesis failed"}
open_run synth_1
source $base/physical_constraints/constrain_record_cdc.tcl
constrain_trusted_record_cdc u_outputs/tx_cdc 10.000 8.000
source $base/physical_constraints/constrain_pixel_fifo_cdc.tcl
constrain_trusted_pixel_fifo_cdc u_outputs/pixel_cdc
constrain_trusted_record_overlay u_outputs/overlay
report_utilization -hierarchical -file $base/utilization_synth_hier.rpt
report_utilization -file $base/utilization_synth.rpt
report_clocks -file $base/clocks_synth.rpt
write_checkpoint -force $base/npu_fullpool_synth.dcp
# Same-process early diagnostic only; saved synth DCP remains pre-diagnostic.
# These are synthesized estimates, never placed/routed qualification.
source $base/impl_constraint_hook_r3.tcl
report_timing_summary -delay_type min_max -max_paths 30 -check_timing_verbose -report_unconstrained -file $base/synth_timing_top30_NOT_ROUTE.rpt
report_timing -delay_type max -max_paths 30 -file $base/synth_setup_top30_NOT_ROUTE.rpt
report_timing -delay_type min -max_paths 30 -file $base/synth_hold_top30_NOT_ROUTE.rpt
puts ACTUAL_R5_SYNTH_TIMING_ESTIMATES_NOT_PLACED_OR_ROUTED
set f [open $base/SYNTH_ONLY_COMPLETE_NOT_QUALIFIED w]
puts $f "Complete actual system synthesized; numeric regression and route still separate. No bit generated."
close $f
close_project
exit
