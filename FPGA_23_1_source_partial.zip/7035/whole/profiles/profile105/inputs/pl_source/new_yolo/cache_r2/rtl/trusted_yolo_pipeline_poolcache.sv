`timescale 1ns/1ps
// Real signed201-layer scheduler/arithmetic -> real head/decode/candidate/NMS.
// One external SLH/private page cache and one external SM4 core are reused.
// AXI and MAC owners change ONLY after both engines and actual buses drain.
// Input RGB role0x4001 must be produced/tagged by the trusted letterbox owner.
// job_* comes from the bound frame coordinator, not a PS-controlled CSR.
// This parent ends at bound ROI; frontend294/315/ViT integration is separate.
module trusted_yolo_pipeline_poolcache #(
 parameter integer COMMAND_COUNT=58814,
 parameter [11:0] BANK_BASE=12'd2420,parameter integer A_WORDS=2548,
 parameter POLICY_ROM="model_object_policy_v2.mem",parameter ROLE_ROM="role_policy_201.hex",
 parameter LUT_FILE="decode_lut.hex"
)(
input wire  job_valid,
output wire  job_ready,
input wire [31:0] job_session,
input wire [31:0] job_frame,
input wire [31:0] job_epoch,
input wire [31:0] job_rgb_base,
input wire  authorized,
input wire [31:0] authorization_epoch,
input wire  job_cancel,
output wire  job_quiescent,
output wire  active,
output wire  job_done,
output wire  job_failed,
output wire [7:0] failure_code,
output wire [31:0] result_session,
output wire [31:0] result_frame,
output wire [31:0] result_epoch,
output wire [31:0] current_index,
output wire [15:0] read_transactions,
output wire [15:0] write_transactions,
input wire  clk,
input wire  rst_n,
output wire  a_write,
output wire  b_write,
output wire [11:0] bank_write_address,
output wire [255:0] bank_write_data,
output wire  a_read,
output wire  b_read,
output wire [11:0] a_read_address,
output wire [11:0] b_read_address,
input wire [255:0] a_read_data,
input wire [255:0] b_read_data,
output wire [31:0] M_AXI_ARADDR,
output wire [7:0] M_AXI_ARLEN,
output wire [2:0] M_AXI_ARSIZE,
output wire [1:0] M_AXI_ARBURST,
output wire  M_AXI_ARVALID,
input wire  M_AXI_ARREADY,
input wire [255:0] M_AXI_RDATA,
input wire [1:0] M_AXI_RRESP,
input wire  M_AXI_RLAST,
input wire  M_AXI_RVALID,
output wire  M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,
output wire [7:0] M_AXI_AWLEN,
output wire [2:0] M_AXI_AWSIZE,
output wire [1:0] M_AXI_AWBURST,
output wire  M_AXI_AWVALID,
input wire  M_AXI_AWREADY,
output wire [255:0] M_AXI_WDATA,
output wire [31:0] M_AXI_WSTRB,
output wire  M_AXI_WLAST,
output wire  M_AXI_WVALID,
input wire  M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,
input wire  M_AXI_BVALID,
output wire  M_AXI_BREADY,
output wire  exclusive_page_lock,
output wire  fetch_valid,
input wire  fetch_ready,
output wire [31:0] fetch_page_index,
output wire [31:0] fetch_page_address,
output wire [31:0] fetch_proof_address,
output wire  service_page_request,
input wire  service_page_ready,
output wire [31:0] service_expected_page,
input wire  service_page_done,
input wire  service_busy,
input wire  service_fault,
input wire  service_cache_valid,
input wire [31:0] service_cached_page,
output wire  service_cache_read,
output wire [9:0] service_cache_address,
input wire  service_cache_read_valid,
input wire [31:0] service_cache_read_data,
input wire key_valid,
output wire mac_request,
input wire mac_ready,
output wire [127:0] mac_chain,
output wire [255:0] mac_data,
input wire mac_response_valid,mac_response_error,
input wire [127:0] mac_tag,
input wire mac_quiescent,

output wire [2:0] selected_count,
output wire [895:0] selected_data,
output wire [51:0] selected_indices,
input wire [11:0] PS_AWADDR,input wire PS_AWVALID,output wire PS_AWREADY,
input wire [31:0] PS_WDATA,input wire [3:0] PS_WSTRB,input wire PS_WVALID,output wire PS_WREADY,
output wire [1:0] PS_BRESP,output wire PS_BVALID,input wire PS_BREADY,
output wire [31:0] blocked_ps_writes
);
wire [31:0] e_M_AXI_ARADDR;
wire [7:0] e_M_AXI_ARLEN;
wire [2:0] e_M_AXI_ARSIZE;
wire [1:0] e_M_AXI_ARBURST;
wire  e_M_AXI_ARVALID;
wire  e_M_AXI_ARREADY;
wire [255:0] e_M_AXI_RDATA;
wire [1:0] e_M_AXI_RRESP;
wire  e_M_AXI_RLAST;
wire  e_M_AXI_RVALID;
wire  e_M_AXI_RREADY;
wire [31:0] e_M_AXI_AWADDR;
wire [7:0] e_M_AXI_AWLEN;
wire [2:0] e_M_AXI_AWSIZE;
wire [1:0] e_M_AXI_AWBURST;
wire  e_M_AXI_AWVALID;
wire  e_M_AXI_AWREADY;
wire [255:0] e_M_AXI_WDATA;
wire [31:0] e_M_AXI_WSTRB;
wire  e_M_AXI_WLAST;
wire  e_M_AXI_WVALID;
wire  e_M_AXI_WREADY;
wire [1:0] e_M_AXI_BRESP;
wire  e_M_AXI_BVALID;
wire  e_M_AXI_BREADY;
wire  e_mac_request;
wire  e_mac_ready;
wire [127:0] e_mac_chain;
wire [255:0] e_mac_data;
wire  e_mac_response_valid;
wire  e_mac_response_error;
wire [127:0] e_mac_tag;
wire  e_mac_quiescent;
wire  e_job_ready;
wire  e_job_quiescent;
wire  e_active;
wire  e_job_done;
wire  e_job_failed;
wire [7:0] e_failure_code;
wire [31:0] e_result_session;
wire [31:0] e_result_frame;
wire [31:0] e_result_epoch;
wire [31:0] p_M_AXI_ARADDR;
wire [7:0] p_M_AXI_ARLEN;
wire [2:0] p_M_AXI_ARSIZE;
wire [1:0] p_M_AXI_ARBURST;
wire  p_M_AXI_ARVALID;
wire  p_M_AXI_ARREADY;
wire [255:0] p_M_AXI_RDATA;
wire [1:0] p_M_AXI_RRESP;
wire  p_M_AXI_RLAST;
wire  p_M_AXI_RVALID;
wire  p_M_AXI_RREADY;
wire [31:0] p_M_AXI_AWADDR;
wire [7:0] p_M_AXI_AWLEN;
wire [2:0] p_M_AXI_AWSIZE;
wire [1:0] p_M_AXI_AWBURST;
wire  p_M_AXI_AWVALID;
wire  p_M_AXI_AWREADY;
wire [255:0] p_M_AXI_WDATA;
wire [31:0] p_M_AXI_WSTRB;
wire  p_M_AXI_WLAST;
wire  p_M_AXI_WVALID;
wire  p_M_AXI_WREADY;
wire [1:0] p_M_AXI_BRESP;
wire  p_M_AXI_BVALID;
wire  p_M_AXI_BREADY;
wire  p_mac_request;
wire  p_mac_ready;
wire [127:0] p_mac_chain;
wire [255:0] p_mac_data;
wire  p_mac_response_valid;
wire  p_mac_response_error;
wire [127:0] p_mac_tag;
wire  p_mac_quiescent;

localparam IDLE=0,ENGINE_START=1,ENGINE_WAIT=2,POST_START=3,POST_WAIT=4,DRAIN=5,REPORT=6;
reg [2:0] state;reg owner_post,aborted,terminal_good,done_pulse,fail_pulse;
reg [31:0] bound_session,bound_frame,bound_epoch,bound_rgb;
reg [7:0] error_code;
wire post_ready,post_quiet,post_active,post_done,post_failed;
wire [31:0] post_session,post_frame,post_epoch;
wire [2:0] post_count;wire [895:0] post_data;wire [51:0] post_indices;
reg [2:0] final_count;reg [895:0] final_data;reg [51:0] final_indices;
wire live=authorized&&key_valid&&!job_cancel&&!aborted&&authorization_epoch==bound_epoch;
wire stop_children=job_cancel||aborted||(state!=IDLE&&(!authorized||authorization_epoch!=bound_epoch));
wire control_quiet;
wire all_quiet=e_job_quiescent&&post_quiet&&mac_quiescent;
assign job_ready=state==IDLE&&all_quiet&&control_quiet&&authorized&&!job_cancel&&key_valid;
assign job_quiescent=state==IDLE&&all_quiet;
assign active=state!=IDLE;assign job_done=done_pulse;assign job_failed=fail_pulse;
assign result_session=bound_session;assign result_frame=bound_frame;assign result_epoch=bound_epoch;
assign failure_code=error_code;
assign selected_count=final_count;assign selected_data=final_data;assign selected_indices=final_indices;
// This is the actual PS write ingress, permanently closed in production.
// There is no raw command, descriptor or software completion bypass below it.
trusted_npu_control_gate #(.ADDR_WIDTH(12),.ALLOW_LEGACY_WRITES(0)) ps_gate(
 .clk(clk),.rst_n(rst_n),.configuration_locked(1'b1),
 .S_AWADDR(PS_AWADDR),.S_AWVALID(PS_AWVALID),.S_AWREADY(PS_AWREADY),
 .S_WDATA(PS_WDATA),.S_WSTRB(PS_WSTRB),.S_WVALID(PS_WVALID),.S_WREADY(PS_WREADY),
 .S_BRESP(PS_BRESP),.S_BVALID(PS_BVALID),.S_BREADY(PS_BREADY),
 .M_AWADDR(),.M_AWVALID(),.M_AWREADY(1'b0),.M_WDATA(),.M_WSTRB(),.M_WVALID(),.M_WREADY(1'b0),
 .M_BRESP(2'd2),.M_BVALID(1'b0),.M_BREADY(),.control_quiescent(control_quiet),.blocked_writes(blocked_ps_writes));
assign M_AXI_ARADDR=owner_post?p_M_AXI_ARADDR:e_M_AXI_ARADDR;
assign M_AXI_ARLEN=owner_post?p_M_AXI_ARLEN:e_M_AXI_ARLEN;
assign M_AXI_ARSIZE=owner_post?p_M_AXI_ARSIZE:e_M_AXI_ARSIZE;
assign M_AXI_ARBURST=owner_post?p_M_AXI_ARBURST:e_M_AXI_ARBURST;
assign M_AXI_ARVALID=owner_post?p_M_AXI_ARVALID:e_M_AXI_ARVALID;
assign e_M_AXI_ARREADY=!owner_post&&M_AXI_ARREADY;assign p_M_AXI_ARREADY=owner_post&&M_AXI_ARREADY;
assign e_M_AXI_RDATA=M_AXI_RDATA;assign p_M_AXI_RDATA=M_AXI_RDATA;
assign e_M_AXI_RRESP=M_AXI_RRESP;assign p_M_AXI_RRESP=M_AXI_RRESP;
assign e_M_AXI_RLAST=M_AXI_RLAST;assign p_M_AXI_RLAST=M_AXI_RLAST;
assign e_M_AXI_RVALID=!owner_post&&M_AXI_RVALID;assign p_M_AXI_RVALID=owner_post&&M_AXI_RVALID;
assign M_AXI_RREADY=owner_post?p_M_AXI_RREADY:e_M_AXI_RREADY;
assign M_AXI_AWADDR=owner_post?p_M_AXI_AWADDR:e_M_AXI_AWADDR;
assign M_AXI_AWLEN=owner_post?p_M_AXI_AWLEN:e_M_AXI_AWLEN;
assign M_AXI_AWSIZE=owner_post?p_M_AXI_AWSIZE:e_M_AXI_AWSIZE;
assign M_AXI_AWBURST=owner_post?p_M_AXI_AWBURST:e_M_AXI_AWBURST;
assign M_AXI_AWVALID=owner_post?p_M_AXI_AWVALID:e_M_AXI_AWVALID;
assign e_M_AXI_AWREADY=!owner_post&&M_AXI_AWREADY;assign p_M_AXI_AWREADY=owner_post&&M_AXI_AWREADY;
assign M_AXI_WDATA=owner_post?p_M_AXI_WDATA:e_M_AXI_WDATA;
assign M_AXI_WSTRB=owner_post?p_M_AXI_WSTRB:e_M_AXI_WSTRB;
assign M_AXI_WLAST=owner_post?p_M_AXI_WLAST:e_M_AXI_WLAST;
assign M_AXI_WVALID=owner_post?p_M_AXI_WVALID:e_M_AXI_WVALID;
assign e_M_AXI_WREADY=!owner_post&&M_AXI_WREADY;assign p_M_AXI_WREADY=owner_post&&M_AXI_WREADY;
assign e_M_AXI_BRESP=M_AXI_BRESP;assign p_M_AXI_BRESP=M_AXI_BRESP;
assign e_M_AXI_BVALID=!owner_post&&M_AXI_BVALID;assign p_M_AXI_BVALID=owner_post&&M_AXI_BVALID;
assign M_AXI_BREADY=owner_post?p_M_AXI_BREADY:e_M_AXI_BREADY;
assign mac_request=owner_post?p_mac_request:e_mac_request;
assign e_mac_ready=!owner_post&&mac_ready;assign p_mac_ready=owner_post&&mac_ready;
assign mac_chain=owner_post?p_mac_chain:e_mac_chain;
assign mac_data=owner_post?p_mac_data:e_mac_data;
assign e_mac_response_valid=!owner_post&&mac_response_valid;assign p_mac_response_valid=owner_post&&mac_response_valid;
assign e_mac_response_error=mac_response_error;assign p_mac_response_error=mac_response_error;
assign e_mac_tag=mac_tag;assign p_mac_tag=mac_tag;
assign e_mac_quiescent=mac_quiescent;assign p_mac_quiescent=mac_quiescent;
trusted_yolo_secure_engine_poolcache #(.COMMAND_COUNT(COMMAND_COUNT),.BANK_BASE(BANK_BASE),.A_WORDS(A_WORDS),.POLICY_ROM(POLICY_ROM),.ROLE_ROM(ROLE_ROM)) engine(
 .job_valid(state==ENGINE_START&&live),
 .job_ready(e_job_ready),
 .job_session(bound_session),
 .job_frame(bound_frame),
 .job_epoch(bound_epoch),
 .job_rgb_base(bound_rgb),
 .authorized(authorized),
 .authorization_epoch(authorization_epoch),
 .job_cancel(stop_children),
 .job_quiescent(e_job_quiescent),
 .active(e_active),
 .job_done(e_job_done),
 .job_failed(e_job_failed),
 .failure_code(e_failure_code),
 .result_session(e_result_session),
 .result_frame(e_result_frame),
 .result_epoch(e_result_epoch),
 .current_index(current_index),
 .read_transactions(read_transactions),
 .write_transactions(write_transactions),
 .clk(clk),
 .rst_n(rst_n),
 .a_write(a_write),
 .b_write(b_write),
 .bank_write_address(bank_write_address),
 .bank_write_data(bank_write_data),
 .a_read(a_read),
 .b_read(b_read),
 .a_read_address(a_read_address),
 .b_read_address(b_read_address),
 .a_read_data(a_read_data),
 .b_read_data(b_read_data),
 .M_AXI_ARADDR(e_M_AXI_ARADDR),
 .M_AXI_ARLEN(e_M_AXI_ARLEN),
 .M_AXI_ARSIZE(e_M_AXI_ARSIZE),
 .M_AXI_ARBURST(e_M_AXI_ARBURST),
 .M_AXI_ARVALID(e_M_AXI_ARVALID),
 .M_AXI_ARREADY(e_M_AXI_ARREADY),
 .M_AXI_RDATA(e_M_AXI_RDATA),
 .M_AXI_RRESP(e_M_AXI_RRESP),
 .M_AXI_RLAST(e_M_AXI_RLAST),
 .M_AXI_RVALID(e_M_AXI_RVALID),
 .M_AXI_RREADY(e_M_AXI_RREADY),
 .M_AXI_AWADDR(e_M_AXI_AWADDR),
 .M_AXI_AWLEN(e_M_AXI_AWLEN),
 .M_AXI_AWSIZE(e_M_AXI_AWSIZE),
 .M_AXI_AWBURST(e_M_AXI_AWBURST),
 .M_AXI_AWVALID(e_M_AXI_AWVALID),
 .M_AXI_AWREADY(e_M_AXI_AWREADY),
 .M_AXI_WDATA(e_M_AXI_WDATA),
 .M_AXI_WSTRB(e_M_AXI_WSTRB),
 .M_AXI_WLAST(e_M_AXI_WLAST),
 .M_AXI_WVALID(e_M_AXI_WVALID),
 .M_AXI_WREADY(e_M_AXI_WREADY),
 .M_AXI_BRESP(e_M_AXI_BRESP),
 .M_AXI_BVALID(e_M_AXI_BVALID),
 .M_AXI_BREADY(e_M_AXI_BREADY),
 .exclusive_page_lock(exclusive_page_lock),
 .fetch_valid(fetch_valid),
 .fetch_ready(fetch_ready),
 .fetch_page_index(fetch_page_index),
 .fetch_page_address(fetch_page_address),
 .fetch_proof_address(fetch_proof_address),
 .service_page_request(service_page_request),
 .service_page_ready(service_page_ready),
 .service_expected_page(service_expected_page),
 .service_page_done(service_page_done),
 .service_busy(service_busy),
 .service_fault(service_fault),
 .service_cache_valid(service_cache_valid),
 .service_cached_page(service_cached_page),
 .service_cache_read(service_cache_read),
 .service_cache_address(service_cache_address),
 .service_cache_read_valid(service_cache_read_valid),
 .service_cache_read_data(service_cache_read_data),
 .key_valid(key_valid),
 .mac_request(e_mac_request),
 .mac_ready(e_mac_ready),
 .mac_chain(e_mac_chain),
 .mac_data(e_mac_data),
 .mac_response_valid(e_mac_response_valid),
 .mac_response_error(e_mac_response_error),
 .mac_tag(e_mac_tag),
 .mac_quiescent(e_mac_quiescent)
);

wire beat_request,beat_ready,beat_write,beat_response_valid,beat_verified,guard_quiet,raw_quiet,guard_error,guard_live;
wire [31:0] beat_address,beat_mask,beat_session,beat_frame,beat_epoch;
wire [15:0] beat_role,beat_shape;wire [255:0] beat_data,beat_response_data;
trusted_yolo_postprocessor #(.LUT_FILE(LUT_FILE)) post(
 .clk(clk),.rst_n(rst_n),.cancel(stop_children),.authorized(authorized),.authorization_epoch(authorization_epoch),
 .job_valid(state==POST_START&&live),.job_ready(post_ready),.job_session(bound_session),.job_frame(bound_frame),.job_epoch(bound_epoch),
 .quiescent(post_quiet),.active(post_active),.done(post_done),.failed(post_failed),
 .result_session(post_session),.result_frame(post_frame),.result_epoch(post_epoch),
 .selected_count(post_count),.selected_data(post_data),.selected_indices(post_indices),
 .beat_request(beat_request),.beat_ready(beat_ready),.beat_write(beat_write),.beat_address(beat_address),.beat_mask(beat_mask),
 .beat_session(beat_session),.beat_frame(beat_frame),.beat_epoch(beat_epoch),.beat_role(beat_role),.beat_shape(beat_shape),.beat_data(beat_data),
 .beat_response_valid(beat_response_valid),.beat_verified(beat_verified),.beat_response_data(beat_response_data),.backend_quiescent(guard_quiet));
wire memory_read_valid,memory_read_ready,memory_write_valid,memory_write_ready;
wire [31:0] memory_data_address,memory_tag_address,memory_write_mask,memory_response_mask;
wire [255:0] memory_write_data,memory_response_data;wire [127:0] memory_write_tag,memory_response_tag;
wire memory_response_valid,memory_response_error;
assign beat_verified=!guard_error&&guard_live;
trusted_yolo_tensor_beat_guard post_guard(
 .clk(clk),.rst_n(rst_n),.cancel(stop_children),.authorized(authorized),.key_valid(key_valid),.authorization_epoch(authorization_epoch),
 .request_valid(beat_request),.request_ready(beat_ready),.request_write(beat_write),
 .request_session(beat_session),.request_frame(beat_frame),.request_epoch(beat_epoch),.request_version(32'd2),
 .request_role(beat_role),.request_shape(beat_shape),.request_address(beat_address),.request_tensor_mask(beat_mask),
 .request_strobe(beat_write?32'hffffffff:32'd0),.request_data(beat_data),
 .response_valid(beat_response_valid),.response_ready(1'b1),.response_error(guard_error),.context_live(guard_live),
 .response_data(beat_response_data),.quiescent(guard_quiet),
 .memory_read_valid(memory_read_valid),.memory_read_ready(memory_read_ready),.memory_write_valid(memory_write_valid),.memory_write_ready(memory_write_ready),
 .memory_data_address(memory_data_address),.memory_tag_address(memory_tag_address),.memory_write_data(memory_write_data),
 .memory_write_tag(memory_write_tag),.memory_write_mask(memory_write_mask),.memory_response_valid(memory_response_valid),
 .memory_response_error(memory_response_error),.memory_response_data(memory_response_data),.memory_response_tag(memory_response_tag),
 .memory_response_mask(memory_response_mask),.backend_quiescent(raw_quiet),
 .mac_request(p_mac_request),.mac_ready(p_mac_ready),.mac_chain(p_mac_chain),.mac_data(p_mac_data),
 .mac_response_valid(p_mac_response_valid),.mac_response_error(p_mac_response_error),.mac_tag(p_mac_tag),.mac_quiescent(p_mac_quiescent));
trusted_tensor_axi_backend post_raw(
 .clk(clk),.rst_n(rst_n),.read_valid(memory_read_valid),.read_ready(memory_read_ready),.write_valid(memory_write_valid),.write_ready(memory_write_ready),
 .data_address(memory_data_address),.tag_address(memory_tag_address),.write_data(memory_write_data),.write_tag(memory_write_tag),.write_mask(memory_write_mask),
 .response_valid(memory_response_valid),.response_error(memory_response_error),.response_data(memory_response_data),
 .response_tag(memory_response_tag),.response_mask(memory_response_mask),.quiescent(raw_quiet),
 .M_AXI_ARADDR(p_M_AXI_ARADDR),
 .M_AXI_ARLEN(p_M_AXI_ARLEN),
 .M_AXI_ARSIZE(p_M_AXI_ARSIZE),
 .M_AXI_ARBURST(p_M_AXI_ARBURST),
 .M_AXI_ARVALID(p_M_AXI_ARVALID),
 .M_AXI_ARREADY(p_M_AXI_ARREADY),
 .M_AXI_RDATA(p_M_AXI_RDATA),
 .M_AXI_RRESP(p_M_AXI_RRESP),
 .M_AXI_RLAST(p_M_AXI_RLAST),
 .M_AXI_RVALID(p_M_AXI_RVALID),
 .M_AXI_RREADY(p_M_AXI_RREADY),
 .M_AXI_AWADDR(p_M_AXI_AWADDR),
 .M_AXI_AWLEN(p_M_AXI_AWLEN),
 .M_AXI_AWSIZE(p_M_AXI_AWSIZE),
 .M_AXI_AWBURST(p_M_AXI_AWBURST),
 .M_AXI_AWVALID(p_M_AXI_AWVALID),
 .M_AXI_AWREADY(p_M_AXI_AWREADY),
 .M_AXI_WDATA(p_M_AXI_WDATA),
 .M_AXI_WSTRB(p_M_AXI_WSTRB),
 .M_AXI_WLAST(p_M_AXI_WLAST),
 .M_AXI_WVALID(p_M_AXI_WVALID),
 .M_AXI_WREADY(p_M_AXI_WREADY),
 .M_AXI_BRESP(p_M_AXI_BRESP),
 .M_AXI_BVALID(p_M_AXI_BVALID),
 .M_AXI_BREADY(p_M_AXI_BREADY)
);

always @(posedge clk)begin
 if(!rst_n)begin
  state<=IDLE;owner_post<=0;aborted<=0;terminal_good<=0;done_pulse<=0;fail_pulse<=0;
  bound_session<=0;bound_frame<=0;bound_epoch<=0;bound_rgb<=0;error_code<=0;
  final_count<=0;final_data<=0;final_indices<=0;
 end else begin
  done_pulse<=0;fail_pulse<=0;
  if(state!=IDLE&&(job_cancel||!authorized||authorization_epoch!=bound_epoch||!key_valid))aborted<=1;
  case(state)
   IDLE:if(job_valid&&job_ready)begin
    bound_session<=job_session;bound_frame<=job_frame;bound_epoch<=job_epoch;bound_rgb<=job_rgb_base;
    final_count<=0;final_data<=0;final_indices<=0;owner_post<=0;aborted<=0;terminal_good<=0;error_code<=0;
    if(job_session==0||job_frame==0||job_epoch!=authorization_epoch||job_rgb_base!=32'h22000000||
       (bound_session==job_session&&bound_epoch==job_epoch&&job_frame<=bound_frame))begin aborted<=1;error_code<=8'h80;state<=DRAIN;end
    else state<=ENGINE_START;
   end
   ENGINE_START:if(!live)state<=DRAIN;else if(e_job_ready)state<=ENGINE_WAIT;
   ENGINE_WAIT:if(e_job_done||e_job_failed)begin
    if(e_job_failed||!live||e_result_session!=bound_session||e_result_frame!=bound_frame||e_result_epoch!=bound_epoch)begin error_code<=e_failure_code;state<=DRAIN;end
    else if(all_quiet)begin owner_post<=1;state<=POST_START;end
   end
   POST_START:if(!live)state<=DRAIN;else if(post_ready)state<=POST_WAIT;
   POST_WAIT:if(post_done||post_failed)begin
    terminal_good<=post_done&&!post_failed&&live&&post_session==bound_session&&post_frame==bound_frame&&post_epoch==bound_epoch;
    if(post_done&&!post_failed&&live)begin final_count<=post_count;final_data<=post_data;final_indices<=post_indices;end
    else error_code<=8'h81;
    state<=DRAIN;
   end
   DRAIN:if(all_quiet)state<=REPORT;
   REPORT:begin
    done_pulse<=terminal_good&&live;fail_pulse<=!terminal_good||!live;
    if(!terminal_good||!live)begin final_count<=0;final_data<=0;final_indices<=0;end
    state<=IDLE;
   end
   default:begin aborted<=1;terminal_good<=0;error_code<=8'hff;state<=DRAIN;end
  endcase
 end
end
endmodule
