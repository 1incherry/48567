`timescale 1ns/1ps
// One aligned four-byte capture per cycle; synchronous byte reads unchanged.
module slh_message_word_sram32_wordfeed #(
 parameter integer DEPTH_BYTES=8447,
 parameter integer ABITS=DEPTH_BYTES>1?$clog2(DEPTH_BYTES):1
)(
 input wire clk,write_enable,read_enable,
 input wire [ABITS-1:0] write_address,read_address,
 input wire [31:0] write_data,input wire [2:0] write_bytes,
 output wire [7:0] read_data,output wire [31:0] read_word_data
);
 localparam integer WORDS=(DEPTH_BYTES+3)/4;
 localparam integer FULL=WORDS/512,TAIL=WORDS%512;
 localparam integer TAIL_SIZE=TAIL==0?0:TAIL<=64?64:TAIL<=128?128:TAIL<=256?256:512;
 localparam integer BANKS=FULL+(TAIL!=0);
 localparam integer BBITS=BANKS>1?$clog2(BANKS):1;
 localparam integer WBITS=WORDS>1?$clog2(WORDS):1;
 localparam integer PHYSICAL_BITS=(FULL*512+TAIL_SIZE)*32;
 wire [WBITS-1:0] write_word=write_address>>2,read_word=read_address>>2;
 reg [31:0] padded;
 always @* begin
  case(write_bytes)
   1:padded={write_data[31:24],24'd0};
   2:padded={write_data[31:16],16'd0};
   3:padded={write_data[31:8],8'd0};
   4:padded=write_data;
   default:padded=32'd0;
  endcase
 end
 reg [BBITS-1:0] read_bank;reg [1:0] read_lane;reg read_in_bounds;
 always @(posedge clk)if(read_enable)begin
  read_bank<=read_word/512;read_lane<=read_address[1:0];read_in_bounds<=read_address<DEPTH_BYTES;
 end
 wire [31:0] words[0:BANKS-1];
 for(genvar b=0;b<BANKS;b=b+1)begin:physical_banks
  localparam integer SIZE=b<FULL?512:TAIL_SIZE;
  localparam integer LBITS=$clog2(SIZE);
  wire wen=write_enable && write_address<DEPTH_BYTES && write_word/512==b;
  wire ren=read_enable && read_address<DEPTH_BYTES && read_word/512==b;
  wire [LBITS-1:0] address=wen?write_word:read_word;
  if(SIZE==512)begin:word512
   SRAM1RW512x32 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(padded),.O(words[b]));
  end else if(SIZE==256)begin:word256
   SRAM1RW256x32 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(padded),.O(words[b]));
  end else if(SIZE==128)begin:word128
   SRAM1RW128x32 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(padded),.O(words[b]));
  end else if(SIZE==64)begin:word64
   SRAM1RW64x32 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(padded),.O(words[b]));
  end
 end
 reg [31:0] selected;
 always @* begin
  selected=32'hxxxxxxxx;
  for(integer b=0;b<BANKS;b=b+1)if(read_bank==b)selected=words[b];
 end
 assign read_data=read_in_bounds?selected[31-read_lane*8-:8]:8'hxx;
 assign read_word_data=read_in_bounds?selected:32'hxxxxxxxx;
 // synopsys translate_off
 initial if(DEPTH_BYTES<1)$fatal(1,"MESSAGE32_BAD_GEOMETRY");
 integer writes=0,reads=0;
 always @(posedge clk)begin
  if(write_enable&&read_enable)$fatal(1,"MESSAGE32_SINGLE_PORT_COLLISION");
  if(write_enable)begin
   if(write_address[1:0]!=0||write_bytes<1||write_bytes>4||
      write_address+write_bytes>DEPTH_BYTES)$fatal(1,"MESSAGE32_BAD_WRITE_RANGE");
   writes=writes+1;
  end
  if(read_enable)reads=reads+1;
 end
 final $display("MESSAGE32_SRAM_ACCESS depth=%0d logical_words=%0d banks=%0d bits=%0d writes=%0d reads=%0d",
  DEPTH_BYTES,WORDS,BANKS,PHYSICAL_BITS,writes,reads);
 // synopsys translate_on
endmodule
