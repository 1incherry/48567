// FPGA synchronous 1RW implementations. Original SRAM ports/read latency retained.
module SRAM1RW64x32(input CE,input [5:0] A,input WEB,CSB,OEB,input [31:0] I,output [31:0] O);
 (* ram_style="block" *) reg [31:0] mem[0:63];
 reg [31:0] read_data;
 always @(posedge CE)if(!CSB)begin if(!WEB)mem[A]<=I;else read_data<=mem[A];end
 assign O=OEB?{32{1'bz}}:read_data;
endmodule
module SRAM1RW128x32(input CE,input [6:0] A,input WEB,CSB,OEB,input [31:0] I,output [31:0] O);
 (* ram_style="block" *) reg [31:0] mem[0:127];
 reg [31:0] read_data;
 always @(posedge CE)if(!CSB)begin if(!WEB)mem[A]<=I;else read_data<=mem[A];end
 assign O=OEB?{32{1'bz}}:read_data;
endmodule
module SRAM1RW256x32(input CE,input [7:0] A,input WEB,CSB,OEB,input [31:0] I,output [31:0] O);
 (* ram_style="block" *) reg [31:0] mem[0:255];
 reg [31:0] read_data;
 always @(posedge CE)if(!CSB)begin if(!WEB)mem[A]<=I;else read_data<=mem[A];end
 assign O=OEB?{32{1'bz}}:read_data;
endmodule
module SRAM1RW256x128(input CE,input [7:0] A,input WEB,CSB,OEB,input [127:0] I,output [127:0] O);
 (* ram_style="block" *) reg [127:0] mem[0:255];
 reg [127:0] read_data;
 always @(posedge CE)if(!CSB)begin if(!WEB)mem[A]<=I;else read_data<=mem[A];end
 assign O=OEB?{128{1'bz}}:read_data;
endmodule
module SRAM1RW512x8(input CE,input [8:0] A,input WEB,CSB,OEB,input [7:0] I,output [7:0] O);
 (* ram_style="block" *) reg [7:0] mem[0:511];
 reg [7:0] read_data;
 always @(posedge CE)if(!CSB)begin if(!WEB)mem[A]<=I;else read_data<=mem[A];end
 assign O=OEB?{8{1'bz}}:read_data;
endmodule
module SRAM1RW512x32(input CE,input [8:0] A,input WEB,CSB,OEB,input [31:0] I,output [31:0] O);
 (* ram_style="block" *) reg [31:0] mem[0:511];
 reg [31:0] read_data;
 always @(posedge CE)if(!CSB)begin if(!WEB)mem[A]<=I;else read_data<=mem[A];end
 assign O=OEB?{32{1'bz}}:read_data;
endmodule
