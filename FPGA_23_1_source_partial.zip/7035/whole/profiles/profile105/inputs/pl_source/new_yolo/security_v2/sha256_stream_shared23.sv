`timescale 1ns/1ps
// Local Merkle SHA controller. All64 rounds use3 rounds/cycle. The producer's
// complete block goes directly into the compressor on the block handshake;
// the next block may start on the previous comp_done edge. No extra SHA engine.
module sha256_stream_shared23 #(parameter integer EXTERNAL_COMPRESSOR=0) (
 input logic clk,rst_n,start,
 input logic initial_state_valid,input logic [255:0] initial_state,input logic [6:0] initial_bytes,
 output logic prefix_done,output logic [255:0] prefix_state,
 input logic block_valid,input logic [511:0] block_data,input logic [6:0] block_bytes,input logic block_last,
 output wire block_ready,output logic busy,done,fault,output logic [255:0] digest,
  output wire compressor_reset,compressor_start,
  output wire [511:0] compressor_block,output wire [255:0] compressor_iv,
  input wire compressor_busy,compressor_done,input wire [255:0] compressor_state
);
  // Binary synthesis with exact original four-state simulation guards.
  function automatic slh_known_true(input logic value);
    case (value)
      1'b1: slh_known_true=1'b1;
      default: slh_known_true=1'b0;
    endcase
  endfunction
  function automatic slh_known_false(input logic value);
    case (value)
      1'b0: slh_known_false=1'b1;
      default: slh_known_false=1'b0;
    endcase
  endfunction
  function automatic slh_not_x(input logic value);
    case (value)
      // synopsys translate_off
      1'bx: slh_not_x=1'b0;
      // synopsys translate_on
      default: slh_not_x=1'b1;
    endcase
  endfunction
  function automatic slh_case_eq_bit(input logic left_value, right_value);
    case ({left_value,right_value})
      2'b00,2'b11: slh_case_eq_bit=1'b1;
      // synopsys translate_off
      2'bxx,2'bzz: slh_case_eq_bit=1'b1;
      // synopsys translate_on
      default: slh_case_eq_bit=1'b0;
    endcase
  endfunction
  function automatic slh_case_eq_256(input logic [255:0] left_value, right_value);
    case (left_value)
      right_value: slh_case_eq_256=1'b1;
      default: slh_case_eq_256=1'b0;
    endcase
  endfunction

 localparam logic [255:0] IV=256'h6a09e667bb67ae853c6ef372a54ff53a510e527f9b05688c1f83d9ab5be0cd19;
 logic [255:0] chain_state;
 logic [63:0] total_bytes,final_bit_length;
 logic inflight,transaction_last,pending_pad,pad_marker;
 wire comp_busy,comp_done;wire [255:0] comp_state;
 wire complete=inflight&&comp_done;
 assign block_ready=busy && !transaction_last && (!inflight || comp_done);
 wire accepted=block_valid&&block_ready;
 wire legal=slh_known_true((block_bytes<=64 && (block_last || block_bytes==64) &&
             (slh_known_false(block_last) || slh_known_true(block_last))));
 wire issue_padding=busy && pending_pad && complete;
 wire comp_start=(accepted && legal) || issue_padding;
 wire [63:0] new_total=total_bytes+{57'd0,block_bytes};
 wire [255:0] comp_iv=complete?comp_state:chain_state;
 function automatic [511:0] padded(input [511:0] raw,input [6:0] count,input [63:0] bits);
  reg [511:0] result;
  begin
   result=0;
   // Constant byte slices avoid a variable indexed 512-bit marker write.
   for(integer j=0;j<64;j++)begin
    if(j<count)result[511-j*8-:8]=raw[511-j*8-:8];
    else if(j==count)result[511-j*8-:8]=8'h80;
   end
   if(count<=55)result[63:0]=bits;
   padded=result;
  end
 endfunction
 wire [511:0] comp_block=issue_padding?{pad_marker?8'h80:8'h00,440'd0,final_bit_length}:
                        (!block_last || block_bytes==64)?block_data:padded(block_data,block_bytes,new_total<<3);
  assign compressor_reset=rst_n;
  assign compressor_start=comp_start;assign compressor_block=comp_block;assign compressor_iv=comp_iv;
  generate if(EXTERNAL_COMPRESSOR)begin:external_compression
    assign comp_busy=compressor_busy;assign comp_done=compressor_done;assign comp_state=compressor_state;
  end else begin:internal_compression

 sha256_compress3_csa u_comp(.clk(clk),.rst_n(rst_n),.start(comp_start),.block(comp_block),.iv(comp_iv),
                       .busy(comp_busy),.done(comp_done),.state_out(comp_state));
  end endgenerate
 always_ff @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin
   busy<=0;done<=0;fault<=0;digest<=0;prefix_done<=0;prefix_state<=0;
   chain_state<=IV;total_bytes<=0;final_bit_length<=0;
   inflight<=0;transaction_last<=0;pending_pad<=0;pad_marker<=0;
  end else begin
   done<=0;prefix_done<=0;
   if(!busy)begin
    if(start)begin
     busy<=1;fault<=0;chain_state<=initial_state_valid?initial_state:IV;
     total_bytes<=initial_state_valid?{57'd0,initial_bytes}:64'd0;
     inflight<=0;transaction_last<=0;pending_pad<=0;pad_marker<=0;
    end
   end else begin
    if(complete)begin
     chain_state<=comp_state;inflight<=0;
     if(!transaction_last && total_bytes==64)begin prefix_done<=1;prefix_state<=comp_state;end
     if(transaction_last && !pending_pad)begin digest<=comp_state;done<=1;busy<=0;end
    end
    if(issue_padding)begin pending_pad<=0;inflight<=1;end
    if(accepted)begin
     if(!legal)begin fault<=1;done<=1;busy<=0;inflight<=0;pending_pad<=0;end
     else begin
      total_bytes<=new_total;final_bit_length<=new_total<<3;inflight<=1;
      transaction_last<=block_last;pending_pad<=block_last && block_bytes>=56;pad_marker<=block_bytes==64;
     end
    end
   end
  end
 end
endmodule
