`timescale 1ns/1ps
// 50MHz raw byte feeder only. AXI PS writes NEVER supply authority/page verdicts.
module npu_model_feed_axil_v2 #(parameter PROOF_WORDS=112)(
 input wire clk,rst_n,trusted_cancel,
 input wire [11:0] s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire [31:0] s_wdata,input wire [3:0] s_wstrb,input wire s_wvalid,output wire s_wready,
 output reg [1:0] s_bresp,output reg s_bvalid,input wire s_bready,
 input wire [11:0] s_araddr,input wire s_arvalid,output wire s_arready,
 output reg [31:0] s_rdata,output reg [1:0] s_rresp,output reg s_rvalid,input wire s_rready,
 input wire trusted_page_accept,input wire [31:0] trusted_page_index,
 input wire svc_manifest_ready,svc_manifest_done,svc_page_done,svc_busy,svc_fault,
 input wire svc_model_authorized,svc_cache_valid,
 input wire [31:0] svc_epoch,svc_cached_page_index,
 input wire [7:0] svc_signature_error,svc_policy_error,svc_page_error,
 output reg svc_manifest_start,svc_cancel,
 output reg msg_valid,output reg [31:0] msg_data,output reg msg_last,input wire msg_ready,
 output reg sig_valid,output reg [31:0] sig_data,output reg sig_last,input wire sig_ready,
 output reg page_valid,output reg [31:0] page_data,input wire page_ready,
 output reg proof_valid,output reg [31:0] proof_data,input wire proof_ready,
 output reg [7:0] feeder_error
);
 localparam [7:0] E_PROTOCOL=8'h01,E_STATE=8'h02,E_EXTRA=8'h03,E_CANCEL=8'h10,
  E_MANIFEST_SHORT=8'h21,E_PAGE_SHORT=8'h22,E_PAGE_ORDER=8'h23,E_SERVICE=8'h24;
 reg aw_hold,w_hold,aw_poison,w_poison;reg [11:0] aw_addr;reg [31:0] w_data;reg [3:0] w_strb;
 reg manifest_active,page_active,fault_seen,manifest_done_seen,page_done_seen;
 reg [31:0] requested_page_index;
 reg [15:0] msg_in,sig_in,page_in,proof_in,msg_out,sig_out,page_out,proof_out;
 wire msg_slot=!msg_valid||msg_ready,sig_slot=!sig_valid||sig_ready;
 wire page_slot=!page_valid||page_ready,proof_slot=!proof_valid||proof_ready;
 wire whole_write=(w_strb===4'hf)&&(aw_addr[1:0]===2'b00)&&!aw_poison&&!w_poison;
 wire blocked=whole_write&&((aw_addr==12'h020&&manifest_active&&msg_in<24&&!msg_slot)||
  (aw_addr==12'h024&&manifest_active&&sig_in<1964&&!sig_slot)||
  (aw_addr==12'h028&&page_active&&page_in<1024&&!page_slot)||
  (aw_addr==12'h02c&&page_active&&proof_in<PROOF_WORDS&&!proof_slot));
 wire manifest_complete=(msg_in==24)&&(sig_in==1964)&&(msg_out==24)&&(sig_out==1964)&&!msg_valid&&!sig_valid;
 wire page_complete=(page_in==1024)&&(proof_in==PROOF_WORDS)&&(page_out==1024)&&(proof_out==PROOF_WORDS)&&!page_valid&&!proof_valid;
 wire any_word=msg_valid||sig_valid||page_valid||proof_valid;
 assign s_awready=rst_n&&!aw_hold&&!s_bvalid;
 assign s_wready=rst_n&&!w_hold&&!s_bvalid;
 assign s_arready=rst_n&&!s_rvalid;
 task abort_feed(input [7:0] code);begin
  svc_cancel<=1;svc_manifest_start<=0;manifest_active<=0;page_active<=0;
  msg_valid<=0;sig_valid<=0;page_valid<=0;proof_valid<=0;msg_last<=0;sig_last<=0;
  msg_in<=0;sig_in<=0;page_in<=0;proof_in<=0;msg_out<=0;sig_out<=0;page_out<=0;proof_out<=0;
  requested_page_index<=0;feeder_error<=code;
 end endtask
 always @(posedge clk)begin
  if(!rst_n)begin
   aw_hold<=0;w_hold<=0;aw_poison<=0;w_poison<=0;aw_addr<=0;w_data<=0;w_strb<=0;
   s_bresp<=0;s_bvalid<=0;s_rdata<=0;s_rresp<=0;s_rvalid<=0;
   svc_manifest_start<=0;svc_cancel<=0;manifest_active<=0;page_active<=0;fault_seen<=0;manifest_done_seen<=0;page_done_seen<=0;
   msg_valid<=0;sig_valid<=0;page_valid<=0;proof_valid<=0;msg_data<=0;sig_data<=0;page_data<=0;proof_data<=0;msg_last<=0;sig_last<=0;
   msg_in<=0;sig_in<=0;page_in<=0;proof_in<=0;msg_out<=0;sig_out<=0;page_out<=0;proof_out<=0;
   requested_page_index<=0;feeder_error<=0;
  end else begin
   svc_manifest_start<=0;svc_cancel<=0;fault_seen<=svc_fault;manifest_done_seen<=svc_manifest_done;page_done_seen<=svc_page_done;
   if(msg_valid&&msg_ready)begin msg_valid<=0;msg_out<=msg_out+1'b1;end
   if(sig_valid&&sig_ready)begin sig_valid<=0;sig_out<=sig_out+1'b1;end
   if(page_valid&&page_ready)begin page_valid<=0;page_out<=page_out+1'b1;end
   if(proof_valid&&proof_ready)begin proof_valid<=0;proof_out<=proof_out+1'b1;end
   if(s_bvalid&&s_bready)s_bvalid<=0;
   if(s_rvalid&&s_rready)s_rvalid<=0;
   if(s_awvalid&&s_awready)begin aw_hold<=1;aw_addr<=s_awaddr;aw_poison<=trusted_cancel;end
   if(s_wvalid&&s_wready)begin w_hold<=1;w_data<=s_wdata;w_strb<=s_wstrb;w_poison<=trusted_cancel;end
   if(svc_manifest_done&&!manifest_done_seen&&manifest_active)begin
    manifest_active<=0;
    if(!manifest_complete)abort_feed(E_MANIFEST_SHORT);
   end
   if(svc_page_done&&!page_done_seen&&page_active)begin
    page_active<=0;
    if(!page_complete)abort_feed(E_PAGE_SHORT);
   end
   // Only the trusted service/CDC page handshake chooses a page. CPU can read
   // this index and supply arbitrary bytes, but can never write the index.
   if(trusted_page_accept)begin
    if(!svc_model_authorized||manifest_active||
       (page_active&&!(svc_page_done&&page_complete))||any_word)abort_feed(E_PAGE_ORDER);
    else begin
     page_active<=1;requested_page_index<=trusted_page_index;
     page_in<=0;proof_in<=0;page_out<=0;proof_out<=0;page_valid<=0;proof_valid<=0;
    end
   end
   if(aw_hold&&w_hold&&!s_bvalid&&!blocked)begin
    aw_hold<=0;w_hold<=0;aw_poison<=0;w_poison<=0;s_bvalid<=1;s_bresp<=0;
    if(!whole_write)begin s_bresp<=2'b10;abort_feed(E_PROTOCOL);end
    else case(aw_addr)
     12'h004:begin
      if(w_data==2)abort_feed(E_CANCEL);
      else if(w_data==1&&svc_manifest_ready&&!svc_busy&&!manifest_active&&!page_active&&
              !any_word&&!trusted_page_accept&&!svc_cancel&&!trusted_cancel)begin
       svc_manifest_start<=1;manifest_active<=1;feeder_error<=0;
       msg_in<=0;sig_in<=0;msg_out<=0;sig_out<=0;msg_valid<=0;sig_valid<=0;msg_last<=0;sig_last<=0;
      end else begin s_bresp<=2'b10;abort_feed(E_STATE);end
     end
     12'h020:begin
      if(!manifest_active||svc_fault||svc_cancel||trusted_cancel)begin s_bresp<=2'b10;abort_feed(E_STATE);end
      else if(msg_in>=24)begin s_bresp<=2'b10;abort_feed(E_EXTRA);end
      else begin msg_valid<=1;msg_data<=w_data;msg_last<=msg_in==23;msg_in<=msg_in+1'b1;end
     end
     12'h024:begin
      if(!manifest_active||svc_fault||svc_cancel||trusted_cancel)begin s_bresp<=2'b10;abort_feed(E_STATE);end
      else if(sig_in>=1964)begin s_bresp<=2'b10;abort_feed(E_EXTRA);end
      else begin sig_valid<=1;sig_data<=w_data;sig_last<=sig_in==1963;sig_in<=sig_in+1'b1;end
     end
     12'h028:begin
      if(!page_active||!svc_model_authorized||svc_fault||svc_cancel||trusted_cancel)begin s_bresp<=2'b10;abort_feed(E_STATE);end
      else if(page_in>=1024)begin s_bresp<=2'b10;abort_feed(E_EXTRA);end
      else begin page_valid<=1;page_data<=w_data;page_in<=page_in+1'b1;end
     end
     12'h02c:begin
      if(!page_active||!svc_model_authorized||svc_fault||svc_cancel||trusted_cancel)begin s_bresp<=2'b10;abort_feed(E_STATE);end
      else if(proof_in>=PROOF_WORDS)begin s_bresp<=2'b10;abort_feed(E_EXTRA);end
      else begin proof_valid<=1;proof_data<=w_data;proof_in<=proof_in+1'b1;end
     end
     default:begin s_bresp<=2'b10;abort_feed(E_PROTOCOL);end
    endcase
   end
   if(s_arvalid&&s_arready)begin
    s_rvalid<=1;s_rresp<=0;s_rdata<=0;
    if(s_araddr[1:0]!=0)s_rresp<=2'b10;
    else case(s_araddr)
     12'h000:s_rdata<=32'h4d464431; // MFD1
     12'h008:s_rdata<={6'd0,svc_page_done,svc_manifest_done,s_rvalid,s_bvalid,w_hold,aw_hold,
       proof_valid,page_valid,sig_valid,msg_valid,proof_ready,page_ready,sig_ready,msg_ready,
       proof_slot,page_slot,sig_slot,msg_slot,(feeder_error!=0),svc_fault,svc_manifest_ready,svc_cache_valid,svc_model_authorized,svc_busy,page_active,manifest_active};
     12'h00c:s_rdata<=requested_page_index;
     12'h010:s_rdata<=svc_epoch;
     12'h014:s_rdata<=svc_cached_page_index;
     12'h018:s_rdata<={8'd0,svc_page_error,svc_policy_error,svc_signature_error};
     12'h01c:s_rdata<={24'd0,feeder_error};
     12'h030:s_rdata<={16'd0,msg_in};
     12'h034:s_rdata<={16'd0,sig_in};
     12'h038:s_rdata<={16'd0,page_in};
     12'h03c:s_rdata<={16'd0,proof_in};
     12'h040:s_rdata<={16'd0,msg_out};
     12'h044:s_rdata<={16'd0,sig_out};
     12'h048:s_rdata<={16'd0,page_out};
     12'h04c:s_rdata<={16'd0,proof_out};
     12'h050:s_rdata<=32'h00010001;
     12'h054:s_rdata<=24;
     12'h058:s_rdata<=1964;
     12'h05c:s_rdata<=1024;
     12'h060:s_rdata<=PROOF_WORDS;
     default:s_rresp<=2'b10;
    endcase
   end
   // Revocation wins over every stream/write action. Accepted partial AW/W
   // halves are poisoned (not discarded), so AXI still receives an error once
   // its matching half arrives. All stream holding words/counters are erased.
   if(trusted_cancel||(svc_fault&&!fault_seen)||(page_active&&!svc_model_authorized))begin
    abort_feed(trusted_cancel?E_CANCEL:E_SERVICE);
    if(aw_hold||(s_awvalid&&s_awready))aw_poison<=1;
    if(w_hold||(s_wvalid&&s_wready))w_poison<=1;
    if(aw_hold&&w_hold&&!s_bvalid)begin aw_hold<=0;w_hold<=0;s_bvalid<=1;s_bresp<=2'b10;end
   end
  end
 end
endmodule

