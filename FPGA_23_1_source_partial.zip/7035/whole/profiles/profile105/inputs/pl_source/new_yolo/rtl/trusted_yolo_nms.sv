`timescale 1ns/1ps
// Deterministic bounded greedy NMS. Coordinates are signed Q16.8 in the
// 320x320 letterbox domain; ROI is pre-mapped to the source by trusted decode.
// Candidates reside in an existing protected scratch cache, not a new tensor
// RAM. Each response requires consumption-time verification and bound tags.
// Selection exactly implements score descending then raw_index ascending for
// these fixed-point inputs, using division-free IoU > threshold.
module trusted_yolo_nms #(
 parameter integer NATIVE_1080=1,
 parameter integer MAX_CANDIDATES=6300
)(
 input wire clk,rst_n,start,cancel,authorized,
 input wire [31:0] session_id,frame_id,epoch,authorization_epoch,
 input wire [12:0] candidate_count,input wire [16:0] iou_threshold_q16,
 output wire ready,busy,quiescent,
 output wire read_valid,input wire read_ready,output wire [12:0] read_index,
 input wire response_valid,response_verified,
 input wire [12:0] response_index,
 input wire [31:0] response_session,response_frame,response_epoch,
 // x0,y0,x1,y1 signed Q8; score unsigned Q30; source pixel ROI 4x16.
 input wire [223:0] response_data,
 output reg done,failed,output reg [2:0] selected_count,
 output reg [31:0] result_session,result_frame,result_epoch,
 output wire [895:0] selected_data,
 output wire [51:0] selected_indices,
 input wire memory_quiescent
);
 localparam[15:0] SOURCE_WIDTH=NATIVE_1080?16'd1920:16'd640,SOURCE_HEIGHT=NATIVE_1080?16'd1080:16'd480;
 localparam IDLE=0,REQUEST=1,RESPONSE=2,CHECK=3,UPDATE=4,NEXT=5,PASS_END=6,DRAIN=7,
  AREA=8,UNION=9,SCALE=10,COMPARE=11;
 reg [3:0] state;
 reg [12:0] count,index,best_index;
 reg [16:0] threshold;
 reg [223:0] current,best,selected[0:3];
 reg [12:0] selected_index[0:3];
 reg best_valid,rejected,abort_pending;
 reg [2:0] compare_index;
 wire revoked=!authorized||authorization_epoch!=result_epoch;
 wire stopping=cancel||revoked||abort_pending;
 wire signed [32:0] ax0={current[31],current[31:0]},ay0={current[63],current[63:32]};
 wire signed [32:0] ax1={current[95],current[95:64]},ay1={current[127],current[127:96]};
 wire [223:0] other=selected[compare_index[1:0]];
 wire signed [32:0] bx0={other[31],other[31:0]},by0={other[63],other[63:32]};
 wire signed [32:0] bx1={other[95],other[95:64]},by1={other[127],other[127:96]};
 wire signed [32:0] ix0=ax0>bx0?ax0:bx0,iy0=ay0>by0?ay0:by0;
 wire signed [32:0] ix1=ax1<bx1?ax1:bx1,iy1=ay1<by1?ay1:by1;
 wire [20:0] iw=ix1>ix0?ix1-ix0:0,ih=iy1>iy0?iy1-iy0:0;
 wire [20:0] aw=ax1>ax0?ax1-ax0:0,ah=ay1>ay0?ay1-ay0:0;
 wire [20:0] bw=bx1>bx0?bx1-bx0:0,bh=by1>by0?by1-by0:0;
 reg [20:0] iw_reg,ih_reg,aw_reg,ah_reg,bw_reg,bh_reg;
 reg [41:0] area_a_reg,area_b_reg,intersection_reg,intersection_delayed;
 reg [42:0] union_reg;
 reg [59:0] threshold_area_reg,scaled_intersection_reg;
 wire suppress=(union_reg!=0)&&(scaled_intersection_reg>threshold_area_reg);
 wire valid_geometry=(ax1>ax0)&&(ay1>ay0)&&
   ax0>=-1048576&&ax1<=1048575&&ay0>=-1048576&&ay1<=1048575&&
   (current[191:176]>current[175:160])&&(current[223:208]>current[207:192])&&
   current[191:176]<=SOURCE_WIDTH&&current[175:160]<SOURCE_WIDTH&&
   current[223:208]<=SOURCE_HEIGHT&&current[207:192]<SOURCE_HEIGHT;
 assign ready=(state==IDLE)&&memory_quiescent&&authorized&&!cancel;
 assign busy=state!=IDLE;
 assign quiescent=state==IDLE&&memory_quiescent;
 assign read_valid=state==REQUEST;
 assign read_index=index;
 assign selected_data={selected[3],selected[2],selected[1],selected[0]};
 assign selected_indices={selected_index[3],selected_index[2],selected_index[1],selected_index[0]};
 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;count<=0;index<=0;best_index<=0;threshold<=0;
   current<=0;best<=0;best_valid<=0;rejected<=0;compare_index<=0;
   selected_count<=0;abort_pending<=0;done<=0;failed<=0;
   result_session<=0;result_frame<=0;result_epoch<=0;
   iw_reg<=0;ih_reg<=0;aw_reg<=0;ah_reg<=0;bw_reg<=0;bh_reg<=0;
   area_a_reg<=0;area_b_reg<=0;intersection_reg<=0;intersection_delayed<=0;
   union_reg<=0;threshold_area_reg<=0;scaled_intersection_reg<=0;
   for(i=0;i<4;i=i+1)begin selected[i]<=0;selected_index[i]<=0;end
  end else begin
   done<=0;failed<=0;
   if(state!=IDLE&&(cancel||revoked))abort_pending<=1;
   case(state)
    IDLE:if(start&&ready)begin
     result_session<=session_id;result_frame<=frame_id;result_epoch<=epoch;
     count<=candidate_count;threshold<=iou_threshold_q16;
     index<=0;best_valid<=0;selected_count<=0;abort_pending<=0;
     for(i=0;i<4;i=i+1)begin selected[i]<=0;selected_index[i]<=0;end
     if(!session_id||!frame_id||epoch!=authorization_epoch||
        candidate_count>MAX_CANDIDATES||iou_threshold_q16>65536)state<=DRAIN;
     else if(candidate_count==0)state<=PASS_END;
     else state<=REQUEST;
    end
    REQUEST:if(read_ready)state<=RESPONSE;
    RESPONSE:if(response_valid)begin
     if(!response_verified||response_index!=index||response_session!=result_session||
        response_frame!=result_frame||response_epoch!=result_epoch)state<=DRAIN;
     else if(stopping)state<=DRAIN;
     else begin current<=response_data;compare_index<=0;rejected<=0;state<=CHECK;end
    end
    CHECK:begin
     if(stopping)state<=DRAIN;
     else if(!valid_geometry)state<=NEXT;
     else if(compare_index==selected_count)state<=UPDATE;
     else if(index==selected_index[compare_index[1:0]])state<=NEXT;
     else begin
      iw_reg<=iw;ih_reg<=ih;aw_reg<=aw;ah_reg<=ah;bw_reg<=bw;bh_reg<=bh;
      state<=AREA;
     end
    end
    AREA:if(stopping)state<=DRAIN;else begin
     area_a_reg<=aw_reg*ah_reg;area_b_reg<=bw_reg*bh_reg;
     intersection_reg<=iw_reg*ih_reg;state<=UNION;
    end
    UNION:if(stopping)state<=DRAIN;else begin
     union_reg<={1'b0,area_a_reg}+{1'b0,area_b_reg}-{1'b0,intersection_reg};
     intersection_delayed<=intersection_reg;state<=SCALE;
    end
    SCALE:if(stopping)state<=DRAIN;else begin
     threshold_area_reg<=union_reg*threshold;
     scaled_intersection_reg<={2'b0,intersection_delayed,16'b0};state<=COMPARE;
    end
    COMPARE:if(stopping)state<=DRAIN;else if(suppress)state<=NEXT;
     else begin compare_index<=compare_index+1;state<=CHECK;end
    UPDATE:begin
     if(stopping)state<=DRAIN;
     else begin
      if(!best_valid||current[159:128]>best[159:128]||
         (current[159:128]==best[159:128]&&index<best_index))begin
       best<=current;best_index<=index;best_valid<=1;
      end
      state<=NEXT;
     end
    end
    NEXT:if(stopping)state<=DRAIN;
     else if(index+1>=count)state<=PASS_END;
     else begin index<=index+1;state<=REQUEST;end
    PASS_END:begin
     if(stopping)state<=DRAIN;
     else if(!best_valid)begin done<=1;state<=IDLE;end
     else begin
      selected[selected_count[1:0]]<=best;
      selected_index[selected_count[1:0]]<=best_index;
      selected_count<=selected_count+1;
      if(selected_count==3)begin done<=1;state<=IDLE;end
      else begin best_valid<=0;index<=0;state<=REQUEST;end
     end
    end
    DRAIN:if(memory_quiescent)begin failed<=1;state<=IDLE;end
    default:state<=DRAIN;
   endcase
  end
 end
endmodule
