`timescale 1ns/1ps
// Frozen-model head gather -> decode -> authenticated candidate DDR -> NMS.
// The enclosing trusted parent connects the beat port to the SHARED typed
// tensor guard / SM4 / DDR backend. No CPU box, score, shape or NMS port exists.
// LUT_FILE and these fixed thresholds are bitstream configuration policy;
// loading this ROM from PS-controlled DDR is not a supported trust boundary.
module trusted_yolo_postprocessor_attestable #(
 parameter LUT_FILE="decode_lut.hex",
 parameter [30:0] CONFIDENCE_Q30=31'd268435456,
 parameter [16:0] IOU_Q16=17'd29491
)(
 input wire [9:0] attestation_index,output wire [255:0] attestation_data,output wire attestation_quiescent,
 input wire clk,rst_n,cancel,authorized,
 input wire [31:0] authorization_epoch,
 input wire job_valid,output wire job_ready,
 input wire [31:0] job_session,job_frame,job_epoch,
 output wire quiescent,active,output reg done,failed,
 output reg [31:0] result_session,result_frame,result_epoch,
 output wire [2:0] selected_count,output wire [895:0] selected_data,
 output wire [51:0] selected_indices,
 output wire beat_request,input wire beat_ready,output reg beat_write,
 output reg [31:0] beat_address,beat_mask,beat_session,beat_frame,beat_epoch,
 output reg [15:0] beat_role,beat_shape,output reg [255:0] beat_data,
 input wire beat_response_valid,beat_verified,
 input wire [255:0] beat_response_data,input wire backend_quiescent
);
 localparam IDLE=0,BIND=1,DECODE_START=2,DECODE_WAIT=3,NMS_START=4,
  NMS_WAIT=5,DRAIN=6,REPORT=7;
 reg [3:0] state;reg aborted,terminal_good;
 wire live=authorized&&!cancel&&!aborted&&authorization_epoch==result_epoch;
 wire stop_children=cancel||aborted||(state!=IDLE&&!authorized)||
                    (state!=IDLE&&authorization_epoch!=result_epoch);
 wire head_quiet,candidate_quiet,decode_quiet,nms_quiet;
 wire candidate_ready,all_committed,candidate_error;
 wire decode_ready,decode_done,decode_failed,nms_ready,nms_done,nms_failed;
 wire decoder_candidate_valid;wire [12:0] decoder_candidate_index;
 wire [223:0] decoder_candidate_data;
 wire head_request,head_ready,head_response_valid,head_verified;
 wire [12:0] head_index,head_response_index;
 wire [31:0] head_base,head_response_session,head_response_frame,head_response_epoch;
 wire [10:0] head_plane,head_cell;wire [1:0] head_anchor;wire [47:0] head_codes;
 wire nms_read_valid,nms_read_ready;wire [12:0] nms_read_index;
 wire candidate_response_valid,candidate_verified,candidate_response_write;
 wire [12:0] candidate_response_index;wire [223:0] candidate_response_data;
 wire [31:0] candidate_session,candidate_frame,candidate_epoch;
 wire [31:0] decode_session,decode_frame,decode_epoch,nms_session,nms_frame,nms_epoch;

 // An explicit grant register prevents changing an offered request if another
 // requester becomes ready while the external guard is backpressured.
 localparam ARB_IDLE=0,ARB_OFFER=1,ARB_REPLY=2;
 reg [1:0] arb_state;reg owner_candidate;
 wire arb_quiet=arb_state==ARB_IDLE&&backend_quiescent;
 wire hbeat_request,cbeat_request;wire hbeat_ready,cbeat_ready;
 wire [31:0] haddress,hmask,hsession,hframe,hepoch;
 wire [15:0] hrole,hshape;
 wire cwrite;wire [31:0] caddress,cmask,csession,cframe,cepoch;
 wire [15:0] crole,cshape;wire [255:0] cdata;
 assign hbeat_ready=arb_state==ARB_IDLE&&backend_quiescent&&!cbeat_request;
 assign cbeat_ready=arb_state==ARB_IDLE&&backend_quiescent;
 assign beat_request=arb_state==ARB_OFFER;
 wire response_to_head=arb_state==ARB_REPLY&&!owner_candidate&&beat_response_valid;
 wire response_to_candidate=arb_state==ARB_REPLY&&owner_candidate&&beat_response_valid;
 always @(posedge clk)begin
  if(!rst_n)begin
   arb_state<=ARB_IDLE;owner_candidate<=0;beat_write<=0;beat_address<=0;beat_mask<=0;
   beat_session<=0;beat_frame<=0;beat_epoch<=0;beat_role<=0;beat_shape<=0;beat_data<=0;
  end else case(arb_state)
   ARB_IDLE:if(backend_quiescent)begin
    if(cbeat_request)begin
     owner_candidate<=1;beat_write<=cwrite;beat_address<=caddress;beat_mask<=cmask;
     beat_session<=csession;beat_frame<=cframe;beat_epoch<=cepoch;
     beat_role<=crole;beat_shape<=cshape;beat_data<=cdata;arb_state<=ARB_OFFER;
    end else if(hbeat_request)begin
     owner_candidate<=0;beat_write<=0;beat_address<=haddress;beat_mask<=hmask;
     beat_session<=hsession;beat_frame<=hframe;beat_epoch<=hepoch;
     beat_role<=hrole;beat_shape<=hshape;beat_data<=0;arb_state<=ARB_OFFER;
    end
   end
   ARB_OFFER:if(beat_ready)arb_state<=ARB_REPLY;
   ARB_REPLY:if(beat_response_valid)arb_state<=ARB_IDLE;
   default:arb_state<=ARB_IDLE;
  endcase
 end
 wire memory_quiet=head_quiet&&candidate_quiet&&arb_quiet;
 wire all_quiet=memory_quiet&&decode_quiet&&nms_quiet;
 assign job_ready=state==IDLE&&all_quiet&&authorized&&!cancel;
 assign quiescent=state==IDLE&&all_quiet;
 assign active=state!=IDLE;
 assign nms_read_ready=candidate_ready&&state==NMS_WAIT;
 trusted_yolo_head_reader heads(
  .clk(clk),.rst_n(rst_n),.cancel(stop_children),.authorized(authorized),.authorization_epoch(authorization_epoch),
  .request_valid(head_request),.request_ready(head_ready),.request_index(head_index),.request_base(head_base),
  .request_plane(head_plane),.request_cell(head_cell),.request_anchor(head_anchor),
  .request_session(result_session),.request_frame(result_frame),.request_epoch(result_epoch),
  .response_valid(head_response_valid),.response_verified(head_verified),.response_index(head_response_index),
  .response_session(head_response_session),.response_frame(head_response_frame),.response_epoch(head_response_epoch),
  .response_codes(head_codes),.quiescent(head_quiet),
  .beat_request(hbeat_request),.beat_ready(hbeat_ready),.beat_address(haddress),.beat_mask(hmask),
  .beat_session(hsession),.beat_frame(hframe),.beat_epoch(hepoch),.beat_role(hrole),.beat_shape(hshape),
  .beat_response_valid(response_to_head),.beat_verified(beat_verified&&live),.beat_data(beat_response_data),
  .beat_response_address(beat_address),.beat_response_session(beat_session),.beat_response_frame(beat_frame),
  .beat_response_epoch(beat_epoch),.backend_quiescent(arb_quiet));
 trusted_yolo_candidate_port candidates(
  .clk(clk),.rst_n(rst_n),.cancel(stop_children),.authorized(authorized),.authorization_epoch(authorization_epoch),
  .job_start(state==BIND),.job_ready(),.job_session(result_session),.job_frame(result_frame),.job_epoch(result_epoch),
  .request_valid(state==DECODE_WAIT?decoder_candidate_valid:state==NMS_WAIT?nms_read_valid:1'b0),
  .request_ready(candidate_ready),.request_write(state==DECODE_WAIT),
  .request_index(state==DECODE_WAIT?decoder_candidate_index:nms_read_index),.request_data(decoder_candidate_data),
  .response_valid(candidate_response_valid),.response_verified(candidate_verified),.response_write(candidate_response_write),
  .response_index(candidate_response_index),.response_data(candidate_response_data),
  .result_session(candidate_session),.result_frame(candidate_frame),.result_epoch(candidate_epoch),
  .commit_error(candidate_error),.all_committed(all_committed),.quiescent(candidate_quiet),
  .backend_request(cbeat_request),.backend_ready(cbeat_ready),.backend_write(cwrite),
  .backend_address(caddress),.backend_mask(cmask),.backend_session(csession),.backend_frame(cframe),.backend_epoch(cepoch),
  .backend_role(crole),.backend_shape(cshape),.backend_data(cdata),
  .backend_response_valid(response_to_candidate),.backend_verified(beat_verified&&live),
  .backend_response_data(beat_response_data),.backend_quiescent(arb_quiet));
 trusted_yolo_decode_attestable #(.LUT_FILE(LUT_FILE)) decode(
  .attestation_index(attestation_index),.attestation_data(attestation_data),.attestation_quiescent(attestation_quiescent),
  .clk(clk),.rst_n(rst_n),.start(state==DECODE_START),.cancel(stop_children),.authorized(authorized),
  .session_id(result_session),.frame_id(result_frame),.epoch(result_epoch),.authorization_epoch(authorization_epoch),
  .confidence_q30(CONFIDENCE_Q30),.ready(decode_ready),.busy(),.quiescent(decode_quiet),
  .head_request(head_request),.head_ready(head_ready),.head_index(head_index),.head_base(head_base),
  .head_plane(head_plane),.head_cell(head_cell),.head_anchor(head_anchor),
  .response_valid(head_response_valid),.response_verified(head_verified),.response_index(head_response_index),
  .response_session(head_response_session),.response_frame(head_response_frame),.response_epoch(head_response_epoch),
  .response_codes(head_codes),.candidate_valid(decoder_candidate_valid),
  .candidate_ready(candidate_ready&&state==DECODE_WAIT),.candidate_index(decoder_candidate_index),.candidate_data(decoder_candidate_data),
  .candidate_commit_error(candidate_error),.memory_quiescent(memory_quiet),.done(decode_done),.failed(decode_failed),
  .result_session(decode_session),.result_frame(decode_frame),.result_epoch(decode_epoch));
 trusted_yolo_nms nms(
  .clk(clk),.rst_n(rst_n),.start(state==NMS_START),.cancel(stop_children),.authorized(authorized),
  .session_id(result_session),.frame_id(result_frame),.epoch(result_epoch),.authorization_epoch(authorization_epoch),
  .candidate_count(13'd6300),.iou_threshold_q16(IOU_Q16),.ready(nms_ready),.busy(),.quiescent(nms_quiet),
  .read_valid(nms_read_valid),.read_ready(nms_read_ready),.read_index(nms_read_index),
  .response_valid(candidate_response_valid&&!candidate_response_write),.response_verified(candidate_verified&&live),
  .response_index(candidate_response_index),.response_session(candidate_session),.response_frame(candidate_frame),
  .response_epoch(candidate_epoch),.response_data(candidate_response_data),.done(nms_done),.failed(nms_failed),
  .selected_count(selected_count),.result_session(nms_session),.result_frame(nms_frame),.result_epoch(nms_epoch),
  .selected_data(selected_data),.selected_indices(selected_indices),.memory_quiescent(memory_quiet));
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;aborted<=0;terminal_good<=0;done<=0;failed<=0;
   result_session<=0;result_frame<=0;result_epoch<=0;end
  else begin
   done<=0;failed<=0;
   if(state!=IDLE&&(cancel||!authorized||authorization_epoch!=result_epoch))aborted<=1;
   case(state)
    IDLE:if(job_valid&&job_ready)begin
     result_session<=job_session;result_frame<=job_frame;result_epoch<=job_epoch;
     terminal_good<=0;aborted<=0;
     if(job_session==0||job_frame==0||job_epoch!=authorization_epoch||
        (result_session==job_session&&result_epoch==job_epoch&&job_frame<=result_frame))begin aborted<=1;state<=DRAIN;end
     else state<=BIND;
    end
    BIND:state<=DECODE_START;
    DECODE_START:if(!live)state<=DRAIN;else if(decode_ready)state<=DECODE_WAIT;
    DECODE_WAIT:if(decode_done||decode_failed)begin
     if(decode_failed||!live||!all_committed||decode_session!=result_session||decode_frame!=result_frame||decode_epoch!=result_epoch)state<=DRAIN;
     else state<=NMS_START;
    end
    NMS_START:if(!live)state<=DRAIN;else if(nms_ready)state<=NMS_WAIT;
    NMS_WAIT:if(nms_done||nms_failed)begin
     terminal_good<=nms_done&&!nms_failed&&live&&nms_session==result_session&&nms_frame==result_frame&&nms_epoch==result_epoch;
     state<=DRAIN;
    end
    DRAIN:if(all_quiet)state<=REPORT;
    REPORT:begin done<=terminal_good&&live;failed<=!terminal_good||!live;state<=IDLE;end
    default:begin aborted<=1;terminal_good<=0;state<=DRAIN;end
   endcase
  end
 end
endmodule
