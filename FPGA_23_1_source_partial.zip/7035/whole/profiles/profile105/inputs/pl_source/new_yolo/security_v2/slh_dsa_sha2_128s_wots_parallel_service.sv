`timescale 1ns/1ps
// Complete FIPS 205 SHA2-128s verification, one shared SHA-256 engine.
// Signature words are big-endian (first byte in word[31:24]).
// External pure mode: stream context bytes followed by raw message bytes.
// Internal mode: stream the exact internal message (no automatic prefix).
// All key/config inputs are captured at start and cannot change a transaction.
module slh_dsa_sha2_128s_wots_parallel_service #(
  parameter integer MAX_MESSAGE_BYTES=8192,
  parameter integer FAST_SHORT=1, WOTS_FAST_SHORT=1,
  parameter integer WOTS_ENGINES=2,WOTS_LONGEST_FIRST=1,SECOND_EXTERNAL_LANE=-1,
  parameter integer TRANSACTION_TIMEOUT=120000000
)(
  input logic clk,rst_n,start,
  output wire wots_active,wots_compressor_reset,wots_compressor_start,
  output wire [511:0] wots_compressor_block,output wire [255:0] wots_compressor_iv,
  input wire wots_compressor_busy,wots_compressor_done,input wire [255:0] wots_compressor_state,

  output wire second_compressor_reset,second_compressor_start,
  output wire [511:0] second_compressor_block,output wire [255:0] second_compressor_iv,
  input wire second_compressor_busy,second_compressor_done,input wire [255:0] second_compressor_state,
  input logic [255:0] public_key,
  input logic external_pure,
  input logic [15:0] message_length,
  input logic [7:0] context_length,
  input logic msg_valid,input logic [31:0] msg_data,input logic [2:0] msg_bytes,input logic msg_last,output logic msg_ready,
  input logic sig_valid,input logic [31:0] sig_word,input logic [3:0] sig_keep,
  input logic sig_last,output logic sig_ready,
  output logic busy,done,auth_valid,fault,output logic [7:0] fault_code,
  output logic [127:0] computed_root,
  output logic [31:0] elapsed_cycles,compute_cycles,
  output logic [2:0] completed_layers,
  output wire short_valid,output wire [511:0] short_data,
  output logic hash_start,output logic [15:0] hash_length,
  output logic hash_valid,output logic [31:0] hash_data,output logic [2:0] hash_count,
  input logic [2:0] hash_capacity,output wire seed_hash,
  input logic hash_ready,hash_done,hash_fault,seed_cached,input logic [255:0] hash_digest,
  output logic [31:0] profile_capture,profile_hmsg,profile_fors,profile_hypertree,
  output logic [31:0] profile_feed,profile_wait,profile_ram
);
  typedef enum logic [5:0] {
    IDLE,CAPTURE,H_INNER,H_INNER_DONE,H_MGF,H_MGF_DONE,F_INIT,F_LEAF_HASH,F_LEAF_DONE,
    F_AUTH_LOAD,F_AUTH_HASH,F_AUTH_DONE,F_SAVE,F_NEXT,F_COMPRESS,F_COMPRESS_DONE,
    W_INIT,W_PARALLEL,W_LOAD,W_CHAIN_INIT,W_CHAIN_HASH,W_CHAIN_DONE,W_SAVE,W_NEXT,W_COMPRESS,W_COMPRESS_DONE,
    W_AUTH_LOAD,W_AUTH_HASH,W_AUTH_DONE,NEXT_LAYER,FINISH,
    READ_REQ,READ_WAIT,READ_SAVE,HASH_START,HASH_FEED,HASH_RAM_READ,HASH_RAM_FEED,HASH_WAIT
  } state_t;
  state_t state,hash_return,read_return;
  typedef enum logic [2:0]{INNER,MGF,NODE,PAIR,F_ROOTS,W_KEYS} hash_kind_t;
  hash_kind_t hash_kind;
  wire [31:0] roots_read,keys_read;
  wire [127:0] signature_node;
  wire [7:0] message_read;
  wire [31:0] message_read_word;
  reg last_buffer_keys;
  wire [31:0] buffer_read=last_buffer_keys?keys_read:roots_read;
  reg signature_write_enable,message_write_enable,roots_write_enable,keys_write_enable;
  reg signature_read_enable,message_read_enable,roots_read_enable,keys_read_enable;
  logic [255:0] key_snapshot;
  logic pure_snapshot;
  logic [7:0] context_snapshot;
  logic [15:0] payload_length,msg_count;
  logic [10:0] sig_count,read_base;
  logic sig_complete,msg_complete,read_sibling;
  logic [1:0] read_slot,save_slot;
  logic [127:0] randomizer,node,sibling,left_node,right_node;
  logic [255:0] inner_digest;
  logic [167:0] fors_message;
  logic [53:0] tree_index;
  logic [8:0] leaf_index;
  logic [3:0] fors_tree,height;
  logic [11:0] fors_index;
  logic [31:0] full_index;
  logic [2:0] layer_index;
  logic [5:0] chain_index;
  logic [3:0] chain_step;
  logic [139:0] wots_digits;
  logic [175:0] compressed_address;
  assign short_valid=FAST_SHORT && seed_cached && (hash_kind==NODE || hash_kind==PAIR);
  assign short_data=hash_kind==NODE?{compressed_address,node,208'd0}:
    {compressed_address,left_node,right_node,80'd0};
  logic [15:0] hash_position;
  logic [31:0] watchdog;
  logic [31:0] cap_end_cycle;
  wire [3:0] current_digit=wots_digits[139-chain_index*4 -: 4];
  assign sig_ready=state==CAPTURE&&!sig_complete;
  assign msg_ready=state==CAPTURE&&!msg_complete;
  // Abort/timeout also clears the shared hash engine before the next transaction.
  assign seed_hash=hash_kind==NODE||hash_kind==PAIR||hash_kind==F_ROOTS||hash_kind==W_KEYS;
  wire w_signature_read,w_key_valid,w_done,w_fault;wire [10:0] w_signature_address;
  wire [7:0] w_key_address,w_fault_code;wire [31:0] w_key_data;
  assign wots_active=busy&&(state==W_INIT||state==W_PARALLEL);
  slh_wots_parallel_scheduler #(.ENGINES(WOTS_ENGINES),.LONGEST_FIRST(WOTS_LONGEST_FIRST),.FAST_SHORT(WOTS_FAST_SHORT),.EXTERNAL_LANE0(1),.EXTERNAL_SECOND_LANE(SECOND_EXTERNAL_LANE)) wots_scheduler(
   .clk(clk),.rst_n(rst_n&&busy),.cancel(busy&&watchdog>=TRANSACTION_TIMEOUT),.start(state==W_INIT),
   .public_seed(key_snapshot[255:128]),.wots_message(node),.layer(layer_index),.tree(tree_index),.leaf(leaf_index),
   .signature_read_enable(w_signature_read),.signature_read_address(w_signature_address),.signature_read_node(signature_node),
   .key_write_valid(w_key_valid),.key_write_ready(1'b1),.key_write_address(w_key_address),.key_write_data(w_key_data),
   .busy(),.done(w_done),.fault(w_fault),.fault_code(w_fault_code),.elapsed_cycles(),.hash_operations(),.loaded_nodes(),.stored_words(),.completed_chains(),
   .external_reset(wots_compressor_reset),.external_start(wots_compressor_start),.external_block(wots_compressor_block),.external_iv(wots_compressor_iv),
   .external_busy(wots_compressor_busy),.external_done(wots_compressor_done),.external_state(wots_compressor_state),
   .second_external_reset(second_compressor_reset),.second_external_start(second_compressor_start),
   .second_external_block(second_compressor_block),.second_external_iv(second_compressor_iv),
   .second_external_busy(second_compressor_busy),.second_external_done(second_compressor_done),.second_external_state(second_compressor_state));



  function automatic [175:0] address(input [7:0] layer,input [63:0] tree,input [7:0] kind,
    input [31:0] keypair,input [31:0] word1,input [31:0] word2);
    address={layer,tree,kind,keypair,word1,word2};
  endfunction
  function automatic [139:0] basew(input [127:0] value);
    integer checksum;logic [139:0] digits;
    begin
      checksum=0;digits=0;
      for(integer i=0;i<32;i=i+1)begin
        digits[139-i*4 -:4]=value[127-i*4 -:4];
        checksum=checksum+15-value[127-i*4 -:4];
      end
      digits[11:8]=(checksum>>8)&15;digits[7:4]=(checksum>>4)&15;digits[3:0]=checksum&15;
      basew=digits;
    end
  endfunction
  function automatic logic is_message_position(input [15:0] pos);
    is_message_position=hash_kind==INNER && pos >= (pure_snapshot?50:48);
  endfunction
  function automatic logic is_buffer_position(input [15:0] pos);
    is_buffer_position=(hash_kind==F_ROOTS||hash_kind==W_KEYS)&&pos>=86;
  endfunction
  function automatic [7:0] hash_byte(input [15:0] pos);
    begin
      hash_byte=0;
    case(hash_kind)
      INNER:begin
        if(pos<16)hash_byte=randomizer[127-pos*8 -:8];
        else if(pos<48)hash_byte=key_snapshot[255-(pos-16)*8 -:8];
        else if(pure_snapshot&&pos==48)hash_byte=0;
        else if(pure_snapshot&&pos==49)hash_byte=context_snapshot;
        else hash_byte=message_read_word[31-((pos-(pure_snapshot?50:48))%4)*8-:8];
      end
      MGF:begin
        if(pos<16)hash_byte=randomizer[127-pos*8 -:8];
        else if(pos<32)hash_byte=key_snapshot[255-(pos-16)*8 -:8];
        else if(pos<64)hash_byte=inner_digest[255-(pos-32)*8 -:8];
      end
      default:begin
        if(pos<16)hash_byte=key_snapshot[255-pos*8 -:8];
        else if(pos<64)hash_byte=0;
        else if(pos<86)hash_byte=compressed_address[175-(pos-64)*8 -:8];
        else if(hash_kind==NODE)hash_byte=node[127-(pos-86)*8 -:8];
        else if(hash_kind==PAIR)begin
          if(pos<102)hash_byte=left_node[127-(pos-86)*8 -:8];
          else hash_byte=right_node[127-(pos-102)*8 -:8];
        end else hash_byte=buffer_read[31-((pos-86)%4)*8 -:8];
      end
    endcase
    end
  endfunction
  logic [2:0] preferred;
  always_comb begin
    hash_valid=(state==HASH_FEED&&!is_message_position(hash_position)&&!is_buffer_position(hash_position)) || state==HASH_RAM_FEED;
    preferred=4;
    if(hash_kind==INNER && is_message_position(hash_position))preferred=4-((hash_position-(pure_snapshot?50:48))%4);
    else if(is_buffer_position(hash_position))preferred=4-((hash_position-86)%4);
    else if(hash_kind==INNER && hash_position<(pure_snapshot?50:48) &&
      (pure_snapshot?50:48)-hash_position<4)preferred=(pure_snapshot?50:48)-hash_position;
    else if((hash_kind==F_ROOTS||hash_kind==W_KEYS) && hash_position<86 && 86-hash_position<4)preferred=86-hash_position;
    if(hash_length-hash_position<preferred)preferred=hash_length-hash_position;
    hash_count=preferred<hash_capacity?preferred:hash_capacity;
    hash_data=0;
    for(integer q=0;q<4;q=q+1)if(q<hash_count)hash_data[31-q*8-:8]=hash_byte(hash_position+q);
  end


  // Aligned big-endian packets: four bytes except the final1/2/3-byte word.
  wire [16:0] message_chunk_end={1'b0,msg_count}+msg_bytes;
  reg message_chunk_ok;
  always @* begin
    message_chunk_ok=0;
    case(msg_bytes)
      3'd1,3'd2,3'd3:
        if(msg_count[1:0]==0 && msg_last && message_chunk_end=={1'b0,payload_length})
          message_chunk_ok=1;
      3'd4:
        if(msg_count[1:0]==0 && message_chunk_end<={1'b0,payload_length} &&
           msg_last==(message_chunk_end=={1'b0,payload_length}))
          message_chunk_ok=1;
      default:message_chunk_ok=0;
    endcase
  end
  // Preserve protocol/signature error priority; never commit a bad packet.
  // Decode the original always_ff priority and CAPTURE error branches exactly.
  // No store changes state timing or bypasses malformed input classification.
  always @* begin
    signature_write_enable=0;message_write_enable=0;roots_write_enable=0;keys_write_enable=0;
    signature_read_enable=0;message_read_enable=0;roots_read_enable=0;keys_read_enable=0;
    if(!rst_n)begin end
    else if(busy&&watchdog>=TRANSACTION_TIMEOUT)begin end
    else case(state)
      CAPTURE:begin
        if((msg_valid&&!msg_ready)||(sig_valid&&!sig_ready))begin end
        else if(sig_valid&&sig_ready&&(sig_keep!=4'hf||sig_last!=(sig_count==1963)))begin end
        else if(msg_valid&&msg_ready&&!message_chunk_ok)begin end
        else begin
          if(msg_valid&&msg_ready)message_write_enable=1;
          if(sig_valid&&sig_ready)signature_write_enable=1;
        end
      end
      F_SAVE:roots_write_enable=1;
      W_SAVE:keys_write_enable=1;
      W_PARALLEL:begin signature_read_enable=w_signature_read;keys_write_enable=w_key_valid;end
      READ_REQ:signature_read_enable=1;
      // Accept the current synchronous byte and issue the following read
      // on the same edge. No read is advanced while the hash sink is stalled.
      HASH_RAM_FEED:if(hash_ready && hash_count>0 && hash_position+hash_count<hash_length)begin
        if(hash_kind==INNER)message_read_enable=1;
        else if(is_buffer_position(hash_position)&&((hash_position-86)%4)+hash_count==4)begin
          if(hash_kind==F_ROOTS)roots_read_enable=1;
          else if(hash_kind==W_KEYS)keys_read_enable=1;
        end
      end
      HASH_RAM_READ:begin
        if(hash_kind==INNER)message_read_enable=1;
        else if(hash_kind==F_ROOTS)roots_read_enable=1;
        else keys_read_enable=1;
      end
      default:begin end
    endcase
  end
  always @(posedge clk)begin
    if(roots_read_enable)last_buffer_keys<=0;
    if(keys_read_enable)last_buffer_keys<=1;
  end
  localparam integer MESSAGE_DEPTH=MAX_MESSAGE_BYTES+255;
  localparam integer MESSAGE_ABITS=MESSAGE_DEPTH>1?$clog2(MESSAGE_DEPTH):1;
  wire [10:0] signature_address=wots_active?w_signature_address:read_base;
  wire [5:0] roots_write_address=fors_tree*4+save_slot;
  wire [15:0] buffer_read_position=hash_position+(state==HASH_RAM_FEED?hash_count:0);
  wire [5:0] roots_read_address=(buffer_read_position-86)/4;
  wire [7:0] keys_write_address=wots_active?w_key_address:chain_index*4+save_slot;
  wire [7:0] keys_read_address=(buffer_read_position-86)/4;
  wire [MESSAGE_ABITS-1:0] message_write_address=msg_count;
  wire [15:0] message_read_position=hash_position+(state==HASH_RAM_FEED?hash_count:0);
  wire [MESSAGE_ABITS-1:0] message_read_address=message_read_position-(pure_snapshot?50:48);
  slh_signature_node_sram128 signature_mem(
    .clk(clk),.write_enable(signature_write_enable),.write_address(sig_count),.write_data(sig_word),
    .read_enable(signature_read_enable),.read_address(signature_address),.read_node(signature_node));
  slh_message_word_sram32_wordfeed #(.DEPTH_BYTES(MESSAGE_DEPTH)) message_mem(
    .clk(clk),.write_enable(message_write_enable),.write_address(message_write_address),.write_data(msg_data),.write_bytes(msg_bytes),
    .read_enable(message_read_enable),.read_address(message_read_address),.read_data(message_read),.read_word_data(message_read_word));
  slh_word_sram #(.WIDTH(32),.DEPTH(56),.BANK_WORDS(64)) roots_mem(
    .clk(clk),.write_enable(roots_write_enable),.write_address(roots_write_address),.write_data(node[127-save_slot*32-:32]),
    .read_enable(roots_read_enable),.read_address(roots_read_address),.read_data(roots_read));
  slh_word_sram #(.WIDTH(32),.DEPTH(140),.BANK_WORDS(256)) keys_mem(
    .clk(clk),.write_enable(keys_write_enable),.write_address(keys_write_address),.write_data(wots_active?w_key_data:node[127-save_slot*32-:32]),
    .read_enable(keys_read_enable),.read_address(keys_read_address),.read_data(keys_read));

  always_ff @(posedge clk)begin
    if(!rst_n)begin
      state<=IDLE;busy<=0;done<=0;auth_valid<=0;fault<=0;fault_code<=0;
      computed_root<=0;elapsed_cycles<=0;compute_cycles<=0;completed_layers<=0;
      hash_start<=0;watchdog<=0;cap_end_cycle<=0;msg_count<=0;sig_count<=0;
      sig_complete<=0;msg_complete<=0;key_snapshot<=0;pure_snapshot<=0;context_snapshot<=0;payload_length<=0;
      randomizer<=0;node<=0;sibling<=0;left_node<=0;right_node<=0;inner_digest<=0;
      fors_message<=0;tree_index<=0;leaf_index<=0;fors_tree<=0;fors_index<=0;full_index<=0;
      height<=0;layer_index<=0;chain_index<=0;chain_step<=0;wots_digits<=0;
      compressed_address<=0;hash_length<=0;hash_position<=0;hash_kind<=INNER;
      read_base<=0;read_slot<=0;save_slot<=0;read_sibling<=0;hash_return<=IDLE;read_return<=IDLE;
    end else begin
      done<=0;hash_start<=0;
      if(busy)begin elapsed_cycles<=elapsed_cycles+1;watchdog<=watchdog+1;end
      if(busy&&watchdog>=TRANSACTION_TIMEOUT)begin
        fault<=1;fault_code<=8'h05;auth_valid<=0;busy<=0;done<=1;state<=IDLE;
      end else case(state)
        IDLE:if(start)begin
          key_snapshot<=public_key;pure_snapshot<=external_pure;context_snapshot<=context_length;
          payload_length<=message_length+(external_pure?context_length:0);
          msg_count<=0;sig_count<=0;sig_complete<=0;
          msg_complete<=message_length==0&&(!external_pure||context_length==0);
          auth_valid<=0;fault<=0;fault_code<=0;computed_root<=0;elapsed_cycles<=0;compute_cycles<=0;completed_layers<=0;
          watchdog<=0;busy<=1;state<=CAPTURE;
          if(message_length>MAX_MESSAGE_BYTES||(!external_pure&&context_length!=0))begin
            busy<=0;done<=1;fault<=1;fault_code<=8'h02;state<=IDLE;
          end
        end
        CAPTURE:begin
          if((msg_valid&&!msg_ready)||(sig_valid&&!sig_ready))begin
            busy<=0;done<=1;fault<=1;fault_code<=8'h04;state<=IDLE;
          end else if(sig_valid&&sig_ready&&(sig_keep!=4'hf||sig_last!=(sig_count==1963)))begin
            busy<=0;done<=1;fault<=1;fault_code<=8'h01;state<=IDLE;
          end else if(msg_valid&&msg_ready&&!message_chunk_ok)begin
            busy<=0;done<=1;fault<=1;fault_code<=8'h03;state<=IDLE;
          end else begin
          if(msg_valid&&msg_ready)begin
            msg_count<=msg_count+msg_bytes;
            if(msg_last)msg_complete<=1;
          end
          if(sig_valid&&sig_ready)begin
            sig_count<=sig_count+1'b1;
            if(sig_count<4)randomizer[127-sig_count*32 -:32]<=sig_word;
            if(sig_last)sig_complete<=1;
          end
          if(sig_complete&&msg_complete)begin cap_end_cycle<=elapsed_cycles;state<=H_INNER;end
          end
        end
        H_INNER:begin
          hash_kind<=INNER;hash_length<=48+(pure_snapshot?2:0)+payload_length;
          hash_return<=H_INNER_DONE;state<=HASH_START;
        end
        H_INNER_DONE:begin inner_digest<=hash_digest;state<=H_MGF;end
        H_MGF:begin hash_kind<=MGF;hash_length<=68;hash_return<=H_MGF_DONE;state<=HASH_START;end
        H_MGF_DONE:begin
          fors_message<=hash_digest[255:88];tree_index<=hash_digest[85:32];leaf_index<=hash_digest[24:16];
          fors_tree<=0;layer_index<=0;state<=F_INIT;
        end
        F_INIT:begin
          fors_index<=fors_message[167-fors_tree*12 -:12];
          full_index<=(fors_tree*4096)+fors_message[167-fors_tree*12 -:12];
          read_base<=4+fors_tree*52;read_slot<=0;read_sibling<=0;read_return<=F_LEAF_HASH;state<=READ_REQ;
        end
        F_LEAF_HASH:begin
          compressed_address<=address(0,{10'b0,tree_index},3,{23'b0,leaf_index},0,full_index);
          hash_kind<=NODE;hash_length<=102;hash_return<=F_LEAF_DONE;state<=HASH_START;
        end
        F_LEAF_DONE:begin node<=hash_digest[255:128];height<=0;state<=F_AUTH_LOAD;end
        F_AUTH_LOAD:begin
          read_base<=4+fors_tree*52+(height+1)*4;read_slot<=0;read_sibling<=1;read_return<=F_AUTH_HASH;state<=READ_REQ;
        end
        F_AUTH_HASH:begin
          left_node<=fors_index[height]?sibling:node;right_node<=fors_index[height]?node:sibling;
          compressed_address<=address(0,{10'b0,tree_index},3,{23'b0,leaf_index},height+1,full_index>>(height+1));
          hash_kind<=PAIR;hash_length<=118;hash_return<=F_AUTH_DONE;state<=HASH_START;
        end
        F_AUTH_DONE:begin
          node<=hash_digest[255:128];
          if(height==11)begin save_slot<=0;state<=F_SAVE;end else begin height<=height+1;state<=F_AUTH_LOAD;end
        end
        F_SAVE:begin
          // Original F_SAVE word is committed by the synchronous SRAM binding.
          if(save_slot==3)state<=F_NEXT;else save_slot<=save_slot+1'b1;
        end
        F_NEXT:if(fors_tree==13)state<=F_COMPRESS;else begin fors_tree<=fors_tree+1;state<=F_INIT;end
        F_COMPRESS:begin
          compressed_address<=address(0,{10'b0,tree_index},4,{23'b0,leaf_index},0,0);
          hash_kind<=F_ROOTS;hash_length<=310;hash_return<=F_COMPRESS_DONE;state<=HASH_START;
        end
        F_COMPRESS_DONE:begin node<=hash_digest[255:128];state<=W_INIT;end
        W_INIT:begin state<=W_PARALLEL;end
        W_PARALLEL:if(w_done)begin
          if(w_fault)begin busy<=0;done<=1;auth_valid<=0;fault<=1;fault_code<=8'h06;state<=IDLE;end
          else state<=W_COMPRESS;
        end
        W_LOAD:begin
          read_base<=732+layer_index*176+chain_index*4;read_slot<=0;read_sibling<=0;read_return<=W_CHAIN_INIT;state<=READ_REQ;
        end
        W_CHAIN_INIT:begin chain_step<=current_digit;if(current_digit==15)begin save_slot<=0;state<=W_SAVE;end else state<=W_CHAIN_HASH;end
        W_CHAIN_HASH:begin
          compressed_address<=address({5'b0,layer_index},{10'b0,tree_index},0,{23'b0,leaf_index},{26'b0,chain_index},{28'b0,chain_step});
          hash_kind<=NODE;hash_length<=102;hash_return<=W_CHAIN_DONE;state<=HASH_START;
        end
        W_CHAIN_DONE:begin
          node<=hash_digest[255:128];
          if(chain_step==14)begin save_slot<=0;state<=W_SAVE;end else begin chain_step<=chain_step+1;state<=W_CHAIN_HASH;end
        end
        W_SAVE:begin
          // Original W_SAVE word is committed by the synchronous SRAM binding.
          if(save_slot==3)state<=W_NEXT;else save_slot<=save_slot+1'b1;
        end
        W_NEXT:if(chain_index==34)state<=W_COMPRESS;else begin chain_index<=chain_index+1;state<=W_LOAD;end
        W_COMPRESS:begin
          compressed_address<=address({5'b0,layer_index},{10'b0,tree_index},1,{23'b0,leaf_index},0,0);
          hash_kind<=W_KEYS;hash_length<=646;hash_return<=W_COMPRESS_DONE;state<=HASH_START;
        end
        W_COMPRESS_DONE:begin node<=hash_digest[255:128];height<=0;state<=W_AUTH_LOAD;end
        W_AUTH_LOAD:begin
          read_base<=732+layer_index*176+140+height*4;read_slot<=0;read_sibling<=1;read_return<=W_AUTH_HASH;state<=READ_REQ;
        end
        W_AUTH_HASH:begin
          left_node<=leaf_index[height]?sibling:node;right_node<=leaf_index[height]?node:sibling;
          compressed_address<=address({5'b0,layer_index},{10'b0,tree_index},2,0,height+1,leaf_index>>(height+1));
          hash_kind<=PAIR;hash_length<=118;hash_return<=W_AUTH_DONE;state<=HASH_START;
        end
        W_AUTH_DONE:begin
          node<=hash_digest[255:128];
          if(height==8)state<=NEXT_LAYER;else begin height<=height+1;state<=W_AUTH_LOAD;end
        end
        NEXT_LAYER:begin
          completed_layers<=layer_index+1;
          if(layer_index==6)state<=FINISH;
          else begin layer_index<=layer_index+1;leaf_index<=tree_index[8:0];tree_index<=tree_index>>9;state<=W_INIT;end
        end
        FINISH:begin
          computed_root<=node;auth_valid<=node==key_snapshot[127:0];fault<=node!=key_snapshot[127:0];
          fault_code<=node==key_snapshot[127:0]?0:8'h80;busy<=0;done<=1;
          compute_cycles<=elapsed_cycles-cap_end_cycle;state<=IDLE;
        end
        READ_REQ:begin state<=READ_WAIT;end
        READ_WAIT:state<=READ_SAVE;
        READ_SAVE:begin
          if(read_sibling)sibling<=signature_node;
          else node<=signature_node;
          state<=read_return;
        end
        HASH_START:begin hash_position<=seed_hash&&seed_cached?64:0;hash_start<=1;state<=short_valid?HASH_WAIT:HASH_FEED;end
        HASH_FEED:begin
          // RAM-backed bytes are fetched in a separate synchronous cycle.
          if(is_message_position(hash_position)||is_buffer_position(hash_position))state<=HASH_RAM_READ;
          else if(hash_ready)begin
            if(hash_position+hash_count==hash_length)state<=HASH_WAIT;
            else hash_position<=hash_position+hash_count;
          end
        end
        HASH_RAM_READ:begin
          // Original clocked read is issued by the SRAM binding in this state.
          state<=HASH_RAM_FEED;
        end
        HASH_RAM_FEED:if(hash_ready)begin
          if(hash_position+hash_count==hash_length)state<=HASH_WAIT;
          else begin
            hash_position<=hash_position+hash_count;
            // A synchronous 32-bit buffer read supplies four consecutive bytes.
            // Keep its value through SHA backpressure; read again only at a word boundary.
            if(is_message_position(hash_position) || is_buffer_position(hash_position))
              state<=HASH_RAM_FEED;
            else state<=HASH_RAM_READ;
          end
        end
        HASH_WAIT:if(hash_done)begin
          if(hash_fault)begin busy<=0;done<=1;fault<=1;fault_code<=8'h06;state<=IDLE;end
          else state<=hash_return;
        end
        default:state<=IDLE;
      endcase
    end
  end
  logic [1:0] profile_phase;
  wire [1:0] current_phase = state==CAPTURE ? 0 : state==H_INNER ? 1 :
    state==F_INIT ? 2 : state==W_INIT ? 3 : profile_phase;
  always_ff @(posedge clk) begin
    if(!rst_n || (state==IDLE && start)) begin
      profile_phase<=0;profile_capture<=0;profile_hmsg<=0;profile_fors<=0;
      profile_hypertree<=0;profile_feed<=0;profile_wait<=0;profile_ram<=0;
    end else if(busy) begin
      profile_phase<=current_phase;
      case(current_phase)
        0:profile_capture<=profile_capture+1;
        1:profile_hmsg<=profile_hmsg+1;
        2:profile_fors<=profile_fors+1;
        3:profile_hypertree<=profile_hypertree+1;
      endcase
      if(hash_start && short_valid)profile_feed<=profile_feed+hash_length-64;
      else if(hash_valid && hash_ready)profile_feed<=profile_feed+hash_count;
      if(state==HASH_WAIT)profile_wait<=profile_wait+1;
      if(state==READ_REQ || state==READ_WAIT || state==READ_SAVE ||
         state==HASH_RAM_READ || (state==HASH_RAM_FEED && message_read_enable))profile_ram<=profile_ram+1;
    end
  end

endmodule
