`timescale 1ns/1ps
// Entire raw compute-CSR write aperture gate. Production default permanently
// rejects PS control writes; optional legacy diagnostics permit them only when
// no trusted frame is active. Signature/page byte feeds use a separate port.
// The parent may accept a trusted frame only when control_quiescent is high.
module trusted_npu_control_gate #(
 parameter integer ADDR_WIDTH=12,parameter integer ALLOW_LEGACY_WRITES=0
)(
 input wire clk,rst_n,configuration_locked,
 input wire [ADDR_WIDTH-1:0] S_AWADDR,input wire S_AWVALID,output wire S_AWREADY,
 input wire [31:0] S_WDATA,input wire [3:0] S_WSTRB,input wire S_WVALID,output wire S_WREADY,
 output wire [1:0] S_BRESP,output wire S_BVALID,input wire S_BREADY,
 output wire [ADDR_WIDTH-1:0] M_AWADDR,output wire M_AWVALID,input wire M_AWREADY,
 output wire [31:0] M_WDATA,output wire [3:0] M_WSTRB,output wire M_WVALID,input wire M_WREADY,
 input wire [1:0] M_BRESP,input wire M_BVALID,output wire M_BREADY,
 output wire control_quiescent,output reg [31:0] blocked_writes
);
 localparam COLLECT=0,FORWARD=1,WAIT_B=2,REPLY=3;
 reg [1:0] state,reply;
 reg aw_held,w_held,aw_sent,w_sent;
 reg [ADDR_WIDTH-1:0] address;
 reg [31:0] data;reg [3:0] strobe;
 assign S_AWREADY=state==COLLECT&&!aw_held;
 assign S_WREADY=state==COLLECT&&!w_held;
 assign S_BVALID=state==REPLY;
 assign S_BRESP=reply;
 assign M_AWADDR=address;
 assign M_WDATA=data;
 assign M_WSTRB=strobe;
 assign M_AWVALID=state==FORWARD&&!aw_sent;
 assign M_WVALID=state==FORWARD&&!w_sent;
 assign M_BREADY=state==WAIT_B;
 assign control_quiescent=state==COLLECT&&!aw_held&&!w_held&&!S_AWVALID&&!S_WVALID;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=COLLECT;reply<=0;aw_held<=0;w_held<=0;aw_sent<=0;w_sent<=0;
   address<=0;data<=0;strobe<=0;blocked_writes<=0;
  end else begin
   if(S_AWVALID&&S_AWREADY)begin address<=S_AWADDR;aw_held<=1;end
   if(S_WVALID&&S_WREADY)begin data<=S_WDATA;strobe<=S_WSTRB;w_held<=1;end
   case(state)
    COLLECT:if(aw_held&&w_held)begin
     if(configuration_locked||!ALLOW_LEGACY_WRITES)begin
      reply<=2;blocked_writes<=blocked_writes+1;state<=REPLY;
     end else begin aw_sent<=0;w_sent<=0;state<=FORWARD;end
    end
    FORWARD:begin
     // Parent cannot newly assert a trusted lock here because quiescent=0.
     // Previously offered AXI beats still drain if an independent revoke
     // occurs; dropping AW/W valid would violate AXI and can hang the PS.
     if(M_AWVALID&&M_AWREADY)aw_sent<=1;
     if(M_WVALID&&M_WREADY)w_sent<=1;
     if((aw_sent||M_AWREADY)&&(w_sent||M_WREADY))state<=WAIT_B;
    end
    WAIT_B:if(M_BVALID)begin reply<=M_BRESP;state<=REPLY;end
    REPLY:if(S_BREADY)begin aw_held<=0;w_held<=0;state<=COLLECT;end
   endcase
  end
 end
endmodule
