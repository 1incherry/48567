`timescale 1ns/1ps
// Decode->MAC-protected DDR->NMS. No tensor BRAM and no CPU result/config port.
// 32-byte records (224-bit candidate +32 zero padding), logical role0x4002.
// NMS reads are forbidden until every sequential decode write truly commits.
module trusted_yolo_candidate_port #(
 parameter integer CANDIDATE_COUNT=6300,
 parameter [31:0] CANDIDATE_BASE=32'h2e200000
)(
 input wire clk,rst_n,cancel,authorized,input wire [31:0] authorization_epoch,
 input wire job_start,output wire job_ready,input wire [31:0] job_session,job_frame,job_epoch,
 input wire request_valid,output wire request_ready,input wire request_write,
 input wire [12:0] request_index,input wire [223:0] request_data,
 output reg response_valid,response_verified,response_write,output reg [12:0] response_index,
 output reg [223:0] response_data,output reg [31:0] result_session,result_frame,result_epoch,
 output reg commit_error,output wire all_committed,output wire quiescent,
 output wire backend_request,input wire backend_ready,output wire backend_write,
 output wire [31:0] backend_address,backend_mask,backend_session,backend_frame,backend_epoch,
 output wire [15:0] backend_role,backend_shape,output wire [255:0] backend_data,
 input wire backend_response_valid,backend_verified,input wire [255:0] backend_response_data,
 input wire backend_quiescent
);
 localparam IDLE=0,OFFER=1,REPLY=2,REPORT=3;
 reg [1:0] state;reg bound,aborted,good;
 reg [12:0] committed;reg [223:0] saved_data;
 wire live=bound&&authorized&&authorization_epoch==result_epoch&&!cancel&&!aborted;
 assign job_ready=state==IDLE&&backend_quiescent;
 assign quiescent=state==IDLE&&backend_quiescent;
 assign request_ready=state==IDLE&&backend_quiescent&&!job_start;
 assign all_committed=bound&&!commit_error&&committed==CANDIDATE_COUNT;
 assign backend_request=state==OFFER;
 assign backend_write=response_write;
 assign backend_address=CANDIDATE_BASE+{14'd0,response_index,5'd0};
 assign backend_mask=32'hffffffff;
 assign backend_session=result_session;assign backend_frame=result_frame;assign backend_epoch=result_epoch;
 assign backend_role=16'h4002;assign backend_shape=16'h4002;
 assign backend_data={32'd0,saved_data};
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;bound<=0;aborted<=0;good<=0;committed<=0;saved_data<=0;
   response_valid<=0;response_verified<=0;response_write<=0;response_index<=0;response_data<=0;
   result_session<=0;result_frame<=0;result_epoch<=0;commit_error<=0;
  end else begin
   response_valid<=0;response_verified<=0;
   if(bound&&(cancel||!authorized||authorization_epoch!=result_epoch))begin aborted<=1;commit_error<=1;end
   if(job_start&&job_ready)begin
    if(authorized&&!cancel&&job_session!=0&&job_frame!=0&&job_epoch==authorization_epoch&&
       (result_session==0||job_session!=result_session||job_epoch!=result_epoch||job_frame>result_frame))begin
     result_session<=job_session;result_frame<=job_frame;result_epoch<=job_epoch;
     committed<=0;commit_error<=0;aborted<=0;bound<=1;
    end else begin bound<=0;aborted<=1;commit_error<=1;end
   end
   case(state)
    IDLE:if(request_valid&&request_ready)begin
     response_write<=request_write;response_index<=request_index;saved_data<=request_data;response_data<=0;good<=0;
     if(!live||commit_error||request_index>=CANDIDATE_COUNT||CANDIDATE_BASE[4:0]!=0||
       (request_write&&(all_committed||request_index!=committed))||(!request_write&&!all_committed))begin
      commit_error<=1;state<=REPORT;
     end else state<=OFFER;
    end
    OFFER:if(backend_ready)state<=REPLY;
    REPLY:if(backend_response_valid)begin
     if(!live||!backend_verified||(!response_write&&backend_response_data[255:224]!=0))begin commit_error<=1;good<=0;end
     else begin
      good<=1;if(response_write)committed<=committed+1;else response_data<=backend_response_data[223:0];
     end
     state<=REPORT;
    end
    REPORT:if(backend_quiescent)begin response_valid<=1;response_verified<=good&&live&&!commit_error;state<=IDLE;end
    default:begin good<=0;commit_error<=1;state<=REPORT;end
   endcase
  end
 end
endmodule
