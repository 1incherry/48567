// Derived FPGA integration wrapper. Original delivery unchanged.
// One compressor shared between exclusive signature and verified-page phases.
`timescale 1ns/1ps
// D92 controlled short-suffix counterfactual from the frozen one-core wrapper.
// Algorithm, core count, external ports and storage are retained.
module slh_verify_shared_model_top #(
 parameter integer WOTS_ENGINES=2, MAX_MESSAGE_BYTES=4096, MAIN_FAST_SHORT=1, WOTS_FAST_SHORT=1
)(
 input wire clk,rst_n,start,cancel,
 input wire phase_model,model_rst_n,model_start,
 input wire [511:0] model_block,input wire [255:0] model_iv,
 output wire model_busy,model_done,output wire [255:0] model_state,
 input wire [255:0] public_key,
 input wire external_pure,
 input wire [15:0] message_length,
 input wire [7:0] context_length,
 input wire msg_valid,input wire [31:0] msg_data,input wire [2:0] msg_bytes,
 input wire msg_last,output wire msg_ready,
 input wire sig_valid,input wire [31:0] sig_word,input wire [3:0] sig_keep,
 input wire sig_last,output wire sig_ready,
 output wire busy,done,auth_valid,fault,output wire [7:0] fault_code,
 output wire [127:0] computed_root,
 output wire [31:0] elapsed_cycles,compute_cycles,
 output wire [31:0] profile_capture,profile_hmsg,profile_fors,profile_hypertree,
 output wire [31:0] profile_feed,profile_wait,profile_ram,
 output wire ownership_fault
);
 wire core_rst_n=rst_n&&!cancel;
 wire signature_phase_rst_n=core_rst_n&&!phase_model;
 reg phase_protocol_fault;
 always @(posedge clk or negedge core_rst_n)begin
  if(!core_rst_n)phase_protocol_fault<=0;
  else if((start&&phase_model)||(phase_model&&busy))phase_protocol_fault<=1;
 end
 wire wots_active,w_reset,w_start,h_reset,h_compress_start;
 wire [511:0] w_block,h_block;
 wire [255:0] w_iv,h_iv;
 wire second_reset,second_start;
 wire [511:0] second_block;wire [255:0] second_iv,second_state;
 wire second_busy,second_done;
 wire primary_busy,primary_done;wire [255:0] primary_state;
 wire short_valid;wire [511:0] short_data;
 wire hash_start,hash_valid,hash_ready,hash_done,hash_fault,seed_cached,seed_hash;
 wire [15:0] hash_length;wire [31:0] hash_data;
 wire [2:0] hash_count,hash_capacity;wire [255:0] hash_digest;
 wire primary_reset=wots_active?w_reset:h_reset;
 wire primary_start=wots_active?w_start:h_compress_start;
 wire [511:0] primary_block=wots_active?w_block:h_block;
 wire [255:0] primary_iv=wots_active?w_iv:h_iv;
 wire primary_ownership_fault,second_ownership_fault;
 assign ownership_fault=primary_ownership_fault||second_ownership_fault||phase_protocol_fault;

 slh_dsa_sha2_128s_wots_parallel_service #(
  .MAX_MESSAGE_BYTES(MAX_MESSAGE_BYTES),.WOTS_ENGINES(1),
  .FAST_SHORT(MAIN_FAST_SHORT),.WOTS_FAST_SHORT(WOTS_FAST_SHORT),
  .WOTS_LONGEST_FIRST(1),.SECOND_EXTERNAL_LANE(-1)
 ) verifier(
  .clk(clk),.rst_n(signature_phase_rst_n),.start(start),
  .public_key(public_key),.external_pure(external_pure),
  .message_length(message_length),.context_length(context_length),
  .msg_valid(msg_valid),.msg_data(msg_data),.msg_bytes(msg_bytes),.msg_last(msg_last),.msg_ready(msg_ready),
  .sig_valid(sig_valid),.sig_word(sig_word),.sig_keep(sig_keep),.sig_last(sig_last),.sig_ready(sig_ready),
  .busy(busy),.done(done),.auth_valid(auth_valid),.fault(fault),.fault_code(fault_code),
  .computed_root(computed_root),.elapsed_cycles(elapsed_cycles),.compute_cycles(compute_cycles),.completed_layers(),
  .wots_active(wots_active),.wots_compressor_reset(w_reset),.wots_compressor_start(w_start),
  .wots_compressor_block(w_block),.wots_compressor_iv(w_iv),
  .wots_compressor_busy(primary_busy),.wots_compressor_done(primary_done),.wots_compressor_state(primary_state),
  .second_compressor_reset(second_reset),.second_compressor_start(second_start),
  .second_compressor_block(second_block),.second_compressor_iv(second_iv),
  .second_compressor_busy(second_busy),.second_compressor_done(second_done),.second_compressor_state(second_state),
  .short_valid(short_valid),.short_data(short_data),.hash_start(hash_start),.hash_length(hash_length),
  .hash_valid(hash_valid),.hash_data(hash_data),.hash_count(hash_count),.hash_capacity(hash_capacity),
  .seed_hash(seed_hash),.hash_ready(hash_ready),.hash_done(hash_done),.hash_fault(hash_fault),
  .seed_cached(seed_cached),.hash_digest(hash_digest),
  .profile_capture(profile_capture),.profile_hmsg(profile_hmsg),.profile_fors(profile_fors),
  .profile_hypertree(profile_hypertree),.profile_feed(profile_feed),.profile_wait(profile_wait),.profile_ram(profile_ram)
 );
 slh_sha256_word_stream_shared23 #(.EXTERNAL_COMPRESSOR(1)) main_hash(
  .clk(clk),.rst_n(signature_phase_rst_n&&busy&&!wots_active),
  .short_valid(short_valid),.short_data(short_data),.start(hash_start),.length(hash_length),
  .seed_hash(seed_hash),.seed_cached(seed_cached),.valid(hash_valid),.data(hash_data),
  .input_bytes(hash_count),.capacity(hash_capacity),.ready(hash_ready),.busy(),
  .done(hash_done),.fault(hash_fault),.digest(hash_digest),
  .compressor_reset(h_reset),.compressor_start(h_compress_start),.compressor_block(h_block),.compressor_iv(h_iv),
  .compressor_busy(primary_busy&&!wots_active),.compressor_done(primary_done&&!wots_active),
  .compressor_state(wots_active?256'd0:primary_state)
 );
 sha256_phase_shared23 primary_compressor(
  .clk(clk),.rst_n(core_rst_n),.phase_model(phase_model),
  .signature_rst_n(primary_reset&&!phase_model),.signature_start(primary_start),.signature_block(primary_block),.signature_iv(primary_iv),
  .signature_busy(primary_busy),.signature_done(primary_done),.signature_state(primary_state),
  .model_rst_n(model_rst_n&&phase_model),.model_start(model_start),.model_block(model_block),.model_iv(model_iv),
  .model_busy(model_busy),.model_done(model_done),.model_state(model_state),.ownership_fault(primary_ownership_fault)
 );
 assign second_busy=1'b0;
 assign second_done=1'b0;
 assign second_state=256'd0;
 assign second_ownership_fault=1'b0;
 // synopsys translate_off
 initial if(WOTS_ENGINES!=2 && WOTS_ENGINES!=4)$fatal(1,"VERIFY_SWEEP_REQUIRES_2_OR_4_ENGINES");
 // synopsys translate_on
endmodule
