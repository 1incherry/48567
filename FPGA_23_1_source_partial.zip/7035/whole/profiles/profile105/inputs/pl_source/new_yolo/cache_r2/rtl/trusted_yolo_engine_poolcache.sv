`timescale 1ns/1ps
// Derived wrapper: one existing arithmetic engine, no CPU command port.
module trusted_yolo_engine_poolcache #(parameter integer COMMAND_COUNT=58814)(
input wire job_valid,output wire job_ready,
 input wire [31:0] job_session,job_frame,job_epoch,job_rgb_base,
 input wire authorized,input wire [31:0] authorization_epoch,
 input wire job_cancel,output wire job_quiescent,active,compute_quiescent,
 output wire job_done,job_failed,output wire [7:0] failure_code,
 output wire [31:0] result_session,result_frame,result_epoch,
 output wire program_request,input wire program_ready,
 output wire [31:0] program_index,program_object,program_epoch,
 input wire program_valid,program_verified,
 input wire [31:0] response_index,response_object,response_epoch,
 input wire [831:0] response_command,
 output wire [31:0] current_index,
 output wire [15:0] read_transactions,write_transactions,
 input wire clk,
 input wire rst_n,
 output wire a_write,
 output wire b_write,
 output wire [11:0] bank_write_address,
 output wire [255:0] bank_write_data,
 output wire a_read,
 output wire b_read,
 output wire [11:0] a_read_address,
 output wire [11:0] b_read_address,
 input wire [255:0] a_read_data,
 input wire [255:0] b_read_data,
 output wire [31:0] M_AXI_ARADDR,
 output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,
 output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,
 input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,
 input wire [1:0] M_AXI_RRESP,
 input wire M_AXI_RLAST,
 input wire M_AXI_RVALID,
 output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,
 output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,
 output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,
 input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,
 output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,
 output wire M_AXI_WVALID,
 input wire M_AXI_WREADY,
 input wire [1:0] M_AXI_BRESP,
 input wire M_AXI_BVALID,
 output wire M_AXI_BREADY
);
wire cmd_valid;
wire cmd_ready;
wire [1:0] cmd_op;
wire [31:0] cmd_address;
wire [15:0] cmd_words;
wire [11:0] cmd_local_address;
wire [511:0] cfg_descriptor;
wire [15:0] cfg_input_h;
wire [15:0] cfg_input_w;
wire [15:0] cfg_input_row0;
wire [15:0] cfg_input_rows;
wire [15:0] cfg_channel_blocks;
wire [15:0] cfg_output_w;
wire [15:0] cfg_output_row0;
wire [15:0] cfg_output_rows;
wire [3:0] cfg_kernel;
wire [3:0] cfg_stride;
wire [3:0] cfg_padding;
wire [7:0] cfg_zero_point;
wire signed [31:0] cfg_bias;
wire busy;
wire done;
wire error;
wire [831:0] command;
wire command_valid,command_ready,scheduler_quiescent;
reg [15:0] reads,writes;
reg accounting_fault;
wire [16:0] outstanding={1'b0,reads}+{1'b0,writes};
wire bus_busy=busy||M_AXI_ARVALID||M_AXI_AWVALID||M_AXI_WVALID;
assign read_transactions=reads;
assign write_transactions=writes;
assign compute_quiescent=!bus_busy&&outstanding==0&&!accounting_fault&&!a_write&&!a_read&&!b_write&&!b_read&&!M_AXI_RVALID&&!M_AXI_BVALID;
assign job_quiescent=scheduler_quiescent&&!bus_busy&&!accounting_fault;
always @(posedge clk)begin
 if(!rst_n)begin reads<=0;writes<=0;accounting_fault<=0;end
 else begin
  case({M_AXI_ARVALID&&M_AXI_ARREADY,M_AXI_RVALID&&M_AXI_RREADY&&M_AXI_RLAST})
   2'b10:begin reads<=reads+1;if(reads==65535)accounting_fault<=1;end
   2'b01:begin reads<=reads-1;if(reads==0)accounting_fault<=1;end
  endcase
  case({M_AXI_AWVALID&&M_AXI_AWREADY,M_AXI_BVALID&&M_AXI_BREADY})
   2'b10:begin writes<=writes+1;if(writes==65535)accounting_fault<=1;end
   2'b01:begin writes<=writes-1;if(writes==0)accounting_fault<=1;end
  endcase
  if(outstanding[16])accounting_fault<=1;
 end
end
trusted_yolo_scheduler #(.COMMAND_COUNT(COMMAND_COUNT)) control(
 .clk(clk),.rst_n(rst_n),.job_valid(job_valid),.job_ready(job_ready),
 .job_session(job_session),.job_frame(job_frame),.job_epoch(job_epoch),.job_rgb_base(job_rgb_base),
 .authorized(authorized),.authorization_epoch(authorization_epoch),.job_cancel(job_cancel),
 .job_quiescent(scheduler_quiescent),.active(active),.job_done(job_done),.job_failed(job_failed),
 .result_session(result_session),.result_frame(result_frame),.result_epoch(result_epoch),.failure_code(failure_code),
 .program_request(program_request),.program_ready(program_ready),.program_index(program_index),
 .program_object(program_object),.program_epoch(program_epoch),.program_valid(program_valid),
 .program_verified(program_verified),.response_index(response_index),.response_object(response_object),
 .response_epoch(response_epoch),.response_command(response_command),
 .command_valid(command_valid),.command_ready(command_ready),.command(command),
 .engine_busy(bus_busy||accounting_fault),.engine_done(done),.engine_error(error||accounting_fault),
 .axi_outstanding(outstanding[15:0]),.current_index(current_index));
trusted_yolo_command_adapter adapter(
 .instruction(command),.instruction_valid(command_valid),.instruction_ready(command_ready),
 .cmd_valid(cmd_valid),
 .cmd_ready(cmd_ready),
 .cmd_op(cmd_op),
 .cmd_address(cmd_address),
 .cmd_words(cmd_words),
 .cmd_local_address(cmd_local_address),
 .cfg_descriptor(cfg_descriptor),
 .cfg_input_h(cfg_input_h),
 .cfg_input_w(cfg_input_w),
 .cfg_input_row0(cfg_input_row0),
 .cfg_input_rows(cfg_input_rows),
 .cfg_channel_blocks(cfg_channel_blocks),
 .cfg_output_w(cfg_output_w),
 .cfg_output_row0(cfg_output_row0),
 .cfg_output_rows(cfg_output_rows),
 .cfg_kernel(cfg_kernel),
 .cfg_stride(cfg_stride),
 .cfg_padding(cfg_padding),
 .cfg_zero_point(cfg_zero_point),
 .cfg_bias(cfg_bias));
yolo_ddr_engine arithmetic(
 .clk(clk),
 .rst_n(rst_n),
 .cmd_valid(cmd_valid),
 .cmd_ready(cmd_ready),
 .cmd_op(cmd_op),
 .cmd_address(cmd_address),
 .cmd_words(cmd_words),
 .cmd_local_address(cmd_local_address),
 .cfg_descriptor(cfg_descriptor),
 .cfg_input_h(cfg_input_h),
 .cfg_input_w(cfg_input_w),
 .cfg_input_row0(cfg_input_row0),
 .cfg_input_rows(cfg_input_rows),
 .cfg_channel_blocks(cfg_channel_blocks),
 .cfg_output_w(cfg_output_w),
 .cfg_output_row0(cfg_output_row0),
 .cfg_output_rows(cfg_output_rows),
 .cfg_kernel(cfg_kernel),
 .cfg_stride(cfg_stride),
 .cfg_padding(cfg_padding),
 .cfg_zero_point(cfg_zero_point),
 .cfg_bias(cfg_bias),
 .busy(busy),
 .done(done),
 .error(error),
 .a_write(a_write),
 .b_write(b_write),
 .bank_write_address(bank_write_address),
 .bank_write_data(bank_write_data),
 .a_read(a_read),
 .b_read(b_read),
 .a_read_address(a_read_address),
 .b_read_address(b_read_address),
 .a_read_data(a_read_data),
 .b_read_data(b_read_data),
 .M_AXI_ARADDR(M_AXI_ARADDR),
 .M_AXI_ARLEN(M_AXI_ARLEN),
 .M_AXI_ARSIZE(M_AXI_ARSIZE),
 .M_AXI_ARBURST(M_AXI_ARBURST),
 .M_AXI_ARVALID(M_AXI_ARVALID),
 .M_AXI_ARREADY(M_AXI_ARREADY),
 .M_AXI_RDATA(M_AXI_RDATA),
 .M_AXI_RRESP(M_AXI_RRESP),
 .M_AXI_RLAST(M_AXI_RLAST),
 .M_AXI_RVALID(M_AXI_RVALID),
 .M_AXI_RREADY(M_AXI_RREADY),
 .M_AXI_AWADDR(M_AXI_AWADDR),
 .M_AXI_AWLEN(M_AXI_AWLEN),
 .M_AXI_AWSIZE(M_AXI_AWSIZE),
 .M_AXI_AWBURST(M_AXI_AWBURST),
 .M_AXI_AWVALID(M_AXI_AWVALID),
 .M_AXI_AWREADY(M_AXI_AWREADY),
 .M_AXI_WDATA(M_AXI_WDATA),
 .M_AXI_WSTRB(M_AXI_WSTRB),
 .M_AXI_WLAST(M_AXI_WLAST),
 .M_AXI_WVALID(M_AXI_WVALID),
 .M_AXI_WREADY(M_AXI_WREADY),
 .M_AXI_BRESP(M_AXI_BRESP),
 .M_AXI_BVALID(M_AXI_BVALID),
 .M_AXI_BREADY(M_AXI_BREADY));
endmodule
