`timescale 1ns/1ps
// Immutable201-row producer/shape/range table derived from the same frozen
// graph and C-exact58814 command program. The configuration root MUST bind
// ROLE_ROM; there is deliberately no runtime/PS ROM write port.
module trusted_yolo_role_policy #(
 parameter ROLE_ROM="role_policy_201.hex"
)(
 input wire clk,rst_n,cancel,authorized,input wire [31:0] authorization_epoch,
 input wire load_valid,output wire load_ready,input wire load_verified,
 input wire [31:0] load_index,load_epoch,input wire [831:0] load_command,
 output reg load_response_valid,load_allowed,output reg [31:0] loaded_index,loaded_epoch,
 output reg [831:0] loaded_command,output wire context_live,output wire quiescent,
 input wire query_valid,output wire query_ready,input wire query_write,
 input wire [31:0] query_address,query_strobe,
 output wire query_response_valid,input wire query_response_ready,
 output reg query_allowed,query_static,output reg [15:0] query_role,query_shape,
 output reg [31:0] query_mask,query_static_object,query_static_offset,response_address
);
 localparam L_IDLE=0,L_READ=1,L_CHECK=2,L_FINAL=3,L_STORE=4,L_REPORT=5;
 reg [2:0] ls;reg [7:0] low,high,mid;
 (* rom_style="distributed" *) reg [387:0] metadata[0:255];
 initial $readmemh(ROLE_ROM,metadata);
 reg [387:0] row,active_row;
 reg context_valid,aborted;
 wire [8:0] midpoint=({1'b0,low}+{1'b0,high})>>1;
 wire live=context_valid&&authorized&&authorization_epoch==loaded_epoch&&!cancel&&!aborted;
 assign context_live=live;
 reg [1:0] qs;
 localparam Q_IDLE=0,Q_CALCULATE=1,Q_MASK=2,Q_REPORT=3;
 reg saved_write;reg [31:0] saved_address,saved_strobe;
 reg [31:0] selected_start,selected_end,write_start,write_end;
 reg selected_allowed,selected_static;reg [15:0] selected_role;
 assign load_ready=ls==L_IDLE&&qs==Q_IDLE;
 assign query_ready=qs==Q_IDLE&&ls==L_IDLE&&!load_valid;
 assign query_response_valid=qs==Q_REPORT;
 assign quiescent=ls==L_IDLE&&qs==Q_IDLE;
 wire [1:0] command_op=loaded_command[1:0];
 wire [31:0] command_address=loaded_command[33:2];
 wire [15:0] command_words=loaded_command[49:34];
 wire [511:0] descriptor=loaded_command[561:50];
 wire [255:0] cfg=loaded_command[817:562];
 wire [31:0] opcode=descriptor[31:0],source0=descriptor[63:32],source1=descriptor[95:64],destination=descriptor[127:96],count=descriptor[159:128];
 wire [31:0] out_start=active_row[67:36],out_bytes=active_row[99:68];
 wire [15:0] out_role={8'd0,active_row[27:20]}+1;
 wire [31:0] conv_bytes=({16'd0,cfg[95:80]}*{16'd0,cfg[127:112]})<<2;
 reg match_allowed,match_static;reg [15:0] match_role;
 reg [31:0] match_start,match_end,match_write_start,match_write_end;
 reg [71:0] input_row;reg [31:0] input_start,input_bytes;reg [15:0] input_role;
 reg [31:0] transfer_start,transfer_end;
 integer i;
 // Select the producing tensor using the authenticated command's graph row.
 // There are no overlapping simultaneously-live distinct input tensors (the
 // offline compiler independently checks that property for all201 graph ops).
 always @*begin
  match_allowed=0;match_static=0;match_role=0;match_start=0;match_end=0;
  match_write_start=0;match_write_end=0;input_row=0;input_start=0;input_bytes=0;input_role=0;
  transfer_start=0;transfer_end=0;
  if(saved_address[4:0]==0&&live)begin
   if(!saved_write&&command_op==1)begin
    match_start=command_address;match_end=command_address+({16'd0,command_words}<<5);
    match_allowed=command_address>=32'h28000000&&match_end<=32'h286fe8a0&&command_words!=0&&
      saved_address>=match_start&&saved_address<match_end;
    match_static=1;
   end else if(saved_write&&command_op==2)begin
    match_start=command_address;match_end=command_address+conv_bytes;
    match_write_start=match_start;match_write_end=match_end;match_role=16'h8000|out_role;
    match_allowed=active_row[19:16]==2&&conv_bytes!=0&&match_start>=32'h2c000000&&match_end<=32'h2d000000&&
     saved_address>=match_start&&saved_address<match_end;
   end else if(saved_write&&command_op==3)begin
    match_start=out_start;match_end=out_start+out_bytes;match_role=out_role;
    match_write_start=destination;match_write_end=destination+(opcode==8?(count<<2):count);
    match_allowed=opcode<=8&&count!=0&&destination>=out_start&&match_write_end<=match_end&&
      saved_address>=out_start&&saved_address<match_end&&saved_address>={destination[31:5],5'd0}&&saved_address<match_write_end;
   end else if(!saved_write&&command_op==3&&opcode==6)begin
    match_start=source0;match_end=source0+(count<<2);match_role=16'h8000|out_role;
    match_allowed=active_row[19:16]==2&&count!=0&&match_start>=32'h2c000000&&match_end<=32'h2d000000&&saved_address>=match_start&&saved_address<match_end;
   end else if(!saved_write&&command_op==3&&opcode==7)begin
    match_start=32'h21000000;match_end=32'h2104b000;match_role=16'h4001;
    match_allowed=active_row[19:16]==0&&source0==match_start&&saved_address>=match_start&&saved_address<match_end;
   end else if(!saved_write&&(command_op==0||command_op==3))begin
    for(i=0;i<4;i=i+1)begin
     input_row=active_row[100+i*72+:72];input_start=input_row[39:8];input_bytes=input_row[71:40];input_role={8'd0,input_row[7:0]}+1;
     if(i<active_row[35:28]&&saved_address>=input_start&&saved_address<input_start+input_bytes)begin
      transfer_start=input_start;transfer_end=input_start+input_bytes;
      if(command_op==0)begin transfer_start=command_address;transfer_end=command_address+({16'd0,command_words}<<5);end
      else if(opcode==0||opcode==1||opcode==2||opcode==8)begin
       transfer_start=(opcode==2&&i==1)?source1:source0;transfer_end=transfer_start+count;
      end
      if(saved_address>={transfer_start[31:5],5'd0}&&saved_address<transfer_end)begin
       match_allowed=command_op==0||opcode==0||opcode==1||opcode==2||opcode==3||opcode==4||opcode==5||opcode==8;
       match_start=input_start;match_end=input_start+input_bytes;match_role=input_role;
      end
     end
    end
   end
  end
 end
 wire [32:0] end_distance={1'b0,selected_end}-{1'b0,saved_address};
 wire [31:0] tensor_mask=end_distance>=32?32'hffffffff:((33'd1<<end_distance[5:0])-1);
 wire [32:0] write_distance={1'b0,write_end}-{1'b0,saved_address};
 wire [31:0] write_high=write_distance>=32?32'hffffffff:((33'd1<<write_distance[5:0])-1);
 wire [31:0] write_low=saved_address>=write_start?32'hffffffff:(32'hffffffff<<(write_start-saved_address));
 always @(posedge clk)begin
  if(!rst_n)begin
   ls<=L_IDLE;qs<=Q_IDLE;low<=0;high<=201;mid<=0;row<=0;active_row<=0;context_valid<=0;aborted<=0;
   load_response_valid<=0;load_allowed<=0;loaded_index<=0;loaded_epoch<=0;loaded_command<=0;
   saved_write<=0;saved_address<=0;saved_strobe<=0;selected_start<=0;selected_end<=0;write_start<=0;write_end<=0;
   selected_allowed<=0;selected_static<=0;selected_role<=0;
   query_allowed<=0;query_static<=0;query_role<=0;query_shape<=0;query_mask<=0;query_static_object<=0;query_static_offset<=0;response_address<=0;
  end else begin
   load_response_valid<=0;load_allowed<=0;
   if(context_valid&&(!authorized||authorization_epoch!=loaded_epoch||cancel))begin context_valid<=0;aborted<=1;end
   case(ls)
    L_IDLE:if(load_valid&&load_ready)begin
     loaded_index<=load_index;loaded_epoch<=load_epoch;loaded_command<=load_command;
     context_valid<=0;aborted<=0;low<=0;high<=201;
     if(!authorized||cancel||!load_verified||load_epoch!=authorization_epoch||load_index>=58814||load_command[831:818]!=0)ls<=L_REPORT;
     else ls<=L_READ;
    end
    L_READ:begin
     if(low+1>=high)ls<=L_FINAL;
     else begin mid<=midpoint[7:0];row<=metadata[midpoint[7:0]];ls<=L_CHECK;end
    end
    L_CHECK:begin if(row[15:0]<=loaded_index)low<=mid;else high<=mid;ls<=L_READ;end
    L_FINAL:begin row<=metadata[low];ls<=L_STORE;end
    L_STORE:begin
     active_row<=row;
     context_valid<=authorized&&!cancel&&authorization_epoch==loaded_epoch&&!aborted&&row[27:20]==low&&row[19:16]<=8&&row[35:28]<=4&&row[15:0]<=loaded_index;
     ls<=L_REPORT;
    end
    L_REPORT:begin load_response_valid<=1;load_allowed<=context_valid&&authorized&&!cancel&&authorization_epoch==loaded_epoch&&!aborted;ls<=L_IDLE;end
    default:begin context_valid<=0;ls<=L_REPORT;end
   endcase
   case(qs)
    Q_IDLE:if(query_valid&&query_ready)begin saved_write<=query_write;saved_address<=query_address;saved_strobe<=query_strobe;qs<=Q_CALCULATE;end
    Q_CALCULATE:begin
     selected_allowed<=match_allowed;selected_static<=match_static;selected_start<=match_start;selected_end<=match_end;
     selected_role<=match_role;write_start<=match_write_start;write_end<=match_write_end;qs<=Q_MASK;
    end
    Q_MASK:begin
     query_allowed<=selected_allowed&&live&&(!saved_write||(saved_strobe!=0&&(saved_strobe&~(write_high&write_low))==0));
     query_static<=selected_static;query_role<=selected_role;query_shape<=selected_role;query_mask<=tensor_mask;
     query_static_object<=selected_static?295:0;query_static_offset<=saved_address-32'h28000000;response_address<=saved_address;qs<=Q_REPORT;
    end
    Q_REPORT:if(query_response_ready)qs<=Q_IDLE;
   endcase
  end
 end
endmodule

