`timescale 1ns/1ps
// Direct internal command adapter to the existing yolo_ddr_engine interface.
// The trusted controller selects ownership before valid is offered; all raw
// PS control writes must remain blocked for the entire frame, including gaps.
module trusted_yolo_command_adapter(
 input wire [831:0] instruction,input wire instruction_valid,
 output wire instruction_ready,
 output wire cmd_valid,input wire cmd_ready,
 output wire [1:0] cmd_op,output wire [31:0] cmd_address,
 output wire [15:0] cmd_words,output wire [11:0] cmd_local_address,
 output wire [511:0] cfg_descriptor,
 output wire [15:0] cfg_input_h,cfg_input_w,cfg_input_row0,cfg_input_rows,
 output wire [15:0] cfg_channel_blocks,cfg_output_w,cfg_output_row0,cfg_output_rows,
 output wire [3:0] cfg_kernel,cfg_stride,cfg_padding,
 output wire [7:0] cfg_zero_point,output wire signed [31:0] cfg_bias
);
 assign instruction_ready=cmd_ready;
 assign cmd_valid=instruction_valid;
 assign cmd_op=instruction[1:0];
 assign cmd_address=instruction[33:2];
 assign cmd_words=instruction[49:34];
 assign cmd_local_address=12'd0;
 assign cfg_descriptor=instruction[561:50];
 assign cfg_input_h=instruction[577:562];
 assign cfg_input_w=instruction[593:578];
 assign cfg_input_row0=instruction[609:594];
 assign cfg_input_rows=instruction[625:610];
 assign cfg_channel_blocks=instruction[641:626];
 assign cfg_output_w=instruction[657:642];
 assign cfg_output_row0=instruction[673:658];
 assign cfg_output_rows=instruction[689:674];
 assign cfg_kernel=instruction[693:690];
 assign cfg_stride=instruction[697:694];
 assign cfg_padding=instruction[701:698];
 assign cfg_zero_point=instruction[709:702];
 assign cfg_bias=instruction[741:710];
endmodule
