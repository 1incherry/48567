// Experimental3-round-per-cycle (22 iterations, final iteration has one valid step) SHA256 compression with carry-save multioperand sums.
// The caller supplies the 512-bit message block and the incoming chaining
// value. Padding and message-length handling belong to a higher-level stream
// controller.
// Isolated controlled ablation. Same adders, K predecode, interface and FSM.
// Select 1 or 3 valid rounds on each working edge; default preserves baseline.
module sha256_compress3_csa #(
`ifdef SLH_SHA256_UNROLL1
    parameter integer ROUNDS_PER_CYCLE = 1
`else
    parameter integer ROUNDS_PER_CYCLE = 3
`endif
) (
    input  logic         clk,
    input  logic         rst_n,
    input  logic         start,
    input  logic [511:0] block,
    input  logic [255:0] iv,
    output logic         busy,
    output logic         done,
    output logic [255:0] state_out
);
    // synopsys translate_off
    initial begin
        if (ROUNDS_PER_CYCLE != 1 && ROUNDS_PER_CYCLE != 3)
            $fatal(1,"R139_UNSUPPORTED_ROUNDS_PER_CYCLE");
    end
    // synopsys translate_on
    logic [31:0] h0,h1,h2,h3,h4,h5,h6,h7;
    logic [31:0] a,b,c,d,e,f,g,h;
    // Sliding schedule: W[t] at slot 0; generate W[t+16] at slot 15.
    logic [31:0] w [0:15];
    logic [6:0] round;
    logic [31:0] round_k[0:2];
    logic [31:0] va[0:3],vb[0:3],vc[0:3],vd[0:3];
    logic [31:0] ve[0:3],vf[0:3],vg[0:3],vh[0:3];
    logic [31:0] nextw[0:2],rt1[0:2],rt2[0:2];
    logic [63:0] rt1_carrysave[0:2];
    typedef enum logic [1:0] {IDLE, ROUND, FINISH} st_t;
    st_t st;

    function automatic [31:0] rotr(input [31:0] x, input integer n);
        rotr = (x >> n) | (x << (32-n));
    endfunction
    function automatic [31:0] ch(input [31:0] x, input [31:0] y, input [31:0] z);
        ch = (x & y) ^ (~x & z);
    endfunction
    function automatic [31:0] maj(input [31:0] x, input [31:0] y, input [31:0] z);
        maj = (x & y) ^ (x & z) ^ (y & z);
    endfunction
    function automatic [31:0] bs0(input [31:0] x);
        bs0 = rotr(x,2) ^ rotr(x,13) ^ rotr(x,22);
    endfunction
    function automatic [31:0] bs1(input [31:0] x);
        bs1 = rotr(x,6) ^ rotr(x,11) ^ rotr(x,25);
    endfunction
    function automatic [31:0] ss0(input [31:0] x);
        ss0 = rotr(x,7) ^ rotr(x,18) ^ (x >> 3);
    endfunction
    function automatic [31:0] ss1(input [31:0] x);
        ss1 = rotr(x,17) ^ rotr(x,19) ^ (x >> 10);
    endfunction
    function automatic [31:0] kconst(input integer i);
        case (i)
          0:kconst=32'h428a2f98; 1:kconst=32'h71374491; 2:kconst=32'hb5c0fbcf; 3:kconst=32'he9b5dba5;
          4:kconst=32'h3956c25b; 5:kconst=32'h59f111f1; 6:kconst=32'h923f82a4; 7:kconst=32'hab1c5ed5;
          8:kconst=32'hd807aa98; 9:kconst=32'h12835b01; 10:kconst=32'h243185be; 11:kconst=32'h550c7dc3;
          12:kconst=32'h72be5d74; 13:kconst=32'h80deb1fe; 14:kconst=32'h9bdc06a7; 15:kconst=32'hc19bf174;
          16:kconst=32'he49b69c1; 17:kconst=32'hefbe4786; 18:kconst=32'h0fc19dc6; 19:kconst=32'h240ca1cc;
          20:kconst=32'h2de92c6f; 21:kconst=32'h4a7484aa; 22:kconst=32'h5cb0a9dc; 23:kconst=32'h76f988da;
          24:kconst=32'h983e5152; 25:kconst=32'ha831c66d; 26:kconst=32'hb00327c8; 27:kconst=32'hbf597fc7;
          28:kconst=32'hc6e00bf3; 29:kconst=32'hd5a79147; 30:kconst=32'h06ca6351; 31:kconst=32'h14292967;
          32:kconst=32'h27b70a85; 33:kconst=32'h2e1b2138; 34:kconst=32'h4d2c6dfc; 35:kconst=32'h53380d13;
          36:kconst=32'h650a7354; 37:kconst=32'h766a0abb; 38:kconst=32'h81c2c92e; 39:kconst=32'h92722c85;
          40:kconst=32'ha2bfe8a1; 41:kconst=32'ha81a664b; 42:kconst=32'hc24b8b70; 43:kconst=32'hc76c51a3;
          44:kconst=32'hd192e819; 45:kconst=32'hd6990624; 46:kconst=32'hf40e3585; 47:kconst=32'h106aa070;
          48:kconst=32'h19a4c116; 49:kconst=32'h1e376c08; 50:kconst=32'h2748774c; 51:kconst=32'h34b0bcb5;
          52:kconst=32'h391c0cb3; 53:kconst=32'h4ed8aa4a; 54:kconst=32'h5b9cca4f; 55:kconst=32'h682e6ff3;
          56:kconst=32'h748f82ee; 57:kconst=32'h78a5636f; 58:kconst=32'h84c87814; 59:kconst=32'h8cc70208;
          60:kconst=32'h90befffa; 61:kconst=32'ha4506ceb; 62:kconst=32'hbef9a3f7; 63:kconst=32'hc67178f2;
          default:kconst=32'b0;
        endcase
    endfunction

    // Explicit parallel prefix carry tree; modulo 2^32, no sequential stage.
    function automatic [31:0] add32_prefix(input [31:0] x,y);
        reg [31:0] pp[0:5],gg[0:5];
        integer level,bit_index;
        begin
            pp[0]=x^y;gg[0]=x&y;
            for(level=0;level<5;level=level+1)begin
                for(bit_index=0;bit_index<32;bit_index=bit_index+1)begin
                    if(bit_index>=(1<<level))begin
                        gg[level+1][bit_index]=gg[level][bit_index] | (pp[level][bit_index]&gg[level][bit_index-(1<<level)]);
                        pp[level+1][bit_index]=pp[level][bit_index]&pp[level][bit_index-(1<<level)];
                    end else begin
                        gg[level+1][bit_index]=gg[level][bit_index];pp[level+1][bit_index]=pp[level][bit_index];
                    end
                end
            end
            add32_prefix=pp[0]^{gg[5][30:0],1'b0};
            // synopsys translate_off
            // Retain the original Verilog + behavior for any X/Z operand.
            if(((^x)===1'bx)||((^y)===1'bx))add32_prefix=x+y;
            // synopsys translate_on
        end
    endfunction

    // Carry-save reduction performs modulo2^32 addition of five operands
    // using bitwise3:2 compressors followed by one carry-propagating adder.
    function automatic [31:0] add5(input [31:0] x0,x1,x2,x3,x4);
        reg [31:0] s0,c0,s1,c1,s2,c2;
        begin
            s0=x0^x1^x2;c0=((x0&x1)|(x0&x2)|(x1&x2))<<1;
            s1=s0^c0^x3;c1=((s0&c0)|(s0&x3)|(c0&x3))<<1;
            s2=s1^c1^x4;c2=((s1&c1)|(s1&x4)|(c1&x4))<<1;
            add5=add32_prefix(s2,c2);
        end
    endfunction
    // Keep T1 as two carry-save terms until the final A/E sums.
    // Each result has one carry-propagating addition; no new register/cycle.
    function automatic [63:0] carrysave5(input [31:0] x0,x1,x2,x3,x4);
        reg [31:0] s0,c0,s1,c1,s2,c2;
        begin
            s0=x0^x1^x2;c0=((x0&x1)|(x0&x2)|(x1&x2))<<1;
            s1=s0^c0^x3;c1=((s0&c0)|(s0&x3)|(c0&x3))<<1;
            s2=s1^c1^x4;c2=((s1&c1)|(s1&x4)|(c1&x4))<<1;
            carrysave5={s2,c2};
        end
    endfunction
    function automatic [31:0] add3(input [31:0] x0,x1,x2);
        reg [31:0] s0,c0;
        begin
            s0=x0^x1^x2;c0=((x0&x1)|(x0&x2)|(x1&x2))<<1;
            add3=add32_prefix(s0,c0);
        end
    endfunction
    function automatic [31:0] add4(input [31:0] x0,x1,x2,x3);
        reg [31:0] s0,c0,s1,c1;
        begin
            s0=x0^x1^x2;c0=((x0&x1)|(x0&x2)|(x1&x2))<<1;
            s1=s0^c0^x3;c1=((s0&c0)|(s0&x3)|(c0&x3))<<1;
            add4=add32_prefix(s1,c1);
        end
    endfunction
    always_comb begin
        va[0]=a;vb[0]=b;vc[0]=c;vd[0]=d;
        ve[0]=e;vf[0]=f;vg[0]=g;vh[0]=h;
        nextw[0]=add5(ss1(w[14]),w[9],ss0(w[1]),w[0],0);
        nextw[1]=add5(ss1(w[15]),w[10],ss0(w[2]),w[1],0);
        nextw[2]=add5(ss1(nextw[0]),w[11],ss0(w[3]),w[2],0);
        for(integer r=0;r<3;r++)begin
            if(r<ROUNDS_PER_CYCLE && round+r<64)begin
            rt1[r]=add5(vh[r],bs1(ve[r]),ch(ve[r],vf[r],vg[r]),round_k[r],w[r]);
            rt1_carrysave[r]=carrysave5(vh[r],bs1(ve[r]),ch(ve[r],vf[r],vg[r]),round_k[r],w[r]);
            rt2[r]=bs0(va[r])+maj(va[r],vb[r],vc[r]);
            va[r+1]=add4(rt1_carrysave[r][63:32],rt1_carrysave[r][31:0],bs0(va[r]),maj(va[r],vb[r],vc[r]));vb[r+1]=va[r];vc[r+1]=vb[r];vd[r+1]=vc[r];
            ve[r+1]=add3(rt1_carrysave[r][63:32],rt1_carrysave[r][31:0],vd[r]);vf[r+1]=ve[r];vg[r+1]=vf[r];vh[r+1]=vg[r];
            end else begin
                rt1[r]=0;rt2[r]=0;rt1_carrysave[r]=0;
                va[r+1]=va[r];vb[r+1]=vb[r];vc[r+1]=vc[r];vd[r+1]=vd[r];
                ve[r+1]=ve[r];vf[r+1]=vf[r];vg[r+1]=vg[r];vh[r+1]=vh[r];
            end
        end
    end

    // Predecode next iteration's K triplet on the existing working edge.
    // Start seeds K0/K1/K2; each ROUND prepares K[t+3..t+5]. No new FSM cycle.
    always_ff @(posedge clk)begin
        if(rst_n)begin
            case(st)
              IDLE:if(start)begin
                  round_k[0]<=kconst(0);round_k[1]<=kconst(1);round_k[2]<=kconst(2);
              end
              ROUND:if(round+ROUNDS_PER_CYCLE<64)begin
                  round_k[0]<=kconst(round+ROUNDS_PER_CYCLE);round_k[1]<=kconst(round+ROUNDS_PER_CYCLE+1);round_k[2]<=kconst(round+ROUNDS_PER_CYCLE+2);
              end
              default: ;
            endcase
        end
    end

    integer i;
    // The working variables and message schedule do not require reset: a
    // start transaction initializes a..h and w[0..15], and every later w
    // word is produced before it is consumed.  Keep these datapath registers
    // out of the asynchronously-reset control process.  Vivado otherwise
    // interprets the missing reset assignments as same-priority set/reset
    // behavior (Synth 8-7137), which can differ between RTL and gates.
    always_ff @(posedge clk) begin
        if (rst_n) begin
            case (st)
              IDLE: begin
                  if (start) begin
                      a<=iv[255:224]; b<=iv[223:192]; c<=iv[191:160]; d<=iv[159:128];
                      e<=iv[127:96]; f<=iv[95:64]; g<=iv[63:32]; h<=iv[31:0];
                      for (i=0;i<16;i=i+1) w[i] <= block[511-i*32 -: 32];
                  end
              end
              ROUND: begin
                  a<=va[3];b<=vb[3];c<=vc[3];d<=vd[3];
                  e<=ve[3];f<=vf[3];g<=vg[3];h<=vh[3];
                  for(i=0;i<16-ROUNDS_PER_CYCLE;i=i+1)w[i]<=w[i+ROUNDS_PER_CYCLE];
                  for(i=0;i<ROUNDS_PER_CYCLE;i=i+1)w[16-ROUNDS_PER_CYCLE+i]<=nextw[i];
              end
              default: ;
            endcase
        end
    end

    always_ff @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            st<=IDLE; busy<=0; done<=0; state_out<='0; round<='0;
            h0<='0; h1<='0; h2<='0; h3<='0; h4<='0; h5<='0; h6<='0; h7<='0;
        end else begin
            done<=0;
            case (st)
              IDLE: begin
                  busy<=0;
                  if (start) begin
                      busy<=1; round<=0;
                      h0<=iv[255:224]; h1<=iv[223:192]; h2<=iv[191:160]; h3<=iv[159:128];
                      h4<=iv[127:96]; h5<=iv[95:64]; h6<=iv[63:32]; h7<=iv[31:0];
                      st<=ROUND;
                  end
              end
              ROUND: begin
                  if (round+ROUNDS_PER_CYCLE >= 64) begin
                      // Capture the last valid round state in a..h first.
                      // Feed-forward is a separate completion cycle.
                      st<=FINISH;
                  end else round<=round+ROUNDS_PER_CYCLE;
              end
              FINISH: begin
                  state_out<={h0+a,h1+b,h2+c,h3+d,h4+e,h5+f,h6+g,h7+h};
                  busy<=0; done<=1; st<=IDLE;
              end
              default: st<=IDLE;
            endcase
        end
    end
endmodule
