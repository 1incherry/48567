`timescale 1ns/1ps
// Same 256-bit CBC-MAC mathematics and same two existing v788 round cores.
// Start is a single admission pulse per block. clear withdraws the result,
// then DRAINS real accepted encryptions; busy never advertises a false idle.
// This block is one shared service, not one instance per tensor/consumer.
// rst_n must come only from the trusted security-reset domain.
module trusted_sm4_cbc_mac256_drain #(
 parameter integer CORE_ROUNDS_PER_CYCLE=2
)(
 input wire clk,rst_n,clear,start,
 input wire [127:0] key,chain_in,input wire [255:0] data_in,
 output wire busy,output reg done,output reg [127:0] tag_out
);
 localparam IDLE=0,START0=1,WAIT0=2,START1=3,WAIT1=4,DRAIN=5;
 reg [2:0] state;
 reg [127:0] saved_key,saved_chain;
 reg [255:0] saved_data;
 wire b0,b1,d0,d1;wire [127:0] c0,c1;
 wire s0=state==START0&&!clear;
 wire s1=state==START1&&!clear;
 assign busy=state!=IDLE||b0||b1||done;
 v788_sm4_encrypt_iter #(.ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_mac0(
  .clk(clk),.rst_n(rst_n),.start(s0),.key(saved_key),
  .block_in(saved_data[255:128]^saved_chain),.busy(b0),.done(d0),.block_out(c0));
 v788_sm4_encrypt_iter #(.ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_mac1(
  .clk(clk),.rst_n(rst_n),.start(s1),.key(saved_key),
  .block_in(saved_data[127:0]^c0),.busy(b1),.done(d1),.block_out(c1));
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;done<=0;tag_out<=0;saved_key<=0;saved_chain<=0;saved_data<=0;end
  else begin
   done<=0;
   if(clear&&state!=IDLE)begin state<=DRAIN;tag_out<=0;end
   else case(state)
    IDLE:if(start&&!clear&&!b0&&!b1&&!done)begin
     saved_key<=key;saved_chain<=chain_in;saved_data<=data_in;state<=START0;
    end
    START0:state<=WAIT0;
    WAIT0:if(d0)state<=START1;
    START1:state<=WAIT1;
    WAIT1:if(d1)begin tag_out<=c1;done<=1;state<=IDLE;end
    DRAIN:if(!b0&&!b1&&!d0&&!d1)state<=IDLE;
    default:begin state<=DRAIN;tag_out<=0;end
   endcase
  end
 end
endmodule
