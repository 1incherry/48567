`timescale 1ns/1ps
// Trusted object policy ROM. expected_* signals must originate in the PL
// sequencer, never in CPU-controlled registers. A matching signed page alone
// cannot authorize swapping two tensors with different object/context roles.
module npu_static_object_map_v2_lutram #(
 parameter ROM_FILE="model_object_policy_v2.mem"
)(input wire clk,rst_n,model_authorized,input wire [31:0] session_epoch,
 input wire request_valid,output wire request_ready,
 input wire [8:0] requested_object,expected_object,
 input wire [31:0] byte_offset,input wire [15:0] byte_count,
 input wire [3:0] expected_kind,expected_block,expected_qkv_op,
 input wire [4:0] expected_dst,expected_stage,
 output wire response_valid,input wire response_ready,
 output wire response_allowed,output wire [31:0] page_index,page_address,proof_address,
 output wire [11:0] page_offset,output wire [15:0] allowed_bytes);
 (* rom_style="distributed" *) reg [79:0] policy[0:511];
 initial $readmemh(ROM_FILE,policy);
 reg pending,valid,allowed;reg [79:0] record;
 reg [31:0] saved_offset,saved_epoch;reg [15:0] saved_count;
 reg [8:0] saved_object,saved_expected_object;
 reg [3:0] saved_kind,saved_block,saved_qkv;
 reg [4:0] saved_dst,saved_stage;
 reg [31:0] result_leaf,result_page_addr,result_proof_addr;
 reg [11:0] result_offset;reg [15:0] result_bytes;
 wire live=(model_authorized===1'b1) && ((saved_epoch==session_epoch)===1'b1);
 assign request_ready=!pending&&!valid&&model_authorized&&rst_n;
 assign response_valid=valid&&live&&rst_n;
 assign response_allowed=response_valid&&allowed;
 assign page_index=response_allowed?result_leaf:0;
 assign page_address=response_allowed?result_page_addr:0;
 assign proof_address=response_allowed?result_proof_addr:0;
 assign page_offset=response_allowed?result_offset:0;
 assign allowed_bytes=response_allowed?result_bytes:0;
 wire [32:0] end_offset={1'b0,saved_offset}+{17'd0,saved_count};
 wire [32:0] within_page={21'd0,saved_offset[11:0]}+{17'd0,saved_count};
 wire [31:0] requested_leaf={16'd0,record[47:32]}+(saved_offset>>12);
 wire check_ok=record[70] && saved_object==saved_expected_object &&
  record[51:48]==saved_kind && record[55:52]==saved_block && record[60:56]==saved_dst &&
  record[64:61]==saved_qkv && record[69:65]==saved_stage &&
  saved_count!=0 && saved_count<=4096 && end_offset<={1'b0,record[31:0]} && within_page<=4096 && requested_leaf<24567;
 always @(posedge clk)begin
  if(request_valid&&request_ready)record<=policy[requested_object];
 end
 always @(posedge clk)begin
  if(!rst_n)begin
   pending<=0;valid<=0;allowed<=0;saved_offset<=0;saved_count<=0;saved_epoch<=0;
   saved_object<=0;saved_expected_object<=0;saved_kind<=0;saved_block<=0;saved_dst<=0;saved_qkv<=0;saved_stage<=0;
   result_leaf<=0;result_page_addr<=0;result_proof_addr<=0;result_offset<=0;result_bytes<=0;
  end else begin
   if(valid&&(!live||response_ready))valid<=0;
   if(pending)begin
    pending<=0;valid<=live;allowed<=live&&(check_ok===1'b1);
    result_leaf<=requested_leaf;result_page_addr<=32'h30000000+(requested_leaf<<12);
    result_proof_addr<=32'h38000000+(requested_leaf<<8)+(requested_leaf<<7)+(requested_leaf<<6)+(requested_leaf<<5);
    result_offset<=saved_offset[11:0];result_bytes<=saved_count;
   end
   if(request_valid&&request_ready)begin
    pending<=1;saved_object<=requested_object;saved_expected_object<=expected_object;
    saved_offset<=byte_offset;saved_count<=byte_count;saved_epoch<=session_epoch;
    saved_kind<=expected_kind;saved_block<=expected_block;saved_dst<=expected_dst;
    saved_qkv<=expected_qkv_op;saved_stage<=expected_stage;
   end
  end
 end
endmodule
