`timescale 1ns/1ps
// A single SHA-256 engine with byte input, known length and backpressure.
module slh_sha256_word_stream_shared23 #(parameter integer EXTERNAL_COMPRESSOR=0) (
  input logic clk,rst_n,start,
  input logic [15:0] length,
  input logic seed_hash, output logic seed_cached,
  input logic short_valid,input logic [511:0] short_data,
  input logic valid,input logic [31:0] data,input logic [2:0] input_bytes,
  output logic [2:0] capacity,output logic ready,
  output logic busy,done,fault,output logic [255:0] digest,
  output wire compressor_reset,compressor_start,
  output wire [511:0] compressor_block,output wire [255:0] compressor_iv,
  input wire compressor_busy,compressor_done,input wire [255:0] compressor_state
);
  // Binary synthesis with exact original four-state simulation guards.
  function automatic slh_known_true(input logic value);
    case (value)
      1'b1: slh_known_true=1'b1;
      default: slh_known_true=1'b0;
    endcase
  endfunction
  function automatic slh_known_false(input logic value);
    case (value)
      1'b0: slh_known_false=1'b1;
      default: slh_known_false=1'b0;
    endcase
  endfunction
  function automatic slh_not_x(input logic value);
    case (value)
      // synopsys translate_off
      1'bx: slh_not_x=1'b0;
      // synopsys translate_on
      default: slh_not_x=1'b1;
    endcase
  endfunction
  function automatic slh_case_eq_bit(input logic left_value, right_value);
    case ({left_value,right_value})
      2'b00,2'b11: slh_case_eq_bit=1'b1;
      // synopsys translate_off
      2'bxx,2'bzz: slh_case_eq_bit=1'b1;
      // synopsys translate_on
      default: slh_case_eq_bit=1'b0;
    endcase
  endfunction
  function automatic slh_case_eq_256(input logic [255:0] left_value, right_value);
    case (left_value)
      right_value: slh_case_eq_256=1'b1;
      default: slh_case_eq_256=1'b0;
    endcase
  endfunction

  typedef enum logic [1:0] {IDLE,COLLECT,SEND,WAIT_HASH} state_t;
  state_t state;
  wire sha_start=rst_n&&(state==IDLE)&&start;logic sha_ready,sha_done,sha_fault;
  logic stored_fault;logic [255:0] stored_digest;logic [255:0] forwarded_sha_digest;
  wire completion_forward=rst_n&&(state==WAIT_HASH)&&sha_done;
  assign done=completion_forward;
  assign digest=completion_forward?forwarded_sha_digest:stored_digest;
  assign fault=completion_forward?sha_fault:stored_fault;
  wire [255:0] sha_digest=forwarded_sha_digest;
  logic [511:0] block_data;
  logic [6:0] bytes_in_block;
  logic [15:0] remaining;
  logic final_block;
  logic seed_transaction,seeded_start,prefix_done;
  logic [255:0] seed_state,prefix_state;
  wire use_seed=seed_hash&&seed_cached;
  wire [6:0] room=7'd64-bytes_in_block;
  always_comb begin
    capacity=4;
    if(room<4)capacity=room[2:0];
    if(remaining<capacity)capacity=remaining[2:0];
  end
  assign ready=(state==COLLECT)&&remaining!=0&&input_bytes!=0&&input_bytes<=capacity;
  sha256_stream_shared23 #(.EXTERNAL_COMPRESSOR(EXTERNAL_COMPRESSOR)) u_sha(.clk(clk),.rst_n(rst_n),.start(sha_start),
    .initial_state_valid(use_seed),.initial_state(seed_state),.initial_bytes(7'd64),
    .prefix_done(prefix_done),.prefix_state(prefix_state),
    .block_valid(state==SEND),.block_data(block_data),.block_bytes(bytes_in_block),
    .block_last(final_block),.block_ready(sha_ready),.busy(),.done(sha_done),
    .fault(sha_fault),.digest(forwarded_sha_digest),
      .compressor_reset(compressor_reset),.compressor_start(compressor_start),
      .compressor_block(compressor_block),.compressor_iv(compressor_iv),
      .compressor_busy(compressor_busy),.compressor_done(compressor_done),.compressor_state(compressor_state));
  always_ff @(posedge clk) begin
    if(!rst_n) begin
      state<=IDLE;busy<=0;stored_fault<=0;stored_digest<=0;
      block_data<=0;bytes_in_block<=0;remaining<=0;final_block<=0;
      seed_cached<=0;seed_state<=0;seed_transaction<=0;seeded_start<=0;
    end else begin
      
      // Reset with the enclosing verifier transaction, including abort.
      if(prefix_done&&seed_transaction&&!seed_cached) begin
        seed_state<=prefix_state;seed_cached<=1;
      end
      case(state)
        IDLE:if(start)begin
          busy<=1;stored_fault<=0;remaining<=use_seed?length-16'd64:length;bytes_in_block<=0;
          seed_transaction<=seed_hash;seeded_start<=use_seed;
          block_data<=0;final_block<=length==(use_seed?64:0);
          state<=length==(use_seed?64:0)?SEND:COLLECT;
          // Trusted controller supplies the complete 38/54-byte suffix. Padding
          // remains in sha256_stream; the cached 64-byte state is unchanged.
          if(use_seed && slh_known_true(short_valid) && (length==102 || length==118))begin
            block_data<=short_data;bytes_in_block<=length-64;remaining<=0;
            final_block<=1;state<=SEND;
          end
        end
        COLLECT:if(valid&&ready)begin
          for(integer q=0;q<4;q=q+1)if(q<input_bytes)
            block_data[511-(bytes_in_block+q)*8 -:8]<=data[31-q*8-:8];
          bytes_in_block<=bytes_in_block+input_bytes;remaining<=remaining-input_bytes;
          if(remaining==input_bytes || bytes_in_block+input_bytes==64)begin
            final_block<=remaining==input_bytes;state<=SEND;
          end
        end
        SEND:if(sha_ready)begin
          if(final_block)state<=WAIT_HASH;
          else begin bytes_in_block<=0;block_data<=0;state<=COLLECT;end
        end
        WAIT_HASH:if(sha_done)begin
          stored_digest<=sha_digest;stored_fault<=sha_fault;busy<=0;state<=IDLE;
        end
        default:state<=IDLE;
      endcase
    end
  end
endmodule
