`timescale 1ns/1ps
// Six NCHW Q8 head attributes -> decode. Metadata is checked against the
// immutable frozen graph roles153/176/197 (+1 so zero is invalid). The backend
// MUST be the shared consumption-time tensor MAC path, never raw AXI+CRC.
module trusted_yolo_head_reader(
 input wire clk,rst_n,cancel,authorized,input wire [31:0] authorization_epoch,
 input wire request_valid,output wire request_ready,
 input wire [12:0] request_index,input wire [31:0] request_base,
 input wire [10:0] request_plane,request_cell,input wire [1:0] request_anchor,
 input wire [31:0] request_session,request_frame,request_epoch,
 output reg response_valid,response_verified,output reg [12:0] response_index,
 output reg [31:0] response_session,response_frame,response_epoch,
 output wire [47:0] response_codes,output wire quiescent,
 output wire beat_request,input wire beat_ready,
 output wire [31:0] beat_address,beat_mask,beat_session,beat_frame,beat_epoch,
 output wire [15:0] beat_role,beat_shape,
 input wire beat_response_valid,beat_verified,input wire [255:0] beat_data,
 input wire [31:0] beat_response_address,beat_response_session,beat_response_frame,beat_response_epoch,
 input wire backend_quiescent
);
 localparam IDLE=0,OFFSET=1,ADDRESS=2,READ=3,REPLY=4,REPORT=5;
 reg [2:0] state,attribute;
 reg [1:0] layer,anchor;
 reg [10:0] plane,cell_index;
 reg [31:0] base,offset,address;
 reg [47:0] codes;
 reg good,aborted;
 wire live=authorized&&authorization_epoch==response_epoch&&!cancel&&!aborted;
 wire [1:0] request_layer=request_index<4800?0:request_index<6000?1:2;
 wire [31:0] expected_base=request_layer==0?32'h2e00fa00:request_layer==1?32'h2e006400:32'h2e000000;
 wire [10:0] expected_plane=request_layer==0?1600:request_layer==1?400:100;
 wire [13:0] expected_index=(request_layer==0?14'd0:request_layer==1?14'd4800:14'd6000)+request_anchor*expected_plane+request_cell;
 assign request_ready=state==IDLE&&backend_quiescent;
 assign quiescent=state==IDLE&&backend_quiescent;
 assign response_codes=codes;
 assign beat_request=state==READ;
 assign beat_address={address[31:5],5'd0};
 assign beat_mask=(layer==2&&beat_address==32'h2e000700)?32'h000000ff:32'hffffffff;
 assign beat_session=response_session;
 assign beat_frame=response_frame;
 assign beat_epoch=response_epoch;
 assign beat_role=layer==0?16'd154:layer==1?16'd177:16'd198;
 assign beat_shape=beat_role;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;attribute<=0;layer<=0;anchor<=0;plane<=0;cell_index<=0;base<=0;offset<=0;address<=0;
   codes<=0;good<=0;aborted<=0;response_valid<=0;response_verified<=0;
   response_index<=0;response_session<=0;response_frame<=0;response_epoch<=0;
  end else begin
   response_valid<=0;response_verified<=0;
   if(state!=IDLE&&!live)aborted<=1;
   case(state)
    IDLE:if(request_valid&&request_ready)begin
     response_index<=request_index;response_session<=request_session;response_frame<=request_frame;response_epoch<=request_epoch;
     layer<=request_layer;anchor<=request_anchor;plane<=expected_plane;cell_index<=request_cell;base<=expected_base;
     attribute<=0;codes<=0;good<=0;aborted<=0;
     if(!authorized||cancel||request_epoch!=authorization_epoch||request_session==0||request_frame==0||request_index>=6300||
        request_base!=expected_base||request_plane!=expected_plane||request_anchor>=3||request_cell>=expected_plane||expected_index!=request_index)state<=REPORT;
     else state<=OFFSET;
    end
    OFFSET:begin
     offset<=(anchor*6+attribute)*plane;
     if(!live)state<=REPORT;else state<=ADDRESS;
    end
    ADDRESS:begin address<=base+offset+cell_index;state<=READ;end
    READ:if(beat_ready)state<=REPLY;
    REPLY:if(beat_response_valid)begin
     if(!live||!beat_verified||beat_response_address!=beat_address||beat_response_session!=response_session||
        beat_response_frame!=response_frame||beat_response_epoch!=response_epoch)state<=REPORT;
     else begin
      codes[attribute*8+:8]<=beat_data[address[4:0]*8+:8];
      if(attribute==5)begin good<=1;state<=REPORT;end
      else begin attribute<=attribute+1;state<=OFFSET;end
     end
    end
    REPORT:if(backend_quiescent)begin response_valid<=1;response_verified<=good&&live;state<=IDLE;end
    default:begin good<=0;state<=REPORT;end
   endcase
  end
 end
endmodule
