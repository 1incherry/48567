`timescale 1ns/1ps
// DDR RGB888 -> separable bilinear (22-bit coefficients) -> signed Q8 ->
// patch projection -> Q29 position add -> shared runtime Norm1 -> QKV layout.
// Coefficients describe geometry only. All image/tensor arithmetic is hardware.
// Exclusive owner 3 leases the existing OutProj A/B and the Norm3 kernel.
module frontend_ddr_engine(
 input wire clk,rst_n,go,output reg busy,done,error,
 input wire [31:0] source_base,source_stride,roi_xy,roi_wh,crop_base,temp_base,param_base,
 input wire [31:0] seed_base,pose_base,x_base,source_wh,reserved,
 output wire [31:0] M_AXI_ARADDR,output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,input wire [1:0] M_AXI_RRESP,input wire M_AXI_RLAST,M_AXI_RVALID,
 output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,output wire [31:0] M_AXI_WSTRB,output wire M_AXI_WLAST,M_AXI_WVALID,
 input wire M_AXI_WREADY,input wire [1:0] M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY,
 output reg a_write,b_write,a_read,b_read,output reg [11:0] write_address,a_address,b_address,
 output reg [255:0] write_data,input wire [255:0] a_data,b_data,
 output reg norm_clear,norm_start,norm_input_valid,
 output reg [15:0] norm_input_address,output reg signed [15:0] norm_input_data,
 output reg norm_scale_valid,norm_bias_valid,output reg [7:0] norm_param_address,
 output reg signed [31:0] norm_param_data,
 output wire norm_ready,input wire norm_valid,norm_done,
 output reg [31:0] perf_total,perf_param,perf_resize,perf_embed,perf_norm,perf_ar,perf_aw,
 input wire [15:0] norm_address,input wire signed [15:0] norm_data
);
 localparam IDLE=0,R_ADDR=1,R_DATA=2,W_SEND=3,W_RESP=4,FAIL=5,R_LOOKUP=6,W_QUEUE=7,W_FLUSH=8,GEO_WAIT=9;
 localparam INIT=10,PARAM_READ=11,PARAM_GOT=12,GEO_LOAD=13,GEO_GOT=14,GEO_NEXT=15,GEO_CAPTURE=16,RS_COPY=17,RS_COPY_STORE=18;
 localparam RS_HEADER=20,RS_COUNT=21,RS_BEGIN=22,RS_COEF=23,RS_PIXEL=24,RS_ACC=25,RS_STORE=26,RS_NEXT=27;
 localparam PATCH_BEGIN=30,PATCH_GOT=31,PATCH_NEXT=32,W_LOAD=33,W_GOT=34,W_NEXT=35;
 localparam DOT_BIAS_READ=36,DOT_BIAS_WAIT=37,DOT_BIAS=38,DOT_READ=39,DOT_WAIT=40,DOT_MUL=41,DOT_ACC=42;
 localparam POS_COEF=43,POS_MUL=44,POS_CLS=45,POS_ADD=46,POS_STORE=47,POSE_MUL=48,POSE_STORE=49,OC_NEXT=50;
 localparam PAD=51,NORM_START=52,NORM_WAIT=53,NORM_NEXT=54,NORM_EXT=55,FINISH=56,PIXEL_WAIT=57,PIXEL_CAPTURE=58,
            PATCH_ADDR0=59,PATCH_ADDR1=60;
 reg [7:0] state,return_state;
 reg [1:0] perf_phase;
 reg [31:0] read_addr,request_addr,write_addr,cache_addr,scalar;
 reg [255:0] read_word,cache_data,write_word;
 reg [31:0] strobes;
 reg [4:0] byte_offset;
 reg cache_valid,aw_sent,w_sent;
 reg [31:0] combine_addr,combine_strobes,pending_addr;
 reg [255:0] combine_data;
 reg [15:0] pending_value;
 reg pending_halfword;
 reg [7:0] pending_return,flush_return,dependency_return;
 reg [11:0] geo_beat;
 reg geometry_ready,identity_geometry;
 reg coefficient_valid,coefficient_vertical;
 reg [15:0] coefficient_dx,coefficient_first;
 reg [5:0] coefficient_count;
 (* ram_style="distributed" *) reg signed [31:0] coefficients[0:31];
 reg [127:0] pixel_valid;
 (* ram_style="distributed" *) reg [19:0] pixel_tags[0:127];
 wire [31:0] geo_x_start=param_base+32'h78000;
 wire [31:0] geo_y_start=param_base+32'h82000;
 wire geo_x_hit=request_addr>=geo_x_start&&request_addr<geo_x_start+35840;
 wire geo_y_hit=request_addr>=geo_y_start&&request_addr<geo_y_start+35840;
 reg [15:0] rx,ry,rw,rh;
 wire identity_resize=(rw==224&&rh==224&&identity_geometry);
 reg [15:0] row,dx;
 reg [1:0] channel;
 reg vertical;
 reg [5:0] tap,taps;
 reg [15:0] first_sample;
 reg signed [31:0] coefficient;
 reg signed [47:0] filter_sum;
 reg [9:0] param_index;
 reg signed [31:0] pose_coef;
 reg [7:0] token,oc;
 reg [9:0] feature;
 reg [5:0] weight_beat,vector;
 reg [255:0] patch_word;
 reg [127:0] activation_vector;
 reg [255:0] weight_vector;
 reg signed [23:0] product[0:15];
 wire signed [31:0] pair[0:7],quad[0:3],oct[0:1];
 wire signed [31:0] vector_sum=oct[0]+oct[1];
 reg signed [31:0] accumulator,position_coef,cls_value;
 reg signed [63:0] wide;
 reg signed [15:0] x_value;
 reg [15:0] pad_index;
 reg norm_done_seen;
 reg [15:0] held_norm_address;reg signed [15:0] held_norm_data;
 reg [7:0] ext_row;reg [1:0] ext_col;
 integer i;
 wire [1:0] patch_channel=feature[9:8];
 wire [7:0] quant;
 frontend_quant_lut u_quant(.channel(patch_channel),.pixel(scalar[7:0]),.q(quant));
 function automatic [15:0] clip16(input signed [63:0] v);
  if(v>32767)clip16=16'h7fff;else if(v< -32768)clip16=16'h8000;else clip16=v[15:0];
 endfunction
 function automatic [7:0] clip8(input signed [47:0] v);
  if(v<0)clip8=0;else if(v>255)clip8=255;else clip8=v[7:0];
 endfunction
 function automatic [31:0] packed16_address(input [31:0] base,input integer index);
  packed16_address=base+(index/16)*32+(15-index%16)*2;
 endfunction
 // This small AXI frontend uses aligned 32-byte reads and byte strobes on writes.
 // One cached line also handles the RGB888/halfword extraction at line borders.
 task automatic read_at(input [31:0] addr,input [7:0] continuation);
 begin
  request_addr<=addr;return_state<=continuation;state<=R_LOOKUP;
 end endtask
 task automatic write_at(input [31:0] addr,input [15:0] value,input halfword,input [7:0] continuation);
 begin
  if(perf_phase==1)begin
   pending_addr<=addr;pending_value<=value;pending_halfword<=halfword;
   pending_return<=continuation;state<=W_QUEUE;
  end else begin
   write_addr<={addr[31:5],5'd0};write_word<={240'd0,value}<<(addr[4:0]*8);
   strobes<=(halfword?32'd3:32'd1)<<addr[4:0];aw_sent<=0;w_sent<=0;
   return_state<=continuation;state<=W_SEND;
   if(cache_addr=={addr[31:5],5'd0})cache_valid<=0;
  end
 end endtask
 task automatic flush_writes(input [7:0] continuation);
 begin flush_return<=continuation;state<=W_FLUSH;end
 endtask
 assign M_AXI_ARADDR=read_addr;assign M_AXI_ARLEN=0;assign M_AXI_ARSIZE=5;
 assign M_AXI_ARBURST=1;assign M_AXI_ARVALID=(state==R_ADDR);assign M_AXI_RREADY=(state==R_DATA);
 assign M_AXI_AWADDR=write_addr;assign M_AXI_AWLEN=0;assign M_AXI_AWSIZE=5;assign M_AXI_AWBURST=1;
 assign M_AXI_AWVALID=(state==W_SEND)&&!aw_sent;
 assign M_AXI_WDATA=write_word;assign M_AXI_WSTRB=strobes;assign M_AXI_WLAST=1;
 assign M_AXI_WVALID=(state==W_SEND)&&!w_sent;assign M_AXI_BREADY=(state==W_RESP);
 assign norm_ready=(state==NORM_WAIT);
 genvar g;
 generate for(g=0;g<16;g=g+1)begin: mul
  always @(posedge clk)if(state==DOT_ACC)
   product[g]<=$signed(activation_vector[g*8+:8])*$signed(weight_vector[g*16+:16]);
 end
 for(g=0;g<8;g=g+1)begin: p
  assign pair[g]={{8{product[g*2][23]}},product[g*2]}+{{8{product[g*2+1][23]}},product[g*2+1]};
 end
 for(g=0;g<4;g=g+1)begin: q assign quad[g]=pair[g*2]+pair[g*2+1];end
 for(g=0;g<2;g=g+1)begin: o assign oct[g]=quad[g*2]+quad[g*2+1];end endgenerate
 wire [31:0] table_base=param_base+(vertical?32'h82000:32'h78000)+dx*160;
 // Token order is row-major. Avoid synthesized division/modulo by 14 on the
 // live DDR address path, and register the remaining pixel address arithmetic.
 reg [3:0] patch_row,patch_col;
 reg [15:0] patch_row_offset,patch_spatial;
 wire [7:0] patch_y={patch_row,feature[7:4]},patch_x={patch_col,feature[3:0]};
 always @(posedge clk)begin
  if(!rst_n||token==0)begin patch_row<=0;patch_col<=0;end
  else if(state==OC_NEXT&&oc==191&&token<196)begin
   if(patch_col==13)begin patch_col<=0;patch_row<=patch_row+1;end
   else patch_col<=patch_col+1;
  end
 end
 always @(posedge clk)begin
  if(!rst_n)begin patch_row_offset<=0;patch_spatial<=0;end
  else if(state==PATCH_BEGIN)patch_row_offset<=patch_y*16'd224;
  else if(state==PATCH_ADDR0)patch_spatial<=patch_row_offset+patch_x;
 end
 wire [31:0] norm_row=held_norm_address/194,norm_col=held_norm_address%194;
 wire [31:0] norm_tile_index=((norm_row/4)*49+norm_col/4)*16+(norm_row%4)*4+norm_col%4;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;busy<=0;done<=0;error<=0;cache_valid<=0;
   combine_addr<=0;combine_strobes<=0;combine_data<=0;pending_addr<=0;pending_value<=0;
   pending_halfword<=0;dependency_return<=0;pending_return<=0;flush_return<=0;geo_beat<=0;geometry_ready<=0;identity_geometry<=1;pixel_valid<=0;coefficient_valid<=0;coefficient_vertical<=0;coefficient_dx<=0;coefficient_first<=0;coefficient_count<=0;
   perf_total<=0;perf_param<=0;perf_resize<=0;perf_embed<=0;perf_norm<=0;perf_ar<=0;perf_aw<=0;perf_phase<=0;
   a_write<=0;b_write<=0;a_read<=0;b_read<=0;write_address<=0;write_data<=0;a_address<=0;b_address<=0;
   norm_clear<=0;norm_start<=0;norm_input_valid<=0;norm_scale_valid<=0;norm_bias_valid<=0;
   norm_input_address<=0;norm_input_data<=0;norm_param_address<=0;norm_param_data<=0;
   norm_done_seen<=0;param_index<=0;rx<=0;ry<=0;rw<=0;rh<=0;
   read_addr<=0;request_addr<=0;write_addr<=0;write_word<=0;strobes<=0;aw_sent<=0;w_sent<=0;
   return_state<=0;byte_offset<=0;cache_addr<=0;cache_data<=0;read_word<=0;scalar<=0;
   row<=0;dx<=0;channel<=0;vertical<=0;tap<=0;taps<=0;first_sample<=0;coefficient<=0;filter_sum<=0;
   pose_coef<=0;token<=0;oc<=0;feature<=0;weight_beat<=0;vector<=0;patch_word<=0;
   activation_vector<=0;weight_vector<=0;accumulator<=0;position_coef<=0;cls_value<=0;wide<=0;
   x_value<=0;pad_index<=0;held_norm_address<=0;held_norm_data<=0;ext_row<=0;ext_col<=0;
  end else begin
   a_write<=0;b_write<=0;a_read<=0;b_read<=0;
   norm_clear<=0;norm_start<=0;norm_input_valid<=0;norm_scale_valid<=0;norm_bias_valid<=0;
   if(norm_done)norm_done_seen<=1;
   if(busy)begin
    perf_total<=perf_total+1;
    case(perf_phase)
     0:perf_param<=perf_param+1;
     1:perf_resize<=perf_resize+1;
     2:perf_embed<=perf_embed+1;
     3:perf_norm<=perf_norm+1;
    endcase
    if(M_AXI_ARVALID&&M_AXI_ARREADY)perf_ar<=perf_ar+1;
    if(M_AXI_AWVALID&&M_AXI_AWREADY)perf_aw<=perf_aw+1;
   end
   case(state)
    IDLE:if(go)begin
     busy<=1;done<=0;error<=0;cache_valid<=0;norm_clear<=1;norm_done_seen<=0;combine_strobes<=0;geometry_ready<=0;identity_geometry<=1;pixel_valid<=0;coefficient_valid<=0;coefficient_vertical<=0;coefficient_dx<=0;coefficient_first<=0;coefficient_count<=0;
     perf_total<=0;perf_param<=0;perf_resize<=0;perf_embed<=0;perf_norm<=0;perf_ar<=0;perf_aw<=0;perf_phase<=0;
     rx<=roi_xy[15:0];ry<=roi_xy[31:16];rw<=roi_wh[15:0];rh<=roi_wh[31:16];
     // The bounded application map is 1GiB PS DDR; reserve top quarter for frontend.
     if(roi_wh[15:0]==0||roi_wh[31:16]==0||roi_wh[15:0]>1920||roi_wh[31:16]>1080||
      ({1'b0,roi_xy[15:0]}+roi_wh[15:0])>source_wh[15:0]||
      ({1'b0,roi_xy[31:16]}+roi_wh[31:16])>source_wh[31:16]||source_stride<source_wh[15:0]*3||
      source_base[31:28]!=2||crop_base[31:28]!=2||temp_base[31:28]!=2||param_base[31:28]!=2||x_base[31:28]!=2||
      source_base[4:0]!=0||crop_base[4:0]!=0||temp_base[4:0]!=0||param_base[4:0]!=0||
      seed_base[4:0]!=0||pose_base[4:0]!=0||x_base[4:0]!=0)state<=FAIL;
     else begin param_index<=0;state<=INIT;end
    end
    INIT:state<=PARAM_READ;
    R_LOOKUP:begin
     byte_offset<=request_addr[4:0];
     if(combine_strobes!=0&&combine_addr=={request_addr[31:5],5'd0})begin
      // A dependent read observes committed data, including partially filled lines.
      write_addr<=combine_addr;write_word<=combine_data;strobes<=combine_strobes;
      aw_sent<=0;w_sent<=0;combine_strobes<=0;dependency_return<=return_state;return_state<=R_LOOKUP;state<=W_SEND;
     end else if(geometry_ready&&perf_phase==1&&(geo_x_hit||geo_y_hit))begin
      b_read<=1;b_address<=geo_x_hit?((request_addr-geo_x_start)>>5):1120+((request_addr-geo_y_start)>>5);
      state<=GEO_WAIT;
     end else if(cache_valid&&cache_addr=={request_addr[31:5],5'd0})begin
      read_word<=cache_data;scalar<=cache_data>>(request_addr[4:0]*8);state<=return_state;
     end else if(perf_phase==1&&pixel_valid[request_addr[11:5]]&&pixel_tags[request_addr[11:5]]==request_addr[31:12])begin
      a_read<=1;a_address<={5'd0,request_addr[11:5]};state<=PIXEL_WAIT;
     end else begin read_addr<={request_addr[31:5],5'd0};state<=R_ADDR;end
    end
    PIXEL_WAIT:state<=PIXEL_CAPTURE;
    PIXEL_CAPTURE:begin
     read_word<=a_data;cache_data<=a_data;cache_addr<={request_addr[31:5],5'd0};cache_valid<=1;
     scalar<=a_data>>(byte_offset*8);state<=return_state;
    end
    GEO_WAIT:state<=GEO_CAPTURE;
    GEO_CAPTURE:begin read_word<=b_data;scalar<=b_data>>(byte_offset*8);state<=return_state;end
    W_QUEUE:begin
     if(combine_strobes==0||combine_addr=={pending_addr[31:5],5'd0})begin
      combine_addr<={pending_addr[31:5],5'd0};
      combine_data<=(combine_strobes==0?256'd0:combine_data)&
       ~( (pending_halfword?256'hffff:256'hff)<<(pending_addr[4:0]*8)) |
       ({240'd0,pending_value}<<(pending_addr[4:0]*8));
      combine_strobes<=(combine_strobes==0?32'd0:combine_strobes)|
       ((pending_halfword?32'd3:32'd1)<<pending_addr[4:0]);
      if(cache_addr=={pending_addr[31:5],5'd0})cache_valid<=0;
      if(pixel_tags[pending_addr[11:5]]==pending_addr[31:12])pixel_valid[pending_addr[11:5]]<=0;
      state<=pending_return;
     end else begin
      write_addr<=combine_addr;write_word<=combine_data;strobes<=combine_strobes;
      aw_sent<=0;w_sent<=0;combine_strobes<=0;return_state<=W_QUEUE;state<=W_SEND;
     end
    end
    W_FLUSH:begin
     if(combine_strobes==0)state<=flush_return;
     else begin
      write_addr<=combine_addr;write_word<=combine_data;strobes<=combine_strobes;
      aw_sent<=0;w_sent<=0;combine_strobes<=0;return_state<=flush_return;state<=W_SEND;
     end
    end
    R_ADDR:if(M_AXI_ARREADY)state<=R_DATA;
    R_DATA:if(M_AXI_RVALID)begin
     if(M_AXI_RRESP!=0||!M_AXI_RLAST)state<=FAIL;
     else begin read_word<=M_AXI_RDATA;cache_data<=M_AXI_RDATA;cache_addr<=read_addr;cache_valid<=1;
      if(perf_phase==1)begin
       a_write<=1;write_address<={5'd0,read_addr[11:5]};write_data<=M_AXI_RDATA;
       pixel_tags[read_addr[11:5]]<=read_addr[31:12];pixel_valid[read_addr[11:5]]<=1;
      end
      scalar<=M_AXI_RDATA>>(byte_offset*8);state<=return_state;end
    end
    W_SEND:begin
     if(M_AXI_AWREADY)aw_sent<=1;if(M_AXI_WREADY)w_sent<=1;
     if((aw_sent||M_AXI_AWREADY)&&(w_sent||M_AXI_WREADY))state<=W_RESP;
    end
    W_RESP:if(M_AXI_BVALID)begin if(M_AXI_BRESP!=0)state<=FAIL;else begin state<=return_state;if(return_state==R_LOOKUP)return_state<=dependency_return;end end
    PARAM_READ:read_at(param_base+((param_index<192)?32'h76000:(param_index<384)?32'h76400:32'h76800)+
      ((param_index<192)?param_index:(param_index<384)?param_index-192:0)*4,PARAM_GOT);
    PARAM_GOT:begin
     norm_param_address<=(param_index<192)?param_index:param_index-192;norm_param_data<=scalar;
     if(param_index<192)norm_scale_valid<=1;else if(param_index<384)norm_bias_valid<=1;else pose_coef<=scalar;
     if(param_index==384)begin geo_beat<=0;state<=GEO_LOAD;end
     else begin param_index<=param_index+1;state<=PARAM_READ;end
    end
    // Both coefficient tables occupy 2240 of the existing 2352 B-bank beats.
    // B is released to the original projection-weight loader after resize.
    GEO_LOAD:read_at((geo_beat<1120?geo_x_start:geo_y_start)+(geo_beat<1120?geo_beat:geo_beat-1120)*32,GEO_GOT);
    GEO_GOT:begin
     if((geo_beat%5)==0&&((read_word[31:0]!=(geo_beat<1120?geo_beat:geo_beat-1120)/5)||
       read_word[95:64]!=4194304||
       !((read_word[63:32]==1)||((read_word[63:32]==2)&&read_word[31:0]<223&&read_word[127:96]==0))))identity_geometry<=0;
     b_write<=1;write_address<=geo_beat;write_data<=read_word;state<=GEO_NEXT;end
    GEO_NEXT:begin
     if(geo_beat==2239)begin
      geometry_ready<=1;perf_phase<=1;row<=0;dx<=0;channel<=0;vertical<=0;
      if(identity_resize)state<=RS_COPY;else state<=RS_HEADER;
     end else begin geo_beat<=geo_beat+1;state<=GEO_LOAD;end
    end
    // Identity resize is exactly a byte copy for the frozen Q22 geometry.
    RS_COPY:read_at(source_base+(ry+row)*source_stride+(rx+dx)*3+channel,RS_COPY_STORE);
    RS_COPY_STORE:write_at(crop_base+(row*224+dx)*3+channel,{8'd0,scalar[7:0]},0,RS_NEXT);
    RS_HEADER:begin
     if(coefficient_valid&&coefficient_dx==dx&&coefficient_vertical==vertical)begin
      first_sample<=coefficient_first;taps<=coefficient_count;tap<=0;filter_sum<=48'sd2097152;state<=RS_COEF;
     end else begin coefficient_valid<=0;read_at(table_base,RS_COUNT);end
    end
    RS_COUNT:begin first_sample<=scalar[15:0];read_at(table_base+4,RS_BEGIN);end
    RS_BEGIN:begin
     if(scalar==0||scalar>32||(first_sample+scalar)>(vertical?rh:rw))state<=FAIL;
     else begin
      taps<=scalar[5:0];tap<=0;filter_sum<=48'sd2097152;state<=RS_COEF;
      coefficient_dx<=dx;coefficient_vertical<=vertical;coefficient_first<=first_sample;coefficient_count<=scalar[5:0];
     end
    end
    RS_COEF:begin
     if(coefficient_valid)begin scalar<=coefficients[tap[4:0]];state<=RS_PIXEL;end
     else read_at(table_base+8+tap*4,RS_PIXEL);
    end
    RS_PIXEL:begin
     coefficient<=scalar;
     if(!coefficient_valid)coefficients[tap[4:0]]<=scalar;
     if(vertical)read_at(temp_base+((first_sample+tap)*224+row)*3+channel,RS_ACC);
     else read_at(source_base+(ry+row)*source_stride+(rx+first_sample+tap)*3+channel,RS_ACC);
    end
    RS_ACC:begin
     filter_sum<=filter_sum+$signed({1'b0,scalar[7:0]})*$signed(coefficient);
     if(tap+1==taps)begin coefficient_valid<=1;state<=RS_STORE;end else begin tap<=tap+1;state<=RS_COEF;end
    end
    RS_STORE:write_at((vertical?crop_base:temp_base)+(vertical?(dx*224+row):(row*224+dx))*3+channel,
      {8'd0,clip8(filter_sum>>>22)},0,RS_NEXT);
    RS_NEXT:begin
     if(channel<2)begin channel<=channel+1;state<=(identity_resize)?RS_COPY:RS_HEADER;end
     else begin channel<=0;
      if(vertical)begin
       // Emit final RGB rows contiguously so one AXI beat carries 32 valid bytes.
       if(row<223)begin row<=row+1;state<=RS_HEADER;end
       else if(dx<223)begin row<=0;dx<=dx+1;state<=RS_HEADER;end
       else begin token<=0;oc<=0;feature<=0;patch_word<=0;flush_writes(PATCH_BEGIN);end
      end else if(dx<223)begin dx<=dx+1;state<=(identity_resize)?RS_COPY:RS_HEADER;end
      else begin dx<=0;
       if(row+1<rh)begin row<=row+1;state<=(identity_resize)?RS_COPY:RS_HEADER;end
       else if(identity_resize)begin token<=0;oc<=0;feature<=0;patch_word<=0;flush_writes(PATCH_BEGIN);end
       else begin vertical<=1;row<=0;flush_writes(RS_HEADER);end
      end
     end
    end
    PATCH_BEGIN:begin
     perf_phase<=2;geometry_ready<=0;
     if(token==0)begin scalar<=0;state<=PATCH_GOT;end
     else state<=PATCH_ADDR0;
    end
    PATCH_ADDR0:state<=PATCH_ADDR1;
    PATCH_ADDR1:read_at(crop_base+({16'd0,patch_spatial}*3)+patch_channel,PATCH_GOT);
    PATCH_GOT:begin
     patch_word[feature[4:0]*8+:8]<=(token==0)?8'd0:quant;state<=PATCH_NEXT;
    end
    PATCH_NEXT:begin
     if(feature[4:0]==31)begin a_write<=1;write_address<=feature>>5;write_data<=patch_word;end
     if(feature==767)begin weight_beat<=0;state<=W_LOAD;end
     else begin feature<=feature+1;state<=PATCH_BEGIN;end
    end
    W_LOAD:read_at(param_base+oc*1568+weight_beat*32,W_GOT);
    W_GOT:begin b_write<=1;write_address<=weight_beat;write_data<=read_word;state<=W_NEXT;end
    W_NEXT:if(weight_beat==48)state<=DOT_BIAS_READ;
     else begin weight_beat<=weight_beat+1;state<=W_LOAD;end
    DOT_BIAS_READ:begin b_read<=1;b_address<=48;state<=DOT_BIAS_WAIT;end
    DOT_BIAS_WAIT:state<=DOT_BIAS;
    DOT_BIAS:begin accumulator<=($signed(b_data[15:0])*32'sd16384)+$signed(b_data[31:16]);vector<=0;state<=DOT_READ;end
    DOT_READ:begin a_read<=1;a_address<=vector>>1;b_read<=1;b_address<=vector;state<=DOT_WAIT;end
    DOT_WAIT:state<=DOT_MUL;
    DOT_MUL:begin activation_vector<=vector[0]?a_data[255:128]:a_data[127:0];weight_vector<=b_data;state<=DOT_ACC;end
    DOT_ACC:state<=POS_COEF;
    // The two explicit pipeline stages below ensure products consume registered SRAM data.
    POS_COEF:begin
     accumulator<=accumulator+vector_sum;
     if(vector==47)read_at(param_base+32'h50000+oc*4,POS_MUL);
     else begin vector<=vector+1;state<=DOT_READ;end
    end
    POS_MUL:begin position_coef<=scalar;wide<=$signed(accumulator)*$signed(scalar);state<=POS_CLS;end
    POS_CLS:read_at(param_base+32'h51000+(token*192+oc)*4,POS_ADD);
    POS_ADD:begin cls_value<=scalar;x_value<=clip16($signed(wide[44:29])+$signed(scalar));state<=POS_STORE;end
    POS_STORE:begin
     norm_input_valid<=1;norm_input_address<=token*192+oc;norm_input_data<=x_value;
     write_at(x_base+(token*192+oc)*2,x_value,1,POSE_MUL);
    end
    POSE_MUL:begin wide<=$signed(x_value)*$signed(pose_coef);state<=POSE_STORE;end
    POSE_STORE:write_at(packed16_address(pose_base,token*192+oc),clip16(wide>>>29),1,OC_NEXT);
    OC_NEXT:begin
     if(oc==191)begin oc<=0;
      if(token==196)begin pad_index<=37824;state<=PAD;end
      else begin token<=token+1;feature<=0;patch_word<=0;state<=PATCH_BEGIN;end
     end else begin oc<=oc+1;weight_beat<=0;state<=W_LOAD;end
    end
    PAD:begin norm_input_valid<=1;norm_input_address<=pad_index;norm_input_data<=0;
     if(pad_index==49151)begin perf_phase<=3;state<=NORM_START;end else pad_index<=pad_index+1;
    end
    NORM_START:begin norm_start<=1;state<=NORM_WAIT;end
    NORM_WAIT:if(norm_valid)begin held_norm_address<=norm_address;held_norm_data<=norm_data;state<=NORM_NEXT;end
     else if(norm_done_seen)begin ext_row<=0;ext_col<=0;state<=NORM_EXT;end
    NORM_NEXT:begin
     if(norm_row<200)write_at(packed16_address(seed_base,norm_tile_index),
       ((norm_row>=197)&&(norm_col<192))?16'd0:held_norm_data,1,NORM_WAIT);
     else state<=NORM_WAIT;
    end
    NORM_EXT:begin
     write_at(packed16_address(seed_base,((ext_row/4)*49+48)*16+(ext_row%4)*4+2+ext_col),
      ext_col==0?16'd16384:16'd1,1,FINISH);
    end
    FINISH:begin
     if(ext_col==0)begin ext_col<=1;state<=NORM_EXT;end
     else if(ext_row<199)begin ext_col<=0;ext_row<=ext_row+1;state<=NORM_EXT;end
     else begin busy<=0;done<=1;state<=IDLE;end
    end
    FAIL:begin busy<=0;done<=1;error<=1;state<=IDLE;end
    default:state<=FAIL;
   endcase
  end
 end
endmodule
