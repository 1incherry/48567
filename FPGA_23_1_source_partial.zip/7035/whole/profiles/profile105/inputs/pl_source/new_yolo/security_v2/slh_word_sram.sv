`timescale 1ns/1ps
// Private EDK synchronous word store. Logical bounds remain the original
// array bounds; unused physical words are never admitted as logical storage.
module slh_word_sram #(
 parameter integer WIDTH=32,DEPTH=1964,BANK_WORDS=512,
 parameter integer ABITS=DEPTH>1?$clog2(DEPTH):1
)(
 input wire clk,write_enable,read_enable,
 input wire [ABITS-1:0] write_address,read_address,
 input wire [WIDTH-1:0] write_data,output wire [WIDTH-1:0] read_data
);
 localparam integer BANKS=(DEPTH+BANK_WORDS-1)/BANK_WORDS;
 localparam integer BBITS=BANKS>1?$clog2(BANKS):1;
 localparam integer LOCAL_BITS=$clog2(BANK_WORDS);
 reg [BBITS-1:0] read_bank;
 reg read_in_bounds;
 always @(posedge clk)if(read_enable)begin
  read_bank<=read_address/ BANK_WORDS;
  read_in_bounds<=read_address<DEPTH;
 end
 wire [WIDTH-1:0] words[0:BANKS-1];
 for(genvar b=0;b<BANKS;b=b+1)begin:physical_banks
  wire wen=write_enable && write_address<DEPTH && write_address/BANK_WORDS==b;
  wire ren=read_enable && read_address<DEPTH && read_address/BANK_WORDS==b;
  wire [LOCAL_BITS-1:0] address=wen?write_address:read_address;
  if(WIDTH==32 && BANK_WORDS==512)begin:word512
   SRAM1RW512x32 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(write_data),.O(words[b]));
  end else if(WIDTH==32 && BANK_WORDS==256)begin:word256
   SRAM1RW256x32 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(write_data),.O(words[b]));
  end else if(WIDTH==32 && BANK_WORDS==64)begin:word64
   SRAM1RW64x32 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(write_data),.O(words[b]));
  end else if(WIDTH==8 && BANK_WORDS==512)begin:byte512
   SRAM1RW512x8 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I(write_data),.O(words[b]));
  end
 end
 reg [WIDTH-1:0] selected_word;
 always @* begin
  selected_word={WIDTH{1'bx}};
  for(integer b=0;b<BANKS;b=b+1)if(read_bank==b)selected_word=words[b];
 end
 assign read_data=read_in_bounds?selected_word:{WIDTH{1'bx}};
 // synopsys translate_off
 initial if(DEPTH<1 || !((WIDTH==32&&(BANK_WORDS==64||BANK_WORDS==256||BANK_WORDS==512))||(WIDTH==8&&BANK_WORDS==512)))
  $fatal(1,"Unsupported faithful SRAM word geometry");
 integer writes=0,reads=0;
 always @(posedge clk)begin
  if(write_enable && read_enable)$fatal(1,"Single-port service SRAM read/write overlap");
  if(write_enable && write_address<DEPTH)writes=writes+1;
  if(read_enable)reads=reads+1;
 end
 final $display("SLH_WORD_SRAM_ACCESS width=%0d depth=%0d bank_words=%0d banks=%0d writes=%0d reads=%0d",WIDTH,DEPTH,BANK_WORDS,BANKS,writes,reads);
 // synopsys translate_on
endmodule
