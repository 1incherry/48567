`timescale 1ns/1ps
// One output channel per command, stripe of output pixels. DMA owns tile loading.
// Input SRAM: NHWC, channels padded to 16, 128-bit words. Weights: KY,KX,Cblock.
// Both read ports have one-cycle synchronous latency, no wait states.
// Output: raw INT32 (bias + dot), requiring external per-channel requantization.
module yolo_conv_stripe(
 input wire clk,input wire rst_n,
 input wire command_valid,output wire command_ready,
 input wire [15:0] cfg_input_h,cfg_input_w,cfg_input_row0,cfg_input_rows,
 input wire [15:0] cfg_channel_blocks,cfg_output_w,cfg_output_row0,cfg_output_rows,
 input wire [3:0] cfg_kernel,cfg_stride,cfg_padding,
 input wire [7:0] cfg_zero_point,input wire signed [31:0] cfg_bias,
 output wire input_read,output wire [31:0] input_address,input wire [127:0] input_data,
 output wire weight_read,output wire [31:0] weight_address,input wire [127:0] weight_data,
 input wire output_ready,output wire output_write,output wire [31:0] output_address,output wire [31:0] output_data,
 output reg done,output reg error
);
 localparam IDLE=0,SETUP1=1,SETUP2=2,SETUP3=3,START=4,FEED=5,RESULT=6;
 reg [2:0] state;
 reg [15:0] ih,iw,row0,rows,cb,ow,oy0,oys;
 reg [3:0] kernel,stride,padding;
 reg [7:0] zp;reg signed [31:0] bias;
 reg [15:0] ox,oy,ic;
 reg [3:0] kx,ky;
 reg [31:0] vec_index,pixel_index;
 reg issued_all,pipe_valid,pipe_pad,pipe_last;
 // Configuration products are pipelined once per command. The live SRAM
 // address is then a registered recurrence, with no multiply-to-BRAM path.
 reg signed [31:0] y_base,x_base,y_cur,x_cur,base_row_delta,base_linear;
 reg [31:0] row_step,x_step,y_step,kernel_span,row_jump;
 reg [31:0] pixel_row_base,pixel_base,read_index;
 reg [16:0] row_end;
 wire dot_start_ready,dot_vector_ready,dot_result_valid;
 wire signed [31:0] dot_result;
 wire request=(state==FEED)&&!issued_all;
 wire last_vector=(ic==cb-1)&&(kx==kernel-1)&&(ky==kernel-1);
 wire outside_image=(y_cur<0)||(y_cur>=ih)||(x_cur<0)||(x_cur>=iw);
 wire missing_row=!outside_image&&((y_cur<row0)||(y_cur>=row_end));
 assign command_ready=state==IDLE;
 assign input_read=request&&!outside_image&&!missing_row;
 assign weight_read=request;
 assign input_address=read_index;
 assign weight_address=vec_index;
 assign output_write=(state==RESULT)&&dot_result_valid;
 assign output_address=pixel_index;
 assign output_data=dot_result;
 yolo_dot16_u8s8 dot(
  .clk(clk),.rst_n(rst_n),.start_valid(state==START),.start_ready(dot_start_ready),
  .bias(bias),.activation_zero_point(zp),.vector_valid(pipe_valid),.vector_ready(dot_vector_ready),
  .activations(pipe_pad?{16{zp}}:input_data),.weights(weight_data),.vector_last(pipe_last),
  .result_valid(dot_result_valid),.result_ready((state==RESULT)&&output_ready),.result(dot_result));
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;done<=0;error<=0;pipe_valid<=0;pipe_pad<=0;pipe_last<=0;
   ih<=0;iw<=0;row0<=0;rows<=0;cb<=0;ow<=0;oy0<=0;oys<=0;
   kernel<=0;stride<=0;padding<=0;zp<=0;bias<=0;
   ox<=0;oy<=0;ic<=0;kx<=0;ky<=0;vec_index<=0;pixel_index<=0;issued_all<=0;
   y_base<=0;x_base<=0;y_cur<=0;x_cur<=0;base_row_delta<=0;base_linear<=0;
   row_step<=0;x_step<=0;y_step<=0;kernel_span<=0;row_jump<=0;
   pixel_row_base<=0;pixel_base<=0;read_index<=0;row_end<=0;
  end else begin
   done<=0;pipe_valid<=request;
   if(request)begin
    pipe_pad<=outside_image||missing_row;pipe_last<=last_vector;
    if(missing_row)error<=1;
    if(last_vector)issued_all<=1;
    else begin
     vec_index<=vec_index+1;
     if(ic==cb-1)begin
      ic<=0;
      if(kx==kernel-1)begin
       kx<=0;ky<=ky+1;y_cur<=y_cur+1;x_cur<=x_base;
       read_index<=read_index+row_jump;
      end else begin kx<=kx+1;x_cur<=x_cur+1;read_index<=read_index+1;end
     end else begin ic<=ic+1;read_index<=read_index+1;end
    end
   end
   case(state)
    IDLE:if(command_valid)begin
     error<=0;
     if(!cfg_input_h||!cfg_input_w||!cfg_input_rows||!cfg_channel_blocks||
        !cfg_output_w||!cfg_output_rows||!cfg_kernel||!cfg_stride||
        ({1'b0,cfg_input_row0}+{1'b0,cfg_input_rows}>{1'b0,cfg_input_h}))begin
      error<=1;done<=1;
     end else begin
      ih<=cfg_input_h;iw<=cfg_input_w;row0<=cfg_input_row0;rows<=cfg_input_rows;
      cb<=cfg_channel_blocks;ow<=cfg_output_w;oy0<=cfg_output_row0;oys<=cfg_output_rows;
      kernel<=cfg_kernel;stride<=cfg_stride;padding<=cfg_padding;zp<=cfg_zero_point;bias<=cfg_bias;
      ox<=0;oy<=0;pixel_index<=0;state<=SETUP1;
      y_base<=$signed({1'b0,cfg_output_row0})*$signed({1'b0,cfg_stride})-$signed({1'b0,cfg_padding});
      x_base<=-$signed({1'b0,cfg_padding});
      row_step<=cfg_input_w*cfg_channel_blocks;
      x_step<=cfg_stride*cfg_channel_blocks;
      kernel_span<=cfg_kernel*cfg_channel_blocks;
      row_end<={1'b0,cfg_input_row0}+{1'b0,cfg_input_rows};
     end
    end
    SETUP1:begin
     base_row_delta<=y_base-$signed({1'b0,row0});
     row_jump<=row_step-kernel_span+1;y_step<=row_step*stride;state<=SETUP2;
    end
    SETUP2:begin
     base_linear<=base_row_delta*$signed({1'b0,iw})-$signed({1'b0,padding});state<=SETUP3;
    end
    SETUP3:begin
     pixel_row_base<=base_linear*cb;pixel_base<=base_linear*cb;state<=START;
    end
    START:if(dot_start_ready)begin
     ic<=0;kx<=0;ky<=0;vec_index<=0;issued_all<=0;state<=FEED;
     y_cur<=y_base;x_cur<=x_base;read_index<=pixel_base;
    end
    FEED:if(pipe_valid&&dot_vector_ready&&pipe_last)state<=RESULT;
    RESULT:if(dot_result_valid&&output_ready)begin
     if((ox==ow-1)&&(oy==oys-1))begin done<=1;state<=IDLE;end
     else begin
      pixel_index<=pixel_index+1;
      if(ox==ow-1)begin
       ox<=0;oy<=oy+1;y_base<=y_base+stride;x_base<=-$signed({1'b0,padding});
       pixel_row_base<=pixel_row_base+y_step;pixel_base<=pixel_row_base+y_step;
      end else begin ox<=ox+1;x_base<=x_base+stride;pixel_base<=pixel_base+x_step;end
      state<=START;
     end
    end
   endcase
  end
 end
endmodule
