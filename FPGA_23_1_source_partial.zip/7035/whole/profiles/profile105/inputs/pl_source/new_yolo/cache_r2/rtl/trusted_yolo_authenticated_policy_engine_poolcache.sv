`timescale 1ns/1ps
// Composition only: existing arithmetic core + authenticated 128-byte program
// consumption. The SLH service, private page cache, A/B SRAM, DMA and AXI
// authentication backend are EXTERNAL SHARED resources, not new instances.
// exclusive_page_lock MUST be honored by the shared service arbiter.
module trusted_yolo_authenticated_policy_engine_poolcache #(
 parameter integer COMMAND_COUNT=58814,
 parameter [11:0] BANK_BASE=12'd2420,parameter integer A_WORDS=2548,
 parameter POLICY_ROM="model_object_policy_v2.mem",
 parameter ROLE_ROM="role_policy_201.hex"
)(
input wire job_valid,output wire job_ready,
 input wire [31:0] job_session,job_frame,job_epoch,job_rgb_base,
 input wire authorized,input wire [31:0] authorization_epoch,
 input wire job_cancel,output wire job_quiescent,active,
 output wire job_done,job_failed,output wire [7:0] failure_code,
 output wire [31:0] result_session,result_frame,result_epoch,
 output wire [31:0] current_index,
 output wire [15:0] read_transactions,write_transactions,
 input wire clk,
 input wire rst_n,
 output wire a_write,
 output wire b_write,
 output wire [11:0] bank_write_address,
 output wire [255:0] bank_write_data,
 output wire a_read,
 output wire b_read,
 output wire [11:0] a_read_address,
 output wire [11:0] b_read_address,
 input wire [255:0] a_read_data,
 input wire [255:0] b_read_data,
 output wire [31:0] M_AXI_ARADDR,
 output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,
 output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,
 input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,
 input wire [1:0] M_AXI_RRESP,
 input wire M_AXI_RLAST,
 input wire M_AXI_RVALID,
 output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,
 output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,
 output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,
 input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,
 output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,
 output wire M_AXI_WVALID,
 input wire M_AXI_WREADY,
 input wire [1:0] M_AXI_BRESP,
 input wire M_AXI_BVALID,
 output wire M_AXI_BREADY,
 output wire exclusive_page_lock,
 output wire fetch_valid,input wire fetch_ready,
 output wire [31:0] fetch_page_index,fetch_page_address,fetch_proof_address,
 output wire service_page_request,input wire service_page_ready,
 output wire [31:0] service_expected_page,
 input wire service_page_done,service_busy,service_fault,service_cache_valid,
 input wire [31:0] service_cached_page,
 output wire service_cache_read,output wire [9:0] service_cache_address,
 input wire service_cache_read_valid,input wire [31:0] service_cache_read_data,
 input wire policy_query_valid,output wire policy_query_ready,input wire policy_query_write,
 input wire [31:0] policy_query_address,policy_query_strobe,
 output wire policy_response_valid,input wire policy_response_ready,
 output wire policy_allowed,policy_static,output wire [15:0] policy_role,policy_shape,
 output wire [31:0] policy_mask,policy_static_object,policy_static_offset,policy_response_address,
 output wire policy_context_live
);
wire program_request,program_ready,program_valid,program_verified;
wire [31:0] program_index,program_object,program_epoch;
wire [31:0] response_index,response_object,response_epoch;
wire [831:0] response_command;
wire engine_ready,engine_quiescent,reader_quiescent,lease_quiescent,policy_quiescent;
wire raw_valid,raw_verified,raw_ready;
wire [31:0] raw_index,raw_object,raw_epoch;
wire [831:0] raw_command;
assign response_object=314;
wire lease_request,lease_ready,lease_response_valid,lease_verified,lease_still_valid;
wire [31:0] lease_object,lease_page,lease_epoch,lease_response_object,lease_response_page,lease_response_epoch;
wire word_request,word_ready,word_response_valid,lease_release,release_ready;
wire [6:0] word_offset,word_response_offset;
wire [255:0] word_response_data;
reg bank_fault;
assign job_ready=engine_ready&&reader_quiescent&&policy_quiescent&&!bank_fault;
assign job_quiescent=engine_quiescent&&reader_quiescent&&lease_quiescent&&policy_quiescent;
// The A tail belongs only to the verified instruction cache. Every compute
// access is physically fenced; signed range analysis is supplementary evidence.
wire raw_a_write,raw_b_write,raw_a_read,raw_b_read,compute_quiescent;
wire [11:0] raw_bank_write_address,raw_a_read_address,raw_b_read_address;
wire [255:0] raw_bank_write_data;
wire cache_bank_owned,cache_bank_write,cache_bank_read;
wire [11:0] cache_bank_write_address,cache_bank_read_address;
wire [255:0] cache_bank_write_data;

wire bank_violation=(raw_a_write&&raw_bank_write_address>=BANK_BASE)||
 (raw_a_read&&raw_a_read_address>=BANK_BASE)||
 (cache_bank_owned&&(raw_a_write||raw_a_read||raw_b_write||raw_b_read));
wire effective_authorized=authorized&&!bank_fault&&!bank_violation;
wire effective_cancel=job_cancel||bank_fault||bank_violation;
wire compute_done,compute_failed;wire [7:0] compute_failure_code;
always @(posedge clk)begin
 if(!rst_n)bank_fault<=0;
 else if(bank_violation)bank_fault<=1; // trusted POR only; no PS retry clear
end
assign a_write=cache_bank_owned ? cache_bank_write : raw_a_write&&raw_bank_write_address<BANK_BASE&&!bank_fault;
assign b_write=!cache_bank_owned&&raw_b_write&&!bank_fault;
assign bank_write_address=cache_bank_owned ? cache_bank_write_address : raw_bank_write_address;
assign bank_write_data=cache_bank_owned ? cache_bank_write_data : raw_bank_write_data;
assign a_read=cache_bank_owned ? cache_bank_read : raw_a_read&&raw_a_read_address<BANK_BASE&&!bank_fault;
assign b_read=!cache_bank_owned&&raw_b_read&&!bank_fault;
assign a_read_address=cache_bank_owned ? cache_bank_read_address : raw_a_read_address;
assign b_read_address=raw_b_read_address;
assign job_done=compute_done&&!bank_fault&&!bank_violation;
assign job_failed=compute_failed||(compute_done&&(bank_fault||bank_violation));
assign failure_code=bank_fault||bank_violation ? 8'hfe : compute_failure_code;
trusted_yolo_engine_poolcache #(.COMMAND_COUNT(COMMAND_COUNT)) arithmetic(
 .job_valid(job_valid&&reader_quiescent&&policy_quiescent&&!bank_fault),.job_ready(engine_ready),.job_quiescent(engine_quiescent),
 .authorized(effective_authorized),.job_cancel(effective_cancel),.job_done(compute_done),.job_failed(compute_failed),.failure_code(compute_failure_code),
 .a_write(raw_a_write),.b_write(raw_b_write),.bank_write_address(raw_bank_write_address),.bank_write_data(raw_bank_write_data),
 .a_read(raw_a_read),.b_read(raw_b_read),.a_read_address(raw_a_read_address),.b_read_address(raw_b_read_address),.*);
trusted_yolo_program_pool_cache #(.COMMAND_COUNT(COMMAND_COUNT),.BANK_BASE(BANK_BASE),.A_WORDS(A_WORDS)) program_consumer(
 .clk(clk),.rst_n(rst_n),.cancel(effective_cancel),.authorized(effective_authorized),.authorization_epoch(authorization_epoch),
 .owner_live(active),.compute_quiescent(compute_quiescent),
 .bank_owned(cache_bank_owned),.bank_write(cache_bank_write),.bank_write_address(cache_bank_write_address),.bank_write_data(cache_bank_write_data),
 .bank_read(cache_bank_read),.bank_read_address(cache_bank_read_address),.bank_read_data(a_read_data),
 .request_valid(program_request),.request_ready(program_ready),.request_index(program_index),.request_object(program_object),.request_epoch(program_epoch),
 .response_valid(raw_valid),.response_verified(raw_verified),.response_index(raw_index),.response_object(raw_object),.response_epoch(raw_epoch),.response_command(raw_command),
 .lease_request(lease_request),.lease_ready(lease_ready),.lease_object(lease_object),.lease_page(lease_page),.lease_epoch(lease_epoch),
 .lease_response_valid(lease_response_valid),.lease_verified(lease_verified),.lease_response_object(lease_response_object),.lease_response_page(lease_response_page),.lease_response_epoch(lease_response_epoch),.lease_still_valid(lease_still_valid),
 .word_request(word_request),.word_ready(word_ready),.word_offset(word_offset),.word_response_valid(word_response_valid),.word_response_offset(word_response_offset),.word_response_data(word_response_data),
 .lease_release(lease_release),.release_ready(release_ready),.cache_quiescent(lease_quiescent),.quiescent(reader_quiescent));
trusted_yolo_page_lease_lutram #(.POLICY_ROM(POLICY_ROM)) program_page(
 .clk(clk),.rst_n(rst_n),.cancel(effective_cancel),.model_authorized(effective_authorized),.session_epoch(authorization_epoch),
 .cache_quiescent(lease_quiescent),.*);

trusted_yolo_role_policy #(.ROLE_ROM(ROLE_ROM)) roles(
 .clk(clk),.rst_n(rst_n),.cancel(effective_cancel),.authorized(effective_authorized),.authorization_epoch(authorization_epoch),
 .load_valid(raw_valid),.load_ready(raw_ready),.load_verified(raw_verified&&raw_object==314),.load_index(raw_index),.load_epoch(raw_epoch),.load_command(raw_command),
 .load_response_valid(program_valid),.load_allowed(program_verified),.loaded_index(response_index),.loaded_epoch(response_epoch),.loaded_command(response_command),
 .context_live(policy_context_live),.quiescent(policy_quiescent),
 .query_valid(policy_query_valid),.query_ready(policy_query_ready),.query_write(policy_query_write),.query_address(policy_query_address),.query_strobe(policy_query_strobe),
 .query_response_valid(policy_response_valid),.query_response_ready(policy_response_ready),.query_allowed(policy_allowed),.query_static(policy_static),.query_role(policy_role),.query_shape(policy_shape),
 .query_mask(policy_mask),.query_static_object(policy_static_object),.query_static_offset(policy_static_offset),.response_address(policy_response_address));

endmodule
