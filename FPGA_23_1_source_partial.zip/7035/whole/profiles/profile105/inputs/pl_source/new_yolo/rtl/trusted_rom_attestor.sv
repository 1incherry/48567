`timescale 1ns/1ps
// Authenticate every immutable ROM word against its signed object before use.
// Static responses MUST come from the shared verified private page cache. The
// ROM is configured with the bitstream and has no PS write path. A changed ROM
// or signed object is rejected; no CPU digest/boolean is accepted as evidence.
module trusted_rom_attestor #(parameter integer WORDS=768)(
 input wire clk,rst_n,start,cancel,authorized,input wire [31:0] authorization_epoch,
 output wire ready,quiescent,output reg done,failed,
 output wire attested,output reg [31:0] result_epoch,
 output wire request_valid,input wire request_ready,output wire [31:0] request_offset,request_epoch,
 input wire response_valid,response_verified,input wire [31:0] response_offset,response_epoch,
 input wire [255:0] response_data,input wire reader_quiescent,
 output wire [9:0] rom_index,input wire [255:0] rom_data,input wire rom_quiescent
);
 localparam IDLE=0,OFFER=1,REPLY=2,ROM_READ=3,COMPARE=4,DRAIN=5,REPORT=6;
 reg [2:0] state;reg [9:0] index;reg good,aborted,passed;
 reg [255:0] signed_word,configured_word;
 wire live=authorized&&!cancel&&!aborted&&authorization_epoch==result_epoch;
 assign ready=state==IDLE&&reader_quiescent&&rom_quiescent&&authorized&&!cancel;
 assign quiescent=state==IDLE&&reader_quiescent;
 assign attested=passed&&authorized&&!cancel&&authorization_epoch==result_epoch;
 assign request_valid=state==OFFER;
 assign request_offset={17'd0,index,5'd0};assign request_epoch=result_epoch;
 assign rom_index=index;
 always @(posedge clk)begin
  if(!rst_n)begin state<=IDLE;index<=0;good<=0;aborted<=0;passed<=0;done<=0;failed<=0;result_epoch<=0;signed_word<=0;configured_word<=0;end
  else begin
   done<=0;failed<=0;
   if(!authorized||cancel||authorization_epoch!=result_epoch)passed<=0;
   if(state!=IDLE&&!live)aborted<=1;
   case(state)
    IDLE:if(start&&ready)begin result_epoch<=authorization_epoch;index<=0;passed<=0;good<=0;aborted<=0;state<=OFFER;end
    OFFER:if(request_ready)state<=REPLY;
    REPLY:if(response_valid)begin
     if(!live||!response_verified||response_offset!=request_offset||response_epoch!=result_epoch)state<=DRAIN;
     else begin signed_word<=response_data;state<=ROM_READ;end
    end
    ROM_READ:if(!live||!rom_quiescent)state<=DRAIN;else begin configured_word<=rom_data;state<=COMPARE;end
    COMPARE:begin
     if(!live||!rom_quiescent||signed_word!==configured_word)state<=DRAIN;
     else if(index==WORDS-1)begin good<=1;state<=DRAIN;end
     else begin index<=index+1;state<=OFFER;end
    end
    DRAIN:if(reader_quiescent)state<=REPORT;
    REPORT:begin done<=good&&live;failed<=!good||!live;passed<=good&&live;state<=IDLE;end
    default:begin good<=0;state<=DRAIN;end
   endcase
  end
 end
endmodule
