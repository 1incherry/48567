`timescale 1ns/1ps
// Trusted microprogram executor. Program replies MUST come from immutable PL
// ROM or a consumption-time authenticated instruction cache, never a PS CSR.
// The host has no command, address, count, completion or program identity port.
module trusted_yolo_scheduler #(
 parameter integer COMMAND_COUNT=1,
 parameter [31:0] PROGRAM_OBJECT=32'd314,
 parameter [31:0] RGB_BASE=32'h22000000,
 parameter integer TIMEOUT_CYCLES=1000000000
)(
 input wire clk,rst_n,
 input wire job_valid, output wire job_ready,
 input wire [31:0] job_session,job_frame,job_epoch,job_rgb_base,
 input wire authorized,input wire [31:0] authorization_epoch,
 input wire job_cancel,
 output wire job_quiescent,output wire active,
 output reg job_done,job_failed,
 output reg [31:0] result_session,result_frame,result_epoch,
 output reg [7:0] failure_code,
 // Trusted program read request / reply. Exactly one request outstanding.
 output wire program_request, input wire program_ready,
 output wire [31:0] program_index,program_object,program_epoch,
 input wire program_valid,input wire program_verified,
 input wire [31:0] response_index,response_object,response_epoch,
 input wire [831:0] response_command,
 // Bits [1:0] op, [33:2] address, [49:34] words,
 // [561:50] nonconv descriptor, [817:562] conv cfg, [831:818] reserved=0.
 output wire command_valid,input wire command_ready,
 output wire [831:0] command,
 input wire engine_busy,engine_done,engine_error,
 input wire [15:0] axi_outstanding,
 output wire [31:0] current_index
);
 localparam IDLE=0,FETCH=1,REPLY=2,OFFER=3,EXECUTE=4,DRAIN=5,REPORT=6,ARM=7;
 reg [2:0] state;
 reg [31:0] index,ticks;
 reg [831:0] held_command;
 reg abort_latched,completion_seen;
 wire revoked=!authorized||(authorization_epoch!=result_epoch);
 wire idle_bus=!engine_busy&&(axi_outstanding==0);
 assign active=state!=IDLE;
 assign job_ready=(state==IDLE)&&authorized&&idle_bus&&!job_cancel;
 assign job_quiescent=(state==IDLE)&&idle_bus;
 assign program_request=state==FETCH;
 assign program_index=index;
 assign program_object=PROGRAM_OBJECT;
 assign program_epoch=result_epoch;
 // Once OFFER is entered valid cannot be withdrawn under backpressure, even
 // when cancellation arrives. The accepted operation is then drained, not
 // silently abandoned. This is required by AXI-valid stability.
 assign command_valid=state==OFFER;
 assign command=held_command;
 assign current_index=index;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;index<=0;ticks<=0;held_command<=0;
   result_session<=0;result_frame<=0;result_epoch<=0;
   job_done<=0;job_failed<=0;failure_code<=0;
   abort_latched<=0;completion_seen<=0;
  end else begin
   job_done<=0;job_failed<=0;
   if(state!=IDLE)begin
    if(ticks<TIMEOUT_CYCLES)ticks<=ticks+1;
    if(job_cancel||revoked||ticks==TIMEOUT_CYCLES)begin
     abort_latched<=1;
     if(!abort_latched)failure_code<=job_cancel?8'd1:revoked?8'd2:8'd3;
    end
   end
   case(state)
    IDLE:if(job_valid&&job_ready)begin
     result_session<=job_session;result_frame<=job_frame;
     result_epoch<=job_epoch;index<=0;ticks<=0;
     failure_code<=0;abort_latched<=0;completion_seen<=0;
     if(job_epoch!=authorization_epoch||job_session==0||job_frame==0||
        job_rgb_base!=RGB_BASE||COMMAND_COUNT<1)begin
      abort_latched<=1;failure_code<=4;state<=DRAIN;
     end else state<=FETCH;
    end
    FETCH:begin
     // A fetch already offered obeys the same stable-valid contract as a
     // command. Cancellation waits for its verified-or-rejected reply.
     if(program_ready)state<=REPLY;
    end
    REPLY:begin
     // Program reader must keep a request alive until its reply, including
     // after cancel. Its busy is part of axi_outstanding / engine_busy.
     if(program_valid)begin
      if(!program_verified||response_index!=index||response_object!=PROGRAM_OBJECT||
         response_epoch!=result_epoch||response_command[831:818]!=0)begin
       failure_code<=5;abort_latched<=1;state<=DRAIN;
      end else if(abort_latched||job_cancel||revoked||ticks==TIMEOUT_CYCLES)state<=DRAIN;
      else begin held_command<=response_command;state<=ARM;end
     end
    end
    ARM:begin
     if(abort_latched||job_cancel||revoked||ticks==TIMEOUT_CYCLES)state<=DRAIN;
     else if(idle_bus&&!engine_done)state<=OFFER;
    end
    OFFER:if(command_ready)begin
     completion_seen<=0;
     // The reused engine clears its sticky prior-command error ON this
     // handshake. Sampling it here would reject a valid recovery command.
     // EXECUTE observes the new command's registered error from next cycle.
     state<=EXECUTE;
    end
    EXECUTE:begin
     if(engine_done)completion_seen<=1;
     if(engine_error)begin failure_code<=6;abort_latched<=1;end
     if((completion_seen||engine_done)&&idle_bus)begin
      completion_seen<=0;
      if(abort_latched||job_cancel||revoked||engine_error||ticks==TIMEOUT_CYCLES)state<=DRAIN;
      else if(index==COMMAND_COUNT-1)state<=REPORT;
      else begin index<=index+1;state<=FETCH;end
     end
    end
    DRAIN:if(idle_bus)begin
     job_failed<=1;state<=IDLE;
    end
    REPORT:begin
     if(abort_latched||job_cancel||revoked||ticks==TIMEOUT_CYCLES)state<=DRAIN;
     else if(idle_bus)begin job_done<=1;state<=IDLE;end
    end
    default:begin failure_code<=7;abort_latched<=1;state<=DRAIN;end
   endcase
  end
 end
endmodule
