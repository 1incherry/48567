`timescale 1ns/1ps
// Experimental component:35 independent WOTS verification chains. Signature
// reads and final140 word writes share the original single-port interfaces.
// Whole SLH verification and authorization remain with the enclosing service.
module slh_wots_parallel_scheduler #(
 parameter integer ENGINES=1, LONGEST_FIRST=0, EXTERNAL_LANE0=0, EXTERNAL_SECOND_LANE=-1, FAST_SHORT=1
)(
 input wire clk,rst_n,cancel,start,
 output wire external_reset,external_start,output wire [511:0] external_block,output wire [255:0] external_iv,
 input wire external_busy,external_done,input wire [255:0] external_state,
 output wire second_external_reset,second_external_start,
 output wire [511:0] second_external_block,output wire [255:0] second_external_iv,
 input wire second_external_busy,second_external_done,input wire [255:0] second_external_state,


 input wire [127:0] public_seed,wots_message,
 input wire [2:0] layer,input wire [53:0] tree,input wire [8:0] leaf,
 output wire signature_read_enable,output wire [10:0] signature_read_address,
 input wire [127:0] signature_read_node,
 output wire key_write_valid,input wire key_write_ready,
 output wire [7:0] key_write_address,output wire [31:0] key_write_data,
 output reg busy,done,fault,output reg [7:0] fault_code,
 output reg [31:0] elapsed_cycles,hash_operations,
 output reg [5:0] loaded_nodes,output reg [7:0] stored_words,
 output reg [34:0] completed_chains
);
 localparam [2:0] EMPTY=0,LOADING=1,START_HASH=2,FEED=3,WAIT_HASH=4,WRITE_KEY=5;
 reg [2:0] lane_state[0:ENGINES-1];
 reg [127:0] lane_node[0:ENGINES-1];
 reg [5:0] lane_chain[0:ENGINES-1];reg [3:0] lane_step[0:ENGINES-1];
 reg [1:0] lane_word[0:ENGINES-1];reg [6:0] feed_position[0:ENGINES-1];
 reg [127:0] seed_snapshot;reg [2:0] layer_snapshot;
 reg [53:0] tree_snapshot;reg [8:0] leaf_snapshot;reg [139:0] digit_snapshot;
 reg [34:0] assigned_chains;
 reg load_pending;integer loading_lane;
 reg read_issue_valid;reg [10:0] read_issue_address;integer read_issue_lane,read_issue_chain;
 reg write_owner_valid;integer write_owner;
 integer free_lane,next_chain,best_length,writer,completed_hashes;
 wire operating=rst_n&&busy&&!cancel&&!start;
 wire request_candidate=operating&&!load_pending&&!read_issue_valid&&free_lane>=0&&next_chain>=0;
 wire [ENGINES-1:0] h_ready,h_done,h_fault,h_cached;
 wire [2:0] h_capacity[0:ENGINES-1];wire [255:0] h_digest[0:ENGINES-1];
 wire [2:0] h_count[0:ENGINES-1];wire [31:0] h_data[0:ENGINES-1];

 function automatic [139:0] basew(input [127:0] value);
  integer checksum;reg [139:0] digits;
  begin
   checksum=0;digits=0;
   for(integer i=0;i<32;i=i+1)begin
    digits[139-i*4 -:4]=value[127-i*4 -:4];checksum=checksum+15-value[127-i*4 -:4];
   end
   digits[11:8]=(checksum>>8)&15;digits[7:4]=(checksum>>4)&15;digits[3:0]=checksum&15;basew=digits;
  end
 endfunction
 function automatic [175:0] chain_address(
  input [2:0] layer_value,input [53:0] tree_value,input [8:0] leaf_value,
  input [5:0] chain_value,input [3:0] step_value);
  chain_address={{5'b0,layer_value},{10'b0,tree_value},8'd0,
                 {23'b0,leaf_value},{26'b0,chain_value},{28'b0,step_value}};
 endfunction
 function automatic [7:0] input_byte(input [127:0] seed_value,
  input [175:0] address_value,input [127:0] node_value,input integer position);
  begin
   input_byte=0;
   if(position<16)input_byte=seed_value[127-position*8 -:8];
   else if(position<64)input_byte=0;
   else if(position<86)input_byte=address_value[175-(position-64)*8 -:8];
   else input_byte=node_value[127-(position-86)*8 -:8];
  end
 endfunction
 // Six balanced selection levels. Left child wins ties, preserving
 // the original lowest-index choice and LONGEST_FIRST=0 priority.
 wire [127:1] chain_tree_valid;
 wire [3:0] chain_tree_digit[1:127];
 wire [5:0] chain_tree_index[1:127];
 for(genvar c=0;c<64;c=c+1)begin:chain_tree_leaves
  if(c<35)begin
   assign chain_tree_valid[64+c]=!assigned_chains[c];
   assign chain_tree_digit[64+c]=digit_snapshot[139-c*4 -:4];
   assign chain_tree_index[64+c]=c;
  end else begin
   assign chain_tree_valid[64+c]=1'b0;
   assign chain_tree_digit[64+c]=4'd15;
   assign chain_tree_index[64+c]=6'd0;
  end
 end
 for(genvar n=1;n<64;n=n+1)begin:chain_tree_nodes
  wire choose_right=chain_tree_valid[2*n+1]&&
   (!chain_tree_valid[2*n]||(LONGEST_FIRST&&chain_tree_digit[2*n+1]<chain_tree_digit[2*n]));
  assign chain_tree_valid[n]=chain_tree_valid[2*n]||chain_tree_valid[2*n+1];
  assign chain_tree_digit[n]=choose_right?chain_tree_digit[2*n+1]:chain_tree_digit[2*n];
  assign chain_tree_index[n]=choose_right?chain_tree_index[2*n+1]:chain_tree_index[2*n];
 end
 always @* begin
  free_lane=-1;next_chain=-1;best_length=-1;writer=-1;completed_hashes=0;
  for(integer i=0;i<ENGINES;i=i+1)begin
   if(lane_state[i]==EMPTY&&free_lane<0)free_lane=i;
   if(lane_state[i]==WRITE_KEY&&writer<0)writer=i;
   if(lane_state[i]==WAIT_HASH&&h_done[i]&&!h_fault[i])completed_hashes=completed_hashes+1;
  end
  next_chain=chain_tree_valid[1]?{26'b0,chain_tree_index[1]}:-1;
  best_length=chain_tree_valid[1]?(15-chain_tree_digit[1]):-1;
  if(write_owner_valid)writer=write_owner;
  // A lane's fourth key word is accepted on this edge.  When no other lane is
  // empty, reuse that lane for the next chain without inserting an idle cycle.
  if(free_lane<0&&writer>=0&&lane_state[writer]==WRITE_KEY&&lane_word[writer]==3&&key_write_ready)
   free_lane=writer;
 end
 // Register the WOTS request before it reaches the SRAM. This changes only the
 // request timing; the existing load_pending cycle still captures the node.
 assign signature_read_enable=operating&&read_issue_valid;
 assign signature_read_address=read_issue_address;
 assign key_write_valid=operating&&writer>=0;
 assign key_write_address=writer>=0?lane_chain[writer]*4+lane_word[writer]:0;
 assign key_write_data=writer>=0?lane_node[writer][127-lane_word[writer]*32 -:32]:0;

 for(genvar lane=0;lane<ENGINES;lane=lane+1)begin:hash_lanes
  wire [175:0] address_value=chain_address(layer_snapshot,tree_snapshot,leaf_snapshot,lane_chain[lane],lane_step[lane]);
  reg [2:0] count;reg [31:0] data;
  always @* begin
   count=4;if(102-feed_position[lane]<4)count=102-feed_position[lane];
   if(h_capacity[lane]<count)count=h_capacity[lane];data=0;
   for(integer q=0;q<4;q=q+1)if(q<count)data[31-q*8 -:8]=input_byte(seed_snapshot,address_value,lane_node[lane],feed_position[lane]+q);
  end
  assign h_count[lane]=count;assign h_data[lane]=data;
  wire c_reset,c_start,c_busy,c_done;wire [511:0] c_block;wire [255:0] c_iv,c_state;
  wire [511:0] short_payload={address_value,lane_node[lane],208'd0};
  slh_sha256_word_stream_shared23 #(.EXTERNAL_COMPRESSOR(1)) hash(
   .clk(clk),.rst_n(rst_n&&busy&&!cancel&&!start),
   .short_valid(FAST_SHORT&&h_cached[lane]),.short_data(short_payload),.start(operating&&lane_state[lane]==START_HASH),.length(16'd102),
   .seed_hash(1'b1),.seed_cached(h_cached[lane]),.valid(operating&&lane_state[lane]==FEED&&count!=0),
   .data(data),.input_bytes(count),.capacity(h_capacity[lane]),.ready(h_ready[lane]),.busy(),
   .done(h_done[lane]),.fault(h_fault[lane]),.digest(h_digest[lane]),
   .compressor_reset(c_reset),.compressor_start(c_start),.compressor_block(c_block),.compressor_iv(c_iv),
   .compressor_busy(c_busy),.compressor_done(c_done),.compressor_state(c_state));
  // Same actual3-round CSA block compressor as the qualified phase23 wrapper.
  if(lane==0)begin:export_lane0
   assign external_reset=c_reset;assign external_start=c_start;assign external_block=c_block;assign external_iv=c_iv;
  end
  if(lane==EXTERNAL_SECOND_LANE)begin:export_second_lane
   assign second_external_reset=c_reset;assign second_external_start=c_start;
   assign second_external_block=c_block;assign second_external_iv=c_iv;
  end
  if(lane==0&&EXTERNAL_LANE0)begin:reuse_service_compressor
   assign c_busy=external_busy;assign c_done=external_done;assign c_state=external_state;
  end else if(lane==EXTERNAL_SECOND_LANE)begin:reuse_second_compressor
   assign c_busy=second_external_busy;assign c_done=second_external_done;assign c_state=second_external_state;
  end else begin:private_compressor
  sha256_phase_shared23 compressor(.clk(clk),.rst_n(rst_n&&busy&&!cancel&&!start),.phase_model(1'b0),
   .signature_rst_n(c_reset),.signature_start(c_start),.signature_block(c_block),.signature_iv(c_iv),
   .signature_busy(c_busy),.signature_done(c_done),.signature_state(c_state),
   .model_rst_n(1'b0),.model_start(1'b0),.model_block(512'd0),.model_iv(256'd0),
   .model_busy(),.model_done(),.model_state(),.ownership_fault());
  end
 end

 generate if(EXTERNAL_SECOND_LANE<0 || EXTERNAL_SECOND_LANE>=ENGINES)begin:unused_second_export
  assign second_external_reset=1'b0;assign second_external_start=1'b0;
  assign second_external_block=512'd0;assign second_external_iv=256'd0;
 end endgenerate
 // synopsys translate_off
 initial begin
  if(EXTERNAL_SECOND_LANE==0 || EXTERNAL_SECOND_LANE>=ENGINES)
   $fatal(1,"INVALID_SECOND_EXTERNAL_LANE");
 end
 // synopsys translate_on
 always @(posedge clk)begin
  if(!rst_n||cancel)begin
   busy<=0;done<=0;fault<=cancel;fault_code<=cancel?8'he8:0;
   elapsed_cycles<=0;hash_operations<=0;loaded_nodes<=0;stored_words<=0;
   completed_chains<=0;assigned_chains<=0;load_pending<=0;loading_lane<=0;
   read_issue_valid<=0;read_issue_address<=0;read_issue_lane<=0;read_issue_chain<=0;
   write_owner_valid<=0;write_owner<=0;
   seed_snapshot<=0;layer_snapshot<=0;tree_snapshot<=0;leaf_snapshot<=0;digit_snapshot<=0;
   for(integer i=0;i<ENGINES;i=i+1)begin
    lane_state[i]<=EMPTY;lane_node[i]<=0;lane_chain[i]<=0;lane_step[i]<=0;lane_word[i]<=0;feed_position[i]<=0;
   end
  end else begin
   done<=0;
   if(start)begin
    if(busy)begin busy<=0;done<=1;fault<=1;fault_code<=8'h04;write_owner_valid<=0;load_pending<=0;read_issue_valid<=0;end
    else begin
     busy<=1;fault<=0;fault_code<=0;elapsed_cycles<=0;hash_operations<=0;loaded_nodes<=0;stored_words<=0;
     completed_chains<=0;assigned_chains<=0;load_pending<=0;read_issue_valid<=0;write_owner_valid<=0;
     seed_snapshot<=public_seed;layer_snapshot<=layer;tree_snapshot<=tree;leaf_snapshot<=leaf;digit_snapshot<=basew(wots_message);
     for(integer i=0;i<ENGINES;i=i+1)begin lane_state[i]<=EMPTY;lane_node[i]<=0;lane_chain[i]<=0;lane_step[i]<=0;lane_word[i]<=0;feed_position[i]<=0;end
    end
   end else if(busy)begin
    elapsed_cycles<=elapsed_cycles+1;hash_operations<=hash_operations+completed_hashes;
    if(request_candidate)begin
     read_issue_valid<=1;read_issue_lane<=free_lane;read_issue_chain<=next_chain;
     read_issue_address<=11'd732+layer_snapshot*11'd176+next_chain*4;
    end
    if(signature_read_enable)begin
     assigned_chains[read_issue_chain]<=1;lane_chain[read_issue_lane]<=read_issue_chain;lane_step[read_issue_lane]<=digit_snapshot[139-read_issue_chain*4 -:4];
     lane_word[read_issue_lane]<=0;lane_state[read_issue_lane]<=LOADING;loading_lane<=read_issue_lane;load_pending<=1;read_issue_valid<=0;
    end else if(load_pending)begin
     lane_node[loading_lane]<=signature_read_node;loaded_nodes<=loaded_nodes+1;load_pending<=0;
     lane_state[loading_lane]<=lane_step[loading_lane]==15?WRITE_KEY:START_HASH;
    end
    if(key_write_valid&&!write_owner_valid)begin write_owner_valid<=1;write_owner<=writer;end
    if(key_write_valid&&key_write_ready)begin
     stored_words<=stored_words+1;
     if(lane_word[writer]==3)begin
      // If the same edge also issues a new signature read, the lane remains
      // LOADING; otherwise it becomes available in the following cycle.
      if(!(signature_read_enable&&read_issue_lane==writer))lane_state[writer]<=EMPTY;
      completed_chains[lane_chain[writer]]<=1;write_owner_valid<=0;
      if(stored_words==139)begin busy<=0;done<=1;end
     end else lane_word[writer]<=lane_word[writer]+1;
    end
    for(integer i=0;i<ENGINES;i=i+1)begin
     case(lane_state[i])
      START_HASH:begin feed_position[i]<=h_cached[i]?64:0;lane_state[i]<=(FAST_SHORT&&h_cached[i])?WAIT_HASH:FEED;end
      FEED:if(h_ready[i]&&h_count[i]!=0)begin
       feed_position[i]<=feed_position[i]+h_count[i];if(feed_position[i]+h_count[i]==102)lane_state[i]<=WAIT_HASH;
      end
      WAIT_HASH:if(h_done[i])begin
       if(h_fault[i])begin busy<=0;done<=1;fault<=1;fault_code<=8'h90;end
       else begin
        lane_node[i]<=h_digest[i][255:128];
        if(lane_step[i]==14)lane_state[i]<=WRITE_KEY;
        else begin lane_step[i]<=lane_step[i]+1;lane_state[i]<=START_HASH;end
       end
      end
      default:begin end
     endcase
    end
   end
  end
 end
 // synopsys translate_off
 initial if(ENGINES<1||ENGINES>4||(LONGEST_FIRST!=0&&LONGEST_FIRST!=1))$fatal(1,"WOTS_SCHEDULER_PARAMETER");
 always @(posedge clk)if(signature_read_enable&&signature_read_address[1:0]!=0)$fatal(1,"WOTS_SCHEDULER_UNALIGNED_READ");
 // synopsys translate_on
endmodule
