`timescale 1ns/1ps
// Existing YOLO AXI master -> immutable per-command role/range policy ->
// static private-page reader OR dynamic typed MAC guard. Serializes beats,
// preserving arbitrary AR bursts and independent AW/W handshakes. R/B are
// released only after true verified consumption/commit, never a PS verdict.
module trusted_yolo_axi_guard(
 input wire clk,rst_n,input wire [31:0] job_session,job_frame,job_epoch,
 input wire context_live,external_quiescent,
 output wire quiescent,output reg transaction_fault,
 input wire [31:0] S_AXI_ARADDR,input wire [7:0] S_AXI_ARLEN,input wire [2:0] S_AXI_ARSIZE,input wire [1:0] S_AXI_ARBURST,
 input wire S_AXI_ARVALID,output wire S_AXI_ARREADY,output wire [255:0] S_AXI_RDATA,output wire [1:0] S_AXI_RRESP,
 output wire S_AXI_RLAST,S_AXI_RVALID,input wire S_AXI_RREADY,
 input wire [31:0] S_AXI_AWADDR,input wire [7:0] S_AXI_AWLEN,input wire [2:0] S_AXI_AWSIZE,input wire [1:0] S_AXI_AWBURST,
 input wire S_AXI_AWVALID,output wire S_AXI_AWREADY,input wire [255:0] S_AXI_WDATA,input wire [31:0] S_AXI_WSTRB,input wire S_AXI_WLAST,S_AXI_WVALID,
 output wire S_AXI_WREADY,output wire [1:0] S_AXI_BRESP,output wire S_AXI_BVALID,input wire S_AXI_BREADY,
 output wire policy_query_valid,input wire policy_query_ready,output wire policy_query_write,
 output wire [31:0] policy_query_address,policy_query_strobe,
 input wire policy_response_valid,output wire policy_response_ready,input wire policy_allowed,policy_static,
 input wire [15:0] policy_role,policy_shape,input wire [31:0] policy_mask,policy_static_object,policy_static_offset,policy_response_address,
 output wire static_request,input wire static_ready,output wire [31:0] static_object,static_offset,static_epoch,
 input wire static_response_valid,static_verified,input wire [255:0] static_data,input wire [31:0] static_response_offset,static_response_epoch,
 output wire guard_request,input wire guard_ready,output wire guard_write,
 output wire [31:0] guard_address,guard_mask,guard_strobe,guard_session,guard_frame,guard_epoch,
 output wire [15:0] guard_role,guard_shape,output wire [255:0] guard_data,
 input wire guard_response_valid,guard_verified,input wire [255:0] guard_response_data
);
 localparam IDLE=0,R_POLICY=1,R_POLICY_REPLY=2,R_STATIC=3,R_STATIC_REPLY=4,R_GUARD=5,R_GUARD_REPLY=6,R_REPORT=7,
 W_PREPARE=8,W_WAIT=9,W_POLICY=10,W_POLICY_REPLY=11,W_GUARD=12,W_GUARD_REPLY=13,W_ADVANCE=14,B_REPORT=15;
 reg [3:0] state;
 reg aw_held,w_held,w_last,bad;
 reg [31:0] aw_address,address,w_strobe;
 reg [7:0] aw_length;reg [2:0] aw_size;reg [1:0] aw_burst;
 reg [255:0] w_data,returned_data;
 reg [8:0] remaining;
 reg [31:0] saved_mask,saved_static_object,saved_static_offset;
 reg [15:0] saved_role,saved_shape;
 wire [14:0] ar_span={3'd0,S_AXI_ARADDR[11:0]}+(({7'd0,S_AXI_ARLEN}+1)<<5);
 wire [14:0] aw_span={3'd0,aw_address[11:0]}+(({7'd0,aw_length}+1)<<5);
 assign S_AXI_ARREADY=state==IDLE&&!aw_held&&!w_held&&!S_AXI_AWVALID&&!S_AXI_WVALID&&external_quiescent;
 assign S_AXI_AWREADY=state==IDLE&&!aw_held;
 assign S_AXI_WREADY=(state==IDLE||state==W_WAIT)&&!w_held;
 assign S_AXI_RVALID=state==R_REPORT;
 assign S_AXI_RDATA=returned_data;
 assign S_AXI_RRESP=bad?2'b10:2'b00;
 assign S_AXI_RLAST=remaining==1;
 assign S_AXI_BVALID=state==B_REPORT;
 assign S_AXI_BRESP=bad?2'b10:2'b00;
 assign policy_query_valid=state==R_POLICY||state==W_POLICY;
 assign policy_query_write=state==W_POLICY;
 assign policy_query_address=address;
 assign policy_query_strobe=state==W_POLICY?w_strobe:0;
 assign policy_response_ready=state==R_POLICY_REPLY||state==W_POLICY_REPLY;
 assign static_request=state==R_STATIC;
 assign static_object=saved_static_object;
 assign static_offset=saved_static_offset;
 assign static_epoch=job_epoch;
 assign guard_request=state==R_GUARD||state==W_GUARD;
 assign guard_write=state==W_GUARD;
 assign guard_address=address;assign guard_mask=saved_mask;
 assign guard_strobe=w_strobe;assign guard_data=w_data;
 assign guard_role=saved_role;assign guard_shape=saved_shape;
 assign guard_session=job_session;assign guard_frame=job_frame;assign guard_epoch=job_epoch;
 assign quiescent=state==IDLE&&!aw_held&&!w_held&&external_quiescent&&!S_AXI_ARVALID&&!S_AXI_AWVALID&&!S_AXI_WVALID;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;aw_held<=0;w_held<=0;w_last<=0;bad<=0;aw_address<=0;address<=0;w_strobe<=0;
   aw_length<=0;aw_size<=0;aw_burst<=0;w_data<=0;returned_data<=0;remaining<=0;
   saved_mask<=0;saved_static_object<=0;saved_static_offset<=0;saved_role<=0;saved_shape<=0;transaction_fault<=0;
  end else begin
   transaction_fault<=0;
   if(S_AXI_AWVALID&&S_AXI_AWREADY)begin aw_held<=1;aw_address<=S_AXI_AWADDR;aw_length<=S_AXI_AWLEN;aw_size<=S_AXI_AWSIZE;aw_burst<=S_AXI_AWBURST;end
   if(S_AXI_WVALID&&S_AXI_WREADY)begin w_held<=1;w_data<=S_AXI_WDATA;w_strobe<=S_AXI_WSTRB;w_last<=S_AXI_WLAST;end
   case(state)
    IDLE:begin
     if(S_AXI_ARVALID&&S_AXI_ARREADY)begin
      address<=S_AXI_ARADDR;remaining<={1'b0,S_AXI_ARLEN}+1;returned_data<=0;
      if(S_AXI_ARADDR[4:0]!=0||S_AXI_ARSIZE!=5||S_AXI_ARBURST!=1||ar_span>4096||!context_live)begin bad<=1;state<=R_REPORT;end
      else begin bad<=0;state<=R_POLICY;end
     end else if(aw_held&&w_held)begin
      aw_held<=0;address<=aw_address;remaining<={1'b0,aw_length}+1;
      bad<=aw_address[4:0]!=0||aw_size!=5||aw_burst!=1||aw_span>4096||!context_live;
      state<=W_PREPARE;
     end
    end
    R_POLICY:if(policy_query_ready)state<=R_POLICY_REPLY;
    R_POLICY_REPLY:if(policy_response_valid)begin
     if(!policy_allowed||policy_response_address!=address||!context_live)begin bad<=1;returned_data<=0;state<=R_REPORT;end
     else begin
      saved_mask<=policy_mask;saved_role<=policy_role;saved_shape<=policy_shape;
      saved_static_object<=policy_static_object;saved_static_offset<=policy_static_offset;
      if(policy_static)begin
       if(policy_static_object!=295)begin bad<=1;state<=R_REPORT;end else state<=R_STATIC;
      end else state<=R_GUARD;
     end
    end
    R_STATIC:if(static_ready)state<=R_STATIC_REPLY;
    R_STATIC_REPLY:if(static_response_valid)begin
     if(!static_verified||static_response_offset!=saved_static_offset||static_response_epoch!=job_epoch||!context_live)begin bad<=1;returned_data<=0;end
     else returned_data<=static_data;
     state<=R_REPORT;
    end
    R_GUARD:if(guard_ready)state<=R_GUARD_REPLY;
    R_GUARD_REPLY:if(guard_response_valid)begin
     if(!guard_verified||!context_live)begin bad<=1;returned_data<=0;end else returned_data<=guard_response_data;
     state<=R_REPORT;
    end
    R_REPORT:if(S_AXI_RREADY)begin
     if(bad)transaction_fault<=1;
     if(remaining==1)state<=IDLE;
     else begin address<=address+32;remaining<=remaining-1;if(bad)begin returned_data<=0;state<=R_REPORT;end else state<=R_POLICY;end
    end
    W_PREPARE:begin
     if(!w_held)state<=W_WAIT;
     else if(bad||w_last!=(remaining==1)||!context_live)begin bad<=1;state<=W_ADVANCE;end
     else state<=W_POLICY;
    end
    W_WAIT:if(w_held)state<=W_PREPARE;
    W_POLICY:if(policy_query_ready)state<=W_POLICY_REPLY;
    W_POLICY_REPLY:if(policy_response_valid)begin
     if(!policy_allowed||policy_static||policy_response_address!=address||!context_live)begin bad<=1;state<=W_ADVANCE;end
     else begin saved_mask<=policy_mask;saved_role<=policy_role;saved_shape<=policy_shape;state<=W_GUARD;end
    end
    W_GUARD:if(guard_ready)state<=W_GUARD_REPLY;
    W_GUARD_REPLY:if(guard_response_valid)begin if(!guard_verified||!context_live)bad<=1;state<=W_ADVANCE;end
    W_ADVANCE:begin
     w_held<=0;
     if(w_last)begin if(remaining!=1)bad<=1;state<=B_REPORT;end
     else begin
      if(remaining>0)remaining<=remaining-1;
      address<=address+32;state<=W_WAIT;
     end
    end
    B_REPORT:if(S_AXI_BREADY)begin if(bad)transaction_fault<=1;state<=IDLE;end
    default:begin bad<=1;state<=B_REPORT;end
   endcase
  end
 end
endmodule
