`timescale 1ns/1ps
// One verified 4KiB program page stored in the EXISTING A-bank tail.
// No data RAM is instantiated here. A[2420..2547] must be hardware fenced
// against every other A writer/reader, including PS/debug, for owner_live.
// rst_n belongs to the trusted security root, never a PS software reset.
module trusted_yolo_program_pool_cache #(
 parameter integer COMMAND_COUNT=58814, PROGRAM_COMMANDS=58814,
 parameter [31:0] PROGRAM_OBJECT=314,
 parameter [11:0] BANK_BASE=12'd2420,
 parameter integer A_WORDS=2548
)(
 input wire clk,rst_n,cancel,authorized,owner_live,
 input wire [31:0] authorization_epoch,
 input wire compute_quiescent,
 output reg bank_owned,
 output wire bank_write,output wire [11:0] bank_write_address,
 output wire [255:0] bank_write_data,
 output wire bank_read,output wire [11:0] bank_read_address,
 input wire [255:0] bank_read_data,
 input wire request_valid,output wire request_ready,
 input wire [31:0] request_index,request_object,request_epoch,
 output reg response_valid,response_verified,
 output reg [31:0] response_index,response_object,response_epoch,
 output wire [831:0] response_command,
 output wire lease_request,input wire lease_ready,
 output wire [31:0] lease_object,lease_page,lease_epoch,
 input wire lease_response_valid,lease_verified,
 input wire [31:0] lease_response_object,lease_response_page,lease_response_epoch,
 input wire lease_still_valid,
 output wire word_request,input wire word_ready,
 output wire [6:0] word_offset,
 input wire word_response_valid,input wire [6:0] word_response_offset,
 input wire [255:0] word_response_data,
 output wire lease_release,input wire release_ready,
 input wire cache_quiescent,output wire quiescent
);
 localparam IDLE=0,WAIT_BANK=1,LEASE=2,LEASE_REPLY=3,WORD=4,
  WORD_REPLY=5,WRITE_BANK=6,COMMIT=7,RELEASE=8,WAIT_RELEASE=9,
  READ_BANK=10,READ_WAIT=11,ASSEMBLE=12,REPORT=13;
 reg [3:0] state;
 reg [1:0] part;
 reg [6:0] fill_word;
 reg [7:0] fill_words;
 reg [1023:0] record;
 reg [255:0] held_word;
 reg aborted,good,quiet_seen,valid_page;
 reg [31:0] cached_page,cached_epoch;
 wire allocation_valid=({1'b0,BANK_BASE}+13'd128==A_WORDS)&&BANK_BASE>=2048;
 wire revoked=!authorized||!owner_live||authorization_epoch!=response_epoch;
 wire stopping=cancel||revoked||aborted;
 wire hit=valid_page&&cached_page==(response_index>>5)&&cached_epoch==response_epoch;
 wire [31:0] requested_page_base={response_index[31:5],5'b0};
 wire [31:0] remaining=PROGRAM_COMMANDS-requested_page_base;
 assign request_ready=state==IDLE&&cache_quiescent;
 assign quiescent=state==IDLE&&!bank_owned&&cache_quiescent;
 assign response_command=record[831:0];
 assign lease_request=state==LEASE;
 assign lease_object=PROGRAM_OBJECT;
 assign lease_page=response_index>>5;
 assign lease_epoch=response_epoch;
 assign word_request=state==WORD;
 assign word_offset=fill_word;
 assign lease_release=state==RELEASE;
 assign bank_write=bank_owned&&state==WRITE_BANK&&!stopping&&lease_still_valid;
 assign bank_write_address=BANK_BASE+{5'd0,fill_word};
 assign bank_write_data=held_word;
 assign bank_read=bank_owned&&state==READ_BANK&&!stopping;
 assign bank_read_address=BANK_BASE+{5'd0,response_index[4:0],part};
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;part<=0;fill_word<=0;fill_words<=0;record<=0;held_word<=0;
   bank_owned<=0;aborted<=0;good<=0;quiet_seen<=0;valid_page<=0;cached_page<=0;cached_epoch<=0;
   response_valid<=0;response_verified<=0;response_index<=0;response_object<=0;response_epoch<=0;
  end else begin
   response_valid<=0;response_verified<=0;
   if(cancel||!authorized||!owner_live||cached_epoch!=authorization_epoch)valid_page<=0;
   if(state!=IDLE&&(cancel||revoked))aborted<=1;
   case(state)
    IDLE:if(request_valid&&request_ready)begin
     response_index<=request_index;response_object<=request_object;response_epoch<=request_epoch;
     part<=0;record<=0;aborted<=0;good<=0;quiet_seen<=0;
     if(!allocation_valid||cancel||!authorized||!owner_live||request_index>=COMMAND_COUNT||request_index>=PROGRAM_COMMANDS||
        request_object!=PROGRAM_OBJECT||request_epoch!=authorization_epoch)state<=REPORT;
     else state<=WAIT_BANK;
    end
    WAIT_BANK:begin
     // Two consecutive genuine idle edges protect the final synchronous bank
     // read/write of the preceding command. No bank ownership while waiting.
     if(stopping)state<=REPORT;
     else if(!compute_quiescent)quiet_seen<=0;
     else if(!quiet_seen)quiet_seen<=1;
     else begin
      bank_owned<=1;
      if(hit)state<=READ_BANK;
      else begin
       valid_page<=0;fill_word<=0;
       fill_words<=remaining>=32 ? 8'd128 : {remaining[5:0],2'b00};
       state<=LEASE;
      end
     end
    end
    LEASE:if(lease_ready)state<=LEASE_REPLY;
    LEASE_REPLY:if(lease_response_valid)begin
     if(!lease_verified||lease_response_object!=PROGRAM_OBJECT||lease_response_page!=lease_page||
        lease_response_epoch!=response_epoch||!lease_still_valid||stopping)state<=RELEASE;
     else state<=WORD;
    end
    WORD:if(word_ready)state<=WORD_REPLY;
    WORD_REPLY:if(word_response_valid)begin
     if(word_response_offset!=fill_word||!lease_still_valid||stopping)state<=RELEASE;
     else begin held_word<=word_response_data;state<=WRITE_BANK;end
    end
    WRITE_BANK:begin
     if(!lease_still_valid||stopping)state<=RELEASE;
     else if({1'b0,fill_word}+1==fill_words)state<=COMMIT;
     else begin fill_word<=fill_word+1;state<=WORD;end
    end
    COMMIT:begin
     // The final write was committed on the PREVIOUS clock edge. Publish only
     // a complete, still-authorized page; partial fill can never be a hit.
     if(!stopping&&lease_still_valid)begin
      valid_page<=1;cached_page<=lease_page;cached_epoch<=response_epoch;
     end
     state<=RELEASE;
    end
    RELEASE:if(release_ready)state<=WAIT_RELEASE;
    WAIT_RELEASE:if(cache_quiescent)begin
     if(hit&&!stopping)state<=READ_BANK;else state<=REPORT;
    end
    READ_BANK:if(stopping)state<=REPORT;else state<=READ_WAIT;
    READ_WAIT:begin
     if(stopping)state<=REPORT;
     else begin
      record[part*256+:256]<=bank_read_data;
      if(part==3)state<=ASSEMBLE;
      else begin part<=part+1;state<=READ_BANK;end
     end
    end
    ASSEMBLE:begin good<=hit&&record[1023:832]==0&&!stopping;state<=REPORT;end
    REPORT:begin
     response_valid<=1;response_verified<=good&&!stopping;
     bank_owned<=0;state<=IDLE;
    end
    default:begin good<=0;valid_page<=0;bank_owned<=0;state<=IDLE;end
   endcase
  end
 end
endmodule
