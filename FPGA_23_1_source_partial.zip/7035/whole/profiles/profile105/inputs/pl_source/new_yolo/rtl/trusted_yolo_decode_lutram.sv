`timescale 1ns/1ps
// Fixed-point cat-head decode for the frozen 320x320 model and 640x480 source.
// This has an explicit Q8/Q30 policy: it is NOT float yd_decode bit equivalence.
// ROM initialization is configuration-authenticated; no runtime PS write port.
module trusted_yolo_decode_lutram #(
 parameter LUT_FILE="decode_lut.hex"
)(
 input wire clk,rst_n,start,cancel,authorized,
 input wire [31:0] session_id,frame_id,epoch,authorization_epoch,
 input wire [30:0] confidence_q30,
 output wire ready,busy,quiescent,
 output wire head_request,input wire head_ready,
 output wire [12:0] head_index,
 output wire [31:0] head_base,
 output wire [10:0] head_plane,head_cell,
 output wire [1:0] head_anchor,
 input wire response_valid,response_verified,input wire [12:0] response_index,
 input wire [31:0] response_session,response_frame,response_epoch,
 input wire [47:0] response_codes,
 output wire candidate_valid,input wire candidate_ready,
 output wire [12:0] candidate_index,
 output wire [223:0] candidate_data,
 input wire candidate_commit_error,memory_quiescent,
 output reg done,failed,
 output reg [31:0] result_session,result_frame,result_epoch
);
 localparam IDLE=0,REQUEST=1,RESPONSE=2,LOOKUP=3,CAPTURE=4,CALCULATE=5,
  PACK=6,OFFER=7,DRAIN=8,FINISH=9;
 reg [3:0] state;
 reg [1:0] layer,anchor;
 reg [5:0] gx,gy;
 reg [12:0] raw;
 reg [2:0] attribute;
 reg [47:0] codes;
 reg [255:0] lut_data;
 (* rom_style="distributed" *) reg [255:0] lut[0:767];
 initial $readmemh(LUT_FILE,lut);
 wire [9:0] lut_address={layer,codes[attribute*8+:8]};
 always @(posedge clk)if(state==LOOKUP)lut_data<=lut[lut_address];
 reg signed [31:0] ox,oy,half_w,half_h;
 reg [31:0] obj,cls,conf;
 reg signed [31:0] x0,y0,x1,y1;
 reg [223:0] packed_candidate;
 reg [30:0] threshold;
 reg abort_pending;
 wire revoked=!authorized||(authorization_epoch!=result_epoch);
 wire stopping=cancel||revoked||abort_pending||candidate_commit_error;
 wire [5:0] size=layer==0?40:layer==1?20:10;
 wire [5:0] stride=8<<layer;
 wire [63:0] conf_product=obj*cls;
 wire [63:0] conf_rounded=conf_product+64'd536870912;
 assign ready=state==IDLE&&memory_quiescent&&authorized&&!cancel;
 assign busy=state!=IDLE;
 assign quiescent=state==IDLE&&memory_quiescent;
 assign head_request=state==REQUEST;
 assign head_index=raw;
 assign head_base=layer==0?32'h2e00fa00:layer==1?32'h2e006400:32'h2e000000;
 assign head_plane=layer==0?1600:layer==1?400:100;
 assign head_cell=gy*size+gx;
 assign head_anchor=anchor;
 assign candidate_valid=state==OFFER;
 assign candidate_index=raw;
 assign candidate_data=packed_candidate;
 function [15:0] round_clip;
  input signed [63:0] q;
  input [15:0] upper;
  reg signed [63:0] whole;
  begin
   whole=q>>>8;
   if(q[7:0]>128||(q[7:0]==128&&whole[0]))whole=whole+1;
   if(whole<0)round_clip=0;
   else if(whole>upper)round_clip=upper;
   else round_clip=whole[15:0];
  end
 endfunction
 wire [15:0] rx0=round_clip($signed(x0)*64'sd2,640);
 wire [15:0] rx1=round_clip($signed(x1)*64'sd2,640);
 wire [15:0] ry0=round_clip($signed(y0)*64'sd2-64'sd20480,480);
 wire [15:0] ry1=round_clip($signed(y1)*64'sd2-64'sd20480,480);
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;layer<=0;anchor<=0;gx<=0;gy<=0;raw<=0;attribute<=0;
   codes<=0;ox<=0;oy<=0;half_w<=0;half_h<=0;obj<=0;cls<=0;conf<=0;
   x0<=0;y0<=0;x1<=0;y1<=0;packed_candidate<=0;threshold<=0;
   abort_pending<=0;done<=0;failed<=0;
   result_session<=0;result_frame<=0;result_epoch<=0;
  end else begin
   done<=0;failed<=0;
   if(state!=IDLE&&(cancel||revoked||candidate_commit_error))abort_pending<=1;
   case(state)
    IDLE:if(start&&ready)begin
     result_session<=session_id;result_frame<=frame_id;result_epoch<=epoch;
     threshold<=confidence_q30;layer<=0;anchor<=0;gx<=0;gy<=0;raw<=0;abort_pending<=0;
     if(!session_id||!frame_id||epoch!=authorization_epoch||
        confidence_q30==0||confidence_q30>=1073741824)state<=DRAIN;
     else state<=REQUEST;
    end
    REQUEST:if(head_ready)state<=RESPONSE;
    RESPONSE:if(response_valid)begin
     if(!response_verified||response_index!=raw||response_session!=result_session||
        response_frame!=result_frame||response_epoch!=result_epoch||stopping)state<=DRAIN;
     else begin codes<=response_codes;attribute<=0;state<=LOOKUP;end
    end
    LOOKUP:if(stopping)state<=DRAIN;else state<=CAPTURE;
    CAPTURE:begin
     if(stopping)state<=DRAIN;
     else begin
      case(attribute)
       0:ox<=lut_data[63:32];
       1:oy<=lut_data[63:32];
       2:half_w<=lut_data[64+anchor*32+:32];
       3:half_h<=lut_data[160+anchor*32+:32];
       4:obj<=lut_data[31:0];
       5:cls<=lut_data[31:0];
      endcase
      if(attribute==5)state<=CALCULATE;
      else begin attribute<=attribute+1;state<=LOOKUP;end
     end
    end
    CALCULATE:begin
     if(stopping)state<=DRAIN;
     else begin
      conf<=conf_rounded>>30;
      x0<=$signed({1'b0,gx})*$signed({1'b0,stride})*256+ox-half_w;
      x1<=$signed({1'b0,gx})*$signed({1'b0,stride})*256+ox+half_w;
      y0<=$signed({1'b0,gy})*$signed({1'b0,stride})*256+oy-half_h;
      y1<=$signed({1'b0,gy})*$signed({1'b0,stride})*256+oy+half_h;
      state<=PACK;
     end
    end
    PACK:begin
     if(stopping)state<=DRAIN;
     else begin
      if(obj>threshold&&conf>threshold&&rx1>rx0&&ry1>ry0)
       packed_candidate<={ry1,ry0,rx1,rx0,conf,y1,x1,y0,x0};
      else packed_candidate<={64'b0,conf,y1,x1,y0,x0};
      state<=OFFER;
     end
    end
    OFFER:if(candidate_ready)begin
     if(stopping)state<=DRAIN;
     else if(raw==6299)state<=FINISH;
     else begin
      raw<=raw+1;
      if(gx+1==size)begin
       gx<=0;
       if(gy+1==size)begin
        gy<=0;
        if(anchor==2)begin anchor<=0;layer<=layer+1;end
        else anchor<=anchor+1;
       end else gy<=gy+1;
      end else gx<=gx+1;
      state<=REQUEST;
     end
    end
    FINISH:if(stopping)state<=DRAIN;
     else if(memory_quiescent)begin done<=1;state<=IDLE;end
    DRAIN:if(memory_quiescent)begin failed<=1;state<=IDLE;end
    default:state<=DRAIN;
   endcase
  end
 end
endmodule
