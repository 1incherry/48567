`timescale 1ns/1ps
// One command at a time. All DMA addresses are aligned 32-byte words in 0x2xxxxxxx.
// AXI completion includes the last B response, not just the last W handshake.
module yolo_ddr_engine_legacy(
 input wire clk,rst_n,input wire cmd_valid,output wire cmd_ready,
 input wire [1:0] cmd_op,input wire [31:0] cmd_address,input wire [15:0] cmd_words,
 input wire [11:0] cmd_local_address,
 input wire [15:0] cfg_input_h,cfg_input_w,cfg_input_row0,cfg_input_rows,
 input wire [15:0] cfg_channel_blocks,cfg_output_w,cfg_output_row0,cfg_output_rows,
 input wire [3:0] cfg_kernel,cfg_stride,cfg_padding,
 input wire [7:0] cfg_zero_point,input wire signed [31:0] cfg_bias,
 output reg busy,done,error,
 output wire a_write,b_write,output wire [11:0] bank_write_address,output wire [255:0] bank_write_data,
 output wire a_read,b_read,output wire [11:0] a_read_address,b_read_address,
 input wire [255:0] a_read_data,b_read_data,
 output wire [31:0] M_AXI_ARADDR,output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,input wire [1:0] M_AXI_RRESP,input wire M_AXI_RLAST,M_AXI_RVALID,
 output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,M_AXI_WVALID,input wire M_AXI_WREADY,
 input wire [1:0] M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY
);
 localparam IDLE=0,READ_ADDR=1,READ_DATA=2,CONV_START=3,CONV_RUN=4,WRITE_WAIT=5;
 reg [2:0] state;reg bank_b;
 reg [31:0] address,out_address;
 reg [15:0] remaining;reg [11:0] local_address;
 reg half_a,half_b;
 wire input_read,weight_read,output_write,conv_done,conv_error,conv_ready;
 wire [31:0] input_address,weight_address,output_address,output_data;
 reg [255:0] output_buffer;reg [31:0] output_strobe;
 reg [3:0] fill;reg pending,aw_accepted,w_accepted;
 reg all_results;
 wire output_ready=!pending;
 wire result_fire=output_write&&output_ready;
 wire [31:0] total_outputs=cfg_output_w*cfg_output_rows;
 assign cmd_ready=state==IDLE;
 assign M_AXI_ARADDR=address;assign M_AXI_ARLEN=0;assign M_AXI_ARSIZE=5;assign M_AXI_ARBURST=1;
 assign M_AXI_ARVALID=state==READ_ADDR;assign M_AXI_RREADY=state==READ_DATA;
 assign a_write=(state==READ_DATA)&&M_AXI_RVALID&&!bank_b&&!M_AXI_RRESP;
 assign b_write=(state==READ_DATA)&&M_AXI_RVALID&&bank_b&&!M_AXI_RRESP;
 assign bank_write_address=local_address;assign bank_write_data=M_AXI_RDATA;
 assign a_read=input_read;assign b_read=weight_read;
 assign a_read_address=input_address[12:1];assign b_read_address=weight_address[12:1];
 always @(posedge clk)begin
  if(input_read)half_a<=input_address[0];
  if(weight_read)half_b<=weight_address[0];
 end
 assign M_AXI_AWADDR=out_address;assign M_AXI_AWLEN=0;assign M_AXI_AWSIZE=5;assign M_AXI_AWBURST=1;
 assign M_AXI_AWVALID=pending&&!aw_accepted;
 assign M_AXI_WDATA=output_buffer;assign M_AXI_WSTRB=output_strobe;
 assign M_AXI_WLAST=1;assign M_AXI_WVALID=pending&&!w_accepted;
 assign M_AXI_BREADY=pending&&aw_accepted&&w_accepted;
 yolo_conv_stripe conv(
  .clk(clk),.rst_n(rst_n),.command_valid(state==CONV_START),.command_ready(conv_ready),
  .cfg_input_h(cfg_input_h),.cfg_input_w(cfg_input_w),.cfg_input_row0(cfg_input_row0),.cfg_input_rows(cfg_input_rows),
  .cfg_channel_blocks(cfg_channel_blocks),.cfg_output_w(cfg_output_w),.cfg_output_row0(cfg_output_row0),.cfg_output_rows(cfg_output_rows),
  .cfg_kernel(cfg_kernel),.cfg_stride(cfg_stride),.cfg_padding(cfg_padding),.cfg_zero_point(cfg_zero_point),.cfg_bias(cfg_bias),
  .input_read(input_read),.input_address(input_address),.input_data(half_a?a_read_data[255:128]:a_read_data[127:0]),
  .weight_read(weight_read),.weight_address(weight_address),.weight_data(half_b?b_read_data[255:128]:b_read_data[127:0]),
  .output_write(output_write),.output_ready(output_ready),.output_address(output_address),.output_data(output_data),
  .done(conv_done),.error(conv_error));
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;busy<=0;done<=0;error<=0;bank_b<=0;address<=0;out_address<=0;
   remaining<=0;local_address<=0;output_buffer<=0;output_strobe<=0;
   fill<=0;pending<=0;aw_accepted<=0;w_accepted<=0;all_results<=0;
  end else begin
   done<=0;
   if(M_AXI_AWVALID&&M_AXI_AWREADY)aw_accepted<=1;
   if(M_AXI_WVALID&&M_AXI_WREADY)w_accepted<=1;
   if(M_AXI_BVALID&&M_AXI_BREADY)begin
    pending<=0;aw_accepted<=0;w_accepted<=0;fill<=0;output_buffer<=0;output_strobe<=0;out_address<=out_address+32;
    if(M_AXI_BRESP)error<=1;
   end
   if(result_fire)begin
    output_buffer[fill*32+:32]<=output_data;output_strobe[fill*4+:4]<=4'hf;
    if(fill==7||output_address==total_outputs-1)begin pending<=1;aw_accepted<=0;w_accepted<=0;end
    else fill<=fill+1;
   end
   case(state)
    IDLE:if(cmd_valid)begin
     error<=0;
     if(cmd_address[31:28]!=4'h2||cmd_address[4:0]!=0||
       (cmd_op<2&&(!cmd_words||({1'b0,cmd_local_address}+{1'b0,cmd_words})>(cmd_op==0?2548:2352)))||
       (cmd_op==2&&(!total_outputs||total_outputs>20384))||cmd_op==3||
       ({1'b0,cmd_address}+({17'd0,cmd_words}<<5)>33'h030000000))begin done<=1;error<=1;end
     else begin
      busy<=1;address<=cmd_address;out_address<=cmd_address;remaining<=cmd_words;local_address<=cmd_local_address;
      bank_b<=cmd_op==1;state<=cmd_op==2?CONV_START:READ_ADDR;all_results<=0;
     end
    end
    READ_ADDR:if(M_AXI_ARREADY)state<=READ_DATA;
    READ_DATA:if(M_AXI_RVALID)begin
     if(M_AXI_RRESP||!M_AXI_RLAST)error<=1;
     if(remaining==1||M_AXI_RRESP||!M_AXI_RLAST)begin state<=IDLE;busy<=0;done<=1;end
     else begin remaining<=remaining-1;local_address<=local_address+1;address<=address+32;state<=READ_ADDR;end
    end
    CONV_START:if(conv_ready)state<=CONV_RUN;
    CONV_RUN:if(conv_done)begin all_results<=1;if(conv_error)error<=1;state<=WRITE_WAIT;end
    WRITE_WAIT:if(!pending)begin state<=IDLE;busy<=0;done<=1;end
   endcase
  end
 end
endmodule
