`timescale 1ns/1ps
// Compatibility wrapper: operations0/1/2 keep the frozen legacy path. Operation3
// uses the byte-addressed descriptor engine and the same SRAM/AXI interfaces.
module yolo_ddr_engine(
 input wire clk,rst_n,input wire cmd_valid,output wire cmd_ready,
 input wire [1:0] cmd_op,input wire [31:0] cmd_address,input wire [15:0] cmd_words,
 input wire [11:0] cmd_local_address,
 input wire [511:0] cfg_descriptor,
 input wire [15:0] cfg_input_h,cfg_input_w,cfg_input_row0,cfg_input_rows,
 input wire [15:0] cfg_channel_blocks,cfg_output_w,cfg_output_row0,cfg_output_rows,
 input wire [3:0] cfg_kernel,cfg_stride,cfg_padding,
 input wire [7:0] cfg_zero_point,input wire signed [31:0] cfg_bias,
 output wire busy,done,error,
 output wire a_write,b_write,output wire [11:0] bank_write_address,output wire [255:0] bank_write_data,
 output wire a_read,b_read,output wire [11:0] a_read_address,b_read_address,
 input wire [255:0] a_read_data,b_read_data,
 output wire [31:0] M_AXI_ARADDR,output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,input wire [1:0] M_AXI_RRESP,input wire M_AXI_RLAST,M_AXI_RVALID,
 output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,M_AXI_WVALID,input wire M_AXI_WREADY,
 input wire [1:0] M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY
);

reg extension_active,last_error;
wire l_busy;
wire l_done;
wire l_error;
wire l_cmd_ready;
wire l_a_write;
wire l_b_write;
wire [11:0] l_bank_write_address;
wire [255:0] l_bank_write_data;
wire l_a_read;
wire l_b_read;
wire [11:0] l_a_read_address;
wire [11:0] l_b_read_address;
wire [31:0] l_M_AXI_ARADDR;
wire [7:0] l_M_AXI_ARLEN;
wire [2:0] l_M_AXI_ARSIZE;
wire [1:0] l_M_AXI_ARBURST;
wire l_M_AXI_ARVALID;
wire l_M_AXI_RREADY;
wire [31:0] l_M_AXI_AWADDR;
wire [7:0] l_M_AXI_AWLEN;
wire [2:0] l_M_AXI_AWSIZE;
wire [1:0] l_M_AXI_AWBURST;
wire l_M_AXI_AWVALID;
wire [255:0] l_M_AXI_WDATA;
wire [31:0] l_M_AXI_WSTRB;
wire l_M_AXI_WLAST;
wire l_M_AXI_WVALID;
wire l_M_AXI_BREADY;
wire e_busy;
wire e_done;
wire e_error;
wire e_cmd_ready;
wire e_a_write;
wire e_b_write;
wire [11:0] e_bank_write_address;
wire [255:0] e_bank_write_data;
wire e_a_read;
wire e_b_read;
wire [11:0] e_a_read_address;
wire [11:0] e_b_read_address;
wire [31:0] e_M_AXI_ARADDR;
wire [7:0] e_M_AXI_ARLEN;
wire [2:0] e_M_AXI_ARSIZE;
wire [1:0] e_M_AXI_ARBURST;
wire e_M_AXI_ARVALID;
wire e_M_AXI_RREADY;
wire [31:0] e_M_AXI_AWADDR;
wire [7:0] e_M_AXI_AWLEN;
wire [2:0] e_M_AXI_AWSIZE;
wire [1:0] e_M_AXI_AWBURST;
wire e_M_AXI_AWVALID;
wire [255:0] e_M_AXI_WDATA;
wire [31:0] e_M_AXI_WSTRB;
wire e_M_AXI_WLAST;
wire e_M_AXI_WVALID;
wire e_M_AXI_BREADY;
assign cmd_ready=l_cmd_ready&&e_cmd_ready&&!extension_active&&!l_busy;
assign busy=l_busy||e_busy||extension_active;
assign done=extension_active?e_done:l_done;
assign error=extension_active?e_error:((l_busy||l_done)?l_error:last_error);
always @(posedge clk)begin
 if(!rst_n)begin extension_active<=0;last_error<=0;end
 else begin
  if(cmd_valid&&cmd_ready)begin extension_active<=cmd_op==3;last_error<=0;end
  if(done)last_error<=extension_active?e_error:l_error;
  if(extension_active&&e_done)extension_active<=0;
 end
end
assign a_write=extension_active?e_a_write:l_a_write;
assign b_write=extension_active?e_b_write:l_b_write;
assign bank_write_address=extension_active?e_bank_write_address:l_bank_write_address;
assign bank_write_data=extension_active?e_bank_write_data:l_bank_write_data;
assign a_read=extension_active?e_a_read:l_a_read;
assign b_read=extension_active?e_b_read:l_b_read;
assign a_read_address=extension_active?e_a_read_address:l_a_read_address;
assign b_read_address=extension_active?e_b_read_address:l_b_read_address;
assign M_AXI_ARADDR=extension_active?e_M_AXI_ARADDR:l_M_AXI_ARADDR;
assign M_AXI_ARLEN=extension_active?e_M_AXI_ARLEN:l_M_AXI_ARLEN;
assign M_AXI_ARSIZE=extension_active?e_M_AXI_ARSIZE:l_M_AXI_ARSIZE;
assign M_AXI_ARBURST=extension_active?e_M_AXI_ARBURST:l_M_AXI_ARBURST;
assign M_AXI_ARVALID=extension_active?e_M_AXI_ARVALID:l_M_AXI_ARVALID;
assign M_AXI_RREADY=extension_active?e_M_AXI_RREADY:l_M_AXI_RREADY;
assign M_AXI_AWADDR=extension_active?e_M_AXI_AWADDR:l_M_AXI_AWADDR;
assign M_AXI_AWLEN=extension_active?e_M_AXI_AWLEN:l_M_AXI_AWLEN;
assign M_AXI_AWSIZE=extension_active?e_M_AXI_AWSIZE:l_M_AXI_AWSIZE;
assign M_AXI_AWBURST=extension_active?e_M_AXI_AWBURST:l_M_AXI_AWBURST;
assign M_AXI_AWVALID=extension_active?e_M_AXI_AWVALID:l_M_AXI_AWVALID;
assign M_AXI_WDATA=extension_active?e_M_AXI_WDATA:l_M_AXI_WDATA;
assign M_AXI_WSTRB=extension_active?e_M_AXI_WSTRB:l_M_AXI_WSTRB;
assign M_AXI_WLAST=extension_active?e_M_AXI_WLAST:l_M_AXI_WLAST;
assign M_AXI_WVALID=extension_active?e_M_AXI_WVALID:l_M_AXI_WVALID;
assign M_AXI_BREADY=extension_active?e_M_AXI_BREADY:l_M_AXI_BREADY;
yolo_ddr_engine_legacy u_l(
.clk(clk),
.rst_n(rst_n),
.cmd_valid(cmd_valid&&cmd_ready&&(cmd_op!=3)),
.cmd_op(cmd_op),
.cmd_address(cmd_address),
.cmd_words(cmd_words),
.cmd_local_address(cmd_local_address),
.cfg_input_h(cfg_input_h),
.cfg_input_w(cfg_input_w),
.cfg_input_row0(cfg_input_row0),
.cfg_input_rows(cfg_input_rows),
.cfg_channel_blocks(cfg_channel_blocks),
.cfg_output_w(cfg_output_w),
.cfg_output_row0(cfg_output_row0),
.cfg_output_rows(cfg_output_rows),
.cfg_kernel(cfg_kernel),
.cfg_stride(cfg_stride),
.cfg_padding(cfg_padding),
.cfg_zero_point(cfg_zero_point),
.cfg_bias(cfg_bias),
.a_read_data(a_read_data),
.b_read_data(b_read_data),
.M_AXI_ARREADY((extension_active!=1'b1)?M_AXI_ARREADY:1'b0),
.M_AXI_RDATA(M_AXI_RDATA),
.M_AXI_RRESP(M_AXI_RRESP),
.M_AXI_RLAST(M_AXI_RLAST),
.M_AXI_RVALID((extension_active!=1'b1)?M_AXI_RVALID:1'b0),
.M_AXI_AWREADY((extension_active!=1'b1)?M_AXI_AWREADY:1'b0),
.M_AXI_WREADY((extension_active!=1'b1)?M_AXI_WREADY:1'b0),
.M_AXI_BRESP(M_AXI_BRESP),
.M_AXI_BVALID((extension_active!=1'b1)?M_AXI_BVALID:1'b0),
.busy(l_busy),
.done(l_done),
.error(l_error),
.cmd_ready(l_cmd_ready),
.a_write(l_a_write),
.b_write(l_b_write),
.bank_write_address(l_bank_write_address),
.bank_write_data(l_bank_write_data),
.a_read(l_a_read),
.b_read(l_b_read),
.a_read_address(l_a_read_address),
.b_read_address(l_b_read_address),
.M_AXI_ARADDR(l_M_AXI_ARADDR),
.M_AXI_ARLEN(l_M_AXI_ARLEN),
.M_AXI_ARSIZE(l_M_AXI_ARSIZE),
.M_AXI_ARBURST(l_M_AXI_ARBURST),
.M_AXI_ARVALID(l_M_AXI_ARVALID),
.M_AXI_RREADY(l_M_AXI_RREADY),
.M_AXI_AWADDR(l_M_AXI_AWADDR),
.M_AXI_AWLEN(l_M_AXI_AWLEN),
.M_AXI_AWSIZE(l_M_AXI_AWSIZE),
.M_AXI_AWBURST(l_M_AXI_AWBURST),
.M_AXI_AWVALID(l_M_AXI_AWVALID),
.M_AXI_WDATA(l_M_AXI_WDATA),
.M_AXI_WSTRB(l_M_AXI_WSTRB),
.M_AXI_WLAST(l_M_AXI_WLAST),
.M_AXI_WVALID(l_M_AXI_WVALID),
.M_AXI_BREADY(l_M_AXI_BREADY)
);
yolo_nonconv_engine u_e(
.clk(clk),
.rst_n(rst_n),
.cmd_valid(cmd_valid&&cmd_ready&&(cmd_op==3)),
.a_read_data(a_read_data),
.b_read_data(b_read_data),
.M_AXI_ARREADY((extension_active==1'b1)?M_AXI_ARREADY:1'b0),
.M_AXI_RDATA(M_AXI_RDATA),
.M_AXI_RRESP(M_AXI_RRESP),
.M_AXI_RLAST(M_AXI_RLAST),
.M_AXI_RVALID((extension_active==1'b1)?M_AXI_RVALID:1'b0),
.M_AXI_AWREADY((extension_active==1'b1)?M_AXI_AWREADY:1'b0),
.M_AXI_WREADY((extension_active==1'b1)?M_AXI_WREADY:1'b0),
.M_AXI_BRESP(M_AXI_BRESP),
.M_AXI_BVALID((extension_active==1'b1)?M_AXI_BVALID:1'b0),
.cfg_descriptor(cfg_descriptor),
.busy(e_busy),
.done(e_done),
.error(e_error),
.cmd_ready(e_cmd_ready),
.a_write(e_a_write),
.b_write(e_b_write),
.bank_write_address(e_bank_write_address),
.bank_write_data(e_bank_write_data),
.a_read(e_a_read),
.b_read(e_b_read),
.a_read_address(e_a_read_address),
.b_read_address(e_b_read_address),
.M_AXI_ARADDR(e_M_AXI_ARADDR),
.M_AXI_ARLEN(e_M_AXI_ARLEN),
.M_AXI_ARSIZE(e_M_AXI_ARSIZE),
.M_AXI_ARBURST(e_M_AXI_ARBURST),
.M_AXI_ARVALID(e_M_AXI_ARVALID),
.M_AXI_RREADY(e_M_AXI_RREADY),
.M_AXI_AWADDR(e_M_AXI_AWADDR),
.M_AXI_AWLEN(e_M_AXI_AWLEN),
.M_AXI_AWSIZE(e_M_AXI_AWSIZE),
.M_AXI_AWBURST(e_M_AXI_AWBURST),
.M_AXI_AWVALID(e_M_AXI_AWVALID),
.M_AXI_WDATA(e_M_AXI_WDATA),
.M_AXI_WSTRB(e_M_AXI_WSTRB),
.M_AXI_WLAST(e_M_AXI_WLAST),
.M_AXI_WVALID(e_M_AXI_WVALID),
.M_AXI_BREADY(e_M_AXI_BREADY)
);
endmodule
