`timescale 1ns/1ps
// Descriptor-driven exact non-convolution path. Shared A is a 64KiB DMA cache;
// shared B holds the currently loaded LUT/1056-byte quantizer record. No tensor
// storage is privately duplicated. AXI reads prefetch up to 16 aligned beats,
// never cross 4KiB or the source aperture; writes combine byte strobes and only
// complete after B. All in-flight bursts/responses are drained on a fault.
module yolo_nonconv_engine(
 input wire clk,rst_n,input wire cmd_valid,output wire cmd_ready,
 input wire [511:0] cfg_descriptor,output reg busy,done,error,
 output wire a_write,b_write,output wire [11:0] bank_write_address,
 output wire [255:0] bank_write_data,
 output wire a_read,b_read,output wire [11:0] a_read_address,b_read_address,
 input wire [255:0] a_read_data,b_read_data,
 output wire [31:0] M_AXI_ARADDR,output wire [7:0] M_AXI_ARLEN,
 output wire [2:0] M_AXI_ARSIZE,output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,
 input wire [255:0] M_AXI_RDATA,input wire [1:0] M_AXI_RRESP,
 input wire M_AXI_RLAST,M_AXI_RVALID,output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,output wire [7:0] M_AXI_AWLEN,
 output wire [2:0] M_AXI_AWSIZE,output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,
 output wire [255:0] M_AXI_WDATA,output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,M_AXI_WVALID,input wire M_AXI_WREADY,
 input wire [1:0] M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY
);
 localparam COPY8=0,UNARY8=1,BINARY8=2,PACK16=3,NEAREST2=4,POOL5=5,
            QUANT32=6,RGB_UNARY=7,UNARY32=8;
 localparam IDLE=0,VALIDATE=1,PREP=2,GET=3,BANK_REQ=4,BANK_WAIT=5,
            READ_ADDR=6,READ_DATA=7,GOT0=8,GOT1=9,LUT_REQ=10,LUT_WAIT=11,
            EMIT=12,POOL_SCAN=13,POOL_GOT=14,POOL_NEXT=15,
            QVALID_REQ=16,QVALID_WAIT=17,QBEGIN=18,QTABLE_REQ=19,
            QTABLE_WAIT=20,QCFG_SEND=21,QSTART=22,QSTREAM=23,QDRAIN=24,
            WORK_DONE=25,FAULT=26,GEOM1=27,GEOM2=28,GEOM3=29,
            POOL_COORD=30,POOL_ADDR1=31,POOL_ADDR2=32,VALIDATE_LATCH=33;
 reg [5:0] state,return_state;
 reg [31:0] d[0:15];
 wire [3:0] opcode=d[0][3:0];
 reg [2047:0] cache_valid;
 (* ram_style="distributed" *) reg [16:0] cache_tags[0:2047];
 reg [31:0] request_address;
 reg request_operand;
 reg [31:0] fill_address;
 reg fill_operand;
 reg [4:0] burst_beats,beats_left;
 reg read_bad;
 reg hot0_valid,hot1_valid;
 reg [26:0] hot0_tag,hot1_tag;
 reg [255:0] hot0_data,hot1_data;
 reg [7:0] fetched_byte,left_byte;
 reg [15:0] lut_index;
 reg [31:0] emit_value;
 reg [1:0] emit_byte_index;
 reg [31:0] item_index,x,y,c;
 reg [2:0] tap_x,tap_y;
 reg [7:0] pool_max;
 reg [63:0] source0_end,source1_end;
 reg [31:0] write_cursor,out_address;
 reg [255:0] output_buffer;
 reg [31:0] output_strobe;
 reg pending,aw_accepted,w_accepted;
 reg [7:0] qcfg_index;
 reg [255:0] qvalid_bits,qtable_word;
 reg [31:0] q_input_index,q_output_index,q_source_pointer;
 wire q_begin_ready,q_cfg_ready,q_configured,q_cfg_error;
 wire q_input_ready,q_output_valid;
 wire [7:0] q_output_data;
 wire q_hot=hot0_valid&&(hot0_tag==q_source_pointer[31:5]);
 wire q_input_valid=(state==QSTREAM)&&q_input_index<d[4]&&q_hot&&!error;
 wire q_output_ready=busy&&opcode==QUANT32&&!error&&!pending&&q_output_index<d[4];
 wire q_input_fire=q_input_valid&&q_input_ready;
 wire q_output_fire=q_output_valid&&q_output_ready;
 wire writer_valid=((state==EMIT)&&!error)||q_output_valid&&opcode==QUANT32&&busy&&!error&&q_output_index<d[4];
 wire [7:0] writer_data=opcode==QUANT32?q_output_data:emit_value[emit_byte_index*8+:8];
 wire writer_fire=writer_valid&&!pending;
 wire writer_last=opcode==QUANT32?(q_output_index==d[4]-1):
                  (item_index==d[4]-1&&(opcode!=UNARY32||emit_byte_index==3));
 wire [31:0] request_word={request_address[31:5],5'b0};
 wire hot_hit=request_operand?(hot1_valid&&hot1_tag==request_address[31:5]):
                                      (hot0_valid&&hot0_tag==request_address[31:5]);
 wire [255:0] hot_data=request_operand?hot1_data:hot0_data;
 function automatic [10:0] cache_index(input [31:0] addr,input operand);
  begin cache_index=(opcode==BINARY8)?{operand,addr[14:5]}:addr[15:5];end
 endfunction
 function automatic [16:0] cache_tag(input [31:0] addr);
  begin cache_tag=(opcode==BINARY8)?addr[31:15]:{1'b0,addr[31:16]};end
 endfunction
 wire [10:0] request_index=cache_index(request_address,request_operand);
 wire cached=cache_valid[request_index]&&cache_tags[request_index]==cache_tag(request_address);
 wire [10:0] fill_index=cache_index(fill_address,fill_operand);
 wire [63:0] selected_end=request_operand?source1_end:source0_end;
 wire [63:0] rounded_end=(selected_end+31)&64'hffffffffffffffe0;
 wire [63:0] available_beats=(rounded_end-{32'd0,request_word})>>5;
 wire [8:0] page_beats=(13'd4096-{1'b0,request_word[11:0]})>>5;
 wire [4:0] next_burst=(available_beats<16)?available_beats[4:0]:
                            (page_beats<16?page_beats[4:0]:5'd16);
 // Also cap a short source span at the page boundary (both limits apply).
 wire [4:0] bounded_burst=(page_beats<next_burst)?page_beats[4:0]:next_burst;

 reg [63:0] calc_plane,calc_src_bytes,calc_dst_bytes,calc_src_end,calc_src1_end,calc_dst_end;
 reg [63:0] calc_elements;
 reg descriptor_ok;
 reg descriptor_valid;
 always @* begin
  calc_plane={48'd0,d[5][15:0]}*d[6][15:0];
  calc_src_bytes={32'd0,d[4]};calc_dst_bytes={32'd0,d[4]};calc_elements=0;
  if(opcode==QUANT32)calc_src_bytes={32'd0,d[4]}<<2;
  if(opcode==UNARY32)calc_dst_bytes={32'd0,d[4]}<<2;
  if(opcode==PACK16||opcode==NEAREST2||opcode==POOL5||opcode==RGB_UNARY)
   calc_src_bytes=calc_plane*d[7][15:0];
  calc_src_end={32'd0,d[1]}+calc_src_bytes;
  calc_src1_end={32'd0,d[2]}+{32'd0,d[4]};
  calc_dst_end={32'd0,d[3]}+calc_dst_bytes;
  descriptor_ok=d[0]<=8&&d[4]!=0&&d[4]<=32'h01000000&&d[10]==0&&d[11]==0&&d[14]==0&&d[15]==32'h594f5033;
  descriptor_ok=descriptor_ok&&d[1]>=32'h20000000&&calc_src_end<=64'h30000000&&
    d[3]>=32'h2c000000&&calc_dst_end<=64'h30000000&&
    !({32'd0,d[3]}<calc_src_end&&{32'd0,d[1]}<calc_dst_end);
  if(opcode==BINARY8)descriptor_ok=descriptor_ok&&d[2]>=32'h20000000&&calc_src1_end<=64'h30000000&&
    !({32'd0,d[3]}<calc_src1_end&&{32'd0,d[2]}<calc_dst_end);
  if(opcode==QUANT32)descriptor_ok=descriptor_ok&&d[1][1:0]==0;
  if(opcode==UNARY8||opcode==RGB_UNARY)descriptor_ok=descriptor_ok&&d[13]<=2344;
  if(opcode==BINARY8)descriptor_ok=descriptor_ok&&d[13]<=304;
  if(opcode==QUANT32)descriptor_ok=descriptor_ok&&d[13]<=2319;
  if(opcode==UNARY32)descriptor_ok=descriptor_ok&&d[13]<=2320;
  if(opcode==PACK16||opcode==NEAREST2||opcode==POOL5||opcode==RGB_UNARY)begin
   descriptor_ok=descriptor_ok&&d[5]>0&&d[5]<=2048&&d[6]>0&&d[6]<=2048&&
     d[7]>0&&d[7]<=1024&&{32'd0,d[9]}==calc_plane;
   if(opcode==PACK16)begin
    calc_elements=calc_plane*d[8][15:0];
    descriptor_ok=descriptor_ok&&d[8]>=d[7]&&d[8]<=1024&&d[8][3:0]==0&&{32'd0,d[4]}==calc_elements;
   end else if(opcode==NEAREST2)descriptor_ok=descriptor_ok&&{32'd0,d[4]}==(calc_src_bytes<<2);
   else descriptor_ok=descriptor_ok&&{32'd0,d[4]}==calc_src_bytes;
   if(opcode==RGB_UNARY)descriptor_ok=descriptor_ok&&d[7]==3;
  end
 end
 // Keep every dynamic product in its own cycle before adding base addresses.
 reg [31:0] row_product,channel_product,spatial_reg,channel_base,rgb_product,linear_address;
 reg signed [32:0] pool_x_reg,pool_y_reg;
 reg [31:0] pool_row_product,pool_channel_product,pool_linear,pool_base;
 wire signed [32:0] pool_sx=$signed({1'b0,x})+$signed({30'd0,tap_x})-33'sd2;
 wire signed [32:0] pool_sy=$signed({1'b0,y})+$signed({30'd0,tap_y})-33'sd2;
 wire pool_inside=pool_x_reg>=0&&pool_y_reg>=0&&pool_x_reg<$signed({1'b0,d[6]})&&pool_y_reg<$signed({1'b0,d[5]});
 wire [31:0] output_w=(opcode==NEAREST2)?d[6]<<1:d[6];
 wire [31:0] output_h=(opcode==NEAREST2)?d[5]<<1:d[5];

 assign cmd_ready=state==IDLE;
 assign a_write=state==READ_DATA&&M_AXI_RVALID&&!M_AXI_RRESP&&!error&&!read_bad&&beats_left!=0;
 assign b_write=1'b0;
 assign bank_write_address={1'b0,fill_index};assign bank_write_data=M_AXI_RDATA;
 assign a_read=state==BANK_REQ;
 assign a_read_address={1'b0,request_index};
 assign b_read=state==LUT_REQ||state==QVALID_REQ||state==QTABLE_REQ;
 assign b_read_address=(state==QVALID_REQ)?d[13][11:0]+12'd32:
         (state==QTABLE_REQ)?d[13][11:0]+{7'd0,qcfg_index[7:3]}:
         d[13][11:0]+((opcode==UNARY32)?{7'd0,lut_index[7:3]}:{1'b0,lut_index[15:5]});
 assign M_AXI_ARADDR=fill_address;
 assign M_AXI_ARLEN={3'd0,burst_beats}-1'b1;
 assign M_AXI_ARSIZE=5;assign M_AXI_ARBURST=1;
 assign M_AXI_ARVALID=state==READ_ADDR;assign M_AXI_RREADY=state==READ_DATA;
 assign M_AXI_AWADDR=out_address;assign M_AXI_AWLEN=0;
 assign M_AXI_AWSIZE=5;assign M_AXI_AWBURST=1;
 assign M_AXI_AWVALID=pending&&!aw_accepted;
 assign M_AXI_WDATA=output_buffer;assign M_AXI_WSTRB=output_strobe;
 assign M_AXI_WLAST=1;assign M_AXI_WVALID=pending&&!w_accepted;
 assign M_AXI_BREADY=pending&&aw_accepted&&w_accepted;

 yolo_threshold_quantizer_pipe quantizer(
  .clk(clk),.rst_n(rst_n&&busy&&opcode==QUANT32&&!error),
  .cfg_begin(state==QBEGIN),.cfg_begin_ready(q_begin_ready),
  .cfg_valid(state==QCFG_SEND),.cfg_ready(q_cfg_ready),
  .cfg_threshold(qtable_word[qcfg_index[2:0]*32+:32]),
  .cfg_reachable(qvalid_bits[qcfg_index]),.configured(q_configured),.cfg_error(q_cfg_error),
  .acc_data(hot0_data[q_source_pointer[4:2]*32+:32]),.acc_valid(q_input_valid),.acc_ready(q_input_ready),
  .q_data(q_output_data),.q_valid(q_output_valid),.q_ready(q_output_ready));

 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;return_state<=IDLE;busy<=0;done<=0;error<=0;
   cache_valid<=0;hot0_valid<=0;hot1_valid<=0;hot0_tag<=0;hot1_tag<=0;hot0_data<=0;hot1_data<=0;
   request_address<=0;request_operand<=0;fill_address<=0;fill_operand<=0;burst_beats<=1;beats_left<=0;read_bad<=0;
   fetched_byte<=0;left_byte<=0;lut_index<=0;emit_value<=0;emit_byte_index<=0;
   item_index<=0;x<=0;y<=0;c<=0;tap_x<=0;tap_y<=0;pool_max<=0;source0_end<=0;source1_end<=0;
   write_cursor<=0;out_address<=0;output_buffer<=0;output_strobe<=0;pending<=0;aw_accepted<=0;w_accepted<=0;
   qcfg_index<=0;qvalid_bits<=0;qtable_word<=0;q_input_index<=0;q_output_index<=0;q_source_pointer<=0;
   row_product<=0;channel_product<=0;spatial_reg<=0;channel_base<=0;rgb_product<=0;linear_address<=0;
   pool_x_reg<=0;pool_y_reg<=0;pool_row_product<=0;pool_channel_product<=0;pool_linear<=0;pool_base<=0;
   descriptor_valid<=0;
   for(i=0;i<16;i=i+1)d[i]<=0;
  end else begin
   done<=0;
   if(M_AXI_AWVALID&&M_AXI_AWREADY)aw_accepted<=1;
   if(M_AXI_WVALID&&M_AXI_WREADY)w_accepted<=1;
   if(M_AXI_BVALID&&M_AXI_BREADY)begin
    pending<=0;aw_accepted<=0;w_accepted<=0;output_buffer<=0;output_strobe<=0;out_address<=out_address+32;
    if(M_AXI_BRESP)error<=1;
   end
   if(writer_fire)begin
    output_buffer[write_cursor[4:0]*8+:8]<=writer_data;
    output_strobe[write_cursor[4:0]]<=1;
    write_cursor<=write_cursor+1;
    if(writer_last||write_cursor[4:0]==31)begin pending<=1;aw_accepted<=0;w_accepted<=0;end
    if(opcode==QUANT32)q_output_index<=q_output_index+1;
   end
   case(state)
    IDLE:if(cmd_valid)begin
     for(i=0;i<16;i=i+1)d[i]<=cfg_descriptor[i*32+:32];
     busy<=1;error<=0;state<=VALIDATE_LATCH;
     cache_valid<=0;hot0_valid<=0;hot1_valid<=0;
     pending<=0;aw_accepted<=0;w_accepted<=0;output_buffer<=0;output_strobe<=0;
    end
    VALIDATE_LATCH:begin descriptor_valid<=descriptor_ok;state<=VALIDATE;end
    VALIDATE:begin
     if(!descriptor_valid)begin error<=1;state<=FAULT;end
     else begin
      source0_end<=calc_src_end;source1_end<=calc_src1_end;
      write_cursor<=d[3];out_address<={d[3][31:5],5'b0};
      item_index<=0;x<=0;y<=0;c<=0;emit_byte_index<=0;
      q_input_index<=0;q_output_index<=0;q_source_pointer<=d[1];
      state<=opcode==QUANT32?QVALID_REQ:PREP;
     end
    end
    PREP:begin
     emit_byte_index<=0;
     if(opcode==PACK16&&c>=d[7])begin emit_value<={24'd0,d[12][7:0]};state<=EMIT;end
     else if(opcode==POOL5)begin pool_max<=0;tap_x<=0;tap_y<=0;state<=POOL_SCAN;end
     else if(opcode==PACK16||opcode==NEAREST2||opcode==RGB_UNARY)begin
      row_product<=((opcode==NEAREST2)?(y>>1):y)*d[6];channel_product<=c*d[9];state<=GEOM1;
     end else begin request_address<=d[1]+item_index;request_operand<=0;return_state<=GOT0;state<=GET;end
    end
    GEOM1:begin
     spatial_reg<=row_product+((opcode==NEAREST2)?(x>>1):x);channel_base<=d[1]+channel_product;state<=GEOM2;
    end
    GEOM2:begin rgb_product<=spatial_reg*d[7];linear_address<=channel_base+spatial_reg;state<=GEOM3;end
    GEOM3:begin
     request_address<=(opcode==RGB_UNARY)?d[1]+rgb_product+c:linear_address;
     request_operand<=0;return_state<=GOT0;state<=GET;
    end
    GET:begin
     if(hot_hit)begin fetched_byte<=hot_data[request_address[4:0]*8+:8];state<=return_state;end
     else if(cached)state<=BANK_REQ;
     else begin
      fill_address<=request_word;fill_operand<=request_operand;
      burst_beats<=bounded_burst;beats_left<=bounded_burst;read_bad<=0;state<=READ_ADDR;
     end
    end
    BANK_REQ:state<=BANK_WAIT;
    BANK_WAIT:begin
     if(request_operand)begin hot1_data<=a_read_data;hot1_tag<=request_address[31:5];hot1_valid<=1;end
     else begin hot0_data<=a_read_data;hot0_tag<=request_address[31:5];hot0_valid<=1;end
     state<=GET;
    end
    READ_ADDR:if(M_AXI_ARREADY)state<=READ_DATA;
    READ_DATA:if(M_AXI_RVALID)begin
     if(!M_AXI_RRESP&&!error&&!read_bad&&beats_left!=0)begin
      cache_valid[fill_index]<=1;cache_tags[fill_index]<=cache_tag(fill_address);
      if(fill_address==request_word)begin
       if(fill_operand)begin hot1_data<=M_AXI_RDATA;hot1_tag<=fill_address[31:5];hot1_valid<=1;end
       else begin hot0_data<=M_AXI_RDATA;hot0_tag<=fill_address[31:5];hot0_valid<=1;end
      end
     end
     if(M_AXI_RRESP||M_AXI_RLAST!=(beats_left==1)||beats_left==0)begin error<=1;read_bad<=1;end
     if(beats_left==1)begin
      state<=(error||read_bad||M_AXI_RRESP||!M_AXI_RLAST)?FAULT:GET;
     end else begin
      if(beats_left!=0)beats_left<=beats_left-1;
      fill_address<=fill_address+32;
     end
    end
    GOT0:begin
     if(opcode==BINARY8)begin left_byte<=fetched_byte;request_address<=d[2]+item_index;request_operand<=1;return_state<=GOT1;state<=GET;end
     else if(opcode==COPY8||opcode==PACK16||opcode==NEAREST2)begin emit_value<={24'd0,fetched_byte};state<=EMIT;end
     else begin lut_index<={8'd0,fetched_byte};state<=LUT_REQ;end
    end
    GOT1:begin lut_index<={left_byte,fetched_byte};state<=LUT_REQ;end
    LUT_REQ:state<=LUT_WAIT;
    LUT_WAIT:begin
     if(opcode==UNARY32)emit_value<=b_read_data[lut_index[2:0]*32+:32];
     else emit_value<={24'd0,b_read_data[lut_index[4:0]*8+:8]};
     state<=EMIT;
    end
    POOL_SCAN:begin
     pool_x_reg<=pool_sx;pool_y_reg<=pool_sy;state<=POOL_COORD;
    end
    POOL_COORD:begin
     if(!pool_inside)state<=POOL_NEXT;
     else begin pool_row_product<=pool_y_reg[31:0]*d[6];pool_channel_product<=c*d[9];state<=POOL_ADDR1;end
    end
    POOL_ADDR1:begin pool_linear<=pool_row_product+pool_x_reg[31:0];pool_base<=d[1]+pool_channel_product;state<=POOL_ADDR2;end
    POOL_ADDR2:begin
     request_address<=pool_base+pool_linear;request_operand<=0;return_state<=POOL_GOT;state<=GET;
    end
    POOL_GOT:begin if(fetched_byte>pool_max)pool_max<=fetched_byte;state<=POOL_NEXT;end
    POOL_NEXT:begin
     if(tap_x==4&&tap_y==4)begin emit_value<={24'd0,pool_max};state<=EMIT;end
     else begin
      if(tap_x==4)begin tap_x<=0;tap_y<=tap_y+1;end else tap_x<=tap_x+1;
      state<=POOL_SCAN;
     end
    end
    EMIT:if(writer_fire)begin
     if(opcode==UNARY32&&emit_byte_index!=3)emit_byte_index<=emit_byte_index+1;
     else begin
      item_index<=item_index+1;
      if(opcode==PACK16)begin
       if(c==d[8]-1)begin c<=0;if(x==d[6]-1)begin x<=0;y<=y+1;end else x<=x+1;end else c<=c+1;
      end else if(opcode==NEAREST2||opcode==POOL5||opcode==RGB_UNARY)begin
       if(x==output_w-1)begin x<=0;if(y==output_h-1)begin y<=0;c<=c+1;end else y<=y+1;end else x<=x+1;
      end
      state<=item_index==d[4]-1?WORK_DONE:PREP;
     end
    end
    QVALID_REQ:state<=QVALID_WAIT;
    QVALID_WAIT:begin qvalid_bits<=b_read_data;state<=QBEGIN;qcfg_index<=0;end
    QBEGIN:if(q_begin_ready)state<=QTABLE_REQ;
    QTABLE_REQ:state<=QTABLE_WAIT;
    QTABLE_WAIT:begin qtable_word<=b_read_data;state<=QCFG_SEND;end
    QCFG_SEND:if(q_cfg_ready)begin
     if(qcfg_index==254)state<=QSTART;
     else begin qcfg_index<=qcfg_index+1;if(qcfg_index[2:0]==7)state<=QTABLE_REQ;end
    end
    QSTART:if(q_configured)state<=QSTREAM;
    QSTREAM:begin
     if(q_input_index==d[4])state<=QDRAIN;
     else if(!q_hot)begin request_address<=q_source_pointer;request_operand<=0;return_state<=QSTREAM;state<=GET;end
     else if(q_input_fire)begin q_input_index<=q_input_index+1;q_source_pointer<=q_source_pointer+4;
      if(q_input_index==d[4]-1)state<=QDRAIN;
     end
    end
    QDRAIN:if(q_output_index==d[4])state<=WORK_DONE;
    WORK_DONE:if(!pending&&output_strobe==0&&!error)begin state<=IDLE;busy<=0;done<=1;end
    FAULT:if(!pending)begin state<=IDLE;busy<=0;done<=1;error<=1;output_strobe<=0;output_buffer<=0;end
    default:begin error<=1;state<=FAULT;end
   endcase
   // A write fault may coincide with a source burst. Keep AR/R protocol alive
   // until its last R beat before entering FAULT and releasing ownership.
   if((error||(opcode==QUANT32&&q_cfg_error))&&state!=IDLE&&state!=READ_ADDR&&state!=READ_DATA&&state!=FAULT)begin
    error<=1;state<=FAULT;
   end
  end
 end
endmodule
