// One accumulator/cycle exact Q8 threshold search after table configuration.
// Eight independently read table copies trade ~4 RAMB36 equivalents for throughput.
// Global pipeline stall preserves every in-flight accumulator and output under
// arbitrary downstream backpressure. Tables may only change when pipeline empty.
module yolo_threshold_quantizer_pipe (
    input wire clk, input wire rst_n,
    input wire cfg_begin, output wire cfg_begin_ready,
    input wire cfg_valid, output wire cfg_ready,
    input wire [31:0] cfg_threshold, input wire cfg_reachable,
    output reg configured, output reg cfg_error,
    input wire [31:0] acc_data, input wire acc_valid, output wire acc_ready,
    output wire [7:0] q_data, output wire q_valid, input wire q_ready
);
    reg loading;
    reg [7:0] load_index;
    reg [31:0] previous_threshold;
    reg previous_reachable;
    wire [15:0] occupied;
    wire empty = !(|occupied);
    wire advance = q_ready || !q_valid;
    assign cfg_begin_ready = !loading && empty;
    assign cfg_ready = loading;
    assign acc_ready = configured && !loading && advance && !cfg_begin;
    wire bad_order = (load_index != 0) &&
        ((!previous_reachable && cfg_reachable) ||
         (previous_reachable && cfg_reachable &&
          ($signed(cfg_threshold) < $signed(previous_threshold))));
    always @(posedge clk) begin
        if (!rst_n) begin
            loading <= 0;
            configured <= 0;
            cfg_error <= 0;
            load_index <= 0;
            previous_threshold <= 0;
            previous_reachable <= 0;
        end else if (cfg_begin && cfg_begin_ready) begin
            loading <= 1;
            configured <= 0;
            cfg_error <= 0;
            load_index <= 0;
        end else if (loading && cfg_valid) begin
            if (bad_order) begin
                loading <= 0;
                configured <= 0;
                cfg_error <= 1;
            end else begin
                previous_threshold <= cfg_threshold;
                previous_reachable <= cfg_reachable;
                if (load_index == 254) begin
                    loading <= 0;
                    configured <= 1;
                end else load_index <= load_index + 1'b1;
            end
        end
    end
    genvar g;
    generate for (g=0;g<8;g=g+1) begin: stages
        (* ram_style="block" *) reg [32:0] threshold_mem [0:254];
        reg [32:0] read_threshold;
        reg [31:0] read_acc, cmp_acc;
        reg [7:0] read_low, read_high, read_mid, cmp_low, cmp_high;
        reg read_valid, cmp_valid;
        wire [31:0] source_acc;
        wire [7:0] source_low, source_high;
        wire source_valid;
        if (g==0) begin: first
            assign source_acc = acc_data;
            assign source_low = 0;
            assign source_high = 255;
            assign source_valid = acc_valid && acc_ready;
        end else begin: later
            assign source_acc = stages[g-1].cmp_acc;
            assign source_low = stages[g-1].cmp_low;
            assign source_high = stages[g-1].cmp_high;
            assign source_valid = stages[g-1].cmp_valid;
        end
        wire [8:0] source_sum = {1'b0,source_low}+{1'b0,source_high};
        wire [7:0] source_mid = source_sum[8:1];
        wire reached = read_threshold[32] &&
            ($signed(read_acc) >= $signed(read_threshold[31:0]));
        assign occupied[2*g] = read_valid;
        assign occupied[2*g+1] = cmp_valid;
        // A separate memory process allows straightforward synchronous BRAM
        // inference. Data is immaterial when the corresponding valid is zero.
        always @(posedge clk) begin
            if (loading && cfg_valid)
                threshold_mem[load_index] <= {cfg_reachable,cfg_threshold};
            if (!loading && advance)
                read_threshold <= threshold_mem[source_mid];
        end
        always @(posedge clk) begin
            if (!rst_n) begin
                read_valid <= 0;
                cmp_valid <= 0;
                read_acc <= 0;
                read_low <= 0;
                read_high <= 0;
                read_mid <= 0;
                cmp_acc <= 0;
                cmp_low <= 0;
                cmp_high <= 0;
            end else if (loading) begin
                read_valid <= 0;
                cmp_valid <= 0;
            end else if (advance) begin
                read_valid <= source_valid;
                read_acc <= source_acc;
                read_low <= source_low;
                read_high <= source_high;
                read_mid <= source_mid;
                cmp_valid <= read_valid;
                cmp_acc <= read_acc;
                cmp_low <= reached ? read_mid+8'd1 : read_low;
                cmp_high <= reached ? read_high : read_mid;
            end
        end
    end endgenerate
    assign q_data = stages[7].cmp_low;
    assign q_valid = stages[7].cmp_valid;
endmodule
