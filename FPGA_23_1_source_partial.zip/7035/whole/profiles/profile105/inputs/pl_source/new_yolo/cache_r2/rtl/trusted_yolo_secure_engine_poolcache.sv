`timescale 1ns/1ps
// Complete existing arithmetic engine AXI security composition. One external
// shared SLH/private-cache service, one external shared SM4 service, no CPU
// descriptors/verdicts. Runtime tensors use typed MAC; QCONST object295 and
// program314 are consumed from the SAME verified private page cache.
module trusted_yolo_secure_engine_poolcache #(
 parameter integer COMMAND_COUNT=58814,
 parameter [11:0] BANK_BASE=12'd2420,parameter integer A_WORDS=2548,
 parameter POLICY_ROM="model_object_policy_v2.mem",parameter ROLE_ROM="role_policy_201.hex"
)(
input wire  job_valid,
output wire  job_ready,
input wire [31:0] job_session,
input wire [31:0] job_frame,
input wire [31:0] job_epoch,
input wire [31:0] job_rgb_base,
input wire  authorized,
input wire [31:0] authorization_epoch,
input wire  job_cancel,
output wire  job_quiescent,
output wire  active,
output wire  job_done,
output wire  job_failed,
output wire [7:0] failure_code,
output wire [31:0] result_session,
output wire [31:0] result_frame,
output wire [31:0] result_epoch,
output wire [31:0] current_index,
output wire [15:0] read_transactions,
output wire [15:0] write_transactions,
input wire  clk,
input wire  rst_n,
output wire  a_write,
output wire  b_write,
output wire [11:0] bank_write_address,
output wire [255:0] bank_write_data,
output wire  a_read,
output wire  b_read,
output wire [11:0] a_read_address,
output wire [11:0] b_read_address,
input wire [255:0] a_read_data,
input wire [255:0] b_read_data,
output wire [31:0] M_AXI_ARADDR,
output wire [7:0] M_AXI_ARLEN,
output wire [2:0] M_AXI_ARSIZE,
output wire [1:0] M_AXI_ARBURST,
output wire  M_AXI_ARVALID,
input wire  M_AXI_ARREADY,
input wire [255:0] M_AXI_RDATA,
input wire [1:0] M_AXI_RRESP,
input wire  M_AXI_RLAST,
input wire  M_AXI_RVALID,
output wire  M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,
output wire [7:0] M_AXI_AWLEN,
output wire [2:0] M_AXI_AWSIZE,
output wire [1:0] M_AXI_AWBURST,
output wire  M_AXI_AWVALID,
input wire  M_AXI_AWREADY,
output wire [255:0] M_AXI_WDATA,
output wire [31:0] M_AXI_WSTRB,
output wire  M_AXI_WLAST,
output wire  M_AXI_WVALID,
input wire  M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,
input wire  M_AXI_BVALID,
output wire  M_AXI_BREADY,
output wire  exclusive_page_lock,
output wire  fetch_valid,
input wire  fetch_ready,
output wire [31:0] fetch_page_index,
output wire [31:0] fetch_page_address,
output wire [31:0] fetch_proof_address,
output wire  service_page_request,
input wire  service_page_ready,
output wire [31:0] service_expected_page,
input wire  service_page_done,
input wire  service_busy,
input wire  service_fault,
input wire  service_cache_valid,
input wire [31:0] service_cached_page,
output wire  service_cache_read,
output wire [9:0] service_cache_address,
input wire  service_cache_read_valid,
input wire [31:0] service_cache_read_data,
input wire key_valid,
output wire mac_request,
input wire mac_ready,
output wire [127:0] mac_chain,
output wire [255:0] mac_data,
input wire mac_response_valid,mac_response_error,
input wire [127:0] mac_tag,
input wire mac_quiescent
);
wire program_lock,weight_lock;reg mutex_fault;
wire inner_ready,inner_quiet,inner_done,inner_failed;
wire axi_quiet,static_quiet,lease_quiet,guard_quiet,raw_quiet;
wire all_quiet=inner_quiet&&axi_quiet&&static_quiet&&lease_quiet&&guard_quiet&&raw_quiet;
reg lifecycle_revoked;
wire terminal_live=authorized&&key_valid&&!job_cancel&&authorization_epoch==result_epoch;
reg job_inflight,pending_terminal,pending_failure;reg done_pulse,fail_pulse;
assign job_ready=inner_ready&&all_quiet&&!pending_terminal&&!job_inflight&&!mutex_fault&&key_valid;
assign job_quiescent=all_quiet&&!pending_terminal&&!job_inflight;
assign job_done=done_pulse;assign job_failed=fail_pulse;
always @(posedge clk)begin
 if(!rst_n)begin lifecycle_revoked<=0;mutex_fault<=0;job_inflight<=0;pending_terminal<=0;pending_failure<=0;done_pulse<=0;fail_pulse<=0;end
 else begin
  done_pulse<=0;fail_pulse<=0;
  if(job_valid&&job_ready)begin job_inflight<=1;lifecycle_revoked<=0;end
  else if(job_inflight&&!terminal_live)lifecycle_revoked<=1;
  if(program_lock&&weight_lock)mutex_fault<=1;
  if(inner_done||inner_failed)begin pending_terminal<=1;pending_failure<=inner_failed;end
  if(pending_terminal&&all_quiet)begin pending_terminal<=0;job_inflight<=0;done_pulse<=!pending_failure&&!mutex_fault&&terminal_live&&!lifecycle_revoked;fail_pulse<=pending_failure||mutex_fault||!terminal_live||lifecycle_revoked;end
 end
end
wire p_fetch_valid,w_fetch_valid,p_page_request,w_page_request,p_cache_read,w_cache_read;
wire [31:0] p_fetch_page_index,p_fetch_page_address,p_fetch_proof_address,p_expected_page;
wire [31:0] w_fetch_page_index,w_fetch_page_address,w_fetch_proof_address,w_expected_page;
wire [9:0] p_cache_address,w_cache_address;
assign exclusive_page_lock=program_lock||weight_lock;
assign fetch_valid=program_lock?p_fetch_valid:weight_lock?w_fetch_valid:1'b0;
assign fetch_page_index=program_lock?p_fetch_page_index:w_fetch_page_index;
assign fetch_page_address=program_lock?p_fetch_page_address:w_fetch_page_address;
assign fetch_proof_address=program_lock?p_fetch_proof_address:w_fetch_proof_address;
assign service_page_request=program_lock?p_page_request:weight_lock?w_page_request:1'b0;
assign service_expected_page=program_lock?p_expected_page:w_expected_page;
assign service_cache_read=program_lock?p_cache_read:weight_lock?w_cache_read:1'b0;
assign service_cache_address=program_lock?p_cache_address:w_cache_address;
wire [31:0] E_M_AXI_ARADDR;
wire [7:0] E_M_AXI_ARLEN;
wire [2:0] E_M_AXI_ARSIZE;
wire [1:0] E_M_AXI_ARBURST;
wire  E_M_AXI_ARVALID;
wire  E_M_AXI_ARREADY;
wire [255:0] E_M_AXI_RDATA;
wire [1:0] E_M_AXI_RRESP;
wire  E_M_AXI_RLAST;
wire  E_M_AXI_RVALID;
wire  E_M_AXI_RREADY;
wire [31:0] E_M_AXI_AWADDR;
wire [7:0] E_M_AXI_AWLEN;
wire [2:0] E_M_AXI_AWSIZE;
wire [1:0] E_M_AXI_AWBURST;
wire  E_M_AXI_AWVALID;
wire  E_M_AXI_AWREADY;
wire [255:0] E_M_AXI_WDATA;
wire [31:0] E_M_AXI_WSTRB;
wire  E_M_AXI_WLAST;
wire  E_M_AXI_WVALID;
wire  E_M_AXI_WREADY;
wire [1:0] E_M_AXI_BRESP;
wire  E_M_AXI_BVALID;
wire  E_M_AXI_BREADY;
wire  policy_query_valid;
wire  policy_query_ready;
wire  policy_query_write;
wire [31:0] policy_query_address;
wire [31:0] policy_query_strobe;
wire  policy_response_valid;
wire  policy_response_ready;
wire  policy_allowed;
wire  policy_static;
wire [15:0] policy_role;
wire [15:0] policy_shape;
wire [31:0] policy_mask;
wire [31:0] policy_static_object;
wire [31:0] policy_static_offset;
wire [31:0] policy_response_address;
wire  policy_context_live;
trusted_yolo_authenticated_policy_engine_poolcache #(.COMMAND_COUNT(COMMAND_COUNT),.BANK_BASE(BANK_BASE),.A_WORDS(A_WORDS),.POLICY_ROM(POLICY_ROM),.ROLE_ROM(ROLE_ROM)) engine(
.job_valid(job_valid&&all_quiet&&!pending_terminal&&!job_inflight&&!mutex_fault),
.job_ready(inner_ready),
.job_session(job_session),
.job_frame(job_frame),
.job_epoch(job_epoch),
.job_rgb_base(job_rgb_base),
.authorized(authorized&&key_valid&&!mutex_fault),
.authorization_epoch(authorization_epoch),
.job_cancel(job_cancel),
.job_quiescent(inner_quiet),
.active(active),
.job_done(inner_done),
.job_failed(inner_failed),
.failure_code(failure_code),
.result_session(result_session),
.result_frame(result_frame),
.result_epoch(result_epoch),
.current_index(current_index),
.read_transactions(read_transactions),
.write_transactions(write_transactions),
.clk(clk),
.rst_n(rst_n),
.a_write(a_write),
.b_write(b_write),
.bank_write_address(bank_write_address),
.bank_write_data(bank_write_data),
.a_read(a_read),
.b_read(b_read),
.a_read_address(a_read_address),
.b_read_address(b_read_address),
.a_read_data(a_read_data),
.b_read_data(b_read_data),
.M_AXI_ARADDR(E_M_AXI_ARADDR),
.M_AXI_ARLEN(E_M_AXI_ARLEN),
.M_AXI_ARSIZE(E_M_AXI_ARSIZE),
.M_AXI_ARBURST(E_M_AXI_ARBURST),
.M_AXI_ARVALID(E_M_AXI_ARVALID),
.M_AXI_ARREADY(E_M_AXI_ARREADY),
.M_AXI_RDATA(E_M_AXI_RDATA),
.M_AXI_RRESP(E_M_AXI_RRESP),
.M_AXI_RLAST(E_M_AXI_RLAST),
.M_AXI_RVALID(E_M_AXI_RVALID),
.M_AXI_RREADY(E_M_AXI_RREADY),
.M_AXI_AWADDR(E_M_AXI_AWADDR),
.M_AXI_AWLEN(E_M_AXI_AWLEN),
.M_AXI_AWSIZE(E_M_AXI_AWSIZE),
.M_AXI_AWBURST(E_M_AXI_AWBURST),
.M_AXI_AWVALID(E_M_AXI_AWVALID),
.M_AXI_AWREADY(E_M_AXI_AWREADY),
.M_AXI_WDATA(E_M_AXI_WDATA),
.M_AXI_WSTRB(E_M_AXI_WSTRB),
.M_AXI_WLAST(E_M_AXI_WLAST),
.M_AXI_WVALID(E_M_AXI_WVALID),
.M_AXI_WREADY(E_M_AXI_WREADY),
.M_AXI_BRESP(E_M_AXI_BRESP),
.M_AXI_BVALID(E_M_AXI_BVALID),
.M_AXI_BREADY(E_M_AXI_BREADY),
.exclusive_page_lock(program_lock),
.fetch_valid(p_fetch_valid),
.fetch_ready(fetch_ready&&!weight_lock),
.fetch_page_index(p_fetch_page_index),
.fetch_page_address(p_fetch_page_address),
.fetch_proof_address(p_fetch_proof_address),
.service_page_request(p_page_request),
.service_page_ready(service_page_ready&&!weight_lock),
.service_expected_page(p_expected_page),
.service_page_done(service_page_done),
.service_busy(service_busy||weight_lock),
.service_fault(service_fault),
.service_cache_valid(service_cache_valid),
.service_cached_page(service_cached_page),
.service_cache_read(p_cache_read),
.service_cache_address(p_cache_address),
.service_cache_read_valid(service_cache_read_valid),
.service_cache_read_data(service_cache_read_data),
.policy_query_valid(policy_query_valid),
.policy_query_ready(policy_query_ready),
.policy_query_write(policy_query_write),
.policy_query_address(policy_query_address),
.policy_query_strobe(policy_query_strobe),
.policy_response_valid(policy_response_valid),
.policy_response_ready(policy_response_ready),
.policy_allowed(policy_allowed),
.policy_static(policy_static),
.policy_role(policy_role),
.policy_shape(policy_shape),
.policy_mask(policy_mask),
.policy_static_object(policy_static_object),
.policy_static_offset(policy_static_offset),
.policy_response_address(policy_response_address),
.policy_context_live(policy_context_live)
);

wire static_request,static_ready,static_response_valid,static_verified;
wire [31:0] static_object,static_offset,static_epoch,static_response_offset,static_response_epoch;
wire [255:0] static_data;
wire guard_request,guard_ready,guard_write,guard_response_valid,guard_verified,guard_error,guard_live;
wire [31:0] guard_address,guard_mask,guard_strobe,guard_session,guard_frame,guard_epoch;
wire [15:0] guard_role,guard_shape;wire [255:0] guard_data,guard_response_data;
wire transaction_fault;
trusted_yolo_axi_guard bus_guard(
 .clk(clk),.rst_n(rst_n),.job_session(result_session),.job_frame(result_frame),.job_epoch(result_epoch),
 .context_live(policy_context_live),.external_quiescent(static_quiet&&guard_quiet&&raw_quiet),.quiescent(axi_quiet),.transaction_fault(transaction_fault),
.S_AXI_ARADDR(E_M_AXI_ARADDR),
.S_AXI_ARLEN(E_M_AXI_ARLEN),
.S_AXI_ARSIZE(E_M_AXI_ARSIZE),
.S_AXI_ARBURST(E_M_AXI_ARBURST),
.S_AXI_ARVALID(E_M_AXI_ARVALID),
.S_AXI_ARREADY(E_M_AXI_ARREADY),
.S_AXI_RDATA(E_M_AXI_RDATA),
.S_AXI_RRESP(E_M_AXI_RRESP),
.S_AXI_RLAST(E_M_AXI_RLAST),
.S_AXI_RVALID(E_M_AXI_RVALID),
.S_AXI_RREADY(E_M_AXI_RREADY),
.S_AXI_AWADDR(E_M_AXI_AWADDR),
.S_AXI_AWLEN(E_M_AXI_AWLEN),
.S_AXI_AWSIZE(E_M_AXI_AWSIZE),
.S_AXI_AWBURST(E_M_AXI_AWBURST),
.S_AXI_AWVALID(E_M_AXI_AWVALID),
.S_AXI_AWREADY(E_M_AXI_AWREADY),
.S_AXI_WDATA(E_M_AXI_WDATA),
.S_AXI_WSTRB(E_M_AXI_WSTRB),
.S_AXI_WLAST(E_M_AXI_WLAST),
.S_AXI_WVALID(E_M_AXI_WVALID),
.S_AXI_WREADY(E_M_AXI_WREADY),
.S_AXI_BRESP(E_M_AXI_BRESP),
.S_AXI_BVALID(E_M_AXI_BVALID),
.S_AXI_BREADY(E_M_AXI_BREADY),
.policy_query_valid(policy_query_valid),
.policy_query_ready(policy_query_ready),
.policy_query_write(policy_query_write),
.policy_query_address(policy_query_address),
.policy_query_strobe(policy_query_strobe),
.policy_response_valid(policy_response_valid),
.policy_response_ready(policy_response_ready),
.policy_allowed(policy_allowed),
.policy_static(policy_static),
.policy_role(policy_role),
.policy_shape(policy_shape),
.policy_mask(policy_mask),
.policy_static_object(policy_static_object),
.policy_static_offset(policy_static_offset),
.policy_response_address(policy_response_address),

 .static_request(static_request),.static_ready(static_ready),.static_object(static_object),.static_offset(static_offset),.static_epoch(static_epoch),
 .static_response_valid(static_response_valid),.static_verified(static_verified),.static_data(static_data),.static_response_offset(static_response_offset),.static_response_epoch(static_response_epoch),
 .guard_request(guard_request),.guard_ready(guard_ready),.guard_write(guard_write),.guard_address(guard_address),.guard_mask(guard_mask),.guard_strobe(guard_strobe),
 .guard_session(guard_session),.guard_frame(guard_frame),.guard_epoch(guard_epoch),.guard_role(guard_role),.guard_shape(guard_shape),.guard_data(guard_data),
 .guard_response_valid(guard_response_valid),.guard_verified(guard_verified),.guard_response_data(guard_response_data));
wire lease_request,lease_ready,lease_response_valid,lease_verified,lease_still_valid,word_request,word_ready,word_response_valid,lease_release,release_ready;
wire [31:0] lease_object,lease_page,lease_epoch,lease_response_object,lease_response_page,lease_response_epoch;
wire [6:0] word_offset,word_response_offset;wire [255:0] word_response_data;
trusted_static_word_reader #(.OBJECT_ID(295),.OBJECT_BYTES(7334048)) constants(
 .clk(clk),.rst_n(rst_n),.cancel(job_cancel),.authorized(authorized&&key_valid&&!mutex_fault),.authorization_epoch(authorization_epoch),
 .request_valid(static_request),.request_ready(static_ready),.request_offset(static_offset),.request_epoch(static_epoch),
 .response_valid(static_response_valid),.response_verified(static_verified),.response_offset(static_response_offset),.response_epoch(static_response_epoch),.response_data(static_data),
 .lease_request(lease_request),.lease_ready(lease_ready),.lease_object(lease_object),.lease_page(lease_page),.lease_epoch(lease_epoch),
 .lease_response_valid(lease_response_valid),.lease_verified(lease_verified),.lease_response_object(lease_response_object),.lease_response_page(lease_response_page),.lease_response_epoch(lease_response_epoch),.lease_still_valid(lease_still_valid),
 .word_request(word_request),.word_ready(word_ready),.word_offset(word_offset),.word_response_valid(word_response_valid),.word_response_offset(word_response_offset),.word_response_data(word_response_data),
 .lease_release(lease_release),.release_ready(release_ready),.cache_quiescent(lease_quiet),.quiescent(static_quiet));
trusted_yolo_page_lease_lutram #(.OBJECT_ID(295),.OBJECT_KIND(5),.OBJECT_BYTES(7334048),.POLICY_ROM(POLICY_ROM)) constant_page(
 .clk(clk),.rst_n(rst_n),.cancel(job_cancel),.model_authorized(authorized&&!mutex_fault),.session_epoch(authorization_epoch),
 .cache_quiescent(lease_quiet),.exclusive_page_lock(weight_lock),
 .fetch_valid(w_fetch_valid),.fetch_ready(fetch_ready&&!program_lock),.fetch_page_index(w_fetch_page_index),.fetch_page_address(w_fetch_page_address),.fetch_proof_address(w_fetch_proof_address),
 .service_page_request(w_page_request),.service_page_ready(service_page_ready&&!program_lock),.service_expected_page(w_expected_page),
 .service_page_done(service_page_done),.service_busy(service_busy||program_lock),.service_fault(service_fault),.service_cache_valid(service_cache_valid),.service_cached_page(service_cached_page),
 .service_cache_read(w_cache_read),.service_cache_address(w_cache_address),.service_cache_read_valid(service_cache_read_valid),.service_cache_read_data(service_cache_read_data),.*);
wire memory_read_valid,memory_read_ready,memory_write_valid,memory_write_ready;
wire [31:0] memory_data_address,memory_tag_address,memory_write_mask,memory_response_mask;
wire [255:0] memory_write_data,memory_response_data;wire [127:0] memory_write_tag,memory_response_tag;
wire memory_response_valid,memory_response_error;
assign guard_verified=!guard_error&&guard_live;
trusted_yolo_tensor_beat_guard tensor_guard(
 .clk(clk),.rst_n(rst_n),.cancel(job_cancel),.authorized(authorized&&key_valid&&!mutex_fault),.key_valid(key_valid),.authorization_epoch(authorization_epoch),
 .request_valid(guard_request),.request_ready(guard_ready),.request_write(guard_write),.request_session(guard_session),.request_frame(guard_frame),.request_epoch(guard_epoch),.request_version(32'd2),
 .request_role(guard_role),.request_shape(guard_shape),.request_address(guard_address),.request_tensor_mask(guard_mask),.request_strobe(guard_strobe),.request_data(guard_data),
 .response_valid(guard_response_valid),.response_ready(1'b1),.response_error(guard_error),.context_live(guard_live),.response_data(guard_response_data),.quiescent(guard_quiet),
 .memory_read_valid(memory_read_valid),.memory_read_ready(memory_read_ready),.memory_write_valid(memory_write_valid),.memory_write_ready(memory_write_ready),
 .memory_data_address(memory_data_address),.memory_tag_address(memory_tag_address),.memory_write_data(memory_write_data),.memory_write_tag(memory_write_tag),.memory_write_mask(memory_write_mask),
 .memory_response_valid(memory_response_valid),.memory_response_error(memory_response_error),.memory_response_data(memory_response_data),.memory_response_tag(memory_response_tag),.memory_response_mask(memory_response_mask),
 .backend_quiescent(raw_quiet),.mac_request(mac_request),.mac_ready(mac_ready),.mac_chain(mac_chain),.mac_data(mac_data),.mac_response_valid(mac_response_valid),.mac_response_error(mac_response_error),.mac_tag(mac_tag),.mac_quiescent(mac_quiescent));
trusted_tensor_axi_backend physical_memory(
 .clk(clk),.rst_n(rst_n),.read_valid(memory_read_valid),.read_ready(memory_read_ready),.write_valid(memory_write_valid),.write_ready(memory_write_ready),
 .data_address(memory_data_address),.tag_address(memory_tag_address),.write_data(memory_write_data),.write_tag(memory_write_tag),.write_mask(memory_write_mask),
 .response_valid(memory_response_valid),.response_error(memory_response_error),.response_data(memory_response_data),.response_tag(memory_response_tag),.response_mask(memory_response_mask),.quiescent(raw_quiet),.*);
endmodule
