`timescale 1ns/1ps
// Streaming exact INT32 dot product: bias + sum((UINT8 activation-zp)*INT8 weight).
// Lane zero occupies bits [7:0]. MACs wrap modulo 2^32, matching INT32 arithmetic.
// External tensor/weight memories are intentionally outside this core.
module yolo_dot16_u8s8(
 input wire clk,input wire rst_n,
 input wire start_valid,output wire start_ready,input wire signed [31:0] bias,
 input wire [7:0] activation_zero_point,
 input wire vector_valid,output wire vector_ready,
 input wire [127:0] activations,input wire [127:0] weights,input wire vector_last,
 output reg result_valid,input wire result_ready,output reg signed [31:0] result
);
 reg busy,last_seen;
 reg [7:0] zero_point;
 reg signed [31:0] accumulator;
 reg product_valid,product_last;
 (* use_dsp="yes" *) reg signed [17:0] product[0:15];
 wire signed [31:0] pair_sum[0:7],quad_sum[0:3],oct_sum[0:1];
 wire signed [31:0] vector_sum=oct_sum[0]+oct_sum[1];
 assign start_ready=!busy&&!result_valid;
 assign vector_ready=busy&&!last_seen;
 wire take_start=start_valid&&start_ready;
 wire take_vector=vector_valid&&vector_ready;
 genvar l;
 generate for(l=0;l<16;l=l+1)begin: lane
  wire signed [8:0] centered=$signed({1'b0,activations[l*8+:8]})-$signed({1'b0,zero_point});
  wire signed [7:0] weight=$signed(weights[l*8+:8]);
  always @(posedge clk)if(take_vector)product[l]<=centered*weight;
 end
 for(l=0;l<8;l=l+1)begin: add_pair
  assign pair_sum[l]={{14{product[l*2][17]}},product[l*2]}+{{14{product[l*2+1][17]}},product[l*2+1]};
 end
 for(l=0;l<4;l=l+1)begin: add_quad
  assign quad_sum[l]=pair_sum[l*2]+pair_sum[l*2+1];
 end
 for(l=0;l<2;l=l+1)begin: add_oct
  assign oct_sum[l]=quad_sum[l*2]+quad_sum[l*2+1];
 end endgenerate
 always @(posedge clk)begin
  if(!rst_n)begin
   busy<=0;last_seen<=0;zero_point<=0;accumulator<=0;
   product_valid<=0;product_last<=0;result_valid<=0;result<=0;
  end else begin
   product_valid<=take_vector;
   if(result_valid&&result_ready)result_valid<=0;
   if(take_start)begin busy<=1;last_seen<=0;zero_point<=activation_zero_point;accumulator<=bias;end
   if(take_vector)begin product_last<=vector_last;if(vector_last)last_seen<=1;end
   if(product_valid)begin
    accumulator<=accumulator+vector_sum;
    if(product_last)begin result<=accumulator+vector_sum;result_valid<=1;busy<=0;end
   end
  end
 end
endmodule
