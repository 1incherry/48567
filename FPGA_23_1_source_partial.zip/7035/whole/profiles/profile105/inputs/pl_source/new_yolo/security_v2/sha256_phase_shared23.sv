`timescale 1ns/1ps
// Phase-exclusive block compressor. Client 0 retains two-round latency;
// client 1 retains three-round latency. This is an intermediate building block,
// not a complete authorization/Merkle frontend or a proven PPA improvement.
module sha256_phase_shared23(
 input wire clk,rst_n,phase_model,
 input wire signature_rst_n,signature_start,
 input wire [511:0] signature_block,input wire [255:0] signature_iv,
 output wire signature_busy,signature_done,output wire [255:0] signature_state,
 input wire model_rst_n,model_start,
 input wire [511:0] model_block,input wire [255:0] model_iv,
 output wire model_busy,model_done,output wire [255:0] model_state,
 output reg ownership_fault
);
 reg owner;
 wire comp_busy,comp_done;wire [255:0] comp_state;
 wire s_request=signature_rst_n && signature_start;
 wire m_request=model_rst_n && model_start;
 // This interface intentionally has no request queue. Conflicting phases
 // invalidate the transaction; higher-level control must keep phases exclusive.
 wire conflict=(s_request && m_request) ||
               (s_request && phase_model) || (m_request && !phase_model) ||
               (comp_busy && phase_model!=owner) ||
               (comp_busy && (owner?m_request:s_request));
 wire request=rst_n && !ownership_fault && !comp_busy && !conflict &&
              (s_request || m_request);
 wire selected_model=phase_model;
 // Phase is trusted enclosing control, stable before a start and throughout
 // the block. No busy/done feedback into asynchronous reset: a cancelled
 // client holds reset low until enclosing control changes/restores its phase.
 wire compressor_rst_n=rst_n && !ownership_fault &&
                       (phase_model?model_rst_n:signature_rst_n);
 sha256_compress3_csa compressor(
  .clk(clk),.rst_n(compressor_rst_n),.start(request),
  .block(selected_model?model_block:signature_block),
  .iv(selected_model?model_iv:signature_iv),
  .busy(comp_busy),.done(comp_done),.state_out(comp_state));
 always @(posedge clk or negedge rst_n)begin
  if(!rst_n)begin owner<=0;ownership_fault<=0;end
  else begin
   if(conflict)ownership_fault<=1;
   if(request)owner<=selected_model;
  end
 end
 assign signature_busy=comp_busy && !owner && signature_rst_n && !ownership_fault;
 assign signature_done=comp_done && !owner && signature_rst_n && !ownership_fault;
 assign model_busy=comp_busy && owner && model_rst_n && !ownership_fault;
 assign model_done=comp_done && owner && model_rst_n && !ownership_fault;
 assign signature_state=signature_done?comp_state:256'd0;
 assign model_state=model_done?comp_state:256'd0;
endmodule
