`timescale 1ns/1ps
// R82 unverified candidate. Preserve 1964 scalar words, aligned node order,
// single-port capture/read exclusion, and 65536 physical bits.
// Three earlier words are packed in registers; the fourth word commits
// the complete node at its original acceptance edge. Reads stay synchronous.
module slh_signature_node_sram128(
 input wire clk,write_enable,read_enable,
 input wire [10:0] write_address,read_address,
 input wire [31:0] write_data,output wire [127:0] read_node
);
 reg [95:0] prefix_words;
 reg read_bank;
 wire [127:0] nodes[0:1];
 wire read_admitted=read_enable && read_address[1:0]==0 && read_address<=1960;
 wire commit_node=write_enable && write_address<1964 && write_address[1:0]==3;
 always @(posedge clk)begin
  if(write_enable && write_address<1964)begin
   case(write_address[1:0])
    2'd0:prefix_words[95:64]<=write_data;
    2'd1:prefix_words[63:32]<=write_data;
    2'd2:prefix_words[31:0]<=write_data;
    default:begin end
   endcase
  end
  if(read_admitted)read_bank<=read_address[10];
 end
 for(genvar bank=0;bank<2;bank=bank+1)begin:physical_banks
  wire wen=commit_node && write_address[10]==bank;
  wire ren=read_admitted && read_address[10]==bank;
  wire [7:0] address=wen?write_address[9:2]:read_address[9:2];
  SRAM1RW256x128 memory(.CE(clk),.A(address),.WEB(!wen),.CSB(!(wen||ren)),.OEB(1'b0),.I({prefix_words,write_data}),.O(nodes[bank]));
 end
 assign read_node=read_bank?nodes[1]:nodes[0];
 // synopsys translate_off
 integer expected_next=0,committed_words=0,writes=0,node_reads=0;
 always @(posedge clk)begin
  if(write_enable && read_enable)$fatal(1,"SIGNATURE_NODE_SINGLE_PORT_OVERLAP");
  if(write_enable)begin
   if((^write_address)===1'bx || write_address>=1964)$fatal(1,"SIGNATURE_NODE_WRITE_BOUNDS");
   if(write_address==0)begin expected_next=0;committed_words=0;end
   if(write_address!=expected_next)$fatal(1,"SIGNATURE_NODE_ORDERED_CAPTURE");
   expected_next=expected_next+1;committed_words=expected_next;writes=writes+1;
  end
  if(read_enable)begin
   if((^read_address)===1'bx || read_address[1:0]!==2'b00 || read_address>1960 || read_address+3>=committed_words)
    $fatal(1,"SIGNATURE_NODE_READ_NOT_COMPLETE_ALIGNED_LOGICAL_NODE");
   node_reads=node_reads+1;
  end
 end
 final $display("SIGNATURE_NODE_SRAM_ACCESS words=1964 banks=2 physical_bits=65536 writes=%0d node_reads=%0d",writes,node_reads);
 // synopsys translate_on
endmodule
