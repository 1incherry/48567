# Common reset assertion is asynchronous; release is synchronized locally.
set_false_path -to [get_pins -hier -filter {NAME =~ *u_trusted_clock/reset100_pipe_reg*/CLR || NAME =~ *u_trusted_clock/reset50_pipe_reg*/CLR}]
