`timescale 1ns/1ps
module tb_independent_axil;
reg clk=0;always #4 clk=~clk;reg rst=1;
reg[31:0]awaddr=0,wdata=0,araddr=0;reg awvalid=0,wvalid=0,arvalid=0,bready=0,rready=0;reg[3:0]wstrb=0;
wire awready,wready,arready,bvalid,rvalid;wire[1:0]bresp,rresp;wire[31:0]rdata;
reg phy_ready=1,locked=1,underflow=0,tx_busy=0,tx_done=0,tx_error=0,mdio_busy=0,mdio_done=0,mdio_ack=0;
reg frozen=0;wire arm,freeze;wire[13:0]rx_index;
wire tx_start,tx_clear,phy_enable,mdio_start,mdio_read;wire[4:0]mdio_phy,mdio_reg;wire[15:0]mdio_wdata,count;
wire[31:0]seq,seed,gap;
wire [863:0] payload;
eth_tx_axil_regs dut(.payload(payload),.rx_frozen(frozen),.rx_frames(32'd256),.rx_bad(32'd2),.rx_overflow(32'd1),.rx_data(32'h44332211),.rx_arm(arm),.rx_freeze(freeze),.rx_index(rx_index),.clk(clk),.rst(rst),.s_awaddr(awaddr),.s_awvalid(awvalid),.s_awready(awready),
 .s_wdata(wdata),.s_wstrb(wstrb),.s_wvalid(wvalid),.s_wready(wready),.s_bresp(bresp),.s_bvalid(bvalid),.s_bready(bready),
 .s_araddr(araddr),.s_arvalid(arvalid),.s_arready(arready),.s_rdata(rdata),.s_rresp(rresp),.s_rvalid(rvalid),.s_rready(rready),
 .phy_ready(phy_ready),.clock_locked(locked),.mac_speed(2'd2),.tx_underflow(underflow),.tx_start(tx_start),.tx_clear(tx_clear),
 .frame_count(count),.seq_base(seq),.seed(seed),.gap_cycles(gap),.tx_busy(tx_busy),.tx_done(tx_done),.tx_error(tx_error),
 .sent_count(32'h1234),.last_seq(32'hff123456),.phy_enable(phy_enable),.mdio_start(mdio_start),.mdio_read(mdio_read),
 .mdio_phy(mdio_phy),.mdio_reg(mdio_reg),.mdio_wdata(mdio_wdata),.mdio_busy(mdio_busy),.mdio_done(mdio_done),
 .mdio_ack_error(mdio_ack),.mdio_rdata(16'h796d));
integer cycles=0,writes=0,reads=0,starts=0,clears=0,mdiostarts=0;reg os=0,oc=0,om=0;
always @(posedge clk)begin
 cycles=cycles+1;if(cycles>10000)$fatal(1,"AXIL watchdog");
 if(!rst)begin
  if((tx_start&&os)||(tx_clear&&oc)||(mdio_start&&om))$fatal(1,"control pulse not single cycle");
  if(tx_start)starts=starts+1;if(tx_clear)clears=clears+1;if(mdio_start)mdiostarts=mdiostarts+1;
  os=tx_start;oc=tx_clear;om=mdio_start;
 end
end
task send_aw(input[31:0]a,input integer delaycycles);begin
 repeat(delaycycles)@(negedge clk);@(negedge clk);awaddr=a;awvalid=1;
 @(posedge clk);while(!awready)@(posedge clk);@(negedge clk);awvalid=0;
end endtask
task send_w(input[31:0]v,input[3:0]st,input integer delaycycles);begin
 repeat(delaycycles)@(negedge clk);@(negedge clk);wdata=v;wstrb=st;wvalid=1;
 @(posedge clk);while(!wready)@(posedge clk);@(negedge clk);wvalid=0;
end endtask
task wr(input[31:0]a,input[31:0]v,input[3:0]st,input integer ad,input integer wd,input[1:0]resp);
 integer j;begin
 fork send_aw(a,ad);send_w(v,st,wd);join
 while(!bvalid)@(negedge clk);
 for(j=0;j<7;j=j+1)begin if(!bvalid||bresp!==resp||awready||wready)$fatal(1,"AXIL B unstable/wrong %08x resp%0d",a,bresp);@(negedge clk);end
 bready=1;@(negedge clk);bready=0;if(bvalid)$fatal(1,"AXIL B not consumed");writes=writes+1;
end endtask
task rd(input[31:0]a,input[31:0]v,input[1:0]resp);integer j;begin
 @(negedge clk);araddr=a;arvalid=1;@(posedge clk);while(!arready)@(posedge clk);
 @(negedge clk);arvalid=0;while(!rvalid)@(negedge clk);
 for(j=0;j<9;j=j+1)begin if(!rvalid||rresp!==resp||rdata!==v||arready)$fatal(1,"AXIL R mismatch %08x val%08x exp%08x resp%0d",a,rdata,v,rresp);@(negedge clk);end
 rready=1;@(negedge clk);rready=0;if(rvalid)$fatal(1,"AXIL R not consumed");reads=reads+1;
end endtask
initial begin
 repeat(5)@(negedge clk);rst=0;
 rd(0,32'h45545831,0);rd(8,32,0);rd(16,32'h70352026,0);rd(20,125000,0);
 wr(12,32'h12345678,15,0,5,0);rd(12,32'h12345678,0);
 wr(16,32'h89abcdef,15,5,0,0);rd(16,32'h89abcdef,0);
 wr(20,0,15,0,0,0);rd(20,0,0);
 wr(12,32'haabbccdd,5,0,3,0);rd(12,32'h12bb56dd,0);
 wr(8,256,15,3,0,0);rd(8,256,0);
 wr(0,32'h9999,15,0,0,2);wr(3,0,15,0,1,2);wr(256,0,15,1,0,2);
 rd(3,0,2);rd(256,0,2);rd(28,32'h1234,0);rd(32,32'hff123456,0);
 wr(4,1,0,0,0,0);if(starts!=0)$fatal(1,"zero strobe start side effect");
 tx_busy=1;wr(4,1,1,0,0,2);wr(4,2,1,0,0,2);if(starts||clears)$fatal(1,"busy control accepted");
 tx_busy=0;phy_ready=0;wr(4,1,1,0,0,2);if(starts)$fatal(1,"unready PHY accepted");
 phy_ready=1;wr(4,1,1,0,0,0);if(starts!=1)$fatal(1,"valid start missing");
 @(negedge clk);tx_done=1;underflow=1;@(negedge clk);tx_done=0;underflow=0;
 wr(4,2,1,0,0,0);if(clears!=1)$fatal(1,"clear missing");rd(24,32'h8c,0);
 wr(36,0,1,0,0,0);if(phy_enable!==0)$fatal(1,"PHY disable missing");wr(36,1,1,0,0,0);
 mdio_busy=1;wr(48,32'hce10796d,15,0,0,2);mdio_busy=0;
 wr(48,32'hce10796d,7,0,0,2);if(mdiostarts)$fatal(1,"invalid MDIO accepted");
 wr(48,32'hce10796d,15,0,0,0);
 if(mdiostarts!=1||!mdio_read||mdio_phy!=7||mdio_reg!=1||mdio_wdata!=16'h796d)$fatal(1,"MDIO command field mismatch");
 rd(48,32'hce10796d,0);
 @(negedge clk);mdio_done=1;@(negedge clk);mdio_done=0;rd(52,32'h4000796d,0);

 rd(64,0,0);rd(72,0,2);rd(76,0,2);
 wr(64,1,15,0,2,0);if(!arm||freeze)$fatal(1,"arm control");
 wr(64,2,15,2,0,0);if(!freeze)$fatal(1,"freeze control");
 frozen=1;rd(64,1,0);rd(72,32'h44332211,0);rd(76,256,0);rd(80,2,0);rd(84,1,0);
 wr(68,255,15,0,0,0);rd(68,255,0);wr(68,256,15,0,0,2);
 wr(64,3,15,0,0,2);wr(64,1,1,0,0,2);
 for(integer p=0;p<27;p=p+1)begin wr(128+p*4,32'h13579bdf^p,15,p%3,(p+1)%3,0);rd(128+p*4,32'h13579bdf^p,0);end
 tx_busy=1;wr(128,0,15,0,0,2);rd(128,32'h13579bdf,0);tx_busy=0;
 wr(128,32'h11223344,5,0,0,0);rd(128,32'h13229b44,0);
 $display("INDEPENDENT_AXIL_PASS writes%0d reads%0d AW/Worder B/Rbackpressure WSTRB reject_controls",writes,reads);$finish;
end
endmodule
