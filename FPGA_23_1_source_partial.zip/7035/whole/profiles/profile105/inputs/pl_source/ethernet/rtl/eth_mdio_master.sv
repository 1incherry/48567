`timescale 1ns/1ps
// Clause22, 32-bit preamble, max2.5MHz MDC from125MHz. Commands only from RTL regs.
module eth_mdio_master #(parameter HALF_PERIOD=25)(
 input wire clk,rst,start,read_cmd,input wire [4:0] phy_addr,reg_addr,
 input wire [15:0] write_data,input wire mdio_i,
 output reg mdio_o,mdio_t,mdc,busy,done,ack_error,output reg [15:0] read_data
);
 reg [63:0] frame;
 reg [5:0] bit_index;
 reg [15:0] divider,read_shift;
 reg reading;
 (* ASYNC_REG="TRUE" *) reg mdio_sync1,mdio_sync2;
 always @(posedge clk)begin mdio_sync1<=mdio_i;mdio_sync2<=mdio_sync1;end
 always @(posedge clk)begin
  if(rst)begin frame<=0;bit_index<=0;divider<=0;read_shift<=0;reading<=0;
   mdio_o<=1;mdio_t<=1;mdc<=0;busy<=0;done<=0;ack_error<=0;read_data<=0;end
  else begin
   done<=0;
   if(!busy)begin
    mdc<=0;divider<=0;mdio_t<=1;
    if(start)begin frame<={32'hffffffff,2'b01,(read_cmd?2'b10:2'b01),phy_addr,reg_addr,2'b10,write_data};
     bit_index<=63;busy<=1;reading<=read_cmd;read_shift<=0;ack_error<=0;mdio_o<=1;mdio_t<=0;end
   end else if(divider==HALF_PERIOD-1)begin
    divider<=0;
    if(!mdc)begin
     mdc<=1;
     if(reading&&bit_index==16&&mdio_sync2!=0)ack_error<=1;
     if(reading&&bit_index<16)read_shift<={read_shift[14:0],mdio_sync2};
    end else begin
     mdc<=0;
     if(bit_index==0)begin busy<=0;done<=1;mdio_t<=1;read_data<=read_shift;end
     else begin bit_index<=bit_index-1;mdio_o<=frame[bit_index-1];mdio_t<=reading&&(bit_index-1<=17);end
    end
   end else divider<=divider+1;
  end
 end
endmodule
