remove_input_delay -clock [get_clocks rgmii_rx_clk] [get_ports {eth_rxd[*] eth_rx_ctl}]
# Edge pairing follows Vivado2023.1 generated gmii_to_rgmii timing_reference_clocks.xdc.
# Launch from PHY virtual clock; capture the current same-polarity edge, and
# hold against the following opposite-polarity transition (DDR center aligned).
create_clock -name rgmii_rx_virtual -period 8.000
set_input_delay -clock rgmii_rx_virtual -max -0.950 [get_ports {eth_rxd[*] eth_rx_ctl}]
set_input_delay -clock rgmii_rx_virtual -min -3.050 [get_ports {eth_rxd[*] eth_rx_ctl}]
set_input_delay -clock rgmii_rx_virtual -clock_fall -max -0.950 -add_delay [get_ports {eth_rxd[*] eth_rx_ctl}]
set_input_delay -clock rgmii_rx_virtual -clock_fall -min -3.050 -add_delay [get_ports {eth_rxd[*] eth_rx_ctl}]
set_false_path -rise_from [get_clocks rgmii_rx_virtual] -fall_to [get_clocks rgmii_rx_clk] -setup
set_false_path -fall_from [get_clocks rgmii_rx_virtual] -rise_to [get_clocks rgmii_rx_clk] -setup
set_false_path -rise_from [get_clocks rgmii_rx_virtual] -rise_to [get_clocks rgmii_rx_clk] -hold
set_false_path -fall_from [get_clocks rgmii_rx_virtual] -fall_to [get_clocks rgmii_rx_clk] -hold
set_multicycle_path -from [get_clocks rgmii_rx_virtual] -to [get_clocks rgmii_rx_clk] -setup 0
set_multicycle_path -from [get_clocks rgmii_rx_virtual] -to [get_clocks rgmii_rx_clk] -hold -1

