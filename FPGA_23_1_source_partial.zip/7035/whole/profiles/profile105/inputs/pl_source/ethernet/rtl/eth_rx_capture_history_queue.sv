`timescale 1ns/1ps
// Four accepted-frame credits, one original 256x32 dual-clock RAM.
// RX never stops for ARM/FREEZE or a slow PS reader. Only a complete checked
// 170-byte HST/HSC frame advances the write Gray pointer. Ethernet has no
// READY: if no free credit at SOF, a qualified frame is dropped-new and the
// saturating overflow counter increments; an accepted/held frame is untouched.
// Public old CSR usage remains ARM1 -> FREEZE2 -> frozen/count1 -> 43words.
// ARM acknowledges only the currently held head; FREEZE requests a head lease,
// does NOT freeze RX, and never returns an empty/stale frozen acknowledgement.
// Both reset inputs start a common queue epoch; RAM itself is never reset.
module eth_rx_capture_history_queue(
 input wire rx_clk,rx_rst,input wire[7:0]rx_data,input wire rx_valid,rx_last,rx_bad,
 input wire reg_clk,reg_rst,input wire arm_toggle,freeze_request,
 input wire[13:0]read_index,output reg[31:0]read_data,
 output wire frozen,output wire[31:0]frame_count,
 output reg[31:0]bad_count,overflow_count);
 wire common_reset=rx_rst||reg_rst;
 (* ASYNC_REG="TRUE" *)reg[2:0]rx_release=0,reg_release=0;
 always @(posedge rx_clk or posedge common_reset)
  if(common_reset)rx_release<=0;else rx_release<={rx_release[1:0],1'b1};
 always @(posedge reg_clk or posedge common_reset)
  if(common_reset)reg_release<=0;else reg_release<={reg_release[1:0],1'b1};
 wire rx_run=rx_release[2],reg_run=reg_release[2];
 (* ram_style="block" *)reg[31:0]memory[0:255];
 reg[2:0]write_bin,write_gray,read_bin,read_gray;
 (* ASYNC_REG="TRUE" *)reg[2:0]read_gray_sync1,read_gray_sync2;
 (* ASYNC_REG="TRUE" *)reg[2:0]write_gray_sync1,write_gray_sync2;
 wire queue_full=write_gray=={~read_gray_sync2[2:1],read_gray_sync2[0]};
 wire queue_empty=read_gray==write_gray_sync2;
 reg[15:0]byte_index;reg frame_credit,frame_bad,outer_bad,format_bad,history_hint;
 reg[31:0]seed_word,magic_word,outer_crc,body_crc,outer_received,body_received;
 reg[15:0]ip_ident,seq_low;reg[7:0]ip_high;reg[19:0]ip_sum;
 wire[19:0]ip_fold1={4'd0,ip_sum[15:0]}+ip_sum[19:16];
 wire[16:0]ip_fold2={1'b0,ip_fold1[15:0]}+ip_fold1[19:16];
 reg[31:0]bad_rx,overflow_rx,bad_gray,overflow_gray;
 (* ASYNC_REG="TRUE" *)reg[31:0]bad_sync1,bad_sync2,overflow_sync1,overflow_sync2;
 reg arm_seen,head_held,request_pending,freeze_low_seen;
 wire arm_event=arm_toggle!=arm_seen;
 assign frozen=reg_run&&head_held&&!arm_event;
 assign frame_count=frozen?32'd1:32'd0;
 wire frame_can_store=byte_index==0?!queue_full:frame_credit;
 wire store=rx_run&&rx_valid&&frame_can_store&&byte_index<170;
 wire[7:0]write_address={write_bin[1:0],byte_index[7:2]};
 wire seed_known=seed_word==32'h48535431||seed_word==32'h48534331;
 wire hint_now=history_hint||(!outer_bad&&byte_index==54&&rx_data==8'h48);
 wire qualified=byte_index==169&&!frame_bad&&!rx_bad&&!outer_bad&&!format_bad&&seed_known&&seed_word==magic_word&&
  ip_fold2==17'h0ffff&&ip_ident==seq_low&&body_received==~body_crc&&{rx_data,outer_received[23:0]}==~outer_crc;
 function automatic[31:0]crc_byte(input[31:0]c0,input[7:0]d);
 reg[31:0]c;integer k;begin c=c0^d;for(k=0;k<8;k=k+1)c=c[0]?(c>>1)^32'hedb88320:c>>1;crc_byte=c;end endfunction
 function automatic[31:0]ungray32(input[31:0]g);
 integer k;begin ungray32[31]=g[31];for(k=30;k>=0;k=k-1)ungray32[k]=ungray32[k+1]^g[k];end endfunction
 function automatic outside_byte_bad(input[15:0]pos,input[7:0]v);
 begin outside_byte_bad=0;case(pos)
 0,6:outside_byte_bad=v!=2;
 1,7:outside_byte_bad=v!=8'h50;2,8:outside_byte_bad=v!=8'h52;3,9:outside_byte_bad=v!=8'h58;
 4:outside_byte_bad=v!=8'h70;5:outside_byte_bad=v!=8'h35;10:outside_byte_bad=v!=8'h31;11:outside_byte_bad=v!=0;
 12:outside_byte_bad=v!=8'h08;13:outside_byte_bad=v!=0;
 14:outside_byte_bad=v!=8'h45;15,16:outside_byte_bad=v!=0;17:outside_byte_bad=v!=156;
 20:outside_byte_bad=v!=8'h40;21:outside_byte_bad=v!=0;22:outside_byte_bad=v!=64;23:outside_byte_bad=v!=17;
 26,30:outside_byte_bad=v!=192;27,31:outside_byte_bad=v!=168;28,32:outside_byte_bad=v!=1;
 29:outside_byte_bad=v!=12;33:outside_byte_bad=v!=11;
 34,36:outside_byte_bad=v!=8'h1f;35,37:outside_byte_bad=v!=8'h91;
 38,40,41:outside_byte_bad=v!=0;39:outside_byte_bad=v!=8'h88;
 default:begin end
 endcase end endfunction
 function automatic format_byte_bad(input[15:0]pos,input[7:0]v);
 begin format_byte_bad=0;case(pos)
 42:format_byte_bad=v!=8'h45;43:format_byte_bad=v!=8'h54;44:format_byte_bad=v!=8'h58;45:format_byte_bad=v!=8'h31;
 50,51,52:format_byte_bad=v!=0;53:format_byte_bad=v!=1;
 62:format_byte_bad=v!=1;
 default:if(pos>=106&&pos<=165)format_byte_bad=v!=0;
 endcase end endfunction
 // Payload writer is reset-free and only modifies an uncommitted/free tail.
 always @(posedge rx_clk)if(store)case(byte_index[1:0])
  0:memory[write_address][7:0]<=rx_data;1:memory[write_address][15:8]<=rx_data;
  2:memory[write_address][23:16]<=rx_data;3:memory[write_address][31:24]<=rx_data;
 endcase
 // Tail bytes are zero; all old slot>0/padding/unknown leases are unreadable.
 always @(posedge reg_clk)begin
  if(frozen&&read_index<43)read_data<=read_index==42?(memory[{read_bin[1:0],read_index[5:0]}]&32'h0000ffff):memory[{read_bin[1:0],read_index[5:0]}];
  else read_data<=0;
 end
 always @(posedge rx_clk)begin
  if(!rx_run)begin
   write_bin<=0;write_gray<=0;read_gray_sync1<=0;read_gray_sync2<=0;
   byte_index<=0;frame_credit<=0;frame_bad<=0;outer_bad<=0;format_bad<=0;history_hint<=0;
   seed_word<=0;magic_word<=0;outer_crc<=32'hffffffff;body_crc<=32'hffffffff;outer_received<=0;body_received<=0;
   ip_ident<=0;seq_low<=0;ip_high<=0;ip_sum<=0;bad_rx<=0;overflow_rx<=0;bad_gray<=0;overflow_gray<=0;
  end else begin
   read_gray_sync1<=read_gray;read_gray_sync2<=read_gray_sync1;
   if(rx_valid)begin
    if(byte_index==0)frame_credit<=!queue_full;
    if(rx_bad)frame_bad<=1;
    outer_bad<=outer_bad||outside_byte_bad(byte_index,rx_data);
    format_bad<=format_bad||format_byte_bad(byte_index,rx_data);
    if(byte_index==54&&rx_data==8'h48&&!outer_bad)history_hint<=1;
    if(byte_index>=54&&byte_index<=57)seed_word<={seed_word[23:0],rx_data};
    if(byte_index>=58&&byte_index<=61)magic_word<={magic_word[23:0],rx_data};
    if(byte_index>=42&&byte_index<=165)outer_crc<=crc_byte(outer_crc,rx_data);
    if(byte_index>=58&&byte_index<=101)body_crc<=crc_byte(body_crc,rx_data);
    if(byte_index>=102&&byte_index<=105)body_received[(byte_index-102)*8+:8]<=rx_data;
    if(byte_index>=166&&byte_index<=168)outer_received[(byte_index-166)*8+:8]<=rx_data;
    if(byte_index>=14&&byte_index<=33)begin
     if(!byte_index[0])ip_high<=rx_data;else ip_sum<=ip_sum+{ip_high,rx_data};
    end
    if(byte_index==18)ip_ident[15:8]<=rx_data;if(byte_index==19)ip_ident[7:0]<=rx_data;
    if(byte_index==48)seq_low[15:8]<=rx_data;if(byte_index==49)seq_low[7:0]<=rx_data;
    if(rx_last)begin
     if(qualified)begin
      if(frame_can_store)begin write_bin<=write_bin+1'b1;write_gray<=((write_bin+3'd1)>>1)^(write_bin+3'd1);end
      else if(overflow_rx!=32'hffffffff)begin overflow_rx<=overflow_rx+1'b1;overflow_gray<=((overflow_rx+32'd1)>>1)^(overflow_rx+32'd1);end
     end else if(hint_now&&bad_rx!=32'hffffffff)begin bad_rx<=bad_rx+1'b1;bad_gray<=((bad_rx+32'd1)>>1)^(bad_rx+32'd1);end
     byte_index<=0;frame_credit<=0;frame_bad<=0;outer_bad<=0;format_bad<=0;history_hint<=0;
     seed_word<=0;magic_word<=0;outer_crc<=32'hffffffff;body_crc<=32'hffffffff;outer_received<=0;body_received<=0;
     ip_ident<=0;seq_low<=0;ip_high<=0;ip_sum<=0;
    end else if(byte_index!=65535)byte_index<=byte_index+1'b1;
   end
  end
 end
 always @(posedge reg_clk)begin
  if(!reg_run)begin
   read_bin<=0;read_gray<=0;write_gray_sync1<=0;write_gray_sync2<=0;
   bad_sync1<=0;bad_sync2<=0;overflow_sync1<=0;overflow_sync2<=0;
   bad_count<=0;overflow_count<=0;arm_seen<=arm_toggle;head_held<=0;request_pending<=0;freeze_low_seen<=0;
  end else begin
   write_gray_sync1<=write_gray;write_gray_sync2<=write_gray_sync1;
   bad_sync1<=bad_gray;bad_sync2<=bad_sync1;overflow_sync1<=overflow_gray;overflow_sync2<=overflow_sync1;
   if(arm_event)begin
    arm_seen<=arm_toggle;request_pending<=1;freeze_low_seen<=!freeze_request;
    if(head_held)begin read_bin<=read_bin+1'b1;read_gray<=((read_bin+3'd1)>>1)^(read_bin+3'd1);end
    head_held<=0;bad_count<=0;overflow_count<=0;
   end else begin
    if(request_pending&&!freeze_request)freeze_low_seen<=1;
    if(request_pending&&freeze_low_seen&&freeze_request&&!head_held&&!queue_empty)begin
     head_held<=1;request_pending<=0;bad_count<=ungray32(bad_sync2);overflow_count<=ungray32(overflow_sync2);
    end
   end
  end
 end
endmodule
