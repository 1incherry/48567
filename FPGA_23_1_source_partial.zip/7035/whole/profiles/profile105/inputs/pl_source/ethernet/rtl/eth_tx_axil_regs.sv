`timescale 1ns/1ps
// Single-outstanding AXI-Lite slave. AW and W are independently buffered.
module eth_tx_axil_regs(
 input wire clk,rst,
 input wire [31:0] s_awaddr,input wire s_awvalid,output wire s_awready,
 input wire [31:0] s_wdata,input wire [3:0] s_wstrb,input wire s_wvalid,output wire s_wready,
 output reg [1:0] s_bresp,output reg s_bvalid,input wire s_bready,
 input wire [31:0] s_araddr,input wire s_arvalid,output wire s_arready,
 output reg [31:0] s_rdata,output reg [1:0] s_rresp,output reg s_rvalid,input wire s_rready,
 input wire rx_frozen,input wire[31:0]rx_frames,rx_bad,rx_overflow,rx_data,
 output reg rx_arm,rx_freeze,output reg[13:0]rx_index,
 input wire phy_ready,clock_locked,input wire [1:0] mac_speed,input wire tx_underflow,
 output reg tx_start,tx_clear,output reg [15:0] frame_count,
 output reg [31:0] seq_base,seed,gap_cycles,
 input wire tx_busy,tx_done,tx_error,input wire [31:0] sent_count,last_seq,
 output reg [863:0] payload,
 output reg phy_enable,
 output reg mdio_start,mdio_read,output reg [4:0] mdio_phy,mdio_reg,
 output reg [15:0] mdio_wdata,input wire mdio_busy,mdio_done,mdio_ack_error,input wire [15:0] mdio_rdata
);
 reg aw_hold,w_hold;reg [31:0] awaddr,wdata;reg [3:0] wstrb;
 reg done_sticky,underflow_sticky,control_error,mdio_done_sticky;
 reg [31:0] mdio_last_cmd;
 function automatic [31:0] merge(input[31:0] old,data,input[3:0] strobe);
  integer j;begin merge=old;for(j=0;j<4;j=j+1)if(strobe[j])merge[j*8+:8]=data[j*8+:8];end
 endfunction
 assign s_awready=!aw_hold&&!s_bvalid;
 assign s_wready=!w_hold&&!s_bvalid;
 assign s_arready=!s_rvalid;
 always @(posedge clk)begin
  if(rst)begin aw_hold<=0;w_hold<=0;awaddr<=0;wdata<=0;wstrb<=0;s_bvalid<=0;s_bresp<=0;s_rvalid<=0;s_rresp<=0;s_rdata<=0;
   rx_arm<=0;rx_freeze<=0;rx_index<=0;tx_start<=0;tx_clear<=0;frame_count<=32;seq_base<=0;seed<=32'h70352026;gap_cycles<=125000;
   payload<=0;done_sticky<=0;underflow_sticky<=0;control_error<=0;phy_enable<=1;mdio_start<=0;mdio_read<=0;
   mdio_phy<=7;mdio_reg<=0;mdio_wdata<=0;mdio_done_sticky<=0;mdio_last_cmd<=0;end
  else begin
   tx_start<=0;tx_clear<=0;mdio_start<=0;
   if(tx_done)done_sticky<=1;
   if(tx_underflow)underflow_sticky<=1;
   if(mdio_done)mdio_done_sticky<=1;
   if(s_awvalid&&s_awready)begin aw_hold<=1;awaddr<=s_awaddr;end
   if(s_wvalid&&s_wready)begin w_hold<=1;wdata<=s_wdata;wstrb<=s_wstrb;end
   if(s_bvalid&&s_bready)s_bvalid<=0;
   if(aw_hold&&w_hold&&!s_bvalid)begin
    aw_hold<=0;w_hold<=0;s_bvalid<=1;s_bresp<=0;
    if(awaddr[31:8]!=0||awaddr[1:0]!=0)s_bresp<=2;
    else case(awaddr[7:0])
     8'h04:if(wstrb[0])begin
      if(wdata[1])begin
       if(tx_busy)s_bresp<=2;
       else begin tx_clear<=1;done_sticky<=0;underflow_sticky<=0;control_error<=0;end
      end
      if(wdata[0])begin
       if(tx_busy||!phy_ready)begin s_bresp<=2;control_error<=1;end
       else begin tx_start<=1;done_sticky<=0;control_error<=0;end
      end
     end
     8'h40:if(wstrb==4'hf&&wdata==1)begin rx_arm<=~rx_arm;rx_freeze<=0;end else if(wstrb==4'hf&&wdata==2)rx_freeze<=1;else s_bresp<=2;
     8'h44:if(wstrb==4'hf&&wdata<256)rx_index<=wdata[13:0];else s_bresp<=2;
     8'h08:frame_count<=merge({16'b0,frame_count},wdata,wstrb);
     8'h0c:seq_base<=merge(seq_base,wdata,wstrb);
     8'h10:seed<=merge(seed,wdata,wstrb);
     8'h14:gap_cycles<=merge(gap_cycles,wdata,wstrb);
     8'h24:if(wstrb[0])phy_enable<=wdata[0];
     8'h30:if(wstrb==4'hf&&wdata[31])begin
      if(mdio_busy)s_bresp<=2;
      else begin mdio_start<=1;mdio_read<=wdata[30];mdio_phy<=wdata[29:25];mdio_reg<=wdata[24:20];
       mdio_wdata<=wdata[15:0];mdio_last_cmd<=wdata;mdio_done_sticky<=0;end
     end else s_bresp<=2;
     default:if(awaddr>=32'h80&&awaddr<=32'he8&&!tx_busy)payload[((awaddr-32'h80)>>2)*32+:32]<=merge(payload[((awaddr-32'h80)>>2)*32+:32],wdata,wstrb);else s_bresp<=2;
    endcase
   end
   if(s_rvalid&&s_rready)s_rvalid<=0;
   if(s_arvalid&&s_arready)begin
    s_rvalid<=1;s_rresp<=0;s_rdata<=0;
    if(s_araddr[31:8]!=0||s_araddr[1:0]!=0)s_rresp<=2;
    else case(s_araddr[7:0])
     8'h40:s_rdata<={31'b0,rx_frozen};
     8'h44:s_rdata<={18'b0,rx_index};
     8'h48:if(rx_frozen)s_rdata<=rx_data;else s_rresp<=2;
     8'h4c:if(rx_frozen)s_rdata<=rx_frames;else s_rresp<=2;
     8'h50:if(rx_frozen)s_rdata<=rx_bad;else s_rresp<=2;
     8'h54:if(rx_frozen)s_rdata<=rx_overflow;else s_rresp<=2;
     8'h00:s_rdata<=32'h45545831;
     8'h04:s_rdata<=0;
     8'h08:s_rdata<={16'b0,frame_count};
     8'h0c:s_rdata<=seq_base;8'h10:s_rdata<=seed;8'h14:s_rdata<=gap_cycles;
     8'h18:s_rdata<={23'b0,(control_error|tx_error),mac_speed,mdio_busy,underflow_sticky,clock_locked,phy_ready,done_sticky,tx_busy};
     8'h1c:s_rdata<=sent_count;8'h20:s_rdata<=last_seq;8'h24:s_rdata<={31'b0,phy_enable};
     8'h30:s_rdata<=mdio_last_cmd;
     8'h34:s_rdata<={mdio_busy,mdio_done_sticky,mdio_ack_error,13'b0,mdio_rdata};
     default:if(s_araddr>=32'h80&&s_araddr<=32'he8)s_rdata<=payload[((s_araddr-32'h80)>>2)*32+:32];else s_rresp<=2;
    endcase
   end
  end
 end
endmodule
