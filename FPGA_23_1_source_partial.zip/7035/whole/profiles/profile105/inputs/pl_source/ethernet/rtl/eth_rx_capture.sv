`timescale 1ns/1ps
// Opt-in only. Default0 is the unchanged c50 legacy implementation.
module eth_rx_capture #(parameter integer CONTINUOUS_HISTORY=0)(
 input wire rx_clk,rx_rst,input wire[7:0]rx_data,input wire rx_valid,rx_last,rx_bad,
 input wire reg_clk,reg_rst,input wire arm_toggle,freeze_request,
 input wire[13:0]read_index,output wire[31:0]read_data,
 output wire frozen,output wire[31:0]frame_count,bad_count,overflow_count);
 generate if(CONTINUOUS_HISTORY==0)begin:legacy_default0
  eth_rx_capture_legacy_exact u_exact(.*);
 end else begin:continuous_history1
  eth_rx_capture_history_queue u_queue(.*);
 end endgenerate
endmodule

`timescale 1ns/1ps
// Frame storage crosses domains only after freeze acknowledgment. No live
// payload bus is sampled in the register clock domain. Contents not reset.
module eth_rx_capture_legacy_exact(
 input wire rx_clk,rx_rst,input wire [7:0] rx_data,
 input wire rx_valid,rx_last,rx_bad,
 input wire reg_clk,reg_rst,input wire arm_toggle,freeze_request,
 input wire [13:0] read_index,output reg [31:0] read_data,
 output wire frozen,output reg [31:0] frame_count,bad_count,overflow_count
);
 (* ram_style="block" *) reg [31:0] memory[0:255];
 (* ASYNC_REG="TRUE" *) reg [1:0] arm_sync,freeze_sync;
 (* ASYNC_REG="TRUE" *) reg [3:0] ack_sync;
 reg last_arm,armed,ack;
 reg [15:0] byte_index;
 reg [31:0] frames_rx,bad_rx,overflow_rx;
 reg frame_bad;
 wire store=armed&&rx_valid&&(frames_rx<4)&&(byte_index<256);
 wire [13:0] write_index={6'b0,frames_rx[1:0],byte_index[7:2]};
 always @(posedge rx_clk)begin
  if(store)case(byte_index[1:0])
   0:memory[write_index][7:0]<=rx_data;
   1:memory[write_index][15:8]<=rx_data;
   2:memory[write_index][23:16]<=rx_data;
   3:memory[write_index][31:24]<=rx_data;
  endcase
 end
 always @(posedge reg_clk)read_data<=memory[read_index[7:0]];
 always @(posedge rx_clk)begin
  if(rx_rst)begin
   arm_sync<=0;freeze_sync<=0;last_arm<=0;armed<=0;ack<=1;
   byte_index<=0;frames_rx<=0;bad_rx<=0;overflow_rx<=0;frame_bad<=0;
  end else begin
   arm_sync<={arm_sync[0],arm_toggle};freeze_sync<={freeze_sync[0],freeze_request};
   if(arm_sync[1]!=last_arm)begin
    last_arm<=arm_sync[1];armed<=1;ack<=0;byte_index<=0;
    frames_rx<=0;bad_rx<=0;overflow_rx<=0;frame_bad<=0;
   end else if(armed)begin
    if(rx_valid)begin
     if(rx_bad)frame_bad<=1;
     if(rx_last)begin
      frames_rx<=frames_rx+1;
      if(rx_bad||frame_bad||byte_index!=169)bad_rx<=bad_rx+1;
      if(frames_rx>=4||byte_index>=256)overflow_rx<=overflow_rx+1;
      byte_index<=0;frame_bad<=0;
      if(freeze_sync[1])begin armed<=0;ack<=1;end
     end else if(byte_index!=65535)byte_index<=byte_index+1;
    end else if(freeze_sync[1]&&byte_index==0)begin armed<=0;ack<=1;end
   end
  end
 end
 assign frozen=ack_sync[3];
 always @(posedge reg_clk)begin
  if(reg_rst)begin ack_sync<=0;frame_count<=0;bad_count<=0;overflow_count<=0;end
  else begin
   ack_sync<={ack_sync[2:0],ack};
   // RX counters have been stable for >=3 reg clocks before this capture.
   if(ack_sync[2]&&!ack_sync[3])begin
    frame_count<=frames_rx;bad_count<=bad_rx;overflow_count<=overflow_rx;
   end
  end
 end
endmodule
