# Scalar toggle / sampled-bit CDC: cut only the first synchronizer input.
# No complete sys125/RGMII clock-domain exception is permitted in this branch.
set eth_scalar_first [get_pins -quiet -hier -regexp {.*u_eth/(u_capture/(arm_sync|freeze_sync|ack_sync)_reg\[0\]|u_mac/(rx_prescale_sync|rx_mii_select_sync)_reg\[0\])/D}]
set_false_path -to $eth_scalar_first
set eth_cal_first [get_pins -quiet {u_eth/delay_ready_sync_reg[0]/D}]
set_false_path -to $eth_cal_first
# Vendor reset chains asynchronously assert, then synchronously shift to zero.
# Do not cut the inter-stage D paths or the receiving-domain reset fanout.
set eth_rx_reset_async [get_pins -quiet -hier -regexp {.*u_eth/u_mac/rgmii_phy_if_inst/rx_rst_reg_reg\[[0-3]\]/PRE}]
set_false_path -to $eth_rx_reset_async
# Legacy diagnostic counters are captured once, after four ack synchronizer
# stages. They remain immutable until a new arm_toggle request reaches RX.
set eth_cap_source [get_cells -quiet -hier -regexp {.*u_eth/u_capture/(frames_rx|bad_rx|overflow_rx)_reg\[[0-9]+\]}]
set eth_cap_dest [get_cells -quiet -hier -regexp {.*u_eth/u_capture/(frame_count|bad_count|overflow_count)_reg\[[0-9]+\]}]
set_max_delay -datapath_only 8.000 -from $eth_cap_source -to $eth_cap_dest
set_bus_skew 4.000 -from $eth_cap_source -to $eth_cap_dest
