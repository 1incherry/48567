# Source in the independent fullproject after create_project. No hardware I/O.
set provision_ip npu_trusted_provision_vio
if {[llength [get_ips -quiet $provision_ip]]==0} {
 create_ip -name vio -vendor xilinx.com -library ip -version 3.0 -module_name $provision_ip
}
set_property -dict [list \
 CONFIG.C_NUM_PROBE_IN {5} CONFIG.C_NUM_PROBE_OUT {5} CONFIG.C_EN_PROBE_IN_ACTIVITY {0} \
 CONFIG.C_PROBE_IN0_WIDTH {32} CONFIG.C_PROBE_IN1_WIDTH {32} CONFIG.C_PROBE_IN2_WIDTH {32} \
 CONFIG.C_PROBE_IN3_WIDTH {128} CONFIG.C_PROBE_IN4_WIDTH {32} \
 CONFIG.C_PROBE_OUT0_WIDTH {128} CONFIG.C_PROBE_OUT1_WIDTH {128} CONFIG.C_PROBE_OUT2_WIDTH {128} \
 CONFIG.C_PROBE_OUT3_WIDTH {32} CONFIG.C_PROBE_OUT4_WIDTH {32} \
 CONFIG.C_PROBE_OUT0_INIT_VAL {0x0} CONFIG.C_PROBE_OUT1_INIT_VAL {0x0} CONFIG.C_PROBE_OUT2_INIT_VAL {0x0} \
 CONFIG.C_PROBE_OUT3_INIT_VAL {0x0} CONFIG.C_PROBE_OUT4_INIT_VAL {0x0}] [get_ips $provision_ip]
generate_target all [get_ips $provision_ip]
puts "TRUSTED_PROVISION_VIO_CONFIGURED_DEFAULT_ZERO"
