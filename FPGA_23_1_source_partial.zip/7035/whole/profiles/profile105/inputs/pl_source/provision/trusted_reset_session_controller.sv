`timescale 1ns/1ps
// Independent CANDIDATE, not wired into the preserved R12 board design.
// clk/POR/locked, provision/resume/revoke and all quiet inputs are trusted PL.
// There is no PS command/key/epoch/release port. ps_reset_n is cancel-only.
module trusted_reset_session_controller #(
 parameter integer EPOCH_WIDTH=32,
 parameter integer SESSION_WIDTH=128,
 parameter integer RESET_HOLD_CYCLES=4,
 parameter integer DRAIN_TIMEOUT_CYCLES=1000000
)(
 input wire clk,trusted_por_n,clock_locked,ps_reset_n,
 input wire trusted_revoke,
 input wire guard_quiescent,axi_quiescent,consumer_quiescent,
 input wire provision_valid,output wire provision_ready,
 input wire trusted_fresh_key_ready,
 input wire [127:0] provision_session_id,provision_key_fingerprint,
 output reg provision_accepted,provision_rejected,
 input wire trusted_resume_valid,output wire trusted_resume_ready,
 input wire [31:0] trusted_resume_epoch,
 input wire [127:0] trusted_resume_session_id,
 output reg resume_accepted,resume_rejected,
 input wire consumer_done,output wire accepted_done,
 output wire security_reset_n,arith_reset_n,
 output wire authorized,key_session_valid,cancel,commit_allowed,
 output wire [31:0] authorization_epoch,
 output wire [127:0] session_id,key_fingerprint,
 output wire quiescent,draining,
 output reg epoch_exhausted,session_exhausted,drain_timed_out,
 output wire locked_fault
);
 localparam WAIT_KEY=0,DRAIN=1,HOLD_RESET=2,WAIT_RESUME=3,RUN=4,LOCKED=5;
 localparam [EPOCH_WIDTH-1:0] EPOCH_MAX={EPOCH_WIDTH{1'b1}};
 localparam [127:0] SESSION_MAX={{(128-SESSION_WIDTH){1'b0}},{SESSION_WIDTH{1'b1}}};
 wire root_assert_n=trusted_por_n&&clock_locked;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *) reg [2:0] root_release;
 always @(posedge clk or negedge root_assert_n)
  if(!root_assert_n)root_release<=0;else root_release<={root_release[1:0],1'b1};
 assign security_reset_n=root_assert_n&&root_release[2];
 // Immediate PS assertion closes commits; its release is synchronized.
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *) reg [1:0] ps_release;
 always @(posedge clk or negedge ps_reset_n)
  if(!ps_reset_n)ps_release<=0;else ps_release<={ps_release[0],1'b1};
 wire ps_live=ps_reset_n&&ps_release[1];
 reg [2:0] state;
 reg ps_seen,revoke_seen,have_key,have_history;
 reg [EPOCH_WIDTH-1:0] protected_epoch;
 reg [127:0] bound_session,bound_fingerprint,last_session,last_fingerprint;
 reg [31:0] reset_ticks,drain_ticks;
 wire all_quiet=guard_quiescent&&axi_quiescent&&consumer_quiescent;
 wire revoke_event=(!ps_live&&!ps_seen)||(trusted_revoke&&!revoke_seen);
 assign locked_fault=epoch_exhausted||drain_timed_out;
 assign authorization_epoch={{(32-EPOCH_WIDTH){1'b0}},protected_epoch};
 assign session_id=bound_session;assign key_fingerprint=bound_fingerprint;
 // This is only a statement about the EXTERNAL installed key session. The
 // external service must retain the previous secret through outstanding MACs.
 assign key_session_valid=security_reset_n&&have_key&&!locked_fault;
 assign authorized=security_reset_n&&state==RUN&&have_key&&!locked_fault&&ps_live&&!trusted_revoke;
 assign cancel=!authorized;
 assign commit_allowed=authorized;
 assign accepted_done=consumer_done&&commit_allowed;
 assign draining=state==DRAIN;
 assign quiescent=security_reset_n&&all_quiet&&state!=RUN&&state!=DRAIN;
 // Only compute datapath registers may use arith_reset_n. Owner/guard/epoch/
 // generation/cache authority/history must instead use security_reset_n.
 // A timeout NEVER abandons outstanding bus requests by asserting this reset.
 assign arith_reset_n=security_reset_n&&state!=WAIT_KEY&&state!=HOLD_RESET;
 assign provision_ready=security_reset_n&&(state==WAIT_KEY||state==WAIT_RESUME)&&
  all_quiet&&ps_live&&!trusted_revoke&&!locked_fault&&!session_exhausted;
 assign trusted_resume_ready=security_reset_n&&state==WAIT_RESUME&&all_quiet&&
  ps_live&&!trusted_revoke&&have_key&&!locked_fault&&!provision_valid;
 wire provision_ok=trusted_fresh_key_ready&&provision_session_id!=0&&
  provision_session_id<=SESSION_MAX&&provision_key_fingerprint!=0&&
  (!have_history||(provision_session_id>last_session&&provision_key_fingerprint!=last_fingerprint));
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=WAIT_KEY;ps_seen<=0;revoke_seen<=0;have_key<=0;have_history<=0;
   protected_epoch<=0;bound_session<=0;bound_fingerprint<=0;last_session<=0;last_fingerprint<=0;
   reset_ticks<=0;drain_ticks<=0;epoch_exhausted<=0;session_exhausted<=0;drain_timed_out<=0;
   provision_accepted<=0;provision_rejected<=0;resume_accepted<=0;resume_rejected<=0;
  end else begin
   provision_accepted<=0;provision_rejected<=0;resume_accepted<=0;resume_rejected<=0;
   ps_seen<=!ps_live;revoke_seen<=trusted_revoke;
   case(state)
    WAIT_KEY:begin reset_ticks<=0;drain_ticks<=0;end
    DRAIN:begin
     if(all_quiet)begin state<=HOLD_RESET;reset_ticks<=0;drain_ticks<=0;end
     else if(drain_ticks>=DRAIN_TIMEOUT_CYCLES-1)begin drain_timed_out<=1;state<=LOCKED;end
     else drain_ticks<=drain_ticks+1'b1;
    end
    HOLD_RESET:begin
     if(reset_ticks<RESET_HOLD_CYCLES)reset_ticks<=reset_ticks+1'b1;
     if(reset_ticks>=RESET_HOLD_CYCLES-1&&ps_live&&!trusted_revoke)state<=WAIT_RESUME;
    end
    WAIT_RESUME:if(trusted_resume_valid&&trusted_resume_ready)begin
     if(trusted_resume_epoch==authorization_epoch&&trusted_resume_session_id==bound_session)begin
      state<=RUN;resume_accepted<=1;
     end else resume_rejected<=1;
    end
    RUN:begin reset_ticks<=0;drain_ticks<=0;end
    LOCKED:begin end
    default:begin state<=LOCKED;drain_timed_out<=1;end
   endcase
   if(provision_valid&&provision_ready)begin
    // This window is already unauthorized AND physically quiescent. An
    // invalid trusted-provider record cannot fall back to an old key lease.
    have_key<=0;
    if(provision_ok&&protected_epoch!=EPOCH_MAX)begin
     have_key<=1;have_history<=1;bound_session<=provision_session_id;bound_fingerprint<=provision_key_fingerprint;
     last_session<=provision_session_id;last_fingerprint<=provision_key_fingerprint;
     protected_epoch<=protected_epoch+1'b1;session_exhausted<=provision_session_id==SESSION_MAX;
     state<=HOLD_RESET;reset_ticks<=0;provision_accepted<=1;
    end else begin
     provision_rejected<=1;state<=WAIT_KEY;
     if(protected_epoch==EPOCH_MAX)begin epoch_exhausted<=1;state<=LOCKED;end
    end
   end
   // A held PS reset consumes one epoch, regardless of duration. PS can burn
   // available epochs (DoS), but cannot reset or wrap the protected counter.
   if(revoke_event&&have_key&&!locked_fault)begin
    if(protected_epoch==EPOCH_MAX)begin epoch_exhausted<=1;state<=LOCKED;end
    else begin
     protected_epoch<=protected_epoch+1'b1;
     if(state!=HOLD_RESET)begin state<=DRAIN;drain_ticks<=0;end
    end
   end
  end
 end
endmodule
