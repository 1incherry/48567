`timescale 1ns/1ps
// The VIO and provider use the SAME independently rooted trusted clock.
// No installed key is attached to an INPUT/readback probe.
module trusted_provision_vio_bridge(
 input wire clk,
 input wire [31:0] ack_word,status_word,controller_epoch,last_sequence_word,
 input wire [127:0] controller_session_id,
 output wire [127:0] debug_key,debug_session_id,debug_key_fingerprint,
 output wire [31:0] debug_resume_epoch,debug_command
);
 npu_trusted_provision_vio u_provision_vio(
  .clk(clk),.probe_in0(ack_word),.probe_in1(status_word),.probe_in2(controller_epoch),
  .probe_in3(controller_session_id),.probe_in4(last_sequence_word),
  .probe_out0(debug_key),.probe_out1(debug_session_id),.probe_out2(debug_key_fingerprint),
  .probe_out3(debug_resume_epoch),.probe_out4(debug_command));
endmodule
