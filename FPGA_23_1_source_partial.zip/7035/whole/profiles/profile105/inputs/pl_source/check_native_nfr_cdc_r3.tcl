set first [get_pins -quiet -hier -regexp {.*u_frames/(receiver/(send|ack)_sync_reg\[0\]|transmitter/(send|ack)_sync_reg\[0\])/D}]
set rh [get_cells -quiet -hier -regexp {.*u_frames/receiver/held_header_reg\[[0-9]+\]}]
set th [get_cells -quiet -hier -regexp {.*u_frames/transmitter/held_packet_reg\[[0-9]+\]}]
puts "NFR_CDC first=[llength $first] rx_header=[llength $rh] tx_packet=[llength $th]"
if {[llength $first]!=4} {error "NFR first synchronizer topology changed"}
if {[llength $rh]!=384} {error "NFR RX immutable header width changed"}
if {[llength $th]!=284} {error "NFR TX immutable packet unexpectedly absent"}
set rl [get_cells -quiet -hier -regexp {.*u_frames/receiver/local_header_reg\[[0-9]+\]}]
set tl [get_cells -quiet -hier -regexp {.*u_frames/transmitter/local_packet_reg\[[0-9]+\]}]
if {[llength $rl]!=384||[llength $tl]!=496} {error "NFR destination mailbox width changed"}
puts "NFR_LOCAL_MAILBOX RX=[llength $rl] TX=[llength $tl]"
set delays [get_cells -quiet -hier -filter {REF_NAME == IDELAYE2 && NAME =~ *g_rx_delay*}]
if {[llength $delays]!=5} {error "Proven R7 RX input delays absent"}
foreach delay $delays {if {[get_property IDELAY_VALUE $delay]!=11} {error "RX tap qualification changed"}}

set ef [get_pins -quiet -hier -regexp {.*u_eth/(u_capture/(arm_sync|freeze_sync|ack_sync)_reg\[0\]|u_mac/(rx_prescale_sync|rx_mii_select_sync)_reg\[0\])/D}]
set er [get_pins -quiet -hier -regexp {.*u_eth/u_mac/rgmii_phy_if_inst/rx_rst_reg_reg\[[0-3]\]/PRE}]
if {[llength $ef]!=5 || [llength $er]!=4} {error "Ethernet synchronizer topology changed"}
if {[llength [get_clocks -quiet sys_clk_50m]]!=1} {error "Missing physical 50MHz oscillator clock"}

# Bind the original 100MHz assertion to the actual generating pin; no clock is created or renamed.
set actual100pin [get_pins -quiet u_trusted_clock/u_mmcm/CLKOUT0]
if {[llength $actual100pin]!=1} {error ACTUAL_TRUSTED_MMCM_CLKOUT0_MISSING}
set actual100clock [get_clocks -quiet -of_objects $actual100pin]
if {[llength $actual100clock]!=1} {error ACTUAL_TRUSTED_MMCM_CLOCK_UNIQUE}
set actual100name [get_property NAME $actual100clock]
if {[get_property WAVEFORM $actual100clock] ne "0.000 5.000"} {error ACTUAL_TRUSTED_100MHz_WAVEFORM_CHANGED}
if {[get_property MASTER_CLOCK $actual100clock] ne "sys_clk_50m"} {error ACTUAL_TRUSTED_100MHz_MASTER_CHANGED}
puts "ACTUAL_PIN_BOUND_TRUSTED_100MHz $actual100pin $actual100name period[get_property PERIOD $actual100clock] waveform[get_property WAVEFORM $actual100clock] master[get_property MASTER_CLOCK $actual100clock]"
foreach {cn period} [list sys_clk_50m 20.000 $actual100name 10.000 clk_raw 8.000 rgmii_rx_clk 8.000] {
 set cc [get_clocks -quiet $cn]
 if {[llength $cc]!=1} {error "Missing clock $cn"}
 if {abs([get_property PERIOD $cc]-$period)>0.001} {error "Wrong clock $cn period"}
}

# Every496 destination bits were physically traced:303 dynamic use all284
# unique held flops (19 merged duplicates),193 fixed0 have only local GND.
set nfr_dynamic 0
set nfr_zero 0
set nfr_seen {}
foreach c $tl {
 set ds {}
 set n [get_nets -segments -of_objects [get_pins -of_objects $c -filter {REF_PIN_NAME == D}]]
 foreach q [get_pins -of_objects $n -filter {DIRECTION == OUT}] {
  set qc [get_cells -of_objects $q]
  if {[get_property IS_PRIMITIVE $qc]} {lappend ds $q}
 }
 if {[llength $ds]!=1} {error "NFR_TX_DYNAMIC_DRIVER_COUNT $c"}
 set dc [get_cells -of_objects $ds]
 set ref [get_property REF_NAME $dc]
 if {$ref eq "FDRE" && [lsearch -exact $th $dc]>=0 && [get_property REF_PIN_NAME $ds] eq "Q"} {
  incr nfr_dynamic
  lappend nfr_seen $dc
 } elseif {$ref eq "GND" && [get_property NAME $dc] eq "u_frames/transmitter/GND"} {
  incr nfr_zero
 } else {error "NFR_TX_UNCONSTRAINED_SOURCE $c $dc $ref"}
}
if {$nfr_dynamic!=303 || $nfr_zero!=193 || [llength [lsort -unique $nfr_seen]]!=284} {error "NFR_TX_TRANSFER_BIT_TOPOLOGY_CHANGED"}
puts "NFR_TX_EVERY_BIT_AUDITED dynamic=$nfr_dynamic zero=$nfr_zero unique_held=[llength [lsort -unique $nfr_seen]]"
