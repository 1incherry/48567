`timescale 1ns/1ps
// Two authenticated32-byte cache registers, one RGB24 skid and one32-byte
// output assembly register. No image RAM, cipher, or raw-DDR bypass.
module trusted_letterbox_io_native1080(
 input wire clk,rst_n,bind_frame,cancel,authorized,key_valid,
 input wire [31:0] session_id,frame_id,epoch,authorization_epoch,
 input wire read_valid,output wire read_ready,input wire [31:0] read_source_address,
 input wire [16:0] read_pixel_index,
 output wire quad_valid,output wire quad_verified,output wire [95:0] quad,
 output wire [16:0] quad_pixel_index,
 output wire [31:0] quad_session,quad_frame,quad_epoch,
 input wire pixel_valid,output wire pixel_ready,input wire [31:0] pixel_address,input wire [23:0] pixel_data,
 output wire quiescent,output reg fault,output reg [31:0] committed_bytes,
 output wire request_valid,input wire request_ready,output wire request_write,
 output wire [31:0] request_address,request_strobe,request_tensor_mask,
 output wire [255:0] request_data,output wire [15:0] request_role,request_shape,
 input wire response_valid,output wire response_ready,input wire response_error,guard_context_live,
 input wire [255:0] response_data,input wire guard_quiescent
);
 localparam IDLE=0,SCAN=1,R_OFFER=2,R_WAIT=3,Q_REPORT=4,APPEND=5,W_OFFER=6,W_WAIT=7;
 reg [3:0] state;reg aborted;
 reg [255:0] cache0,cache1;
 reg valid0,valid1;reg [31:0] address0,address1;
 reg [31:0] session0,session1,frame0,frame1,epoch0,epoch1;
 reg [31:0] quad_source,miss_address;reg [16:0] saved_pixel_index;
 reg [3:0] quad_byte;reg [95:0] assembled_quad;reg verified;
 reg miss_slot;
 reg [255:0] assembly;reg [5:0] lane;reg [31:0] word_address,accepted_bytes;
 reg [23:0] held_pixel;reg [1:0] pixel_byte;reg word_ends_pixel;
 wire live=authorized&&key_valid&&authorization_epoch==epoch&&!cancel&&!aborted;
 wire stopping=!live||fault;
 assign read_ready=state==IDLE;
 assign pixel_ready=state==IDLE&&!read_valid;
 assign quad_valid=state==Q_REPORT;
 assign quad_verified=verified&&live&&!fault;
 assign quad=assembled_quad;assign quad_pixel_index=saved_pixel_index;
 assign quad_session=session_id;assign quad_frame=frame_id;assign quad_epoch=epoch;
 assign quiescent=state==IDLE&&lane==0&&guard_quiescent;
 assign request_valid=state==R_OFFER||state==W_OFFER;
 assign request_write=state==W_OFFER;
 assign request_address=state==R_OFFER?miss_address:word_address;
 assign request_strobe=state==W_OFFER?32'hffffffff:32'd0;
 assign request_tensor_mask=32'hffffffff;
 assign request_data=assembly;
 assign request_role=state==R_OFFER?16'h4002:16'h4001;
 assign request_shape=request_role;
 assign response_ready=state==R_WAIT||state==W_WAIT;
 wire slot=quad_byte>=6;
 wire [31:0] byte_address=quad_source+(slot?(32'd5760+quad_byte-6):quad_byte);
 wire [31:0] aligned_address={byte_address[31:5],5'd0};
 wire hit=slot?(valid1&&address1==aligned_address&&session1==session_id&&frame1==frame_id&&epoch1==epoch):
   (valid0&&address0==aligned_address&&session0==session_id&&frame0==frame_id&&epoch0==epoch);
 wire [255:0] cache_data=slot?cache1:cache0;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;aborted<=0;fault<=0;valid0<=0;valid1<=0;cache0<=0;cache1<=0;address0<=0;address1<=0;
   session0<=0;session1<=0;frame0<=0;frame1<=0;epoch0<=0;epoch1<=0;
   quad_source<=0;miss_address<=0;saved_pixel_index<=0;quad_byte<=0;assembled_quad<=0;verified<=0;miss_slot<=0;
   assembly<=0;lane<=0;word_address<=32'h21000000;accepted_bytes<=0;committed_bytes<=0;held_pixel<=0;pixel_byte<=0;word_ends_pixel<=0;
  end else begin
   if(!authorized||!key_valid||cancel||authorization_epoch!=epoch)begin
    valid0<=0;valid1<=0;aborted<=1;
    // Already offered requests remain immutable. Unoffered partial words are
    // never sealed, and may be discarded only while not pending a guard op.
    if(state==IDLE||state==SCAN||state==Q_REPORT||state==APPEND)begin lane<=0;assembly<=0;end
   end
   if(bind_frame)begin
    state<=IDLE;aborted<=0;fault<=0;valid0<=0;valid1<=0;lane<=0;assembly<=0;
    accepted_bytes<=0;committed_bytes<=0;word_address<=32'h21000000;verified<=0;
   end else case(state)
    IDLE:if(read_valid)begin
     quad_source<=read_source_address;saved_pixel_index<=read_pixel_index;quad_byte<=0;assembled_quad<=0;verified<=0;
     if(stopping||read_source_address<32'h22000000||{1'b0,read_source_address}+5766>33'h0225eec00)begin
      fault<=1;aborted<=1;lane<=0;state<=Q_REPORT;
     end else state<=SCAN;
    end else if(pixel_valid)begin
     if(stopping)begin lane<=0;assembly<=0;end
     else if(pixel_address!=32'h21000000+accepted_bytes||accepted_bytes>307197)begin fault<=1;aborted<=1;lane<=0;end
     else begin held_pixel<=pixel_data;pixel_byte<=0;state<=APPEND;end
    end
    SCAN:if(stopping)begin verified<=0;lane<=0;state<=Q_REPORT;end
     else if(hit)begin
      assembled_quad[quad_byte*8+:8]<=cache_data[byte_address[4:0]*8+:8];
      if(quad_byte==11)begin verified<=1;state<=Q_REPORT;end else quad_byte<=quad_byte+1;
     end else begin miss_address<=aligned_address;miss_slot<=slot;state<=R_OFFER;end
    R_OFFER:if(request_ready)state<=R_WAIT;
    R_WAIT:if(response_valid)begin
     if(response_error||!guard_context_live||stopping)begin
      valid0<=0;valid1<=0;fault<=1;aborted<=1;verified<=0;lane<=0;state<=Q_REPORT;
     end else begin
      if(miss_slot)begin cache1<=response_data;address1<=miss_address;session1<=session_id;frame1<=frame_id;epoch1<=epoch;valid1<=1;end
      else begin cache0<=response_data;address0<=miss_address;session0<=session_id;frame0<=frame_id;epoch0<=epoch;valid0<=1;end
      state<=SCAN;
     end
    end
    Q_REPORT:state<=IDLE;
    APPEND:if(stopping)begin lane<=0;assembly<=0;state<=IDLE;end
     else begin
      assembly[lane*8+:8]<=held_pixel[pixel_byte*8+:8];accepted_bytes<=accepted_bytes+1;
      if(pixel_byte!=2)pixel_byte<=pixel_byte+1;
      if(lane==31)begin lane<=0;word_ends_pixel<=pixel_byte==2;state<=W_OFFER;end
      else begin lane<=lane+1;if(pixel_byte==2)state<=IDLE;end
     end
    W_OFFER:if(request_ready)state<=W_WAIT;
    W_WAIT:if(response_valid)begin
     if(response_error||!guard_context_live||stopping)begin
      fault<=1;aborted<=1;valid0<=0;valid1<=0;lane<=0;assembly<=0;state<=IDLE;
     end else begin
      committed_bytes<=committed_bytes+32;word_address<=word_address+32;assembly<=0;
      if(word_ends_pixel)state<=IDLE;else state<=APPEND;
     end
    end
    default:begin fault<=1;aborted<=1;state<=IDLE;lane<=0;end
   endcase
  end
 end
endmodule
