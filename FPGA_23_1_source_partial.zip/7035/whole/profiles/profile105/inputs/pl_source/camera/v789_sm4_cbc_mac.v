`timescale 1ns/1ps

// Fixed-length 256-bit SM4-CBC-MAC primitive.
// Each beat is authenticated as exactly two 128-bit blocks:
//   T1 = SM4_K(P0 xor chain_in)
//   tag = SM4_K(P1 xor T1)
// For a stream, the caller feeds the previous tag as chain_in. The final tag
// is therefore a standard CBC-MAC for a fixed-size block sequence. A separate
// metadata channel must carry/store the tag; this module deliberately does not
// overload AXI WDATA/RDATA.
module v789_sm4_cbc_mac256 #(
    parameter CORE_ROUNDS_PER_CYCLE = 1
) (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,
    input  wire         start,
    input  wire [127:0] key,
    input  wire [127:0] chain_in,
    input  wire [255:0] data_in,
    output wire         busy,
    output reg          done,
    output reg [127:0]  tag_out
);

reg phase;
reg active;
reg [127:0] chain_reg;
reg [255:0] data_reg;
wire c0_busy, c1_busy, c0_done, c1_done;
wire [127:0] c0_out, c1_out;

v788_sm4_encrypt_iter #(.ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_mac0 (
    .clk(clk), .rst_n(rst_n), .start(active && !phase), .key(key),
    .block_in(data_reg[255:128] ^ chain_reg), .busy(c0_busy), .done(c0_done), .block_out(c0_out)
);
v788_sm4_encrypt_iter #(.ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_mac1 (
    .clk(clk), .rst_n(rst_n), .start(active && phase), .key(key),
    .block_in(data_reg[127:0] ^ c0_out), .busy(c1_busy), .done(c1_done), .block_out(c1_out)
);

assign busy = active;

always @(posedge clk) begin
    if (!rst_n) begin
        phase <= 1'b0; active <= 1'b0; done <= 1'b0;
        chain_reg <= 128'd0; data_reg <= 256'd0; tag_out <= 128'd0;
    end else begin
        done <= 1'b0;
        if (clear) begin
            phase <= 1'b0; active <= 1'b0; chain_reg <= 128'd0;
        end else if (start && !active) begin
            phase <= 1'b0; active <= 1'b1;
            chain_reg <= chain_in; data_reg <= data_in;
        end else if (active && !phase && c0_done) begin
            phase <= 1'b1;
        end else if (active && phase && c1_done) begin
            tag_out <= c1_out;
            active <= 1'b0;
            done <= 1'b1;
        end
    end
end
endmodule

module v789_sm4_cbc_mac_auth_check (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         clear,
    input  wire         start,
    input  wire [127:0] key,
    input  wire [127:0] chain_in,
    input  wire [255:0] data_in,
    input  wire         expected_valid,
    input  wire [127:0] expected_tag,
    output wire         busy,
    output wire         done,
    output wire [127:0] tag_out,
    output reg          auth_fail
);
wire mac_done;
v789_sm4_cbc_mac256 u_mac (
    .clk(clk), .rst_n(rst_n), .clear(clear), .start(start), .key(key),
    .chain_in(chain_in), .data_in(data_in), .busy(busy), .done(mac_done), .tag_out(tag_out)
);
assign done = mac_done;
always @(posedge clk) begin
    if (!rst_n || clear) begin
        auth_fail <= 1'b0;
    end else begin
        if (expected_valid && !busy && (tag_out != expected_tag))
            auth_fail <= (tag_out != expected_tag);
    end
end
endmodule
