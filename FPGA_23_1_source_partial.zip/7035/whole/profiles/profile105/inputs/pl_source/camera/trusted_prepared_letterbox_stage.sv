`timescale 1ns/1ps
// Consume an ALREADY committed real letterbox record as stage0. There is no
// timer/CPU done substitution. The frame tuple is single-use across retries.
module trusted_prepared_letterbox_stage(
 input wire clk,rst_n,cancel,authorized,input wire [31:0] authorization_epoch,
 input wire sealed_valid,input wire [31:0] sealed_session,sealed_frame,sealed_epoch,
 input wire stage_valid,output wire stage_ready,input wire [2:0] stage_id,
 input wire [31:0] stage_token,stage_session,stage_frame,stage_epoch,stage_base,
 output wire completion_valid,output wire completion_error,output wire quiescent,
 output reg [2:0] completion_stage,
 output reg [31:0] completion_token,completion_session,completion_frame,completion_epoch
);
 reg pending,bad,used;
 reg [31:0] last_session,last_frame,last_epoch;
 wire fresh=!used||sealed_epoch>last_epoch||(sealed_epoch==last_epoch&&
  (sealed_session>last_session||(sealed_session==last_session&&sealed_frame>last_frame)));
 wire context_matches=sealed_valid&&authorized&&sealed_epoch==authorization_epoch&&
  stage_session==sealed_session&&stage_frame==sealed_frame&&stage_epoch==sealed_epoch&&
  stage_base==32'h22000000&&stage_token!=0&&stage_session!=0&&stage_frame!=0&&fresh;
 assign stage_ready=!pending&&!cancel&&stage_id==0;
 assign completion_valid=pending&&!cancel;
 assign completion_error=bad||!authorized||!sealed_valid||authorization_epoch!=completion_epoch||
  sealed_session!=completion_session||sealed_frame!=completion_frame||sealed_epoch!=completion_epoch;
 assign quiescent=!pending;
 always @(posedge clk)begin
  if(!rst_n)begin pending<=0;bad<=0;used<=0;last_session<=0;last_frame<=0;last_epoch<=0;
   completion_stage<=0;completion_token<=0;completion_session<=0;completion_frame<=0;completion_epoch<=0;end
  else begin
   pending<=0;
   if(stage_valid&&stage_ready)begin
    pending<=1;bad<=!context_matches;completion_stage<=stage_id;completion_token<=stage_token;
    completion_session<=stage_session;completion_frame<=stage_frame;completion_epoch<=stage_epoch;
    if(context_matches)begin used<=1;last_session<=sealed_session;last_frame<=sealed_frame;last_epoch<=sealed_epoch;end
   end
  end
 end
endmodule
