`timescale 1ns/1ps
// Diagnostic frame ownership and demand scheduling. Addresses remain constants
// in the sink; the CPU can select a profile, never a DMA destination.
// Inference completion MUST come from the PL consumer, with the issued tags.
// This transport controller does not authenticate camera image contents.
module nfr_frame_coordinator(
 input wire clk,rst_n,go,stop,profile1080,pattern,repeat_frames,
 output wire go_ready,output reg active,fault,
 output wire sink_start,sink_cancel,sink_consume_done,
 input wire sink_start_ready,sink_busy,sink_ready,sink_fault,
 output wire sink_profile1080,sink_pattern,sink_display_bank,
 output reg [31:0] session_id,frame_id,
 input wire [31:0] sink_frame,sink_base,
 output wire job_valid,input wire job_ready,
 output wire [31:0] job_session,job_frame,job_base,
 input wire job_done,input wire [31:0] job_done_session,job_done_frame,
 output wire job_cancel,input wire job_quiescent,job_fault,
 output reg [31:0] rejected_completions,completed_frames,
 output reg display_enable,output reg [31:0] display_base,display_seq,
 input wire [31:0] display_ack_seq,display_active_base,
 input wire display_fault
);
 localparam IDLE=0,REQUEST=1,RECEIVE=2,DISPLAY=3,INFER=4,RELEASE=5,DRAIN=6;
 reg [2:0] state;
 reg mode1080,pattern_mode,repeat_mode,write_bank,job_accepted;
 // The sink's fault is sticky until it accepts the next start. REQUEST must
 // not reinterpret the previous cancelled frame's fault as a new failure.
 // In RECEIVE the accepted start has already cleared that sticky record.
 wire sink_fault_current=sink_fault&&(state==RECEIVE||state==DISPLAY||state==INFER||state==RELEASE);
 assign go_ready=state==IDLE&&!sink_busy&&job_quiescent;
 assign sink_start=state==REQUEST&&sink_start_ready&&!stop&&!fault;
 assign sink_cancel=stop||state==DRAIN;
 assign sink_consume_done=state==RELEASE&&!stop&&!fault&&job_quiescent;
 assign sink_profile1080=mode1080;assign sink_pattern=pattern_mode;
 assign sink_display_bank=write_bank;
 assign job_valid=state==INFER&&!job_accepted&&sink_ready&&!stop&&!fault&&!job_fault;
 // Cancellation invalidates the job immediately, but the DDR slot may not
 // be reused until every accepted consumer read/write has actually drained.
 assign job_cancel=state==DRAIN||stop||(active&&!mode1080&&(sink_fault_current||job_fault));
 assign job_session=session_id;assign job_frame=frame_id;assign job_base=sink_base;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;active<=0;fault<=0;session_id<=0;frame_id<=0;
   mode1080<=0;pattern_mode<=0;repeat_mode<=0;write_bank<=0;job_accepted<=0;
   rejected_completions<=0;completed_frames<=0;
   display_enable<=0;display_base<=32'h25000000;display_seq<=0;
  end else begin
   if(job_done&&!(state==INFER&&(job_accepted||job_valid&&job_ready)&&
      job_done_session==session_id&&job_done_frame==frame_id))
    rejected_completions<=rejected_completions+1'b1;
   case(state)
    IDLE:if(go&&go_ready&&!stop)begin
     // Exhaustion requires an explicit system reset, never silently wrap tags.
     if(session_id==32'hffffffff||frame_id==32'hffffffff)fault<=1;
     else begin
      session_id<=session_id+1'b1;frame_id<=frame_id+1'b1;
      mode1080<=profile1080;pattern_mode<=pattern;repeat_mode<=repeat_frames;
      write_bank<=display_enable?(display_active_base==32'h25000000):1'b0;
      active<=1;fault<=0;job_accepted<=0;state<=REQUEST;
     end
    end
    REQUEST:if(sink_start)state<=RECEIVE;
    RECEIVE:if(sink_ready)begin
     if(sink_frame!=frame_id)begin fault<=1;state<=DRAIN;end
     else if(mode1080)begin
      display_base<=sink_base;display_seq<=frame_id;display_enable<=1;state<=DISPLAY;
     end else begin job_accepted<=0;state<=INFER;end
    end
    DISPLAY:if(display_ack_seq==display_seq&&display_active_base==display_base)begin
     completed_frames<=completed_frames+1'b1;state<=RELEASE;
    end
    INFER:begin
     if(job_valid&&job_ready)job_accepted<=1;
     if(job_done&&(job_accepted||job_valid&&job_ready)&&
       job_done_session==session_id&&job_done_frame==frame_id)begin
      completed_frames<=completed_frames+1'b1;state<=RELEASE;
     end
    end
    RELEASE:if(!sink_busy&&job_quiescent)begin
     job_accepted<=0;
     if(repeat_mode&&frame_id!=32'hffffffff)begin
      frame_id<=frame_id+1'b1;
      write_bank<=mode1080?(display_active_base==32'h25000000):1'b0;
      state<=REQUEST;
     end else begin active<=0;state<=IDLE;if(repeat_mode)fault<=1;end
    end
    DRAIN:if(!sink_busy&&job_quiescent)begin state<=IDLE;active<=0;job_accepted<=0;end
    default:begin state<=DRAIN;fault<=1;end
   endcase
   if(active&&(sink_fault_current||(mode1080&&display_fault)||(!mode1080&&job_fault)||stop))begin
    fault<=1;state<=DRAIN;
    // Retain the last complete displayed frame; never publish the failed one.
   end
  end
 end
endmodule
