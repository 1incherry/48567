`timescale 1ns/1ps

// Iterative SM4 encryption core. One 128-bit block completes in 32 rounds.
// The byte/word ordering follows GB/T 32907 and the published SM4 vectors.
module v788_sm4_encrypt_iter #(
    parameter ROUNDS_PER_CYCLE = 1
) (
    input  wire         clk,
    input  wire         rst_n,
    input  wire         start,
    input  wire [127:0] key,
    input  wire [127:0] block_in,
    output reg          busy,
    output reg          done,
    output reg  [127:0] block_out
);

reg [5:0] round;
reg [31:0] x0, x1, x2, x3;
reg [31:0] k0, k1, k2, k3;
reg        round_data_phase;
reg [31:0] round_key_pending;
reg        round_key_cache_valid;
reg        round_key_expand_phase;
reg [127:0] round_key_cached_key;
reg [127:0] round_key_pending_block;
reg [31:0] round_key_cache [0:31];

function [7:0] sm4_sbox;
    input [7:0] a;
    begin
        case (a)
        8'h00:sm4_sbox=8'hd6; 8'h01:sm4_sbox=8'h90; 8'h02:sm4_sbox=8'he9; 8'h03:sm4_sbox=8'hfe;
        8'h04:sm4_sbox=8'hcc; 8'h05:sm4_sbox=8'he1; 8'h06:sm4_sbox=8'h3d; 8'h07:sm4_sbox=8'hb7;
        8'h08:sm4_sbox=8'h16; 8'h09:sm4_sbox=8'hb6; 8'h0a:sm4_sbox=8'h14; 8'h0b:sm4_sbox=8'hc2;
        8'h0c:sm4_sbox=8'h28; 8'h0d:sm4_sbox=8'hfb; 8'h0e:sm4_sbox=8'h2c; 8'h0f:sm4_sbox=8'h05;
        8'h10:sm4_sbox=8'h2b; 8'h11:sm4_sbox=8'h67; 8'h12:sm4_sbox=8'h9a; 8'h13:sm4_sbox=8'h76;
        8'h14:sm4_sbox=8'h2a; 8'h15:sm4_sbox=8'hbe; 8'h16:sm4_sbox=8'h04; 8'h17:sm4_sbox=8'hc3;
        8'h18:sm4_sbox=8'haa; 8'h19:sm4_sbox=8'h44; 8'h1a:sm4_sbox=8'h13; 8'h1b:sm4_sbox=8'h26;
        8'h1c:sm4_sbox=8'h49; 8'h1d:sm4_sbox=8'h86; 8'h1e:sm4_sbox=8'h06; 8'h1f:sm4_sbox=8'h99;
        8'h20:sm4_sbox=8'h9c; 8'h21:sm4_sbox=8'h42; 8'h22:sm4_sbox=8'h50; 8'h23:sm4_sbox=8'hf4;
        8'h24:sm4_sbox=8'h91; 8'h25:sm4_sbox=8'hef; 8'h26:sm4_sbox=8'h98; 8'h27:sm4_sbox=8'h7a;
        8'h28:sm4_sbox=8'h33; 8'h29:sm4_sbox=8'h54; 8'h2a:sm4_sbox=8'h0b; 8'h2b:sm4_sbox=8'h43;
        8'h2c:sm4_sbox=8'hed; 8'h2d:sm4_sbox=8'hcf; 8'h2e:sm4_sbox=8'hac; 8'h2f:sm4_sbox=8'h62;
        8'h30:sm4_sbox=8'he4; 8'h31:sm4_sbox=8'hb3; 8'h32:sm4_sbox=8'h1c; 8'h33:sm4_sbox=8'ha9;
        8'h34:sm4_sbox=8'hc9; 8'h35:sm4_sbox=8'h08; 8'h36:sm4_sbox=8'he8; 8'h37:sm4_sbox=8'h95;
        8'h38:sm4_sbox=8'h80; 8'h39:sm4_sbox=8'hdf; 8'h3a:sm4_sbox=8'h94; 8'h3b:sm4_sbox=8'hfa;
        8'h3c:sm4_sbox=8'h75; 8'h3d:sm4_sbox=8'h8f; 8'h3e:sm4_sbox=8'h3f; 8'h3f:sm4_sbox=8'ha6;
        8'h40:sm4_sbox=8'h47; 8'h41:sm4_sbox=8'h07; 8'h42:sm4_sbox=8'ha7; 8'h43:sm4_sbox=8'hfc;
        8'h44:sm4_sbox=8'hf3; 8'h45:sm4_sbox=8'h73; 8'h46:sm4_sbox=8'h17; 8'h47:sm4_sbox=8'hba;
        8'h48:sm4_sbox=8'h83; 8'h49:sm4_sbox=8'h59; 8'h4a:sm4_sbox=8'h3c; 8'h4b:sm4_sbox=8'h19;
        8'h4c:sm4_sbox=8'he6; 8'h4d:sm4_sbox=8'h85; 8'h4e:sm4_sbox=8'h4f; 8'h4f:sm4_sbox=8'ha8;
        8'h50:sm4_sbox=8'h68; 8'h51:sm4_sbox=8'h6b; 8'h52:sm4_sbox=8'h81; 8'h53:sm4_sbox=8'hb2;
        8'h54:sm4_sbox=8'h71; 8'h55:sm4_sbox=8'h64; 8'h56:sm4_sbox=8'hda; 8'h57:sm4_sbox=8'h8b;
        8'h58:sm4_sbox=8'hf8; 8'h59:sm4_sbox=8'heb; 8'h5a:sm4_sbox=8'h0f; 8'h5b:sm4_sbox=8'h4b;
        8'h5c:sm4_sbox=8'h70; 8'h5d:sm4_sbox=8'h56; 8'h5e:sm4_sbox=8'h9d; 8'h5f:sm4_sbox=8'h35;
        8'h60:sm4_sbox=8'h1e; 8'h61:sm4_sbox=8'h24; 8'h62:sm4_sbox=8'h0e; 8'h63:sm4_sbox=8'h5e;
        8'h64:sm4_sbox=8'h63; 8'h65:sm4_sbox=8'h58; 8'h66:sm4_sbox=8'hd1; 8'h67:sm4_sbox=8'ha2;
        8'h68:sm4_sbox=8'h25; 8'h69:sm4_sbox=8'h22; 8'h6a:sm4_sbox=8'h7c; 8'h6b:sm4_sbox=8'h3b;
        8'h6c:sm4_sbox=8'h01; 8'h6d:sm4_sbox=8'h21; 8'h6e:sm4_sbox=8'h78; 8'h6f:sm4_sbox=8'h87;
        8'h70:sm4_sbox=8'hd4; 8'h71:sm4_sbox=8'h00; 8'h72:sm4_sbox=8'h46; 8'h73:sm4_sbox=8'h57;
        8'h74:sm4_sbox=8'h9f; 8'h75:sm4_sbox=8'hd3; 8'h76:sm4_sbox=8'h27; 8'h77:sm4_sbox=8'h52;
        8'h78:sm4_sbox=8'h4c; 8'h79:sm4_sbox=8'h36; 8'h7a:sm4_sbox=8'h02; 8'h7b:sm4_sbox=8'he7;
        8'h7c:sm4_sbox=8'ha0; 8'h7d:sm4_sbox=8'hc4; 8'h7e:sm4_sbox=8'hc8; 8'h7f:sm4_sbox=8'h9e;
        8'h80:sm4_sbox=8'hea; 8'h81:sm4_sbox=8'hbf; 8'h82:sm4_sbox=8'h8a; 8'h83:sm4_sbox=8'hd2;
        8'h84:sm4_sbox=8'h40; 8'h85:sm4_sbox=8'hc7; 8'h86:sm4_sbox=8'h38; 8'h87:sm4_sbox=8'hb5;
        8'h88:sm4_sbox=8'ha3; 8'h89:sm4_sbox=8'hf7; 8'h8a:sm4_sbox=8'hf2; 8'h8b:sm4_sbox=8'hce;
        8'h8c:sm4_sbox=8'hf9; 8'h8d:sm4_sbox=8'h61; 8'h8e:sm4_sbox=8'h15; 8'h8f:sm4_sbox=8'ha1;
        8'h90:sm4_sbox=8'he0; 8'h91:sm4_sbox=8'hae; 8'h92:sm4_sbox=8'h5d; 8'h93:sm4_sbox=8'ha4;
        8'h94:sm4_sbox=8'h9b; 8'h95:sm4_sbox=8'h34; 8'h96:sm4_sbox=8'h1a; 8'h97:sm4_sbox=8'h55;
        8'h98:sm4_sbox=8'had; 8'h99:sm4_sbox=8'h93; 8'h9a:sm4_sbox=8'h32; 8'h9b:sm4_sbox=8'h30;
        8'h9c:sm4_sbox=8'hf5; 8'h9d:sm4_sbox=8'h8c; 8'h9e:sm4_sbox=8'hb1; 8'h9f:sm4_sbox=8'he3;
        8'ha0:sm4_sbox=8'h1d; 8'ha1:sm4_sbox=8'hf6; 8'ha2:sm4_sbox=8'he2; 8'ha3:sm4_sbox=8'h2e;
        8'ha4:sm4_sbox=8'h82; 8'ha5:sm4_sbox=8'h66; 8'ha6:sm4_sbox=8'hca; 8'ha7:sm4_sbox=8'h60;
        8'ha8:sm4_sbox=8'hc0; 8'ha9:sm4_sbox=8'h29; 8'haa:sm4_sbox=8'h23; 8'hab:sm4_sbox=8'hab;
        8'hac:sm4_sbox=8'h0d; 8'had:sm4_sbox=8'h53; 8'hae:sm4_sbox=8'h4e; 8'haf:sm4_sbox=8'h6f;
        8'hb0:sm4_sbox=8'hd5; 8'hb1:sm4_sbox=8'hdb; 8'hb2:sm4_sbox=8'h37; 8'hb3:sm4_sbox=8'h45;
        8'hb4:sm4_sbox=8'hde; 8'hb5:sm4_sbox=8'hfd; 8'hb6:sm4_sbox=8'h8e; 8'hb7:sm4_sbox=8'h2f;
        8'hb8:sm4_sbox=8'h03; 8'hb9:sm4_sbox=8'hff; 8'hba:sm4_sbox=8'h6a; 8'hbb:sm4_sbox=8'h72;
        8'hbc:sm4_sbox=8'h6d; 8'hbd:sm4_sbox=8'h6c; 8'hbe:sm4_sbox=8'h5b; 8'hbf:sm4_sbox=8'h51;
        8'hc0:sm4_sbox=8'h8d; 8'hc1:sm4_sbox=8'h1b; 8'hc2:sm4_sbox=8'haf; 8'hc3:sm4_sbox=8'h92;
        8'hc4:sm4_sbox=8'hbb; 8'hc5:sm4_sbox=8'hdd; 8'hc6:sm4_sbox=8'hbc; 8'hc7:sm4_sbox=8'h7f;
        8'hc8:sm4_sbox=8'h11; 8'hc9:sm4_sbox=8'hd9; 8'hca:sm4_sbox=8'h5c; 8'hcb:sm4_sbox=8'h41;
        8'hcc:sm4_sbox=8'h1f; 8'hcd:sm4_sbox=8'h10; 8'hce:sm4_sbox=8'h5a; 8'hcf:sm4_sbox=8'hd8;
        8'hd0:sm4_sbox=8'h0a; 8'hd1:sm4_sbox=8'hc1; 8'hd2:sm4_sbox=8'h31; 8'hd3:sm4_sbox=8'h88;
        8'hd4:sm4_sbox=8'ha5; 8'hd5:sm4_sbox=8'hcd; 8'hd6:sm4_sbox=8'h7b; 8'hd7:sm4_sbox=8'hbd;
        8'hd8:sm4_sbox=8'h2d; 8'hd9:sm4_sbox=8'h74; 8'hda:sm4_sbox=8'hd0; 8'hdb:sm4_sbox=8'h12;
        8'hdc:sm4_sbox=8'hb8; 8'hdd:sm4_sbox=8'he5; 8'hde:sm4_sbox=8'hb4; 8'hdf:sm4_sbox=8'hb0;
        8'he0:sm4_sbox=8'h89; 8'he1:sm4_sbox=8'h69; 8'he2:sm4_sbox=8'h97; 8'he3:sm4_sbox=8'h4a;
        8'he4:sm4_sbox=8'h0c; 8'he5:sm4_sbox=8'h96; 8'he6:sm4_sbox=8'h77; 8'he7:sm4_sbox=8'h7e;
        8'he8:sm4_sbox=8'h65; 8'he9:sm4_sbox=8'hb9; 8'hea:sm4_sbox=8'hf1; 8'heb:sm4_sbox=8'h09;
        8'hec:sm4_sbox=8'hc5; 8'hed:sm4_sbox=8'h6e; 8'hee:sm4_sbox=8'hc6; 8'hef:sm4_sbox=8'h84;
        8'hf0:sm4_sbox=8'h18; 8'hf1:sm4_sbox=8'hf0; 8'hf2:sm4_sbox=8'h7d; 8'hf3:sm4_sbox=8'hec;
        8'hf4:sm4_sbox=8'h3a; 8'hf5:sm4_sbox=8'hdc; 8'hf6:sm4_sbox=8'h4d; 8'hf7:sm4_sbox=8'h20;
        8'hf8:sm4_sbox=8'h79; 8'hf9:sm4_sbox=8'hee; 8'hfa:sm4_sbox=8'h5f; 8'hfb:sm4_sbox=8'h3e;
        8'hfc:sm4_sbox=8'hd7; 8'hfd:sm4_sbox=8'hcb; 8'hfe:sm4_sbox=8'h39; default:sm4_sbox=8'h48;
        endcase
    end
endfunction

function [31:0] rol32;
    input [31:0] a;
    input [4:0] n;
    begin rol32 = (a << n) | (a >> (32-n)); end
endfunction

function [31:0] tau;
    input [31:0] a;
    begin tau = {sm4_sbox(a[31:24]), sm4_sbox(a[23:16]), sm4_sbox(a[15:8]), sm4_sbox(a[7:0])}; end
endfunction

function [31:0] linear_t;
    input [31:0] a;
    reg [31:0] b;
    begin b=tau(a); linear_t=b ^ rol32(b,2) ^ rol32(b,10) ^ rol32(b,18) ^ rol32(b,24); end
endfunction

function [31:0] linear_key;
    input [31:0] a;
    reg [31:0] b;
    begin b=tau(a); linear_key=b ^ rol32(b,13) ^ rol32(b,23); end
endfunction

function [31:0] ck;
    input [4:0] r;
    begin
        case (r)
         0:ck=32'h00070e15;  1:ck=32'h1c232a31;  2:ck=32'h383f464d;  3:ck=32'h545b6269;
         4:ck=32'h70777e85;  5:ck=32'h8c939aa1;  6:ck=32'ha8afb6bd;  7:ck=32'hc4cbd2d9;
         8:ck=32'he0e7eef5;  9:ck=32'hfc030a11; 10:ck=32'h181f262d; 11:ck=32'h343b4249;
        12:ck=32'h50575e65; 13:ck=32'h6c737a81; 14:ck=32'h888f969d; 15:ck=32'ha4abb2b9;
        16:ck=32'hc0c7ced5; 17:ck=32'hdce3eaf1; 18:ck=32'hf8ff060d; 19:ck=32'h141b2229;
        20:ck=32'h30373e45; 21:ck=32'h4c535a61; 22:ck=32'h686f767d; 23:ck=32'h848b9299;
        24:ck=32'ha0a7aeb5; 25:ck=32'hbcc3cad1; 26:ck=32'hd8dfe6ed; 27:ck=32'hf4fb0209;
        28:ck=32'h10171e25; 29:ck=32'h2c333a41; 30:ck=32'h484f565d; default:ck=32'h646b7279;
        endcase
    end
endfunction

wire [31:0] rk_next = k0 ^ linear_key(k1 ^ k2 ^ k3 ^ ck(round[4:0]));
wire [31:0] x_next = x0 ^ linear_t(x1 ^ x2 ^ x3 ^ rk_next);
wire [31:0] x_next_pending =
    x0 ^ linear_t(x1 ^ x2 ^ x3 ^ round_key_pending);

// Four-round combinational expansion used only by the V876 fast load-MAC
// experiment.  The state equations are exactly four consecutive applications
// of the one-round recurrence above; the default core remains one round/cycle.
wire [5:0] round_p1 = round + 6'd1;
wire [5:0] round_p2 = round + 6'd2;
wire [5:0] round_p3 = round + 6'd3;
// Two-round expansion used by the authenticated load MAC.  The previous
// four-round expansion placed four complete S-box layers on one routed path;
// two rounds preserve useful MAC throughput while halving that logic depth.
wire [31:0] rk_2r_0 = rk_next;
wire [31:0] x_2r_0  = x_next;
wire [31:0] rk_2r_1 = k1 ^ linear_key(k2 ^ k3 ^ rk_2r_0 ^ ck(round_p1[4:0]));
wire [31:0] x_2r_1  = x1 ^ linear_t(x2 ^ x3 ^ x_2r_0 ^ rk_2r_1);
// V896/V900 cached-key datapaths.  Tensor streams reuse one key for many
// blocks, so expand the 32 round keys only when the key changes.  The hot data
// paths then contain only data rounds instead of interleaved key and data
// expansions.  The 1024-bit key cache maps naturally to FF/LUTRAM, not BRAM.
wire [31:0] rk_cache_2r_0 = round_key_cache[round[4:0]];
wire [31:0] rk_cache_2r_1 = round_key_cache[round_p1[4:0]];
wire [31:0] x_cache_2r_0 = x0 ^ linear_t(x1 ^ x2 ^ x3 ^ rk_cache_2r_0);
wire [31:0] x_cache_2r_1 = x1 ^ linear_t(x2 ^ x3 ^ x_cache_2r_0 ^ rk_cache_2r_1);
wire [31:0] rk_cache_4r_0 = round_key_cache[round[4:0]];
wire [31:0] rk_cache_4r_1 = round_key_cache[round_p1[4:0]];
wire [31:0] rk_cache_4r_2 = round_key_cache[round_p2[4:0]];
wire [31:0] rk_cache_4r_3 = round_key_cache[round_p3[4:0]];
wire [31:0] x_cache_4r_0 = x0 ^ linear_t(x1 ^ x2 ^ x3 ^ rk_cache_4r_0);
wire [31:0] x_cache_4r_1 = x1 ^ linear_t(x2 ^ x3 ^ x_cache_4r_0 ^ rk_cache_4r_1);
wire [31:0] x_cache_4r_2 = x2 ^ linear_t(x3 ^ x_cache_4r_0 ^ x_cache_4r_1 ^ rk_cache_4r_2);
wire [31:0] x_cache_4r_3 = x3 ^ linear_t(x_cache_4r_0 ^ x_cache_4r_1 ^ x_cache_4r_2 ^ rk_cache_4r_3);
wire [31:0] rk_4r_0 = rk_next;
wire [31:0] x_4r_0  = x_next;
wire [31:0] rk_4r_1 = k1 ^ linear_key(k2 ^ k3 ^ rk_4r_0 ^ ck(round_p1[4:0]));
wire [31:0] x_4r_1  = x1 ^ linear_t(x2 ^ x3 ^ x_4r_0 ^ rk_4r_1);
wire [31:0] rk_4r_2 = k2 ^ linear_key(k3 ^ rk_4r_0 ^ rk_4r_1 ^ ck(round_p2[4:0]));
wire [31:0] x_4r_2  = x2 ^ linear_t(x3 ^ x_4r_0 ^ x_4r_1 ^ rk_4r_2);
wire [31:0] rk_4r_3 = k3 ^ linear_key(rk_4r_0 ^ rk_4r_1 ^ rk_4r_2 ^ ck(round_p3[4:0]));
wire [31:0] x_4r_3  = x3 ^ linear_t(x_4r_0 ^ x_4r_1 ^ x_4r_2 ^ rk_4r_3);

always @(posedge clk) begin
    if (!rst_n) begin
        round <= 6'd0; busy <= 1'b0; done <= 1'b0; block_out <= 128'd0;
        x0<=0; x1<=0; x2<=0; x3<=0; k0<=0; k1<=0; k2<=0; k3<=0;
        round_data_phase <= 1'b0;
        round_key_pending <= 32'd0;
        round_key_cache_valid <= 1'b0;
        round_key_expand_phase <= 1'b0;
        round_key_cached_key <= 128'd0;
        round_key_pending_block <= 128'd0;
    end else begin
        done <= 1'b0;
        if (start && !busy) begin
            round <= 6'd0;
            busy <= 1'b1;
            round_data_phase <= 1'b0;
            if (ROUNDS_PER_CYCLE == 2 || ROUNDS_PER_CYCLE == 4) begin
                round_key_pending_block <= block_in;
                if (!round_key_cache_valid || round_key_cached_key != key) begin
                    k0 <= key[127:96] ^ 32'ha3b1bac6;
                    k1 <= key[95:64]  ^ 32'h56aa3350;
                    k2 <= key[63:32]  ^ 32'h677d9197;
                    k3 <= key[31:0]   ^ 32'hb27022dc;
                    round_key_cached_key <= key;
                    round_key_cache_valid <= 1'b0;
                    round_key_expand_phase <= 1'b1;
                end else begin
                    x0 <= block_in[127:96]; x1 <= block_in[95:64];
                    x2 <= block_in[63:32];  x3 <= block_in[31:0];
                    round_key_expand_phase <= 1'b0;
                end
            end else begin
                x0 <= block_in[127:96]; x1 <= block_in[95:64];
                x2 <= block_in[63:32];  x3 <= block_in[31:0];
                k0 <= key[127:96] ^ 32'ha3b1bac6;
                k1 <= key[95:64]  ^ 32'h56aa3350;
                k2 <= key[63:32]  ^ 32'h677d9197;
                k3 <= key[31:0]   ^ 32'hb27022dc;
                round_key_expand_phase <= 1'b0;
            end
        end else if (busy) begin
            if (ROUNDS_PER_CYCLE == 4) begin
                if (round_key_expand_phase) begin
                    round_key_cache[round[4:0]] <= rk_next;
                    k0 <= k1; k1 <= k2; k2 <= k3; k3 <= rk_next;
                    if (round == 6'd31) begin
                        round_key_cache_valid <= 1'b1;
                        round_key_expand_phase <= 1'b0;
                        x0 <= round_key_pending_block[127:96];
                        x1 <= round_key_pending_block[95:64];
                        x2 <= round_key_pending_block[63:32];
                        x3 <= round_key_pending_block[31:0];
                        round <= 6'd0;
                    end else begin
                        round <= round + 1'b1;
                    end
                end else begin
                    x0 <= x_cache_4r_0; x1 <= x_cache_4r_1;
                    x2 <= x_cache_4r_2; x3 <= x_cache_4r_3;
                    if (round == 6'd28) begin
                        block_out <= {x_cache_4r_3, x_cache_4r_2,
                                      x_cache_4r_1, x_cache_4r_0};
                        busy <= 1'b0;
                        done <= 1'b1;
                    end else begin
                        round <= round + 6'd4;
                    end
                end
            end else if (ROUNDS_PER_CYCLE == 2) begin
                if (round_key_expand_phase) begin
                    round_key_cache[round[4:0]] <= rk_next;
                    k0 <= k1; k1 <= k2; k2 <= k3; k3 <= rk_next;
                    if (round == 6'd31) begin
                        round_key_cache_valid <= 1'b1;
                        round_key_expand_phase <= 1'b0;
                        x0 <= round_key_pending_block[127:96];
                        x1 <= round_key_pending_block[95:64];
                        x2 <= round_key_pending_block[63:32];
                        x3 <= round_key_pending_block[31:0];
                        round <= 6'd0;
                    end else begin
                        round <= round + 1'b1;
                    end
                end else begin
                    x0 <= x2;            x1 <= x3;
                    x2 <= x_cache_2r_0;  x3 <= x_cache_2r_1;
                    if (round == 6'd30) begin
                        block_out <= {x_cache_2r_1, x_cache_2r_0, x3, x2};
                        busy <= 1'b0;
                        done <= 1'b1;
                    end else begin
                        round <= round + 6'd2;
                    end
                end
            end else begin
                // One-round mode is split into key-schedule and data-round
                // phases.  The previous implementation placed two complete
                // S-box/linear layers in one cycle (k -> rk_next -> x_next),
                // which dominated the routed SecureRead/MAC paths.  The extra
                // cycle per round is small relative to the protected NPU
                // workload and makes each phase independently pipelineable.
                if (!round_data_phase) begin
                    k0 <= k1; k1 <= k2; k2 <= k3; k3 <= rk_next;
                    round_key_pending <= rk_next;
                    round_data_phase <= 1'b1;
                end else begin
                    x0 <= x1; x1 <= x2; x2 <= x3; x3 <= x_next_pending;
                    round_data_phase <= 1'b0;
                    if (round == 6'd31) begin
                        block_out <= {x_next_pending, x3, x2, x1};
                        busy <= 1'b0;
                        done <= 1'b1;
                    end else begin
                        round <= round + 1'b1;
                    end
                end
            end
        end
    end
end

endmodule

// 256-bit AXI-stream-compatible SM4-CTR boundary. Two iterative SM4 cores
// process the two 128-bit halves in parallel. Counter blocks are derived from
// nonce || byte_address[31:4], making reads independently seekable.
module v788_secure_stream_sm4_ctr #(
    parameter DATA_WIDTH = 256,
    parameter KEEP_WIDTH = DATA_WIDTH/8,
    parameter CORE_ROUNDS_PER_CYCLE = 1
) (
    input  wire                  clk,
    input  wire                  rst_n,
    input  wire                  clear,
    input  wire                  crypto_enable,
    input  wire [127:0]          crypto_key,
    input  wire [95:0]           crypto_nonce,
    input  wire                  cmd_fire,
    input  wire [31:0]           cmd_addr,
    input  wire                  s_valid,
    output wire                  s_ready,
    input  wire [DATA_WIDTH-1:0] s_data,
    input  wire [KEEP_WIDTH-1:0] s_keep,
    input  wire                  s_last,
    output wire                  m_valid,
    input  wire                  m_ready,
    output wire [DATA_WIDTH-1:0] m_data,
    output wire [KEEP_WIDTH-1:0] m_keep,
    output wire                  m_last,
    output reg  [31:0]           stat_beats,
    output reg  [31:0]           stat_stall_cycles
);

reg [127:0] ctr_reg;
reg [255:0] payload_reg;
reg [KEEP_WIDTH-1:0] keep_reg;
reg last_reg;
reg pending;
reg out_valid_reg;
reg [255:0] out_data_reg;
wire encrypted_active = crypto_enable || pending || out_valid_reg;
wire encrypted_accept = crypto_enable && s_valid && s_ready;
wire [127:0] cmd_counter = {crypto_nonce, 4'b0000, cmd_addr[31:4]};
wire [127:0] accept_counter = cmd_fire ? cmd_counter : ctr_reg;

wire core0_busy, core1_busy, core0_done, core1_done;
wire [127:0] ks0, ks1;
wire [255:0] keystream = {ks1, ks0};
v788_sm4_encrypt_iter #(.ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_sm4_lo (
    .clk(clk), .rst_n(rst_n), .start(encrypted_accept), .key(crypto_key),
    .block_in(accept_counter), .busy(core0_busy), .done(core0_done), .block_out(ks0)
);
v788_sm4_encrypt_iter #(.ROUNDS_PER_CYCLE(CORE_ROUNDS_PER_CYCLE)) u_sm4_hi (
    .clk(clk), .rst_n(rst_n), .start(encrypted_accept), .key(crypto_key),
    .block_in(accept_counter + 128'd1), .busy(core1_busy), .done(core1_done), .block_out(ks1)
);

assign s_ready = encrypted_active ? (!pending && !out_valid_reg && !core0_busy && !core1_busy) : m_ready;
assign m_valid = encrypted_active ? out_valid_reg : s_valid;
assign m_data  = encrypted_active ? out_data_reg : s_data;
assign m_keep  = encrypted_active ? keep_reg : s_keep;
assign m_last  = encrypted_active ? last_reg : s_last;

integer bi;
reg [255:0] masked_xor;
always @* begin
    masked_xor = payload_reg;
    for (bi = 0; bi < KEEP_WIDTH; bi = bi + 1)
        if (keep_reg[bi])
            masked_xor[bi*8 +: 8] = payload_reg[bi*8 +: 8] ^ keystream[bi*8 +: 8];
end

always @(posedge clk) begin
    if (!rst_n) begin
        ctr_reg <= 128'd0; payload_reg <= 256'd0; keep_reg <= 0; last_reg <= 1'b0;
        pending <= 1'b0; out_valid_reg <= 1'b0; out_data_reg <= 256'd0;
        stat_beats <= 32'd0; stat_stall_cycles <= 32'd0;
    end else begin
        if (clear) begin
            ctr_reg <= 128'd0; pending <= 1'b0; out_valid_reg <= 1'b0;
            stat_beats <= 32'd0; stat_stall_cycles <= 32'd0;
        end else begin
            if (cmd_fire)
                ctr_reg <= cmd_counter;
            if (encrypted_accept) begin
                payload_reg <= s_data;
                keep_reg <= s_keep;
                last_reg <= s_last;
                pending <= 1'b1;
                ctr_reg <= accept_counter + 128'd2;
            end
            if (pending && core0_done && core1_done) begin
                out_data_reg <= masked_xor;
                pending <= 1'b0;
                out_valid_reg <= 1'b1;
            end
            if (out_valid_reg && m_ready)
                out_valid_reg <= 1'b0;
            if (s_valid && s_ready)
                stat_beats <= stat_beats + 1'b1;
            if (s_valid && !s_ready)
                stat_stall_cycles <= stat_stall_cycles + 1'b1;
        end
    end
end

endmodule
