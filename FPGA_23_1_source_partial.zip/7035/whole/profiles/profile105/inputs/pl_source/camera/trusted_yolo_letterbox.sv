`timescale 1ns/1ps
// Exact specialization of yd_letterbox for 640x480 -> 320x320.
// Interior is 320x240: each output is (four RGB samples + 2) >> 2,
// identical to the reference Q11 interpolation. Top/bottom 40 rows are 114.
// No image RAM is allocated here; the existing trusted DMA/cache gathers each
// 2x2 quad, and packs outgoing byte triples into full AXI bursts.
module trusted_yolo_letterbox(
 input wire clk,rst_n,start,cancel,authorized,
 input wire [31:0] session_id,frame_id,epoch,authorization_epoch,
 output wire ready,busy,quiescent,
 output wire read_valid,input wire read_ready,
 output wire [31:0] read_source_address,
 output wire [16:0] read_pixel_index,
 input wire response_valid,response_verified,
 input wire [16:0] response_pixel_index,
 input wire [31:0] response_session,response_frame,response_epoch,
 // Four RGB24 little-endian byte triples: p00,p01,p10,p11.
 input wire [95:0] response_quad,
 output wire pixel_valid,input wire pixel_ready,
 output wire [31:0] pixel_address,output wire [23:0] pixel_data,
 input wire memory_quiescent,write_error,
 output reg done,failed,
 output reg [31:0] result_session,result_frame,result_epoch
);
 localparam IDLE=0,NEXT_PIXEL=1,REQUEST=2,RESPONSE=3,OFFER=4,DRAIN=5,FINISH=6;
 reg [2:0] state;
 reg [8:0] x,y;
 reg [16:0] index;
 reg [23:0] held_pixel;
 reg abort_pending;
 wire revoked=!authorized||authorization_epoch!=result_epoch;
 wire stopping=cancel||revoked||abort_pending||write_error;
 assign ready=state==IDLE&&memory_quiescent&&authorized&&!cancel;
 assign busy=state!=IDLE;
 assign quiescent=state==IDLE&&memory_quiescent;
 assign read_valid=state==REQUEST;
 assign read_source_address=32'h22000000+(y-9'd40)*32'd3840+x*32'd6;
 assign read_pixel_index=index;
 assign pixel_valid=state==OFFER;
 assign pixel_address=32'h21000000+index*32'd3;
 assign pixel_data=held_pixel;
 function [7:0] average;
  input [7:0] a,b,c,d;
  reg [9:0] sum;
  begin sum={2'b0,a}+{2'b0,b}+{2'b0,c}+{2'b0,d}+10'd2;average=sum[9:2];end
 endfunction
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;x<=0;y<=0;index<=0;held_pixel<=0;
   result_session<=0;result_frame<=0;result_epoch<=0;
   abort_pending<=0;done<=0;failed<=0;
  end else begin
   done<=0;failed<=0;
   if(state!=IDLE&&(cancel||revoked||write_error))abort_pending<=1;
   case(state)
    IDLE:if(start&&ready)begin
     result_session<=session_id;result_frame<=frame_id;result_epoch<=epoch;
     x<=0;y<=0;index<=0;abort_pending<=0;
     if(!session_id||!frame_id||epoch!=authorization_epoch)state<=DRAIN;
     else state<=NEXT_PIXEL;
    end
    NEXT_PIXEL:if(stopping)state<=DRAIN;
     else if(y<40||y>=280)begin held_pixel<=24'h727272;state<=OFFER;end
     else state<=REQUEST;
    REQUEST:if(read_ready)state<=RESPONSE;
    RESPONSE:if(response_valid)begin
     if(!response_verified||response_pixel_index!=index||response_session!=result_session||
        response_frame!=result_frame||response_epoch!=result_epoch||stopping)state<=DRAIN;
     else begin
      held_pixel[7:0]<=average(response_quad[7:0],response_quad[31:24],response_quad[55:48],response_quad[79:72]);
      held_pixel[15:8]<=average(response_quad[15:8],response_quad[39:32],response_quad[63:56],response_quad[87:80]);
      held_pixel[23:16]<=average(response_quad[23:16],response_quad[47:40],response_quad[71:64],response_quad[95:88]);
      state<=OFFER;
     end
    end
    OFFER:if(pixel_ready)begin
     if(stopping)state<=DRAIN;
     else if(index==102399)state<=FINISH;
     else begin
      index<=index+1;
      if(x==319)begin x<=0;y<=y+1;end else x<=x+1;
      state<=NEXT_PIXEL;
     end
    end
    FINISH:if(stopping)state<=DRAIN;
     else if(memory_quiescent)begin done<=1;state<=IDLE;end
    DRAIN:if(memory_quiescent)begin failed<=1;state<=IDLE;end
    default:state<=DRAIN;
   endcase
  end
 end
endmodule
