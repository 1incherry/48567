`timescale 1ns/1ps
// One guard request -> actual data+metadata AXI transactions. Data and metadata
// occupy separate32-byte beats. Metadata={96'b0,mask32,tag128}. A write only
// reports completion after BOTH data B and metadata B; crash/partial commit
// subsequently fails MAC rather than releasing unauthenticated data.
// No cancel input: every accepted AXI request is drained to real RLAST/B.
module trusted_tensor_axi_backend(
 input wire clk,rst_n,
 input wire read_valid,output wire read_ready,input wire write_valid,output wire write_ready,
 input wire [31:0] data_address,tag_address,input wire [255:0] write_data,
 input wire [127:0] write_tag,input wire [31:0] write_mask,
 output wire response_valid,output wire response_error,
 output reg [255:0] response_data,output reg [127:0] response_tag,output reg [31:0] response_mask,
 output wire quiescent,
 output wire [31:0] M_AXI_ARADDR,output wire [7:0] M_AXI_ARLEN,output wire [2:0] M_AXI_ARSIZE,output wire [1:0] M_AXI_ARBURST,
 output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,input wire [255:0] M_AXI_RDATA,input wire [1:0] M_AXI_RRESP,input wire M_AXI_RLAST,M_AXI_RVALID,output wire M_AXI_RREADY,
 output wire [31:0] M_AXI_AWADDR,output wire [7:0] M_AXI_AWLEN,output wire [2:0] M_AXI_AWSIZE,output wire [1:0] M_AXI_AWBURST,
 output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,output wire [255:0] M_AXI_WDATA,output wire [31:0] M_AXI_WSTRB,
 output wire M_AXI_WLAST,M_AXI_WVALID,input wire M_AXI_WREADY,input wire [1:0] M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY
);
 localparam IDLE=0,R_DATA_ADDR=1,R_DATA=2,R_TAG_ADDR=3,R_TAG=4,W_DATA=5,W_DATA_B=6,W_TAG=7,W_TAG_B=8,REPORT=9;
 reg [3:0] state;reg bad,aw_sent,w_sent,r_extra;
 reg [31:0] saved_data_address,saved_tag_address;reg [255:0] saved_data,saved_metadata;
 assign read_ready=state==IDLE&&!write_valid;
 assign write_ready=state==IDLE;
 assign response_valid=state==REPORT;
 assign response_error=bad;
 assign quiescent=state==IDLE&&!M_AXI_RVALID&&!M_AXI_BVALID;
 assign M_AXI_ARADDR=state==R_DATA_ADDR?saved_data_address:saved_tag_address;
 assign M_AXI_ARLEN=0;assign M_AXI_ARSIZE=5;assign M_AXI_ARBURST=1;
 assign M_AXI_ARVALID=state==R_DATA_ADDR||state==R_TAG_ADDR;
 assign M_AXI_RREADY=state==R_DATA||state==R_TAG;
 assign M_AXI_AWADDR=state==W_DATA?saved_data_address:saved_tag_address;
 assign M_AXI_AWLEN=0;assign M_AXI_AWSIZE=5;assign M_AXI_AWBURST=1;
 assign M_AXI_AWVALID=(state==W_DATA||state==W_TAG)&&!aw_sent;
 assign M_AXI_WDATA=state==W_DATA?saved_data:saved_metadata;
 assign M_AXI_WSTRB=32'hffffffff;assign M_AXI_WLAST=1;
 assign M_AXI_WVALID=(state==W_DATA||state==W_TAG)&&!w_sent;
 assign M_AXI_BREADY=state==W_DATA_B||state==W_TAG_B;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;bad<=0;aw_sent<=0;w_sent<=0;r_extra<=0;saved_data_address<=0;saved_tag_address<=0;saved_data<=0;saved_metadata<=0;
   response_data<=0;response_tag<=0;response_mask<=0;
  end else case(state)
   IDLE:if((read_valid&&read_ready)||(write_valid&&write_ready))begin
    saved_data_address<=data_address;saved_tag_address<=tag_address;saved_data<=write_data;saved_metadata<={96'd0,write_mask,write_tag};
    response_data<=0;response_tag<=0;response_mask<=0;bad<=0;aw_sent<=0;w_sent<=0;r_extra<=0;
    if(data_address[4:0]!=0||tag_address[4:0]!=0||data_address==tag_address)begin bad<=1;state<=REPORT;end
    else state<=write_valid?W_DATA:R_DATA_ADDR;
   end
   R_DATA_ADDR:if(M_AXI_ARREADY)begin r_extra<=0;state<=R_DATA;end
   R_DATA:if(M_AXI_RVALID)begin
    if(M_AXI_RRESP!=0||!M_AXI_RLAST||r_extra)bad<=1;
    if(!r_extra)response_data<=M_AXI_RDATA;
    if(M_AXI_RLAST)begin if(bad||M_AXI_RRESP!=0||r_extra)state<=REPORT;else state<=R_TAG_ADDR;end
    else r_extra<=1;
   end
   R_TAG_ADDR:if(M_AXI_ARREADY)begin r_extra<=0;state<=R_TAG;end
   R_TAG:if(M_AXI_RVALID)begin
    if(M_AXI_RRESP!=0||!M_AXI_RLAST||r_extra||M_AXI_RDATA[255:160]!=0)bad<=1;
    if(!r_extra)begin response_tag<=M_AXI_RDATA[127:0];response_mask<=M_AXI_RDATA[159:128];end
    if(M_AXI_RLAST)state<=REPORT;else r_extra<=1;
   end
   W_DATA,W_TAG:begin
    if(M_AXI_AWVALID&&M_AXI_AWREADY)aw_sent<=1;
    if(M_AXI_WVALID&&M_AXI_WREADY)w_sent<=1;
    if((aw_sent||(M_AXI_AWVALID&&M_AXI_AWREADY))&&(w_sent||(M_AXI_WVALID&&M_AXI_WREADY)))state<=state==W_DATA?W_DATA_B:W_TAG_B;
   end
   W_DATA_B:if(M_AXI_BVALID)begin
    if(M_AXI_BRESP!=0)begin bad<=1;state<=REPORT;end
    else begin aw_sent<=0;w_sent<=0;state<=W_TAG;end
   end
   W_TAG_B:if(M_AXI_BVALID)begin if(M_AXI_BRESP!=0)bad<=1;state<=REPORT;end
   REPORT:state<=IDLE;
   default:begin bad<=1;state<=REPORT;end
  endcase
 end
endmodule
