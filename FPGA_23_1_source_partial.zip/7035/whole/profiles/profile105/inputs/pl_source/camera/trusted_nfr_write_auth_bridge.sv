`timescale 1ns/1ps
// Ingestion adapter, NOT a second cipher or an unauthenticated DDR bypass.
// AW/W may arrive independently. One 64-bit skid and one 256-bit assembly
// register are used; there is no inferred memory. Shared guard owns crypto.
module trusted_nfr_write_auth_bridge #(
 parameter [31:0] BASE=32'h22000000,
 parameter integer FRAME_BYTES=6220800
)(
 input wire clk,rst_n,cancel,authorized,key_valid,
 input wire [31:0] authorization_epoch,
 input wire frame_begin,output wire frame_begin_ready,
 input wire [31:0] trusted_session,trusted_frame,trusted_epoch,
 input wire producer_frame_ready,
 input wire [31:0] producer_session,producer_frame,
 output wire authenticated_frame_ready,output wire quiescent,
 output wire context_live,output reg fault,
 output reg [31:0] accepted_bytes,committed_bytes,
 input wire [31:0] S_AXI_AWADDR,input wire [7:0] S_AXI_AWLEN,
 input wire [2:0] S_AXI_AWSIZE,input wire [1:0] S_AXI_AWBURST,
 input wire S_AXI_AWVALID,output wire S_AXI_AWREADY,
 input wire [63:0] S_AXI_WDATA,input wire [7:0] S_AXI_WSTRB,
 input wire S_AXI_WLAST,S_AXI_WVALID,output wire S_AXI_WREADY,
 output wire [1:0] S_AXI_BRESP,output wire S_AXI_BVALID,input wire S_AXI_BREADY,
 output wire request_valid,input wire request_ready,
 output wire request_write,
 output wire [31:0] request_session,request_frame,request_epoch,request_version,
 output wire [15:0] request_role,request_shape,
 output wire [31:0] request_address,request_tensor_mask,request_strobe,
 output wire [255:0] request_data,
 input wire response_valid,output wire response_ready,
 input wire response_error,guard_context_live,guard_quiescent
);
 localparam IDLE=0,TAKE=1,OFFER=2,RESULT=3,DRAIN=4,REPORT=5;
 reg [2:0] state;
 reg bound,aborted,aw_full,w_full,burst_bad,b_error;
 reg [31:0] saved_session,saved_frame,saved_epoch,aw_address;
 reg [8:0] beats_left;
 reg [63:0] w_data;reg [7:0] w_strobe;reg w_last;
 reg [255:0] assembly;reg [31:0] assembly_mask,assembly_address;
 reg finish_burst;
 wire live_now=bound&&!aborted&&!cancel&&authorized&&key_valid&&authorization_epoch==saved_epoch;
 assign context_live=live_now;
 // quiescent covers producer offers as well as the shared guard; a scheduler
 // may rebind only when it has stopped issuing the old producer transaction.
 assign quiescent=state==IDLE&&!aw_full&&!w_full&&!S_AXI_AWVALID&&!S_AXI_WVALID&&guard_quiescent;
 assign frame_begin_ready=quiescent;
 assign authenticated_frame_ready=live_now&&!fault&&accepted_bytes==FRAME_BYTES&&committed_bytes==FRAME_BYTES&&
   producer_frame_ready&&producer_session==saved_session&&producer_frame==saved_frame&&quiescent;
 assign S_AXI_AWREADY=state==IDLE&&!aw_full;
 assign S_AXI_WREADY=(state==IDLE||state==TAKE)&&!w_full;
 assign S_AXI_BVALID=state==REPORT;
 assign S_AXI_BRESP=b_error?2'b10:2'b00;
 assign request_valid=state==OFFER;
 assign request_write=1'b1;
 assign request_session=saved_session;assign request_frame=saved_frame;assign request_epoch=saved_epoch;
 assign request_version=32'd2;assign request_role=16'h4002;assign request_shape=16'h4002;
 assign request_address=assembly_address;assign request_tensor_mask=32'hffffffff;
 assign request_strobe=assembly_mask;assign request_data=assembly;
 assign response_ready=state==RESULT;
 function automatic [4:0] first_byte(input [7:0] m);
  integer i;reg found;begin first_byte=0;found=0;
   for(i=0;i<8;i=i+1)if(m[i]&&!found)begin first_byte=i;found=1;end
  end
 endfunction
 function automatic [5:0] pop32(input [31:0] m);
  integer i;begin pop32=0;for(i=0;i<32;i=i+1)pop32=pop32+m[i];end
 endfunction
 wire [8:0] strobe_shift={1'b0,w_strobe}>>first_byte(w_strobe);
 wire contiguous=w_strobe!=0&&(strobe_shift&(strobe_shift+1'b1))==0;
 wire last_beat=beats_left==1;
 wire [31:0] byte_address=aw_address+first_byte(w_strobe);
 wire [31:0] beat_mask=aw_address[4:3]==0?{24'd0,w_strobe}:
   aw_address[4:3]==1?{16'd0,w_strobe,8'd0}:
   aw_address[4:3]==2?{8'd0,w_strobe,16'd0}:{w_strobe,24'd0};
 wire beat_bad=!live_now||burst_bad||!contiguous||byte_address!=BASE+accepted_bytes||
   {1'b0,accepted_bytes}+pop32({24'd0,w_strobe})>FRAME_BYTES||w_last!=last_beat;
 wire [32:0] offered_end={1'b0,S_AXI_AWADDR}+(({25'd0,S_AXI_AWLEN}+1'b1)<<3);
 wire aw_bad=S_AXI_AWSIZE!=3||S_AXI_AWBURST!=1||S_AXI_AWADDR[2:0]!=0||
   S_AXI_AWADDR<BASE||offered_end>{1'b0,BASE}+FRAME_BYTES||
   {1'b0,S_AXI_AWADDR[11:0]}+(({5'd0,S_AXI_AWLEN}+1'b1)<<3)>4096||!live_now;
 integer i;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;bound<=0;aborted<=0;fault<=0;aw_full<=0;w_full<=0;burst_bad<=0;b_error<=0;
   accepted_bytes<=0;committed_bytes<=0;saved_session<=0;saved_frame<=0;saved_epoch<=0;
   aw_address<=0;beats_left<=0;w_data<=0;w_strobe<=0;w_last<=0;
   assembly<=0;assembly_mask<=0;assembly_address<=0;finish_burst<=0;
  end else begin
   if(bound&&(!authorized||!key_valid||cancel||authorization_epoch!=saved_epoch))begin aborted<=1;fault<=1;end
   if(frame_begin&&frame_begin_ready)begin
    bound<=1;aborted<=cancel||!authorized||!key_valid||trusted_epoch!=authorization_epoch;
    fault<=cancel||!authorized||!key_valid||trusted_epoch!=authorization_epoch;
    saved_session<=trusted_session;saved_frame<=trusted_frame;saved_epoch<=trusted_epoch;
    accepted_bytes<=0;committed_bytes<=0;
   end
   if(S_AXI_WVALID&&S_AXI_WREADY)begin w_full<=1;w_data<=S_AXI_WDATA;w_strobe<=S_AXI_WSTRB;w_last<=S_AXI_WLAST;end
   if(S_AXI_AWVALID&&S_AXI_AWREADY)begin
    // Alignment is checked on the unmodified input. The low three stored
    // address bits are constant zero, avoiding a needless 256-way byte mux.
    aw_full<=1;aw_address<={S_AXI_AWADDR[31:3],3'b0};beats_left<={1'b0,S_AXI_AWLEN}+1'b1;
    burst_bad<=aw_bad;b_error<=0;
    if(aw_bad)begin aborted<=1;fault<=1;end
   end
   case(state)
    IDLE:if(aw_full)state<=TAKE;
    TAKE:if(w_full)begin
     w_full<=0;aw_address<=aw_address+8;beats_left<=beats_left-1;
     finish_burst<=last_beat;
     if(beat_bad)begin
      burst_bad<=1;aborted<=1;fault<=1;assembly<=0;assembly_mask<=0;
      if(last_beat)state<=DRAIN;
     end else begin
      // Before each append the buffer is empty or the same aligned 32B word.
      if(assembly_mask==0)begin assembly<=0;assembly_address<={aw_address[31:5],5'b0};end
      for(i=0;i<32;i=i+1)if(beat_mask[i])assembly[i*8+:8]<=w_data[(i%8)*8+:8];
      assembly_mask<=assembly_mask|beat_mask;
      accepted_bytes<=accepted_bytes+pop32({24'd0,w_strobe});
      if(aw_address[4:0]==24||last_beat)state<=OFFER;
     end
    end
    // VALID is irrevocable once offered, including cancel/revoke while stalled.
    OFFER:if(request_ready)state<=RESULT;
    RESULT:if(response_valid)begin
     if(response_error||!guard_context_live||!live_now)begin burst_bad<=1;aborted<=1;fault<=1;end
     else committed_bytes<=committed_bytes+pop32(assembly_mask);
     assembly<=0;assembly_mask<=0;
     state<=finish_burst?DRAIN:TAKE;
    end
    DRAIN:if(guard_quiescent)begin b_error<=burst_bad||!live_now;state<=REPORT;end
    REPORT:if(S_AXI_BREADY)begin state<=IDLE;aw_full<=0;end
    default:begin aborted<=1;fault<=1;state<=DRAIN;end
   endcase
  end
 end
endmodule
