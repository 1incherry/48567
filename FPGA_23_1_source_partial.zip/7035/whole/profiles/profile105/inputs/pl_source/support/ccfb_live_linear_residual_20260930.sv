// Trusted on-chip linear -> existing private FC2 residual SRAM write interface.
// Data are staged before commit, but consumer_start is blocked until the full
// protected source completion matches. This module does not compute a MAC.
module ccfb_live_linear_residual_20260930(
 input wire clk,rst_n,clear,source_discard,
 input wire source_begin,input wire[127:0]source_context,
 input wire word_valid,input wire[15:0]word_address,input wire signed[15:0]word_data,
 input wire source_complete,input wire[127:0]complete_context,
 input wire consumer_request,input wire[127:0]consumer_context,
 output wire residual_valid,output wire[15:0]residual_address,output wire signed[15:0]residual_data,
 output wire consumer_allow,output wire committed,
 output reg fault,output reg[7:0]fault_code,
 output reg[31:0]captured_words,residual_words,consumer_starts
);
 localparam IDLE=0,CAPTURE=1,SEALED=2,USED=3,FAILED=4;
 reg[2:0]state;reg[127:0]held_context;
 reg[5:0]tile_row,tile_col;reg[3:0]lane;
 wire[15:0]expected_address=((tile_row*4+lane[3:2])*192)+(tile_col*4+lane[1:0]);
 wire begin_bad=source_begin&&(state!=IDLE||source_context[103:88]!=7||source_context[87:80]!=0||
   source_context[127:112]==0||source_context[71:40]==0||source_context[39:8]==0||source_context[7:0]!=0);
 wire word_bad=word_valid&&(state!=CAPTURE||captured_words>=39936||word_address!=expected_address);
 wire final_word=word_valid&&!word_bad&&captured_words==39935;
 wire complete_bad=source_complete&&(state!=CAPTURE||complete_context!=held_context||
                                      (captured_words!=39936&&!final_word));
 wire consumer_identity=consumer_context[127:104]==held_context[127:104]&&
   consumer_context[103:88]==12&&consumer_context[87:72]==held_context[87:72]&&
   consumer_context[71:40]==held_context[71:40]&&consumer_context[39:8]>held_context[39:8]&&
   consumer_context[7:0]==0;
 wire consumer_bad=consumer_request&&(state!=SEALED||!consumer_identity);
 wire reject=source_discard||begin_bad||word_bad||complete_bad||consumer_bad;
 assign residual_valid=word_valid&&(state==CAPTURE)&&!fault&&!clear&&!reject&&word_address<37824;
 assign residual_address=word_address;assign residual_data=word_data;
 assign consumer_allow=consumer_request&&(state==SEALED)&&consumer_identity&&!fault&&!clear&&!reject;
 assign committed=(state==SEALED)&&!fault&&!clear&&!reject;
 always @(posedge clk)begin
  if(!rst_n||clear)begin
   state<=IDLE;held_context<=0;tile_row<=0;tile_col<=0;lane<=0;
   fault<=0;fault_code<=0;captured_words<=0;residual_words<=0;consumer_starts<=0;
  end else if(fault)begin state<=FAILED;end
  else if(reject)begin
   state<=FAILED;fault<=1;held_context<=0;
   if(source_discard)fault_code<=8'hb1;
   else if(begin_bad)fault_code<=8'hb2;
   else if(word_bad)fault_code<=8'hb3;
   else if(complete_bad)fault_code<=8'hb5;
   else fault_code<=8'hb4;
  end else begin
   if(source_begin)begin state<=CAPTURE;held_context<=source_context;end
   if(word_valid)begin
    captured_words<=captured_words+1;
    if(residual_valid)residual_words<=residual_words+1;
    if(lane==15)begin
     lane<=0;
     if(tile_col==47)begin tile_col<=0;tile_row<=tile_row+1;end
     else tile_col<=tile_col+1;
    end else lane<=lane+1;
   end
   if(source_complete)state<=SEALED;
   if(consumer_allow)begin state<=USED;consumer_starts<=consumer_starts+1;end
  end
 end
endmodule
