// Matched synthesis compilation unit for V876.  Both defines precede all
// affected RTL so the netlist contains V801 and its 4-round/cycle load MAC.
`define V801_LOAD_AUTH
`define V876_FAST_LOAD_MAC
`include "v870_v859_secure_add_this_one_file.v"
`include "secure_gemm_v0/v789_sm4_cbc_mac.v"
`include "../v794_v793_secure_tensor_gateway_pkg/v801_secure_stream_load_auth_2lane.v"
`include "../v794_v793_secure_tensor_gateway_pkg/v794_full_axi_contract_guard.v"
