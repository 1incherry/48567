// V881 matched synthesis compilation unit: V879 Norm2/Norm3 radix-16 plus
// the timing-driven Softmax shared radix-16 divider.
`define V801_LOAD_AUTH
`define V876_FAST_LOAD_MAC
`define V878_NORM2_RADIX16
`define V879_NORM3_RADIX16
`define V881_SOFTMAX_RADIX16
`include "../v794_v793_secure_tensor_gateway_pkg/third_party/verilog_library/intdiv_r16_plus/rtl/lzc.sv"
`include "../v794_v793_secure_tensor_gateway_pkg/third_party/verilog_library/intdiv_r16_plus/rtl/r4_qds_constants_generator.sv"
`include "../v794_v793_secure_tensor_gateway_pkg/third_party/verilog_library/intdiv_r16_plus/rtl/r4_qds.sv"
`include "../v794_v793_secure_tensor_gateway_pkg/third_party/verilog_library/intdiv_r16_plus/rtl/r16_block.sv"
`include "../v794_v793_secure_tensor_gateway_pkg/third_party/verilog_library/intdiv_r16_plus/rtl/intdiv_r16_plus.sv"
`include "v870_v859_secure_add_this_one_file.v"
`include "secure_gemm_v0/v789_sm4_cbc_mac.v"
`include "../v794_v793_secure_tensor_gateway_pkg/v801_secure_stream_load_auth_2lane.v"
`include "../v794_v793_secure_tensor_gateway_pkg/v794_full_axi_contract_guard.v"
