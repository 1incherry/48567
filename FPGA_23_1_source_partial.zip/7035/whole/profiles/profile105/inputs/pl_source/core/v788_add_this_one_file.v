`timescale 1ns/1ps
`define V788_SM4_CTR
`include "secure_gemm_v0/v788_sm4_ctr_stream.v"
`include "v787_add_this_one_file.v"
