// Matched synthesis compilation unit for the original 1-round/cycle V801
// authenticated-load data plane.  The define must precede v870/v736 parsing;
// defining it later only changes v794's ports and silently leaves V790 active.
`define V801_LOAD_AUTH
`include "v870_v859_secure_add_this_one_file.v"
`include "secure_gemm_v0/v789_sm4_cbc_mac.v"
`include "../v794_v793_secure_tensor_gateway_pkg/v801_secure_stream_load_auth_2lane.v"
`include "../v794_v793_secure_tensor_gateway_pkg/v794_full_axi_contract_guard.v"
