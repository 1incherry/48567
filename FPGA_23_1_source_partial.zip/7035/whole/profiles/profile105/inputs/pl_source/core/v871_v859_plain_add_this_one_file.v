`timescale 1ns/1ps
// Matched plaintext baseline for the V859-compressed Transformer datapath.
// Keep the V859 Norm2 LUTRAM remap, but stop at the V786 passthrough shell so
// no SM4 read/write engines are physically instantiated.
`define V859_NORM2_LINEAR_LUTRAM
`include "secure_gemm_v0/v859_distributed_sdp_sync.v"
// V787 is part of the matched NPU datapath (FC1 LUTRAM prefetch); it then
// falls through to the V786 plaintext stream shell without defining SM4.
`include "v787_add_this_one_file.v"
