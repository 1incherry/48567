`timescale 1ns/1ps
`include "audio105_profile_parameters.vh"
module trusted_audio_profile313_contract(input wire[4:0]word_index,input wire[31:0]candidate_word,output wire word_equal);
reg[31:0]expected;always @*begin expected=0;case(word_index)
5'd0:expected=32'h41325331;
5'd1:expected=32'h00000001;
5'd2:expected=32'h00007d00;
5'd3:expected=32'h00003e80;
5'd4:expected=32'h000001e0;
5'd5:expected=32'h00000140;
5'd6:expected=32'h00000063;
5'd7:expected=32'h00000028;
5'd8:expected=32'h00000064;
5'd9:expected=32'h00000040;
5'd10:expected=32'h0000000c;
5'd11:expected=32'h00000001;
5'd12:expected=32'h00000100;
5'd13:expected=32'h00000069;
5'd14:expected=`AUDIO105_PATCH_FRACTION;
5'd15:expected=`AUDIO105_CLS_FRACTION;
5'd16:expected=32'hef7bb8fe;
5'd17:expected=32'hab661d28;
5'd18:expected=32'hda2d6fbf;
5'd19:expected=32'h537d2f5b;
5'd20:expected=32'hff4ce77a;
5'd21:expected=32'h0dfcf13a;
5'd22:expected=32'hb89fc06d;
5'd23:expected=32'h5f57f093;
5'd24:expected=32'h00000001;
5'd25:expected=32'h0000000e;
5'd26:expected=32'h0000000a;
5'd27:expected=32'h00000063;
5'd28:expected=32'h00000080;
5'd29:expected=32'h00020069;
5'd30:expected=32'h00000000;
5'd31:expected=32'h00000001;
default:expected=0;endcase end
assign word_equal=candidate_word==expected;endmodule
