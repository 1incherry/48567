`timescale 1ns/1ps
module tb_yolo_dot16;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,start_valid=0,vector_valid=0,vector_last=0,result_ready=0;
 reg signed [31:0] bias=0;
 reg [7:0] activation_zero_point=0;
 reg [127:0] activations=0,weights=0;
 wire start_ready,vector_ready,result_valid;wire signed [31:0] result;
 yolo_dot16_u8s8 dut(.*);
 integer test_idx,k,chunks,lanes,c,j,av,wv,seed=32'h1977035;
 reg signed [63:0] expected;
 reg signed [31:0] held;
 initial begin
  repeat(3)@(negedge clk);rst_n=1;
  for(test_idx=0;test_idx<160;test_idx=test_idx+1)begin
   case(test_idx%5)0:activation_zero_point=0;1:activation_zero_point=128;2:activation_zero_point=255;default:activation_zero_point=$random(seed);endcase
   k=(test_idx<6)?test_idx+1:1+($unsigned($random(seed))%4096);
   chunks=(k+15)/16;bias=$random(seed);expected=$signed(bias);
   @(negedge clk);start_valid=1;
   @(posedge clk);while(!start_ready)@(posedge clk);
   @(negedge clk);start_valid=0;
   for(c=0;c<chunks;c=c+1)begin
    if(c%7==0)begin vector_valid=0;repeat(2)@(negedge clk);end
    activations={16{activation_zero_point}};weights=0;
    for(j=0;j<16;j=j+1)if(c*16+j<k)begin
     av=$unsigned($random(seed))%256;wv=($unsigned($random(seed))%256)-128;
     activations[j*8+:8]=av;weights[j*8+:8]=wv;
     expected=expected+(longint'(av)-longint'(int'(activation_zero_point)))*longint'(wv);
    end
    vector_valid=1;vector_last=(c==chunks-1);
    @(posedge clk);while(!vector_ready)@(posedge clk);
    @(negedge clk);
   end
   vector_valid=0;vector_last=0;
   while(!result_valid)@(negedge clk);
   if(result!==expected[31:0])$fatal(1,"dot mismatch test=%0d k=%0d zp=%0d got=%0d expected=%0d",test_idx,k,activation_zero_point,result,$signed(expected[31:0]));
   held=result;
   repeat(4)begin @(negedge clk);if(!result_valid||result!==held||start_ready)$fatal(1,"output backpressure violation");end
   result_ready=1;@(negedge clk);result_ready=0;
  end
  // Reset aborts an unfinished command and permits a fresh start.
  @(negedge clk);start_valid=1;@(negedge clk);start_valid=0;
  vector_valid=1;activations=128'hffffffffffffffffffffffffffffffff;weights=128'h80808080808080808080808080808080;
  @(negedge clk);vector_valid=0;rst_n=0;repeat(2)@(negedge clk);rst_n=1;
  @(negedge clk);if(!start_ready||result_valid)$fatal(1,"reset abort failed");
  $display("YOLO_DOT16_PASS tests=160 zero_points=0_128_255_random k_up_to=4096 backpressure=PASS reset_abort=PASS");$finish;
 end
 initial begin #2000000;$fatal(1,"timeout");end
endmodule
