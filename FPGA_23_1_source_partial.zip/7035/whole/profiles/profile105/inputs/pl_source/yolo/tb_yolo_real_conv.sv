`timescale 1ns/1ps
module tb_yolo_real_conv;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,command_valid=0;
 wire command_ready,input_read,weight_read,output_write,done,error;
 reg [15:0] cfg_input_h=320,cfg_input_w=320,cfg_input_row0,cfg_input_rows,cfg_channel_blocks=1;
 reg [15:0] cfg_output_w=160,cfg_output_row0,cfg_output_rows=4;
 reg [3:0] cfg_kernel=6,cfg_stride=2,cfg_padding=2;
 reg [7:0] cfg_zero_point;reg signed [31:0] cfg_bias;
 wire [31:0] input_address,weight_address,output_address,output_data;
 reg [127:0] input_data,weight_data;
 // Testbench's DDR image/weight backing is not synthesized or claimed as on-chip RAM.
 reg [127:0] ddr_image[0:102399],ddr_weight[0:575];
 reg [31:0] ddr_bias[0:15],expected[0:30719];
 // Fixed SRAM capacities compatible with the existing shared tensor banks.
 reg [127:0] amem[0:4899],wmem[0:4703];
 wire output_ready=1'b1;
 yolo_conv_stripe dut(.*);
 integer oc,stripe,row0,row1,i,j,fd,zp_int,seen,total=0,outfd;
 always @(posedge clk)begin
  if(input_read)begin if(input_address>=4900)$fatal(1,"shared A bank exceeded");input_data<=amem[input_address];end
  if(weight_read)begin if(weight_address>=4704)$fatal(1,"shared B bank exceeded");weight_data<=wmem[weight_address];end
  if(output_write)begin
   if(output_address!==seen||output_data!==expected[total])
    $fatal(1,"real INT8 convolution mismatch oc=%0d stripe=%0d pixel=%0d got=%0d expected=%0d",oc,stripe,seen,$signed(output_data),$signed(expected[total]));
   $fwrite(outfd,"%08x\n",output_data);seen=seen+1;total=total+1;
  end
 end
 initial begin
  $readmemh("real_conv/image.hex",ddr_image);$readmemh("real_conv/weights.hex",ddr_weight);
  $readmemh("real_conv/bias.hex",ddr_bias);$readmemh("real_conv/expected.hex",expected);
  fd=$fopen("real_conv/config.txt","r");if(!fd)$fatal(1,"missing fixture");
  i=$fscanf(fd,"%d",zp_int);if(i!=1)$fatal(1,"bad config");$fclose(fd);cfg_zero_point=zp_int;
  outfd=$fopen("real_conv/actual.hex","w");if(!outfd)$fatal(1,"cannot write actual");
  repeat(3)@(negedge clk);rst_n=1;
  for(oc=0;oc<16;oc=oc+1)begin
   for(i=0;i<36;i=i+1)wmem[i]=ddr_weight[oc*36+i];cfg_bias=ddr_bias[oc];
   for(stripe=0;stripe<3;stripe=stripe+1)begin
    cfg_output_row0=(stripe==0)?0:(stripe==1)?80:156;
    row0=cfg_output_row0*2-2;if(row0<0)row0=0;
    row1=(cfg_output_row0+3)*2-2+6;if(row1>320)row1=320;
    cfg_input_row0=row0;cfg_input_rows=row1-row0;
    for(i=0;i<(row1-row0)*320;i=i+1)amem[i]=ddr_image[row0*320+i];
    seen=0;@(negedge clk);command_valid=1;@(negedge clk);command_valid=0;
    while(!done)@(negedge clk);
    if(error||seen!=640)$fatal(1,"real convolution completion error");
    @(negedge clk);
   end
  end
  $fclose(outfd);
  $display("YOLO_REAL_CONV_PASS outputs=%0d channels=16 stripes=top_middle_bottom trained_int8_weights=YES exact=YES",total);
  $finish;
 end
 initial begin #30000000;$fatal(1,"timeout");end
endmodule
