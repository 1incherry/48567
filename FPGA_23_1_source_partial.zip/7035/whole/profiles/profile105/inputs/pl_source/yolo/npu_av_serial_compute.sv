`timescale 1ns/1ps
// One hardware DDR owner at a time. This is the board's actual arbiter,
// not a simulation-only replacement. Vision arithmetic remains unchanged.
module npu_av_serial_compute #(parameter [31:0] OUT_BASE_ADDR=32'h1c000000)(
input wire clk,rst_n,
output wire audio_active,audio_irq,
output wire [31:0] stat0,stat1,stat2,stat3,
input wire [11:0] V_awaddr,
input wire V_awvalid,
output wire V_awready,
input wire [31:0] V_wdata,
input wire [3:0] V_wstrb,
input wire V_wvalid,
output wire V_wready,
output wire [1:0] V_bresp,
output wire V_bvalid,
input wire V_bready,
input wire [11:0] V_araddr,
input wire V_arvalid,
output wire V_arready,
output wire [31:0] V_rdata,
output wire [1:0] V_rresp,
output wire V_rvalid,
input wire V_rready,
input wire [20:0] A_awaddr,
input wire A_awvalid,
output wire A_awready,
input wire [31:0] A_wdata,
input wire [3:0] A_wstrb,
input wire A_wvalid,
output wire A_wready,
output wire [1:0] A_bresp,
output wire A_bvalid,
input wire A_bready,
input wire [20:0] A_araddr,
input wire A_arvalid,
output wire A_arready,
output wire [31:0] A_rdata,
output wire [1:0] A_rresp,
output wire A_rvalid,
input wire A_rready,
output wire [31:0] M_araddr,
output wire [7:0] M_arlen,
output wire [2:0] M_arsize,
output wire [1:0] M_arburst,
output wire M_arvalid,
input wire M_arready,
input wire [255:0] M_rdata,
input wire [1:0] M_rresp,
input wire M_rlast,
input wire M_rvalid,
output wire M_rready,
output wire [31:0] M_awaddr,
output wire [7:0] M_awlen,
output wire [2:0] M_awsize,
output wire [1:0] M_awburst,
output wire M_awvalid,
input wire M_awready,
output wire [255:0] M_wdata,
output wire [31:0] M_wstrb,
output wire M_wlast,
output wire M_wvalid,
input wire M_wready,
input wire [1:0] M_bresp,
input wire M_bvalid,
output wire M_bready);
wire audio_claim,audio_busy,vision_idle;
wire [31:0] v_araddr;
wire [7:0] v_arlen;
wire [2:0] v_arsize;
wire [1:0] v_arburst;
wire v_arvalid;
wire v_arready;
wire [255:0] v_rdata;
wire [1:0] v_rresp;
wire v_rlast;
wire v_rvalid;
wire v_rready;
wire [31:0] v_awaddr;
wire [7:0] v_awlen;
wire [2:0] v_awsize;
wire [1:0] v_awburst;
wire v_awvalid;
wire v_awready;
wire [255:0] v_wdata;
wire [31:0] v_wstrb;
wire v_wlast;
wire v_wvalid;
wire v_wready;
wire [1:0] v_bresp;
wire v_bvalid;
wire v_bready;
wire [31:0] a_araddr;
wire [7:0] a_arlen;
wire [2:0] a_arsize;
wire [1:0] a_arburst;
wire a_arvalid;
wire a_arready;
wire [255:0] a_rdata;
wire [1:0] a_rresp;
wire a_rlast;
wire a_rvalid;
wire a_rready;
wire [31:0] a_awaddr;
wire [7:0] a_awlen;
wire [2:0] a_awsize;
wire [1:0] a_awburst;
wire a_awvalid;
wire a_awready;
wire [255:0] a_wdata;
wire [31:0] a_wstrb;
wire a_wlast;
wire a_wvalid;
wire a_wready;
wire [1:0] a_bresp;
wire a_bvalid;
wire a_bready;
npu_yolo_vit_core #(.ENABLE_LIVE_CHAIN(1),.AV_CAPABILITY(1),.OUT_BASE_ADDR(OUT_BASE_ADDR)) u_npu(.clk(clk),.rst_n(rst_n),.external_busy(audio_claim),.external_idle(vision_idle),
.S_AXIL_AWADDR(V_awaddr),
.S_AXIL_AWVALID(V_awvalid),
.S_AXIL_AWREADY(V_awready),
.S_AXIL_WDATA(V_wdata),
.S_AXIL_WSTRB(V_wstrb),
.S_AXIL_WVALID(V_wvalid),
.S_AXIL_WREADY(V_wready),
.S_AXIL_BRESP(V_bresp),
.S_AXIL_BVALID(V_bvalid),
.S_AXIL_BREADY(V_bready),
.S_AXIL_ARADDR(V_araddr),
.S_AXIL_ARVALID(V_arvalid),
.S_AXIL_ARREADY(V_arready),
.S_AXIL_RDATA(V_rdata),
.S_AXIL_RRESP(V_rresp),
.S_AXIL_RVALID(V_rvalid),
.S_AXIL_RREADY(V_rready),
.M_AXI_ARADDR(v_araddr),
.M_AXI_ARLEN(v_arlen),
.M_AXI_ARSIZE(v_arsize),
.M_AXI_ARBURST(v_arburst),
.M_AXI_ARVALID(v_arvalid),
.M_AXI_ARREADY(v_arready),
.M_AXI_RDATA(v_rdata),
.M_AXI_RRESP(v_rresp),
.M_AXI_RLAST(v_rlast),
.M_AXI_RVALID(v_rvalid),
.M_AXI_RREADY(v_rready),
.M_AXI_AWADDR(v_awaddr),
.M_AXI_AWLEN(v_awlen),
.M_AXI_AWSIZE(v_awsize),
.M_AXI_AWBURST(v_awburst),
.M_AXI_AWVALID(v_awvalid),
.M_AXI_AWREADY(v_awready),
.M_AXI_WDATA(v_wdata),
.M_AXI_WSTRB(v_wstrb),
.M_AXI_WLAST(v_wlast),
.M_AXI_WVALID(v_wvalid),
.M_AXI_WREADY(v_wready),
.M_AXI_BRESP(v_bresp),
.M_AXI_BVALID(v_bvalid),
.M_AXI_BREADY(v_bready),
.data_auth_enable('0),
.data_auth_expected_valid('0),
.data_auth_expected_tag('0),
.data_auth_mac_key('0),
.data_auth_context('0),
.data_auth_common_enable('0),
.data_auth_common_object_context('0),
.data_auth_common_dtype('0),
.data_auth_common_role('0),
.data_auth_common_key_id('0),
.data_auth_secure_clear('0),
.data_auth_done(),
.data_auth_ok(),
.data_auth_fail(),
.stat0(stat0),
.stat1(stat1),
.stat2(stat2),
.stat3(stat3));
audio_serial_top u_audio(.clk(clk),.rst_n(rst_n),.can_enable(vision_idle),.claim(audio_claim),.active(audio_active),.busy(audio_busy),.irq(audio_irq),.s_axi_awprot(3'b0),.s_axi_arprot(3'b0),
.s_axi_awaddr(A_awaddr),
.s_axi_awvalid(A_awvalid),
.s_axi_awready(A_awready),
.s_axi_wdata(A_wdata),
.s_axi_wstrb(A_wstrb),
.s_axi_wvalid(A_wvalid),
.s_axi_wready(A_wready),
.s_axi_bresp(A_bresp),
.s_axi_bvalid(A_bvalid),
.s_axi_bready(A_bready),
.s_axi_araddr(A_araddr),
.s_axi_arvalid(A_arvalid),
.s_axi_arready(A_arready),
.s_axi_rdata(A_rdata),
.s_axi_rresp(A_rresp),
.s_axi_rvalid(A_rvalid),
.s_axi_rready(A_rready),
.M_AXI_ARADDR(a_araddr),
.M_AXI_ARLEN(a_arlen),
.M_AXI_ARSIZE(a_arsize),
.M_AXI_ARBURST(a_arburst),
.M_AXI_ARVALID(a_arvalid),
.M_AXI_ARREADY(a_arready),
.M_AXI_RDATA(a_rdata),
.M_AXI_RRESP(a_rresp),
.M_AXI_RLAST(a_rlast),
.M_AXI_RVALID(a_rvalid),
.M_AXI_RREADY(a_rready),
.M_AXI_AWADDR(a_awaddr),
.M_AXI_AWLEN(a_awlen),
.M_AXI_AWSIZE(a_awsize),
.M_AXI_AWBURST(a_awburst),
.M_AXI_AWVALID(a_awvalid),
.M_AXI_AWREADY(a_awready),
.M_AXI_WDATA(a_wdata),
.M_AXI_WSTRB(a_wstrb),
.M_AXI_WLAST(a_wlast),
.M_AXI_WVALID(a_wvalid),
.M_AXI_WREADY(a_wready),
.M_AXI_BRESP(a_bresp),
.M_AXI_BVALID(a_bvalid),
.M_AXI_BREADY(a_bready));
assign M_araddr=audio_active?a_araddr:v_araddr;
assign M_arlen=audio_active?a_arlen:v_arlen;
assign M_arsize=audio_active?a_arsize:v_arsize;
assign M_arburst=audio_active?a_arburst:v_arburst;
assign M_arvalid=audio_active?a_arvalid:v_arvalid;
assign a_arready=audio_active?M_arready:'0;
assign v_arready=audio_active?'0:M_arready;
assign a_rdata=audio_active?M_rdata:'0;
assign v_rdata=audio_active?'0:M_rdata;
assign a_rresp=audio_active?M_rresp:'0;
assign v_rresp=audio_active?'0:M_rresp;
assign a_rlast=audio_active?M_rlast:'0;
assign v_rlast=audio_active?'0:M_rlast;
assign a_rvalid=audio_active?M_rvalid:'0;
assign v_rvalid=audio_active?'0:M_rvalid;
assign M_rready=audio_active?a_rready:v_rready;
assign M_awaddr=audio_active?a_awaddr:v_awaddr;
assign M_awlen=audio_active?a_awlen:v_awlen;
assign M_awsize=audio_active?a_awsize:v_awsize;
assign M_awburst=audio_active?a_awburst:v_awburst;
assign M_awvalid=audio_active?a_awvalid:v_awvalid;
assign a_awready=audio_active?M_awready:'0;
assign v_awready=audio_active?'0:M_awready;
assign M_wdata=audio_active?a_wdata:v_wdata;
assign M_wstrb=audio_active?a_wstrb:v_wstrb;
assign M_wlast=audio_active?a_wlast:v_wlast;
assign M_wvalid=audio_active?a_wvalid:v_wvalid;
assign a_wready=audio_active?M_wready:'0;
assign v_wready=audio_active?'0:M_wready;
assign a_bresp=audio_active?M_bresp:'0;
assign v_bresp=audio_active?'0:M_bresp;
assign a_bvalid=audio_active?M_bvalid:'0;
assign v_bvalid=audio_active?'0:M_bvalid;
assign M_bready=audio_active?a_bready:v_bready;
endmodule
