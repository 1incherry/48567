`timescale 1ns/1ps
module tb_yolo_conv_stripe;
 reg clk=0;always #5 clk=~clk;
 reg rst_n=0,command_valid=0;
 wire command_ready,input_read,weight_read,output_write,done,error;
 reg [15:0] cfg_input_h,cfg_input_w,cfg_input_row0,cfg_input_rows,cfg_channel_blocks;
 reg [15:0] cfg_output_w,cfg_output_row0,cfg_output_rows;
 reg [3:0] cfg_kernel,cfg_stride,cfg_padding;
 reg [7:0] cfg_zero_point;reg signed [31:0] cfg_bias;
 wire [31:0] input_address,weight_address,output_address,output_data;
 reg [127:0] input_data,weight_data;
 reg [127:0] amem[0:8191],wmem[0:4095];
 reg signed [31:0] expected[0:2047];
 wire output_ready=1'b1;
 yolo_conv_stripe dut(.*);
 integer seed=703521,tc,i,j,k,y,x,yy,xx,ky,kx,cb,lane,addr,av,wv,n,seen,total=0;
 reg signed [63:0] sum;
 always @(posedge clk)begin
  if(input_read)begin if(input_address>=8192)$fatal(1,"input bounds");input_data<=amem[input_address];end
  if(weight_read)begin if(weight_address>=4096)$fatal(1,"weight bounds");weight_data<=wmem[weight_address];end
  if(output_write)begin
   if(output_address!==seen||output_data!==expected[seen])
    $fatal(1,"stripe mismatch test=%0d pixel=%0d addr=%0d got=%0d expected=%0d",tc,seen,output_address,$signed(output_data),expected[seen]);
   seen=seen+1;total=total+1;
  end
 end
 initial begin
  repeat(3)@(negedge clk);rst_n=1;
  for(tc=0;tc<24;tc=tc+1)begin
   cfg_input_h=13;cfg_input_w=15;cfg_input_row0=0;cfg_input_rows=13;
   cfg_channel_blocks=1+tc%4;cfg_kernel=(tc%3==0)?6:(tc%3==1)?3:1;
   cfg_stride=(tc%3==0)?2:1;cfg_padding=(tc%3==0)?2:(tc%3==1)?1:0;
   cfg_output_w=(15+2*cfg_padding-cfg_kernel)/cfg_stride+1;
   cfg_output_row0=tc%3;cfg_output_rows=3;
   cfg_zero_point=(tc%3==0)?0:(tc%3==1)?128:255;cfg_bias=$random(seed);
   // Some tests use a true partial input stripe with a nonzero global row origin.
   if(tc>=12)begin
    cfg_input_h=17;
    cfg_output_row0=3;
    cfg_input_row0=3*cfg_stride-cfg_padding;
    cfg_input_rows=2*cfg_stride+cfg_kernel;
   end
   for(i=0;i<cfg_input_rows*cfg_input_w*cfg_channel_blocks;i=i+1)
    for(j=0;j<16;j=j+1)amem[i][j*8+:8]=$random(seed);
   for(i=0;i<cfg_kernel*cfg_kernel*cfg_channel_blocks;i=i+1)
    for(j=0;j<16;j=j+1)wmem[i][j*8+:8]=$random(seed);
   n=0;
   for(y=0;y<cfg_output_rows;y=y+1)for(x=0;x<cfg_output_w;x=x+1)begin
    sum=$signed(cfg_bias);
    for(ky=0;ky<cfg_kernel;ky=ky+1)for(kx=0;kx<cfg_kernel;kx=kx+1)
     for(cb=0;cb<cfg_channel_blocks;cb=cb+1)for(lane=0;lane<16;lane=lane+1)begin
      yy=(y+cfg_output_row0)*cfg_stride+ky-cfg_padding;xx=x*cfg_stride+kx-cfg_padding;
      av=cfg_zero_point;
      if(yy>=0&&yy<cfg_input_h&&xx>=0&&xx<cfg_input_w)begin
       if(yy<cfg_input_row0||yy>=cfg_input_row0+cfg_input_rows)$fatal(1,"bad test stripe");
       addr=((yy-cfg_input_row0)*cfg_input_w+xx)*cfg_channel_blocks+cb;
       av=$unsigned(amem[addr][lane*8+:8]);
      end
      wv=$signed(wmem[(ky*cfg_kernel+kx)*cfg_channel_blocks+cb][lane*8+:8]);
      sum=sum+(longint'(av)-longint'(int'(cfg_zero_point)))*longint'(wv);
     end
    expected[n]=sum[31:0];n=n+1;
   end
   seen=0;@(negedge clk);command_valid=1;@(negedge clk);command_valid=0;
   while(!done)@(negedge clk);
   if(error||seen!=n)$fatal(1,"bad completion test=%0d seen=%0d n=%0d error=%0d",tc,seen,n,error);
   @(negedge clk);
  end
  cfg_channel_blocks=0;command_valid=1;@(negedge clk);command_valid=0;
  if(!done||!error)$fatal(1,"invalid config not rejected");
  $display("YOLO_CONV_STRIPE_PASS tests=24 pixels=%0d kernels=1_3_6 strides=1_2 padding=0_1_2 partial_rows=PASS int32_exact=PASS",total);
  $finish;
 end
 initial begin #10000000;$fatal(1,"timeout");end
endmodule
