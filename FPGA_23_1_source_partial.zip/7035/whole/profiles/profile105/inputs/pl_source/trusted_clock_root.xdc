# Fixed physical oscillator, available in synthesis and implementation.
create_clock -period 20.000 -name sys_clk_50m [get_ports sys_clk_50m]
