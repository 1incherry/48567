// Technology-neutral, permitted-geometry SRAM boundary. Reference mode is for
// functional verification ONLY. Real cells must be bound through the named
// technology adapters and checked against the actual macro pin/byte-mask model.
module kwt_sram16_macro #(parameter DEPTH=4096,AW=$clog2(DEPTH))(
    input wire clk,a_en,a_we,b_en,b_we,
    input wire [AW-1:0] a_addr,b_addr,
    input wire [15:0] a_data,b_data,
    input wire [1:0] a_mask,b_mask,
    output wire [15:0] a_q,b_q
);
`ifdef KWT_SRAM_REFERENCE
`ifdef SYNTHESIS
    KWT_REFERENCE_SRAM_MUST_NOT_BE_USED_FOR_PPA invalid_reference_synthesis();
`else
    reg [15:0] storage[0:DEPTH-1];reg [15:0] aq,bq;
    assign a_q=aq;assign b_q=bq;
    integer byte_lane;
    initial if(DEPTH!=128&&DEPTH!=1024&&DEPTH!=4096)$fatal(1,"Unpermitted SRAM geometry");
    always @(posedge clk)begin
        if(a_en)begin
            aq<=storage[a_addr];
            for(byte_lane=0;byte_lane<2;byte_lane=byte_lane+1)
                if(a_we&&a_mask[byte_lane])storage[a_addr][byte_lane*8+:8]<=a_data[byte_lane*8+:8];
        end
        if(b_en)begin
            bq<=storage[b_addr];
            for(byte_lane=0;byte_lane<2;byte_lane=byte_lane+1)
                if(b_we&&b_mask[byte_lane])storage[b_addr][byte_lane*8+:8]<=b_data[byte_lane*8+:8];
        end
    end
`endif
`else
    // These adapters are deliberately unresolved until real vendor macro
    // wrappers are supplied. Their common ABI is a design contract, not a
    // claim that the organizer cells have these native pin names or masks.
    generate if(DEPTH==4096)begin: cell4096
        kwt_tech_sram16x4096_dp cell_adapter(.*);
    end else if(DEPTH==1024)begin: cell1024
        kwt_tech_sram16x1024_dp cell_adapter(.*);
    end else if(DEPTH==128)begin: cell128
        kwt_tech_sram16x128_dp cell_adapter(.*);
    end else begin: invalid_size
        KWT_UNPERMITTED_SRAM_GEOMETRY invalid_geometry();
    end endgenerate
`endif
endmodule
module kwt_sram_banked #(
    parameter WIDTH=32,DEPTH=131072,MACRO_DEPTH=4096,ADDR_W=$clog2(DEPTH)
)(
    input wire clk,a_en,a_we,b_en,b_we,
    input wire [ADDR_W-1:0] a_addr,b_addr,
    input wire [WIDTH-1:0] a_data,b_data,
    input wire [(WIDTH+7)/8-1:0] a_strobe,
    output wire [WIDTH-1:0] a_q,b_q
);
    localparam LANES=(WIDTH+15)/16,BANKS=(DEPTH+MACRO_DEPTH-1)/MACRO_DEPTH;
    localparam MAW=$clog2(MACRO_DEPTH),BSW=BANKS<=1?1:$clog2(BANKS);
    wire [31:0] a_ext=a_addr,b_ext=b_addr;
    wire [BSW-1:0] a_bank=a_ext>>MAW,b_bank=b_ext>>MAW;
    reg [BSW-1:0] a_selected,b_selected;
    wire [LANES*16-1:0] a_padded=a_data,b_padded=b_data;
    wire [LANES*2-1:0] masks=a_strobe;
    wire [LANES*16-1:0] a_outputs[0:BANKS-1],b_outputs[0:BANKS-1];
    always @(posedge clk)begin if(a_en)a_selected<=a_bank;if(b_en)b_selected<=b_bank;end
    assign a_q=a_outputs[a_selected][WIDTH-1:0];
    assign b_q=b_outputs[b_selected][WIDTH-1:0];
    genvar bank,lane;
    generate for(bank=0;bank<BANKS;bank=bank+1)begin: banks
        for(lane=0;lane<LANES;lane=lane+1)begin: lanes
            kwt_sram16_macro #(.DEPTH(MACRO_DEPTH)) macro_cell(
                .clk(clk),.a_en(a_en&&a_bank==bank),.a_we(a_we),
                .a_addr(a_ext[MAW-1:0]),.a_data(a_padded[lane*16+:16]),.a_mask(masks[lane*2+:2]),
                .a_q(a_outputs[bank][lane*16+:16]),
                .b_en(b_en&&b_bank==bank),.b_we(b_we),
                .b_addr(b_ext[MAW-1:0]),.b_data(b_padded[lane*16+:16]),.b_mask(2'b11),
                .b_q(b_outputs[bank][lane*16+:16]));
        end
    end endgenerate
endmodule
