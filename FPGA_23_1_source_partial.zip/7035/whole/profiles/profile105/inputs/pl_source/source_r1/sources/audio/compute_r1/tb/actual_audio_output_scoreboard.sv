`timescale 1ns/1ps
// Actual AV publisher/CDC/TX/overlay observes ONLY the real audio private bank.
// Python expected packet comes from original head gold/known root job tuple;
// it is never input to the audio inference or DDR.
module actual_audio_output_scoreboard(
 input wire clk,security_reset_n,authorized,key_valid,clip_start,
 input wire record_commit,record_visible,input wire[287:0]record_context,
 input wire[3:0]record_class,input wire[383:0]record_logits,
 output wire admission_ready,quiescent,fault,output reg checked
);
reg tx_clk=0,pixel_clk=0;always #4 tx_clk=~tx_clk;always #6.734 pixel_clk=~pixel_clk;
reg[11:0]x=0,y=0;integer tx_cycle=0;
reg tx_ready=0;wire[7:0]tx_data;wire tx_valid,tx_last;
wire[23:0]overlay_rgb;wire overlay_hs,overlay_vs,overlay_de;
always @(negedge tx_clk)begin tx_cycle=tx_cycle+1;tx_ready=tx_cycle%7!=0&&tx_cycle%13!=0;end
always @(posedge pixel_clk)begin
 if(!security_reset_n)begin x<=0;y<=0;end
 else if(x==1649)begin x<=0;y<=y==749?0:y+1'b1;end else x<=x+1'b1;
end
trusted_av_record_outputs actual_outputs(
 .clk(clk),.security_reset_n(security_reset_n),.authorization_live(authorized&&key_valid),.job_start(clip_start),
 .record_commit(1'b0),.record_visible(1'b0),.record_camera(32'd0),.record_session(32'd0),.record_frame(32'd0),.record_epoch(32'd0),.record_key_session(128'd0),.record_count(3'd0),.record_rois(896'd0),.record_indices(52'd0),.record_results(512'd0),
 .audio_record_commit(record_commit),.audio_record_visible(record_visible),.audio_record_context(record_context),.audio_record_class(record_class),.audio_record_logits(record_logits),
 .admission_ready(admission_ready),.quiescent(quiescent),.fault(fault),
 .tx_clk(tx_clk),.tx_reset_n(security_reset_n),.tx_data(tx_data),.tx_valid(tx_valid),.tx_last(tx_last),.tx_ready(tx_ready),
 .pixel_clk(pixel_clk),.pixel_reset_n(security_reset_n),.pixel_x(x),.pixel_y(y),.pixel_rgb(24'h123456),.pixel_hs(x<40),.pixel_vs(y<5),.pixel_de(x<1280&&y<720),.overlay_rgb(overlay_rgb),.overlay_hs(overlay_hs),.overlay_vs(overlay_vs),.overlay_de(overlay_de));
reg[7:0]expected[0:269];reg[2047:0]expected_body;
reg tx_checked=0,pixel_checked=0;integer count=0,fd,i;
initial begin
 checked=0;$readmemh("expected_audio_report.hex",expected);expected_body=0;
 for(i=0;i<256;i=i+1)expected_body[2047-i*8-:8]=expected[14+i];
 fd=$fopen("actual_audio_result_report.bin","wb");if(!fd)$fatal(1,"audio report dump open failed");
end
always @(posedge tx_clk)if(security_reset_n&&tx_valid&&tx_ready)begin
 if(count>=270||tx_data!==expected[count]||tx_last!==(count==269))$fatal(1,"actual audio NAR2/Python diff byte%0d actual%h expected%h",count,tx_data,expected[count]);
 $fwrite(fd,"%c",tx_data);count=count+1;if(tx_last)begin tx_checked=1;$fflush(fd);end
end
always @(posedge pixel_clk)if(security_reset_n&&actual_outputs.pixel_label_valid)begin
 if(actual_outputs.pixel_body!==expected_body)$fatal(1,"actual audio pixel snapshot differs from Python NAR2");
 pixel_checked=1;
end
always @(posedge clk)if(security_reset_n&&tx_checked&&pixel_checked&&quiescent&&!checked)begin
 if(!authorized||!key_valid||!record_visible||fault)$fatal(1,"actual audio output not current at completion");
 checked<=1;$display("ACTUAL_AUDIO_BANK_AV_PUBLISH_CDC_TX270_PY_EXACT class=%0d modality=NAR2 actual_pixel_snapshot=1",record_class);
end
endmodule
