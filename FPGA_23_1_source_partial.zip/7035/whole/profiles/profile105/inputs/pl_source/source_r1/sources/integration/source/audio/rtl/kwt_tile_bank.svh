// One write port and one synchronous read port; two independently owned slots.
// No reset/initialization of data: loader overwrites every valid tile operand.
module kwt_tile_bank #(parameter WIDTH=24)(
    input wire clk,write_enable,read_enable,
    input wire [8:0] write_address,read_address,
    input wire signed [WIDTH-1:0] write_data,
    output wire signed [WIDTH-1:0] read_data
);
`ifdef KWT_USE_SRAM_BANKS
    kwt_sram_banked #(.WIDTH(WIDTH),.DEPTH(512),.MACRO_DEPTH(1024),.ADDR_W(9)) macro_bank(
        .clk(clk),.a_en(write_enable),.a_we(write_enable),.a_addr(write_address),.a_data(write_data),
        .a_strobe({((WIDTH+7)/8){1'b1}}),.a_q(),
        .b_en(read_enable),.b_we(1'b0),.b_addr(read_address),.b_data({WIDTH{1'b0}}),.b_q(read_data));
`else
    (* ram_style="block" *) reg signed [WIDTH-1:0] data[0:511];
    reg signed [WIDTH-1:0] read_register;
    assign read_data=read_register;
    always @(posedge clk) begin
        if(write_enable) data[write_address]<=write_data;
        if(read_enable) read_register<=data[read_address];
    end
`endif
endmodule
