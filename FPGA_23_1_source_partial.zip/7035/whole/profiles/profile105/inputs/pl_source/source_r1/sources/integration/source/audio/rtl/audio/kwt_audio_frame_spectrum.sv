`timescale 1ns/1ps
// PCM480 -> window/BFP/FFT ->244 magnitudes used by the frozen Mel bank.
// Unused FFT bins are drained. Completion waits for both the FFT tail and
// acceptance of the last magnitude, including indefinite output stalls.
module kwt_audio_frame_spectrum #(
    parameter HANN_FILE="model/audio_hann_q30.hex",
    parameter TWIDDLE_FILE="model/audio_twiddle_q30.hex"
)(
    input wire clk,rst_n,clear,start,in_valid,
    input wire signed [15:0] in_pcm,
    output wire in_ready,out_valid,
    input wire out_ready,
    output wire [31:0] out_magnitude,
    output wire [8:0] out_index,
    output wire [5:0] out_fraction,
    output wire out_last,busy,overflow,
    output reg done
);
    reg active,fft_finished,last_accepted;
    wire fft_valid,fft_ready,fft_busy,fft_done,mag_ready;
    wire signed [31:0] fft_real,fft_imag;
    wire [8:0] fft_index;wire [5:0] fft_fraction;
    assign busy=active;
    assign out_last=out_valid&&out_index==243;
    assign fft_ready=fft_index>=244||mag_ready;
    wire last_fire=out_last&&out_ready;
    kwt_audio_frame_fft #(.HANN_FILE(HANN_FILE),.TWIDDLE_FILE(TWIDDLE_FILE)) frame_fft(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(start&&!active),.in_valid(in_valid),.in_pcm(in_pcm),
        .in_ready(in_ready),.out_valid(fft_valid),.out_ready(fft_ready),.out_real(fft_real),.out_imag(fft_imag),
        .out_index(fft_index),.out_fraction(fft_fraction),.busy(fft_busy),.done(fft_done),.overflow(overflow));
    kwt_audio_magnitude magnitude(
        .clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(fft_valid&&fft_index<244),.in_ready(mag_ready),
        .in_real(fft_real),.in_imag(fft_imag),.in_index(fft_index),.in_fraction(fft_fraction),
        .out_valid(out_valid),.out_ready(out_ready),.out_magnitude(out_magnitude),.out_index(out_index),.out_fraction(out_fraction));
    always @(posedge clk)begin
        if(!rst_n||clear)begin active<=0;fft_finished<=0;last_accepted<=0;done<=0;end
        else begin
            done<=0;
            if(start&&!active)begin active<=1;fft_finished<=0;last_accepted<=0;end
            if(active)begin
                if(fft_done)fft_finished<=1;
                if(last_fire)last_accepted<=1;
                if((fft_finished||fft_done)&&(last_accepted||last_fire))begin active<=0;done<=1;end
            end
        end
    end
endmodule
