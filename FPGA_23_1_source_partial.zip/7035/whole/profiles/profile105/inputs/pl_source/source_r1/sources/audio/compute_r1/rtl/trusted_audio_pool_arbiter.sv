`timescale 1ns/1ps
// Native A sub-owner, subordinate to the real whole-audio pool grant. Kernel
// owner_live remains the whole-audio grant, never this transient sub-owner.
module trusted_audio_pool_arbiter(
 input wire clk,security_reset_n,audio_pool_granted,cancel,
 input wire kernel_pool_quiet,kernel_write_valid,kernel_read_request,kernel_read_enable,
 input wire [11:0]kernel_write_address,kernel_read_address,input wire [255:0]kernel_write_data,
 output wire kernel_write_ready,kernel_read_ready,
 input wire ledger_request,ledger_read,ledger_write,
 input wire [11:0]ledger_read_address,ledger_write_address,input wire [255:0]ledger_write_data,
 output wire ledger_granted,
 output wire pool_requested,pool_read,pool_write,output wire [11:0]pool_read_address,pool_write_address,
 output wire [255:0]pool_write_data,output wire quiescent,protocol_violation,output reg fault
);
 reg[1:0]owner;
 wire kernel_request=kernel_write_valid||kernel_read_request;
 assign ledger_granted=audio_pool_granted&&owner==2;
 assign kernel_write_ready=audio_pool_granted&&owner==1;
 // New independent ledger intent preempts an as-yet UNACCEPTED kernel read;
 // an already accepted kernel read stays owner until its real capture ends.
 assign kernel_read_ready=audio_pool_granted&&owner==1&&!ledger_request;
 assign pool_requested=owner!=0||ledger_request||kernel_request||!kernel_pool_quiet;
 wire krange=kernel_read_address<1024,kwrange=kernel_write_address<1024;
 wire lrange=ledger_read_address>=1024&&ledger_read_address<2048;
 wire lwrange=ledger_write_address>=1024&&ledger_write_address<2048;
 assign pool_read=audio_pool_granted&&((owner==2&&ledger_read&&lrange)||(owner==1&&kernel_read_enable&&krange));
 assign pool_write=audio_pool_granted&&((owner==2&&ledger_write&&lwrange)||(owner==1&&kernel_write_valid&&kwrange));
 assign protocol_violation=(ledger_read&&(!ledger_granted||!lrange))||
  (ledger_write&&(!ledger_granted||!lwrange))||
  (kernel_read_enable&&(!kernel_read_ready||!krange))||
  (kernel_write_valid&&kernel_write_ready&&!kwrange);
 assign pool_read_address=owner==2?ledger_read_address:kernel_read_address;
 assign pool_write_address=owner==2?ledger_write_address:kernel_write_address;
 assign pool_write_data=owner==2?ledger_write_data:kernel_write_data;
 assign quiescent=owner==0&&!ledger_request&&!kernel_request&&kernel_pool_quiet;
 always @(posedge clk)begin
  if(!security_reset_n)begin owner<=0;fault<=0;end
  else begin
   if(owner!=0&&!audio_pool_granted)fault<=1;
   if(protocol_violation)fault<=1;
   case(owner)
    0:if(audio_pool_granted)begin
     if(ledger_request&&kernel_pool_quiet)owner<=2;
     else if(kernel_request)owner<=1;
    end
    1:if(kernel_pool_quiet&&!kernel_read_enable)begin
     if(ledger_request)owner<=2;
     else if(!kernel_request)owner<=0;
    end
    2:if(!ledger_request)begin
     if(kernel_request&&!cancel)owner<=1;
     else owner<=0;
    end
    default:begin owner<=0;fault<=1;end
   endcase
  end
 end
endmodule
