`timescale 1ns/1ps
// Signed integer dot product. The caller defines fixed-point scales.
// first/last mark accepted terms. clear aborts both pipeline and output.
// Default 48-bit accumulation safely covers 256 full-range int16 products.
// One multiplier register separates multiplication from accumulation.
module kwt_dot_product #(
    parameter integer DATA_W = 16,
    parameter integer DATA_A_W = DATA_W,
    parameter integer DATA_B_W = DATA_W,
    parameter integer ACC_W = 48
) (
    input wire clk,
    input wire rst_n,
    input wire clear,
    input wire in_valid,
    output wire in_ready,
    input wire in_first,
    input wire in_last,
    input wire signed [DATA_A_W-1:0] in_a,
    input wire signed [DATA_B_W-1:0] in_b,
    output reg out_valid,
    input wire out_ready,
    output reg signed [ACC_W-1:0] out_data
);
    localparam integer PROD_W = DATA_A_W + DATA_B_W;
    reg product_valid, product_first, product_last;
    reg signed [PROD_W-1:0] product;
    reg signed [ACC_W-1:0] accumulator;
    wire output_available = !out_valid || out_ready;
    wire consume_product = product_valid && output_available;
    wire signed [ACC_W-1:0] extended_product =
        $signed({{(ACC_W-PROD_W){product[PROD_W-1]}}, product});
    wire signed [ACC_W-1:0] next_sum = product_first ?
        extended_product : accumulator + extended_product;

    assign in_ready = rst_n && !clear && (!product_valid || output_available);

    always @(posedge clk) begin
        if (!rst_n || clear) begin
            product_valid <= 1'b0;
            product_first <= 1'b0;
            product_last <= 1'b0;
            product <= '0;
            accumulator <= '0;
            out_valid <= 1'b0;
            out_data <= '0;
        end else begin
            if (out_valid && out_ready)
                out_valid <= 1'b0;
            if (consume_product) begin
                product_valid <= 1'b0;
                accumulator <= next_sum;
                if (product_last) begin
                    out_data <= next_sum;
                    out_valid <= 1'b1;
                end
            end
            if (in_valid && in_ready) begin
                product <= in_a * in_b;
                product_first <= in_first;
                product_last <= in_last;
                product_valid <= 1'b1;
            end
        end
    end
endmodule
