`timescale 1ns/1ps
// Full32B audio-arena transactions. Private per-line {producer_phase,counter}
// defeats rollback WITHIN one clip as well as cross-clip/epoch substitution.
// Static model words use the separate verified-page reader, never this path.
// No cipher/RAM/CPU verdict is instantiated: one outer CBC2 and A-pool ledger.
module trusted_audio_line_auth #(
 parameter [31:0] BASE=32'h3c000000,TAG_BASE=32'h3f000000,
 parameter integer FIRST_LINE=6400,LINE_COUNT=8151,
 parameter [31:0] MODEL_VERSION=2,COUNTER_LIMIT=24'hffffff,
 parameter integer CLOSED_BRIDGE_PHASE_READY=0
)(
 input wire clk,security_reset_n,cancel,authorized,key_valid,model_authorized,
 input wire [31:0] authorization_epoch,current_model_epoch,
 input wire [127:0] current_key_session,
 input wire clip_begin_valid,output wire clip_begin_ready,
 input wire [31:0] clip_session_id,clip_id,clip_epoch,clip_source_id,clip_generation,
 input wire clip_release,output wire clip_ready,output wire phase_active,
 input wire phase_valid,output wire phase_ready,input wire [7:0] phase_id,
 input wire cache_clean,
 input wire request_valid,output wire request_ready,input wire request_write,
 input wire [31:0] request_address,input wire [255:0] request_data,
 output wire response_valid,input wire response_ready,output wire response_error,
 output wire [255:0] response_data,output wire quiescent,output reg fault,
 output wire ledger_clear, input wire ledger_clear_ready,
 output wire ledger_request,input wire ledger_ready,output wire ledger_write,
 output wire [12:0] ledger_line,output wire [31:0] ledger_value,
 input wire ledger_response,input wire ledger_error,input wire [31:0] ledger_read_value,
 output wire ledger_response_ready,input wire ledger_quiescent,
 output wire memory_read_valid,input wire memory_read_ready,
 output wire memory_write_valid,input wire memory_write_ready,
 output wire [31:0] memory_data_address,memory_tag_address,
 output wire [255:0] memory_write_data,output wire [127:0] memory_write_tag,
 output wire [31:0] memory_write_mask,
 input wire memory_response_valid,memory_response_error,
 input wire [255:0] memory_response_data,input wire [127:0] memory_response_tag,
 input wire [31:0] memory_response_mask,input wire backend_quiescent,
 output wire mac_request,input wire mac_ready,output wire [127:0] mac_chain,
 output wire [255:0] mac_data,input wire mac_response_valid,mac_response_error,
 input wire [127:0] mac_tag,input wire mac_quiescent
);
 localparam IDLE=0,CLEAR=1,CLEAR_WAIT=2,READY=3,LOOKUP=4,LOOKUP_WAIT=5,
 MAC=6,MAC_WAIT=7,MEM_READ=8,MEM_READ_WAIT=9,MEM_WRITE=10,MEM_WRITE_WAIT=11,
 VERSION=12,VERSION_WAIT=13,REPORT=14;
 reg[3:0]state;reg initializing,writing,bad,aborted,prepared;
 reg[13:0]init_line;
 reg[31:0]session_id,frame_id,epoch,model_epoch,address,source_id,generation;
 reg[127:0]key_session,chain,tag;
 reg[7:0]current_phase;
 reg[31:0]version;
 reg[1:0]part;
 reg[255:0]data;
 reg[31:0]last_session,last_clip,last_epoch,last_generation;
 wire context_live=authorized&&key_valid&&model_authorized&&!cancel&&!aborted&&
  authorization_epoch==epoch&&current_model_epoch==model_epoch&&current_key_session==key_session;
 wire resources_quiet=backend_quiescent&&mac_quiescent&&ledger_quiescent;
 assign clip_begin_ready=state==IDLE&&resources_quiet&&authorized&&key_valid&&model_authorized&&
  current_key_session!=0&&current_model_epoch!=0&&!cancel;
 // This is the installed clip LEASE, not transaction-idle. It must remain
 // live during an admitted lookup/MAC/DDR operation; otherwise the private
 // cache bridge would cancel its own valid transaction on the next cycle.
 assign clip_ready=prepared&&context_live&&!fault;
 assign phase_active=clip_ready&&current_phase!=0;
 assign phase_ready=state==READY&&clip_ready&&cache_clean&&(CLOSED_BRIDGE_PHASE_READY!=0||!request_valid);
 // synthesis translate_off
 always @(posedge clk or negedge clk)if(security_reset_n&&CLOSED_BRIDGE_PHASE_READY!=0&&
  (cache_clean===1'b1)&&(request_valid!==1'b0))
  $fatal(1,"CLOSED_BRIDGE_PHASE_READY_PRECONDITION_VIOLATED");
 // synthesis translate_on
 assign request_ready=state==READY&&clip_ready&&current_phase!=0&&!phase_valid;
 assign response_valid=state==REPORT&&resources_quiet;
 assign response_error=bad||!context_live||fault;
 assign response_data=response_error?256'd0:data;
 assign quiescent=(state==IDLE||state==READY)&&resources_quiet;
 assign ledger_clear=state==CLEAR;
 assign ledger_request=state==LOOKUP||state==VERSION;
 assign ledger_write=state==VERSION;
 assign ledger_line=((address-BASE)>>5)-FIRST_LINE;
 assign ledger_value=version;
 assign ledger_response_ready=state==CLEAR_WAIT||state==LOOKUP_WAIT||state==VERSION_WAIT;
 assign memory_read_valid=state==MEM_READ;
 assign memory_write_valid=state==MEM_WRITE;
 assign memory_data_address=address;
 assign memory_tag_address=TAG_BASE+(address-BASE);
 assign memory_write_data=data;
 assign memory_write_tag=tag;
 assign memory_write_mask=32'hffffffff;
 wire[255:0]header0={32'h41554433,session_id,frame_id,epoch,key_session};
 wire[255:0]header1={MODEL_VERSION,model_epoch,address,version,32'ha2010020,32'hffffffff,source_id,generation};
 assign mac_request=state==MAC;
 assign mac_chain=part==0?128'd0:chain;
 assign mac_data=part==0?header0:part==1?header1:data;
 wire request_range=request_address[4:0]==0&&request_address>=BASE+FIRST_LINE*32&&
  request_address<BASE+(FIRST_LINE+LINE_COUNT)*32;
 wire fresh_clip=clip_session_id!=0&&clip_id!=0&&clip_generation!=0&&clip_epoch==authorization_epoch&&
  (clip_epoch>last_epoch||(clip_epoch==last_epoch&&
   (clip_session_id>last_session||(clip_session_id==last_session&&(clip_id>last_clip||(clip_id==last_clip&&clip_generation>last_generation))))));
 task reject_transaction;
  begin bad<=1;fault<=1;prepared<=0;state<=REPORT;end
 endtask
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=IDLE;initializing<=0;writing<=0;bad<=0;aborted<=0;prepared<=0;fault<=0;init_line<=0;
   session_id<=0;frame_id<=0;epoch<=0;model_epoch<=0;address<=0;key_session<=0;
   chain<=0;tag<=0;current_phase<=0;version<=0;part<=0;data<=0;
   last_session<=0;last_clip<=0;last_epoch<=0;last_generation<=0;source_id<=0;generation<=0;
  end else begin
   if(state!=IDLE&&!context_live)begin aborted<=1;prepared<=0;end
   case(state)
    IDLE:if(clip_begin_valid&&clip_begin_ready)begin
     session_id<=clip_session_id;frame_id<=clip_id;source_id<=clip_source_id;generation<=clip_generation;epoch<=clip_epoch;model_epoch<=current_model_epoch;key_session<=current_key_session;
     bad<=0;aborted<=0;prepared<=0;current_phase<=0;fault<=0;initializing<=1;writing<=1;part<=0;chain<=0;data<=0;version<=32'h00000001;
     init_line<=FIRST_LINE;address<=BASE+FIRST_LINE*32;
     if(!fresh_clip)begin bad<=1;fault<=1;state<=REPORT;end
     else begin last_session<=clip_session_id;last_clip<=clip_id;last_epoch<=clip_epoch;last_generation<=clip_generation;state<=CLEAR;end
    end
    CLEAR:if(!context_live&&ledger_quiescent)reject_transaction;
     else if(ledger_clear_ready)state<=CLEAR_WAIT;
    CLEAR_WAIT:if(ledger_response)begin
     if(ledger_error||!context_live)reject_transaction;
     else begin part<=0;chain<=0;state<=MAC;end
    end
    READY:begin
     if(clip_release&&resources_quiet&&cache_clean&&!request_valid)begin prepared<=0;state<=IDLE;end
     else if(phase_valid&&phase_ready)begin
      if(phase_id<=current_phase||phase_id==0)begin fault<=1;prepared<=0;end
      else current_phase<=phase_id;
     end else if(request_valid&&request_ready)begin
      address<=request_address;writing<=request_write;data<=request_data;bad<=0;initializing<=0;
      if(!request_range)reject_transaction;else state<=LOOKUP;
     end
    end
    LOOKUP:if(!context_live&&ledger_quiescent)reject_transaction;
     else if(ledger_ready)state<=LOOKUP_WAIT;
    LOOKUP_WAIT:if(ledger_response)begin
     if(ledger_error||!context_live)reject_transaction;
     else if(writing)begin
      if(ledger_read_value[31:24]>current_phase||
       (ledger_read_value[31:24]==current_phase&&ledger_read_value[23:0]==COUNTER_LIMIT))reject_transaction;
      else begin
       version<={current_phase,ledger_read_value[31:24]==current_phase?ledger_read_value[23:0]+24'd1:24'd1};
       part<=0;chain<=0;state<=MAC;
      end
     end else if(ledger_read_value==0)reject_transaction;
     else begin version<=ledger_read_value;state<=MEM_READ;end
    end
    MEM_READ:if(memory_read_ready)state<=MEM_READ_WAIT;
    MEM_READ_WAIT:if(memory_response_valid)begin
     if(memory_response_error||memory_response_mask!=32'hffffffff||!context_live)reject_transaction;
     else begin data<=memory_response_data;tag<=memory_response_tag;part<=0;chain<=0;state<=MAC;end
    end
    MAC:if(mac_ready)state<=MAC_WAIT;
    MAC_WAIT:if(mac_response_valid)begin
     if(mac_response_error||!context_live)reject_transaction;
     else if(part<2)begin chain<=mac_tag;part<=part+1;state<=MAC;end
     else if(!writing)begin if(mac_tag!=tag)reject_transaction;else state<=REPORT;end
     else begin tag<=mac_tag;state<=MEM_WRITE;end
    end
    MEM_WRITE:if(memory_write_ready)state<=MEM_WRITE_WAIT;
    MEM_WRITE_WAIT:if(memory_response_valid)begin
     if(memory_response_error||!context_live)reject_transaction;
     else state<=VERSION;
    end
    VERSION:if(!context_live&&ledger_quiescent)reject_transaction;
     else if(ledger_ready)state<=VERSION_WAIT;
    VERSION_WAIT:if(ledger_response)begin
     if(ledger_error||!context_live)reject_transaction;
     else if(initializing)begin
      if(init_line==FIRST_LINE+LINE_COUNT-1)begin initializing<=0;prepared<=1;state<=READY;end
      else begin init_line<=init_line+1;address<=address+32;data<=0;version<=32'h00000001;part<=0;chain<=0;state<=MAC;end
     end else state<=REPORT;
    end
    REPORT:if(response_valid&&response_ready)begin
     if(initializing||aborted||!context_live)begin prepared<=0;state<=IDLE;end
     else state<=READY;
    end
    default:reject_transaction;
   endcase
  end
 end
 // synthesis translate_off
 initial if(FIRST_LINE<0||LINE_COUNT<1||LINE_COUNT>8192||FIRST_LINE+LINE_COUNT>16384)
  $fatal(1,"audio dynamic ledger range exceeds physical512KiB");
 // synthesis translate_on
endmodule
