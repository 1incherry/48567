`timescale 1ns/1ps
// Candidate: actual legacy numerical cache + typed96/privately versioned DDR path.
module trusted_audio_typed_ddr_cache #(parameter FIRST_LINE=6400,LINE_COUNT=8138)(
input wire clk,security_reset_n,cache_reset_n,cancel,authorized,key_valid,model_authorized,
input wire [31:0] authorization_epoch,current_model_epoch,input wire [127:0]current_key_session,
input wire clip_begin_valid,output wire clip_begin_ready,input wire [31:0]clip_session_id,clip_id,clip_epoch,clip_source_id,clip_generation,
input wire clip_release,output wire clip_ready,phase_active,
input wire phase_valid,output wire phase_ready,input wire [7:0]phase_id,
input wire client_active,flush,invalidate,commit,output wire clean,step,flush_done,cache_idle,
input wire a_en,a_we,b_en,b_we,input wire [16:0]a_addr,b_addr,input wire [31:0]a_data,b_data,input wire [3:0]a_strobe,
output wire [31:0]a_q,b_q,misses,writebacks,stalls,
output wire quiescent,transport_quiescent,fault,
input wire pool_granted,output wire pool_request,pool_read,pool_write,
output wire [11:0]pool_read_address,pool_write_address,input wire [255:0]pool_read_data,output wire [255:0]pool_write_data,
output wire mac_request,output wire [127:0]mac_chain,output wire [255:0]mac_data,
input wire mac_ready,mac_response_valid,mac_response_error,input wire [127:0]mac_tag,input wire mac_quiescent,
output wire [31:0] M_AXI_ARADDR,
output wire [7:0] M_AXI_ARLEN,
output wire [2:0] M_AXI_ARSIZE,
output wire [1:0] M_AXI_ARBURST,
output wire  M_AXI_ARVALID,
input wire  M_AXI_ARREADY,
input wire [255:0] M_AXI_RDATA,
input wire [1:0] M_AXI_RRESP,
input wire  M_AXI_RLAST,
input wire  M_AXI_RVALID,
output wire  M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,
output wire [7:0] M_AXI_AWLEN,
output wire [2:0] M_AXI_AWSIZE,
output wire [1:0] M_AXI_AWBURST,
output wire  M_AXI_AWVALID,
input wire  M_AXI_AWREADY,
output wire [255:0] M_AXI_WDATA,
output wire [31:0] M_AXI_WSTRB,
output wire  M_AXI_WLAST,
output wire  M_AXI_WVALID,
input wire  M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,
input wire  M_AXI_BVALID,
output wire  M_AXI_BREADY
);
wire c_clk;
wire c_rst_n;
wire c_client_active;
wire c_flush;
wire c_invalidate;
wire c_commit;
wire c_clean;
wire c_step;
wire c_flush_done;
wire c_fault;
wire c_a_en;
wire c_a_we;
wire c_b_en;
wire c_b_we;
wire [16:0] c_a_addr;
wire [16:0] c_b_addr;
wire [31:0] c_a_data;
wire [31:0] c_b_data;
wire [3:0] c_a_strobe;
wire [31:0] c_a_q;
wire [31:0] c_b_q;
wire [31:0] c_araddr;
wire [7:0] c_arlen;
wire [2:0] c_arsize;
wire [1:0] c_arburst;
wire c_arvalid;
wire c_arready;
wire [255:0] c_rdata;
wire [1:0] c_rresp;
wire c_rlast;
wire c_rvalid;
wire c_rready;
wire [31:0] c_awaddr;
wire [7:0] c_awlen;
wire [2:0] c_awsize;
wire [1:0] c_awburst;
wire c_awvalid;
wire c_awready;
wire [255:0] c_wdata;
wire [31:0] c_wstrb;
wire c_wlast;
wire c_wvalid;
wire c_wready;
wire [1:0] c_bresp;
wire c_bvalid;
wire c_bready;
wire [31:0] c_misses;
wire [31:0] c_writebacks;
wire [31:0] c_stalls;
wire c_idle;
wire b_clk;
wire b_security_reset_n;
wire b_cancel;
wire b_admission_live;
wire [31:0] b_S_ARADDR;
wire [7:0] b_S_ARLEN;
wire [2:0] b_S_ARSIZE;
wire [1:0] b_S_ARBURST;
wire b_S_ARVALID;
wire b_S_ARREADY;
wire [255:0] b_S_RDATA;
wire [1:0] b_S_RRESP;
wire b_S_RLAST;
wire b_S_RVALID;
wire b_S_RREADY;
wire [31:0] b_S_AWADDR;
wire [7:0] b_S_AWLEN;
wire [2:0] b_S_AWSIZE;
wire [1:0] b_S_AWBURST;
wire b_S_AWVALID;
wire b_S_AWREADY;
wire [255:0] b_S_WDATA;
wire [31:0] b_S_WSTRB;
wire b_S_WLAST;
wire b_S_WVALID;
wire b_S_WREADY;
wire [1:0] b_S_BRESP;
wire b_S_BVALID;
wire b_S_BREADY;
wire b_request_valid;
wire b_request_ready;
wire b_request_write;
wire [31:0] b_request_address;
wire [255:0] b_request_data;
wire b_response_valid;
wire b_response_ready;
wire b_response_error;
wire [255:0] b_response_data;
wire b_quiescent;
wire b_fault;
wire g_clk;
wire g_security_reset_n;
wire g_cancel;
wire g_authorized;
wire g_key_valid;
wire g_model_authorized;
wire [31:0] g_authorization_epoch;
wire [31:0] g_current_model_epoch;
wire [127:0] g_current_key_session;
wire g_clip_begin_valid;
wire g_clip_begin_ready;
wire [31:0] g_clip_session_id;
wire [31:0] g_clip_id;
wire [31:0] g_clip_epoch;
wire [31:0] g_clip_source_id;
wire [31:0] g_clip_generation;
wire g_clip_release;
wire g_clip_ready;
wire g_phase_active;
wire g_phase_valid;
wire g_phase_ready;
wire [7:0] g_phase_id;
wire g_cache_clean;
wire g_request_valid;
wire g_request_ready;
wire g_request_write;
wire [31:0] g_request_address;
wire [255:0] g_request_data;
wire g_response_valid;
wire g_response_ready;
wire g_response_error;
wire [255:0] g_response_data;
wire g_quiescent;
wire g_fault;
wire g_ledger_clear;
wire g_ledger_clear_ready;
wire g_ledger_request;
wire g_ledger_ready;
wire g_ledger_write;
wire [12:0] g_ledger_line;
wire [31:0] g_ledger_value;
wire g_ledger_response;
wire g_ledger_error;
wire [31:0] g_ledger_read_value;
wire g_ledger_response_ready;
wire g_ledger_quiescent;
wire g_memory_read_valid;
wire g_memory_read_ready;
wire g_memory_write_valid;
wire g_memory_write_ready;
wire [31:0] g_memory_data_address;
wire [31:0] g_memory_tag_address;
wire [255:0] g_memory_write_data;
wire [127:0] g_memory_write_tag;
wire [31:0] g_memory_write_mask;
wire g_memory_response_valid;
wire g_memory_response_error;
wire [255:0] g_memory_response_data;
wire [127:0] g_memory_response_tag;
wire [31:0] g_memory_response_mask;
wire g_backend_quiescent;
wire g_mac_request;
wire g_mac_ready;
wire [127:0] g_mac_chain;
wire [255:0] g_mac_data;
wire g_mac_response_valid;
wire g_mac_response_error;
wire [127:0] g_mac_tag;
wire g_mac_quiescent;
wire l_clk;
wire l_security_reset_n;
wire l_cancel;
wire l_pool_granted;
wire l_clear_valid;
wire l_clear_ready;
wire l_request_valid;
wire l_request_ready;
wire l_request_write;
wire [12:0] l_request_line;
wire [31:0] l_request_value;
wire l_response_valid;
wire l_response_ready;
wire l_response_error;
wire [31:0] l_response_value;
wire l_quiescent;
wire l_fault;
wire l_pool_read;
wire [11:0] l_pool_read_address;
wire [255:0] l_pool_read_data;
wire l_pool_write;
wire [11:0] l_pool_write_address;
wire [255:0] l_pool_write_data;
wire m_clk;
wire m_rst_n;
wire m_read_valid;
wire m_read_ready;
wire m_write_valid;
wire m_write_ready;
wire [31:0] m_data_address;
wire [31:0] m_tag_address;
wire [255:0] m_write_data;
wire [127:0] m_write_tag;
wire [31:0] m_write_mask;
wire m_response_valid;
wire m_response_error;
wire [255:0] m_response_data;
wire [127:0] m_response_tag;
wire [31:0] m_response_mask;
wire m_quiescent;
wire [31:0] m_M_AXI_ARADDR;
wire [7:0] m_M_AXI_ARLEN;
wire [2:0] m_M_AXI_ARSIZE;
wire [1:0] m_M_AXI_ARBURST;
wire m_M_AXI_ARVALID;
wire m_M_AXI_ARREADY;
wire [255:0] m_M_AXI_RDATA;
wire [1:0] m_M_AXI_RRESP;
wire m_M_AXI_RLAST;
wire m_M_AXI_RVALID;
wire m_M_AXI_RREADY;
wire [31:0] m_M_AXI_AWADDR;
wire [7:0] m_M_AXI_AWLEN;
wire [2:0] m_M_AXI_AWSIZE;
wire [1:0] m_M_AXI_AWBURST;
wire m_M_AXI_AWVALID;
wire m_M_AXI_AWREADY;
wire [255:0] m_M_AXI_WDATA;
wire [31:0] m_M_AXI_WSTRB;
wire m_M_AXI_WLAST;
wire m_M_AXI_WVALID;
wire m_M_AXI_WREADY;
wire [1:0] m_M_AXI_BRESP;
wire m_M_AXI_BVALID;
wire m_M_AXI_BREADY;
assign clean=c_clean;
assign flush_done=c_flush_done;
assign a_q=c_a_q;
assign b_q=c_b_q;
assign misses=c_misses;
assign writebacks=c_writebacks;
assign stalls=c_stalls;
assign cache_idle=c_idle;
assign step=c_step&&phase_active;
assign clip_begin_ready=g_clip_begin_ready;
assign phase_ready=g_phase_ready;
assign fault=c_fault||b_fault||g_fault||l_fault;
assign clip_ready=g_clip_ready&&!c_fault&&!b_fault&&!l_fault;
assign phase_active=g_phase_active&&!c_fault&&!b_fault&&!l_fault;
assign transport_quiescent=b_quiescent&&g_quiescent&&l_quiescent&&m_quiescent&&mac_quiescent;
assign quiescent=transport_quiescent&&c_idle&&c_clean;
assign pool_request=g_ledger_clear||g_ledger_request||!l_quiescent;
assign pool_read=l_pool_read;
assign pool_write=l_pool_write;
assign pool_read_address=l_pool_read_address;
assign pool_write_address=l_pool_write_address;
assign pool_write_data=l_pool_write_data;
assign mac_request=g_mac_request;
assign mac_chain=g_mac_chain;
assign mac_data=g_mac_data;
assign M_AXI_ARADDR=m_M_AXI_ARADDR;
assign M_AXI_ARLEN=m_M_AXI_ARLEN;
assign M_AXI_ARSIZE=m_M_AXI_ARSIZE;
assign M_AXI_ARBURST=m_M_AXI_ARBURST;
assign M_AXI_ARVALID=m_M_AXI_ARVALID;
assign M_AXI_RREADY=m_M_AXI_RREADY;
assign M_AXI_AWADDR=m_M_AXI_AWADDR;
assign M_AXI_AWLEN=m_M_AXI_AWLEN;
assign M_AXI_AWSIZE=m_M_AXI_AWSIZE;
assign M_AXI_AWBURST=m_M_AXI_AWBURST;
assign M_AXI_AWVALID=m_M_AXI_AWVALID;
assign M_AXI_WDATA=m_M_AXI_WDATA;
assign M_AXI_WSTRB=m_M_AXI_WSTRB;
assign M_AXI_WLAST=m_M_AXI_WLAST;
assign M_AXI_WVALID=m_M_AXI_WVALID;
assign M_AXI_BREADY=m_M_AXI_BREADY;
assign c_clk=clk;
assign c_rst_n=security_reset_n&&cache_reset_n;
assign c_client_active=client_active&&phase_active;
assign c_flush=flush;
assign c_invalidate=invalidate;
assign c_commit=commit&&phase_active;
assign c_a_en=a_en;
assign c_a_we=a_we;
assign c_b_en=b_en;
assign c_b_we=b_we;
assign c_a_addr=a_addr;
assign c_b_addr=b_addr;
assign c_a_data=a_data;
assign c_b_data=b_data;
assign c_a_strobe=a_strobe;
assign c_arready=b_S_ARREADY;
assign c_rdata=b_S_RDATA;
assign c_rresp=b_S_RRESP;
assign c_rlast=b_S_RLAST;
assign c_rvalid=b_S_RVALID;
assign c_awready=b_S_AWREADY;
assign c_wready=b_S_WREADY;
assign c_bresp=b_S_BRESP;
assign c_bvalid=b_S_BVALID;
audio_ddr_cache #(.BASE(32'h3c000000),.PIPELINED_COMMIT(1)) u_c(
.clk(c_clk),
.rst_n(c_rst_n),
.client_active(c_client_active),
.flush(c_flush),
.invalidate(c_invalidate),
.commit(c_commit),
.clean(c_clean),
.step(c_step),
.flush_done(c_flush_done),
.fault(c_fault),
.a_en(c_a_en),
.a_we(c_a_we),
.b_en(c_b_en),
.b_we(c_b_we),
.a_addr(c_a_addr),
.b_addr(c_b_addr),
.a_data(c_a_data),
.b_data(c_b_data),
.a_strobe(c_a_strobe),
.a_q(c_a_q),
.b_q(c_b_q),
.araddr(c_araddr),
.arlen(c_arlen),
.arsize(c_arsize),
.arburst(c_arburst),
.arvalid(c_arvalid),
.arready(c_arready),
.rdata(c_rdata),
.rresp(c_rresp),
.rlast(c_rlast),
.rvalid(c_rvalid),
.rready(c_rready),
.awaddr(c_awaddr),
.awlen(c_awlen),
.awsize(c_awsize),
.awburst(c_awburst),
.awvalid(c_awvalid),
.awready(c_awready),
.wdata(c_wdata),
.wstrb(c_wstrb),
.wlast(c_wlast),
.wvalid(c_wvalid),
.wready(c_wready),
.bresp(c_bresp),
.bvalid(c_bvalid),
.bready(c_bready),
.misses(c_misses),
.writebacks(c_writebacks),
.stalls(c_stalls),
.idle(c_idle));
assign b_clk=clk;
assign b_security_reset_n=security_reset_n;
assign b_cancel=cancel;
assign b_admission_live=phase_active;
assign b_S_ARADDR=c_araddr;
assign b_S_ARLEN=c_arlen;
assign b_S_ARSIZE=c_arsize;
assign b_S_ARBURST=c_arburst;
assign b_S_ARVALID=c_arvalid;
assign b_S_RREADY=c_rready;
assign b_S_AWADDR=c_awaddr;
assign b_S_AWLEN=c_awlen;
assign b_S_AWSIZE=c_awsize;
assign b_S_AWBURST=c_awburst;
assign b_S_AWVALID=c_awvalid;
assign b_S_WDATA=c_wdata;
assign b_S_WSTRB=c_wstrb;
assign b_S_WLAST=c_wlast;
assign b_S_WVALID=c_wvalid;
assign b_S_BREADY=c_bready;
assign b_request_ready=g_request_ready;
assign b_response_valid=g_response_valid;
assign b_response_error=g_response_error;
assign b_response_data=g_response_data;
trusted_audio_cache_line_bridge u_b(
.clk(b_clk),
.security_reset_n(b_security_reset_n),
.cancel(b_cancel),
.admission_live(b_admission_live),
.S_ARADDR(b_S_ARADDR),
.S_ARLEN(b_S_ARLEN),
.S_ARSIZE(b_S_ARSIZE),
.S_ARBURST(b_S_ARBURST),
.S_ARVALID(b_S_ARVALID),
.S_ARREADY(b_S_ARREADY),
.S_RDATA(b_S_RDATA),
.S_RRESP(b_S_RRESP),
.S_RLAST(b_S_RLAST),
.S_RVALID(b_S_RVALID),
.S_RREADY(b_S_RREADY),
.S_AWADDR(b_S_AWADDR),
.S_AWLEN(b_S_AWLEN),
.S_AWSIZE(b_S_AWSIZE),
.S_AWBURST(b_S_AWBURST),
.S_AWVALID(b_S_AWVALID),
.S_AWREADY(b_S_AWREADY),
.S_WDATA(b_S_WDATA),
.S_WSTRB(b_S_WSTRB),
.S_WLAST(b_S_WLAST),
.S_WVALID(b_S_WVALID),
.S_WREADY(b_S_WREADY),
.S_BRESP(b_S_BRESP),
.S_BVALID(b_S_BVALID),
.S_BREADY(b_S_BREADY),
.request_valid(b_request_valid),
.request_ready(b_request_ready),
.request_write(b_request_write),
.request_address(b_request_address),
.request_data(b_request_data),
.response_valid(b_response_valid),
.response_ready(b_response_ready),
.response_error(b_response_error),
.response_data(b_response_data),
.quiescent(b_quiescent),
.fault(b_fault));
assign g_clk=clk;
assign g_security_reset_n=security_reset_n;
assign g_cancel=cancel;
assign g_authorized=authorized;
assign g_key_valid=key_valid;
assign g_model_authorized=model_authorized;
assign g_authorization_epoch=authorization_epoch;
assign g_current_model_epoch=current_model_epoch;
assign g_current_key_session=current_key_session;
assign g_clip_begin_valid=clip_begin_valid;
assign g_clip_session_id=clip_session_id;
assign g_clip_id=clip_id;
assign g_clip_epoch=clip_epoch;
assign g_clip_source_id=clip_source_id;
assign g_clip_generation=clip_generation;
assign g_clip_release=clip_release;
assign g_phase_valid=phase_valid;
assign g_phase_id=phase_id;
assign g_cache_clean=c_clean&&b_quiescent&&m_quiescent&&l_quiescent&&mac_quiescent;
assign g_request_valid=b_request_valid;
assign g_request_write=b_request_write;
assign g_request_address=b_request_address;
assign g_request_data=b_request_data;
assign g_response_ready=b_response_ready;
assign g_ledger_clear_ready=l_clear_ready;
assign g_ledger_ready=l_request_ready;
assign g_ledger_response=l_response_valid;
assign g_ledger_error=l_response_error;
assign g_ledger_read_value=l_response_value;
assign g_ledger_quiescent=l_quiescent;
assign g_memory_read_ready=m_read_ready;
assign g_memory_write_ready=m_write_ready;
assign g_memory_response_valid=m_response_valid;
assign g_memory_response_error=m_response_error;
assign g_memory_response_data=m_response_data;
assign g_memory_response_tag=m_response_tag;
assign g_memory_response_mask=m_response_mask;
assign g_backend_quiescent=m_quiescent;
assign g_mac_ready=mac_ready;
assign g_mac_response_valid=mac_response_valid;
assign g_mac_response_error=mac_response_error;
assign g_mac_tag=mac_tag;
assign g_mac_quiescent=mac_quiescent;
trusted_audio_line_auth #(.FIRST_LINE(FIRST_LINE),.LINE_COUNT(LINE_COUNT)) u_g(
.clk(g_clk),
.security_reset_n(g_security_reset_n),
.cancel(g_cancel),
.authorized(g_authorized),
.key_valid(g_key_valid),
.model_authorized(g_model_authorized),
.authorization_epoch(g_authorization_epoch),
.current_model_epoch(g_current_model_epoch),
.current_key_session(g_current_key_session),
.clip_begin_valid(g_clip_begin_valid),
.clip_begin_ready(g_clip_begin_ready),
.clip_session_id(g_clip_session_id),
.clip_id(g_clip_id),
.clip_epoch(g_clip_epoch),
.clip_source_id(g_clip_source_id),
.clip_generation(g_clip_generation),
.clip_release(g_clip_release),
.clip_ready(g_clip_ready),
.phase_active(g_phase_active),
.phase_valid(g_phase_valid),
.phase_ready(g_phase_ready),
.phase_id(g_phase_id),
.cache_clean(g_cache_clean),
.request_valid(g_request_valid),
.request_ready(g_request_ready),
.request_write(g_request_write),
.request_address(g_request_address),
.request_data(g_request_data),
.response_valid(g_response_valid),
.response_ready(g_response_ready),
.response_error(g_response_error),
.response_data(g_response_data),
.quiescent(g_quiescent),
.fault(g_fault),
.ledger_clear(g_ledger_clear),
.ledger_clear_ready(g_ledger_clear_ready),
.ledger_request(g_ledger_request),
.ledger_ready(g_ledger_ready),
.ledger_write(g_ledger_write),
.ledger_line(g_ledger_line),
.ledger_value(g_ledger_value),
.ledger_response(g_ledger_response),
.ledger_error(g_ledger_error),
.ledger_read_value(g_ledger_read_value),
.ledger_response_ready(g_ledger_response_ready),
.ledger_quiescent(g_ledger_quiescent),
.memory_read_valid(g_memory_read_valid),
.memory_read_ready(g_memory_read_ready),
.memory_write_valid(g_memory_write_valid),
.memory_write_ready(g_memory_write_ready),
.memory_data_address(g_memory_data_address),
.memory_tag_address(g_memory_tag_address),
.memory_write_data(g_memory_write_data),
.memory_write_tag(g_memory_write_tag),
.memory_write_mask(g_memory_write_mask),
.memory_response_valid(g_memory_response_valid),
.memory_response_error(g_memory_response_error),
.memory_response_data(g_memory_response_data),
.memory_response_tag(g_memory_response_tag),
.memory_response_mask(g_memory_response_mask),
.backend_quiescent(g_backend_quiescent),
.mac_request(g_mac_request),
.mac_ready(g_mac_ready),
.mac_chain(g_mac_chain),
.mac_data(g_mac_data),
.mac_response_valid(g_mac_response_valid),
.mac_response_error(g_mac_response_error),
.mac_tag(g_mac_tag),
.mac_quiescent(g_mac_quiescent));
assign l_clk=clk;
assign l_security_reset_n=security_reset_n;
assign l_cancel=cancel;
assign l_pool_granted=pool_granted;
assign l_clear_valid=g_ledger_clear;
assign l_request_valid=g_ledger_request;
assign l_request_write=g_ledger_write;
assign l_request_line=g_ledger_line;
assign l_request_value=g_ledger_value;
assign l_response_ready=g_ledger_response_ready;
assign l_pool_read_data=pool_read_data;
trusted_audio_version_pool u_l(
.clk(l_clk),
.security_reset_n(l_security_reset_n),
.cancel(l_cancel),
.pool_granted(l_pool_granted),
.clear_valid(l_clear_valid),
.clear_ready(l_clear_ready),
.request_valid(l_request_valid),
.request_ready(l_request_ready),
.request_write(l_request_write),
.request_line(l_request_line),
.request_value(l_request_value),
.response_valid(l_response_valid),
.response_ready(l_response_ready),
.response_error(l_response_error),
.response_value(l_response_value),
.quiescent(l_quiescent),
.fault(l_fault),
.pool_read(l_pool_read),
.pool_read_address(l_pool_read_address),
.pool_read_data(l_pool_read_data),
.pool_write(l_pool_write),
.pool_write_address(l_pool_write_address),
.pool_write_data(l_pool_write_data));
assign m_clk=clk;
assign m_rst_n=security_reset_n;
assign m_read_valid=g_memory_read_valid;
assign m_write_valid=g_memory_write_valid;
assign m_data_address=g_memory_data_address;
assign m_tag_address=g_memory_tag_address;
assign m_write_data=g_memory_write_data;
assign m_write_tag=g_memory_write_tag;
assign m_write_mask=g_memory_write_mask;
assign m_M_AXI_ARREADY=M_AXI_ARREADY;
assign m_M_AXI_RDATA=M_AXI_RDATA;
assign m_M_AXI_RRESP=M_AXI_RRESP;
assign m_M_AXI_RLAST=M_AXI_RLAST;
assign m_M_AXI_RVALID=M_AXI_RVALID;
assign m_M_AXI_AWREADY=M_AXI_AWREADY;
assign m_M_AXI_WREADY=M_AXI_WREADY;
assign m_M_AXI_BRESP=M_AXI_BRESP;
assign m_M_AXI_BVALID=M_AXI_BVALID;
trusted_tensor_axi_backend u_m(
.clk(m_clk),
.rst_n(m_rst_n),
.read_valid(m_read_valid),
.read_ready(m_read_ready),
.write_valid(m_write_valid),
.write_ready(m_write_ready),
.data_address(m_data_address),
.tag_address(m_tag_address),
.write_data(m_write_data),
.write_tag(m_write_tag),
.write_mask(m_write_mask),
.response_valid(m_response_valid),
.response_error(m_response_error),
.response_data(m_response_data),
.response_tag(m_response_tag),
.response_mask(m_response_mask),
.quiescent(m_quiescent),
.M_AXI_ARADDR(m_M_AXI_ARADDR),
.M_AXI_ARLEN(m_M_AXI_ARLEN),
.M_AXI_ARSIZE(m_M_AXI_ARSIZE),
.M_AXI_ARBURST(m_M_AXI_ARBURST),
.M_AXI_ARVALID(m_M_AXI_ARVALID),
.M_AXI_ARREADY(m_M_AXI_ARREADY),
.M_AXI_RDATA(m_M_AXI_RDATA),
.M_AXI_RRESP(m_M_AXI_RRESP),
.M_AXI_RLAST(m_M_AXI_RLAST),
.M_AXI_RVALID(m_M_AXI_RVALID),
.M_AXI_RREADY(m_M_AXI_RREADY),
.M_AXI_AWADDR(m_M_AXI_AWADDR),
.M_AXI_AWLEN(m_M_AXI_AWLEN),
.M_AXI_AWSIZE(m_M_AXI_AWSIZE),
.M_AXI_AWBURST(m_M_AXI_AWBURST),
.M_AXI_AWVALID(m_M_AXI_AWVALID),
.M_AXI_AWREADY(m_M_AXI_AWREADY),
.M_AXI_WDATA(m_M_AXI_WDATA),
.M_AXI_WSTRB(m_M_AXI_WSTRB),
.M_AXI_WLAST(m_M_AXI_WLAST),
.M_AXI_WVALID(m_M_AXI_WVALID),
.M_AXI_WREADY(m_M_AXI_WREADY),
.M_AXI_BRESP(m_M_AXI_BRESP),
.M_AXI_BVALID(m_M_AXI_BVALID),
.M_AXI_BREADY(m_M_AXI_BREADY));
endmodule
