// One result slot per cycle, four registered stages to SRAM write.
// The bias response arrives one cycle after the input slot's memory request.
// End tokens propagate through masked tail slots without causing writes.
module kwt_matmul_output_pipeline(
    input wire clk,rst_n,clear,in_issue,in_valid,in_end,has_bias,
    input wire signed [47:0] accumulator,
    input wire signed [7:0] shift,
    input wire [5:0] output_bits,
    input wire [16:0] address,
    input wire signed [31:0] bias_response,
    output wire write_valid,out_end,
    output wire [16:0] write_address,
    output wire signed [31:0] write_data
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
    reg [3:0] valid,end_token;
    reg [16:0] addr0,addr1,addr2,addr3;
    reg signed [47:0] sum0;
    reg signed [7:0] shift0;
    reg [5:0] bits0,bits1,bits2;
    reg bias0;
    reg signed [63:0] rounded1,added2;
    reg signed [31:0] beta1,data3;
    assign write_valid=valid[3]&&rst_n&&!clear;
    assign out_end=end_token[3]&&rst_n&&!clear;
    assign write_address=addr3;
    assign write_data=data3;
    always @(posedge clk) begin
        if(!rst_n||clear) begin
            valid<=0;end_token<=0;addr0<=0;addr1<=0;addr2<=0;addr3<=0;
            sum0<=0;shift0<=0;bits0<=0;bits1<=0;bits2<=0;bias0<=0;
            rounded1<=0;beta1<=0;added2<=0;data3<=0;
        end else begin
            valid<={valid[2:0],in_issue&&in_valid};
            end_token<={end_token[2:0],in_issue&&in_end};
            if(in_issue) begin
                sum0<=accumulator;shift0<=shift;bits0<=output_bits;
                bias0<=has_bias;addr0<=address;
            end
            if(valid[0]||end_token[0]) begin
                rounded1<=kwt_round64($signed({{16{sum0[47]}},sum0}),shift0);
                beta1<=bias0?bias_response:32'sd0;bits1<=bits0;addr1<=addr0;
            end
            if(valid[1]||end_token[1]) begin
                added2<=rounded1+$signed({{32{beta1[31]}},beta1});bits2<=bits1;addr2<=addr1;
            end
            if(valid[2]||end_token[2]) begin
                data3<=kwt_sat32(added2,$signed({26'd0,bits2}));addr3<=addr2;
            end
        end
    end
endmodule
