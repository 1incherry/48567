`timescale 1ns/1ps
// One 512-point complex FFT, real input, bit-reversed loading and nine
// normalized radix2 passes. Each pass issues one butterfly per clock.
// Two 512x64 synchronous dual-port memories alternate source/destination.
// Input is already windowed and normalized; its per-frame exponent travels
// with the frame. Coefficients are frozen Q30, rounding matches software.
module kwt_audio_fft512 #(
    parameter TWIDDLE_FILE="model/audio_twiddle_q30.hex"
) (
    input wire clk,rst_n,clear,start,
    input wire [5:0] input_fraction,
    input wire in_valid,
    output wire in_ready,
    input wire signed [31:0] in_real,
    output wire out_valid,
    input wire out_ready,
    output wire signed [31:0] out_real,out_imag,
    output wire [8:0] out_index,
    output wire [5:0] out_fraction,
    output wire busy,
    output reg done,overflow
);
    localparam IDLE=0,LOAD=1,PREP=2,RUN=3,READ_OUT=4,WAIT_OUT=5,HOLD_OUT=6;
    reg [2:0] state;
    reg [8:0] load_index,issue_index,output_index;
    reg [3:0] stage;
    reg source_bank;
    reg [5:0] frame_fraction;
    reg [63:0] twiddle[0:255];
    initial $readmemh(TWIDDLE_FILE,twiddle);
    function automatic [8:0] reverse9(input [8:0] value);
        integer k;
        begin for(k=0;k<9;k=k+1)reverse9[k]=value[8-k];end
    endfunction
    wire live=rst_n&&!clear;
    assign busy=state!=IDLE;
    assign in_ready=live&&state==LOAD;
    assign out_valid=live&&state==HOLD_OUT;
    assign out_index=output_index;
    assign out_fraction=frame_fraction-6'd9;
    reg signed [31:0] result_real,result_imag;
    assign out_real=result_real;assign out_imag=result_imag;
    wire issue=live&&state==RUN&&issue_index<9'd256;
    wire [8:0] half_length=9'd1<<stage;
    wire [8:0] j=issue_index&(half_length-9'd1);
    wire [8:0] address_a=((issue_index>>stage)<<(stage+1))|j;
    wire [8:0] address_b=address_a+half_length;
    wire [7:0] twiddle_index=j<<(8-stage);
    reg read_pending,last_pending;
    reg [8:0] a_pending,b_pending;
    reg signed [31:0] cosine,sine;
    // Separate synchronous RAM + bank selection from the 32x32 multiplier.
    // A direct BRAM-to-DSP cascade missed the FPGA 150MHz target by0.187ns.
    reg operand_valid,operand_last;
    reg signed [31:0] operand_ar,operand_ai,operand_br,operand_bi,operand_cos,operand_sin;
    reg [8:0] operand_a,operand_b;
    reg a0_en,a0_we,b0_en,b0_we,a1_en,a1_we,b1_en,b1_we;
    reg [8:0] a0_addr,b0_addr,a1_addr,b1_addr;
    reg [63:0] a0_data,b0_data,a1_data,b1_data;
    wire [63:0] a0_q,b0_q,a1_q,b1_q;
    wire [63:0] src_a=source_bank?a1_q:a0_q;
    wire [63:0] src_b=source_bank?b1_q:b0_q;
    wire butterfly_valid,butterfly_last,butterfly_overflow;
    wire [8:0] write_a,write_b;
    wire signed [31:0] yr0,yi0,yr1,yi1;
    kwt_audio_fft_butterfly butterfly(
        .clk(clk),.rst_n(rst_n),.clear(clear||state==PREP),
        .in_valid(operand_valid&&state==RUN),
        .ar(operand_ar),.ai(operand_ai),.br(operand_br),.bi(operand_bi),
        .cosine(operand_cos),.sine(operand_sin),.address_a(operand_a),.address_b(operand_b),.in_last(operand_last),
        .out_valid(butterfly_valid),.out_last(butterfly_last),
        .out_address_a(write_a),.out_address_b(write_b),
        .yr0(yr0),.yi0(yi0),.yr1(yr1),.yi1(yi1),.overflow(butterfly_overflow));
    kwt_audio_fft_ram bank0(
        .clk(clk),.a_en(a0_en),.a_we(a0_we),.a_addr(a0_addr),.a_data(a0_data),.a_strobe(8'hff),.a_q(a0_q),
        .b_en(b0_en),.b_we(b0_we),.b_addr(b0_addr),.b_data(b0_data),.b_q(b0_q));
    kwt_audio_fft_ram bank1(
        .clk(clk),.a_en(a1_en),.a_we(a1_we),.a_addr(a1_addr),.a_data(a1_data),.a_strobe(8'hff),.a_q(a1_q),
        .b_en(b1_en),.b_we(b1_we),.b_addr(b1_addr),.b_data(b1_data),.b_q(b1_q));
    always @* begin
        a0_en=0;a0_we=0;b0_en=0;b0_we=0;a1_en=0;a1_we=0;b1_en=0;b1_we=0;
        a0_addr=0;b0_addr=0;a1_addr=0;b1_addr=0;
        a0_data=0;b0_data=0;a1_data=0;b1_data=0;
        if(live)begin
            if(state==LOAD&&in_valid)begin
                a0_en=1;a0_we=1;a0_addr=reverse9(load_index);a0_data={32'd0,in_real};
            end
            if(issue)begin
                if(source_bank)begin a1_en=1;b1_en=1;a1_addr=address_a;b1_addr=address_b;end
                else begin a0_en=1;b0_en=1;a0_addr=address_a;b0_addr=address_b;end
            end
            if(state==RUN&&butterfly_valid)begin
                if(source_bank)begin
                    a0_en=1;a0_we=1;b0_en=1;b0_we=1;
                    a0_addr=write_a;b0_addr=write_b;a0_data={yi0,yr0};b0_data={yi1,yr1};
                end else begin
                    a1_en=1;a1_we=1;b1_en=1;b1_we=1;
                    a1_addr=write_a;b1_addr=write_b;a1_data={yi0,yr0};b1_data={yi1,yr1};
                end
            end
            if(state==READ_OUT)begin
                if(source_bank)begin a1_en=1;a1_addr=output_index;end
                else begin a0_en=1;a0_addr=output_index;end
            end
        end
    end
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            state<=IDLE;load_index<=0;issue_index<=0;output_index<=0;stage<=0;source_bank<=0;
            frame_fraction<=0;read_pending<=0;last_pending<=0;a_pending<=0;b_pending<=0;
            cosine<=0;sine<=0;result_real<=0;result_imag<=0;done<=0;overflow<=0;
            operand_valid<=0;operand_last<=0;operand_ar<=0;operand_ai<=0;operand_br<=0;operand_bi<=0;
            operand_cos<=0;operand_sin<=0;operand_a<=0;operand_b<=0;
        end else begin
            done<=0;
            read_pending<=issue;
            operand_valid<=read_pending&&state==RUN;
            if(read_pending&&state==RUN)begin
                operand_ar<=src_a[31:0];operand_ai<=src_a[63:32];operand_br<=src_b[31:0];operand_bi<=src_b[63:32];
                operand_cos<=cosine;operand_sin<=sine;operand_a<=a_pending;operand_b<=b_pending;operand_last<=last_pending;
            end
            if(issue)begin
                a_pending<=address_a;b_pending<=address_b;last_pending<=issue_index==255;
                {sine,cosine}<=twiddle[twiddle_index];issue_index<=issue_index+1'b1;
            end
            if(state==RUN&&butterfly_overflow)overflow<=1;
            case(state)
                IDLE:if(start)begin
                    state<=LOAD;load_index<=0;frame_fraction<=input_fraction;source_bank<=0;
                    stage<=0;overflow<=0;output_index<=0;
                end
                LOAD:if(in_valid)begin
                    if(load_index==511)state<=PREP;
                    else load_index<=load_index+1'b1;
                end
                PREP:begin issue_index<=0;state<=RUN;end
                RUN:if(butterfly_last)begin
                    source_bank<=!source_bank;
                    if(stage==8)begin state<=READ_OUT;output_index<=0;end
                    else begin stage<=stage+1'b1;state<=PREP;end
                end
                READ_OUT:state<=WAIT_OUT;
                WAIT_OUT:begin result_real<=src_a[31:0];result_imag<=src_a[63:32];state<=HOLD_OUT;end
                HOLD_OUT:if(out_ready)begin
                    if(output_index==511)begin done<=1;state<=IDLE;end
                    else begin output_index<=output_index+1'b1;state<=READ_OUT;end
                end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
