`timescale 1ns/1ps
// Floor sqrt(unsigned64), restoring digit-by-digit, 32 cycles.
module kwt_sqrt64(
    input wire clk,rst_n,clear,start,
    input wire [63:0] radicand,
    output reg busy,valid,
    output reg [31:0] result
);
    reg [63:0] operand;
    reg [35:0] remainder;
    reg [31:0] root;
    reg [5:0] count;
    // Before each digit, remainder < 2*root+1; root is at most31 bits
    // before the final step. 36 bits retain the shifted trial exactly.
    wire [35:0] trial_rem={remainder[33:0],operand[63:62]};
    wire [35:0] divisor={2'b0,root,2'b01};
    wire take=trial_rem>=divisor;
    wire [35:0] next_rem=take?trial_rem-divisor:trial_rem;
    wire [31:0] next_root={root[30:0],take};
    always @(posedge clk) begin
        if(!rst_n||clear) begin busy<=0;valid<=0;result<=0;operand<=0;remainder<=0;root<=0;count<=0;end
        else begin
            valid<=0;
            if(start&&!busy) begin busy<=1;operand<=radicand;remainder<=0;root<=0;count<=0;end
            else if(busy) begin
                remainder<=next_rem;root<=next_root;operand<=operand<<2;count<=count+1;
                if(count==31) begin busy<=0;valid<=1;result<=next_root;end
            end
        end
    end
endmodule
