`default_nettype none
`include "audio105_profile_parameters.vh"
`timescale 1ns/1ps
// Candidate actual audio parent: no PS command, descriptor or label inputs.
// Root authority, protected epoch/key session and sole model/CBC/A services
// must come from the real enclosing trusted system, never success constants.
module trusted_audio_compute_parent #(parameter [63:0] CAPTURE_TIMEOUT_CYCLES=64'd30000000000, COMPUTE_TIMEOUT_CYCLES=64'd1000000000,parameter integer AUDIO_PARALLEL_CLOCK=0)(
 output wire [63:0] observation_post_pcm_cycles,
 input wire clk,security_reset_n,arith_reset_n,authorized,key_valid,model_authorized,cancel,trusted_clear_fault,service_protocol_violation,
 input wire [31:0]model_epoch,runtime_epoch,source_id,clip_id,generation,
 input wire [127:0]key_session_id,
 input wire start_valid,output wire start_ready,
 input wire pcm_valid,output wire pcm_ready,input wire [15:0]pcm_data,
 input wire [14:0]pcm_index,input wire pcm_last,input wire [287:0]pcm_context,
 input wire audio_pool_granted,output wire pool_requested,pool_read,pool_write,
 output wire [11:0]pool_read_address,pool_write_address,input wire [255:0]pool_read_data,output wire [255:0]pool_write_data,
 output wire mac_request,output wire [127:0]mac_chain,output wire [255:0]mac_data,
 input wire mac_ready,mac_response_valid,mac_response_error,input wire [127:0]mac_tag,input wire mac_quiescent,
 output wire fetch_valid,input wire fetch_ready,output wire [31:0]fetch_page_index,fetch_page_address,fetch_proof_address,
 output wire service_page_request,input wire service_page_ready,output wire [31:0]service_expected_page,
 input wire service_page_done,service_busy,service_fault,service_cache_valid,input wire [31:0]service_cached_page,
 output wire service_cache_read,output wire [9:0]service_cache_address,input wire service_cache_read_valid,input wire [31:0]service_cache_read_data,
 output wire busy,quiescent,done,result_visible,output reg fault,
 output wire [287:0]result_context,output wire [6:0]result_class,output wire [31:0]result_score,
 output wire result_commit_pulse,output wire [7:0]observation_phase,
 output wire observation_encoder_start,observation_encoder_done,
 output wire [31:0]M_AXI_ARADDR,output wire [7:0]M_AXI_ARLEN,output wire [2:0]M_AXI_ARSIZE,output wire [1:0]M_AXI_ARBURST,
 output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,input wire [255:0]M_AXI_RDATA,input wire [1:0]M_AXI_RRESP,input wire M_AXI_RLAST,M_AXI_RVALID,output wire M_AXI_RREADY,
 output wire [31:0]M_AXI_AWADDR,output wire [7:0]M_AXI_AWLEN,output wire [2:0]M_AXI_AWSIZE,output wire [1:0]M_AXI_AWBURST,
 output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,output wire [255:0]M_AXI_WDATA,output wire [31:0]M_AXI_WSTRB,output wire M_AXI_WLAST,M_AXI_WVALID,input wire M_AXI_WREADY,
 input wire [1:0]M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY,
 input wire trusted_core_clock_raw
);
localparam IDLE=0,CLIP=1,PHASE4=2,ENABLE=3,ENABLE_WAIT=4,FE_FIRST=5,FE_FIRST_WAIT=6,FE_LAST=7,FE_LAST_WAIT=8,
 SEED_READ=9,SEED_WAIT=10,SEED_WRITE=11,SEED_WRITE_WAIT=12,SEED_FLUSH=13,SEED_FLUSH_WAIT=14,
 FRONT_START=15,FRONT_WAIT=16,ENC_START=17,ENC_WAIT=18,HEAD_PHASE=19,HEAD_START=20,
 CLS_READ=21,CLS_READ_WAIT=22,CLS_SEND=23,HEAD_WAIT=24,COMMIT=25,FINISHED=26,DRAIN=27,CLEANUP=28,DRAIN_RESET=29,PROFILE_READ=30,PROFILE_WAIT=31;
reg[4:0]profile_index;wire profile_word_matches;
reg [4:0]state;reg[287:0]ctx;reg aborted,front_parameters;reg[5:0]seed_index,cls_index;
reg[31:0]seed_word,cls_word;reg[7:0]phase;
reg capture_finished;reg[63:0]compute_elapsed;reg[63:0]elapsed;reg[287:0]last_context;reg seen_context;
reg local_reset_n;reg[2:0]reset_ticks;reg typed_clip_armed;
wire functional_reset_n=security_reset_n&&local_reset_n;
wire[287:0]current_context={model_epoch,runtime_epoch,source_id,clip_id,generation,key_session_id};
wire active=state!=IDLE&&state!=FINISHED;
wire live=authorized&&key_valid&&model_authorized&&!cancel&&!aborted&&!fault&&ctx==current_context;
wire stopping=!live&&active;
assign observation_post_pcm_cycles=compute_elapsed;
wire deadline=active&&(capture_finished?compute_elapsed>=COMPUTE_TIMEOUT_CYCLES:elapsed>=CAPTURE_TIMEOUT_CYCLES);
wire admission_live=live&&!deadline;
wire fresh=!seen_context||runtime_epoch!=last_context[255:224]||key_session_id!=last_context[127:0]||generation>last_context[159:128];
wire[287:0]reader_context;
wire pipeline_quiet,external_transport_quiet,child_fault;
wire clip_accept=start_valid&&start_ready;
reg[2:0]bind_state;reg[8:0]bound_parameter_object;reg[287:0]bound_parameter_context;
reg[31:0]bind_first;reg bind_bad;
wire static_client0_request;
wire [8:0]static_client0_object;
wire [31:0]static_client0_index;
wire setup_static=state==PROFILE_READ||state==FE_FIRST||state==FE_LAST||state==SEED_READ;
wire parameter_static=bind_state==1||bind_state==3;
wire seed_bus=state==ENABLE||state==SEED_WRITE||state==CLS_READ;
wire seed_bus_wait=state==ENABLE_WAIT||state==SEED_WRITE_WAIT||state==CLS_READ_WAIT;
wire frontend_owner=state==FRONT_START||state==FRONT_WAIT;
wire encoder_owner=state==ENC_START||state==ENC_WAIT;
wire word_owner=!frontend_owner&&!encoder_owner;
wire flush_setup=state==SEED_FLUSH||state==SEED_FLUSH_WAIT;
wire flush_front=frontend_owner;
wire flush_encoder=encoder_owner;
wire  compute_clip_begin_valid;
wire  compute_clip_begin_ready;
wire [31:0] compute_clip_session_id;
wire  compute_clip_release;
wire  compute_clip_ready;
wire  compute_phase_active;
wire  compute_phase_valid;
wire  compute_phase_ready;
wire [7:0] compute_phase_id;
wire  compute_frontend_phase;
wire [8:0] compute_parameter_object;
wire [7:0] compute_trusted_current_phase;
wire [16:0] compute_allowed_a_base;
wire [16:0] compute_allowed_b_base;
wire [16:0] compute_allowed_bias_base;
wire [16:0] compute_allowed_write_base;
wire [17:0] compute_allowed_a_words;
wire [17:0] compute_allowed_b_words;
wire [17:0] compute_allowed_bias_words;
wire [17:0] compute_allowed_write_words;
wire  compute_request_range_fault;
wire  compute_trusted_flush_valid;
wire  compute_trusted_flush_ready;
wire  compute_trusted_flush_response_valid;
wire  compute_trusted_flush_response_ready;
wire  compute_trusted_flush_response_error;
wire [287:0] compute_trusted_flush_response_context;
wire  compute_transport_quiescent;
wire  compute_static_router_quiescent;
wire  compute_static_request_valid;
wire  compute_static_request_ready;
wire [8:0] compute_static_request_object;
wire [31:0] compute_static_request_word_index;
wire  compute_static_response_valid;
wire  compute_static_response_ready;
wire  compute_static_response_error;
wire [8:0] compute_static_response_object;
wire [31:0] compute_static_response_word_index;
wire [31:0] compute_static_response_data;
wire [287:0] compute_static_response_context;
wire  compute_static_quiescent;
wire  compute_kernel_core_ready;
wire  compute_kernel_pool_quiescent;
wire  compute_kernel_quiescent;
wire  compute_kernel_fault;
wire  compute_kernel_pool_write_valid;
wire  compute_kernel_pool_write_ready;
wire [11:0] compute_kernel_pool_write_address;
wire [255:0] compute_kernel_pool_write_data;
wire  compute_kernel_pool_read_request;
wire  compute_kernel_pool_read_enable;
wire  compute_kernel_pool_read_ready;
wire [11:0] compute_kernel_pool_read_address;
wire [255:0] compute_kernel_pool_read_data;
wire  compute_ledger_pool_granted;
wire  compute_ledger_pool_request;
wire  compute_ledger_pool_read;
wire  compute_ledger_pool_write;
wire [11:0] compute_ledger_pool_read_address;
wire [11:0] compute_ledger_pool_write_address;
wire [255:0] compute_ledger_pool_read_data;
wire [255:0] compute_ledger_pool_write_data;
wire  compute_mac_request;
wire [127:0] compute_mac_chain;
wire [255:0] compute_mac_data;
wire  compute_mac_ready;
wire  compute_mac_response_valid;
wire  compute_mac_response_error;
wire [127:0] compute_mac_tag;
wire  compute_mac_quiescent;
wire  compute_claim;
wire  compute_active;
wire  compute_busy;
wire  compute_irq;
wire  compute_diagnostic_cache_clean;
wire  compute_diagnostic_cache_idle;
wire  compute_diagnostic_cache_fault;
wire  compute_diagnostic_management_quiet;
wire [20:0] compute_s_axi_awaddr;
wire [2:0] compute_s_axi_awprot;
wire  compute_s_axi_awvalid;
wire  compute_s_axi_awready;
wire [31:0] compute_s_axi_wdata;
wire [3:0] compute_s_axi_wstrb;
wire  compute_s_axi_wvalid;
wire  compute_s_axi_wready;
wire [1:0] compute_s_axi_bresp;
wire  compute_s_axi_bvalid;
wire  compute_s_axi_bready;
wire [20:0] compute_s_axi_araddr;
wire [2:0] compute_s_axi_arprot;
wire  compute_s_axi_arvalid;
wire  compute_s_axi_arready;
wire [31:0] compute_s_axi_rdata;
wire [1:0] compute_s_axi_rresp;
wire  compute_s_axi_rvalid;
wire  compute_s_axi_rready;
wire [31:0] compute_M_AXI_ARADDR;
wire [7:0] compute_M_AXI_ARLEN;
wire [2:0] compute_M_AXI_ARSIZE;
wire [1:0] compute_M_AXI_ARBURST;
wire  compute_M_AXI_ARVALID;
wire  compute_M_AXI_ARREADY;
wire [255:0] compute_M_AXI_RDATA;
wire [1:0] compute_M_AXI_RRESP;
wire  compute_M_AXI_RLAST;
wire  compute_M_AXI_RVALID;
wire  compute_M_AXI_RREADY;
wire [31:0] compute_M_AXI_AWADDR;
wire [7:0] compute_M_AXI_AWLEN;
wire [2:0] compute_M_AXI_AWSIZE;
wire [1:0] compute_M_AXI_AWBURST;
wire  compute_M_AXI_AWVALID;
wire  compute_M_AXI_AWREADY;
wire [255:0] compute_M_AXI_WDATA;
wire [31:0] compute_M_AXI_WSTRB;
wire  compute_M_AXI_WLAST;
wire  compute_M_AXI_WVALID;
wire  compute_M_AXI_WREADY;
wire [1:0] compute_M_AXI_BRESP;
wire  compute_M_AXI_BVALID;
wire  compute_M_AXI_BREADY;
wire  frontend_trusted_clear_fault;
wire  frontend_start;
wire  frontend_start_ready;
wire  frontend_parameters_valid;
wire [287:0] frontend_parameters_context;
wire  frontend_typed_memory_ready;
wire [287:0] frontend_typed_memory_context;
wire  frontend_memory_quiescent;
wire  frontend_core_quiescent;
wire  frontend_pcm_valid;
wire  frontend_pcm_ready;
wire [15:0] frontend_pcm_data;
wire [14:0] frontend_pcm_index;
wire  frontend_pcm_last;
wire [287:0] frontend_pcm_context;
wire  frontend_flush_request;
wire  frontend_flush_ready;
wire [287:0] frontend_flush_context;
wire  frontend_flush_response_valid;
wire  frontend_flush_response_ready;
wire  frontend_flush_response_error;
wire [287:0] frontend_flush_response_context;
wire  frontend_sealed_seed_valid;
wire [287:0] frontend_sealed_seed_context;
wire  frontend_busy;
wire  frontend_quiescent;
wire  frontend_done;
wire  frontend_fault;
wire [31:0] frontend_committed_pcm_samples;
wire [20:0] frontend_m_awaddr;
wire [2:0] frontend_m_awprot;
wire  frontend_m_awvalid;
wire  frontend_m_awready;
wire [31:0] frontend_m_wdata;
wire [3:0] frontend_m_wstrb;
wire  frontend_m_wvalid;
wire  frontend_m_wready;
wire [1:0] frontend_m_bresp;
wire  frontend_m_bvalid;
wire  frontend_m_bready;
wire [20:0] frontend_m_araddr;
wire [2:0] frontend_m_arprot;
wire  frontend_m_arvalid;
wire  frontend_m_arready;
wire [31:0] frontend_m_rdata;
wire [1:0] frontend_m_rresp;
wire  frontend_m_rvalid;
wire  frontend_m_rready;
wire  encoder_start_valid;
wire  encoder_start_ready;
wire  encoder_sealed_seed_ready;
wire  encoder_typed_memory_available;
wire [287:0] encoder_sealed_seed_context;
wire [287:0] encoder_typed_memory_context;
wire  encoder_phase_request;
wire  encoder_phase_ready;
wire [7:0] encoder_phase_request_value;
wire [7:0] encoder_trusted_phase;
wire  encoder_phase_begin;
wire  encoder_phase_end;
wire [16:0] encoder_read_a_base;
wire [16:0] encoder_read_b_base;
wire [16:0] encoder_read_bias_base;
wire [16:0] encoder_write_base;
wire [17:0] encoder_read_a_words;
wire [17:0] encoder_read_b_words;
wire [17:0] encoder_read_bias_words;
wire [17:0] encoder_write_words;
wire [17:0] encoder_read_a_end,encoder_read_b_end,encoder_read_bias_end,encoder_write_end;
wire  encoder_busy;
wire  encoder_done;
wire  encoder_quiescent;
wire  encoder_fault;
wire [7:0] encoder_error_code;
wire [7:0] encoder_command_index;
wire [7:0] encoder_completed_commands;
wire [3:0] encoder_block_index;
wire [3:0] encoder_operation_index;
wire  encoder_engine_cancel;
wire  encoder_engine_quiescent;
wire  encoder_parameter_request;
wire  encoder_parameter_ready;
wire [8:0] encoder_parameter_object;
wire [287:0] encoder_parameter_context;
wire  encoder_parameter_response_valid;
wire  encoder_parameter_response_verified;
wire  encoder_parameter_response_ready;
wire [8:0] encoder_parameter_response_object;
wire [287:0] encoder_parameter_response_context;
wire  encoder_parameter_quiescent;
wire  encoder_flush_request;
wire  encoder_flush_ready;
wire  encoder_flush_done;
wire  encoder_flush_quiescent;
wire  encoder_static_request_valid;
wire  encoder_static_request_ready;
wire [8:0] encoder_static_request_object;
wire [31:0] encoder_static_request_word_index;
wire  encoder_static_response_valid;
wire  encoder_static_response_ready;
wire  encoder_static_response_error;
wire [8:0] encoder_static_response_object;
wire [31:0] encoder_static_response_word_index;
wire [31:0] encoder_static_response_data;
wire [287:0] encoder_static_response_context;
wire  encoder_static_quiescent;
wire [20:0] encoder_m_awaddr;
wire  encoder_m_awvalid;
wire  encoder_m_awready;
wire [31:0] encoder_m_wdata;
wire [3:0] encoder_m_wstrb;
wire  encoder_m_wvalid;
wire  encoder_m_wready;
wire [1:0] encoder_m_bresp;
wire  encoder_m_bvalid;
wire  encoder_m_bready;
wire [20:0] encoder_m_araddr;
wire  encoder_m_arvalid;
wire  encoder_m_arready;
wire [31:0] encoder_m_rdata;
wire [1:0] encoder_m_rresp;
wire  encoder_m_rvalid;
wire  encoder_m_rready;
wire  head_trusted_clear_fault;
wire  head_start;
wire  head_start_ready;
wire  head_cls_valid;
wire  head_cls_ready;
wire [5:0] head_cls_index;
wire [31:0] head_cls_data;
wire  head_cls_last;
wire  head_request_valid;
wire  head_request_ready;
wire [8:0] head_request_object;
wire [31:0] head_request_word_index;
wire  head_response_valid;
wire  head_response_ready;
wire  head_response_error;
wire [8:0] head_response_object;
wire [31:0] head_response_word_index;
wire [31:0] head_response_data;
wire [31:0] head_response_model_epoch;
wire [31:0] head_response_runtime_epoch;
wire [31:0] head_response_source_id;
wire [31:0] head_response_clip_id;
wire [31:0] head_response_generation;
wire [127:0] head_response_key_session_id;
wire  head_busy;
wire  head_quiescent;
wire  head_result_visible;
wire  head_done;
wire  head_fault;
wire [6:0] head_result_class;
wire [31:0] head_result_score;
wire [287:0] head_result_context;
wire  bank_trusted_clear_fault;
wire  bank_clip_start;
wire  bank_clip_ready;
wire  bank_pipeline_quiescent;
wire  bank_sealed_seed_valid;
wire [287:0] bank_sealed_seed_context;
wire  bank_encoder_start_accepted;
wire  bank_encoder_complete;
wire [287:0] bank_encoder_context;
wire  bank_commit_valid;
wire  bank_commit_ready;
wire [287:0] bank_commit_context;
wire [6:0] bank_commit_class;
wire [31:0] bank_commit_score;
wire  bank_commit_pulse;
wire  bank_fault;
wire  bank_visible;
wire [287:0] bank_result_context;
wire [6:0] bank_result_class;
wire [31:0] bank_result_score;
wire  wordbus_request_valid;
wire  wordbus_request_ready;
wire  wordbus_request_write;
wire [20:0] wordbus_request_address;
wire [31:0] wordbus_request_data;
wire  wordbus_response_valid;
wire  wordbus_response_ready;
wire  wordbus_response_error;
wire [31:0] wordbus_response_data;
wire  wordbus_quiescent;
wire [20:0] wordbus_m_awaddr;
wire  wordbus_m_awvalid;
wire  wordbus_m_awready;
wire [31:0] wordbus_m_wdata;
wire [3:0] wordbus_m_wstrb;
wire  wordbus_m_wvalid;
wire  wordbus_m_wready;
wire [1:0] wordbus_m_bresp;
wire  wordbus_m_bvalid;
wire  wordbus_m_bready;
wire [20:0] wordbus_m_araddr;
wire  wordbus_m_arvalid;
wire  wordbus_m_arready;
wire [31:0] wordbus_m_rdata;
wire [1:0] wordbus_m_rresp;
wire  wordbus_m_rvalid;
wire  wordbus_m_rready;
wire  reader_request_valid;
wire  reader_request_ready;
wire [8:0] reader_request_object;
wire [31:0] reader_request_word_index;
wire  reader_response_valid;
wire  reader_response_ready;
wire  reader_response_error;
wire [8:0] reader_response_object;
wire [31:0] reader_response_word_index;
wire [31:0] reader_response_data;
wire [31:0] reader_response_runtime_epoch;
wire [31:0] reader_response_model_epoch;
wire [31:0] reader_response_source_id;
wire [31:0] reader_response_clip_id;
wire [31:0] reader_response_generation;
wire [127:0] reader_response_key_session_id;
wire  reader_lease_request;
wire  reader_lease_ready;
wire [31:0] reader_lease_object;
wire [31:0] reader_lease_page;
wire [31:0] reader_lease_epoch;
wire  reader_lease_response_valid;
wire  reader_lease_verified;
wire [31:0] reader_lease_response_object;
wire [31:0] reader_lease_response_page;
wire [31:0] reader_lease_response_epoch;
wire  reader_lease_still_valid;
wire  reader_word_request;
wire  reader_word_ready;
wire [6:0] reader_word_offset;
wire  reader_word_response_valid;
wire [6:0] reader_word_response_offset;
wire [255:0] reader_word_response_data;
wire  reader_lease_release;
wire  reader_release_ready;
wire  reader_cache_quiescent;
wire  reader_quiescent;
wire  lease_lease_request;
wire  lease_lease_ready;
wire [31:0] lease_lease_object;
wire [31:0] lease_lease_page;
wire [31:0] lease_lease_epoch;
wire  lease_lease_response_valid;
wire  lease_lease_verified;
wire [31:0] lease_lease_response_object;
wire [31:0] lease_lease_response_page;
wire [31:0] lease_lease_response_epoch;
wire  lease_lease_still_valid;
wire  lease_word_request;
wire  lease_word_ready;
wire [6:0] lease_word_offset;
wire  lease_word_response_valid;
wire [6:0] lease_word_response_offset;
wire [255:0] lease_word_response_data;
wire  lease_lease_release;
wire  lease_release_ready;
wire  lease_cache_quiescent;
wire  lease_exclusive_page_lock;
wire  lease_fetch_valid;
wire  lease_fetch_ready;
wire [31:0] lease_fetch_page_index;
wire [31:0] lease_fetch_page_address;
wire [31:0] lease_fetch_proof_address;
wire  lease_service_page_request;
wire  lease_service_page_ready;
wire [31:0] lease_service_expected_page;
wire  lease_service_page_done;
wire  lease_service_busy;
wire  lease_service_fault;
wire  lease_service_cache_valid;
wire [31:0] lease_service_cached_page;
wire  lease_service_cache_read;
wire [9:0] lease_service_cache_address;
wire  lease_service_cache_read_valid;
wire [31:0] lease_service_cache_read_data;
wire [3:0] staticmux_client_request;
wire [3:0] staticmux_client_ready;
wire [35:0] staticmux_client_object;
wire [127:0] staticmux_client_index;
wire [3:0] staticmux_client_response;
wire [3:0] staticmux_client_response_ready;
wire  staticmux_response_error;
wire [8:0] staticmux_response_object;
wire [31:0] staticmux_response_index;
wire [31:0] staticmux_response_data;
wire [287:0] staticmux_response_context;
wire  staticmux_request_valid;
wire  staticmux_request_ready;
wire [8:0] staticmux_request_object;
wire [31:0] staticmux_request_index;
wire  staticmux_response_valid;
wire  staticmux_response_ready;
wire  staticmux_reader_response_error;
wire [8:0] staticmux_reader_response_object;
wire [31:0] staticmux_reader_response_index;
wire [31:0] staticmux_reader_response_data;
wire [287:0] staticmux_reader_response_context;
wire  staticmux_reader_quiescent;
wire  staticmux_quiescent;
wire  staticmux_fault;
wire  poolarb_kernel_pool_quiet;
wire  poolarb_kernel_write_valid;
wire  poolarb_kernel_read_request;
wire  poolarb_kernel_read_enable;
wire [11:0] poolarb_kernel_write_address;
wire [11:0] poolarb_kernel_read_address;
wire [255:0] poolarb_kernel_write_data;
wire  poolarb_kernel_write_ready;
wire  poolarb_kernel_read_ready;
wire  poolarb_ledger_request;
wire  poolarb_ledger_read;
wire  poolarb_ledger_write;
wire [11:0] poolarb_ledger_read_address;
wire [11:0] poolarb_ledger_write_address;
wire [255:0] poolarb_ledger_write_data;
wire  poolarb_ledger_granted;
wire  poolarb_pool_requested;
wire  poolarb_pool_read;
wire  poolarb_pool_write;
wire [11:0] poolarb_pool_read_address;
wire [11:0] poolarb_pool_write_address;
wire [255:0] poolarb_pool_write_data;
wire  poolarb_quiescent;
wire  poolarb_protocol_violation;
wire  poolarb_fault;
assign M_AXI_ARADDR=compute_M_AXI_ARADDR;
assign M_AXI_ARLEN=compute_M_AXI_ARLEN;
assign M_AXI_ARSIZE=compute_M_AXI_ARSIZE;
assign M_AXI_ARBURST=compute_M_AXI_ARBURST;
assign M_AXI_ARVALID=compute_M_AXI_ARVALID;
assign compute_M_AXI_ARREADY=M_AXI_ARREADY;
assign compute_M_AXI_RDATA=M_AXI_RDATA;
assign compute_M_AXI_RRESP=M_AXI_RRESP;
assign compute_M_AXI_RLAST=M_AXI_RLAST;
assign compute_M_AXI_RVALID=M_AXI_RVALID;
assign M_AXI_RREADY=compute_M_AXI_RREADY;
assign M_AXI_AWADDR=compute_M_AXI_AWADDR;
assign M_AXI_AWLEN=compute_M_AXI_AWLEN;
assign M_AXI_AWSIZE=compute_M_AXI_AWSIZE;
assign M_AXI_AWBURST=compute_M_AXI_AWBURST;
assign M_AXI_AWVALID=compute_M_AXI_AWVALID;
assign compute_M_AXI_AWREADY=M_AXI_AWREADY;
assign M_AXI_WDATA=compute_M_AXI_WDATA;
assign M_AXI_WSTRB=compute_M_AXI_WSTRB;
assign M_AXI_WLAST=compute_M_AXI_WLAST;
assign M_AXI_WVALID=compute_M_AXI_WVALID;
assign compute_M_AXI_WREADY=M_AXI_WREADY;
assign compute_M_AXI_BRESP=M_AXI_BRESP;
assign compute_M_AXI_BVALID=M_AXI_BVALID;
assign M_AXI_BREADY=compute_M_AXI_BREADY;
assign mac_request=compute_mac_request;
assign mac_chain=compute_mac_chain;
assign mac_data=compute_mac_data;
assign compute_mac_ready=mac_ready;
assign compute_mac_response_valid=mac_response_valid;
assign compute_mac_response_error=mac_response_error;
assign compute_mac_tag=mac_tag;
assign compute_mac_quiescent=mac_quiescent;
assign fetch_valid=lease_fetch_valid;
assign lease_fetch_ready=fetch_ready;
assign fetch_page_index=lease_fetch_page_index;
assign fetch_page_address=lease_fetch_page_address;
assign fetch_proof_address=lease_fetch_proof_address;
assign service_page_request=lease_service_page_request;
assign lease_service_page_ready=service_page_ready;
assign service_expected_page=lease_service_expected_page;
assign lease_service_page_done=service_page_done;
assign lease_service_busy=service_busy;
assign lease_service_fault=service_fault;
assign lease_service_cache_valid=service_cache_valid;
assign lease_service_cached_page=service_cached_page;
assign service_cache_read=lease_service_cache_read;
assign service_cache_address=lease_service_cache_address;
assign lease_service_cache_read_valid=service_cache_read_valid;
assign lease_service_cache_read_data=service_cache_read_data;
assign frontend_pcm_valid=pcm_valid;
assign pcm_ready=frontend_pcm_ready;
assign frontend_pcm_data=pcm_data;
assign frontend_pcm_index=pcm_index;
assign frontend_pcm_last=pcm_last;
assign frontend_pcm_context=pcm_context;
assign pool_requested=poolarb_pool_requested;
assign pool_read=poolarb_pool_read;
assign pool_write=poolarb_pool_write;
assign pool_read_address=poolarb_pool_read_address;
assign pool_write_address=poolarb_pool_write_address;
assign pool_write_data=poolarb_pool_write_data;
assign poolarb_kernel_pool_quiet=compute_kernel_pool_quiescent;
assign poolarb_kernel_write_valid=compute_kernel_pool_write_valid;
assign poolarb_kernel_read_request=compute_kernel_pool_read_request;
assign poolarb_kernel_read_enable=compute_kernel_pool_read_enable;
assign poolarb_kernel_write_address=compute_kernel_pool_write_address;
assign poolarb_kernel_read_address=compute_kernel_pool_read_address;
assign poolarb_kernel_write_data=compute_kernel_pool_write_data;
assign compute_kernel_pool_read_data=pool_read_data;
assign compute_ledger_pool_read_data=pool_read_data;
assign compute_kernel_pool_write_ready=poolarb_kernel_write_ready;
assign compute_kernel_pool_read_ready=poolarb_kernel_read_ready;
assign poolarb_ledger_request=compute_ledger_pool_request;
assign poolarb_ledger_read=compute_ledger_pool_read;
assign poolarb_ledger_write=compute_ledger_pool_write;
assign poolarb_ledger_read_address=compute_ledger_pool_read_address;
assign poolarb_ledger_write_address=compute_ledger_pool_write_address;
assign poolarb_ledger_write_data=compute_ledger_pool_write_data;
assign compute_ledger_pool_granted=poolarb_ledger_granted;
assign lease_lease_request=reader_lease_request;
assign lease_lease_object=reader_lease_object;
assign lease_lease_page=reader_lease_page;
assign lease_lease_epoch=reader_lease_epoch;
assign lease_word_request=reader_word_request;
assign lease_word_offset=reader_word_offset;
assign lease_lease_release=reader_lease_release;
assign reader_lease_ready=lease_lease_ready;
assign reader_lease_response_valid=lease_lease_response_valid;
assign reader_lease_verified=lease_lease_verified;
assign reader_lease_response_object=lease_lease_response_object;
assign reader_lease_response_page=lease_lease_response_page;
assign reader_lease_response_epoch=lease_lease_response_epoch;
assign reader_lease_still_valid=lease_lease_still_valid;
assign reader_word_ready=lease_word_ready;
assign reader_word_response_valid=lease_word_response_valid;
assign reader_word_response_offset=lease_word_response_offset;
assign reader_word_response_data=lease_word_response_data;
assign reader_release_ready=lease_release_ready;
assign reader_cache_quiescent=lease_cache_quiescent;
assign reader_request_valid=staticmux_request_valid;
assign reader_request_object=staticmux_request_object;
assign reader_request_word_index=staticmux_request_index;
trusted_audio_profile313_contract u_profile_contract(.word_index(profile_index),.candidate_word(staticmux_response_data),.word_equal(profile_word_matches));
assign staticmux_request_ready=reader_request_ready;
assign staticmux_response_valid=reader_response_valid;
assign reader_response_ready=staticmux_response_ready;
assign staticmux_reader_response_error=reader_response_error;
assign staticmux_reader_response_object=reader_response_object;
assign staticmux_reader_response_data=reader_response_data;
assign staticmux_reader_response_index=reader_response_word_index;
assign staticmux_reader_quiescent=reader_quiescent;
assign reader_context={reader_response_model_epoch,reader_response_runtime_epoch,reader_response_source_id,reader_response_clip_id,reader_response_generation,reader_response_key_session_id};
assign staticmux_reader_response_context=reader_context;
assign static_client0_request=(setup_static&&admission_live)||parameter_static;
assign static_client0_object=parameter_static?bound_parameter_object:state==PROFILE_READ?9'd313:state==SEED_READ?9'd309:9'd308;
assign static_client0_index=parameter_static?(bind_state==1?32'd0:32'd49791):state==PROFILE_READ?{27'd0,profile_index}:state==FE_LAST?32'd8959:state==SEED_READ?{26'd0,seed_index}:32'd0;
assign staticmux_client_request={head_request_valid,compute_static_request_valid,encoder_static_request_valid,static_client0_request};
assign staticmux_client_object={head_request_object,compute_static_request_object,encoder_static_request_object,static_client0_object};
assign staticmux_client_index={head_request_word_index,compute_static_request_word_index,encoder_static_request_word_index,static_client0_index};
assign encoder_static_request_ready=staticmux_client_ready[1];
assign encoder_static_response_valid=staticmux_client_response[1];
assign encoder_static_response_error=staticmux_response_error;
assign encoder_static_response_object=staticmux_response_object;
assign encoder_static_response_data=staticmux_response_data;
assign encoder_static_response_word_index=staticmux_response_index;
assign encoder_static_response_context=staticmux_response_context;
assign compute_static_request_ready=staticmux_client_ready[2];
assign compute_static_response_valid=staticmux_client_response[2];
assign compute_static_response_error=staticmux_response_error;
assign compute_static_response_object=staticmux_response_object;
assign compute_static_response_data=staticmux_response_data;
assign compute_static_response_word_index=staticmux_response_index;
assign compute_static_response_context=staticmux_response_context;
assign head_request_ready=staticmux_client_ready[3];
assign head_response_valid=staticmux_client_response[3];
assign head_response_error=staticmux_response_error;
assign head_response_object=staticmux_response_object;
assign head_response_data=staticmux_response_data;
assign head_response_word_index=staticmux_response_index;
assign head_response_model_epoch=staticmux_response_context[287:256];
assign head_response_runtime_epoch=staticmux_response_context[255:224];
assign head_response_source_id=staticmux_response_context[223:192];
assign head_response_clip_id=staticmux_response_context[191:160];
assign head_response_generation=staticmux_response_context[159:128];
assign head_response_key_session_id=staticmux_response_context[127:0];
// Cancellation retires only the actual old response already owned by the
// private mux. No new request is generated, no service quiet is fabricated,
// and every externally accepted lease/word operation still genuinely drains.
assign staticmux_client_response_ready=stopping?4'hf:{head_response_ready,compute_static_response_ready,encoder_static_response_ready,(state==PROFILE_WAIT||state==FE_FIRST_WAIT||state==FE_LAST_WAIT||state==SEED_WAIT||bind_state==2||bind_state==4)};
assign compute_static_quiescent=reader_quiescent;
assign encoder_static_quiescent=staticmux_quiescent;
assign compute_clip_begin_valid=state==CLIP&&admission_live;
assign compute_clip_session_id=32'd1;
assign compute_clip_release=state==FINISHED||stopping;
assign compute_phase_valid=admission_live&&(state==PHASE4||state==HEAD_PHASE||encoder_phase_request);
assign compute_phase_id=state==PHASE4?8'd4:state==HEAD_PHASE?8'd185:encoder_phase_request_value;
assign encoder_phase_ready=compute_phase_ready&&state==ENC_WAIT&&admission_live;
assign compute_frontend_phase=phase==4;
assign compute_parameter_object=bound_parameter_object;
assign compute_trusted_current_phase=phase;
assign compute_allowed_a_base=encoder_read_a_base;
assign compute_allowed_a_words=encoder_read_a_words;
assign compute_allowed_b_base=encoder_read_b_base;
assign compute_allowed_b_words=encoder_read_b_words;
assign compute_allowed_bias_base=encoder_read_bias_base;
assign compute_allowed_bias_words=encoder_read_bias_words;
assign compute_allowed_write_base=encoder_write_base;
assign compute_allowed_write_words=encoder_write_words;
assign frontend_trusted_clear_fault=trusted_clear_fault;
assign head_trusted_clear_fault=trusted_clear_fault;
assign bank_trusted_clear_fault=trusted_clear_fault;
assign frontend_start=state==FRONT_START&&admission_live;
assign frontend_parameters_valid=front_parameters&&live;
assign frontend_parameters_context=ctx;
assign frontend_typed_memory_ready=compute_clip_ready&&phase==4;
assign frontend_typed_memory_context=ctx;
assign frontend_memory_quiescent=compute_transport_quiescent&&compute_diagnostic_cache_idle&&staticmux_quiescent;
assign frontend_core_quiescent=!compute_busy&&compute_diagnostic_management_quiet;
assign encoder_start_valid=state==ENC_START&&admission_live;
assign encoder_sealed_seed_ready=frontend_sealed_seed_valid;
assign encoder_sealed_seed_context=frontend_sealed_seed_context;
assign encoder_typed_memory_available=compute_clip_ready;
assign encoder_typed_memory_context=ctx;
assign encoder_engine_quiescent=!compute_busy&&compute_diagnostic_management_quiet&&compute_kernel_pool_quiescent;
assign encoder_parameter_ready=bind_state==0&&state==ENC_WAIT&&admission_live;
assign encoder_parameter_response_valid=bind_state==5;
assign encoder_parameter_response_verified=!bind_bad&&live&&bound_parameter_context==ctx;
assign encoder_parameter_response_object=bound_parameter_object;
assign encoder_parameter_response_context=bound_parameter_context;
assign encoder_parameter_quiescent=bind_state==0;
assign wordbus_request_valid=seed_bus&&admission_live;
assign wordbus_request_write=state!=CLS_READ;
assign wordbus_request_address=state==ENABLE?21'h200:21'h100000+((state==CLS_READ?17'd51200+cls_index:17'd51200+seed_index)<<2);
assign wordbus_request_data=state==ENABLE?32'd1:seed_word;
assign wordbus_response_ready=seed_bus_wait;
assign head_start=state==HEAD_START&&admission_live;
assign head_cls_valid=state==CLS_SEND&&admission_live;
assign head_cls_index=cls_index;
assign head_cls_data=cls_word;
assign head_cls_last=cls_index==6'd63;
assign compute_trusted_flush_valid=(state==SEED_FLUSH&&admission_live)||(flush_front&&frontend_flush_request)||(flush_encoder&&encoder_flush_request);
assign frontend_flush_ready=compute_trusted_flush_ready&&flush_front;
assign frontend_flush_response_valid=compute_trusted_flush_response_valid&&flush_front;
assign frontend_flush_response_error=compute_trusted_flush_response_error;
assign frontend_flush_response_context=compute_trusted_flush_response_context;
assign encoder_flush_ready=compute_trusted_flush_ready&&flush_encoder;
assign encoder_flush_done=compute_trusted_flush_response_valid&&compute_trusted_flush_response_ready&&flush_encoder&&!compute_trusted_flush_response_error;
assign encoder_flush_quiescent=!compute_trusted_flush_response_valid&&compute_diagnostic_cache_idle&&compute_transport_quiescent;
assign compute_trusted_flush_response_ready=state==SEED_FLUSH_WAIT||(flush_front&&frontend_flush_response_ready)||flush_encoder;
assign pipeline_quiet=compute_transport_quiescent&&compute_diagnostic_cache_idle&&compute_diagnostic_cache_clean&&compute_diagnostic_management_quiet&&!compute_busy&&staticmux_quiescent&&head_quiescent&&wordbus_quiescent&&poolarb_quiescent&&bind_state==0;
assign external_transport_quiet=compute_transport_quiescent&&mac_quiescent&&reader_quiescent&&lease_cache_quiescent&&staticmux_quiescent&&poolarb_quiescent&&compute_kernel_pool_quiescent;
assign bank_clip_start=clip_accept;
assign bank_pipeline_quiescent=pipeline_quiet;
assign bank_sealed_seed_valid=frontend_sealed_seed_valid;
assign bank_sealed_seed_context=frontend_sealed_seed_context;
assign bank_encoder_start_accepted=encoder_start_valid&&encoder_start_ready;
assign bank_encoder_complete=encoder_done;
assign bank_encoder_context=ctx;
assign bank_commit_valid=state==COMMIT&&admission_live&&!child_fault&&head_result_visible;
assign bank_commit_context=head_result_context;
assign bank_commit_class=head_result_class;
assign bank_commit_score=head_result_score;
assign result_visible=!child_fault?bank_visible:'d0;
assign result_context=!child_fault?bank_result_context:'d0;
assign result_class=!child_fault?bank_result_class:'d0;
assign result_score=!child_fault?bank_result_score:'d0;
assign result_commit_pulse=!child_fault?bank_commit_pulse:'d0;
assign observation_phase=phase;
assign observation_encoder_start=encoder_start_valid&&encoder_start_ready;
assign observation_encoder_done=encoder_done;
assign quiescent=!active&&pipeline_quiet;
assign busy=active||!pipeline_quiet;
assign done=state==FINISHED&&bank_visible;
assign start_ready=(state==IDLE||state==FINISHED)&&pipeline_quiet&&bank_clip_ready&&authorized&&key_valid&&model_authorized&&!cancel&&!fault&&fresh;
assign compute_s_axi_awaddr=frontend_owner?frontend_m_awaddr:encoder_owner?encoder_m_awaddr:wordbus_m_awaddr;
assign compute_s_axi_awvalid=frontend_owner?frontend_m_awvalid:encoder_owner?encoder_m_awvalid:wordbus_m_awvalid;
assign compute_s_axi_wdata=frontend_owner?frontend_m_wdata:encoder_owner?encoder_m_wdata:wordbus_m_wdata;
assign compute_s_axi_wstrb=frontend_owner?frontend_m_wstrb:encoder_owner?encoder_m_wstrb:wordbus_m_wstrb;
assign compute_s_axi_wvalid=frontend_owner?frontend_m_wvalid:encoder_owner?encoder_m_wvalid:wordbus_m_wvalid;
assign compute_s_axi_bready=frontend_owner?frontend_m_bready:encoder_owner?encoder_m_bready:wordbus_m_bready;
assign compute_s_axi_araddr=frontend_owner?frontend_m_araddr:encoder_owner?encoder_m_araddr:wordbus_m_araddr;
assign compute_s_axi_arvalid=frontend_owner?frontend_m_arvalid:encoder_owner?encoder_m_arvalid:wordbus_m_arvalid;
assign compute_s_axi_rready=frontend_owner?frontend_m_rready:encoder_owner?encoder_m_rready:wordbus_m_rready;
assign compute_s_axi_awprot=3'd0;
assign compute_s_axi_arprot=3'd0;
assign frontend_m_awready=compute_s_axi_awready&&frontend_owner;
assign encoder_m_awready=compute_s_axi_awready&&encoder_owner;
assign wordbus_m_awready=compute_s_axi_awready&&word_owner;
assign frontend_m_wready=compute_s_axi_wready&&frontend_owner;
assign encoder_m_wready=compute_s_axi_wready&&encoder_owner;
assign wordbus_m_wready=compute_s_axi_wready&&word_owner;
assign frontend_m_bresp=compute_s_axi_bresp;
assign encoder_m_bresp=compute_s_axi_bresp;
assign wordbus_m_bresp=compute_s_axi_bresp;
assign frontend_m_bvalid=compute_s_axi_bvalid&&frontend_owner;
assign encoder_m_bvalid=compute_s_axi_bvalid&&encoder_owner;
assign wordbus_m_bvalid=compute_s_axi_bvalid&&word_owner;
assign frontend_m_arready=compute_s_axi_arready&&frontend_owner;
assign encoder_m_arready=compute_s_axi_arready&&encoder_owner;
assign wordbus_m_arready=compute_s_axi_arready&&word_owner;
assign frontend_m_rdata=compute_s_axi_rdata;
assign encoder_m_rdata=compute_s_axi_rdata;
assign wordbus_m_rdata=compute_s_axi_rdata;
assign frontend_m_rresp=compute_s_axi_rresp;
assign encoder_m_rresp=compute_s_axi_rresp;
assign wordbus_m_rresp=compute_s_axi_rresp;
assign frontend_m_rvalid=compute_s_axi_rvalid&&frontend_owner;
assign encoder_m_rvalid=compute_s_axi_rvalid&&encoder_owner;
assign wordbus_m_rvalid=compute_s_axi_rvalid&&word_owner;
trusted_audio_serial_compute #(.AUDIO_PARALLEL_CLOCK(AUDIO_PARALLEL_CLOCK),.USE_REGISTERED_INTERVAL_ENDS(1)) u_compute(
 .trusted_core_clock_raw(trusted_core_clock_raw),
 .clk(clk),
 .rst_n(arith_reset_n&&local_reset_n),
 .can_enable(live),
 .security_reset_n(security_reset_n),
 .cancel(stopping),
 .authorized(live),
 .key_valid(key_valid),
 .model_authorized(model_authorized),
 .authorization_epoch(ctx[255:224]),
 .current_model_epoch(ctx[287:256]),
 .source_id(ctx[223:192]),
 .clip_id(ctx[191:160]),
 .generation(ctx[159:128]),
 .current_key_session(ctx[127:0]),
 .clip_begin_valid(compute_clip_begin_valid),
 .clip_begin_ready(compute_clip_begin_ready),
 .clip_session_id(compute_clip_session_id),
 .clip_release(compute_clip_release),
 .clip_ready(compute_clip_ready),
 .phase_active(compute_phase_active),
 .phase_valid(compute_phase_valid),
 .phase_ready(compute_phase_ready),
 .phase_id(compute_phase_id),
 .frontend_phase(compute_frontend_phase),
 .parameter_object(compute_parameter_object),
 .trusted_current_phase(compute_trusted_current_phase),
 .allowed_a_base(compute_allowed_a_base),
 .allowed_b_base(compute_allowed_b_base),
 .allowed_bias_base(compute_allowed_bias_base),
 .allowed_write_base(compute_allowed_write_base),
 .allowed_a_words(compute_allowed_a_words),
 .allowed_b_words(compute_allowed_b_words),
 .allowed_bias_words(compute_allowed_bias_words),
 .allowed_write_words(compute_allowed_write_words),
 .allowed_a_end(encoder_read_a_end),.allowed_b_end(encoder_read_b_end),
 .allowed_bias_end(encoder_read_bias_end),.allowed_write_end(encoder_write_end),
 .request_range_fault(compute_request_range_fault),
 .trusted_flush_valid(compute_trusted_flush_valid),
 .trusted_flush_ready(compute_trusted_flush_ready),
 .trusted_flush_response_valid(compute_trusted_flush_response_valid),
 .trusted_flush_response_ready(compute_trusted_flush_response_ready),
 .trusted_flush_response_error(compute_trusted_flush_response_error),
 .trusted_flush_response_context(compute_trusted_flush_response_context),
 .transport_quiescent(compute_transport_quiescent),
 .static_router_quiescent(compute_static_router_quiescent),
 .static_request_valid(compute_static_request_valid),
 .static_request_ready(compute_static_request_ready),
 .static_request_object(compute_static_request_object),
 .static_request_word_index(compute_static_request_word_index),
 .static_response_valid(compute_static_response_valid),
 .static_response_ready(compute_static_response_ready),
 .static_response_error(compute_static_response_error),
 .static_response_object(compute_static_response_object),
 .static_response_word_index(compute_static_response_word_index),
 .static_response_data(compute_static_response_data),
 .static_response_context(compute_static_response_context),
 .static_quiescent(compute_static_quiescent),
 .kernel_owner_live(audio_pool_granted),
 .kernel_core_ready(compute_kernel_core_ready),
 .kernel_pool_quiescent(compute_kernel_pool_quiescent),
 .kernel_quiescent(compute_kernel_quiescent),
 .kernel_fault(compute_kernel_fault),
 .kernel_pool_write_valid(compute_kernel_pool_write_valid),
 .kernel_pool_write_ready(compute_kernel_pool_write_ready),
 .kernel_pool_write_address(compute_kernel_pool_write_address),
 .kernel_pool_write_data(compute_kernel_pool_write_data),
 .kernel_pool_read_request(compute_kernel_pool_read_request),
 .kernel_pool_read_enable(compute_kernel_pool_read_enable),
 .kernel_pool_read_ready(compute_kernel_pool_read_ready),
 .kernel_pool_read_address(compute_kernel_pool_read_address),
 .kernel_pool_read_data(compute_kernel_pool_read_data),
 .ledger_pool_granted(compute_ledger_pool_granted),
 .ledger_pool_request(compute_ledger_pool_request),
 .ledger_pool_read(compute_ledger_pool_read),
 .ledger_pool_write(compute_ledger_pool_write),
 .ledger_pool_read_address(compute_ledger_pool_read_address),
 .ledger_pool_write_address(compute_ledger_pool_write_address),
 .ledger_pool_read_data(compute_ledger_pool_read_data),
 .ledger_pool_write_data(compute_ledger_pool_write_data),
 .mac_request(compute_mac_request),
 .mac_chain(compute_mac_chain),
 .mac_data(compute_mac_data),
 .mac_ready(compute_mac_ready),
 .mac_response_valid(compute_mac_response_valid),
 .mac_response_error(compute_mac_response_error),
 .mac_tag(compute_mac_tag),
 .mac_quiescent(compute_mac_quiescent),
 .claim(compute_claim),
 .active(compute_active),
 .busy(compute_busy),
 .irq(compute_irq),
 .diagnostic_cache_clean(compute_diagnostic_cache_clean),
 .diagnostic_cache_idle(compute_diagnostic_cache_idle),
 .diagnostic_cache_fault(compute_diagnostic_cache_fault),
 .diagnostic_management_quiet(compute_diagnostic_management_quiet),
 .s_axi_awaddr(compute_s_axi_awaddr),
 .s_axi_awprot(compute_s_axi_awprot),
 .s_axi_awvalid(compute_s_axi_awvalid),
 .s_axi_awready(compute_s_axi_awready),
 .s_axi_wdata(compute_s_axi_wdata),
 .s_axi_wstrb(compute_s_axi_wstrb),
 .s_axi_wvalid(compute_s_axi_wvalid),
 .s_axi_wready(compute_s_axi_wready),
 .s_axi_bresp(compute_s_axi_bresp),
 .s_axi_bvalid(compute_s_axi_bvalid),
 .s_axi_bready(compute_s_axi_bready),
 .s_axi_araddr(compute_s_axi_araddr),
 .s_axi_arprot(compute_s_axi_arprot),
 .s_axi_arvalid(compute_s_axi_arvalid),
 .s_axi_arready(compute_s_axi_arready),
 .s_axi_rdata(compute_s_axi_rdata),
 .s_axi_rresp(compute_s_axi_rresp),
 .s_axi_rvalid(compute_s_axi_rvalid),
 .s_axi_rready(compute_s_axi_rready),
 .M_AXI_ARADDR(compute_M_AXI_ARADDR),
 .M_AXI_ARLEN(compute_M_AXI_ARLEN),
 .M_AXI_ARSIZE(compute_M_AXI_ARSIZE),
 .M_AXI_ARBURST(compute_M_AXI_ARBURST),
 .M_AXI_ARVALID(compute_M_AXI_ARVALID),
 .M_AXI_ARREADY(compute_M_AXI_ARREADY),
 .M_AXI_RDATA(compute_M_AXI_RDATA),
 .M_AXI_RRESP(compute_M_AXI_RRESP),
 .M_AXI_RLAST(compute_M_AXI_RLAST),
 .M_AXI_RVALID(compute_M_AXI_RVALID),
 .M_AXI_RREADY(compute_M_AXI_RREADY),
 .M_AXI_AWADDR(compute_M_AXI_AWADDR),
 .M_AXI_AWLEN(compute_M_AXI_AWLEN),
 .M_AXI_AWSIZE(compute_M_AXI_AWSIZE),
 .M_AXI_AWBURST(compute_M_AXI_AWBURST),
 .M_AXI_AWVALID(compute_M_AXI_AWVALID),
 .M_AXI_AWREADY(compute_M_AXI_AWREADY),
 .M_AXI_WDATA(compute_M_AXI_WDATA),
 .M_AXI_WSTRB(compute_M_AXI_WSTRB),
 .M_AXI_WLAST(compute_M_AXI_WLAST),
 .M_AXI_WVALID(compute_M_AXI_WVALID),
 .M_AXI_WREADY(compute_M_AXI_WREADY),
 .M_AXI_BRESP(compute_M_AXI_BRESP),
 .M_AXI_BVALID(compute_M_AXI_BVALID),
 .M_AXI_BREADY(compute_M_AXI_BREADY));
trusted_audio_pcm_frontend u_frontend(
 .clk(clk),
 .security_reset_n(functional_reset_n),
 .authorized(live),
 .cancel(stopping),
 .trusted_clear_fault(frontend_trusted_clear_fault),
 .model_epoch(ctx[287:256]),
 .runtime_epoch(ctx[255:224]),
 .source_id(ctx[223:192]),
 .clip_id(ctx[191:160]),
 .generation(ctx[159:128]),
 .key_session_id(ctx[127:0]),
 .start(frontend_start),
 .start_ready(frontend_start_ready),
 .parameters_valid(frontend_parameters_valid),
 .parameters_context(frontend_parameters_context),
 .typed_memory_ready(frontend_typed_memory_ready),
 .typed_memory_context(frontend_typed_memory_context),
 .memory_quiescent(frontend_memory_quiescent),
 .core_quiescent(frontend_core_quiescent),
 .pcm_valid(frontend_pcm_valid),
 .pcm_ready(frontend_pcm_ready),
 .pcm_data(frontend_pcm_data),
 .pcm_index(frontend_pcm_index),
 .pcm_last(frontend_pcm_last),
 .pcm_context(frontend_pcm_context),
 .flush_request(frontend_flush_request),
 .flush_ready(frontend_flush_ready),
 .flush_context(frontend_flush_context),
 .flush_response_valid(frontend_flush_response_valid),
 .flush_response_ready(frontend_flush_response_ready),
 .flush_response_error(frontend_flush_response_error),
 .flush_response_context(frontend_flush_response_context),
 .sealed_seed_valid(frontend_sealed_seed_valid),
 .sealed_seed_context(frontend_sealed_seed_context),
 .busy(frontend_busy),
 .quiescent(frontend_quiescent),
 .done(frontend_done),
 .fault(frontend_fault),
 .committed_pcm_samples(frontend_committed_pcm_samples),
 .m_awaddr(frontend_m_awaddr),
 .m_awprot(frontend_m_awprot),
 .m_awvalid(frontend_m_awvalid),
 .m_awready(frontend_m_awready),
 .m_wdata(frontend_m_wdata),
 .m_wstrb(frontend_m_wstrb),
 .m_wvalid(frontend_m_wvalid),
 .m_wready(frontend_m_wready),
 .m_bresp(frontend_m_bresp),
 .m_bvalid(frontend_m_bvalid),
 .m_bready(frontend_m_bready),
 .m_araddr(frontend_m_araddr),
 .m_arprot(frontend_m_arprot),
 .m_arvalid(frontend_m_arvalid),
 .m_arready(frontend_m_arready),
 .m_rdata(frontend_m_rdata),
 .m_rresp(frontend_m_rresp),
 .m_rvalid(frontend_m_rvalid),
 .m_rready(frontend_m_rready));
trusted_audio_encoder_sequence_phased u_encoder(
 .clk(clk),
 .rst_n(functional_reset_n),
 .cancel(stopping),
 .authorized(live),
 .model_epoch(ctx[287:256]),
 .runtime_epoch(ctx[255:224]),
 .source_id(ctx[223:192]),
 .clip_id(ctx[191:160]),
 .generation(ctx[159:128]),
 .key_session_id(ctx[127:0]),
 .start_valid(encoder_start_valid),
 .start_ready(encoder_start_ready),
 .sealed_seed_ready(encoder_sealed_seed_ready),
 .typed_memory_available(encoder_typed_memory_available),
 .sealed_seed_context(encoder_sealed_seed_context),
 .typed_memory_context(encoder_typed_memory_context),
 .phase_request(encoder_phase_request),
 .phase_ready(encoder_phase_ready),
 .phase_request_value(encoder_phase_request_value),
 .trusted_phase(encoder_trusted_phase),
 .phase_begin(encoder_phase_begin),
 .phase_end(encoder_phase_end),
 .read_a_base(encoder_read_a_base),
 .read_b_base(encoder_read_b_base),
 .read_bias_base(encoder_read_bias_base),
 .write_base(encoder_write_base),
 .read_a_words(encoder_read_a_words),
 .read_b_words(encoder_read_b_words),
 .read_bias_words(encoder_read_bias_words),
 .write_words(encoder_write_words),
 .read_a_end(encoder_read_a_end),.read_b_end(encoder_read_b_end),
 .read_bias_end(encoder_read_bias_end),.write_end(encoder_write_end),
 .busy(encoder_busy),
 .done(encoder_done),
 .quiescent(encoder_quiescent),
 .fault(encoder_fault),
 .error_code(encoder_error_code),
 .command_index(encoder_command_index),
 .completed_commands(encoder_completed_commands),
 .block_index(encoder_block_index),
 .operation_index(encoder_operation_index),
 .engine_cancel(encoder_engine_cancel),
 .engine_quiescent(encoder_engine_quiescent),
 .parameter_request(encoder_parameter_request),
 .parameter_ready(encoder_parameter_ready),
 .parameter_object(encoder_parameter_object),
 .parameter_context(encoder_parameter_context),
 .parameter_response_valid(encoder_parameter_response_valid),
 .parameter_response_verified(encoder_parameter_response_verified),
 .parameter_response_ready(encoder_parameter_response_ready),
 .parameter_response_object(encoder_parameter_response_object),
 .parameter_response_context(encoder_parameter_response_context),
 .parameter_quiescent(encoder_parameter_quiescent),
 .flush_request(encoder_flush_request),
 .flush_ready(encoder_flush_ready),
 .flush_done(encoder_flush_done),
 .flush_quiescent(encoder_flush_quiescent),
 .static_request_valid(encoder_static_request_valid),
 .static_request_ready(encoder_static_request_ready),
 .static_request_object(encoder_static_request_object),
 .static_request_word_index(encoder_static_request_word_index),
 .static_response_valid(encoder_static_response_valid),
 .static_response_ready(encoder_static_response_ready),
 .static_response_error(encoder_static_response_error),
 .static_response_object(encoder_static_response_object),
 .static_response_word_index(encoder_static_response_word_index),
 .static_response_data(encoder_static_response_data),
 .static_response_context(encoder_static_response_context),
 .static_quiescent(encoder_static_quiescent),
 .m_awaddr(encoder_m_awaddr),
 .m_awvalid(encoder_m_awvalid),
 .m_awready(encoder_m_awready),
 .m_wdata(encoder_m_wdata),
 .m_wstrb(encoder_m_wstrb),
 .m_wvalid(encoder_m_wvalid),
 .m_wready(encoder_m_wready),
 .m_bresp(encoder_m_bresp),
 .m_bvalid(encoder_m_bvalid),
 .m_bready(encoder_m_bready),
 .m_araddr(encoder_m_araddr),
 .m_arvalid(encoder_m_arvalid),
 .m_arready(encoder_m_arready),
 .m_rdata(encoder_m_rdata),
 .m_rresp(encoder_m_rresp),
 .m_rvalid(encoder_m_rvalid),
 .m_rready(encoder_m_rready));
wire head_logit_valid,head_logit_ready,head_logit_last;wire[6:0]head_logit_index;wire[31:0]head_logit_data;wire[287:0]head_logit_context;
trusted_audio_classifier_stream #(.FRACTION(`AUDIO105_CLS_FRACTION),.CLASSES(105),.CLASS_BITS(7)) u_head(
 .clk(clk),
 .security_reset_n(functional_reset_n),
 .authorized(live),
 .cancel(stopping),
 .trusted_clear_fault(head_trusted_clear_fault),
 .model_epoch(ctx[287:256]),
 .runtime_epoch(ctx[255:224]),
 .source_id(ctx[223:192]),
 .clip_id(ctx[191:160]),
 .generation(ctx[159:128]),
 .key_session_id(ctx[127:0]),
 .start(head_start),
 .start_ready(head_start_ready),
 .cls_valid(head_cls_valid),
 .cls_ready(head_cls_ready),
 .cls_index(head_cls_index),
 .cls_data(head_cls_data),
 .cls_last(head_cls_last),
 .request_valid(head_request_valid),
 .request_ready(head_request_ready),
 .request_object(head_request_object),
 .request_word_index(head_request_word_index),
 .response_valid(head_response_valid),
 .response_ready(head_response_ready),
 .response_error(head_response_error),
 .response_object(head_response_object),
 .response_word_index(head_response_word_index),
 .response_data(head_response_data),
 .response_model_epoch(head_response_model_epoch),
 .response_runtime_epoch(head_response_runtime_epoch),
 .response_source_id(head_response_source_id),
 .response_clip_id(head_response_clip_id),
 .response_generation(head_response_generation),
 .response_key_session_id(head_response_key_session_id),
 .busy(head_busy),
 .quiescent(head_quiescent),
 .result_visible(head_result_visible),
 .done(head_done),
 .fault(head_fault),
 .result_class(head_result_class),
 .result_score(head_result_score),
 .logit_valid(head_logit_valid),.logit_ready(head_logit_ready),.logit_index(head_logit_index),.logit_data(head_logit_data),.logit_last(head_logit_last),.logit_context(head_logit_context),
 .result_context(head_result_context));
trusted_audio_result_bank_stream #(.CLASSES(105),.CLASS_BITS(7)) u_bank(
 .clk(clk),
 .security_reset_n(security_reset_n),
 .authorized(authorized&&model_authorized),
 .key_valid(key_valid),
 .cancel(cancel||aborted||fault),
 .trusted_clear_fault(bank_trusted_clear_fault),
 .model_epoch(model_epoch),
 .runtime_epoch(runtime_epoch),
 .source_id(source_id),
 .clip_id(clip_id),
 .generation(generation),
 .key_session_id(key_session_id),
 .clip_start(bank_clip_start),
 .clip_ready(bank_clip_ready),
 .pipeline_quiescent(bank_pipeline_quiescent),
 .sealed_seed_valid(bank_sealed_seed_valid),
 .sealed_seed_context(bank_sealed_seed_context),
 .encoder_start_accepted(bank_encoder_start_accepted),
 .encoder_complete(bank_encoder_complete),
 .encoder_context(bank_encoder_context),
 .commit_valid(bank_commit_valid),
 .commit_ready(bank_commit_ready),
 .commit_context(bank_commit_context),
 .commit_class(bank_commit_class),
 .commit_score(bank_commit_score),
 .logit_valid(head_logit_valid),.logit_ready(head_logit_ready),.logit_index(head_logit_index),.logit_data(head_logit_data),.logit_last(head_logit_last),.logit_context(head_logit_context),
 .debug_read(1'b0),.debug_index(7'd0),.debug_valid(),.debug_data(),
 .commit_pulse(bank_commit_pulse),
 .fault(bank_fault),
 .visible(bank_visible),
 .result_context(bank_result_context),
 .result_class(bank_result_class),
 .result_score(bank_result_score));
trusted_audio_word_bus u_wordbus(
 .clk(clk),
 .security_reset_n(functional_reset_n),
 .request_valid(wordbus_request_valid),
 .request_ready(wordbus_request_ready),
 .request_write(wordbus_request_write),
 .request_address(wordbus_request_address),
 .request_data(wordbus_request_data),
 .response_valid(wordbus_response_valid),
 .response_ready(wordbus_response_ready),
 .response_error(wordbus_response_error),
 .response_data(wordbus_response_data),
 .quiescent(wordbus_quiescent),
 .m_awaddr(wordbus_m_awaddr),
 .m_awvalid(wordbus_m_awvalid),
 .m_awready(wordbus_m_awready),
 .m_wdata(wordbus_m_wdata),
 .m_wstrb(wordbus_m_wstrb),
 .m_wvalid(wordbus_m_wvalid),
 .m_wready(wordbus_m_wready),
 .m_bresp(wordbus_m_bresp),
 .m_bvalid(wordbus_m_bvalid),
 .m_bready(wordbus_m_bready),
 .m_araddr(wordbus_m_araddr),
 .m_arvalid(wordbus_m_arvalid),
 .m_arready(wordbus_m_arready),
 .m_rdata(wordbus_m_rdata),
 .m_rresp(wordbus_m_rresp),
 .m_rvalid(wordbus_m_rvalid),
 .m_rready(wordbus_m_rready));
trusted_audio_static_word_reader u_reader(
 .clk(clk),
 .rst_n(functional_reset_n),
 .cancel(stopping),
 .authorized(live),
 .runtime_epoch(ctx[255:224]),
 .model_epoch(ctx[287:256]),
 .source_id(ctx[223:192]),
 .clip_id(ctx[191:160]),
 .generation(ctx[159:128]),
 .key_session_id(ctx[127:0]),
 .request_valid(reader_request_valid),
 .request_ready(reader_request_ready),
 .request_object(reader_request_object),
 .request_word_index(reader_request_word_index),
 .response_valid(reader_response_valid),
 .response_ready(reader_response_ready),
 .response_error(reader_response_error),
 .response_object(reader_response_object),
 .response_word_index(reader_response_word_index),
 .response_data(reader_response_data),
 .response_runtime_epoch(reader_response_runtime_epoch),
 .response_model_epoch(reader_response_model_epoch),
 .response_source_id(reader_response_source_id),
 .response_clip_id(reader_response_clip_id),
 .response_generation(reader_response_generation),
 .response_key_session_id(reader_response_key_session_id),
 .lease_request(reader_lease_request),
 .lease_ready(reader_lease_ready),
 .lease_object(reader_lease_object),
 .lease_page(reader_lease_page),
 .lease_epoch(reader_lease_epoch),
 .lease_response_valid(reader_lease_response_valid),
 .lease_verified(reader_lease_verified),
 .lease_response_object(reader_lease_response_object),
 .lease_response_page(reader_lease_response_page),
 .lease_response_epoch(reader_lease_response_epoch),
 .lease_still_valid(reader_lease_still_valid),
 .word_request(reader_word_request),
 .word_ready(reader_word_ready),
 .word_offset(reader_word_offset),
 .word_response_valid(reader_word_response_valid),
 .word_response_offset(reader_word_response_offset),
 .word_response_data(reader_word_response_data),
 .lease_release(reader_lease_release),
 .release_ready(reader_release_ready),
 .cache_quiescent(reader_cache_quiescent),
 .quiescent(reader_quiescent));
trusted_audio_page_lease u_lease(
 .clk(clk),
 .rst_n(functional_reset_n),
 .cancel(stopping),
 .model_authorized(live),
 .session_epoch(ctx[255:224]),
 .lease_request(lease_lease_request),
 .lease_ready(lease_lease_ready),
 .lease_object(lease_lease_object),
 .lease_page(lease_lease_page),
 .lease_epoch(lease_lease_epoch),
 .lease_response_valid(lease_lease_response_valid),
 .lease_verified(lease_lease_verified),
 .lease_response_object(lease_lease_response_object),
 .lease_response_page(lease_lease_response_page),
 .lease_response_epoch(lease_lease_response_epoch),
 .lease_still_valid(lease_lease_still_valid),
 .word_request(lease_word_request),
 .word_ready(lease_word_ready),
 .word_offset(lease_word_offset),
 .word_response_valid(lease_word_response_valid),
 .word_response_offset(lease_word_response_offset),
 .word_response_data(lease_word_response_data),
 .lease_release(lease_lease_release),
 .release_ready(lease_release_ready),
 .cache_quiescent(lease_cache_quiescent),
 .exclusive_page_lock(lease_exclusive_page_lock),
 .fetch_valid(lease_fetch_valid),
 .fetch_ready(lease_fetch_ready),
 .fetch_page_index(lease_fetch_page_index),
 .fetch_page_address(lease_fetch_page_address),
 .fetch_proof_address(lease_fetch_proof_address),
 .service_page_request(lease_service_page_request),
 .service_page_ready(lease_service_page_ready),
 .service_expected_page(lease_service_expected_page),
 .service_page_done(lease_service_page_done),
 .service_busy(lease_service_busy),
 .service_fault(lease_service_fault),
 .service_cache_valid(lease_service_cache_valid),
 .service_cached_page(lease_service_cached_page),
 .service_cache_read(lease_service_cache_read),
 .service_cache_address(lease_service_cache_address),
 .service_cache_read_valid(lease_service_cache_read_valid),
 .service_cache_read_data(lease_service_cache_read_data));
trusted_audio_static_word_mux u_staticmux(
 .clk(clk),
 .security_reset_n(functional_reset_n),
 .client_request(staticmux_client_request),
 .client_ready(staticmux_client_ready),
 .client_object(staticmux_client_object),
 .client_index(staticmux_client_index),
 .client_response(staticmux_client_response),
 .client_response_ready(staticmux_client_response_ready),
 .response_error(staticmux_response_error),
 .response_object(staticmux_response_object),
 .response_index(staticmux_response_index),
 .response_data(staticmux_response_data),
 .response_context(staticmux_response_context),
 .request_valid(staticmux_request_valid),
 .request_ready(staticmux_request_ready),
 .request_object(staticmux_request_object),
 .request_index(staticmux_request_index),
 .response_valid(staticmux_response_valid),
 .response_ready(staticmux_response_ready),
 .reader_response_error(staticmux_reader_response_error),
 .reader_response_object(staticmux_reader_response_object),
 .reader_response_index(staticmux_reader_response_index),
 .reader_response_data(staticmux_reader_response_data),
 .reader_response_context(staticmux_reader_response_context),
 .reader_quiescent(staticmux_reader_quiescent),
 .quiescent(staticmux_quiescent),
 .fault(staticmux_fault));
trusted_audio_pool_arbiter u_poolarb(
 .clk(clk),
 .security_reset_n(functional_reset_n),
 .audio_pool_granted(audio_pool_granted),
 .cancel(stopping),
 .kernel_pool_quiet(poolarb_kernel_pool_quiet),
 .kernel_write_valid(poolarb_kernel_write_valid),
 .kernel_read_request(poolarb_kernel_read_request),
 .kernel_read_enable(poolarb_kernel_read_enable),
 .kernel_write_address(poolarb_kernel_write_address),
 .kernel_read_address(poolarb_kernel_read_address),
 .kernel_write_data(poolarb_kernel_write_data),
 .kernel_write_ready(poolarb_kernel_write_ready),
 .kernel_read_ready(poolarb_kernel_read_ready),
 .ledger_request(poolarb_ledger_request),
 .ledger_read(poolarb_ledger_read),
 .ledger_write(poolarb_ledger_write),
 .ledger_read_address(poolarb_ledger_read_address),
 .ledger_write_address(poolarb_ledger_write_address),
 .ledger_write_data(poolarb_ledger_write_data),
 .ledger_granted(poolarb_ledger_granted),
 .pool_requested(poolarb_pool_requested),
 .pool_read(poolarb_pool_read),
 .pool_write(poolarb_pool_write),
 .pool_read_address(poolarb_pool_read_address),
 .pool_write_address(poolarb_pool_write_address),
 .pool_write_data(poolarb_pool_write_data),
 .quiescent(poolarb_quiescent),
 .protocol_violation(poolarb_protocol_violation),
 .fault(poolarb_fault));

// Cached status from the retired clip is not a new-job failure. The actual
// guard clears its old fault only when its REAL new clip_begin is accepted;
// all current guard failures are then armed. Locally reset child status is
// inactive only during the bounded genuine CLEANUP reset, never at COMMIT.
// Raw protocol violations remain unconditional terminal faults.
assign child_fault=poolarb_protocol_violation||service_protocol_violation||
 ((state!=CLEANUP)&&((typed_clip_armed&&compute_diagnostic_cache_fault)||compute_request_range_fault||poolarb_fault||staticmux_fault||frontend_fault||encoder_fault||head_fault||bank_fault));
always @(posedge clk)begin
 if(!security_reset_n)begin
  state<=IDLE;profile_index<=0;capture_finished<=0;compute_elapsed<=0;ctx<=0;aborted<=0;fault<=0;front_parameters<=0;seed_index<=0;cls_index<=0;seed_word<=0;cls_word<=0;phase<=0;elapsed<=0;last_context<=0;seen_context<=0;local_reset_n<=1;reset_ticks<=0;typed_clip_armed<=0;
 end else begin
  if(trusted_clear_fault&&quiescent)begin fault<=0;aborted<=0;typed_clip_armed<=0;end
  if(compute_clip_begin_valid&&compute_clip_begin_ready)typed_clip_armed<=1;
  if(active)elapsed<=elapsed+1'b1;
  if(active&&capture_finished)compute_elapsed<=compute_elapsed+1'b1;
  if(active&&pcm_valid&&pcm_ready&&pcm_last)capture_finished<=1;
  if(active&&state!=DRAIN&&state!=DRAIN_RESET&&(!live||deadline||child_fault))begin fault<=1;aborted<=1;state<=DRAIN;end
  else case(state)
   IDLE,FINISHED:if(clip_accept)begin capture_finished<=0;compute_elapsed<=0;ctx<=current_context;last_context<=current_context;seen_context<=1;elapsed<=0;typed_clip_armed<=0;aborted<=0;front_parameters<=0;seed_index<=0;cls_index<=0;phase<=0;local_reset_n<=0;reset_ticks<=0;state<=CLEANUP;end
   CLEANUP:if(reset_ticks==3)begin local_reset_n<=1;state<=CLIP;end else reset_ticks<=reset_ticks+1'b1;
   CLIP:if(compute_clip_begin_ready)state<=PHASE4;
   PHASE4:if(compute_clip_ready&&compute_phase_ready)begin phase<=4;state<=ENABLE;end
   ENABLE:if(wordbus_request_ready)state<=ENABLE_WAIT;
   ENABLE_WAIT:if(wordbus_response_valid)begin if(wordbus_response_error)begin fault<=1;state<=DRAIN;end else begin profile_index<=0;state<=PROFILE_READ;end end
   PROFILE_READ:if(staticmux_client_ready[0])state<=PROFILE_WAIT;
   PROFILE_WAIT:if(staticmux_client_response[0])begin
    if(staticmux_response_error||staticmux_response_context!=ctx||staticmux_response_object!=313||staticmux_response_index!={27'd0,profile_index}||!profile_word_matches)begin fault<=1;state<=DRAIN;end
    else if(profile_index==31)state<=FE_FIRST;
    else begin profile_index<=profile_index+1'b1;state<=PROFILE_READ;end
   end
   FE_FIRST:if(staticmux_client_ready[0])state<=FE_FIRST_WAIT;
   FE_FIRST_WAIT:if(staticmux_client_response[0])begin if(staticmux_response_error||staticmux_response_context!=ctx)begin fault<=1;state<=DRAIN;end else state<=FE_LAST;end
   FE_LAST:if(staticmux_client_ready[0])state<=FE_LAST_WAIT;
   FE_LAST_WAIT:if(staticmux_client_response[0])begin if(staticmux_response_error||staticmux_response_context!=ctx)begin fault<=1;state<=DRAIN;end else state<=SEED_READ;end
   SEED_READ:if(staticmux_client_ready[0])state<=SEED_WAIT;
   SEED_WAIT:if(staticmux_client_response[0])begin
    if(staticmux_response_error||staticmux_response_context!=ctx||staticmux_response_object!=309||staticmux_response_index!={26'd0,seed_index})begin fault<=1;state<=DRAIN;end
    else begin seed_word<=staticmux_response_data;state<=SEED_WRITE;end
   end
   SEED_WRITE:if(wordbus_request_ready)state<=SEED_WRITE_WAIT;
   SEED_WRITE_WAIT:if(wordbus_response_valid)begin
    if(wordbus_response_error)begin fault<=1;state<=DRAIN;end
    else if(seed_index==63)state<=SEED_FLUSH;
    else begin seed_index<=seed_index+1'b1;state<=SEED_READ;end
   end
   SEED_FLUSH:if(compute_trusted_flush_ready)state<=SEED_FLUSH_WAIT;
   SEED_FLUSH_WAIT:if(compute_trusted_flush_response_valid)begin
    if(compute_trusted_flush_response_error||compute_trusted_flush_response_context!=ctx)begin fault<=1;state<=DRAIN;end
    else begin front_parameters<=1;state<=FRONT_START;end
   end
   FRONT_START:if(frontend_start_ready)state<=FRONT_WAIT;
   FRONT_WAIT:if(frontend_done&&frontend_sealed_seed_valid)state<=ENC_START;
   ENC_START:if(encoder_start_ready)state<=ENC_WAIT;
   ENC_WAIT:begin
    if(encoder_phase_request&&encoder_phase_ready)phase<=encoder_phase_request_value;
    if(encoder_done)state<=HEAD_PHASE;
   end
   HEAD_PHASE:if(compute_phase_ready)begin phase<=185;state<=HEAD_START;end
   HEAD_START:if(head_start_ready)begin cls_index<=0;state<=CLS_READ;end
   CLS_READ:if(wordbus_request_ready)state<=CLS_READ_WAIT;
   CLS_READ_WAIT:if(wordbus_response_valid)begin
    if(wordbus_response_error||wordbus_response_data[31:24]!={8{wordbus_response_data[23]}})begin fault<=1;state<=DRAIN;end
    else begin cls_word<=wordbus_response_data;state<=CLS_SEND;end
   end
   CLS_SEND:if(head_cls_ready)begin if(cls_index==63)state<=HEAD_WAIT;else begin cls_index<=cls_index+1'b1;state<=CLS_READ;end end
   HEAD_WAIT:if(head_done&&head_result_visible)state<=COMMIT;
   COMMIT:if(bank_commit_ready&&head_result_visible)state<=FINISHED;
   // Only private functional/dirty-cache state resets here. The root epoch,
   // installed key/session, consumed-generation history, result-bank history,
   // line MAC/ledger/backend and every accepted external transaction remain
   // in the security domain. A stalled external B/MAC prevents this edge.
   DRAIN:if(external_transport_quiet)begin local_reset_n<=0;reset_ticks<=0;state<=DRAIN_RESET;end
   DRAIN_RESET:if(reset_ticks==3)begin local_reset_n<=1;state<=IDLE;end else reset_ticks<=reset_ticks+1'b1;
   default:begin fault<=1;state<=DRAIN;end
  endcase
 end
end
// Parameter phase is a genuine signed-object binding. Its first AND final
// words are consumed through the actual reader; every arithmetic operand then
// independently uses that same verified-page path, with no raw-DDR copy.
always @(posedge clk)begin
 if(!functional_reset_n)begin bind_state<=0;bound_parameter_object<=0;bound_parameter_context<=0;bind_bad<=0;bind_first<=0;end
 else case(bind_state)
  0:if(encoder_parameter_request&&encoder_parameter_ready)begin bind_state<=1;bound_parameter_object<=encoder_parameter_object;bound_parameter_context<=encoder_parameter_context;bind_bad<=0;end
  1:if(staticmux_client_ready[0])bind_state<=2;
  2:if(staticmux_client_response[0])begin bind_first<=staticmux_response_data;bind_bad<=staticmux_response_error||staticmux_response_context!=bound_parameter_context||staticmux_response_object!=bound_parameter_object||staticmux_response_index!=0;bind_state<=3;end
  3:if(staticmux_client_ready[0])bind_state<=4;
  4:if(staticmux_client_response[0])begin bind_bad<=bind_bad||staticmux_response_error||staticmux_response_context!=bound_parameter_context||staticmux_response_object!=bound_parameter_object||staticmux_response_index!=49791;bind_state<=5;end
  5:if(encoder_parameter_response_ready)bind_state<=0;
  default:bind_state<=0;
 endcase
end
endmodule

`default_nettype wire
