`timescale 1ns/1ps
// Untrusted PS stimulus: raw signed manifest/signature/static page/proof bytes
// only, sent through the ACTUAL npu_model_feed_axil_v2 slave. Never sets an
// authority, page verdict, runtime completion or intermediate tensor value.
module full_chain_model_feeder #(
 parameter PACKET_FILE="manifest_packet.mem",parameter MODEL_FILE="whole_model.mem",parameter PROOF_FILE="whole_proofs.mem"
)(
 input wire clk,rst_n,enable,
 input wire page_request_event,input wire [31:0] requested_page,
 output reg [11:0] s_awaddr,output reg s_awvalid,input wire s_awready,
 output reg [31:0] s_wdata,output reg [3:0] s_wstrb,output reg s_wvalid,input wire s_wready,
 input wire [1:0] s_bresp,input wire s_bvalid,output reg s_bready,
 output reg [11:0] s_araddr,output reg s_arvalid,input wire s_arready,
 input wire [31:0] s_rdata,input wire [1:0] s_rresp,input wire s_rvalid,output reg s_rready,
 output reg manifest_loaded,output reg worker_busy,output reg [31:0] supplied_pages
);
reg [31:0] packet[0:1995],full_model[0:13352959],full_proofs[0:1460479];
integer pending_leaf=-1,leaf,i,polls;
reg [31:0] status;
always @(posedge clk)if(rst_n&&page_request_event)begin
 if(!manifest_loaded||pending_leaf>=0||worker_busy)$fatal(1,"actual page request overlaps untrusted PS feeder");
 if(requested_page>=13047)$fatal(1,"actual page outside signedV2 range");
 pending_leaf=requested_page;
end
task automatic write_word(input [11:0] addr,input [31:0] data);
 reg ah,wh;integer budget;
 begin
  @(negedge clk);s_awaddr=addr;s_wdata=data;s_wstrb=15;s_awvalid=1;s_wvalid=1;s_bready=0;ah=0;wh=0;budget=0;
  while(!ah||!wh)begin
   @(posedge clk);if(s_awvalid&&s_awready)ah=1;if(s_wvalid&&s_wready)wh=1;
   @(negedge clk);if(ah)s_awvalid=0;if(wh)s_wvalid=0;
   budget=budget+1;if(budget>100000)$fatal(1,"raw feeder AW/W timeout addr=%h",addr);
  end
  while(!s_bvalid)begin @(negedge clk);budget=budget+1;if(budget>100000)$fatal(1,"raw feeder B timeout addr=%h",addr);end
  if(s_bresp!=0)$fatal(1,"actual model feeder rejects raw word addr=%h response=%b",addr,s_bresp);
  s_bready=1;@(negedge clk);s_bready=0;
 end
endtask
task automatic read_word(input [11:0] addr,output [31:0] value);
 integer budget;
 begin
  @(negedge clk);s_araddr=addr;s_arvalid=1;s_rready=0;budget=0;
  do begin @(posedge clk);budget=budget+1;if(budget>100000)$fatal(1,"raw feeder AR timeout");end while(!s_arready);
  @(negedge clk);s_arvalid=0;
  while(!s_rvalid)begin @(negedge clk);budget=budget+1;if(budget>100000)$fatal(1,"raw feeder R timeout");end
  if(s_rresp!=0)$fatal(1,"raw feeder read rejected");value=s_rdata;s_rready=1;@(negedge clk);s_rready=0;
 end
endtask
// Called by the initial untrusted PS agent, or by a lifecycle test only after
// the actual page worker and the protected hub have drained. It submits the
// exact same raw signed package again; no verdict/authority is assigned here.
task automatic reload_manifest;
 integer j,attempts;reg [31:0] state_word;
 begin
  if(worker_busy||pending_leaf>=0)$fatal(1,"PS reload overlaps outstanding actual page feed");
  manifest_loaded=0;state_word=0;attempts=0;
  while(!state_word[5]||state_word[2])begin read_word(12'h008,state_word);attempts=attempts+1;if(attempts>1000000)$fatal(1,"actual service not manifest-ready");end
  write_word(12'h004,1);
  for(j=0;j<24;j=j+1)write_word(12'h020,packet[1972+j]);
  for(j=0;j<1964;j=j+1)write_word(12'h024,packet[8+j]);
  state_word=0;attempts=0;
  while(!state_word[3])begin
   read_word(12'h008,state_word);if(state_word[6]||state_word[7])$fatal(1,"actual signature verification/feeder fault %h",state_word);
   attempts=attempts+1;if(attempts>1000000)$fatal(1,"actual signature verify timeout");
  end
  manifest_loaded=1;
  $display("FULL_CHAIN_ACTUAL_AXIL_RAW_MANIFEST_AUTHORIZED public_signed_bytes_only=1 no_authority_override=1");
 end
endtask
initial begin
 s_awaddr=0;s_awvalid=0;s_wdata=0;s_wstrb=15;s_wvalid=0;s_bready=0;s_araddr=0;s_arvalid=0;s_rready=0;manifest_loaded=0;worker_busy=0;supplied_pages=0;
 $readmemh(PACKET_FILE,packet);$readmemh(MODEL_FILE,full_model);$readmemh(PROOF_FILE,full_proofs);
 wait(rst_n&&enable);reload_manifest();
 forever begin
  wait(pending_leaf>=0);worker_busy=1;leaf=pending_leaf;pending_leaf=-1;
  for(i=0;i<1024;i=i+1)write_word(12'h028,full_model[leaf*1024+i]);
  for(i=0;i<112;i=i+1)write_word(12'h02c,full_proofs[leaf*112+i]);
  worker_busy=0;supplied_pages=supplied_pages+1;
 end
end
endmodule
