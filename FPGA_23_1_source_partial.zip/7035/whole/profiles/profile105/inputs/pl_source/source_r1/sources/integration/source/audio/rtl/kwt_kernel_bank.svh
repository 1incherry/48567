// One16-bit column-lane bank of a complete B matrix. Four4096-word banks
// occupy32KiB. A command overwrites every used/padded word before computing;
// no power-up contents or cross-command cache validity are assumed.
module kwt_kernel_bank(
    input wire clk,write_enable,read_enable,
    input wire [11:0] write_address,read_address,
    input wire signed [15:0] write_data,
    output wire signed [15:0] read_data
);
`ifdef KWT_USE_SRAM_BANKS
    kwt_sram_banked #(.WIDTH(16),.DEPTH(4096),.MACRO_DEPTH(4096),.ADDR_W(12)) macro_bank(
        .clk(clk),.a_en(write_enable),.a_we(write_enable),.a_addr(write_address),.a_data(write_data),
        .a_strobe(2'b11),.a_q(),.b_en(read_enable),.b_we(1'b0),.b_addr(read_address),.b_data(16'd0),.b_q(read_data));
`else
    (* ram_style="block" *) reg signed [15:0] storage[0:4095];
    reg signed [15:0] read_register;
    assign read_data=read_register;
    always @(posedge clk)begin
        if(write_enable)storage[write_address]<=write_data;
        if(read_enable)read_register<=storage[read_address];
    end
`endif
endmodule
