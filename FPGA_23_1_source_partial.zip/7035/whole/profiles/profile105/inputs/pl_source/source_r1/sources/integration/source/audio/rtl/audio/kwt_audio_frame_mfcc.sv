`timescale 1ns/1ps
// One480-sample PCM16 frame ->40 signed24 MFCC coefficients Q14.
// All arithmetic follows fixed_frontend_v2_bfp, including magnitude Mel,
// frozen Q30 coefficients, floor-ln Q24 and nearest-even DCT output.
module kwt_audio_frame_mfcc #(
    parameter HANN_FILE="model/audio_hann_q30.hex",
    parameter TWIDDLE_FILE="model/audio_twiddle_q30.hex",
    parameter MEL_FILE="model/audio_mel_sparse_q30.hex",
    parameter MEL_OFFSETS_FILE="model/audio_mel_offsets.hex",
    parameter LOG_FILE="model/audio_log_q24.hex",
    parameter DCT_FILE="model/audio_dct4_q30.hex"
)(
    input wire clk,rst_n,clear,start,in_valid,
    input wire signed [15:0] in_pcm,
    output wire in_ready,out_valid,
    input wire out_ready,
    output wire signed [23:0] out_mfcc,
    output wire [5:0] out_index,
    output wire out_last,busy,error,
    output reg done
);
    reg active,spectrum_finished,mel_finished,dct_finished;
    wire launch=start&&!active;
    wire spectrum_valid,spectrum_ready,spectrum_last,spectrum_busy,spectrum_done,spectrum_error;
    wire [31:0] spectrum_magnitude;wire [8:0] spectrum_index;wire [5:0] spectrum_fraction;
    wire mel_valid,mel_ready,mel_busy,mel_done,mel_error;
    wire [63:0] mel_value;wire [6:0] mel_index,mel_fraction;
    wire log_valid,log_ready;wire signed [31:0] log_value;wire [6:0] log_index;
    wire dct_busy,dct_done,dct_error;
    assign busy=active;assign out_last=out_valid&&out_index==39;
    assign error=spectrum_error||mel_error||dct_error;
    kwt_audio_frame_spectrum #(.HANN_FILE(HANN_FILE),.TWIDDLE_FILE(TWIDDLE_FILE)) spectrum(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(launch),.in_valid(in_valid),.in_pcm(in_pcm),.in_ready(in_ready),
        .out_valid(spectrum_valid),.out_ready(spectrum_ready),.out_magnitude(spectrum_magnitude),
        .out_index(spectrum_index),.out_fraction(spectrum_fraction),.out_last(spectrum_last),
        .busy(spectrum_busy),.done(spectrum_done),.overflow(spectrum_error));
    kwt_audio_mel80 #(.COEFFICIENT_FILE(MEL_FILE),.OFFSETS_FILE(MEL_OFFSETS_FILE)) mel(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(launch),
        .in_valid(spectrum_valid),.in_ready(spectrum_ready),.in_magnitude(spectrum_magnitude),.in_index(spectrum_index),.in_fraction(spectrum_fraction),
        .out_valid(mel_valid),.out_ready(mel_ready),.out_mel(mel_value),.out_index(mel_index),.out_fraction(mel_fraction),
        .busy(mel_busy),.done(mel_done),.error(mel_error));
    kwt_audio_log_q24 #(.TABLE_FILE(LOG_FILE)) logarithm(
        .clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(mel_valid),.in_ready(mel_ready),.in_mel(mel_value),.in_fraction(mel_fraction),.in_index(mel_index),
        .out_valid(log_valid),.out_ready(log_ready),.out_log(log_value),.out_index(log_index));
    kwt_audio_dct40 #(.COEFFICIENT_FILE(DCT_FILE)) dct(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(launch),.in_valid(log_valid),.in_ready(log_ready),.in_log(log_value),.in_index(log_index),
        .out_valid(out_valid),.out_ready(out_ready),.out_mfcc(out_mfcc),.out_index(out_index),.busy(dct_busy),.done(dct_done),.error(dct_error));
    always @(posedge clk)begin
        if(!rst_n||clear)begin active<=0;spectrum_finished<=0;mel_finished<=0;dct_finished<=0;done<=0;end
        else begin
            done<=0;
            if(launch)begin active<=1;spectrum_finished<=0;mel_finished<=0;dct_finished<=0;end
            if(active)begin
                if(spectrum_done)spectrum_finished<=1;
                if(mel_done)mel_finished<=1;
                if(dct_done)dct_finished<=1;
                if((spectrum_finished||spectrum_done)&&(mel_finished||mel_done)&&(dct_finished||dct_done))begin active<=0;done<=1;end
            end
        end
    end
endmodule
