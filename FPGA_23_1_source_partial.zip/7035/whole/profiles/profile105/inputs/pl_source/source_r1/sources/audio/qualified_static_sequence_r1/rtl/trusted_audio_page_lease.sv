`timescale 1ns/1ps
// Trusted object-map -> existing shared SLH/Merkle service -> private cache
// lease. This does not instantiate another SHA/SLH core. The enclosing arbiter
// MUST honor exclusive_page_lock and may not replace the page while leased.
module trusted_audio_page_lease #(
 parameter POLICY_ROM="model_object_policy_v2.mem"
)(
 input wire clk,rst_n,cancel,model_authorized,input wire [31:0] session_epoch,
 input wire lease_request,output wire lease_ready,
 input wire [31:0] lease_object,lease_page,lease_epoch,
 output reg lease_response_valid,lease_verified,
 output wire [31:0] lease_response_object,lease_response_page,lease_response_epoch,
 output wire lease_still_valid,
 input wire word_request,output wire word_ready,input wire [6:0] word_offset,
 output reg word_response_valid,output reg [6:0] word_response_offset,
 output wire [255:0] word_response_data,
 input wire lease_release,output wire release_ready,
 output wire cache_quiescent,exclusive_page_lock,
 // One atomic page fetch admission: DMA receives these only when both its
 // fetch_ready and service_page_ready are true. This is not an AXI channel.
 output wire fetch_valid,input wire fetch_ready,
 output wire [31:0] fetch_page_index,fetch_page_address,fetch_proof_address,
 output wire service_page_request,input wire service_page_ready,
 output wire [31:0] service_expected_page,
 input wire service_page_done,service_busy,service_fault,service_cache_valid,
 input wire [31:0] service_cached_page,
 output wire service_cache_read,output wire [9:0] service_cache_address,
 input wire service_cache_read_valid,input wire [31:0] service_cache_read_data
);
 localparam IDLE=0,MAP_REQUEST=1,MAP_REPLY=2,PAGE=3,PAGE_WAIT=4,
  GRANT=5,HELD=6,READ_WORD=7,WORD_REPORT=8;
 reg [3:0] state;
 reg [31:0] saved_object,saved_page,saved_epoch,saved_leaf,saved_page_addr,saved_proof_addr;
 reg [6:0] saved_word;
 reg [3:0] sent,received;
 reg [255:0] gathered;
 reg aborted,grant_good;
 wire live=model_authorized&&session_epoch==saved_epoch&&!cancel&&!aborted;
 wire private_live=live&&grant_good&&service_cache_valid&&service_cached_page==saved_leaf&&!service_fault;
 wire map_ready,map_valid,map_allowed;
 wire [31:0] map_leaf,map_address,map_proof;
 wire [11:0] map_offset;wire [15:0] map_bytes;
 wire [63:0] object_offset={32'd0,saved_page}<<12;
 // Object IDs and semantic stage come from a trusted audio phase controller.
 wire audio_object=saved_object>=296&&saved_object<=313;
 wire [31:0] selected_bytes=saved_object<=307?32'd199168:
  saved_object==308?32'd35840:saved_object==309?32'd256:
  saved_object==310?32'd10752:saved_object==311?32'd26880:
  saved_object==312?32'd420:saved_object==313?32'd128:32'd0;
 wire [4:0] selected_stage=saved_object<=307?saved_object-296:
  saved_object==308?5'd12:saved_object==309?5'd13:
  saved_object==310?5'd16:5'd31;
 wire [3:0] selected_kind=saved_object==313?4'd8:saved_object<=310?4'd6:4'd7;
 wire [63:0] remaining={32'd0,selected_bytes}-object_offset;
 wire [15:0] request_bytes=object_offset>=selected_bytes?0:remaining<4096?remaining[15:0]:4096;
 npu_static_object_map_v2_lutram #(.ROM_FILE(POLICY_ROM)) policy(
  .clk(clk),.rst_n(rst_n),.model_authorized(model_authorized),.session_epoch(session_epoch),
  .request_valid(state==MAP_REQUEST&&live),.request_ready(map_ready),
  .requested_object(saved_object[8:0]),.expected_object(saved_object[8:0]),
  .byte_offset(object_offset[31:0]),.byte_count(request_bytes),
  .expected_kind(selected_kind),.expected_block(4'd15),.expected_qkv_op(4'd15),.expected_dst(5'd31),.expected_stage(selected_stage),
  .response_valid(map_valid),.response_ready(1'b1),.response_allowed(map_allowed),
  .page_index(map_leaf),.page_address(map_address),.proof_address(map_proof),.page_offset(map_offset),.allowed_bytes(map_bytes));
 assign lease_ready=state==IDLE&&!service_busy;
 assign lease_response_object=saved_object;
 assign lease_response_page=saved_page;
 assign lease_response_epoch=saved_epoch;
 assign lease_still_valid=private_live&&(state==HELD||state==READ_WORD||state==WORD_REPORT);
 assign word_ready=state==HELD; // Even a revoked word request gets an invalid reply and can drain.
 assign word_response_data=gathered;
 assign release_ready=state==HELD;
 assign cache_quiescent=state==IDLE&&!service_busy;
 assign exclusive_page_lock=state!=IDLE;
 assign fetch_valid=state==PAGE&&live&&service_page_ready;
 assign service_page_request=state==PAGE&&live&&fetch_ready;
 assign fetch_page_index=saved_leaf;
 assign fetch_page_address=saved_page_addr;
 assign fetch_proof_address=saved_proof_addr;
 assign service_expected_page=saved_leaf;
 assign service_cache_read=state==READ_WORD&&private_live&&sent<8;
 assign service_cache_address={saved_word,sent[2:0]};
 wire [31:0] swapped={service_cache_read_data[7:0],service_cache_read_data[15:8],service_cache_read_data[23:16],service_cache_read_data[31:24]};
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;saved_object<=0;saved_page<=0;saved_epoch<=0;saved_leaf<=0;saved_page_addr<=0;saved_proof_addr<=0;
   saved_word<=0;sent<=0;received<=0;gathered<=0;aborted<=0;grant_good<=0;
   lease_response_valid<=0;lease_verified<=0;word_response_valid<=0;word_response_offset<=0;
  end else begin
   lease_response_valid<=0;lease_verified<=0;word_response_valid<=0;
   if(state!=IDLE&&(cancel||!model_authorized||session_epoch!=saved_epoch))aborted<=1;
   case(state)
    IDLE:if(lease_request&&lease_ready)begin
     saved_object<=lease_object;saved_page<=lease_page;saved_epoch<=lease_epoch;
     grant_good<=0;aborted<=0;gathered<=0;
     if(cancel||!model_authorized||(lease_object<296||lease_object>313)||lease_epoch!=session_epoch||lease_page>1048575)state<=GRANT;
     else state<=MAP_REQUEST;
    end
    MAP_REQUEST:if(!live)state<=GRANT;else if(map_ready)state<=MAP_REPLY;
    MAP_REPLY:if(!live)state<=GRANT;else if(map_valid)begin
     if(!map_allowed)state<=GRANT;
     else begin
      saved_leaf<=map_leaf;saved_page_addr<=map_address;saved_proof_addr<=map_proof;
      if(service_cache_valid&&service_cached_page==map_leaf&&!service_fault)begin grant_good<=1;state<=GRANT;end
      else state<=PAGE;
     end
    end
    PAGE:if(!live)state<=GRANT;else if(service_page_ready&&fetch_ready)state<=PAGE_WAIT;
    PAGE_WAIT:begin
     if(service_page_done||(!service_busy&&!live))begin
      grant_good<=live&&service_cache_valid&&service_cached_page==saved_leaf&&!service_fault;
      state<=GRANT;
     end
    end
    GRANT:begin lease_response_valid<=1;lease_verified<=private_live;state<=HELD;end
    HELD:begin
     if(lease_release)begin grant_good<=0;state<=IDLE;end
     else if(word_request)begin
      saved_word<=word_offset;word_response_offset<=word_offset;sent<=0;received<=0;gathered<=0;
      state<=private_live?READ_WORD:WORD_REPORT;
     end
    end
    READ_WORD:begin
     if(!private_live)begin grant_good<=0;gathered<=0;state<=WORD_REPORT;end
     else begin
      if(service_cache_read)sent<=sent+1;
      if(service_cache_read_valid)begin
       gathered[received*32+:32]<=swapped;received<=received+1;
       if(received==7)state<=WORD_REPORT;
      end
     end
    end
    WORD_REPORT:begin word_response_valid<=1;state<=HELD;end
    default:begin grant_good<=0;state<=GRANT;end
   endcase
  end
 end
endmodule
