// Independently implemented balanced priority tree. No upstream lzc code is
// used. Supported divider widths32/64 are powers of two. Zero count is WIDTH-1
// with empty_o=1, matching the public module interface.
module kwt_lzc_tree #(parameter WIDTH=64,CNT_WIDTH=$clog2(WIDTH))(
    input wire [WIDTH-1:0] value,
    output wire [CNT_WIDTH-1:0] count,
    output wire empty
);
    generate if(WIDTH==2) begin: leaf
        assign count=!value[1];
        assign empty=!(|value);
    end else begin: branch
        wire [CNT_WIDTH-2:0] upper_count,lower_count;
        wire upper_empty,lower_empty;
        kwt_lzc_tree #(.WIDTH(WIDTH/2)) upper(.value(value[WIDTH-1:WIDTH/2]),.count(upper_count),.empty(upper_empty));
        kwt_lzc_tree #(.WIDTH(WIDTH/2)) lower(.value(value[WIDTH/2-1:0]),.count(lower_count),.empty(lower_empty));
        assign count=upper_empty?{1'b1,lower_count}:{1'b0,upper_count};
        assign empty=upper_empty&&lower_empty;
    end endgenerate
endmodule
module kwt_hyf_lzc #(parameter WIDTH=64,MODE=1,CNT_WIDTH=$clog2(WIDTH))(
    input wire [WIDTH-1:0] in_i,
    output wire [CNT_WIDTH-1:0] cnt_o,
    output wire empty_o
);
    wire [WIDTH-1:0] ordered;
    genvar bit_index;
    generate for(bit_index=0;bit_index<WIDTH;bit_index=bit_index+1) begin: bits
        assign ordered[bit_index]=MODE?in_i[bit_index]:in_i[WIDTH-1-bit_index];
    end endgenerate
    kwt_lzc_tree #(.WIDTH(WIDTH),.CNT_WIDTH(CNT_WIDTH)) tree(.value(ordered),.count(cnt_o),.empty(empty_o));
endmodule
