`timescale 1ns/1ps
// Streaming floor(sqrt(real^2+imag^2)). The square, sum and restoring
// square-root steps are registered; there is no combinational sqrt chain.
// Fraction/index metadata is held through output backpressure.
module kwt_audio_magnitude(
    input wire clk,rst_n,clear,in_valid,
    output wire in_ready,
    input wire signed [31:0] in_real,in_imag,
    input wire [8:0] in_index,
    input wire [5:0] in_fraction,
    output wire out_valid,
    input wire out_ready,
    output wire [31:0] out_magnitude,
    output wire [8:0] out_index,
    output wire [5:0] out_fraction
);
    localparam IDLE=0,PRODUCT=1,SUM=2,START_ROOT=3,WAIT_ROOT=4,HOLD=5;
    reg [2:0] state;
    reg signed [31:0] real0,imag0;
    reg [63:0] real_square,imag_square,radicand;
    reg [31:0] magnitude;
    reg [8:0] index;
    reg [5:0] fraction;
    wire root_valid,root_busy;wire [31:0] root_result;
    assign in_ready=rst_n&&!clear&&state==IDLE;
    assign out_valid=rst_n&&!clear&&state==HOLD;
    assign out_magnitude=magnitude;assign out_index=index;assign out_fraction=fraction;
    kwt_sqrt64 square_root(.clk(clk),.rst_n(rst_n),.clear(clear),.start(state==START_ROOT),
        .radicand(radicand),.busy(root_busy),.valid(root_valid),.result(root_result));
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            state<=IDLE;real0<=0;imag0<=0;real_square<=0;imag_square<=0;radicand<=0;
            magnitude<=0;index<=0;fraction<=0;
        end else case(state)
            IDLE:if(in_valid)begin
                real0<=in_real;imag0<=in_imag;index<=in_index;fraction<=in_fraction;state<=PRODUCT;
            end
            PRODUCT:begin real_square<=real0*real0;imag_square<=imag0*imag0;state<=SUM;end
            SUM:begin radicand<=real_square+imag_square;state<=START_ROOT;end
            START_ROOT:state<=WAIT_ROOT;
            WAIT_ROOT:if(root_valid)begin magnitude<=root_result;state<=HOLD;end
            HOLD:if(out_ready)state<=IDLE;
            default:state<=IDLE;
        endcase
    end
endmodule
