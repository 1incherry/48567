`timescale 1ns/1ps
// Management stays on the fabric clock. A registered AXI-Lite bridge holds
// external responses stable while DDR misses pause the bit-exact numerical core.
module trusted_audio_serial_compute #(parameter integer AUDIO_PARALLEL_CLOCK=0, parameter integer USE_REGISTERED_INTERVAL_ENDS=0)(input wire clk,rst_n,can_enable,
input wire security_reset_n,cancel,authorized,key_valid,model_authorized,
input wire [31:0]authorization_epoch,current_model_epoch,source_id,clip_id,generation,
input wire [127:0]current_key_session,
input wire clip_begin_valid,output wire clip_begin_ready,input wire [31:0]clip_session_id,
input wire clip_release,output wire clip_ready,phase_active,
input wire phase_valid,output wire phase_ready,input wire [7:0]phase_id,
input wire frontend_phase,input wire [8:0]parameter_object,
input wire [7:0]trusted_current_phase,
input wire [16:0]allowed_a_base,allowed_b_base,allowed_bias_base,allowed_write_base,
input wire [17:0]allowed_a_words,allowed_b_words,allowed_bias_words,allowed_write_words,
input wire [17:0]allowed_a_end,allowed_b_end,allowed_bias_end,allowed_write_end,
output wire request_range_fault,
input wire trusted_flush_valid,output wire trusted_flush_ready,
output wire trusted_flush_response_valid,input wire trusted_flush_response_ready,
output wire trusted_flush_response_error,output wire [287:0]trusted_flush_response_context,
output wire transport_quiescent,static_router_quiescent,
output wire static_request_valid,input wire static_request_ready,output wire [8:0]static_request_object,
output wire [31:0]static_request_word_index,input wire static_response_valid,output wire static_response_ready,
input wire static_response_error,input wire [8:0]static_response_object,
input wire [31:0]static_response_word_index,static_response_data,input wire [287:0]static_response_context,input wire static_quiescent,
input wire kernel_owner_live,
output wire kernel_core_ready,kernel_pool_quiescent,kernel_quiescent,kernel_fault,
output wire kernel_pool_write_valid,input wire kernel_pool_write_ready,
output wire [11:0]kernel_pool_write_address,output wire [255:0]kernel_pool_write_data,
output wire kernel_pool_read_request,kernel_pool_read_enable,input wire kernel_pool_read_ready,
output wire [11:0]kernel_pool_read_address,input wire [255:0]kernel_pool_read_data,
input wire ledger_pool_granted,output wire ledger_pool_request,ledger_pool_read,ledger_pool_write,
output wire [11:0]ledger_pool_read_address,ledger_pool_write_address,input wire [255:0]ledger_pool_read_data,output wire [255:0]ledger_pool_write_data,
output wire mac_request,output wire [127:0]mac_chain,output wire [255:0]mac_data,
input wire mac_ready,mac_response_valid,mac_response_error,input wire [127:0]mac_tag,input wire mac_quiescent,

output wire claim,output reg active,output wire busy,output wire irq,
output wire diagnostic_cache_clean,diagnostic_cache_idle,diagnostic_cache_fault,diagnostic_management_quiet,
input wire [20:0] s_axi_awaddr,input wire [2:0] s_axi_awprot,input wire s_axi_awvalid,output wire s_axi_awready,
input wire [31:0] s_axi_wdata,input wire [3:0] s_axi_wstrb,input wire s_axi_wvalid,output wire s_axi_wready,
output reg [1:0] s_axi_bresp,output reg s_axi_bvalid,input wire s_axi_bready,
input wire [20:0] s_axi_araddr,input wire [2:0] s_axi_arprot,input wire s_axi_arvalid,output wire s_axi_arready,
output reg [31:0] s_axi_rdata,output reg [1:0] s_axi_rresp,output reg s_axi_rvalid,input wire s_axi_rready,
output wire [31:0] M_AXI_ARADDR,output wire [7:0] M_AXI_ARLEN,output wire [2:0] M_AXI_ARSIZE,output wire [1:0] M_AXI_ARBURST,
output wire M_AXI_ARVALID,input wire M_AXI_ARREADY,input wire [255:0] M_AXI_RDATA,input wire [1:0] M_AXI_RRESP,input wire M_AXI_RLAST,M_AXI_RVALID,output wire M_AXI_RREADY,
output wire [31:0] M_AXI_AWADDR,output wire [7:0] M_AXI_AWLEN,output wire [2:0] M_AXI_AWSIZE,output wire [1:0] M_AXI_AWBURST,
output wire M_AXI_AWVALID,input wire M_AXI_AWREADY,output wire [255:0] M_AXI_WDATA,output wire [31:0] M_AXI_WSTRB,output wire M_AXI_WLAST,M_AXI_WVALID,input wire M_AXI_WREADY,
input wire [1:0] M_AXI_BRESP,input wire M_AXI_BVALID,output wire M_AXI_BREADY,
 input wire trusted_core_clock_raw
);
reg ah,wh,rh;reg [20:0] wa,ra;reg [31:0] wd;reg [3:0] ws;
reg [2:0] bridge;reg sent_a,sent_w;
reg cache_flush,cache_invalidate;
wire cache_clean;
wire cache_step,cache_ready,cache_idle,cache_done,cache_fault,core_locked;
wire [31:0] cache_misses,cache_writebacks,cache_stalls;
reg [31:0] flush_completions;
reg req_a_en,req_a_we,req_b_en,req_b_we;
reg [16:0] req_a_addr,req_b_addr;
reg [31:0] req_a_data,req_b_data;
reg [3:0] req_a_strobe;
reg advance_pending,request_settle;
wire core_clk;
wire [287:0]current_context={current_model_epoch,authorization_epoch,source_id,clip_id,generation,current_key_session};
wire static_ready,static_router_fault;
wire cache_a_enable,cache_b_enable;wire [31:0]cache_a_q,cache_b_q;
function automatic in_interval(input[16:0]address,base,input[17:0]count);
 begin in_interval=count!=0&&{1'b0,address}>={1'b0,base}&&{1'b0,address}<({1'b0,base}+count);end
endfunction
// End registers come from the same accepted descriptor edge as base/count.
// Retain the zero-count and lower-bound checks. Fixed frontend/head ranges
// keep their original expression; no cycle, cancel or revocation is delayed.
function automatic registered_interval(input[16:0]address,base,input[17:0]count,interval_end);
 begin registered_interval=count!=0&&{1'b0,address}>={1'b0,base}&&{1'b0,address}<interval_end;end
endfunction
function automatic selected_interval(input[16:0]address,base,input[17:0]count,interval_end);
 begin
  if(USE_REGISTERED_INTERVAL_ENDS!=0)selected_interval=registered_interval(address,base,count,interval_end);
  else selected_interval=in_interval(address,base,count);
 end
endfunction
function automatic dynamic_allowed(input[16:0]address,input writing);
 begin
  if(trusted_current_phase==4)dynamic_allowed=in_interval(address,17'd51200,18'd6400)||in_interval(address,17'd112448,18'd3960);
  else if(trusted_current_phase==185)dynamic_allowed=!writing&&in_interval(address,17'd51200,18'd64);
  else if(trusted_current_phase>=5&&trusted_current_phase<=184)
   dynamic_allowed=writing?selected_interval(address,allowed_write_base,allowed_write_words,allowed_write_end):
    selected_interval(address,allowed_a_base,allowed_a_words,allowed_a_end)||selected_interval(address,allowed_b_base,allowed_b_words,allowed_b_end)||selected_interval(address,allowed_bias_base,allowed_bias_words,allowed_bias_end)||selected_interval(address,allowed_write_base,allowed_write_words,allowed_write_end);
  else dynamic_allowed=0;
 end
endfunction
wire dynamic_a_allowed=dynamic_allowed(req_a_addr,req_a_we),dynamic_b_allowed=dynamic_allowed(req_b_addr,req_b_we);
assign request_range_fault=active&&!request_settle&&((cache_a_enable&&!dynamic_a_allowed)||(cache_b_enable&&!dynamic_b_allowed));
reg direct_flush_pending,direct_flush_response,direct_flush_done;reg [287:0]direct_flush_context;
assign trusted_flush_ready=active&&!core_locked&&cache_idle&&diagnostic_management_quiet&&!direct_flush_pending&&!direct_flush_response&&authorized&&!cancel;
wire direct_flush_accept=trusted_flush_valid&&trusted_flush_ready;
assign trusted_flush_response_valid=direct_flush_response;
assign trusted_flush_response_error=cancel||!authorized||direct_flush_context!=current_context||cache_fault;
assign trusted_flush_response_context=direct_flush_context;
always @(posedge clk)begin
 if(!rst_n)begin direct_flush_pending<=0;direct_flush_response<=0;direct_flush_done<=0;direct_flush_context<=0;end
 else begin
  if(direct_flush_accept)begin direct_flush_pending<=1;direct_flush_done<=0;direct_flush_context<=current_context;end
  if(direct_flush_pending&&cache_done)direct_flush_done<=1;
  if(direct_flush_pending&&direct_flush_done&&cache_clean&&cache_idle&&transport_quiescent)begin direct_flush_pending<=0;direct_flush_response<=1;end
  if(direct_flush_response&&trusted_flush_response_ready)direct_flush_response<=0;
 end
end

// Default retains the original buffered-clock contract. The explicit board
// mode feeds the real BUFGCE from the same trusted MMCM output as main BUFG.
wire audio_gate_input;
generate if(AUDIO_PARALLEL_CLOCK!=0)begin: parallel_clock
 assign audio_gate_input=trusted_core_clock_raw;
end else begin: legacy_clock
 assign audio_gate_input=clk;
end endgenerate
`ifdef AUDIO_SIM_CLOCK
reg clock_enable;
always @* if(!audio_gate_input)clock_enable=!rst_n||cache_step;
assign core_clk=audio_gate_input&&clock_enable;
`else
BUFGCE u_audio_clock(.I(audio_gate_input),.CE(!rst_n||cache_step),.O(core_clk));
`endif
assign diagnostic_cache_clean=cache_clean;assign diagnostic_cache_idle=cache_idle;assign diagnostic_cache_fault=cache_fault;
assign diagnostic_management_quiet=bridge==0&&!ah&&!wh&&!rh&&!s_axi_bvalid&&!s_axi_rvalid;
assign claim=active||(bridge==0&&ah&&wh&&wa==21'h200&&wd==1);
assign busy=core_locked||bridge!=0||!cache_idle;
assign s_axi_awready=rst_n&&!ah&&!s_axi_bvalid;
assign s_axi_wready=rst_n&&!wh&&!s_axi_bvalid;
assign s_axi_arready=rst_n&&!rh&&!s_axi_rvalid;
wire ca_ready,cw_ready,cb_valid,cr_ready,cr_valid;
wire [1:0] cb_resp,cr_resp;wire [31:0] cr_data;
wire mem_a_en,mem_a_we,mem_b_en,mem_b_we;
wire [16:0] mem_a_addr,mem_b_addr;
wire [31:0] mem_a_data,mem_b_data,mem_a_q,mem_b_q;
wire [3:0] mem_a_strobe;
// Register the core's memory requests before associative cache lookup. After a
// core edge, allow one capture cycle and then a readiness cycle. Only the
// registered commit opens BUFGCE and updates synchronous RAM outputs together.
// AXI refill/writeback keeps running on the full-rate fabric clock.

assign cache_step=advance_pending&&active&&!cache_flush&&!cache_invalidate&&!cache_fault&&kernel_core_ready&&static_ready&&!cancel&&!request_range_fault&&!direct_flush_pending&&!direct_flush_response&&!direct_flush_accept;
always @(posedge clk)begin
 if(!rst_n)begin
  req_a_en<=0;req_a_we<=0;req_b_en<=0;req_b_we<=0;req_a_addr<=0;req_b_addr<=0;
  req_a_data<=0;req_b_data<=0;req_a_strobe<=0;advance_pending<=0;request_settle<=1;
 end else begin
  req_a_en<=mem_a_en;req_a_we<=mem_a_we;req_b_en<=mem_b_en;req_b_we<=mem_b_we;
  req_a_addr<=mem_a_addr;req_b_addr<=mem_b_addr;req_a_data<=mem_a_data;req_b_data<=mem_b_data;req_a_strobe<=mem_a_strobe;
  if(cache_step)begin advance_pending<=0;request_settle<=1;end
  else if(advance_pending)begin end
  else if(request_settle)request_settle<=0;
  else advance_pending<=cache_ready&&static_ready;
 end
end
`ifdef AUDIO_SIM_CLOCK
always @(posedge clk)if(rst_n&&cache_step&&!cache_ready)$fatal(1,"Audio commit without stable cached operands");
`endif
kwt_encoder_audio_axi_core_pool u_core(

.fabric_clk(clk),.core_step(cache_step),.kernel_owner_live(kernel_owner_live),.kernel_cancel(cancel),
.kernel_core_ready(kernel_core_ready),.kernel_pool_quiescent(kernel_pool_quiescent),.kernel_quiescent(kernel_quiescent),.kernel_fault(kernel_fault),
.kernel_pool_write_valid(kernel_pool_write_valid),.kernel_pool_write_ready(kernel_pool_write_ready),.kernel_pool_write_address(kernel_pool_write_address),.kernel_pool_write_data(kernel_pool_write_data),
.kernel_pool_read_request(kernel_pool_read_request),.kernel_pool_read_enable(kernel_pool_read_enable),.kernel_pool_read_ready(kernel_pool_read_ready),.kernel_pool_read_address(kernel_pool_read_address),.kernel_pool_read_data(kernel_pool_read_data),

.clk(core_clk),.rst_n(rst_n),.core_locked(core_locked),.irq(irq),
.s_axi_awaddr(wa),.s_axi_awprot(3'b0),.s_axi_awvalid(bridge==1&&!sent_a),.s_axi_awready(ca_ready),
.s_axi_wdata(wd),.s_axi_wstrb(ws),.s_axi_wvalid(bridge==1&&!sent_w),.s_axi_wready(cw_ready),
.s_axi_bresp(cb_resp),.s_axi_bvalid(cb_valid),.s_axi_bready(bridge==2&&cache_step),
.s_axi_araddr(ra),.s_axi_arprot(3'b0),.s_axi_arvalid(bridge==3),.s_axi_arready(cr_ready),
.s_axi_rdata(cr_data),.s_axi_rresp(cr_resp),.s_axi_rvalid(cr_valid),.s_axi_rready(bridge==4&&cache_step),
.mem_a_en(mem_a_en),.mem_a_we(mem_a_we),.mem_a_addr(mem_a_addr),.mem_a_data(mem_a_data),.mem_a_strobe(mem_a_strobe),.mem_a_q(mem_a_q),
.mem_b_en(mem_b_en),.mem_b_we(mem_b_we),.mem_b_addr(mem_b_addr),.mem_b_data(mem_b_data),.mem_b_q(mem_b_q));

trusted_audio_static_dual_router static_operands(
 .clk(clk),.security_reset_n(rst_n),.cancel(cancel),.authorized(authorized&&key_valid&&model_authorized),
 .request_stable(active&&!request_settle),.core_commit(cache_step),.current_context(current_context),
 .frontend_phase(frontend_phase),.parameter_object(parameter_object),
 .a_en(req_a_en),.a_we(req_a_we),.a_addr(req_a_addr),.b_en(req_b_en),.b_we(req_b_we),.b_addr(req_b_addr),
 .cache_a_en(cache_a_enable),.cache_b_en(cache_b_enable),.cache_a_q(cache_a_q),.cache_b_q(cache_b_q),.a_q(mem_a_q),.b_q(mem_b_q),
 .step_ready(static_ready),.quiescent(static_router_quiescent),.fault(static_router_fault),
 .request_valid(static_request_valid),.request_ready(static_request_ready),.request_object(static_request_object),.request_word_index(static_request_word_index),
 .response_valid(static_response_valid),.response_ready(static_response_ready),.response_error(static_response_error),.response_object(static_response_object),.response_word_index(static_response_word_index),.response_data(static_response_data),.response_context(static_response_context),.static_quiescent(static_quiescent));
wire typed_cache_fault;
assign cache_fault=typed_cache_fault||static_router_fault||kernel_fault;
trusted_audio_typed_ddr_cache cache(
 .clk(clk),.security_reset_n(security_reset_n),.cache_reset_n(rst_n),.cancel(cancel),.authorized(authorized),.key_valid(key_valid),.model_authorized(model_authorized),
 .authorization_epoch(authorization_epoch),.current_model_epoch(current_model_epoch),.current_key_session(current_key_session),
 .clip_begin_valid(clip_begin_valid),.clip_begin_ready(clip_begin_ready),.clip_session_id(clip_session_id),.clip_id(clip_id),.clip_epoch(authorization_epoch),.clip_source_id(source_id),.clip_generation(generation),
 .clip_release(clip_release),.clip_ready(clip_ready),.phase_active(phase_active),.phase_valid(phase_valid),.phase_ready(phase_ready),.phase_id(phase_id),
 .client_active(active),.flush(cache_flush||direct_flush_accept),.invalidate(cache_invalidate),.commit(cache_step),.clean(cache_clean),.step(cache_ready),.flush_done(cache_done),.cache_idle(cache_idle),.fault(typed_cache_fault),
 .a_en(cache_a_enable&&dynamic_a_allowed),.a_we(req_a_we),.a_addr(req_a_addr),.a_data(req_a_data),.a_strobe(req_a_strobe),.a_q(cache_a_q),
 .b_en(cache_b_enable&&dynamic_b_allowed),.b_we(req_b_we),.b_addr(req_b_addr),.b_data(req_b_data),.b_q(cache_b_q),
 .misses(cache_misses),.writebacks(cache_writebacks),.stalls(cache_stalls),.transport_quiescent(transport_quiescent),.quiescent(),
 .pool_granted(ledger_pool_granted),.pool_request(ledger_pool_request),.pool_read(ledger_pool_read),.pool_write(ledger_pool_write),.pool_read_address(ledger_pool_read_address),.pool_write_address(ledger_pool_write_address),.pool_read_data(ledger_pool_read_data),.pool_write_data(ledger_pool_write_data),
 .mac_request(mac_request),.mac_chain(mac_chain),.mac_data(mac_data),.mac_ready(mac_ready),.mac_response_valid(mac_response_valid),.mac_response_error(mac_response_error),.mac_tag(mac_tag),.mac_quiescent(mac_quiescent),
 .M_AXI_ARADDR(M_AXI_ARADDR),.M_AXI_ARLEN(M_AXI_ARLEN),.M_AXI_ARSIZE(M_AXI_ARSIZE),.M_AXI_ARBURST(M_AXI_ARBURST),.M_AXI_ARVALID(M_AXI_ARVALID),.M_AXI_ARREADY(M_AXI_ARREADY),.M_AXI_RDATA(M_AXI_RDATA),.M_AXI_RRESP(M_AXI_RRESP),.M_AXI_RLAST(M_AXI_RLAST),.M_AXI_RVALID(M_AXI_RVALID),.M_AXI_RREADY(M_AXI_RREADY),.M_AXI_AWADDR(M_AXI_AWADDR),.M_AXI_AWLEN(M_AXI_AWLEN),.M_AXI_AWSIZE(M_AXI_AWSIZE),.M_AXI_AWBURST(M_AXI_AWBURST),.M_AXI_AWVALID(M_AXI_AWVALID),.M_AXI_AWREADY(M_AXI_AWREADY),.M_AXI_WDATA(M_AXI_WDATA),.M_AXI_WSTRB(M_AXI_WSTRB),.M_AXI_WLAST(M_AXI_WLAST),.M_AXI_WVALID(M_AXI_WVALID),.M_AXI_WREADY(M_AXI_WREADY),.M_AXI_BRESP(M_AXI_BRESP),.M_AXI_BVALID(M_AXI_BVALID),.M_AXI_BREADY(M_AXI_BREADY));
always @(posedge clk)begin
 if(!rst_n)begin
  ah<=0;wh<=0;rh<=0;wa<=0;ra<=0;wd<=0;ws<=0;bridge<=0;sent_a<=0;sent_w<=0;
  active<=0;cache_flush<=0;cache_invalidate<=0;flush_completions<=0;
  s_axi_bvalid<=0;s_axi_bresp<=0;s_axi_rvalid<=0;s_axi_rdata<=0;s_axi_rresp<=0;
 end else begin
  cache_flush<=0;cache_invalidate<=0;
  if(cache_done)flush_completions<=flush_completions+1;
  if(s_axi_awvalid&&s_axi_awready)begin ah<=1;wa<=s_axi_awaddr;end
  if(s_axi_wvalid&&s_axi_wready)begin wh<=1;wd<=s_axi_wdata;ws<=s_axi_wstrb;end
  if(s_axi_arvalid&&s_axi_arready)begin rh<=1;ra<=s_axi_araddr;end
  if(s_axi_bvalid&&s_axi_bready)s_axi_bvalid<=0;
  if(s_axi_rvalid&&s_axi_rready)s_axi_rvalid<=0;
  case(bridge)
   0:if(ah&&wh&&!s_axi_bvalid)begin
    if(wa>=21'h200&&wa<=21'h23c)begin
     ah<=0;wh<=0;s_axi_bvalid<=1;s_axi_bresp<=2;
     if(ws==15&&wa==21'h200&&!core_locked&&cache_idle&&wd<=1&&(!wd[0]||can_enable))begin
      if(wd[0])begin active<=1;s_axi_bresp<=0;end
      else if(cache_clean)begin active<=0;s_axi_bresp<=0;end
     end else if(ws==15&&wa==21'h204&&!core_locked&&cache_idle&&wd!=0&&wd<=3)begin
      cache_flush<=wd[0];cache_invalidate<=wd[1];s_axi_bresp<=0;
     end
    end else if(!active||cache_fault)begin ah<=0;wh<=0;s_axi_bvalid<=1;s_axi_bresp<=2;end
    else begin bridge<=1;sent_a<=0;sent_w<=0;end
   end else if(rh&&!s_axi_rvalid)begin
    if(ra>=21'h200&&ra<=21'h23c)begin
     rh<=0;s_axi_rvalid<=1;s_axi_rresp<=0;
     case(ra)
      21'h200:s_axi_rdata<={31'b0,active};
      21'h208:s_axi_rdata<={28'b0,core_locked,cache_fault,!cache_idle,active};
      21'h20c:s_axi_rdata<=cache_misses;
      21'h210:s_axi_rdata<=cache_writebacks;
      21'h214:s_axi_rdata<=cache_stalls;
      21'h218:s_axi_rdata<=32'h41554431;
      21'h21c:s_axi_rdata<=flush_completions;
      default:begin s_axi_rresp<=2;s_axi_rdata<=0;end
     endcase
    end else if(!active||cache_fault)begin rh<=0;s_axi_rvalid<=1;s_axi_rresp<=2;s_axi_rdata<=0;end
    else bridge<=3;
   end
   1:if(cache_step)begin
    if(ca_ready)sent_a<=1;
    if(cw_ready)sent_w<=1;
    if((sent_a||ca_ready)&&(sent_w||cw_ready))bridge<=2;
   end
   2:if(cache_step&&cb_valid)begin ah<=0;wh<=0;s_axi_bvalid<=1;s_axi_bresp<=cb_resp;bridge<=0;end
   3:if(cache_step&&cr_ready)bridge<=4;
   4:if(cache_step&&cr_valid)begin rh<=0;s_axi_rvalid<=1;s_axi_rresp<=cr_resp;s_axi_rdata<=cr_data;bridge<=0;end
   default:bridge<=0;
  endcase
  // Finish the external transaction with an error if DDR fails. The arithmetic
  // core remains frozen; management status stays readable for explicit recovery.
  if(cache_fault&&bridge!=0)begin
   if(bridge==1||bridge==2)begin ah<=0;wh<=0;s_axi_bvalid<=1;s_axi_bresp<=2;end
   else begin rh<=0;s_axi_rvalid<=1;s_axi_rresp<=2;s_axi_rdata<=0;end
   bridge<=0;
  end
 end
end
endmodule
