// Shared-SRAM DMA: one read and one write per cycle after pipeline fill.
// Handles overlap in memmove direction; no DDR/external master is required.
// Opcode6 ABI: source=word1, destination=word3, word_count=word13[17:0].
module kwt_memory_copy(
    input wire clk,rst_n,clear,start,
    input wire [16:0] source,destination,
    input wire [17:0] word_count,
    output reg busy,done,fault,
    output reg [31:0] cycles,
    output wire a_enable,b_enable,b_write,
    output wire [16:0] a_address,b_address,
    output wire [31:0] b_write_data,
    input wire [31:0] a_read_data
);
    reg reverse;
    reg [17:0] length,issued;
    reg [16:0] read_pointer,dest_pointer,response_dest,write_pointer;
    reg read_pending,read_last,write_pending,write_last;
    reg [31:0] payload;
    wire issue=busy&&!clear&&issued<length;
    assign a_enable=issue;
    assign a_address=read_pointer;
    assign b_enable=busy&&!clear&&write_pending;
    assign b_write=b_enable;
    assign b_address=write_pointer;
    assign b_write_data=payload;
    always @(posedge clk) begin
        if(!rst_n||clear) begin
            busy<=0;done<=0;fault<=0;cycles<=0;reverse<=0;length<=0;issued<=0;
            read_pointer<=0;dest_pointer<=0;response_dest<=0;write_pointer<=0;
            read_pending<=0;read_last<=0;write_pending<=0;write_last<=0;payload<=0;
        end else begin
            read_pending<=issue;write_pending<=read_pending;
            if(start&&!busy) begin
                busy<=1;done<=0;fault<=0;cycles<=0;length<=word_count;issued<=0;
                read_pending<=0;write_pending<=0;
                reverse<=destination>source&&{1'b0,destination}<{1'b0,source}+word_count;
                if(destination>source&&{1'b0,destination}<{1'b0,source}+word_count) begin
                    read_pointer<=source+word_count-1;dest_pointer<=destination+word_count-1;
                end else begin read_pointer<=source;dest_pointer<=destination;end
                if(word_count==0||{1'b0,source}+word_count>131072||{1'b0,destination}+word_count>131072) begin
                    busy<=0;done<=1;fault<=1;
                end else if(source==destination) begin busy<=0;done<=1;end
            end else if(busy) begin
                cycles<=cycles+1;
                if(issue) begin
                    issued<=issued+1;response_dest<=dest_pointer;read_last<=issued==length-1;
                    read_pointer<=reverse?read_pointer-1:read_pointer+1;
                    dest_pointer<=reverse?dest_pointer-1:dest_pointer+1;
                end
                if(read_pending) begin
                    payload<=a_read_data;write_pointer<=response_dest;write_last<=read_last;
                end
                if(write_pending&&write_last) begin busy<=0;done<=1;end
            end
        end
    end
endmodule
