`timescale 1ns/1ps
// Registered core-memory episode to one existing authenticated static reader.
// Static model operands never touch the dynamic DDR cache. Returned words are
// held until the actual gated core edge, including ledger-driven fabric pauses.
module trusted_audio_static_dual_router(
 input wire clk,security_reset_n,cancel,authorized,request_stable,core_commit,
 input wire [287:0] current_context,
 input wire frontend_phase,input wire [8:0] parameter_object,
 input wire a_en,a_we,b_en,b_we,input wire [16:0]a_addr,b_addr,
 output wire cache_a_en,cache_b_en,output wire [31:0]a_q,b_q,
 input wire [31:0]cache_a_q,cache_b_q,
 output wire step_ready,quiescent,output reg fault,
 output wire request_valid,input wire request_ready,output wire [8:0]request_object,
 output wire [31:0]request_word_index,
 input wire response_valid,output wire response_ready,input wire response_error,
 input wire [8:0]response_object,input wire [31:0]response_word_index,response_data,
 input wire [287:0]response_context,input wire static_quiescent
);
 localparam IDLE=0,OFFER_A=1,WAIT_A=2,OFFER_B=3,WAIT_B=4,HOLD=5,DRAIN=6;
 reg[2:0]state;reg bound_a,bound_b,aborted;
 reg[8:0]obj_a,obj_b;reg[31:0]idx_a,idx_b,value_a,value_b;
 reg[287:0]bound_context;reg returned_a_static,returned_b_static;
 reg[31:0]returned_a,returned_b;
 wire live=authorized&&!cancel&&!aborted&&!fault&&current_context==bound_context;
 wire a_parameter=a_addr<17'd49792;
 wire b_parameter=b_addr<17'd49792;
 wire a_front=a_addr>=17'd116416&&a_addr<17'd125376;
 wire b_front=b_addr>=17'd116416&&b_addr<17'd125376;
 wire a_static=a_en&&(a_parameter||a_front);
 wire b_static=b_en&&(b_parameter||b_front);
 wire map_a_good=(!a_parameter||(!frontend_phase&&parameter_object>=296&&parameter_object<=307))&&(!a_front||frontend_phase);
 wire map_b_good=(!b_parameter||(!frontend_phase&&parameter_object>=296&&parameter_object<=307))&&(!b_front||frontend_phase);
 assign cache_a_en=a_en&&!a_static;
 assign cache_b_en=b_en&&!b_static;
 // The old cache updates q on the actual core edge. Returning an already
 // fetched static value before that edge would advance memory by one cycle.
 assign a_q=returned_a_static?returned_a:cache_a_q;
 assign b_q=returned_b_static?returned_b:cache_b_q;
 assign step_ready=authorized&&!cancel&&!fault&&request_stable&&
  ((!a_static&&!b_static&&state==IDLE)||(state==HOLD&&live));
 assign quiescent=state==IDLE&&static_quiescent;
 assign request_valid=state==OFFER_A||state==OFFER_B;
 assign request_object=state==OFFER_A?obj_a:obj_b;
 assign request_word_index=state==OFFER_A?idx_a:idx_b;
 assign response_ready=state==WAIT_A||state==WAIT_B;
 wire response_match=response_context==bound_context&&!response_error&&
  response_object==(state==WAIT_A?obj_a:obj_b)&&response_word_index==(state==WAIT_A?idx_a:idx_b);
 always @(posedge clk)begin
  if(!security_reset_n)begin state<=IDLE;bound_a<=0;bound_b<=0;aborted<=0;obj_a<=0;obj_b<=0;idx_a<=0;idx_b<=0;value_a<=0;value_b<=0;bound_context<=0;fault<=0;returned_a_static<=0;returned_b_static<=0;returned_a<=0;returned_b<=0;end
  else begin
   if(core_commit&&step_ready)begin
    if(a_en)begin returned_a_static<=a_static;if(a_static)returned_a<=value_a;end
    if(b_en)begin returned_b_static<=b_static;if(b_static)returned_b<=value_b;end
   end
   if(state!=IDLE&&!live)begin aborted<=1;fault<=1;end
   case(state)
    IDLE:if(request_stable&&authorized&&!cancel&&!fault&&(a_static||b_static))begin
     bound_context<=current_context;aborted<=0;bound_a<=a_static;bound_b<=b_static;
     obj_a<=a_front?9'd308:parameter_object;obj_b<=b_front?9'd308:parameter_object;
     idx_a<=a_front?{15'd0,a_addr}-32'd116416:{15'd0,a_addr};
     idx_b<=b_front?{15'd0,b_addr}-32'd116416:{15'd0,b_addr};
     if((a_static&&(a_we||!map_a_good))||(b_static&&(b_we||!map_b_good)))begin fault<=1;aborted<=1;state<=DRAIN;end
     else state<=a_static?OFFER_A:OFFER_B;
    end
    // Already-offered requests stay offered on revoke, so the real reader can
    // consume them as error tokens. Accepted responses always actually drain.
    OFFER_A:if(request_ready)state<=WAIT_A;
    OFFER_B:if(request_ready)state<=WAIT_B;
    WAIT_A:if(response_valid)begin
     if(!live||!response_match)begin fault<=1;aborted<=1;state<=DRAIN;end
     else begin value_a<=response_data;state<=bound_b?OFFER_B:HOLD;end
    end
    WAIT_B:if(response_valid)begin
     if(!live||!response_match)begin fault<=1;aborted<=1;state<=DRAIN;end
     else begin value_b<=response_data;state<=HOLD;end
    end
    HOLD:if(!live)state<=DRAIN;else if(core_commit)begin state<=IDLE;bound_a<=0;bound_b<=0;end
    DRAIN:if(static_quiescent)begin state<=IDLE;bound_a<=0;bound_b<=0;value_a<=0;value_b<=0;end
    default:begin fault<=1;state<=DRAIN;end
   endcase
   if(core_commit&&!step_ready)begin fault<=1;aborted<=1;end
  end
 end
endmodule
