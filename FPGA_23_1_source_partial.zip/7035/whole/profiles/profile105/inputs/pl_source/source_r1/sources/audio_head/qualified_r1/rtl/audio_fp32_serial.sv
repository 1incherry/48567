`timescale 1ns/1ps
// Separate IEEE754 binary32 operations: never a fused multiply-add.
// Berkeley HardFloat Release1 supplies the unmodified numerical primitives.
// Raw computation and rounding are separated by a real register boundary.
module audio_fp32_serial(
 input wire clk,rst_n,request_valid,operation_add,
 output wire request_ready,input wire [31:0] operand_a,operand_b,
 output wire response_valid,input wire response_ready,
 output reg [31:0] response_data,output reg [4:0] response_flags,
 output wire quiescent
);
 reg [1:0] state;
 wire [32:0] input_a,input_b,rounded;
 reg [32:0] a,b;
 reg add_selected;
 wire mi,mn,mf,mz,ms,ai,an,af,az,asign;
 wire signed [9:0] me,ae;
 wire [26:0] mq,aq;
 reg ri,rn,rf,rz,rs;
 reg signed [9:0] re;
 reg [26:0] rq;
 wire [4:0] flags;
 wire [31:0] ieee_result;
 fNToRecFN #(8,24) a_convert(operand_a,input_a);
 fNToRecFN #(8,24) b_convert(operand_b,input_b);
 mulRecFNToRaw #(8,24) multiply(1'b1,a,b,mi,mn,mf,mz,ms,me,mq);
 addRecFNToRaw #(8,24) add(1'b1,1'b0,a,b,3'b000,ai,an,af,az,asign,ae,aq);
 roundRawFNToRecFN #(8,24,0) rounding(1'b1,ri,1'b0,rn,rf,rz,rs,re,rq,3'b000,rounded,flags);
 recFNToFN #(8,24) output_convert(rounded,ieee_result);
 assign request_ready=state==0;
 assign response_valid=state==3;
 assign quiescent=state==0;
 always @(posedge clk)begin
  if(!rst_n)begin state<=0;a<=0;b<=0;add_selected<=0;ri<=0;rn<=0;rf<=0;rz<=0;rs<=0;re<=0;rq<=0;response_data<=0;response_flags<=0;end
  else case(state)
   0:if(request_valid)begin
    a<=input_a;b<=input_b;add_selected<=operation_add;state<=1;
   end
   1:begin
    ri<=add_selected?ai:mi;rn<=add_selected?an:mn;rf<=add_selected?af:mf;
    rz<=add_selected?az:mz;rs<=add_selected?asign:ms;re<=add_selected?ae:me;rq<=add_selected?aq:mq;state<=2;
   end
   2:begin response_data<=ieee_result;response_flags<=flags;state<=3;end
   3:if(response_ready)state<=0;
   default:state<=0;
  endcase
 end
endmodule
