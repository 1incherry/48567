// Arithmetic helpers shared by the programmable encoder engines.
function automatic signed [63:0] kwt_round64;
    input signed [63:0] value;
    input integer shift;
    reg signed [63:0] quotient;
    reg round_bit,sticky;
    begin
        if(shift<=0) kwt_round64=value<<<(-shift);
        else if(shift>=64) kwt_round64=0;
        else begin
            quotient=value>>>shift;
            round_bit=$unsigned((value>>(shift-1))&1);
            sticky=|(value<<(65-shift));
            // Keep both operands signed and at the full result width.
            // An unsigned one-bit increment can lose the sign extension
            // when synthesis narrows an intermediate arithmetic shift.
            kwt_round64=quotient+((round_bit&&(sticky||quotient[0]))?64'sd1:64'sd0);
        end
    end
endfunction
function automatic signed [31:0] kwt_sat32;
    input signed [63:0] value;
    input integer bits;
    reg signed [63:0] high,low;
    reg [63:0] high_bits,low_bits,value_bits;
    begin
        // Command validation restricts output format to signed16/signed24.
        // Constant limits avoid a second variable-width barrel shifter.
        high=bits==16?64'sd32767:64'sd8388607;
        low=bits==16?-64'sd32768:-64'sd8388608;
        high_bits=$unsigned(high);low_bits=$unsigned(low);value_bits=$unsigned(value);
        if(value>high) kwt_sat32=$signed(high_bits[31:0]);
        else if(value<low) kwt_sat32=$signed(low_bits[31:0]);
        else kwt_sat32=$signed(value_bits[31:0]);
    end
endfunction
