`timescale 1ns/1ps
// Four output-channel MACs share one80-word log-Mel scratchpad.
// Coefficients Q30,log input Q24,output MFCC Q14 signed24,RNE.
// Carry-save feedback avoids a64-bit carry chain on every accumulation.
module kwt_audio_dct40 #(
    parameter COEFFICIENT_FILE="model/audio_dct4_q30.hex"
)(
    input wire clk,rst_n,clear,start,in_valid,
    output wire in_ready,
    input wire signed [31:0] in_log,
    input wire [6:0] in_index,
    output wire out_valid,
    input wire out_ready,
    output wire signed [23:0] out_mfcc,
    output wire [5:0] out_index,
    output wire busy,
    output reg done,error
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
    localparam IDLE=0,LOAD=1,PREP=2,RUN=3,FINAL_SUM=4,RNE=5,CHECK=6,EMIT=7;
    reg [2:0] state;
    reg [6:0] load_index,issue_index;
    reg [3:0] group;
    reg [1:0] lane;
    reg [127:0] coefficients[0:799],coefficient_q,operand_coefficients;
    initial $readmemh(COEFFICIENT_FILE,coefficients);
    reg signed [31:0] operand;
    reg read_pending,read_last,operand_valid,operand_last,product_valid,product_last;
    reg signed [63:0] product[0:3],sum_part[0:3],carry_part[0:3],final_sum[0:3],rounded[0:3];
    reg signed [23:0] results[0:3];
    wire live=rst_n&&!clear;
    assign in_ready=live&&state==LOAD;
    assign out_valid=live&&state==EMIT;
    assign out_mfcc=results[lane];assign out_index={group,lane};
    assign busy=state!=IDLE;
    wire loading=in_ready&&in_valid;
    wire issue=live&&state==RUN&&issue_index<80;
    wire [31:0] memory_q;
    kwt_audio_scratch_ram #(.WIDTH(32),.DEPTH(128),.ADDR_W(7)) log_ram(
        .clk(clk),.a_en(loading||issue),.a_we(loading),.a_addr(loading?load_index:issue_index),
        .a_data(in_log),.a_strobe(4'hf),.a_q(memory_q),
        .b_en(1'b0),.b_we(1'b0),.b_addr(7'd0),.b_data(32'd0),.b_q());
    integer j;
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            state<=IDLE;load_index<=0;issue_index<=0;group<=0;lane<=0;
            coefficient_q<=0;operand_coefficients<=0;operand<=0;
            read_pending<=0;read_last<=0;operand_valid<=0;operand_last<=0;product_valid<=0;product_last<=0;
            done<=0;error<=0;
            for(j=0;j<4;j=j+1)begin product[j]<=0;sum_part[j]<=0;carry_part[j]<=0;final_sum[j]<=0;rounded[j]<=0;results[j]<=0;end
        end else begin
            done<=0;
            read_pending<=issue;
            operand_valid<=read_pending&&state==RUN;
            product_valid<=operand_valid&&state==RUN;
            if(issue)begin
                coefficient_q<=coefficients[group*10'd80+issue_index];
                issue_index<=issue_index+1'b1;read_last<=issue_index==79;
            end
            if(read_pending&&state==RUN)begin operand<=memory_q;operand_coefficients<=coefficient_q;operand_last<=read_last;end
            if(operand_valid&&state==RUN)begin
                for(j=0;j<4;j=j+1)product[j]<=operand*$signed(operand_coefficients[j*32+:32]);
                product_last<=operand_last;
            end
            if(product_valid&&state==RUN)begin
                for(j=0;j<4;j=j+1)begin
                    sum_part[j]<=sum_part[j]^carry_part[j]^product[j];
                    carry_part[j]<=((sum_part[j]&carry_part[j])|(sum_part[j]&product[j])|(carry_part[j]&product[j]))<<1;
                end
            end
            case(state)
                IDLE:if(start)begin state<=LOAD;load_index<=0;group<=0;error<=0;end
                LOAD:if(in_valid)begin
                    if(in_index!=load_index||in_log< -32'sd463571610||in_log>32'sd463571610)error<=1;
                    if(load_index==79)state<=PREP;else load_index<=load_index+1'b1;
                end
                PREP:begin
                    issue_index<=0;for(j=0;j<4;j=j+1)begin sum_part[j]<=0;carry_part[j]<=0;end
                    state<=RUN;
                end
                RUN:if(product_valid&&product_last)state<=FINAL_SUM;
                FINAL_SUM:begin for(j=0;j<4;j=j+1)final_sum[j]<=sum_part[j]+carry_part[j];state<=RNE;end
                RNE:begin for(j=0;j<4;j=j+1)rounded[j]<=kwt_round64(final_sum[j],40);state<=CHECK;end
                CHECK:begin
                    for(j=0;j<4;j=j+1)begin
                        results[j]<=rounded[j][23:0];
                        if(rounded[j]>64'sd8388607||rounded[j]< -64'sd8388608)error<=1;
                    end
                    lane<=0;state<=EMIT;
                end
                EMIT:if(out_ready)begin
                    if(lane!=3)lane<=lane+1'b1;
                    else if(group==9)begin done<=1;state<=IDLE;end
                    else begin group<=group+1'b1;state<=PREP;end
                end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
