`timescale 1ns/1ps
// Small DSP scratchpads use the permitted16x128 geometry, avoiding a full
// 4096-word macro for each80/244-word frame buffer. No storage reset/init.
module kwt_audio_scratch_ram #(
    parameter WIDTH=32,DEPTH=256,ADDR_W=$clog2(DEPTH)
)(
    input wire clk,a_en,a_we,b_en,b_we,
    input wire [ADDR_W-1:0] a_addr,b_addr,
    input wire [WIDTH-1:0] a_data,b_data,
    input wire [(WIDTH+7)/8-1:0] a_strobe,
    output wire [WIDTH-1:0] a_q,b_q
);
`ifdef KWT_USE_SRAM_BANKS
    kwt_sram_banked #(.WIDTH(WIDTH),.DEPTH(DEPTH),.MACRO_DEPTH(128),.ADDR_W(ADDR_W)) memory(.*);
`else
    kwt_bram #(.WIDTH(WIDTH),.DEPTH(DEPTH),.ADDR_W(ADDR_W)) memory(.*);
`endif
endmodule
