`timescale 1ns/1ps
// One actual reader/lease/service, four internal trusted consumers. The parent
// owns all clients; there is no CPU client. Offered/accepted requests survive
// revoke as error tokens until the existing reader's real release is quiet.
module trusted_audio_static_word_mux(
 input wire clk,security_reset_n,
 input wire [3:0]client_request,output wire [3:0]client_ready,
 input wire [35:0]client_object,input wire [127:0]client_index,
 output wire [3:0]client_response,input wire [3:0]client_response_ready,
 output wire response_error,output wire [8:0]response_object,
 output wire [31:0]response_index,response_data,output wire [287:0]response_context,
 output wire request_valid,input wire request_ready,output wire [8:0]request_object,
 output wire [31:0]request_index,input wire response_valid,output wire response_ready,
 input wire reader_response_error,input wire [8:0]reader_response_object,
 input wire [31:0]reader_response_index,reader_response_data,
 input wire [287:0]reader_response_context,input wire reader_quiescent,
 output wire quiescent,output reg fault
);
 localparam IDLE=0,OFFER=1,WAIT_RESPONSE=2,DRAIN=3;
 reg[1:0]state,owner;reg[8:0]saved_object;reg[31:0]saved_index;
 reg[1:0]selected;integer i;
 always @*begin selected=0;for(i=3;i>=0;i=i-1)if(client_request[i])selected=i;end
 assign request_valid=state==OFFER;
 assign request_object=saved_object;assign request_index=saved_index;
 assign client_ready=state==OFFER&&request_ready?(4'b1<<owner):0;
 assign client_response=state==WAIT_RESPONSE&&response_valid?(4'b1<<owner):0;
 assign response_ready=state==WAIT_RESPONSE&&client_response_ready[owner];
 assign response_error=reader_response_error;
 assign response_object=reader_response_object;assign response_index=reader_response_index;
 assign response_data=reader_response_data;assign response_context=reader_response_context;
 assign quiescent=state==IDLE&&reader_quiescent;
 always @(posedge clk)begin
  if(!security_reset_n)begin state<=IDLE;owner<=0;saved_object<=0;saved_index<=0;fault<=0;end
  else case(state)
   IDLE:if(|client_request&&reader_quiescent)begin
    owner<=selected;saved_object<=client_object[selected*9+:9];saved_index<=client_index[selected*32+:32];state<=OFFER;
   end
   OFFER:begin
    if(!client_request[owner]||client_object[owner*9+:9]!=saved_object||client_index[owner*32+:32]!=saved_index)fault<=1;
    if(request_ready)state<=WAIT_RESPONSE;
   end
   WAIT_RESPONSE:if(response_valid&&response_ready)state<=DRAIN;
   DRAIN:if(reader_quiescent)state<=IDLE;
   default:begin fault<=1;state<=DRAIN;end
  endcase
 end
endmodule
