`timescale 1ns/1ps
// Serialized modalities share one sequence, source bundle, TX CDC and pixel CDC.
// All inputs originate in their actual private PL result banks.
module trusted_av_record_publisher(
 input wire clk,security_reset_n,authorization_live,job_start,
 input wire record_commit,record_visible,
 input wire [31:0] record_camera,record_session,record_frame,record_epoch,
 input wire [127:0] record_key_session,input wire [2:0] record_count,
 input wire [895:0] record_rois,input wire [51:0] record_indices,input wire [511:0] record_results,
 input wire audio_record_commit,audio_record_visible,input wire [287:0] audio_record_context,
 input wire [3:0] audio_record_class,input wire [383:0] audio_record_logits,
 input wire tx_ready,pixel_ready,
 output wire snapshot_valid,output reg [2047:0] snapshot_data,
 output wire admission_ready,quiescent,display_current_live,
 output reg fault,output reg [31:0] sequence_id
);
 reg pending,pending_audio,display_current,display_audio;
 wire both_commit=record_commit&&audio_record_commit;
 wire selected_visible=pending_audio?audio_record_visible:record_visible;
 wire display_visible=display_audio?audio_record_visible:record_visible;
 wire publish_live=authorization_live&&selected_visible&&!job_start&&!fault&&!record_commit&&!audio_record_commit;
 wire [2047:0] audio_body;
 trusted_audio_report_body audio_formatter(.report_sequence(sequence_id+32'd1),.result_context(audio_record_context),.result_class(audio_record_class),.result_logits(audio_record_logits),.body(audio_body));
 assign snapshot_valid=pending&&publish_live&&(pending_audio||record_count<=4)&&tx_ready&&pixel_ready;
 assign admission_ready=!pending&&tx_ready&&pixel_ready&&!record_commit&&!audio_record_commit&&!fault;
 assign quiescent=!pending&&tx_ready&&pixel_ready;
 assign display_current_live=display_current&&authorization_live&&display_visible&&!job_start&&!fault&&!record_commit&&!audio_record_commit;
 integer i;
 always @*begin
  snapshot_data=0;
  if(pending_audio)snapshot_data=audio_body;
  else begin
   snapshot_data[2047-0*8-:32]=32'h4e545232;
   snapshot_data[2047-4*8-:32]=32'h00020001;
   snapshot_data[2047-8*8-:32]=sequence_id+1'b1;
   snapshot_data[2047-12*8-:32]=record_camera;
   snapshot_data[2047-16*8-:32]=record_session;
   snapshot_data[2047-20*8-:32]=record_frame;
   snapshot_data[2047-24*8-:32]=record_epoch;
   snapshot_data[2047-28*8-:32]={29'd0,record_count};
   snapshot_data[2047-32*8-:128]=record_key_session;
   // Both actual banks have already sanitized and validated their payload.
   for(i=0;i<4;i=i+1)begin
    snapshot_data[2047-(48+i*28)*8-:224]=record_rois[i*224+:224];
    snapshot_data[2047-(160+i*2)*8-:16]={3'd0,record_indices[i*13+:13]};
    snapshot_data[2047-(168+i*16)*8-:128]=record_results[i*128+:128];
   end
  end
 end
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin pending<=0;pending_audio<=0;display_current<=0;display_audio<=0;fault<=0;sequence_id<=0;end
  else begin
   if(!authorization_live||!display_visible||job_start)display_current<=0;
   if(pending&&!publish_live)pending<=0;
   if(pending&&!pending_audio&&record_visible&&record_count>4)begin fault<=1;pending<=0;end
   if(job_start&&!admission_ready)fault<=1;
   if(snapshot_valid)begin pending<=0;display_current<=1;display_audio<=pending_audio;sequence_id<=sequence_id+1'b1;end
   if(record_commit||audio_record_commit)begin
    if(pending||both_commit||sequence_id==32'hffffffff)fault<=1;
    else if(authorization_live&&!job_start)begin pending<=1;pending_audio<=audio_record_commit;display_current<=0;end
   end
  end
 end
endmodule
