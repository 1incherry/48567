`timescale 1ns/1ps
// Full 64-bit unsigned magnitude restoring division, signed nearest-even result.
// Variable latency is intentionally replaced by bounded 64-step arithmetic.
// The public busy/valid/error/clear contract matches kwt_divide64; no round,
// precision, denominator high bit or signed INT64_MIN behavior is removed.
module kwt_divide64(
 input wire clk,rst_n,clear,start,
 input wire signed [63:0] numerator,input wire [63:0] denominator,
 output reg busy,valid,error,output reg signed [63:0] result
);
 localparam IDLE=0,DIVIDE=1,ROUND=2,SIGN=3;
 reg [1:0]state;
 reg negative;reg [5:0]step;
 reg [63:0]dividend,divisor,quotient,remainder,rounded;
 wire [64:0]trial={remainder,dividend[63]};
 // One extra borrow bit makes comparison and subtraction one datapath.
 wire [65:0]difference={1'b0,trial}-{2'b0,divisor};
 wire ge=!difference[65];
 wire [64:0]twice_remainder={remainder,1'b0};
 wire increment=(twice_remainder>{1'b0,divisor})||
                 ((twice_remainder=={1'b0,divisor})&&quotient[0]);
 always @(posedge clk)begin
  if(!rst_n||clear)begin
   busy<=0;valid<=0;error<=0;result<=0;state<=IDLE;
   negative<=0;step<=0;dividend<=0;divisor<=1;quotient<=0;remainder<=0;rounded<=0;
  end else begin
   valid<=0;
   if(start&&!busy)begin
    error<=0;
    if(denominator==0)begin valid<=1;error<=1;result<=0;end
    else begin
     busy<=1;state<=DIVIDE;negative<=numerator[63];step<=0;
     dividend<=numerator[63]?(~$unsigned(numerator)+64'd1):$unsigned(numerator);
     divisor<=denominator;quotient<=0;remainder<=0;
    end
   end else if(busy)case(state)
    DIVIDE:begin
     dividend<={dividend[62:0],1'b0};
     remainder<=ge?difference[63:0]:trial[63:0];
     quotient<={quotient[62:0],ge};
     if(step==63)state<=ROUND;else step<=step+1'b1;
    end
    ROUND:begin rounded<=quotient+increment;state<=SIGN;end
    SIGN:begin result<=negative?-$signed(rounded):$signed(rounded);busy<=0;valid<=1;state<=IDLE;end
    default:begin busy<=0;valid<=1;error<=1;state<=IDLE;end
   endcase
  end
 end
endmodule
