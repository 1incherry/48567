`timescale 1ns/1ps
// The actual audio_ddr_cache issues only aligned, full-strobe, single32B beats.
// This is its private transactional adapter, not a general CPU AXI firewall.
// Canceled/not-admitted requests complete locally with SLVERR. Once accepted
// by the typed guard they retain their original read/write response routing
// until real backend/MAC/ledger drain; no reset is used to abandon a request.
module trusted_audio_cache_line_bridge(
 input wire clk,security_reset_n,cancel,admission_live,
 input wire [31:0] S_ARADDR,input wire [7:0] S_ARLEN,input wire [2:0] S_ARSIZE,
 input wire [1:0] S_ARBURST,input wire S_ARVALID,output wire S_ARREADY,
 output wire [255:0] S_RDATA,output wire [1:0] S_RRESP,output wire S_RLAST,S_RVALID,input wire S_RREADY,
 input wire [31:0] S_AWADDR,input wire [7:0] S_AWLEN,input wire [2:0] S_AWSIZE,
 input wire [1:0] S_AWBURST,input wire S_AWVALID,output wire S_AWREADY,
 input wire [255:0] S_WDATA,input wire [31:0] S_WSTRB,input wire S_WLAST,S_WVALID,output wire S_WREADY,
 output wire [1:0] S_BRESP,output wire S_BVALID,input wire S_BREADY,
 output wire request_valid,input wire request_ready,output wire request_write,
 output wire [31:0] request_address,output wire [255:0] request_data,
 input wire response_valid,output wire response_ready,input wire response_error,input wire [255:0] response_data,
 output wire quiescent,output reg fault
);
 localparam IDLE=0,OFFER=1,WAIT=2;
 reg[1:0]state;reg ah,wh,rh,awbad,wbad,arbad;
 reg[31:0]awaddr,araddr;reg[255:0]wdata;
 reg writing,poisoned,bvalid,rvalid,bad_b,bad_r;
 reg[255:0]rdata;
 wire live=admission_live&&!cancel;
 assign S_AWREADY=security_reset_n&&!ah&&!bvalid&&!(state!=IDLE&&writing);
 assign S_WREADY=security_reset_n&&!wh&&!bvalid&&!(state!=IDLE&&writing);
 assign S_ARREADY=security_reset_n&&!rh&&!rvalid&&!(state!=IDLE&&!writing);
 assign S_BVALID=bvalid;assign S_BRESP=(bad_b||!live)?2'b10:2'b00;
 assign S_RVALID=rvalid;assign S_RRESP=(bad_r||!live)?2'b10:2'b00;
 assign S_RDATA=(bad_r||!live)?256'd0:rdata;assign S_RLAST=1'b1;
 assign request_valid=state==OFFER&&live&&!poisoned&&!fault;
 assign request_write=writing;
 assign request_address=writing?awaddr:araddr;
 assign request_data=wdata;
 assign response_ready=state==WAIT;
 assign quiescent=state==IDLE&&!ah&&!wh&&!rh&&!bvalid&&!rvalid&&
  !S_AWVALID&&!S_WVALID&&!S_ARVALID;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=IDLE;ah<=0;wh<=0;rh<=0;awbad<=0;wbad<=0;arbad<=0;
   awaddr<=0;araddr<=0;wdata<=0;writing<=0;poisoned<=0;
   bvalid<=0;rvalid<=0;bad_b<=0;bad_r<=0;rdata<=0;fault<=0;
  end else begin
   if(S_AWVALID&&S_AWREADY)begin ah<=1;awaddr<=S_AWADDR;awbad<=S_AWADDR[4:0]!=0||S_AWLEN!=0||S_AWSIZE!=5||S_AWBURST!=1;end
   if(S_WVALID&&S_WREADY)begin wh<=1;wdata<=S_WDATA;wbad<=S_WSTRB!=32'hffffffff||!S_WLAST;end
   if(S_ARVALID&&S_ARREADY)begin rh<=1;araddr<=S_ARADDR;arbad<=S_ARADDR[4:0]!=0||S_ARLEN!=0||S_ARSIZE!=5||S_ARBURST!=1;end
   if(bvalid&&S_BREADY)bvalid<=0;
   if(rvalid&&S_RREADY)rvalid<=0;
   if(!live)begin
    if(state!=IDLE)poisoned<=1;
    if(bvalid)bad_b<=1;
    if(rvalid)begin bad_r<=1;rdata<=0;end
   end
   case(state)
    IDLE:begin
     poisoned<=0;
     if(ah&&wh&&!bvalid)begin
      writing<=1;
      if(awbad||wbad||!live||fault)begin
       ah<=0;wh<=0;bvalid<=1;bad_b<=1;
       if(awbad||wbad)fault<=1;
      end else state<=OFFER;
     end else if(rh&&!rvalid)begin
      writing<=0;
      if(arbad||!live||fault)begin
       rh<=0;rvalid<=1;bad_r<=1;rdata<=0;
       if(arbad)fault<=1;
      end else state<=OFFER;
     end
    end
    OFFER:if(!live||poisoned||fault)begin
     if(writing)begin ah<=0;wh<=0;bvalid<=1;bad_b<=1;end
     else begin rh<=0;rvalid<=1;bad_r<=1;rdata<=0;end
     state<=IDLE;
    end else if(request_ready)state<=WAIT;
    WAIT:if(response_valid)begin
     if(writing)begin ah<=0;wh<=0;bvalid<=1;bad_b<=response_error||poisoned||!live;end
     else begin rh<=0;rvalid<=1;bad_r<=response_error||poisoned||!live;
      rdata<=response_error||poisoned||!live?256'd0:response_data;end
     state<=IDLE;
    end
    default:begin fault<=1;state<=IDLE;end
   endcase
  end
 end
endmodule
