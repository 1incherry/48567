`timescale 1ns/1ps
// The command ABI and shared-memory layout remain identical to the verified
// scalar v5 baseline. Matrix commands use tiled16-PE hardware; all nonlinear
// and residual commands use the bit-exact scalar operator implementation.
`include "source_r1/sources/integration/source/audio/rtl/kwt_tile_bank.svh"
`include "source_r1/sources/integration/source/audio/rtl/kwt_kernel_bank.svh"
`include "source_r1/sources/integration/source/audio/rtl/kwt_pe4x4.svh"
`include "source_r1/sources/integration/source/audio/rtl/kwt_matmul_output_pipeline.svh"
`include "source_r1/sources/audio/compute_r1/rtl/kwt_tiled_matmul_pool.svh"
`include "source_r1/sources/integration/source/audio/rtl/kwt_memory_copy.svh"
`include "source_r1/sources/integration/source/audio/rtl/kwt_gelu_pipeline.svh"
`include "source_r1/sources/integration/source/audio/rtl/kwt_encoder_scalar.svh"
module kwt_encoder_engine_pool #(
    parameter EXP_FILE="kwt_exp.hex",GELU_FILE="kwt_gelu.hex",
    parameter PARALLEL_MATRIX=1
)(

    input wire fabric_clk,core_step,kernel_owner_live,kernel_cancel,
    output wire kernel_core_ready,kernel_pool_quiescent,kernel_quiescent,kernel_fault,
    output wire kernel_pool_write_valid,input wire kernel_pool_write_ready,
    output wire [11:0] kernel_pool_write_address,output wire [255:0] kernel_pool_write_data,
    output wire kernel_pool_read_request,kernel_pool_read_enable,input wire kernel_pool_read_ready,
    output wire [11:0] kernel_pool_read_address,input wire [255:0] kernel_pool_read_data,
    input wire clk,rst_n,clear,start,
    input wire [3:0] opcode,
    input wire [16:0] source_a,source_b,destination,bias_base,
    input wire [7:0] rows,
    input wire [8:0] columns,inner,
    input wire signed [7:0] shift_a,shift_b,
    input wire [5:0] output_bits,
    input wire has_bias,transpose_b,
    input wire [5:0] input_fraction,
    input wire [63:0] epsilon,
    output wire busy,done,fault,
    output wire [31:0] cycles,
    output wire a_enable,b_enable,b_write,
    output wire [16:0] a_address,b_address,
    output wire [31:0] b_write_data,
    input wire signed [31:0] a_read_data,b_read_data
);
    reg [1:0] selected;
    always @(posedge clk) begin
        if(!rst_n||clear) selected<=0;
        else if(start&&!busy) selected<=opcode==3?3:(opcode==6?2:(PARALLEL_MATRIX&&opcode==1?1:0));
    end
    wire scalar_busy,scalar_done,scalar_fault,scalar_ae,scalar_be,scalar_bw;
    wire tile_busy,tile_done,tile_fault,tile_ae,tile_be,tile_bw;
    wire [31:0] scalar_cycles,tile_cycles,scalar_wd,tile_wd;
    wire [16:0] scalar_aa,scalar_ba,tile_aa,tile_ba;
    wire copy_busy,copy_done,copy_fault,copy_ae,copy_be,copy_bw;
    wire [31:0] copy_cycles,copy_wd;
    wire [16:0] copy_aa,copy_ba;
    wire gelu_busy,gelu_done,gelu_fault,gelu_ae,gelu_be,gelu_bw;
    wire [31:0] gelu_cycles,gelu_wd;
    wire [16:0] gelu_aa,gelu_ba;
    wire matrix_start=start&&!busy&&PARALLEL_MATRIX&&opcode==1;
    wire scalar_start=start&&!busy&&opcode!=3&&opcode!=6&&(!PARALLEL_MATRIX||opcode!=1);
    kwt_encoder_scalar #(.EXP_FILE(EXP_FILE),.GELU_FILE(GELU_FILE),.ENABLE_MATRIX(!PARALLEL_MATRIX),.ENABLE_GELU(0)) scalar(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(scalar_start),
        .opcode(opcode),.source_a(source_a),.source_b(source_b),.destination(destination),.bias_base(bias_base),
        .rows(rows),.columns(columns),.inner(inner),.shift_a(shift_a),.shift_b(shift_b),.output_bits(output_bits),
        .has_bias(has_bias),.transpose_b(transpose_b),.input_fraction(input_fraction),.epsilon(epsilon),
        .busy(scalar_busy),.done(scalar_done),.fault(scalar_fault),.cycles(scalar_cycles),
        .a_enable(scalar_ae),.b_enable(scalar_be),.b_write(scalar_bw),
        .a_address(scalar_aa),.b_address(scalar_ba),.b_write_data(scalar_wd),
        .a_read_data(a_read_data),.b_read_data(b_read_data));
    kwt_tiled_matmul_pool tile(
        .fabric_clk(fabric_clk),.core_step(core_step),.kernel_owner_live(kernel_owner_live),.kernel_cancel(kernel_cancel),
        .kernel_core_ready(kernel_core_ready),.kernel_pool_quiescent(kernel_pool_quiescent),.kernel_quiescent(kernel_quiescent),.kernel_fault(kernel_fault),
        .kernel_pool_write_valid(kernel_pool_write_valid),.kernel_pool_write_ready(kernel_pool_write_ready),
        .kernel_pool_write_address(kernel_pool_write_address),.kernel_pool_write_data(kernel_pool_write_data),
        .kernel_pool_read_request(kernel_pool_read_request),.kernel_pool_read_enable(kernel_pool_read_enable),.kernel_pool_read_ready(kernel_pool_read_ready),
        .kernel_pool_read_address(kernel_pool_read_address),.kernel_pool_read_data(kernel_pool_read_data),

        .clk(clk),.rst_n(rst_n),.clear(clear),.start(matrix_start),
        .source_a(source_a),.source_b(source_b),.destination(destination),.bias_base(bias_base),
        .rows(rows),.columns(columns),.inner(inner),.shift_a(shift_a),.output_bits(output_bits),
        .has_bias(has_bias),.transpose_b(transpose_b),
        .busy(tile_busy),.done(tile_done),.fault(tile_fault),.cycles(tile_cycles),
        .a_enable(tile_ae),.b_enable(tile_be),.b_write(tile_bw),
        .a_address(tile_aa),.b_address(tile_ba),.b_write_data(tile_wd),
        .a_read_data(a_read_data),.b_read_data(b_read_data));
    kwt_memory_copy copy(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(start&&!busy&&opcode==6),
        .source(source_a),.destination(destination),.word_count(epsilon[17:0]),
        .busy(copy_busy),.done(copy_done),.fault(copy_fault),.cycles(copy_cycles),
        .a_enable(copy_ae),.b_enable(copy_be),.b_write(copy_bw),
        .a_address(copy_aa),.b_address(copy_ba),.b_write_data(copy_wd),.a_read_data(a_read_data));
    kwt_gelu_pipeline #(.GELU_FILE(GELU_FILE)) gelu(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(start&&!busy&&opcode==3),
        .source(source_a),.destination(destination),.rows(rows),.columns(columns),
        .shift_a(shift_a),.shift_b(shift_b),.input_fraction(input_fraction),.output_bits(output_bits),
        .busy(gelu_busy),.done(gelu_done),.fault(gelu_fault),.cycles(gelu_cycles),
        .a_enable(gelu_ae),.b_enable(gelu_be),.b_write(gelu_bw),.a_address(gelu_aa),.b_address(gelu_ba),
        .b_write_data(gelu_wd),.a_read_data(a_read_data));
    assign busy=selected==3?gelu_busy:(selected==2?copy_busy:(selected==1?tile_busy:scalar_busy));
    assign done=selected==3?gelu_done:(selected==2?copy_done:(selected==1?tile_done:scalar_done));
    assign fault=kernel_fault||(selected==3?gelu_fault:(selected==2?copy_fault:(selected==1?tile_fault:scalar_fault)));
    assign cycles=selected==3?gelu_cycles:(selected==2?copy_cycles:(selected==1?tile_cycles:scalar_cycles));
    assign a_enable=selected==3?gelu_ae:(selected==2?copy_ae:(selected==1?tile_ae:scalar_ae));
    assign b_enable=selected==3?gelu_be:(selected==2?copy_be:(selected==1?tile_be:scalar_be));
    assign b_write=selected==3?gelu_bw:(selected==2?copy_bw:(selected==1?tile_bw:scalar_bw));
    assign a_address=selected==3?gelu_aa:(selected==2?copy_aa:(selected==1?tile_aa:scalar_aa));
    assign b_address=selected==3?gelu_ba:(selected==2?copy_ba:(selected==1?tile_ba:scalar_ba));
    assign b_write_data=selected==3?gelu_wd:(selected==2?copy_wd:(selected==1?tile_wd:scalar_wd));
endmodule
