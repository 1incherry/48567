`timescale 1ns/1ps
// PL-only consumer of authenticated object310. No PS descriptor, GO, ACK,
// label or layer index is accepted. KWT arithmetic is intentionally unchanged.
// The actual parent must implement authenticated parameter copy, typed dynamic
// memory and sealed PCM/PE producer; these interfaces are NOT success constants.
module trusted_audio_encoder_sequence_phased #(
 parameter [63:0] TASK_TIMEOUT_CYCLES=64'd1000000000
)(input wire clk,rst_n,cancel,authorized,
 input wire [31:0] model_epoch,runtime_epoch,source_id,clip_id,generation,
 input wire [127:0] key_session_id,
 input wire start_valid,output wire start_ready,input wire sealed_seed_ready,typed_memory_available,
 input wire [287:0] sealed_seed_context,typed_memory_context,
 output wire phase_request,input wire phase_ready,output wire [7:0] phase_request_value,
 output reg [7:0] trusted_phase,output reg phase_begin,phase_end,
 output wire [16:0] read_a_base,read_b_base,read_bias_base,write_base,
 output wire [17:0] read_a_words,read_b_words,read_bias_words,write_words,
 output reg [17:0] read_a_end,read_b_end,read_bias_end,write_end,
 output wire busy,done,quiescent,output reg fault,output reg [7:0] error_code,
 output reg [7:0] command_index,completed_commands,output reg [3:0] block_index,operation_index,
 output wire engine_cancel,input wire engine_quiescent,
 output wire parameter_request,input wire parameter_ready,
 output wire [8:0] parameter_object,output wire [287:0] parameter_context,
 input wire parameter_response_valid,parameter_response_verified,output wire parameter_response_ready,input wire [8:0] parameter_response_object,
 input wire [287:0] parameter_response_context,input wire parameter_quiescent,
 output wire flush_request,input wire flush_ready,flush_done,flush_quiescent,
 output wire static_request_valid,input wire static_request_ready,
 output wire [8:0] static_request_object,output wire [31:0] static_request_word_index,
 input wire static_response_valid,output wire static_response_ready,input wire static_response_error,
 input wire [8:0] static_response_object,input wire [31:0] static_response_word_index,static_response_data,
 input wire [287:0] static_response_context,input wire static_quiescent,
 output wire [20:0] m_awaddr,output wire m_awvalid,input wire m_awready,
 output wire [31:0] m_wdata,output wire [3:0] m_wstrb,output wire m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output wire [20:0] m_araddr,output wire m_arvalid,input wire m_arready,
 input wire [31:0] m_rdata,input wire [1:0] m_rresp,input wire m_rvalid,output wire m_rready
);
localparam IDLE=0,PARAM_REQ=1,PARAM_WAIT=2,FETCH_REQ=3,FETCH_WAIT=4,PREP_WRITE=5,WRITE_BUS=6,
 READ_BUS=7,FLUSH_REQ=8,FLUSH_WAIT=9,NEXT_LAYER=10,FINAL_WAIT=11,DRAIN=12,FINISHED=13,FAILED=14,PHASE_REQ=15;
reg [3:0] state;reg parameter_phase;
reg [287:0] bound_context,last_context;
reg [63:0] elapsed;reg aborted,seen_context;
reg [3:0] field_index;reg [4:0] write_index;
reg [31:0] command[0:15];reg [20:0] bus_address;reg [31:0] bus_data;
reg aw_sent,w_sent,ar_sent;
wire [287:0] current_context={model_epoch,runtime_epoch,source_id,clip_id,generation,key_session_id};
wire active=state!=IDLE&&state!=FINISHED&&state!=FAILED;
wire timed_out=elapsed>=TASK_TIMEOUT_CYCLES;
wire live=authorized&&!cancel&&!aborted&&!timed_out&&current_context==bound_context;
wire fresh=!seen_context||current_context[287:160]!=last_context[287:160]||key_session_id!=last_context[127:0]||generation>last_context[159:128];
wire all_quiet=engine_quiescent&&parameter_quiescent&&flush_quiescent&&static_quiescent;
assign start_ready=(state==IDLE||state==FINISHED||state==FAILED)&&all_quiet&&authorized&&!cancel&&sealed_seed_ready&&typed_memory_available&&sealed_seed_context==current_context&&typed_memory_context==current_context&&generation!=0&&fresh;
assign busy=active;assign quiescent=!active&&all_quiet;
assign done=state==FINISHED&&live&&!fault&&completed_commands==168&&all_quiet;
assign engine_cancel=active&&(!live||fault);
assign parameter_request=state==PARAM_REQ;
assign parameter_response_ready=state==PARAM_WAIT;
assign parameter_object=9'd296+block_index;assign parameter_context=bound_context;
assign flush_request=state==FLUSH_REQ;
assign static_request_valid=state==FETCH_REQ;
assign static_request_object=9'd310;
assign static_request_word_index={20'd0,command_index,4'd0}+field_index;
assign static_response_ready=state==FETCH_WAIT;
assign m_awaddr=bus_address;assign m_wdata=bus_data;assign m_wstrb=4'hf;
assign m_awvalid=state==WRITE_BUS&&!aw_sent;
assign m_wvalid=state==WRITE_BUS&&!w_sent;assign m_bready=state==WRITE_BUS;
assign m_araddr=21'd4;assign m_arvalid=state==READ_BUS&&!ar_sent;assign m_rready=state==READ_BUS;
// Phases0..4 belong to ZERO/CLS/MFCC/PE/POS sealed producer.
// Parameter binding5+15*block, fourteen actual operations6+15*block+op.
// These are PL-owned stage IDs; no external phase/index can enter the core.
assign phase_request=state==PHASE_REQ&&live;
assign phase_request_value=8'd5+({4'd0,block_index}<<4)-{4'd0,block_index}+
 (parameter_phase?8'd0:8'd1+{4'd0,operation_index});
wire [3:0] command_opcode=command[0][3:0];
// Atomically maintain the exact products of accepted descriptor words.
// No count becomes visible before its original command-word acceptance edge.
reg [17:0] matrix_elements,a_matrix_elements,b_matrix_elements;
wire [31:0] prospective_rows=field_index==5?static_response_data:command[5];
wire [31:0] prospective_cols=field_index==6?static_response_data:command[6];
wire [31:0] prospective_inner=field_index==7?static_response_data:command[7];
// Raw (unmasked) interval ends. Count==0 still rejects in the consumer.
// Thus parameter_phase can mask a count to zero without a critical-path adder.
wire [3:0] prospective_opcode=field_index==0?static_response_data[3:0]:command[0][3:0];
wire [16:0] prospective_a_base=field_index==1?static_response_data[16:0]:command[1][16:0];
wire [16:0] prospective_b_base=field_index==2?static_response_data[16:0]:command[2][16:0];
wire [16:0] prospective_write_base=field_index==3?static_response_data[16:0]:command[3][16:0];
wire [16:0] prospective_bias_base=field_index==4?static_response_data[16:0]:command[4][16:0];
wire prospective_bias_flag=field_index==11?static_response_data[0]:command[11][0];
wire [17:0] prospective_matrix=prospective_rows*prospective_cols;
wire [17:0] prospective_a_matrix=prospective_rows*prospective_inner;
wire [17:0] prospective_b_matrix=prospective_cols*prospective_inner;
wire [17:0] prospective_a_words=prospective_opcode==1?prospective_a_matrix:prospective_matrix;
wire [17:0] prospective_b_words=prospective_opcode==1?prospective_b_matrix:prospective_opcode==2?prospective_matrix:prospective_opcode==5?prospective_cols[17:0]:18'd0;
wire [17:0] prospective_bias_words=((prospective_opcode==1&&prospective_bias_flag)||prospective_opcode==5)?prospective_cols[17:0]:18'd0;
assign read_a_base=command[1][16:0];assign read_b_base=command[2][16:0];
assign read_bias_base=command[4][16:0];assign write_base=command[3][16:0];
assign read_a_words=parameter_phase?18'd0:command_opcode==1?a_matrix_elements:matrix_elements;
assign read_b_words=parameter_phase?18'd0:command_opcode==1?b_matrix_elements:command_opcode==2?matrix_elements:command_opcode==5?command[6][17:0]:18'd0;
assign read_bias_words=parameter_phase?18'd0:((command_opcode==1&&command[11][0])||command_opcode==5)?command[6][17:0]:18'd0;
assign write_words=parameter_phase?18'd0:matrix_elements;
// Addresses/counts are canonical 32-bit WORD indices, not physical bytes.
// The parent separately routes static object operands away from dynamic DDR.
wire descriptor_word_allowed;
trusted_audio_descriptor_policy u_policy(.command_index(command_index),.word_index(field_index),.candidate_word(static_response_data),.allowed(descriptor_word_allowed));
task fail(input [7:0] code);begin fault<=1;error_code<=code;aborted<=1;end endtask
integer i;
always @(posedge clk)begin
 if(!rst_n)begin
  state<=IDLE;parameter_phase<=1;trusted_phase<=0;phase_begin<=0;phase_end<=0;bound_context<=0;last_context<=0;elapsed<=0;aborted<=0;seen_context<=0;
  fault<=0;error_code<=0;command_index<=0;completed_commands<=0;block_index<=0;operation_index<=0;
  field_index<=0;write_index<=0;bus_address<=0;bus_data<=0;aw_sent<=0;w_sent<=0;ar_sent<=0;
  for(i=0;i<16;i=i+1)command[i]<=0;
  matrix_elements<=0;a_matrix_elements<=0;b_matrix_elements<=0;
  read_a_end<=0;read_b_end<=0;read_bias_end<=0;write_end<=0;
 end else begin
  phase_begin<=0;phase_end<=0;
  // Completion from a revoked or replaced clip is never resurrected merely
  // by restoring the input context/authorization. Only a new accepted job
  // with a fresh protected generation clears this tombstone.
  if(state==FINISHED&&!live)aborted<=1;
  if(active)begin elapsed<=elapsed+1'b1;if(!live)begin aborted<=1;fault<=1;if(!fault)error_code<=timed_out?8'hf1:8'hf2;end end
  case(state)
   IDLE,FINISHED,FAILED:if(start_valid&&start_ready)begin
    bound_context<=current_context;last_context<=current_context;seen_context<=1;elapsed<=0;aborted<=0;fault<=0;error_code<=0;
    command_index<=0;completed_commands<=0;block_index<=0;operation_index<=0;field_index<=0;write_index<=0;
    aw_sent<=0;w_sent<=0;ar_sent<=0;parameter_phase<=1;trusted_phase<=0;state<=PHASE_REQ;
   end
   PHASE_REQ:if(!live)state<=DRAIN;else if(phase_ready)begin
    trusted_phase<=phase_request_value;phase_begin<=1;
    if(parameter_phase)state<=PARAM_REQ;else begin write_index<=0;state<=PREP_WRITE;end
   end
   PARAM_REQ:if(parameter_ready)state<=PARAM_WAIT;
   PARAM_WAIT:if(parameter_response_valid)begin
    if(!live||!parameter_response_verified||parameter_response_object!=parameter_object||parameter_response_context!=bound_context)begin fail(8'h01);state<=DRAIN;end
    else state<=FLUSH_REQ;
   end
   FETCH_REQ:if(static_request_ready)state<=FETCH_WAIT;
   FETCH_WAIT:if(static_response_valid)begin
    if(!live||static_response_error||static_response_object!=310||static_response_word_index!=static_request_word_index||static_response_context!=bound_context||descriptor_word_allowed!==1'b1)begin fail(8'h02);state<=DRAIN;end
    else begin
     command[field_index]<=static_response_data;
     // Same accepted-word edge as command[], with the identical18-bit sum.
     read_a_end<={1'b0,prospective_a_base}+prospective_a_words;
     read_b_end<={1'b0,prospective_b_base}+prospective_b_words;
     read_bias_end<={1'b0,prospective_bias_base}+prospective_bias_words;
     write_end<={1'b0,prospective_write_base}+prospective_matrix;
     if(field_index==5||field_index==6)matrix_elements<=prospective_rows*prospective_cols;
     if(field_index==5||field_index==7)a_matrix_elements<=prospective_rows*prospective_inner;
     if(field_index==6||field_index==7)b_matrix_elements<=prospective_cols*prospective_inner;
     if(field_index==15)begin write_index<=0;state<=PHASE_REQ;end
     else begin field_index<=field_index+1'b1;state<=FETCH_REQ;end
    end
   end
   PREP_WRITE:if(!live)state<=DRAIN;else begin
    bus_address<=write_index<16?21'h40+{14'd0,write_index,2'd0}:21'd0;
    bus_data<=write_index<16?command[write_index[3:0]]:write_index==16?32'd1:32'd2;
    aw_sent<=0;w_sent<=0;state<=WRITE_BUS;
   end
   WRITE_BUS:begin
    if(m_awvalid&&m_awready)aw_sent<=1;
    if(m_wvalid&&m_wready)w_sent<=1;
    // The accepted partial AW/W/B transaction is never withdrawn on revoke.
    if(m_bvalid)begin
     if(m_bresp!=0)begin fail(8'h03);state<=DRAIN;end
     else if(!live)state<=DRAIN;
     else if(write_index<16)begin write_index<=write_index+1'b1;state<=PREP_WRITE;end
     else if(write_index==16)begin ar_sent<=0;state<=READ_BUS;end
     else begin
      completed_commands<=completed_commands+1'b1;
      state<=FLUSH_REQ;
     end
    end
   end
   READ_BUS:begin
    if(m_arvalid&&m_arready)ar_sent<=1;
    if(m_rvalid)begin
     if(m_rresp!=0||m_rdata[2])begin fail(8'h04);state<=DRAIN;end
     else if(!live)state<=DRAIN;
     else if(m_rdata[1])begin write_index<=17;state<=PREP_WRITE;end
     else begin ar_sent<=0;end
    end
   end
   FLUSH_REQ:if(flush_ready)begin if(flush_done)state<=NEXT_LAYER;else state<=FLUSH_WAIT;end
   FLUSH_WAIT:if(flush_done)state<=NEXT_LAYER;
   NEXT_LAYER:if(!live)state<=DRAIN;else if(all_quiet)begin
    // Actual flush completed and every old request/AXIL response drained.
    phase_end<=1;
    if(parameter_phase)begin parameter_phase<=0;field_index<=0;state<=FETCH_REQ;end
    else if(block_index==11&&operation_index==13)state<=FINAL_WAIT;
    else begin
     command_index<=command_index+1'b1;field_index<=0;
     if(operation_index==13)begin block_index<=block_index+1'b1;operation_index<=0;parameter_phase<=1;state<=PHASE_REQ;end
     else begin operation_index<=operation_index+1'b1;state<=FETCH_REQ;end
    end
   end
   FINAL_WAIT:if(!live)state<=DRAIN;else if(all_quiet)begin
    if(completed_commands!=168)begin fail(8'h05);state<=DRAIN;end else state<=FINISHED;
   end
   DRAIN:if(all_quiet)state<=FAILED;
   default:begin fail(8'hff);state<=DRAIN;end
  endcase
 end
end
endmodule
