`timescale 1ns/1ps
// Private32bit per-dynamic-line version ledger, borrowing A[1024..2047]. There is no RAM,
// CPU port, MAC core, or grant generator in this adapter. The actual final A
// arbiter must hold this lane selected until quiescent, including read->RMW.
module trusted_audio_version_pool #(
 parameter integer A_BASE=1024,LINE_COUNT=8192
)(
 input wire clk,security_reset_n,cancel,pool_granted,
 input wire clear_valid,output wire clear_ready,
 input wire request_valid,output wire request_ready,
 input wire request_write,input wire [12:0] request_line,
 input wire [31:0] request_value,
 output wire response_valid,input wire response_ready,
 output wire response_error,output wire [31:0] response_value,
 output wire quiescent,output reg fault,
 output wire pool_read,output wire [11:0] pool_read_address,
 input wire [255:0] pool_read_data,
 output wire pool_write,output wire [11:0] pool_write_address,
 output wire [255:0] pool_write_data
);
 localparam IDLE=0,READ=1,CAPTURE=2,WRITE=3,CLEAR=4,REPORT=5;
 localparam WORD_COUNT=(LINE_COUNT+7)/8;
 reg [2:0]state;
 reg [12:0]line_index;reg writing,bad;
 reg [31:0]new_value,returned_value;
 reg [255:0]saved_word;
 reg [10:0]clear_word;
 wire admission=security_reset_n&&pool_granted&&!cancel&&!fault;
 assign clear_ready=state==IDLE&&admission;
 assign request_ready=state==IDLE&&admission&&!clear_valid;
 assign response_valid=state==REPORT;
 assign response_error=bad||cancel||!pool_granted||fault;
 assign response_value=response_error?32'd0:returned_value;
 assign quiescent=state==IDLE;
 wire access=security_reset_n&&pool_granted&&!cancel&&!fault;
 assign pool_read=state==READ&&access;
 assign pool_read_address=A_BASE+(line_index>>3);
 assign pool_write=(state==WRITE||state==CLEAR)&&access;
 assign pool_write_address=A_BASE+(state==CLEAR?clear_word:(line_index>>3));
 assign pool_write_data=state==CLEAR?256'd0:saved_word;
 always @(posedge clk or negedge security_reset_n)begin
  if(!security_reset_n)begin
   state<=IDLE;line_index<=0;writing<=0;bad<=0;new_value<=0;
   returned_value<=0;saved_word<=0;clear_word<=0;fault<=0;
  end else begin
   if(state!=IDLE&&(cancel||!pool_granted))begin
    bad<=1;returned_value<=0;
    if(!pool_granted)fault<=1;
   end
   if(state!=IDLE&&state!=REPORT&&(!pool_granted||cancel))begin
    // A transaction is never reinterpreted as a read from the new owner.
    // Cancel is a normal rejected completion. Losing a committed grant is a
    // protocol failure and remains sticky until trusted POR.
    bad<=1;returned_value<=0;state<=REPORT;
   end else case(state)
    IDLE:begin
     bad<=0;returned_value<=0;
     if(clear_valid&&clear_ready)begin clear_word<=0;state<=CLEAR;end
     else if(request_valid&&request_ready)begin
      line_index<=request_line;new_value<=request_value;writing<=request_write;
      if(request_line>=LINE_COUNT)begin bad<=1;state<=REPORT;end
      else state<=READ;
     end
    end
    READ:state<=CAPTURE;
    CAPTURE:begin
     returned_value<=pool_read_data[line_index[2:0]*32+:32];
     saved_word<=pool_read_data;
     if(writing)begin
      saved_word[line_index[2:0]*32+:32]<=new_value;
      state<=WRITE;
     end else state<=REPORT;
    end
    WRITE:state<=REPORT;
    CLEAR:if(clear_word==WORD_COUNT-1)state<=REPORT;else clear_word<=clear_word+1;
    REPORT:if(response_ready)state<=IDLE;
    default:begin fault<=1;bad<=1;state<=REPORT;end
   endcase
  end
 end
 // synthesis translate_off
 initial begin
  if(LINE_COUNT<1||LINE_COUNT>8192||A_BASE<0||A_BASE+WORD_COUNT>2548)
   $fatal(1,"audio version pool exceeds actual A2548");
 end
 // synthesis translate_on
endmodule
