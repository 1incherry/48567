// 4x4 GEMM with double-slot local banks and an independent lookahead loader.
// A 4-row stripe is reused across N tiles; B tiles alternate slots. Loading
// the next tile overlaps current compute/drain except when shared ports are
// needed for output/bias. Partial tiles are zero-filled and masked on drain.
// Arithmetic matches the serial baseline: exact48 accumulation, nearest-even
// rescale, output-scale bias, then signed16/signed24 saturation.
module kwt_tiled_matmul_pool #(parameter ENABLE_B_CACHE=1,PIPELINED_DRAIN=1)(

    input wire fabric_clk,core_step,kernel_owner_live,kernel_cancel,
    output wire kernel_core_ready,kernel_pool_quiescent,kernel_quiescent,kernel_fault,
    output wire kernel_pool_write_valid,input wire kernel_pool_write_ready,
    output wire [11:0] kernel_pool_write_address,output wire [255:0] kernel_pool_write_data,
    output wire kernel_pool_read_request,kernel_pool_read_enable,input wire kernel_pool_read_ready,
    output wire [11:0] kernel_pool_read_address,input wire [255:0] kernel_pool_read_data,
    input wire clk,rst_n,clear,start,
    input wire [16:0] source_a,source_b,destination,bias_base,
    input wire [7:0] rows,
    input wire [8:0] columns,inner,
    input wire signed [7:0] shift_a,
    input wire [5:0] output_bits,
    input wire has_bias,transpose_b,
    output reg busy,done,fault,
    output reg [31:0] cycles,
    output reg a_enable,b_enable,b_write,
    output reg [16:0] a_address,b_address,
    output reg [31:0] b_write_data,
    input wire signed [31:0] a_read_data,b_read_data
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
    localparam WAIT_TILE=0,PREP=1,RUN=2,WAIT_RESULT=3,D_SELECT=4,D_BIAS=5,
               D_CAPTURE=6,D_ROUND=7,D_ADD=8,D_SAT=9,D_WRITE=10,D_NEXT=11,D_PIPE=12,D_FLUSH=13;
    reg [3:0] state;
    reg [7:0] m;
    reg [8:0] n,k;
    reg signed [7:0] shift;
    reg [5:0] bits;
    reg hb,tb,pipelined_drain;
    reg [16:0] sb,bb;
    reg [7:0] cur_row;
    reg [8:0] cur_col;
    reg cur_a_slot,cur_b_slot,cur_last;
    reg [16:0] cur_a_base,cur_b_base,cur_out_base,cur_dest_row;
    reg [8:0] compute_term;
    reg pe_read_valid,pe_first,pe_last;
    reg [767:0] results;
    reg [3:0] drain_index;
    reg [16:0] drain_pointer,bias_pointer;
    reg signed [63:0] rounded,with_bias;
    reg signed [31:0] beta,pending_output;

    reg load_active,load_finished,load_need_a,load_a_slot,load_b_slot;
    reg [7:0] load_row;
    reg [8:0] load_col;
    reg [16:0] load_a_base,load_b_base,load_out_base,load_dest_row;
    reg [1:0] load_a_lane,load_b_lane;
    reg [8:0] load_a_term,load_b_term;
    reg [16:0] load_a_pointer,load_b_pointer;
    reg load_response,load_response_last,response_a_valid,response_b_valid;
    reg [1:0] response_a_lane,response_b_lane;
    reg [7:0] response_a_term,response_b_term;
    reg cache_mode,cache_active,cache_ready,cache_response,cache_response_valid,cache_response_last;
    reg cache_response_dual,cache_response_second_valid;
    reg [6:0] column_groups,cache_group;
    reg [8:0] cache_term;
    reg [1:0] cache_lane,cache_response_lane;
    reg [11:0] cache_load_index,cache_response_index,cache_compute_pointer;
    reg [16:0] cache_pointer,cache_transpose_base;
    wire [9:0] cache_column={1'b0,cache_group,2'b0}+cache_lane;
    wire cache_valid=cache_column<n;
    wire cache_issue=busy&&cache_mode&&cache_active&&!clear;
    // A's first stripe finishes long before a large B kernel. Thereafter
    // use its idle read port for the adjacent column in the same bank group.
    wire cache_dual=cache_issue&&!load_active&&!load_response&&!cache_lane[0];
    wire cache_second_valid=cache_dual&&(cache_column+10'd1)<n;
    wire [16:0] cache_second_pointer=cache_pointer+(tb?{8'd0,k}:17'd1);
    wire cache_group_last=cache_lane==3||(cache_dual&&cache_lane==2);
    wire cache_last=cache_group_last&&cache_group==column_groups-1&&cache_term==k-1;
    wire cache_allowed=ENABLE_B_CACHE&&rows>8&&
        (inner*((columns+9'd3)>>2))<=18'd4096&&
        !(({1'b0,destination}<({1'b0,source_a}+rows*inner))&&
          ({1'b0,source_a}<({1'b0,destination}+rows*columns)))&&
        !(({1'b0,destination}<({1'b0,source_b}+inner*columns))&&
          ({1'b0,source_b}<({1'b0,destination}+rows*columns)));
    wire drain_valid;
    wire pipe_issue=pipelined_drain&&rst_n&&busy&&state==D_PIPE&&!clear;
    wire pipe_write_valid,pipe_end;
    wire [16:0] pipe_address;
    wire signed [31:0] pipe_data;
    wire ports_reserved=state==D_BIAS||(!cache_mode&&state==D_WRITE)||
        (pipe_issue&&hb&&drain_valid)||(!cache_mode&&pipe_write_valid);
    wire load_issue=busy&&load_active&&!ports_reserved&&!clear;
    wire load_a_valid=load_need_a&&({1'b0,load_row}+load_a_lane<m);
    wire load_b_valid=({1'b0,load_col}+load_b_lane<n);
    wire final_load=load_a_lane==3&&load_a_term==k-1;
    wire [95:0] a_flat;
    wire [63:0] b_flat,b_tile_flat,b_cache_flat;
    assign b_flat=cache_mode?b_cache_flat:b_tile_flat;
    wire pe_ready,pe_valid;
    wire [767:0] pe_result;
    wire compute_issue=busy&&state==RUN&&compute_term<k&&pe_ready&&!clear;
    wire pe_clear=clear||start||state==PREP;
    wire more_columns=({1'b0,cur_col}+10'd4)<n;
    wire next_exists=more_columns||({1'b0,cur_row}+9'd4)<m;
    wire [7:0] next_row=more_columns?cur_row:cur_row+8'd4;
    wire [8:0] next_col=more_columns?cur_col+9'd4:9'd0;
    wire [16:0] next_a_base=more_columns?cur_a_base:cur_a_base+{6'd0,k,2'b0};
    wire [16:0] next_b_base=more_columns?(cur_b_base+(tb?{6'd0,k,2'b0}:17'd4)):sb;
    wire [16:0] next_dest_row=more_columns?cur_dest_row:cur_dest_row+{6'd0,n,2'b0};
    wire [16:0] next_out_base=more_columns?cur_out_base+17'd4:next_dest_row;
    assign drain_valid=({1'b0,cur_row}+drain_index[3:2]<m)&&
                     ({1'b0,cur_col}+drain_index[1:0]<n);
    wire signed [47:0] selected_result=results[drain_index*48+:48];
    kwt_matmul_output_pipeline drain_pipe(
        .clk(clk),.rst_n(rst_n),.clear(clear||start||state==PREP),
        .in_issue(pipe_issue),.in_valid(drain_valid),.in_end(drain_index==15),.has_bias(hb),
        .accumulator(selected_result),.shift(shift),.output_bits(bits),.address(drain_pointer),
        .bias_response(a_read_data),.write_valid(pipe_write_valid),.out_end(pipe_end),
        .write_address(pipe_address),.write_data(pipe_data));
    // Diagnostic counters; not a second timer. cycles includes every wait.
    reg [31:0] loaded_words,compute_slices,overlap_cycles,tiles_completed;
    genvar lane;
    generate for(lane=0;lane<4;lane=lane+1) begin: banks
        kwt_tile_bank #(.WIDTH(24)) a_bank(
            .clk(clk),.write_enable(load_response&&load_need_a&&response_a_lane==lane),
            .write_address({load_a_slot,response_a_term}),
            .write_data(response_a_valid?a_read_data[23:0]:24'sd0),
            .read_enable(compute_issue),.read_address({cur_a_slot,compute_term[7:0]}),
            .read_data(a_flat[lane*24+:24]));
        kwt_tile_bank #(.WIDTH(16)) b_bank(
            .clk(clk),.write_enable(load_response&&!cache_mode&&response_b_lane==lane),
            .write_address({load_b_slot,response_b_term}),
            .write_data(response_b_valid?b_read_data[15:0]:16'sd0),
            .read_enable(compute_issue&&!cache_mode),.read_address({cur_b_slot,compute_term[7:0]}),
            .read_data(b_tile_flat[lane*16+:16]));
    end endgenerate

    // Actual former four4096x16 kernel banks reside in shared A0..1023.
    // Fabric adapter keeps its read return across core pauses/ledger access.
    wire kernel_load_committed;
    trusted_audio_kernel_pool_adapter u_kernel_pool(
      .clk(fabric_clk),.rst_n(rst_n),.owner_live(kernel_owner_live),.cancel(kernel_cancel),
      .clear(clear||start),.core_step(core_step),
      .cache_response(cache_response&&ENABLE_B_CACHE),.cache_response_index(cache_response_index),
      .cache_response_lane(cache_response_lane),.cache_response_dual(cache_response_dual),
      .cache_response_valid(cache_response_valid),.cache_response_second_valid(cache_response_second_valid),.cache_response_last(cache_response_last),
      .b_read_data(b_read_data[15:0]),.a_read_data(a_read_data[15:0]),
      .compute_read(compute_issue&&cache_mode&&ENABLE_B_CACHE),.compute_pointer(cache_compute_pointer),
      .read_data(b_cache_flat),.core_ready(kernel_core_ready),.quiescent(kernel_quiescent),.pool_quiescent(kernel_pool_quiescent),
      .load_committed(kernel_load_committed),.fault(kernel_fault),
      .pool_write_valid(kernel_pool_write_valid),.pool_write_ready(kernel_pool_write_ready),.pool_write_address(kernel_pool_write_address),.pool_write_data(kernel_pool_write_data),
      .pool_read_request(kernel_pool_read_request),.pool_read_enable(kernel_pool_read_enable),.pool_read_ready(kernel_pool_read_ready),.pool_read_address(kernel_pool_read_address),.pool_read_data(kernel_pool_read_data));

    kwt_pe4x4 pe(.clk(clk),.rst_n(rst_n),.clear(pe_clear),.in_valid(pe_read_valid),
        .in_first(pe_first),.in_last(pe_last),.a_flat(a_flat),.b_flat(b_flat),
        .in_ready(pe_ready),.out_valid(pe_valid),.out_ready(state==WAIT_RESULT),.result_flat(pe_result));
    always @* begin
        a_enable=0;b_enable=0;b_write=0;a_address=0;b_address=0;b_write_data=pending_output;
        if(load_issue) begin
            a_enable=load_a_valid;a_address=load_a_pointer;
            b_enable=!cache_mode&&load_b_valid;b_address=load_b_pointer;
        end
        if(cache_issue)begin
            b_enable=cache_valid;b_address=cache_pointer;
            if(cache_dual)begin a_enable=cache_second_valid;a_address=cache_second_pointer;end
        end
        if(busy&&!clear&&state==D_BIAS) begin a_enable=1;a_address=bias_pointer;end
        if(busy&&!clear&&state==D_WRITE) begin
            b_enable=1;b_write=1;b_address=drain_pointer;
        end
        if(pipe_issue&&drain_valid&&hb)begin a_enable=1;a_address=bias_pointer;end
        if(busy&&!clear&&pipelined_drain&&pipe_write_valid)begin
            b_enable=1;b_write=1;b_address=pipe_address;b_write_data=pipe_data;
        end
    end
    always @(posedge clk) begin
        if(!rst_n||clear) begin
            busy<=0;done<=0;fault<=0;cycles<=0;state<=WAIT_TILE;
            m<=0;n<=0;k<=0;shift<=0;bits<=0;hb<=0;tb<=0;pipelined_drain<=0;sb<=0;bb<=0;
            cur_row<=0;cur_col<=0;cur_a_slot<=0;cur_b_slot<=0;cur_last<=0;
            cur_a_base<=0;cur_b_base<=0;cur_out_base<=0;cur_dest_row<=0;
            compute_term<=0;pe_read_valid<=0;pe_first<=0;pe_last<=0;results<=0;
            drain_index<=0;drain_pointer<=0;bias_pointer<=0;rounded<=0;with_bias<=0;beta<=0;pending_output<=0;
            load_active<=0;load_finished<=0;load_need_a<=0;load_a_slot<=0;load_b_slot<=0;
            load_row<=0;load_col<=0;load_a_base<=0;load_b_base<=0;load_out_base<=0;load_dest_row<=0;
            load_a_lane<=0;load_b_lane<=0;load_a_term<=0;load_b_term<=0;load_a_pointer<=0;load_b_pointer<=0;
            load_response<=0;load_response_last<=0;response_a_valid<=0;response_b_valid<=0;
            response_a_lane<=0;response_b_lane<=0;response_a_term<=0;response_b_term<=0;
            cache_mode<=0;cache_active<=0;cache_ready<=0;cache_response<=0;
            cache_response_valid<=0;cache_response_last<=0;cache_response_lane<=0;
            cache_response_dual<=0;cache_response_second_valid<=0;
            column_groups<=0;cache_group<=0;cache_term<=0;cache_lane<=0;
            cache_load_index<=0;cache_response_index<=0;cache_compute_pointer<=0;
            cache_pointer<=0;cache_transpose_base<=0;
            loaded_words<=0;compute_slices<=0;overlap_cycles<=0;tiles_completed<=0;
        end else begin
            pe_read_valid<=compute_issue;
            pe_first<=compute_term==0;pe_last<=compute_term==k-1;
            load_response<=load_issue;
            cache_response<=cache_issue;
            if(start&&!busy) begin
                // Preserve legacy timing for aliasing generic commands.
                // All official encoder matrices have disjoint destinations.
                pipelined_drain<=PIPELINED_DRAIN&&
                    !(({1'b0,destination}<({1'b0,source_a}+rows*inner))&&({1'b0,source_a}<({1'b0,destination}+rows*columns)))&&
                    !(({1'b0,destination}<({1'b0,source_b}+inner*columns))&&({1'b0,source_b}<({1'b0,destination}+rows*columns)))&&
                    !(has_bias&&({1'b0,destination}<({1'b0,bias_base}+columns))&&({1'b0,bias_base}<({1'b0,destination}+rows*columns)));
                m<=rows;n<=columns;k<=inner;shift<=shift_a;bits<=output_bits;hb<=has_bias;tb<=transpose_b;
                sb<=source_b;bb<=bias_base;busy<=1;done<=0;fault<=0;cycles<=0;state<=WAIT_TILE;
                load_active<=1;load_finished<=0;load_need_a<=1;load_a_slot<=0;load_b_slot<=0;
                load_row<=0;load_col<=0;load_a_base<=source_a;load_b_base<=source_b;
                load_out_base<=destination;load_dest_row<=destination;
                load_a_lane<=0;load_b_lane<=0;load_a_term<=0;load_b_term<=0;
                load_a_pointer<=source_a;load_b_pointer<=source_b;load_response<=0;
                compute_term<=0;pe_read_valid<=0;
                cache_mode<=cache_allowed;cache_active<=cache_allowed;cache_ready<=!cache_allowed;cache_response<=0;
                column_groups<=(columns+9'd3)>>2;cache_group<=0;cache_term<=0;cache_lane<=0;
                cache_load_index<=0;cache_compute_pointer<=0;cache_pointer<=source_b;cache_transpose_base<=source_b;
                loaded_words<=0;compute_slices<=0;overlap_cycles<=0;tiles_completed<=0;
                if(rows==0||columns==0||columns>256||inner==0||inner>256||
                   (output_bits!=16&&output_bits!=24)||shift_a < -40||shift_a>60||
                   ({1'b0,source_a}+rows*inner)>131072||
                   ({1'b0,source_b}+inner*columns)>131072||
                   ({1'b0,destination}+rows*columns)>131072||
                   (has_bias&&({1'b0,bias_base}+columns)>131072)) begin
                    busy<=0;done<=1;fault<=1;load_active<=0;cache_active<=0;
                end
            end else if(busy) begin
                cycles<=cycles+1;
                if(compute_issue) begin compute_term<=compute_term+1;compute_slices<=compute_slices+1;end
                if(load_issue&&compute_issue) overlap_cycles<=overlap_cycles+1;
                if(load_issue||cache_issue)loaded_words<=loaded_words+
                    (load_issue&&load_a_valid?32'd1:32'd0)+
                    (load_issue&&!cache_mode&&load_b_valid?32'd1:32'd0)+
                    (cache_issue&&cache_valid?32'd1:32'd0)+
                    (cache_second_valid?32'd1:32'd0);
                if(cache_issue)begin
                    cache_response_valid<=cache_valid;cache_response_last<=cache_last;
                    cache_response_dual<=cache_dual;cache_response_second_valid<=cache_second_valid;
                    cache_response_lane<=cache_lane;cache_response_index<=cache_load_index;
                    cache_lane<=cache_lane+(cache_dual?2'd2:2'd1);
                    if(cache_group_last)begin
                        cache_load_index<=cache_load_index+1;
                        if(cache_group==column_groups-1)begin cache_group<=0;cache_term<=cache_term+1;end
                        else cache_group<=cache_group+1;
                    end
                    if(tb)begin
                        if(cache_group_last&&cache_group==column_groups-1)begin
                            cache_transpose_base<=cache_transpose_base+1;cache_pointer<=cache_transpose_base+1;
                        end else cache_pointer<=cache_pointer+(cache_dual?{7'd0,k,1'b0}:{8'd0,k});
                    end else cache_pointer<=cache_pointer+(cache_valid?17'd1:17'd0)+(cache_second_valid?17'd1:17'd0);
                    if(cache_last)cache_active<=0;
                end
                if(cache_response&&cache_response_last)cache_ready<=1;
                if(compute_issue&&cache_mode)cache_compute_pointer<=cache_compute_pointer+column_groups;
                if(load_issue) begin
                    response_a_valid<=load_a_valid;response_b_valid<=load_b_valid;
                    response_a_lane<=load_a_lane;response_b_lane<=load_b_lane;
                    response_a_term<=load_a_term[7:0];response_b_term<=load_b_term[7:0];
                    load_response_last<=final_load;
                    load_a_pointer<=load_a_pointer+1;
                    if(load_a_term==k-1) begin load_a_term<=0;load_a_lane<=load_a_lane+1;end
                    else load_a_term<=load_a_term+1;
                    if(tb) begin
                        load_b_pointer<=load_b_pointer+1;
                        if(load_b_term==k-1) begin load_b_term<=0;load_b_lane<=load_b_lane+1;end
                        else load_b_term<=load_b_term+1;
                    end else begin
                        load_b_pointer<=load_b_pointer+(load_b_lane==3?({8'd0,n}-17'd3):17'd1);
                        if(load_b_lane==3) begin load_b_lane<=0;load_b_term<=load_b_term+1;end
                        else load_b_lane<=load_b_lane+1;
                    end
                    if(final_load) load_active<=0;
                end
                if(load_response&&load_response_last) load_finished<=1;
                case(state)
                    WAIT_TILE:if(load_finished&&cache_ready) begin
                        cur_row<=load_row;cur_col<=load_col;cur_a_slot<=load_a_slot;cur_b_slot<=load_b_slot;
                        cur_a_base<=load_a_base;cur_b_base<=load_b_base;
                        cur_out_base<=load_out_base;cur_dest_row<=load_dest_row;
                        cur_last<=({1'b0,load_col}+10'd4>=n)&&({1'b0,load_row}+9'd4>=m);
                        load_finished<=0;state<=PREP;
                    end
                    PREP:begin
                        compute_term<=0;drain_index<=0;drain_pointer<=cur_out_base;bias_pointer<=bb+cur_col;
                        state<=RUN;
                        cache_compute_pointer<=cur_col>>2;
                        if(cache_mode&&cur_col==0&&({1'b0,cur_row}+9'd4)<m)begin
                            // Load the next four A rows while all N tiles
                            // reuse the current A stripe and complete B cache.
                            load_active<=1;load_finished<=0;load_need_a<=1;
                            load_a_slot<=!cur_a_slot;load_row<=cur_row+8'd4;load_col<=0;
                            load_a_base<=cur_a_base+{6'd0,k,2'b0};load_b_base<=sb;
                            load_dest_row<=cur_dest_row+{6'd0,n,2'b0};load_out_base<=cur_dest_row+{6'd0,n,2'b0};
                            load_a_lane<=0;load_a_term<=0;load_a_pointer<=cur_a_base+{6'd0,k,2'b0};
                        end else if(!cache_mode&&next_exists) begin
                            load_active<=1;load_need_a<=!more_columns;
                            load_a_slot<=more_columns?cur_a_slot:!cur_a_slot;load_b_slot<=!cur_b_slot;
                            load_row<=next_row;load_col<=next_col;load_a_base<=next_a_base;load_b_base<=next_b_base;
                            load_out_base<=next_out_base;load_dest_row<=next_dest_row;
                            load_a_lane<=0;load_b_lane<=0;load_a_term<=0;load_b_term<=0;
                            load_a_pointer<=next_a_base;load_b_pointer<=next_b_base;
                        end
                    end
                    RUN:if(compute_issue&&compute_term==k-1) state<=WAIT_RESULT;
                    WAIT_RESULT:if(pe_valid) begin results<=pe_result;state<=pipelined_drain?D_PIPE:D_SELECT;end
                    D_PIPE:begin
                        if(drain_index==15)state<=D_FLUSH;
                        else begin
                            drain_index<=drain_index+1;
                            drain_pointer<=drain_pointer+(drain_index[1:0]==3?({8'd0,n}-17'd3):17'd1);
                            bias_pointer<=drain_index[1:0]==3?bb+cur_col:bias_pointer+1;
                        end
                    end
                    D_FLUSH:if(pipe_end)begin
                        tiles_completed<=tiles_completed+1;
                        if(cur_last)begin busy<=0;done<=1;state<=WAIT_TILE;end
                        else if(cache_mode&&more_columns)begin
                            cur_col<=next_col;cur_out_base<=next_out_base;
                            cur_last<=({1'b0,next_col}+10'd4>=n)&&({1'b0,cur_row}+9'd4>=m);
                            state<=PREP;
                        end else state<=WAIT_TILE;
                    end
                    D_SELECT:begin
                        if(!drain_valid) state<=D_NEXT;
                        else if(hb) state<=D_BIAS;
                        else begin beta<=0;state<=D_ROUND;end
                    end
                    D_BIAS:state<=D_CAPTURE;
                    D_CAPTURE:begin beta<=a_read_data;state<=D_ROUND;end
                    D_ROUND:begin rounded<=kwt_round64({{16{selected_result[47]}},selected_result},shift);state<=D_ADD;end
                    D_ADD:begin with_bias<=rounded+{{32{beta[31]}},beta};state<=D_SAT;end
                    D_SAT:begin pending_output<=kwt_sat32(with_bias,bits);state<=D_WRITE;end
                    D_WRITE:state<=D_NEXT;
                    D_NEXT:begin
                        if(drain_index==15) begin
                            tiles_completed<=tiles_completed+1;
                            if(cur_last) begin busy<=0;done<=1;state<=WAIT_TILE;end
                            else if(cache_mode&&more_columns)begin
                                cur_col<=next_col;cur_out_base<=next_out_base;
                                cur_last<=({1'b0,next_col}+10'd4>=n)&&({1'b0,cur_row}+9'd4>=m);
                                state<=PREP;
                            end else state<=WAIT_TILE;
                        end else begin
                            drain_index<=drain_index+1;
                            drain_pointer<=drain_pointer+(drain_index[1:0]==3?({8'd0,n}-17'd3):17'd1);
                            bias_pointer<=drain_index[1:0]==3?bb+cur_col:bias_pointer+1;
                            state<=D_SELECT;
                        end
                    end
                    default:begin busy<=0;done<=1;fault<=1;state<=WAIT_TILE;end
                endcase
            end
        end
    end
endmodule
