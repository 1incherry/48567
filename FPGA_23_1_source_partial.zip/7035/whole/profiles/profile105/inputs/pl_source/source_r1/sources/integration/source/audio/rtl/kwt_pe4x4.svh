// Output-stationary 4x4 outer-product array. Sixteen independent 24x16 MACs
// consume one K slice per cycle. A rows and B columns broadcast to four PEs.
module kwt_pe4x4(
    input wire clk,rst_n,clear,in_valid,in_first,in_last,out_ready,
    input wire [95:0] a_flat,
    input wire [63:0] b_flat,
    output wire in_ready,out_valid,
    output wire [767:0] result_flat
);
    wire [15:0] ready,valid;
    assign in_ready=&ready;
    assign out_valid=&valid;
    genvar r,c;
    generate for(r=0;r<4;r=r+1) begin: rows
        for(c=0;c<4;c=c+1) begin: columns
            kwt_dot_product #(.DATA_A_W(24),.DATA_B_W(16),.ACC_W(48)) mac(
                .clk(clk),.rst_n(rst_n),.clear(clear),.in_valid(in_valid),
                .in_ready(ready[r*4+c]),.in_first(in_first),.in_last(in_last),
                .in_a(a_flat[r*24+:24]),.in_b(b_flat[c*16+:16]),
                .out_valid(valid[r*4+c]),.out_ready(out_ready),
                .out_data(result_flat[(r*4+c)*48+:48]));
        end
    end endgenerate
endmodule
