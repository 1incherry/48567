`timescale 1ns/1ps
// Two synchronous word ports retain the original KWT RAM contract. The client
// advances only on step. A complete cache transaction runs on the ungated clock.
// Fully associative lines prevent two simultaneously required addresses from
// evicting each other. Dirty lines are never discarded without AXI B completion.
module audio_ddr_cache #(parameter LINES=4,parameter [31:0] BASE=32'h34000000,parameter PIPELINED_COMMIT=0)(
 input wire clk,rst_n,client_active,flush,invalidate,
 input wire commit,
 output wire clean,output wire step,output reg flush_done,output reg fault,
 input wire a_en,a_we,b_en,b_we,
 input wire [16:0] a_addr,b_addr,
 input wire [31:0] a_data,b_data,input wire [3:0] a_strobe,
 output reg [31:0] a_q,b_q,
 output reg [31:0] araddr,output wire [7:0] arlen,output wire [2:0] arsize,
 output wire [1:0] arburst,output wire arvalid,input wire arready,
 input wire [255:0] rdata,input wire [1:0] rresp,input wire rlast,rvalid,output wire rready,
 output reg [31:0] awaddr,output wire [7:0] awlen,output wire [2:0] awsize,
 output wire [1:0] awburst,output wire awvalid,input wire awready,
 output reg [255:0] wdata,output wire [31:0] wstrb,output wire wlast,wvalid,input wire wready,
 input wire [1:0] bresp,input wire bvalid,output wire bready,
 output reg [31:0] misses,writebacks,stalls,output wire idle
);
 localparam IDLE=0,WB=1,WB_RESP=2,REFILL_ADDR=3,REFILL_DATA=4,FLUSH_SCAN=5;
 reg [2:0] state;
 reg [LINES-1:0] valid,dirty;
 reg [13:0] tags[0:LINES-1];
 wire [255:0] data[0:LINES-1];
 integer ai,bi,victim,replace_ptr,flush_index,selected;
 wire commit_step=PIPELINED_COMMIT?commit:step;
 genvar li,wi,bi_byte;
 generate for(li=0;li<LINES;li=li+1)begin:cache_lines
  for(wi=0;wi<8;wi=wi+1)begin:cache_words
   for(bi_byte=0;bi_byte<4;bi_byte=bi_byte+1)begin:cache_bytes
    reg [7:0] storage;
    assign data[li][wi*32+bi_byte*8+:8]=storage;
    always @(posedge clk)begin
     if(rst_n&&state==REFILL_DATA&&rvalid&&rresp==0&&rlast&&selected==li)
      storage<=rdata[wi*32+bi_byte*8+:8];
     else if(commit_step&&b_en&&b_we&&bi==li&&b_addr[2:0]==wi)
      storage<=b_data[bi_byte*8+:8];
     else if(commit_step&&a_en&&a_we&&ai==li&&a_addr[2:0]==wi&&a_strobe[bi_byte])
      storage<=a_data[bi_byte*8+:8];
    end
   end
  end
 end endgenerate
 reg ah,bh,found,doing_flush,do_invalidate,aw_sent,w_sent;
 reg [13:0] pending_tag;
 integer i,j;
 always @* begin
  ai=0;bi=0;ah=!a_en;bh=!b_en;
  for(integer k=0;k<LINES;k=k+1)begin
   if(valid[k]&&tags[k]==a_addr[16:3])begin ai=k;ah=1;end
   if(valid[k]&&tags[k]==b_addr[16:3])begin bi=k;bh=1;end
  end
  victim=replace_ptr;found=0;
  for(integer k=0;k<LINES;k=k+1)begin
   if(!found&&!valid[k])begin victim=k;found=1;end
  end
  for(integer k=0;k<LINES;k=k+1)begin
   if(!found&&(!a_en||tags[(replace_ptr+k)%LINES]!=a_addr[16:3])&&(!b_en||tags[(replace_ptr+k)%LINES]!=b_addr[16:3]))begin
    victim=(replace_ptr+k)%LINES;found=1;
   end
  end
 end
 assign clean=dirty==0;
 assign idle=state==IDLE;
 assign step=rst_n&&client_active&&state==IDLE&&!flush&&!invalidate&&!fault&&ah&&bh;
 assign arlen=0;assign arsize=5;assign arburst=1;assign arvalid=state==REFILL_ADDR;
 assign awlen=0;assign awsize=5;assign awburst=1;assign awvalid=state==WB&&!aw_sent;
 assign wstrb=32'hffffffff;assign wlast=1;assign wvalid=state==WB&&!w_sent;
 assign rready=state==REFILL_DATA;assign bready=state==WB_RESP;
 always @(posedge clk)begin
  if(!rst_n)begin
   state<=IDLE;valid<=0;dirty<=0;fault<=0;flush_done<=0;
   misses<=0;writebacks<=0;stalls<=0;replace_ptr<=0;flush_index<=0;selected<=0;
   doing_flush<=0;do_invalidate<=0;aw_sent<=0;w_sent<=0;pending_tag<=0;
   araddr<=0;awaddr<=0;wdata<=0;a_q<=0;b_q<=0;
  end else begin
   flush_done<=0;
   if(client_active&&!step)stalls<=stalls+1;
   case(state)
    IDLE:if(!fault)begin
     if(flush||invalidate)begin
      doing_flush<=1;do_invalidate<=invalidate;flush_index<=0;state<=FLUSH_SCAN;
     end else if(client_active&&(!ah||!bh))begin
      selected<=victim;pending_tag<=!ah?a_addr[16:3]:b_addr[16:3];
      misses<=misses+1;replace_ptr<=(victim+1)%LINES;doing_flush<=0;
      if(valid[victim]&&dirty[victim])begin
       awaddr<=BASE+{tags[victim],5'b0};wdata<=data[victim];
       aw_sent<=0;w_sent<=0;state<=WB;
      end else begin
       araddr<=BASE+{(!ah?a_addr[16:3]:b_addr[16:3]),5'b0};state<=REFILL_ADDR;
      end
     end else if(commit_step)begin
      if(a_en)a_q<=data[ai][a_addr[2:0]*32+:32];
      if(b_en)b_q<=data[bi][b_addr[2:0]*32+:32];
      if(a_en&&a_we)begin
       dirty[ai]<=1;
      end
      if(b_en&&b_we)dirty[bi]<=1;
     end
    end
    WB:begin
     if(awvalid&&awready)aw_sent<=1;
     if(wvalid&&wready)w_sent<=1;
     if((aw_sent||awready)&&(w_sent||wready))state<=WB_RESP;
    end
    WB_RESP:if(bvalid)begin
     if(bresp!=0)begin fault<=1;state<=IDLE;end
     else begin
      dirty[selected]<=0;writebacks<=writebacks+1;
      if(doing_flush)begin flush_index<=flush_index+1;state<=FLUSH_SCAN;end
      else begin araddr<=BASE+{pending_tag,5'b0};state<=REFILL_ADDR;end
     end
    end
    REFILL_ADDR:if(arready)state<=REFILL_DATA;
    REFILL_DATA:if(rvalid)begin
     if(rresp!=0||!rlast)begin fault<=1;state<=IDLE;end
     else begin tags[selected]<=pending_tag;valid[selected]<=1;dirty[selected]<=0;state<=IDLE;end
    end
    FLUSH_SCAN:begin
     if(flush_index==LINES)begin
      if(do_invalidate)valid<=0;
      state<=IDLE;doing_flush<=0;flush_done<=1;
     end else if(valid[flush_index]&&dirty[flush_index])begin
      selected<=flush_index;awaddr<=BASE+{tags[flush_index],5'b0};wdata<=data[flush_index];
      aw_sent<=0;w_sent<=0;state<=WB;
     end else flush_index<=flush_index+1;
    end
    default:begin fault<=1;state<=IDLE;end
   endcase
  end
 end
endmodule
