`timescale 1ns/1ps
// Independent modality-specific candidate. Never reinterpret visual105 records
// as audio, nor admit PS-provided labels. Full logits stay local to this bank.
module trusted_audio_result_bank_stream #(
 parameter integer CLASSES=105,
 parameter integer CLASS_BITS=(CLASSES<2?1:$clog2(CLASSES))
)(
 input wire clk,security_reset_n,authorized,key_valid,cancel,trusted_clear_fault,
 input wire [31:0] model_epoch,runtime_epoch,source_id,clip_id,generation,
 input wire [127:0] key_session_id,
 input wire clip_start,output wire clip_ready,input wire pipeline_quiescent,
 input wire sealed_seed_valid,input wire [287:0] sealed_seed_context,
 input wire encoder_start_accepted,encoder_complete,input wire [287:0] encoder_context,
 input wire logit_valid,output wire logit_ready,
 input wire [CLASS_BITS-1:0] logit_index,input wire [31:0] logit_data,
 input wire logit_last,input wire [287:0] logit_context,
 input wire commit_valid,output wire commit_ready,input wire [287:0] commit_context,
 input wire [CLASS_BITS-1:0] commit_class,input wire [31:0] commit_score,
 output reg commit_pulse,output reg fault,output wire visible,
 output wire [287:0] result_context,output wire [CLASS_BITS-1:0] result_class,
 output wire [31:0] result_score,
 // Internal PL verification/readout only; no new PS MMIO authority.
 input wire debug_read,input wire [CLASS_BITS-1:0] debug_index,
 output wire debug_valid,output wire [31:0] debug_data
);
 wire [287:0] live_context={model_epoch,runtime_epoch,source_id,clip_id,generation,key_session_id};
 wire trusted_now=authorized&&key_valid&&!cancel&&model_epoch!=0&&runtime_epoch!=0&&key_session_id!=0;
 reg [287:0] admitted_context,stored_context;
 reg admitted,encoder_started,encoder_armed,encoder_seen,consumed,present;
 reg [31:0] last_epoch,last_generation;reg [127:0] last_key;
 reg [CLASS_BITS-1:0] stored_class,next_logit,stream_winner;
 reg [31:0] stored_score,stream_best;
 reg stream_complete,finite_all;
 (* ram_style="block" *) reg [31:0] logit_memory[0:CLASSES-1];
 reg debug_pending;reg [31:0] debug_q;reg [287:0] debug_context;
 wire fresh=runtime_epoch!=last_epoch||key_session_id!=last_key||generation>last_generation;
 wire current=trusted_now&&admitted&&live_context==admitted_context;
 wire seed_current=sealed_seed_valid&&sealed_seed_context==admitted_context;
 wire stream_window=current&&seed_current&&encoder_seen&&!consumed&&!fault&&!stream_complete;
 wire stream_item_ok=stream_window&&logit_context==admitted_context&&
  logit_index==next_logit&&logit_index<CLASSES&&logit_last==(next_logit==CLASSES-1)&&logit_data[30:23]!=8'hff;
 assign logit_ready=stream_window;
 assign clip_ready=trusted_now&&!fault&&(!admitted||consumed)&&pipeline_quiescent&&fresh&&clip_id!=0&&generation!=0;
 wire payload_ok=current&&seed_current&&encoder_seen&&!consumed&&!fault&&stream_complete&&finite_all&&!logit_valid&&
  commit_context==admitted_context&&commit_class<CLASSES&&commit_score[30:23]!=8'hff&&
  commit_class==stream_winner&&commit_score==stream_best;
 assign commit_ready=payload_ok&&pipeline_quiescent;
 assign visible=security_reset_n&&present&&!fault&&trusted_now&&live_context==stored_context;
 assign result_context=visible?stored_context:288'd0;
 assign result_class=visible?stored_class:{CLASS_BITS{1'b0}};
 assign result_score=visible?stored_score:32'd0;
 // Registered read and both request+response context gating prevent old RAM
 // contents escaping after revoke/epoch/model/clip changes. RAM is not reset.
 assign debug_valid=debug_pending&&visible&&debug_context==stored_context;
 assign debug_data=debug_valid?debug_q:32'd0;
 function automatic greater(input [31:0] a,input [31:0] b);
  begin
   if(a[30:0]==0&&b[30:0]==0)greater=0;
   else if(a[31]!=b[31])greater=!a[31];
   else greater=a[31]?a[30:0]<b[30:0]:a[30:0]>b[30:0];
  end
 endfunction
 // Single write port for successful ordered items; no class-count-wide route.
 always @(posedge clk)begin
  if(security_reset_n&&logit_valid&&trusted_now&&!clip_start&&stream_item_ok)
   logit_memory[logit_index]<=logit_data;
  if(debug_read&&visible&&debug_index<CLASSES)debug_q<=logit_memory[debug_index];
 end
 always @(posedge clk)begin
  if(!security_reset_n)begin
   admitted_context<=0;stored_context<=0;admitted<=0;encoder_started<=0;encoder_armed<=0;encoder_seen<=0;consumed<=0;present<=0;
   last_epoch<=0;last_generation<=0;last_key<=0;stored_class<=0;stored_score<=0;commit_pulse<=0;fault<=0;
   next_logit<=0;stream_winner<=0;stream_best<=0;stream_complete<=0;finite_all<=1;
   debug_pending<=0;debug_context<=0;
  end else begin
   commit_pulse<=0;
   debug_pending<=debug_read&&visible&&debug_index<CLASSES;
   if(debug_read&&visible&&debug_index<CLASSES)debug_context<=stored_context;
   if(trusted_clear_fault&&pipeline_quiescent&&!admitted)fault<=0;
   if(!trusted_now||admitted&&live_context!=admitted_context)begin
    admitted<=0;encoder_started<=0;encoder_armed<=0;encoder_seen<=0;consumed<=0;present<=0;
    stream_complete<=0;finite_all<=1;next_logit<=0;debug_pending<=0;
   end
   if(clip_start)begin
    present<=0;debug_pending<=0;
    if(!clip_ready)fault<=1;
    else begin
     admitted<=1;admitted_context<=live_context;encoder_started<=0;encoder_armed<=0;encoder_seen<=0;consumed<=0;
     last_epoch<=runtime_epoch;last_key<=key_session_id;last_generation<=generation;
     next_logit<=0;stream_complete<=0;finite_all<=1;stream_winner<=0;stream_best<=0;
    end
   end
   if(encoder_start_accepted&&trusted_now&&!clip_start)begin
    if(!current||!seed_current||encoder_started||consumed)fault<=1;
    else begin encoder_started<=1;encoder_armed<=!encoder_complete;end
   end
   if(encoder_started&&!encoder_complete)encoder_armed<=1;
   // Preserve actual accepted-start -> lowDONE -> highDONE one-clip evidence.
   if(encoder_started&&encoder_armed&&encoder_complete&&!encoder_seen&&trusted_now&&!clip_start)begin
    if(!current||!seed_current||encoder_context!=admitted_context||consumed)fault<=1;
    else encoder_seen<=1;
   end
   if(logit_valid&&trusted_now&&!clip_start)begin
    if(!stream_item_ok)begin fault<=1;finite_all<=0;present<=0;end
    else if(logit_ready)begin
     if(next_logit==0||greater(logit_data,stream_best))begin stream_winner<=logit_index;stream_best<=logit_data;end
     if(logit_last)stream_complete<=1;else next_logit<=next_logit+1'b1;
    end
   end
   if(commit_valid&&trusted_now&&!clip_start)begin
    if(!payload_ok)fault<=1;
    else if(commit_ready)begin
     consumed<=1;present<=1;commit_pulse<=1;stored_context<=admitted_context;
     stored_class<=commit_class;stored_score<=commit_score;
    end
   end
  end
 end
 // synthesis translate_off
 initial begin
  if(CLASSES<1||CLASSES>128||CLASS_BITS<1||CLASS_BITS>7||2**CLASS_BITS<CLASSES)
   $fatal(1,"unsupported audio class parameter");
 end
 // synthesis translate_on
endmodule
