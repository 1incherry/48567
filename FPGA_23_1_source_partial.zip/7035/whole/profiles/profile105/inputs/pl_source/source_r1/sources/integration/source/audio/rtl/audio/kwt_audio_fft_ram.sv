`timescale 1ns/1ps
// The common BRAM wrapper supplies kwt_sram_banked in SRAM configurations.
// Two banks together store 8KiB. A 16x1024 macro mapping allocates 16KiB,
// instead of wasting 64KiB in 16x4096 macros for this small scratchpad.
module kwt_audio_fft_ram(
    input wire clk,a_en,a_we,b_en,b_we,
    input wire [8:0] a_addr,b_addr,
    input wire [63:0] a_data,b_data,
    input wire [7:0] a_strobe,
    output wire [63:0] a_q,b_q
);
`ifdef KWT_USE_SRAM_BANKS
    kwt_sram_banked #(.WIDTH(64),.DEPTH(512),.MACRO_DEPTH(1024),.ADDR_W(9)) memory(.*);
`else
    kwt_bram #(.WIDTH(64),.DEPTH(512),.ADDR_W(9)) memory(.*);
`endif
endmodule
