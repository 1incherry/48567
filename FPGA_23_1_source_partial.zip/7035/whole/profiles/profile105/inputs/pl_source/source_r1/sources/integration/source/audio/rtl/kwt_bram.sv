`timescale 1ns/1ps
`ifdef KWT_USE_SRAM_BANKS
`include "source_r1/sources/integration/source/audio/rtl/kwt_sram_banked.svh"
`endif
// Same-clock simple true dual-port RAM. No reset of storage: infer block RAM.
// The wrapper prevents writes to live input/weight banks and reads of live output.
module kwt_bram #(
    parameter integer WIDTH=16, DEPTH=256,
    parameter integer ADDR_W=$clog2(DEPTH)
) (
    input wire clk,
    input wire a_en,a_we,
    input wire [ADDR_W-1:0] a_addr,
    input wire [WIDTH-1:0] a_data,
    input wire [(WIDTH+7)/8-1:0] a_strobe,
    output wire [WIDTH-1:0] a_q,
    input wire b_en,b_we,
    input wire [ADDR_W-1:0] b_addr,
    input wire [WIDTH-1:0] b_data,
    output wire [WIDTH-1:0] b_q
);
`ifdef KWT_USE_SRAM_BANKS
    kwt_sram_banked #(.WIDTH(WIDTH),.DEPTH(DEPTH),.MACRO_DEPTH(4096),.ADDR_W(ADDR_W)) macro_ram(
        .clk(clk),.a_en(a_en),.a_we(a_we),.a_addr(a_addr),.a_data(a_data),.a_strobe(a_strobe),.a_q(a_q),
        .b_en(b_en),.b_we(b_we),.b_addr(b_addr),.b_data(b_data),.b_q(b_q));
`else
    (* ram_style="block" *) reg [WIDTH-1:0] memory[0:DEPTH-1];
    reg [WIDTH-1:0] aq,bq;
    assign a_q=aq;assign b_q=bq;
    integer lane;
    always @(posedge clk) if(a_en) begin
        for(lane=0;lane<(WIDTH+7)/8;lane=lane+1)
            if(a_we&&a_strobe[lane]) memory[a_addr][lane*8+:8]<=a_data[lane*8+:8];
        aq<=memory[a_addr];
    end
    always @(posedge clk) if(b_en) begin
        if(b_we) memory[b_addr]<=b_data;
        bq<=memory[b_addr];
    end
`endif
endmodule
