`timescale 1ns/1ps
//16000 mono PCM16 samples ->98 overlapped frames ->98x40 MFCC Q14.
// A640-sample ring holds480 live window samples plus160 prefetch samples.
// Prefetch writes are disjoint from the live480-sample window. Input can
// stall while a frame computes; frame timing never assumes a fixed rate.
module kwt_audio_mfcc_profile #(
    parameter integer CLIP_SAMPLES=32000,
    parameter integer HOP_SAMPLES=320,
    parameter HANN_FILE="model/audio_hann_q30.hex",
    parameter TWIDDLE_FILE="model/audio_twiddle_q30.hex",
    parameter MEL_FILE="model/audio_mel_sparse_q30.hex",
    parameter MEL_OFFSETS_FILE="model/audio_mel_offsets.hex",
    parameter LOG_FILE="model/audio_log_q24.hex",
    parameter DCT_FILE="model/audio_dct4_q30.hex"
)(
    input wire clk,rst_n,clear,start,in_valid,
    input wire signed [15:0] in_pcm,
    output wire in_ready,out_valid,
    input wire out_ready,
    output wire signed [23:0] out_mfcc,
    output wire [5:0] out_index,
    output wire [6:0] out_frame_index,
    output wire out_frame_last,out_clip_last,busy,
    output reg done,error
);
    localparam integer WINDOW_SAMPLES=480;
    localparam integer RING_SAMPLES=WINDOW_SAMPLES+HOP_SAMPLES;
    localparam integer FRAMES=(CLIP_SAMPLES-WINDOW_SAMPLES)/HOP_SAMPLES+1;
    localparam IDLE=0,INITIAL_LOAD=1,START_FRAME=2,FEED_FRAME=3,WAIT_FRAME=4,TAIL=5;
    reg [2:0] state;
    reg [14:0] input_count;
    reg [8:0] prefetch_count;
    reg [9:0] write_pointer,window_base,read_pointer;
    reg [8:0] issued_count,accepted_count;
    reg [6:0] frame_index;
    reg read_pending,frame_finished;
    wire live=rst_n&&!clear;
    assign busy=state!=IDLE;
    assign in_ready=live&&input_count<CLIP_SAMPLES&&(state==INITIAL_LOAD||state==TAIL||
        ((state==FEED_FRAME||state==WAIT_FRAME)&&frame_index<FRAMES-1&&prefetch_count<HOP_SAMPLES));
    wire input_fire=in_valid&&in_ready;
    wire frame_ready,frame_busy,frame_done,frame_error;
    wire issue=live&&state==FEED_FRAME&&issued_count<480&&(!read_pending||frame_ready);
    wire [15:0] ring_q;
    assign out_frame_index=frame_index;
    assign out_clip_last=out_frame_last&&frame_index==FRAMES-1;
    function automatic [9:0] next_ring(input [9:0] address);
        next_ring=address==RING_SAMPLES-1?10'd0:address+10'd1;
    endfunction
    kwt_audio_scratch_ram #(.WIDTH(16),.DEPTH(RING_SAMPLES),.ADDR_W(10)) pcm_ring(
        .clk(clk),.a_en(input_fire),.a_we(input_fire),.a_addr(write_pointer),.a_data(in_pcm),.a_strobe(2'b11),.a_q(),
        .b_en(issue),.b_we(1'b0),.b_addr(read_pointer),.b_data(16'd0),.b_q(ring_q));
    kwt_audio_frame_mfcc #(.HANN_FILE(HANN_FILE),.TWIDDLE_FILE(TWIDDLE_FILE),.MEL_FILE(MEL_FILE),
        .MEL_OFFSETS_FILE(MEL_OFFSETS_FILE),.LOG_FILE(LOG_FILE),.DCT_FILE(DCT_FILE)) frame_engine(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(state==START_FRAME),
        .in_valid(live&&state==FEED_FRAME&&read_pending),.in_pcm(ring_q),.in_ready(frame_ready),
        .out_valid(out_valid),.out_ready(out_ready),.out_mfcc(out_mfcc),.out_index(out_index),.out_last(out_frame_last),
        .busy(frame_busy),.done(frame_done),.error(frame_error));
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            state<=IDLE;input_count<=0;prefetch_count<=0;write_pointer<=0;window_base<=0;read_pointer<=0;
            issued_count<=0;accepted_count<=0;frame_index<=0;read_pending<=0;frame_finished<=0;done<=0;error<=0;
        end else begin
            done<=0;
            if(input_fire)begin
                input_count<=input_count+1'b1;write_pointer<=next_ring(write_pointer);
                if(state!=INITIAL_LOAD)prefetch_count<=prefetch_count+1'b1;
            end
            if(!read_pending||frame_ready)read_pending<=issue;
            if(issue)begin issued_count<=issued_count+1'b1;read_pointer<=next_ring(read_pointer);end
            if((state==FEED_FRAME||state==WAIT_FRAME)&&frame_error)error<=1;
            case(state)
                IDLE:if(start)begin
                    state<=INITIAL_LOAD;input_count<=0;prefetch_count<=0;write_pointer<=0;window_base<=0;
                    frame_index<=0;frame_finished<=0;read_pending<=0;error<=0;
                end
                INITIAL_LOAD:if(input_fire&&input_count==479)state<=START_FRAME;
                START_FRAME:begin
                    state<=FEED_FRAME;read_pointer<=window_base;issued_count<=0;accepted_count<=0;read_pending<=0;
                end
                FEED_FRAME:if(read_pending&&frame_ready)begin
                    if(accepted_count==479)state<=WAIT_FRAME;else accepted_count<=accepted_count+1'b1;
                end
                WAIT_FRAME:begin
                    if(frame_done)frame_finished<=1;
                    if(frame_finished||frame_done)begin
                        if(frame_index==FRAMES-1)begin
                            // floor geometry leaves a real160-sample tail for2s.
                            // Do not seal DONE or pretend those samples were consumed.
                            if(input_count==CLIP_SAMPLES)begin state<=IDLE;done<=1;end
                            else if(input_count<CLIP_SAMPLES)state<=TAIL;
                            else begin error<=1;state<=IDLE;done<=1;end
                        end else if(prefetch_count==HOP_SAMPLES)begin
                            window_base<=window_base+HOP_SAMPLES>=RING_SAMPLES?
                              window_base+HOP_SAMPLES-RING_SAMPLES:window_base+HOP_SAMPLES;
                            frame_index<=frame_index+1'b1;prefetch_count<=0;frame_finished<=0;state<=START_FRAME;
                        end
                    end
                end
                TAIL:begin
                    // Tail bytes are consumed through the same real input handshake.
                    // They do not create a padded extra MFCC frame.
                    if(input_count==CLIP_SAMPLES)begin state<=IDLE;done<=1;end
                end
                default:state<=IDLE;
            endcase
        end
    end
// synthesis translate_off
    initial begin
      if(!((CLIP_SAMPLES==16000&&HOP_SAMPLES==160)||(CLIP_SAMPLES==32000&&HOP_SAMPLES==320)))
        $fatal(1,"profile must be exactlegacy1s ornew2s geometry");
      if(RING_SAMPLES>1024||FRAMES>128||CLIP_SAMPLES>32767)
        $fatal(1,"profile counter/ring bounds");
    end
    // synthesis translate_on
endmodule
