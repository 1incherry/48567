`timescale 1ns/1ps
// Trusted raw-PCM producer -> real KWT frontend CSR -> actual authenticated
// cache flush -> sealed seed context. No raw DDR load or PS-controlled ACK.
// The producer port must be wired to trusted physical ingress or trusted-PC
// debug provisioning, never the untrusted PS register window.
module trusted_audio_pcm_frontend(
 input wire clk,security_reset_n,authorized,cancel,trusted_clear_fault,
 input wire [31:0] model_epoch,runtime_epoch,source_id,clip_id,generation,
 input wire [127:0] key_session_id,
 input wire start,output wire start_ready,
 input wire parameters_valid,input wire [287:0] parameters_context,
 input wire typed_memory_ready,input wire [287:0] typed_memory_context,
 input wire memory_quiescent,core_quiescent,
 input wire pcm_valid,output wire pcm_ready,input wire [15:0] pcm_data,
 input wire [14:0] pcm_index,input wire pcm_last,input wire [287:0] pcm_context,
 output wire flush_request,input wire flush_ready,output wire [287:0] flush_context,
 input wire flush_response_valid,output wire flush_response_ready,
 input wire flush_response_error,input wire [287:0] flush_response_context,
 output wire sealed_seed_valid,output wire [287:0] sealed_seed_context,
 output wire busy,quiescent,output wire done,output reg fault,
 output reg [31:0] committed_pcm_samples,
 output wire [20:0] m_awaddr,output wire [2:0] m_awprot,output wire m_awvalid,input wire m_awready,
 output wire [31:0] m_wdata,output wire [3:0] m_wstrb,output wire m_wvalid,input wire m_wready,
 input wire [1:0] m_bresp,input wire m_bvalid,output wire m_bready,
 output wire [20:0] m_araddr,output wire [2:0] m_arprot,output wire m_arvalid,input wire m_arready,
 input wire [31:0] m_rdata,input wire [1:0] m_rresp,input wire m_rvalid,output wire m_rready
);
 localparam IDLE=0,BEGIN_FRONT=1,WAIT_FRONT=2,STREAM=3,WAIT_DONE=4,
  CHECK_PCM=5,CHECK_MFCC=6,CHECK_EMBED=7,FLUSH=8,CLEAR_FRONT=9,SEAL=10,
  ABORT_FRONT=11,WAIT_ABORT=12,WAIT_QUIET=13,HARD_FAIL=14;
 reg [3:0] state;
 reg [287:0] captured_context;
 wire [287:0] live_context={model_epoch,runtime_epoch,source_id,clip_id,generation,key_session_id};
 reg issued,aborted,present,done_reg,have_sample,flush_issued;
 reg [15:0] sample;
 reg [31:0] last_generation,last_runtime_epoch;reg [127:0] last_key_session;
 wire context_ok=authorized&&!cancel&&!aborted&&live_context==captured_context;
 wire context_well_formed=model_epoch!=0&&runtime_epoch!=0&&clip_id!=0&&generation!=0&&key_session_id!=0;
 wire fresh=runtime_epoch!=last_runtime_epoch||key_session_id!=last_key_session||generation>last_generation;
 wire new_context_ok=authorized&&!cancel&&context_well_formed&&fresh&&parameters_valid&&parameters_context==live_context&&typed_memory_ready&&typed_memory_context==live_context;
 reg bus_active,bus_write,aw_sent,w_sent,ar_sent,bus_done,bus_error;
 reg [20:0] bus_address;reg [31:0] bus_payload,bus_result;reg [3:0] bus_strobes;
 wire bus_quiet=!bus_active&&!bus_done;
 wire op_ready=bus_quiet;
 wire ordinary_phase=state==BEGIN_FRONT||state==WAIT_FRONT||state==WAIT_DONE||
  state==CHECK_PCM||state==CHECK_MFCC||state==CHECK_EMBED||state==CLEAR_FRONT;
 wire abort_phase=state==ABORT_FRONT||state==WAIT_ABORT;
 wire op_valid=!issued&&(abort_phase||(context_ok&&(ordinary_phase||(state==STREAM&&have_sample))));
 wire op_write=state==BEGIN_FRONT||state==STREAM||state==CLEAR_FRONT||state==ABORT_FRONT;
 wire [20:0] op_address=state==BEGIN_FRONT||state==ABORT_FRONT?21'h100:
  state==STREAM?21'h108:state==CLEAR_FRONT?21'h000:
  state==WAIT_FRONT||state==WAIT_ABORT?21'h104:state==WAIT_DONE?21'h004:
  state==CHECK_PCM?21'h110:state==CHECK_MFCC?21'h114:21'h118;
 wire [31:0] op_payload=state==STREAM?{16'd0,sample}:state==BEGIN_FRONT?32'd1:32'd2;
 assign m_awaddr=bus_address;assign m_awprot=0;
 assign m_awvalid=bus_active&&bus_write&&!aw_sent;
 assign m_wdata=bus_payload;assign m_wstrb=bus_strobes;
 assign m_wvalid=bus_active&&bus_write&&!w_sent;
 assign m_bready=bus_active&&bus_write&&aw_sent&&w_sent;
 assign m_araddr=bus_address;assign m_arprot=0;
 assign m_arvalid=bus_active&&!bus_write&&!ar_sent;
 assign m_rready=bus_active&&!bus_write&&ar_sent;
 always @(posedge clk)begin
  if(!security_reset_n)begin
   bus_active<=0;bus_write<=0;aw_sent<=0;w_sent<=0;ar_sent<=0;
   bus_done<=0;bus_error<=0;bus_address<=0;bus_payload<=0;bus_strobes<=0;bus_result<=0;
  end else begin
   bus_done<=0;
   if(op_valid&&op_ready)begin
    bus_active<=1;bus_write<=op_write;bus_address<=op_address;bus_payload<=op_payload;
    bus_strobes<=state==STREAM?4'b0011:4'b1111;aw_sent<=0;w_sent<=0;ar_sent<=0;bus_error<=0;
   end
   if(m_awvalid&&m_awready)aw_sent<=1;
   if(m_wvalid&&m_wready)w_sent<=1;
   if(m_arvalid&&m_arready)ar_sent<=1;
   if(m_bvalid&&m_bready)begin bus_active<=0;bus_done<=1;bus_error<=m_bresp!=0;end
   if(m_rvalid&&m_rready)begin bus_active<=0;bus_done<=1;bus_error<=m_rresp!=0;bus_result<=m_rdata;end
  end
 end
 assign start_ready=state==IDLE&&bus_quiet&&!fault&&new_context_ok&&memory_quiescent&&core_quiescent;
 assign pcm_ready=state==STREAM&&context_ok&&!fault&&!have_sample&&!issued&&bus_quiet;
 assign flush_request=state==FLUSH&&!flush_issued&&context_ok;
 assign flush_response_ready=state==FLUSH&&flush_issued;
 assign flush_context=captured_context;
 assign sealed_seed_valid=present&&context_ok&&!fault&&state==IDLE;
 assign sealed_seed_context=sealed_seed_valid?captured_context:288'd0;
 assign done=done_reg&&sealed_seed_valid;
 assign quiescent=state==IDLE&&bus_quiet&&!flush_issued&&core_quiescent&&memory_quiescent;
 assign busy=!quiescent;
 always @(posedge clk)begin
  if(!security_reset_n)begin
   state<=IDLE;captured_context<=0;issued<=0;aborted<=0;present<=0;done_reg<=0;
   have_sample<=0;flush_issued<=0;sample<=0;committed_pcm_samples<=0;fault<=0;
   last_generation<=0;last_runtime_epoch<=0;last_key_session<=0;
  end else begin
   done_reg<=0;
   if(trusted_clear_fault&&quiescent)fault<=0;
   if(!context_ok)present<=0;
   if(state!=IDLE&&!context_ok)begin aborted<=1;fault<=1;end
   if(op_valid&&op_ready)issued<=1;
   if(state!=IDLE&&state!=ABORT_FRONT&&state!=WAIT_ABORT&&state!=WAIT_QUIET&&state!=HARD_FAIL&&
     !context_ok&&!issued&&bus_quiet&&!flush_issued)begin state<=ABORT_FRONT;have_sample<=0;end
   else if(bus_done&&issued)begin
    issued<=0;
    if(state==ABORT_FRONT)begin if(bus_error)state<=HARD_FAIL;else state<=WAIT_ABORT;end
    else if(state==WAIT_ABORT)begin
     if(bus_error)state<=HARD_FAIL;else if(!bus_result[0])state<=WAIT_QUIET;
    end else if(bus_error||!context_ok)begin fault<=1;aborted<=1;state<=ABORT_FRONT;have_sample<=0;end
    else case(state)
     BEGIN_FRONT:state<=WAIT_FRONT;
     WAIT_FRONT:begin
      if(bus_result[2])begin fault<=1;aborted<=1;state<=ABORT_FRONT;end
      else if(bus_result[6:3]==4'd2&&bus_result[0]&&!bus_result[1])state<=STREAM;
     end
     STREAM:begin
      have_sample<=0;committed_pcm_samples<=committed_pcm_samples+1'b1;
      if(committed_pcm_samples==31999)state<=WAIT_DONE;
     end
     WAIT_DONE:begin
      if(bus_result[2])begin fault<=1;aborted<=1;state<=ABORT_FRONT;end
      else if(bus_result[1])state<=CHECK_PCM;
     end
     CHECK_PCM:if(bus_result!=32000)begin fault<=1;aborted<=1;state<=ABORT_FRONT;end else state<=CHECK_MFCC;
     CHECK_MFCC:if(bus_result!=3960)begin fault<=1;aborted<=1;state<=ABORT_FRONT;end else state<=CHECK_EMBED;
     CHECK_EMBED:if(bus_result!=2)begin fault<=1;aborted<=1;state<=ABORT_FRONT;end else state<=FLUSH;
     CLEAR_FRONT:state<=SEAL;
     default:begin fault<=1;aborted<=1;state<=ABORT_FRONT;end
    endcase
   end else case(state)
    IDLE:if(start)begin
     if(!fresh&&authorized&&context_well_formed)fault<=1;
     else if(start_ready)begin
      captured_context<=live_context;last_runtime_epoch<=runtime_epoch;last_key_session<=key_session_id;last_generation<=generation;
      committed_pcm_samples<=0;issued<=0;aborted<=0;present<=0;have_sample<=0;flush_issued<=0;state<=BEGIN_FRONT;
     end
    end
    STREAM:if(pcm_valid&&pcm_ready)begin
     if(pcm_context!=captured_context||pcm_index!=committed_pcm_samples||pcm_last!=(committed_pcm_samples==31999))begin
      fault<=1;aborted<=1;state<=ABORT_FRONT;
     end else begin sample<=pcm_data;have_sample<=1;end
    end
    FLUSH:begin
     if(flush_request&&flush_ready)flush_issued<=1;
     if(flush_response_valid&&flush_response_ready)begin
      flush_issued<=0;
      if(!context_ok||flush_response_error||flush_response_context!=captured_context)begin fault<=1;aborted<=1;state<=ABORT_FRONT;end
      else state<=CLEAR_FRONT;
     end
    end
    SEAL:if(core_quiescent&&memory_quiescent&&bus_quiet)begin
     present<=1;done_reg<=1;state<=IDLE;
    end
    WAIT_QUIET:if(core_quiescent&&memory_quiescent&&bus_quiet)begin state<=IDLE;issued<=0;end
    HARD_FAIL:begin fault<=1;present<=0;end
    default:begin end
   endcase
  end
 end
endmodule
