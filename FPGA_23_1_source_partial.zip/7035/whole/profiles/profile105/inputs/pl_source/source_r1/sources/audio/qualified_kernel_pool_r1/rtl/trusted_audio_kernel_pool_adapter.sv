`timescale 1ns/1ps
// Four original 4096x16 KWT kernel banks occupy A[0..1023]x256 instead.
// clk is the ungated fabric clock; core_step MUST be the real upcoming gated
// KWT rising edge. A native read completes at that same edge (v714/v921).
// Pool ownership/authorization and model identity remain the trusted parent's
// responsibility. This adapter creates neither a grant nor an authenticated key.
module trusted_audio_kernel_pool_adapter #(
 parameter [11:0] POOL_BASE=12'd0
)(input wire clk,rst_n,owner_live,cancel,clear,core_step,
 input wire cache_response,input wire [11:0] cache_response_index,
 input wire [1:0] cache_response_lane,input wire cache_response_dual,
 input wire cache_response_valid,cache_response_second_valid,cache_response_last,
 input wire [15:0] b_read_data,a_read_data,
 input wire compute_read,input wire [11:0] compute_pointer,
 output wire [63:0] read_data,output wire core_ready,quiescent,pool_quiescent,output reg load_committed,output reg fault,
 output wire pool_write_valid,input wire pool_write_ready,output wire [11:0] pool_write_address,output wire [255:0] pool_write_data,
 output wire pool_read_request,pool_read_enable,input wire pool_read_ready,output wire [11:0] pool_read_address,input wire [255:0] pool_read_data
);
reg [255:0] assembly;
reg [15:0] filled;
reg [9:0] assembly_group,pending_group;
reg pending,pending_last,read_pending;
reg [1:0] read_slice;
reg [63:0] read_latched;
wire [9:0] incoming_group=cache_response_index[11:2];
wire [3:0] incoming_slot={cache_response_index[1:0],cache_response_lane};
wire incoming_dual_good=!cache_response_dual||!cache_response_lane[0];
reg [255:0] next_assembly;reg [15:0] next_filled;
always @*begin
 next_assembly=filled==0?256'd0:assembly;next_filled=filled;
 next_assembly[incoming_slot*16+:16]=cache_response_valid?b_read_data:16'd0;
 next_filled[incoming_slot]=1;
 if(cache_response_dual&&incoming_dual_good)begin
  next_assembly[(incoming_slot+1)*16+:16]=cache_response_second_valid?a_read_data:16'd0;
  next_filled[incoming_slot+1]=1;
 end
end
// Never admit the next core edge on a pending write, even on its accepting
// edge: otherwise the first compute read could collide with the last fill and
// observe the OLD v714 RAM value. One fabric drain edge preserves core latency.
assign core_ready=rst_n&&owner_live&&!cancel&&!pending&&!fault&&
 (!compute_read||clear||(load_committed&&pool_read_ready));
assign quiescent=!pending&&filled==0&&!read_pending;
// A partially assembled word has not touched A and may yield its port to the
// ledger. Root/job quiescence still requires clear/cancel or complete assembly.
assign pool_quiescent=!pending&&!read_pending;
assign pool_write_valid=pending&&owner_live;
assign pool_write_address=POOL_BASE+{2'd0,pending_group};
// No second 256-bit queue: the core is stalled while this complete word is
// pending, so the assembly register itself holds the stable accepted payload.
assign pool_write_data=assembly;
assign pool_read_enable=core_step&&core_ready&&compute_read&&!clear;
// Arbiter grants from this independent intent, not from an enable which is
// already ready-qualified. It locks only an ACTUAL pool_read_enable edge.
assign pool_read_request=owner_live&&!cancel&&!fault&&!pending&&compute_read&&load_committed&&!clear;
assign pool_read_address=POOL_BASE+{2'd0,compute_pointer[11:2]};
// Immediate bypass preserves the original one-core-edge RAM return. Capture
// before yielding A, then hold across core pauses while the ledger reads A.
assign read_data=read_pending?pool_read_data[read_slice*64+:64]:read_latched;
always @(posedge clk)begin
 if(!rst_n)begin
  assembly<=0;filled<=0;assembly_group<=0;pending_group<=0;
  pending<=0;pending_last<=0;read_pending<=0;read_slice<=0;read_latched<=0;load_committed<=0;fault<=0;
 end else begin
  read_pending<=pool_read_enable;
  if(read_pending)read_latched<=pool_read_data[read_slice*64+:64];
  if(pool_read_enable)read_slice<=compute_pointer[1:0];
  if(!owner_live&&(pending||filled!=0||read_pending))fault<=1;
  if(core_step&&!core_ready)fault<=1;
  if(pool_write_valid&&pool_write_ready)begin
   pending<=0;
   if(pending_last&&!cancel&&!clear&&!fault)load_committed<=1;
  end
  if(cancel)begin filled<=0;if(!pending)assembly<=0;load_committed<=0;end
  else if(core_step&&core_ready)begin
   if(clear)begin filled<=0;assembly<=0;load_committed<=0;end
   else if(cache_response)begin
    if(!incoming_dual_good||(filled!=0&&incoming_group!=assembly_group)||filled[incoming_slot]||
       (cache_response_dual&&filled[incoming_slot+1])||
       (cache_response_last&&next_filled[cache_response_index[1:0]*4+:4]!=4'hf))begin
     fault<=1;load_committed<=0;
    end else begin
     assembly_group<=incoming_group;assembly<=next_assembly;filled<=next_filled;
     if(next_filled==16'hffff||cache_response_last)begin
      pending<=1;pending_last<=cache_response_last;pending_group<=incoming_group;
      filled<=0;
     end
    end
   end
  end
 end
end
endmodule
