`include "audio105_profile_parameters.vh"
`timescale 1ns/1ps
// Live audio frontend + PE embedding + programmable encoder interface. AXI4-Lite32, 512KiB
// shared BRAM at offset 0x100000. Descriptor at 0x40..0x7c (16 words).
// Memory reads/writes are rejected during active operations; status remains
// accessible. E203 schedules the 168 operations and reloads parameters.
module kwt_encoder_audio_axi_core_pool #(
    parameter EXP_FILE="kwt_exp.hex", GELU_FILE="kwt_gelu.hex",
    parameter HANN_FILE="model/audio_hann_q30.hex",TWIDDLE_FILE="model/audio_twiddle_q30.hex",
    parameter MEL_FILE="model/audio_mel_sparse_q30.hex",MEL_OFFSETS_FILE="model/audio_mel_offsets.hex",
    parameter LOG_FILE="model/audio_log_q24.hex",DCT_FILE="model/audio_dct4_q30.hex"
) (

    input wire fabric_clk,core_step,kernel_owner_live,kernel_cancel,
    output wire kernel_core_ready,kernel_pool_quiescent,kernel_quiescent,kernel_fault,
    output wire kernel_pool_write_valid,input wire kernel_pool_write_ready,
    output wire [11:0] kernel_pool_write_address,output wire [255:0] kernel_pool_write_data,
    output wire kernel_pool_read_request,kernel_pool_read_enable,input wire kernel_pool_read_ready,
    output wire [11:0] kernel_pool_read_address,input wire [255:0] kernel_pool_read_data,
    input wire clk,rst_n,
    input wire [20:0] s_axi_awaddr,
    input wire [2:0] s_axi_awprot,
    input wire s_axi_awvalid,
    output wire s_axi_awready,
    input wire [31:0] s_axi_wdata,
    input wire [3:0] s_axi_wstrb,
    input wire s_axi_wvalid,
    output wire s_axi_wready,
    output reg [1:0] s_axi_bresp,
    output reg s_axi_bvalid,
    input wire s_axi_bready,
    input wire [20:0] s_axi_araddr,
    input wire [2:0] s_axi_arprot,
    input wire s_axi_arvalid,
    output wire s_axi_arready,
    output reg [31:0] s_axi_rdata,
    output reg [1:0] s_axi_rresp,
    output reg s_axi_rvalid,
    input wire s_axi_rready,
    output wire core_locked,
    output wire mem_a_en,mem_a_we,mem_b_en,mem_b_we,
    output wire [16:0] mem_a_addr,mem_b_addr,
    output wire [31:0] mem_a_data,mem_b_data,
    output wire [3:0] mem_a_strobe,
    input wire [31:0] mem_a_q,mem_b_q,
    output wire irq
);
    reg aw_held,w_held;
    reg [20:0] aw_address,read_address;
    reg [31:0] write_payload,config_words[0:15];
    reg [3:0] write_strobes;
    reg [1:0] read_state;
    reg start,clear;
    wire busy,done,fault;
    wire [31:0] operation_cycles;
    reg [31:0] accelerator_reads,accelerator_writes,host_reads,host_writes;
    reg [31:0] load_request,load_ack;
    reg [63:0] elapsed_clock;
    localparam F_IDLE=0,F_START=1,F_MFCC=2,F_MAT_START=3,F_MAT_WAIT=4,
        F_MAT_CLEAR=5,F_POS_START=6,F_POS_WAIT=7,F_POS_CLEAR=8,F_FINISH=9,F_FAIL_CLEAR=10,F_CLEAR=11;
    reg [3:0] front_state;
    reg front_done,front_fault;
    reg frontend_clear;
    reg [31:0] front_cycles,pcm_count,mfcc_count,embedding_commands;
    wire pcm_ready,mfcc_valid,mfcc_ready,frontend_done,frontend_error;
    wire front_active=front_state!=F_IDLE;
    wire locked=busy||start||front_active;
    wire write_pending=aw_held&&w_held&&!s_axi_bvalid;
    wire pcm_eligible=aw_address==21'h108&&write_strobes[1:0]==2'b11&&
        front_state==F_MFCC&&pcm_count<32000&&!frontend_error;
    wire write_execute=write_pending&&(!pcm_eligible||pcm_ready);
    wire front_control=write_execute&&aw_address==21'h100&&write_strobes[0];
    wire front_abort=front_control&&write_payload[1];
    wire front_begin=front_control&&!write_payload[1]&&write_payload[0]&&!locked;
    wire pcm_fire=write_execute&&pcm_eligible;
    wire signed [23:0] mfcc_data;
    wire [5:0] mfcc_index;
    wire [6:0] mfcc_frame;
    wire mfcc_last,clip_last;
    wire mfcc_write=mfcc_valid&&mfcc_ready;
    wire auto_start=front_state==F_MAT_START||front_state==F_POS_START;
    wire auto_clear=front_state==F_MAT_CLEAR||front_state==F_POS_CLEAR||front_state==F_FAIL_CLEAR;
    wire engine_clear=clear||front_abort||front_begin||auto_clear;
    wire auto_position=front_state>=F_POS_START;
    wire [31:0] command_words[0:15];
    genvar descriptor_index;
    generate for(descriptor_index=0;descriptor_index<16;descriptor_index=descriptor_index+1)begin: commands
        wire [31:0] automatic_word;
        assign automatic_word=descriptor_index==0?(auto_position?32'd2:32'd1):
            descriptor_index==1?(auto_position?32'd51264:32'd112448):
            descriptor_index==2?(auto_position?32'd119040:32'd116416):
            descriptor_index==3?32'd51264:
            descriptor_index==4?(auto_position?32'd0:32'd118976):
            descriptor_index==5?32'd99:descriptor_index==6?32'd64:
            descriptor_index==7?(auto_position?32'd0:32'd40):
            descriptor_index==8?(auto_position?32'd0:(14+`AUDIO105_PATCH_FRACTION-10)):
            descriptor_index==10?(auto_position?32'd16:32'd24):
            descriptor_index==11?(auto_position?32'd0:32'd1):32'd0;
        assign command_words[descriptor_index]=front_active?automatic_word:config_words[descriptor_index];
    end endgenerate
    assign mfcc_ready=rst_n&&!front_abort&&front_state==F_MFCC&&mfcc_count<3960;
    kwt_audio_mfcc_profile #(.HANN_FILE(HANN_FILE),.TWIDDLE_FILE(TWIDDLE_FILE),.MEL_FILE(MEL_FILE),
        .MEL_OFFSETS_FILE(MEL_OFFSETS_FILE),.LOG_FILE(LOG_FILE),.DCT_FILE(DCT_FILE)) frontend(
        .clk(clk),.rst_n(rst_n),.clear(frontend_clear),
        .start(front_state==F_START),.in_valid(write_pending&&pcm_eligible),.in_pcm(write_payload[15:0]),
        .in_ready(pcm_ready),.out_valid(mfcc_valid),.out_ready(mfcc_ready),.out_mfcc(mfcc_data),
        .out_index(mfcc_index),.out_frame_index(mfcc_frame),.out_frame_last(mfcc_last),
        .out_clip_last(clip_last),.busy(),.done(frontend_done),.error(frontend_error));
    wire read_issue=(read_state==1)&&!write_execute;
    wire write_aligned=aw_address[1:0]==0;
    wire read_aligned=read_address[1:0]==0;
    wire wm=write_aligned&&aw_address>=21'h100000&&aw_address<21'h180000;
    wire rm=read_aligned&&read_address>=21'h100000&&read_address<21'h180000;
    wire wc=write_aligned&&aw_address>=21'h40&&aw_address<=21'h7c;
    wire rc=read_aligned&&read_address>=21'h40&&read_address<=21'h7c;
    wire host_write=write_execute&&wm&&!locked;
    wire host_read=read_issue&&rm&&!locked;
    wire a_enable,b_enable,b_write;
    wire [16:0] a_address,b_address;
    wire [31:0] b_write_data,a_read_data,b_read_data;
    wire [16:0] host_address=write_execute?aw_address[18:2]:read_address[18:2];
    integer i,lane;
    assign s_axi_awready=rst_n&&!aw_held&&!s_axi_bvalid;
    assign s_axi_wready=rst_n&&!w_held&&!s_axi_bvalid;
    assign s_axi_arready=rst_n&&(read_state==0)&&!s_axi_rvalid;
    assign irq=front_done||(!front_active&&done);
    assign core_locked=locked;
    assign mem_a_en=a_enable||host_write||host_read;
    assign mem_a_we=host_write;
    assign mem_a_addr=busy?a_address:host_address;
    assign mem_a_data=write_payload;
    assign mem_a_strobe=write_strobes;
    assign a_read_data=mem_a_q;
    assign mem_b_en=!engine_clear&&(mfcc_write||b_enable);
    assign mem_b_we=!engine_clear&&(mfcc_write||b_write);
    assign mem_b_addr=mfcc_write?(17'd112448+mfcc_count[16:0]):b_address;
    assign mem_b_data=mfcc_write?{{8{mfcc_data[23]}},mfcc_data}:b_write_data;
    assign b_read_data=mem_b_q;
    kwt_encoder_engine_pool #(.EXP_FILE(EXP_FILE),.GELU_FILE(GELU_FILE)) engine(
        .fabric_clk(fabric_clk),.core_step(core_step),.kernel_owner_live(kernel_owner_live),.kernel_cancel(kernel_cancel),
        .kernel_core_ready(kernel_core_ready),.kernel_pool_quiescent(kernel_pool_quiescent),.kernel_quiescent(kernel_quiescent),.kernel_fault(kernel_fault),
        .kernel_pool_write_valid(kernel_pool_write_valid),.kernel_pool_write_ready(kernel_pool_write_ready),
        .kernel_pool_write_address(kernel_pool_write_address),.kernel_pool_write_data(kernel_pool_write_data),
        .kernel_pool_read_request(kernel_pool_read_request),.kernel_pool_read_enable(kernel_pool_read_enable),.kernel_pool_read_ready(kernel_pool_read_ready),
        .kernel_pool_read_address(kernel_pool_read_address),.kernel_pool_read_data(kernel_pool_read_data),

        .clk(clk),.rst_n(rst_n),.clear(engine_clear),.start(start||auto_start),
        .opcode(command_words[0][3:0]),.source_a(command_words[1][16:0]),.source_b(command_words[2][16:0]),
        .destination(command_words[3][16:0]),.bias_base(command_words[4][16:0]),
        .rows(command_words[5][7:0]),.columns(command_words[6][8:0]),.inner(command_words[7][8:0]),
        .shift_a(command_words[8][7:0]),.shift_b(command_words[9][7:0]),.output_bits(command_words[10][5:0]),
        .has_bias(command_words[11][0]),.transpose_b(command_words[11][1]),.input_fraction(command_words[12][5:0]),
        .epsilon({command_words[14],command_words[13]}),.busy(busy),.done(done),.fault(fault),.cycles(operation_cycles),
        .a_enable(a_enable),.b_enable(b_enable),.b_write(b_write),.a_address(a_address),.b_address(b_address),
        .b_write_data(b_write_data),.a_read_data(a_read_data),.b_read_data(b_read_data));
    always @(posedge clk) begin
        if(!rst_n) begin
            aw_held<=0;w_held<=0;s_axi_bvalid<=0;s_axi_bresp<=0;
            read_state<=0;read_address<=0;s_axi_rvalid<=0;s_axi_rdata<=0;s_axi_rresp<=0;
            start<=0;clear<=0;aw_address<=0;write_payload<=0;write_strobes<=0;
            accelerator_reads<=0;accelerator_writes<=0;host_reads<=0;host_writes<=0;
            load_request<=0;load_ack<=0;
            elapsed_clock<=0;
            for(i=0;i<16;i=i+1) config_words[i]<=0;
        end else begin
            start<=0;clear<=0;
            elapsed_clock<=elapsed_clock+1;
            accelerator_reads<=accelerator_reads+a_enable+(b_enable&&!b_write);
            accelerator_writes<=accelerator_writes+(!engine_clear&&(b_write||mfcc_write));
            host_reads<=host_reads+host_read;host_writes<=host_writes+host_write;
            if(s_axi_awvalid&&s_axi_awready) begin aw_held<=1;aw_address<=s_axi_awaddr;end
            if(s_axi_wvalid&&s_axi_wready) begin w_held<=1;write_payload<=s_axi_wdata;write_strobes<=s_axi_wstrb;end
            if(s_axi_bvalid&&s_axi_bready) s_axi_bvalid<=0;
            if(write_execute) begin
                aw_held<=0;w_held<=0;s_axi_bvalid<=1;s_axi_bresp<=2'b10;
                if(write_aligned&&aw_address==0) begin
                    if(!write_strobes[0]) s_axi_bresp<=0;
                    else if(write_payload[1]) begin if(!front_active)begin clear<=1;s_axi_bresp<=0;end end
                    else if(write_payload[0]) begin if(!locked) begin start<=1;s_axi_bresp<=0;end end
                    else if(write_payload[2]) begin
                        if(!locked) begin accelerator_reads<=0;accelerator_writes<=0;host_reads<=0;host_writes<=0;s_axi_bresp<=0;end
                    end else s_axi_bresp<=0;
                end else if(write_aligned&&aw_address==21'h100)begin
                    if(!write_strobes[0]||write_payload[1]||(!locked&&write_payload[0])||write_payload==0)s_axi_bresp<=0;
                end else if(aw_address==21'h108&&pcm_eligible)begin
                    s_axi_bresp<=0;
                end else if(write_aligned&&!locked&&(aw_address==21'h80||aw_address==21'h84)) begin
                    s_axi_bresp<=0;
                    for(lane=0;lane<4;lane=lane+1) if(write_strobes[lane]) begin
                        if(aw_address==21'h80) load_request[lane*8+:8]<=write_payload[lane*8+:8];
                        else load_ack[lane*8+:8]<=write_payload[lane*8+:8];
                    end
                end else if(!locked&&wc) begin
                    s_axi_bresp<=0;
                    for(lane=0;lane<4;lane=lane+1) if(write_strobes[lane])
                        config_words[(aw_address-21'h40)>>2][lane*8+:8]<=write_payload[lane*8+:8];
                end else if(host_write) s_axi_bresp<=0;
            end
            if(s_axi_rvalid&&s_axi_rready) s_axi_rvalid<=0;
            if(s_axi_arvalid&&s_axi_arready) begin read_address<=s_axi_araddr;read_state<=1;end
            if(read_issue) begin
                if(host_read) read_state<=2;
                else begin
                    read_state<=0;s_axi_rvalid<=1;s_axi_rresp<=0;
                    if(rc) s_axi_rdata<=config_words[(read_address-21'h40)>>2];
                    else case(read_address)
                        0:s_axi_rdata<=0;
                        4:s_axi_rdata<={29'b0,(fault||front_fault),(front_done||(!front_active&&done)),locked};
                        8:s_axi_rdata<=operation_cycles;
                        16:s_axi_rdata<=accelerator_reads;
                        20:s_axi_rdata<=accelerator_writes;
                        24:s_axi_rdata<=host_reads;
                        28:s_axi_rdata<=host_writes;
                        32:s_axi_rdata<=elapsed_clock[31:0];
                        36:s_axi_rdata<=elapsed_clock[63:32];
                        128:s_axi_rdata<=load_request;
                        132:s_axi_rdata<=load_ack;
                        256:s_axi_rdata<=0;
                        260:s_axi_rdata<={25'd0,front_state,front_fault,front_done,front_active};
                        268:s_axi_rdata<=front_cycles;
                        272:s_axi_rdata<=pcm_count;
                        276:s_axi_rdata<=mfcc_count;
                        280:s_axi_rdata<=embedding_commands;
                        default:begin s_axi_rresp<=2'b10;s_axi_rdata<=0;end
                    endcase
                end
            end
            if(read_state==2) begin read_state<=0;s_axi_rvalid<=1;s_axi_rresp<=0;s_axi_rdata<=a_read_data;end
        end
    end
    // Exclusive producer ownership: MFCC writes while the PE engine is idle,
    // then two automatic descriptors generate every patch token in shared X.
    // No host transfer of precomputed patch tokens is part of this job.
    // The frontend clear crosses a register. A combinational clear from
    // write_execute would feed in_ready back into write_execute through the
    // AXI PCM backpressure path, even when address conditions are exclusive.
    always @(posedge clk)begin
        if(!rst_n)frontend_clear<=1;
        else frontend_clear<=front_abort||front_begin||front_state==F_FAIL_CLEAR;
    end
    always @(posedge clk)begin
        if(!rst_n||front_abort)begin
            front_state<=F_IDLE;front_done<=0;front_fault<=0;
            front_cycles<=0;pcm_count<=0;mfcc_count<=0;embedding_commands<=0;
        end else begin
            if(front_active)front_cycles<=front_cycles+1'b1;
            if(clear&&!front_active)begin front_done<=0;front_fault<=0;end
            if(pcm_fire)pcm_count<=pcm_count+1'b1;
            if(mfcc_write)begin
                mfcc_count<=mfcc_count+1'b1;
                if(mfcc_frame*40+mfcc_index!=mfcc_count||mfcc_last!=(mfcc_index==39)||clip_last!=(mfcc_count==3959))begin
                    front_fault<=1;front_state<=F_FAIL_CLEAR;
                end
            end
            case(front_state)
                F_IDLE:if(front_begin)begin
                    front_state<=F_CLEAR;front_done<=0;front_fault<=0;front_cycles<=0;
                    pcm_count<=0;mfcc_count<=0;embedding_commands<=0;
                end
                F_CLEAR:front_state<=F_START;
                F_START:front_state<=F_MFCC;
                F_MFCC:begin
                    if(frontend_error)begin front_fault<=1;front_state<=F_FAIL_CLEAR;end
                    else if(frontend_done)begin
                        if(pcm_count!=32000||mfcc_count!=3960)begin front_fault<=1;front_state<=F_FAIL_CLEAR;end
                        else front_state<=F_MAT_START;
                    end
                end
                F_MAT_START:front_state<=F_MAT_WAIT;
                F_MAT_WAIT:if(done)begin
                    embedding_commands<=embedding_commands+1'b1;
                    if(fault)begin front_fault<=1;front_state<=F_FAIL_CLEAR;end
                    else front_state<=F_MAT_CLEAR;
                end
                F_MAT_CLEAR:front_state<=F_POS_START;
                F_POS_START:front_state<=F_POS_WAIT;
                F_POS_WAIT:if(done)begin
                    embedding_commands<=embedding_commands+1'b1;
                    if(fault)begin front_fault<=1;front_state<=F_FAIL_CLEAR;end
                    else front_state<=F_POS_CLEAR;
                end
                F_POS_CLEAR,F_FAIL_CLEAR:front_state<=F_FINISH;
                F_FINISH:begin front_state<=F_IDLE;front_done<=1;end
                default:begin front_fault<=1;front_state<=F_FAIL_CLEAR;end
            endcase
        end
    end

endmodule
