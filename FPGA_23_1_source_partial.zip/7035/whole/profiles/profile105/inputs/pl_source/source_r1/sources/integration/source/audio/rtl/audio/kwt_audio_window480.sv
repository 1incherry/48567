`timescale 1ns/1ps
// Accept one 480-sample PCM16 frame. Store exact PCM*HannQ30 products,
// select the frame exponent before rounding, then stream 512 signed32
// samples (including 32 zero pads). This preserves very quiet frames.
module kwt_audio_window480 #(
    parameter HANN_FILE="model/audio_hann_q30.hex"
)(
    input wire clk,rst_n,clear,start,in_valid,
    input wire signed [15:0] in_pcm,
    output wire in_ready,out_valid,
    input wire out_ready,
    output wire signed [31:0] out_real,
    output wire [8:0] out_index,
    output wire [5:0] out_fraction,
    output wire busy,
    output reg done,overflow
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
    localparam IDLE=0,LOAD=1,DRAIN1=2,DRAIN2=3,EXPONENT=4,READ=5,WAIT=6,NORMALIZE=7,ROUND=8,EMIT=9;
    reg [3:0] state;
    reg [8:0] load_index,output_index,tag0,tag1;
    reg load_valid,raw_valid;
    reg signed [15:0] pcm0;
    reg signed [31:0] hann0;
    reg signed [47:0] raw_product;
    reg [47:0] peak;
    reg signed [6:0] window_shift;
    reg [5:0] fraction;
    reg signed [31:0] result;
    reg signed [63:0] read_value,rounded_value;
    reg signed [31:0] hann[0:479];
    initial $readmemh(HANN_FILE,hann);
    wire live=rst_n&&!clear;
    assign in_ready=live&&state==LOAD;
    assign out_valid=live&&state==EMIT;
    assign out_real=result;assign out_index=output_index;assign out_fraction=fraction;
    assign busy=state!=IDLE;
    wire [47:0] absolute_product=raw_product[47]?-raw_product:raw_product;
    wire [63:0] memory_q;
    wire writing=live&&raw_valid;
    wire reading=live&&state==READ&&output_index<480;
    // Isolate RAM read, variable normalization/RNE and overflow detection.
    wire signed [63:0] rounded=kwt_round64(read_value,$signed(window_shift));
    function automatic integer normalization_shift(input [47:0] value);
        integer k;
        begin
            normalization_shift=15;
            for(k=0;k<48;k=k+1)if(value[k])normalization_shift=k-29;
        end
    endfunction
    kwt_audio_fft_ram frame_ram(
        .clk(clk),.a_en(writing||reading),.a_we(writing),
        .a_addr(writing?tag1:output_index),.a_data({{16{raw_product[47]}},raw_product}),.a_strobe(8'hff),.a_q(memory_q),
        .b_en(1'b0),.b_we(1'b0),.b_addr(9'd0),.b_data(64'd0),.b_q());
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            state<=IDLE;load_index<=0;output_index<=0;tag0<=0;tag1<=0;
            load_valid<=0;raw_valid<=0;pcm0<=0;hann0<=0;raw_product<=0;
            peak<=0;window_shift<=15;fraction<=30;result<=0;done<=0;overflow<=0;read_value<=0;rounded_value<=0;
        end else begin
            done<=0;load_valid<=in_ready&&in_valid;raw_valid<=load_valid;
            if(in_ready&&in_valid)begin pcm0<=in_pcm;hann0<=hann[load_index];tag0<=load_index;end
            if(load_valid)begin raw_product<=pcm0*hann0;tag1<=tag0;end
            if(raw_valid&&absolute_product>peak)peak<=absolute_product;
            case(state)
                IDLE:if(start)begin state<=LOAD;load_index<=0;peak<=0;overflow<=0;output_index<=0;end
                LOAD:if(in_valid)begin
                    if(load_index==479)state<=DRAIN1;
                    else load_index<=load_index+1'b1;
                end
                DRAIN1:state<=DRAIN2;
                DRAIN2:state<=EXPONENT;
                EXPONENT:begin
                    window_shift<=normalization_shift(peak);fraction<=45-normalization_shift(peak);state<=READ;
                end
                READ:if(output_index<480)state<=WAIT;else begin result<=0;state<=EMIT;end
                WAIT:begin read_value<=memory_q;state<=NORMALIZE;end
                NORMALIZE:begin rounded_value<=rounded;state<=ROUND;end
                ROUND:begin
                    result<=rounded_value[31:0];state<=EMIT;
                    if(rounded_value>64'sd2147483647||rounded_value< -64'sd2147483648)overflow<=1;
                end
                EMIT:if(out_ready)begin
                    if(output_index==511)begin done<=1;state<=IDLE;end
                    else begin output_index<=output_index+1'b1;state<=READ;end
                end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
