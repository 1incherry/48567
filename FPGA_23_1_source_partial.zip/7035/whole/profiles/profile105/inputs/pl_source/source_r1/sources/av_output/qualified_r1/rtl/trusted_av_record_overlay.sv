`timescale 1ns/1ps
// Opaque protected strip, actual PL bank labels only. Background pixels remain
// diagnostic/untrusted. Output RGB/HS/VS/DE all have the same two-clock latency.
module trusted_av_record_overlay #(
 parameter WIDTH=1280,HEIGHT=720,HTOTAL=1650,VTOTAL=750
)(input wire clk,rst_n,source_current_live,
 input wire snapshot_valid,input wire [2047:0] snapshot_data,output wire snapshot_ready,
 input wire [11:0] x,y,input wire [23:0] rgb_in,input wire hs_in,vs_in,de_in,
 output reg [23:0] rgb_out,output reg hs_out,vs_out,de_out,
 output wire current_label_valid
);
 reg [2047:0] display_record;
 reg render_valid;
 (* ASYNC_REG="TRUE",SHREG_EXTRACT="NO" *) reg [1:0] live_sync;
 wire display_reset_n=rst_n&&source_current_live;
 wire accept=snapshot_valid&&snapshot_ready;
 // Copy only in blanking at the frame boundary; CDC retains its entire body.
 assign snapshot_ready=rst_n&&x==HTOTAL-1&&y==VTOTAL-1;
 assign current_label_valid=render_valid&&live_sync[1];
 always @(posedge clk or negedge display_reset_n)begin
  if(!display_reset_n)live_sync<=0;
  else live_sync<={live_sync[0],1'b1};
 end
 always @(posedge clk)begin
  if(!rst_n||!live_sync[1])render_valid<=0;
  else if(accept)render_valid<=1;
 end
 always @(posedge clk)begin
  if(!rst_n)display_record<=0;
  else if(accept)display_record<=snapshot_data;
 end
 function automatic [7:0] hexchar(input [3:0] nibble);
  begin hexchar=nibble<10?8'd48+nibble:8'd65+(nibble-10);end
 endfunction
 function automatic [191:0] class_name(input [7:0] class_id);
  begin case(class_id)
8'd0:class_name=192'h424541522020202020202020202020202020202020202020;
8'd1:class_name=192'h4341545f5f4142595353494e49414e202020202020202020;
8'd2:class_name=192'h4341545f5f42454e47414c20202020202020202020202020;
8'd3:class_name=192'h4341545f5f4249524d414e20202020202020202020202020;
8'd4:class_name=192'h4341545f5f424f4d42415920202020202020202020202020;
8'd5:class_name=192'h4341545f5f425249544953485f53484f5254484149522020;
8'd6:class_name=192'h4341545f5f454759505449414e5f4d415520202020202020;
8'd7:class_name=192'h4341545f5f4d41494e455f434f4f4e202020202020202020;
8'd8:class_name=192'h4341545f5f5045525349414e202020202020202020202020;
8'd9:class_name=192'h4341545f5f524147444f4c4c202020202020202020202020;
8'd10:class_name=192'h4341545f5f5255535349414e5f424c554520202020202020;
8'd11:class_name=192'h4341545f5f5349414d455345202020202020202020202020;
8'd12:class_name=192'h4341545f5f535048594e5820202020202020202020202020;
8'd13:class_name=192'h434f57202020202020202020202020202020202020202020;
8'd14:class_name=192'h444f475f5f41464748414e20202020202020202020202020;
8'd15:class_name=192'h444f475f5f4146524943414e5f57494c445f444f47202020;
8'd16:class_name=192'h444f475f5f4149524544414c452020202020202020202020;
8'd17:class_name=192'h444f475f5f414d45524943414e5f42554c4c444f47202020;
8'd18:class_name=192'h444f475f5f414d45524943414e5f484149524c4553532020;
8'd19:class_name=192'h444f475f5f414d45524943414e5f5049545f42554c4c5f54;
8'd20:class_name=192'h444f475f5f414d45524943414e5f5350414e49454c202020;
8'd21:class_name=192'h444f475f5f424153454e4a49202020202020202020202020;
8'd22:class_name=192'h444f475f5f42415353455420202020202020202020202020;
8'd23:class_name=192'h444f475f5f4241535345545f484f554e4420202020202020;
8'd24:class_name=192'h444f475f5f424541474c4520202020202020202020202020;
8'd25:class_name=192'h444f475f5f4245524d414953452020202020202020202020;
8'd26:class_name=192'h444f475f5f424943484f4e5f465249534520202020202020;
8'd27:class_name=192'h444f475f5f424c454e4845494d2020202020202020202020;
8'd28:class_name=192'h444f475f5f424c4f4f44484f554e44202020202020202020;
8'd29:class_name=192'h444f475f5f424c55455449434b2020202020202020202020;
8'd30:class_name=192'h444f475f5f424f524445525f434f4c4c4945202020202020;
8'd31:class_name=192'h444f475f5f424f525a4f4920202020202020202020202020;
8'd32:class_name=192'h444f475f5f424f53544f4e5f544552524945522020202020;
8'd33:class_name=192'h444f475f5f424f5845522020202020202020202020202020;
8'd34:class_name=192'h444f475f5f42554c4c5f4d41535449464620202020202020;
8'd35:class_name=192'h444f475f5f42554c4c5f5445525249455220202020202020;
8'd36:class_name=192'h444f475f5f42554c4c444f47202020202020202020202020;
8'd37:class_name=192'h444f475f5f434149524e2020202020202020202020202020;
8'd38:class_name=192'h444f475f5f43484948554148554120202020202020202020;
8'd39:class_name=192'h444f475f5f4348494e4553455f4352455354454420202020;
8'd40:class_name=192'h444f475f5f43484f57202020202020202020202020202020;
8'd41:class_name=192'h444f475f5f434c554d424552202020202020202020202020;
8'd42:class_name=192'h444f475f5f434f434b41504f4f2020202020202020202020;
8'd43:class_name=192'h444f475f5f434f434b455220202020202020202020202020;
8'd44:class_name=192'h444f475f5f434f4c4c494520202020202020202020202020;
8'd45:class_name=192'h444f475f5f434f5247492020202020202020202020202020;
8'd46:class_name=192'h444f475f5f434f594f544520202020202020202020202020;
8'd47:class_name=192'h444f475f5f44414c4d415449414e20202020202020202020;
8'd48:class_name=192'h444f475f5f44414c4d4154494f4e20202020202020202020;
8'd49:class_name=192'h444f475f5f44484f4c452020202020202020202020202020;
8'd50:class_name=192'h444f475f5f44494e474f2020202020202020202020202020;
8'd51:class_name=192'h444f475f5f444f4245524d414e2020202020202020202020;
8'd52:class_name=192'h444f475f5f454c4b5f484f554e4420202020202020202020;
8'd53:class_name=192'h444f475f5f454e474c4953485f434f434b45525f5350414e;
8'd54:class_name=192'h444f475f5f454e474c4953485f5345545445522020202020;
8'd55:class_name=192'h444f475f5f4652454e43485f42554c4c444f472020202020;
8'd56:class_name=192'h444f475f5f4745524d414e5f534845504552442020202020;
8'd57:class_name=192'h444f475f5f4745524d414e5f53484f525448414952454420;
8'd58:class_name=192'h444f475f5f474f4c44454e5f524554524945564552202020;
8'd59:class_name=192'h444f475f5f47524541545f44414e45202020202020202020;
8'd60:class_name=192'h444f475f5f47524541545f504552454e4545532020202020;
8'd61:class_name=192'h444f475f5f47524541545f505952454e4545532020202020;
8'd62:class_name=192'h444f475f5f47524559484f554e4420202020202020202020;
8'd63:class_name=192'h444f475f5f47524f454e454e4441454c2020202020202020;
8'd64:class_name=192'h444f475f5f484156414e4553452020202020202020202020;
8'd65:class_name=192'h444f475f5f49524953485f5350414e49454c202020202020;
8'd66:class_name=192'h444f475f5f49524953485f574f4c46484f554e4420202020;
8'd67:class_name=192'h444f475f5f4a4150414e4553455f4348494e202020202020;
8'd68:class_name=192'h444f475f5f4a4150414e4553455f5350414e49454c202020;
8'd69:class_name=192'h444f475f5f4b454553484f4e442020202020202020202020;
8'd70:class_name=192'h444f475f5f4b4f4d4f4e444f522020202020202020202020;
8'd71:class_name=192'h444f475f5f4c41425241444f4f444c452020202020202020;
8'd72:class_name=192'h444f475f5f4c41425241444f522020202020202020202020;
8'd73:class_name=192'h444f475f5f4c454f4e424552474552202020202020202020;
8'd74:class_name=192'h444f475f5f4c484153412020202020202020202020202020;
8'd75:class_name=192'h444f475f5f4d414c494e4f49532020202020202020202020;
8'd76:class_name=192'h444f475f5f4d414c54455345202020202020202020202020;
8'd77:class_name=192'h444f475f5f4d45585f484149524c45535320202020202020;
8'd78:class_name=192'h444f475f5f4d494e4941545552455f50494e534348455220;
8'd79:class_name=192'h444f475f5f4e4557464f554e444c414e4420202020202020;
8'd80:class_name=192'h444f475f5f50454b494e4553452020202020202020202020;
8'd81:class_name=192'h444f475f5f5049545f42554c4c2020202020202020202020;
8'd82:class_name=192'h444f475f5f504f4d4552414e49414e202020202020202020;
8'd83:class_name=192'h444f475f5f504f4f444c4520202020202020202020202020;
8'd84:class_name=192'h444f475f5f50554720202020202020202020202020202020;
8'd85:class_name=192'h444f475f5f52484f44455349414e20202020202020202020;
8'd86:class_name=192'h444f475f5f524f54545745494c4552202020202020202020;
8'd87:class_name=192'h444f475f5f5341494e545f4245524e415244202020202020;
8'd88:class_name=192'h444f475f5f53414d4f594544202020202020202020202020;
8'd89:class_name=192'h444f475f5f5343484e41555a455220202020202020202020;
8'd90:class_name=192'h444f475f5f53434f5443485f544552524945522020202020;
8'd91:class_name=192'h444f475f5f53434f54544953485f54455252494552202020;
8'd92:class_name=192'h444f475f5f534841525f5045492020202020202020202020;
8'd93:class_name=192'h444f475f5f53484942415f494e5520202020202020202020;
8'd94:class_name=192'h444f475f5f534849485f545a552020202020202020202020;
8'd95:class_name=192'h444f475f5f534942455249414e5f4855534b592020202020;
8'd96:class_name=192'h444f475f5f53544146464f524453484952455f42554c4c5f;
8'd97:class_name=192'h444f475f5f56495a534c4120202020202020202020202020;
8'd98:class_name=192'h444f475f5f5748454154454e5f5445525249455220202020;
8'd99:class_name=192'h444f475f5f594f524b494520202020202020202020202020;
8'd100:class_name=192'h444f475f5f594f524b53484952455f544552524945522020;
8'd101:class_name=192'h4541474c4520202020202020202020202020202020202020;
8'd102:class_name=192'h464953482020202020202020202020202020202020202020;
8'd103:class_name=192'h534e414b4520202020202020202020202020202020202020;
8'd104:class_name=192'h544947455220202020202020202020202020202020202020;
   default:class_name="INVALID CLASS           ";
  endcase end
 endfunction
 function automatic [6:0] glyph_column(input [7:0] ch,input [2:0] column);
  begin case({ch,column})
11'h180:glyph_column=7'h3e;
11'h181:glyph_column=7'h51;
11'h182:glyph_column=7'h49;
11'h183:glyph_column=7'h45;
11'h184:glyph_column=7'h3e;
11'h188:glyph_column=7'h00;
11'h189:glyph_column=7'h42;
11'h18a:glyph_column=7'h7f;
11'h18b:glyph_column=7'h40;
11'h18c:glyph_column=7'h00;
11'h190:glyph_column=7'h42;
11'h191:glyph_column=7'h61;
11'h192:glyph_column=7'h51;
11'h193:glyph_column=7'h49;
11'h194:glyph_column=7'h46;
11'h198:glyph_column=7'h21;
11'h199:glyph_column=7'h41;
11'h19a:glyph_column=7'h45;
11'h19b:glyph_column=7'h4b;
11'h19c:glyph_column=7'h31;
11'h1a0:glyph_column=7'h18;
11'h1a1:glyph_column=7'h14;
11'h1a2:glyph_column=7'h12;
11'h1a3:glyph_column=7'h7f;
11'h1a4:glyph_column=7'h10;
11'h1a8:glyph_column=7'h27;
11'h1a9:glyph_column=7'h45;
11'h1aa:glyph_column=7'h45;
11'h1ab:glyph_column=7'h45;
11'h1ac:glyph_column=7'h39;
11'h1b0:glyph_column=7'h3c;
11'h1b1:glyph_column=7'h4a;
11'h1b2:glyph_column=7'h49;
11'h1b3:glyph_column=7'h49;
11'h1b4:glyph_column=7'h30;
11'h1b8:glyph_column=7'h01;
11'h1b9:glyph_column=7'h71;
11'h1ba:glyph_column=7'h09;
11'h1bb:glyph_column=7'h05;
11'h1bc:glyph_column=7'h03;
11'h1c0:glyph_column=7'h36;
11'h1c1:glyph_column=7'h49;
11'h1c2:glyph_column=7'h49;
11'h1c3:glyph_column=7'h49;
11'h1c4:glyph_column=7'h36;
11'h1c8:glyph_column=7'h06;
11'h1c9:glyph_column=7'h49;
11'h1ca:glyph_column=7'h49;
11'h1cb:glyph_column=7'h29;
11'h1cc:glyph_column=7'h1e;
11'h208:glyph_column=7'h7e;
11'h209:glyph_column=7'h11;
11'h20a:glyph_column=7'h11;
11'h20b:glyph_column=7'h11;
11'h20c:glyph_column=7'h7e;
11'h210:glyph_column=7'h7f;
11'h211:glyph_column=7'h49;
11'h212:glyph_column=7'h49;
11'h213:glyph_column=7'h49;
11'h214:glyph_column=7'h36;
11'h218:glyph_column=7'h3e;
11'h219:glyph_column=7'h41;
11'h21a:glyph_column=7'h41;
11'h21b:glyph_column=7'h41;
11'h21c:glyph_column=7'h22;
11'h220:glyph_column=7'h7f;
11'h221:glyph_column=7'h41;
11'h222:glyph_column=7'h41;
11'h223:glyph_column=7'h22;
11'h224:glyph_column=7'h1c;
11'h228:glyph_column=7'h7f;
11'h229:glyph_column=7'h49;
11'h22a:glyph_column=7'h49;
11'h22b:glyph_column=7'h49;
11'h22c:glyph_column=7'h41;
11'h230:glyph_column=7'h7f;
11'h231:glyph_column=7'h09;
11'h232:glyph_column=7'h09;
11'h233:glyph_column=7'h09;
11'h234:glyph_column=7'h01;
11'h238:glyph_column=7'h3e;
11'h239:glyph_column=7'h41;
11'h23a:glyph_column=7'h49;
11'h23b:glyph_column=7'h49;
11'h23c:glyph_column=7'h7a;
11'h240:glyph_column=7'h7f;
11'h241:glyph_column=7'h08;
11'h242:glyph_column=7'h08;
11'h243:glyph_column=7'h08;
11'h244:glyph_column=7'h7f;
11'h248:glyph_column=7'h00;
11'h249:glyph_column=7'h41;
11'h24a:glyph_column=7'h7f;
11'h24b:glyph_column=7'h41;
11'h24c:glyph_column=7'h00;
11'h250:glyph_column=7'h20;
11'h251:glyph_column=7'h40;
11'h252:glyph_column=7'h41;
11'h253:glyph_column=7'h3f;
11'h254:glyph_column=7'h01;
11'h258:glyph_column=7'h7f;
11'h259:glyph_column=7'h08;
11'h25a:glyph_column=7'h14;
11'h25b:glyph_column=7'h22;
11'h25c:glyph_column=7'h41;
11'h260:glyph_column=7'h7f;
11'h261:glyph_column=7'h40;
11'h262:glyph_column=7'h40;
11'h263:glyph_column=7'h40;
11'h264:glyph_column=7'h40;
11'h268:glyph_column=7'h7f;
11'h269:glyph_column=7'h02;
11'h26a:glyph_column=7'h0c;
11'h26b:glyph_column=7'h02;
11'h26c:glyph_column=7'h7f;
11'h270:glyph_column=7'h7f;
11'h271:glyph_column=7'h04;
11'h272:glyph_column=7'h08;
11'h273:glyph_column=7'h10;
11'h274:glyph_column=7'h7f;
11'h278:glyph_column=7'h3e;
11'h279:glyph_column=7'h41;
11'h27a:glyph_column=7'h41;
11'h27b:glyph_column=7'h41;
11'h27c:glyph_column=7'h3e;
11'h280:glyph_column=7'h7f;
11'h281:glyph_column=7'h09;
11'h282:glyph_column=7'h09;
11'h283:glyph_column=7'h09;
11'h284:glyph_column=7'h06;
11'h288:glyph_column=7'h3e;
11'h289:glyph_column=7'h41;
11'h28a:glyph_column=7'h51;
11'h28b:glyph_column=7'h21;
11'h28c:glyph_column=7'h5e;
11'h290:glyph_column=7'h7f;
11'h291:glyph_column=7'h09;
11'h292:glyph_column=7'h19;
11'h293:glyph_column=7'h29;
11'h294:glyph_column=7'h46;
11'h298:glyph_column=7'h46;
11'h299:glyph_column=7'h49;
11'h29a:glyph_column=7'h49;
11'h29b:glyph_column=7'h49;
11'h29c:glyph_column=7'h31;
11'h2a0:glyph_column=7'h01;
11'h2a1:glyph_column=7'h01;
11'h2a2:glyph_column=7'h7f;
11'h2a3:glyph_column=7'h01;
11'h2a4:glyph_column=7'h01;
11'h2a8:glyph_column=7'h3f;
11'h2a9:glyph_column=7'h40;
11'h2aa:glyph_column=7'h40;
11'h2ab:glyph_column=7'h40;
11'h2ac:glyph_column=7'h3f;
11'h2b0:glyph_column=7'h1f;
11'h2b1:glyph_column=7'h20;
11'h2b2:glyph_column=7'h40;
11'h2b3:glyph_column=7'h20;
11'h2b4:glyph_column=7'h1f;
11'h2b8:glyph_column=7'h3f;
11'h2b9:glyph_column=7'h40;
11'h2ba:glyph_column=7'h38;
11'h2bb:glyph_column=7'h40;
11'h2bc:glyph_column=7'h3f;
11'h2c0:glyph_column=7'h63;
11'h2c1:glyph_column=7'h14;
11'h2c2:glyph_column=7'h08;
11'h2c3:glyph_column=7'h14;
11'h2c4:glyph_column=7'h63;
11'h2c8:glyph_column=7'h07;
11'h2c9:glyph_column=7'h08;
11'h2ca:glyph_column=7'h70;
11'h2cb:glyph_column=7'h08;
11'h2cc:glyph_column=7'h07;
11'h2d0:glyph_column=7'h61;
11'h2d1:glyph_column=7'h51;
11'h2d2:glyph_column=7'h49;
11'h2d3:glyph_column=7'h45;
11'h2d4:glyph_column=7'h43;
11'h2f8:glyph_column=7'h40;
11'h2f9:glyph_column=7'h40;
11'h2fa:glyph_column=7'h40;
11'h2fb:glyph_column=7'h40;
11'h2fc:glyph_column=7'h40;
11'h1d0:glyph_column=7'h00;
11'h1d1:glyph_column=7'h00;
11'h1d2:glyph_column=7'h24;
11'h1d3:glyph_column=7'h00;
11'h1d4:glyph_column=7'h00;
11'h168:glyph_column=7'h00;
11'h169:glyph_column=7'h00;
11'h16a:glyph_column=7'h08;
11'h16b:glyph_column=7'h00;
11'h16c:glyph_column=7'h00;
   default:glyph_column=0;
  endcase end
 endfunction
 function automatic [63:0] audio_name(input [3:0] class_id);
  begin case(class_id)
   4'd0:audio_name=64'h53494c454e434520;
   4'd1:audio_name=64'h554e4b4e4f574e20;
   4'd2:audio_name=64'h5945532020202020;
   4'd3:audio_name=64'h4e4f202020202020;
   4'd4:audio_name=64'h5550202020202020;
   4'd5:audio_name=64'h444f574e20202020;
   4'd6:audio_name=64'h4c45465420202020;
   4'd7:audio_name=64'h5249474854202020;
   4'd8:audio_name=64'h4f4e202020202020;
   4'd9:audio_name=64'h4f46462020202020;
   4'd10:audio_name=64'h53544f5020202020;
   4'd11:audio_name=64'h474f202020202020;
   default:audio_name=64'h2020202020202020;
  endcase end
 endfunction
 wire [5:0] char_position=x/12;
 wire [2:0] line_position=y/18;
 wire [2:0] glyph_x=(x%12)>>1,glyph_y=(y%18)>>1;
 wire inside_strip=x<WIDTH&&y<108;
 wire audio_record=display_record[2047-0*8-:32]==32'h4e415232;
 wire [63:0] audio_label=audio_name(display_record[2047-48*8-:32]);
 wire [2:0] count=display_record[2047-28*8-:32];
 reg [7:0] character;
 reg [191:0] label;
 reg [383:0] phrase;
 reg [127:0] result_item;
 reg [31:0] frame_word,epoch_word,generation;
 reg [7:0] class_id;
 integer slot;
 always @* begin
  character=32;label=0;phrase=0;result_item=0;generation=0;class_id=0;slot=0;
  frame_word=audio_record?display_record[2047-16*8-:32]:display_record[2047-20*8-:32];epoch_word=display_record[2047-24*8-:32];
  if(line_position==0)begin
   phrase=current_label_valid?(audio_record?"PL VERIFIED AUDIO                               ":count==0?"PL VERIFIED  NO TARGET                           ":"PL VERIFIED RESULT                              "):
     "NO VALID PL RESULT                              ";
   if(char_position<48)character=phrase[383-char_position*8-:8];
  end else if(line_position==1&&current_label_valid)begin
   phrase=audio_record?"CLIP           EPOCH                            ":"FRAME          EPOCH                            ";
   if(char_position<48)character=phrase[383-char_position*8-:8];
   if(char_position>=6&&char_position<14)character=hexchar(frame_word[31-(char_position-6)*4-:4]);
   if(char_position>=21&&char_position<29)character=hexchar(epoch_word[31-(char_position-21)*4-:4]);
  end else if(audio_record&&line_position==2&&current_label_valid)begin
   phrase="AUDIO                                           ";
   class_id=display_record[2047-48*8-:32];generation=display_record[2047-20*8-:32];
   phrase[383-14*8-:32]=" ID ";phrase[383-20*8-:40]=" GEN ";
   if(char_position<48)character=phrase[383-char_position*8-:8];
   if(char_position>=6&&char_position<14)character=audio_label[63-(char_position-6)*8-:8];
   if(char_position==18)character=hexchar(class_id[7:4]);
   if(char_position==19)character=hexchar(class_id[3:0]);
   if(char_position>=25&&char_position<33)character=hexchar(generation[31-(char_position-25)*4-:4]);
  end else if(!audio_record&&line_position>=2&&line_position<6&&current_label_valid)begin
   slot=line_position-2;
   if(slot<count)begin
    result_item=display_record[2047-(168+slot*16)*8-:128];
    generation=result_item[127:96];class_id=result_item[95:88];label=class_name(class_id);
    phrase="ROI                                             ";
    phrase[383-29*8-:32]=" ID ";phrase[383-35*8-:40]=" GEN ";
    if(char_position<48)character=phrase[383-char_position*8-:8];
    if(char_position==3)character=8'd48+slot;
    if(char_position>=5&&char_position<29)character=label[191-(char_position-5)*8-:8];
    if(char_position==33)character=hexchar(class_id[7:4]);
    if(char_position==34)character=hexchar(class_id[3:0]);
    if(char_position>=40&&char_position<48)character=hexchar(generation[31-(char_position-40)*4-:4]);
   end
  end
 end
 reg [7:0] character_s1;
 reg [2:0] column_s1,row_s1;
 reg strip_s1,hs_s1,vs_s1,de_s1;
 reg [23:0] background_s1;
 wire [6:0] glyph_bits=glyph_column(character_s1,column_s1);
 wire glyph_pixel=column_s1<5&&row_s1<7&&glyph_bits[row_s1];
 always @(posedge clk)begin
  if(!rst_n)begin
   character_s1<=32;column_s1<=0;row_s1<=0;strip_s1<=0;background_s1<=0;hs_s1<=0;vs_s1<=0;de_s1<=0;
   rgb_out<=0;hs_out<=0;vs_out<=0;de_out<=0;
  end else begin
   character_s1<=character;column_s1<=glyph_x;row_s1<=glyph_y;strip_s1<=inside_strip;
   background_s1<=rgb_in;hs_s1<=hs_in;vs_s1<=vs_in;de_s1<=de_in;
   hs_out<=hs_s1;vs_out<=vs_s1;de_out<=de_s1;
   if(!de_s1)rgb_out<=0;
   else if(strip_s1)rgb_out<=glyph_pixel?(current_label_valid?24'hffffff:24'hff6060):24'h101020;
   else rgb_out<=background_s1;
  end
 end
endmodule
