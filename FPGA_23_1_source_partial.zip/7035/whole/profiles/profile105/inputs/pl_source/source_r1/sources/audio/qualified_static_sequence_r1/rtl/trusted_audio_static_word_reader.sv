`timescale 1ns/1ps
// One natural little-endian 32-bit word from the actual shared authenticated
// page lease. The parent supplies PL-owned phase/object requests and a bound
// model/runtime/key/clip context. There is no PS or raw-DDR read path here.
module trusted_audio_static_word_reader(
 input wire clk,rst_n,cancel,authorized,
 input wire [31:0] runtime_epoch,model_epoch,source_id,clip_id,generation,
 input wire [127:0] key_session_id,
 input wire request_valid,output wire request_ready,
 input wire [8:0] request_object,input wire [31:0] request_word_index,
 output wire response_valid,input wire response_ready,output wire response_error,
 output wire [8:0] response_object,output wire [31:0] response_word_index,response_data,
 output reg [31:0] response_runtime_epoch,response_model_epoch,response_source_id,response_clip_id,response_generation,
 output reg [127:0] response_key_session_id,
 output wire lease_request,input wire lease_ready,output wire [31:0] lease_object,lease_page,lease_epoch,
 input wire lease_response_valid,lease_verified,input wire [31:0] lease_response_object,lease_response_page,lease_response_epoch,
 input wire lease_still_valid,
 output wire word_request,input wire word_ready,output wire [6:0] word_offset,
 input wire word_response_valid,input wire [6:0] word_response_offset,input wire [255:0] word_response_data,
 output wire lease_release,input wire release_ready,input wire cache_quiescent,output wire quiescent
);
localparam IDLE=0,LEASE=1,LEASE_WAIT=2,WORD=3,WORD_WAIT=4,RELEASE=5,QUIET=6,REPORT=7;
reg [2:0] state;
reg [8:0] object_id;reg [31:0] word_index,data;reg good,aborted;
wire context_live=authorized&&!cancel&&!aborted&&runtime_epoch==response_runtime_epoch&&model_epoch==response_model_epoch&&
 key_session_id==response_key_session_id&&source_id==response_source_id&&clip_id==response_clip_id&&generation==response_generation;
wire request_in_range=request_object>=296&&request_object<=313&&
 request_word_index<(request_object<=307?49792:request_object==308?8960:request_object==309?64:request_object==310?2688:request_object==311?6720:request_object==312?105:32);
assign request_ready=state==IDLE&&cache_quiescent;
assign quiescent=state==IDLE&&cache_quiescent;
assign response_valid=state==REPORT;
assign response_error=!good||!context_live;
assign response_object=object_id;assign response_word_index=word_index;
assign response_data=response_error?32'd0:data;
assign lease_request=state==LEASE&&context_live;
assign lease_object={23'd0,object_id};assign lease_page=word_index>>10;assign lease_epoch=response_runtime_epoch;
assign word_request=state==WORD&&context_live;assign word_offset=word_index[9:3];
assign lease_release=state==RELEASE;
always @(posedge clk)begin
 if(!rst_n)begin
  state<=IDLE;object_id<=0;word_index<=0;data<=0;good<=0;aborted<=0;
  response_runtime_epoch<=0;response_model_epoch<=0;response_source_id<=0;response_clip_id<=0;response_generation<=0;response_key_session_id<=0;
 end else begin
  if(state!=IDLE&&!context_live)aborted<=1;
  case(state)
   IDLE:if(request_valid&&request_ready)begin
    object_id<=request_object;word_index<=request_word_index;data<=0;good<=0;aborted<=0;
    response_runtime_epoch<=runtime_epoch;response_model_epoch<=model_epoch;response_source_id<=source_id;response_clip_id<=clip_id;response_generation<=generation;response_key_session_id<=key_session_id;
    if(cancel||!authorized||generation==0||!request_in_range)state<=REPORT;else state<=LEASE;
   end
   LEASE:if(!context_live)state<=REPORT;else if(lease_ready)state<=LEASE_WAIT;
   LEASE_WAIT:if(lease_response_valid)begin
    if(!lease_verified||lease_response_object!=lease_object||lease_response_page!=lease_page||lease_response_epoch!=lease_epoch||!lease_still_valid||!context_live)state<=RELEASE;
    else state<=WORD;
   end
   WORD:if(!context_live)state<=RELEASE;else if(word_ready)state<=WORD_WAIT;
   WORD_WAIT:if(word_response_valid)begin
    if(word_response_offset==word_offset&&lease_still_valid&&context_live)begin data<=word_response_data[word_index[2:0]*32+:32];good<=1;end
    state<=RELEASE;
   end
   RELEASE:if(release_ready)state<=QUIET;
   QUIET:if(cache_quiescent)state<=REPORT;
   REPORT:if(response_ready)state<=IDLE;
   default:begin good<=0;state<=RELEASE;end
  endcase
 end
end
endmodule
