`timescale 1ns/1ps
// Unsigned64 fixed-point Mel ->signed32 ln Q24,clamped at ln(1e-12).
// Nine registered stages:input,leading bit,normalize,ROM,difference product,
// interpolate sum,RNE/exponent term,combine,clamp. II1 when output accepts.
// Global stall preserves all pipeline entries under arbitrary backpressure.
module kwt_audio_log_q24 #(
    parameter TABLE_FILE="model/audio_log_q24.hex"
)(
    input wire clk,rst_n,clear,in_valid,
    output wire in_ready,
    input wire [63:0] in_mel,
    input wire [6:0] in_fraction,in_index,
    output wire out_valid,
    input wire out_ready,
    output wire signed [31:0] out_log,
    output wire [6:0] out_index
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
    localparam signed [31:0] LOG_FLOOR=-32'sd463571610;
    reg [23:0] log_table[0:4096];
    initial $readmemh(TABLE_FILE,log_table);
    reg [8:0] valid,zero;
    reg [6:0] index[0:8];
    reg [63:0] value0,value1;
    reg [6:0] fraction0;
    reg [5:0] exponent1;
    reg signed [8:0] bias1,bias2,bias3,bias4,bias5;
    reg [31:0] coordinate2;
    reg [23:0] base3,next3,base4;
    reg [19:0] fraction3;
    reg [32:0] product4;
    reg [43:0] mix5;
    reg [31:0] rounded6;
    reg signed [31:0] exponent_term6,result8;
    reg signed [32:0] sum7;
    wire advance=!valid[8]||out_ready;
    assign in_ready=rst_n&&!clear&&advance;
    assign out_valid=rst_n&&!clear&&valid[8];
    assign out_log=result8;assign out_index=index[8];
    function automatic [5:0] msb64(input [63:0] value);
        integer k;
        begin msb64=0;for(k=0;k<64;k=k+1)if(value[k])msb64=k;end
    endfunction
    wire [63:0] normalized=exponent1<=32?value1<<(32-exponent1):value1>>(exponent1-32);
    wire [23:0] difference3=next3-base3;
    wire signed [63:0] rounded_mix=kwt_round64($signed({20'd0,mix5}),20);
    integer j;
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            valid<=0;zero<=0;for(j=0;j<9;j=j+1)index[j]<=0;
            value0<=0;value1<=0;fraction0<=0;exponent1<=0;
            bias1<=0;bias2<=0;bias3<=0;bias4<=0;bias5<=0;coordinate2<=0;
            base3<=0;next3<=0;fraction3<=0;base4<=0;product4<=0;mix5<=0;
            rounded6<=0;exponent_term6<=0;sum7<=0;result8<=0;
        end else if(advance)begin
            valid<={valid[7:0],in_valid};
            if(in_valid)begin value0<=in_mel;fraction0<=in_fraction;index[0]<=in_index;zero[0]<=in_mel==0;end
            for(j=1;j<9;j=j+1)if(valid[j-1])begin index[j]<=index[j-1];zero[j]<=zero[j-1];end
            if(valid[0])begin
                value1<=value0;exponent1<=msb64(value0);
                bias1<=$signed({3'b0,msb64(value0)})-$signed({2'b0,fraction0});
            end
            if(valid[1])begin coordinate2<=normalized[31:0];bias2<=bias1;end
            if(valid[2])begin
                base3<=log_table[{1'b0,coordinate2[31:20]}];
                next3<=log_table[{1'b0,coordinate2[31:20]}+13'd1];
                fraction3<=coordinate2[19:0];bias3<=bias2;
            end
            if(valid[3])begin product4<=difference3[12:0]*fraction3;base4<=base3;bias4<=bias3;end
            if(valid[4])begin mix5<={base4,20'd0}+{11'd0,product4};bias5<=bias4;end
            if(valid[5])begin rounded6<=rounded_mix[31:0];exponent_term6<=bias5*32'sd11629080;end
            if(valid[6])sum7<=$signed({exponent_term6[31],exponent_term6})+$signed({1'b0,rounded6});
            if(valid[7])result8<=zero[7]||sum7<LOG_FLOOR?LOG_FLOOR:sum7[31:0];
        end
    end
endmodule
