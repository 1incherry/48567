`timescale 1ns/1ps
// Fixed NAR2 big-endian256B body from the actual private audio bank.
// The caller uses the SAME270B Ethernet envelope (EtherType88b6) as NTR2.
// No claim of Ethernet link cryptographic authentication is made.
module trusted_audio_report_body(
 input wire [31:0] report_sequence,input wire [287:0] result_context,
 input wire [3:0] result_class,input wire [383:0] result_logits,
 output reg [2047:0] body
);
 integer i;
 always @*begin
  body=0;
  body[2047-0*8-:32]=32'h4e415232;
  body[2047-4*8-:32]=32'h00020002;
  body[2047-8*8-:32]=report_sequence;
  body[2047-12*8-:32]=result_context[223:192];
  body[2047-16*8-:32]=result_context[191:160];
  body[2047-20*8-:32]=result_context[159:128];
  body[2047-24*8-:32]=result_context[255:224];
  body[2047-28*8-:32]=result_context[287:256];
  body[2047-32*8-:128]=result_context[127:0];
  body[2047-48*8-:32]={28'd0,result_class};
  body[2047-52*8-:32]=32'd12;
  body[2047-56*8-:32]=32'd16000;
  body[2047-60*8-:32]=32'd3920;
  for(i=0;i<12;i=i+1)body[2047-(64+i*4)*8-:32]=result_logits[i*32+:32];
 end
endmodule
