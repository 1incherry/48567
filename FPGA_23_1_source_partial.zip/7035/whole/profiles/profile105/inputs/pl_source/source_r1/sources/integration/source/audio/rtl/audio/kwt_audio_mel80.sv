`timescale 1ns/1ps
// Frozen sparse244x80 Mel matrix:477 nonzero Q30 coefficients.
// Capture one magnitude frame, then compute one band at a time with a
// registered RAM/ROM/multiply/accumulate path. No learned weights change.
module kwt_audio_mel80 #(
    parameter COEFFICIENT_FILE="model/audio_mel_sparse_q30.hex",
    parameter OFFSETS_FILE="model/audio_mel_offsets.hex"
)(
    input wire clk,rst_n,clear,start,in_valid,
    output wire in_ready,
    input wire [31:0] in_magnitude,
    input wire [8:0] in_index,
    input wire [5:0] in_fraction,
    output wire out_valid,
    input wire out_ready,
    output wire [63:0] out_mel,
    output wire [6:0] out_index,out_fraction,
    output wire busy,
    output reg done,error
);
    localparam IDLE=0,LOAD=1,INIT_BAND=2,COEFF=3,MAG_READ=4,MAG_WAIT=5,MULTIPLY=6,ACCUMULATE=7,HOLD=8;
    reg [3:0] state;
    reg [7:0] load_index;
    reg [6:0] band;
    reg [5:0] magnitude_fraction;
    reg [8:0] tap,end_tap;
    reg [63:0] entry,product,accumulator;
    reg [31:0] magnitude;
    reg [63:0] coefficients[0:476];
    reg [8:0] offsets[0:80];
    initial begin $readmemh(COEFFICIENT_FILE,coefficients);$readmemh(OFFSETS_FILE,offsets);end
    wire live=rst_n&&!clear;
    assign in_ready=live&&state==LOAD;
    assign out_valid=live&&state==HOLD;
    assign out_mel=accumulator;assign out_index=band;
    assign out_fraction={1'b0,magnitude_fraction}+7'd30;
    assign busy=state!=IDLE;
    wire loading=in_ready&&in_valid;
    wire reading=live&&state==MAG_READ;
    wire [31:0] memory_q;
    wire [64:0] sum={1'b0,accumulator}+{1'b0,product};
    kwt_audio_scratch_ram #(.WIDTH(32),.DEPTH(256),.ADDR_W(8)) magnitude_ram(
        .clk(clk),.a_en(loading||reading),.a_we(loading),
        .a_addr(loading?load_index:entry[38:31]),.a_data(in_magnitude),.a_strobe(4'hf),.a_q(memory_q),
        .b_en(1'b0),.b_we(1'b0),.b_addr(8'd0),.b_data(32'd0),.b_q());
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            state<=IDLE;load_index<=0;band<=0;magnitude_fraction<=0;tap<=0;end_tap<=0;
            entry<=0;product<=0;accumulator<=0;magnitude<=0;done<=0;error<=0;
        end else begin
            done<=0;
            case(state)
                IDLE:if(start)begin state<=LOAD;load_index<=0;band<=0;error<=0;end
                LOAD:if(in_valid)begin
                    if(in_index!={1'b0,load_index})error<=1;
                    if(load_index==0)magnitude_fraction<=in_fraction;
                    else if(in_fraction!=magnitude_fraction)error<=1;
                    if(load_index==243)state<=INIT_BAND;
                    else load_index<=load_index+1'b1;
                end
                INIT_BAND:begin tap<=offsets[band];end_tap<=offsets[band+1'b1];accumulator<=0;state<=COEFF;end
                COEFF:begin entry<=coefficients[tap];state<=MAG_READ;end
                MAG_READ:state<=MAG_WAIT;
                MAG_WAIT:begin magnitude<=memory_q;state<=MULTIPLY;end
                MULTIPLY:begin product<=magnitude*entry[30:0];state<=ACCUMULATE;end
                ACCUMULATE:begin
                    accumulator<=sum[63:0];if(sum[64])error<=1;
                    if(tap+1'b1==end_tap)state<=HOLD;
                    else begin tap<=tap+1'b1;state<=COEFF;end
                end
                HOLD:if(out_ready)begin
                    if(band==79)begin state<=IDLE;done<=1;end
                    else begin band<=band+1'b1;state<=INIT_BAND;end
                end
                default:state<=IDLE;
            endcase
        end
    end
endmodule
