`timescale 1ns/1ps
// Complete operator set for KWT-1. Commands come from E203/host; all numerical
// operations execute in RTL. Memory addresses are 32-bit WORD indices in a
// 512KiB shared RAM. Both read ports are synchronous one-cycle ports, B also
// writes. No golden activations enter the engine after initial input loading.
module kwt_encoder_scalar #(
    parameter EXP_FILE="kwt_exp.hex", GELU_FILE="kwt_gelu.hex",
    parameter ENABLE_MATRIX=1,ENABLE_GELU=1
) (
    input wire clk,rst_n,clear,start,
    input wire [3:0] opcode,
    input wire [16:0] source_a,source_b,destination,bias_base,
    input wire [7:0] rows,
    input wire [8:0] columns,inner,
    input wire signed [7:0] shift_a,shift_b,
    input wire [5:0] output_bits,
    input wire has_bias,transpose_b,
    input wire [5:0] input_fraction,
    input wire [63:0] epsilon,
    output reg busy,done,fault,
    output reg [31:0] cycles,
    output reg a_enable,b_enable,b_write,
    output reg [16:0] a_address,b_address,
    output reg [31:0] b_write_data,
    input wire signed [31:0] a_read_data,b_read_data
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
`ifdef KWT_CONST_ROM
    `include "source_r1/sources/integration/source/audio/rtl/kwt_nonlinear_constants.vh"
`endif
    localparam MAT=1,ADD=2,GELU=3,SOFTMAX=4,LN=5;
    localparam [5:0] IDLE=6'd0,M_READ=6'd1,M_PRODUCT=6'd2,M_ACC=6'd3,M_BIAS=6'd4,M_FINAL=6'd5,WRITE=6'd6,
        A_READ=6'd7,A_VALUE=6'd8,G_READ=6'd9,G_VALUE=6'd10,ROM_READ=6'd11,ROM_VALUE=6'd12,
        S_MAX_READ=6'd13,S_MAX_VALUE=6'd14,S_EXP_READ=6'd15,S_EXP_VALUE=6'd16,S_EXP_STORE=6'd17,
        S_DIV_READ=6'd18,S_DIV_VALUE=6'd19,DIV_WAIT=6'd20,L_SUM_READ=6'd21,L_SUM_VALUE=6'd22,
        L_VAR_READ=6'd23,L_VAR_VALUE=6'd24,L_VAR_SQUARE=6'd25,L_VAR_ACC=6'd26,SQRT_WAIT=6'd27,
        L_NORM_READ=6'd28,L_NORM_VALUE=6'd29,L_NORM_PRODUCT=6'd30,L_BIAS_READ=6'd31,L_DIV_START=6'd32,
        ROM_SUM=6'd33,ROM_ROUND=6'd34,ROM_SCALE=6'd35,RESULT_SAT=6'd36,A_SUM=6'd37,M_ADD=6'd38,
        G_COORD=6'd39,S_COORD=6'd40,L_MEAN=6'd41,L_VAR_MEAN=6'd42,L_SQRT_START=6'd43,READ_CAPTURE=6'd44,
        S_RECIP_START=6'd45,S_RECIP_WAIT=6'd46,S_PROB_PRODUCT=6'd47,S_PROB_QUOTIENT=6'd48,
        S_PROB_QD=6'd49,S_PROB_SUB=6'd50,S_PROB_CORRECT=6'd51,S_PROB_ROUND=6'd52,
        VALIDATE_SIZES=6'd53,VALIDATE_ENDS=6'd54,VALIDATE_CHECK=6'd55,ROM_MULTIPLY=6'd56;
    reg [5:0] state;
    reg fields_invalid;
    reg [17:0] size_a,size_b,size_out,end_a,end_b,end_out,end_bias;
    reg [3:0] op;
    reg [16:0] sa,sb,dst,bb;
    reg [7:0] m;
    reg [8:0] n,k;
    reg signed [7:0] sha,shb;
    reg [5:0] outbits,xf;
    reg hb,tb;
    reg [63:0] eps;
    reg [31:0] row,col,term,element;
    reg [16:0] pointer_a,pointer_b,pointer_bias,pointer_out,pointer_exp,source_row,destination_row,total_elements;
    reg signed [63:0] accumulator,product,sum,mean;
    reg signed [24:0] centered;
    reg signed [23:0] gamma_value;
    reg [31:0] pending;
    (* dont_touch="true" *) reg [31:0] coordinate;
    reg signed [31:0] row_max,beta;
    reg [63:0] denominator_value;
    reg [31:0] stddev;
    reg [33:0] reciprocal;
    reg [30:0] prob_exponent;
    reg [53:0] prob_numerator;
    reg [64:0] prob_product;
    reg [24:0] prob_quotient;
    reg [63:0] prob_qd,prob_remainder;
    reg signed [64:0] prob_delta;
    reg [16:0] a_line_start,b_column_start,a_next,b_next;
    reg m_response_pending,m_response_first,m_response_last;
    reg m_response2_pending,m_response2_first,m_response2_last;
    reg signed [31:0] a_buffer,b_buffer;
    reg [5:0] read_return;
    wire mac_in_ready,mac_out_valid;
    wire signed [47:0] mac_out_data;
    wire mac_issue=busy&&(state==M_READ)&&!clear&&(term<k)&&mac_in_ready;
    wire mac_clear=clear||start||(busy&&state==WRITE&&op==MAT);
    // Every matrix B operand in the selected KWT profile is signed16:
    // kernels, projected K or projected V. A can be signed16/signed24.
    // A 48-bit accumulator safely covers 256 full-range24x16 products.
    generate if(ENABLE_MATRIX)begin: matrix_enabled
    kwt_dot_product #(.DATA_A_W(24),.DATA_B_W(16),.ACC_W(48)) matrix_mac(
        .clk(clk),.rst_n(rst_n),.clear(mac_clear),.in_valid(m_response2_pending),.in_ready(mac_in_ready),
        .in_first(m_response2_first),.in_last(m_response2_last),.in_a(a_buffer[23:0]),.in_b(b_buffer[15:0]),
        .out_valid(mac_out_valid),.out_ready(state==M_PRODUCT),.out_data(mac_out_data));
    end else begin: matrix_disabled
        assign mac_in_ready=1'b1;assign mac_out_valid=1'b0;assign mac_out_data=48'sd0;
    end endgenerate
    reg [16:0] coefficient0,coefficient1;
    reg signed [49:0] mix_product0,mix_product1;
    reg signed [50:0] mix_sum;
    reg signed [31:0] lut_value;
    reg signed [63:0] result_value,scaled_a,scaled_b,coordinate_input,variance_mean;
    reg signed [63:0] gelu_boundary;
    reg signed [7:0] gelu_tail_shift;
    reg signed [31:0] lut0,lut1;
    reg signed [31:0] lut_operand0,lut_operand1;
`ifndef KWT_CONST_ROM
    (* ram_style="block" *) reg signed [31:0] exp_lut[0:6144];
    (* ram_style="block" *) reg signed [31:0] gelu_lut[0:2048];
    initial begin $readmemh(EXP_FILE,exp_lut);$readmemh(GELU_FILE,gelu_lut);end
`endif
    always @(posedge clk) if(state==ROM_READ) begin
`ifdef KWT_CONST_ROM
        if(op==SOFTMAX) begin lut0<=kwt_exp_constant(coordinate[28:16]);lut1<=kwt_exp_constant(coordinate[28:16]+13'd1);end
        else if(ENABLE_GELU)begin lut0<=kwt_gelu_constant({1'b0,coordinate[26:16]});lut1<=kwt_gelu_constant({1'b0,coordinate[26:16]}+12'd1);end
        else begin lut0<=0;lut1<=0;end
`else
        if(op==SOFTMAX) begin lut0<=exp_lut[coordinate[28:16]];lut1<=exp_lut[coordinate[28:16]+1];end
        else if(ENABLE_GELU)begin lut0<=gelu_lut[coordinate[26:16]];lut1<=gelu_lut[coordinate[26:16]+1];end
        else begin lut0<=0;lut1<=0;end
`endif
    end
    wire signed [63:0] ax=$signed({{32{a_buffer[31]}},a_buffer});
    wire signed [63:0] bx=$signed({{32{b_buffer[31]}},b_buffer});
    wire [63:0] coordinate_input_bits=$unsigned(coordinate_input);
    wire [31:0] a_buffer_bits=$unsigned(a_buffer),b_buffer_bits=$unsigned(b_buffer);
    // Frozen model: score fractions18/19/20; GELU input fraction12. All
    // coordinates are exact left shifts, so no variable 64-bit rounding
    // hardware is needed here. Command validation enforces this contract.
    wire [31:0] soft_coordinate=(sha==-7) ? {1'b0,coordinate_input_bits[23:0],7'b0} :
                               (sha==-6) ? {2'b0,coordinate_input_bits[23:0],6'b0} :
                               (sha==-5) ? {3'b0,coordinate_input_bits[23:0],5'b0} :
                                           {4'b0,coordinate_input_bits[23:0],4'b0};
    wire signed [63:0] rounded_lut=kwt_round64($signed({{13{mix_sum[50]}},mix_sum}),16);
    wire [63:0] rounded_lut_bits=$unsigned(rounded_lut);
    reg div_start,sqrt_start;
    reg signed [63:0] div_numerator;
    reg [63:0] div_denominator,sqrt_input;
    wire div_busy,div_valid,div_error,sqrt_busy,sqrt_valid;
    wire signed [63:0] div_result;
    wire [31:0] sqrt_result;
    wire math_clear=clear||start;
    kwt_divide64 divider(.clk(clk),.rst_n(rst_n),.clear(math_clear),.start(div_start),
        .numerator(div_numerator),.denominator(div_denominator),.busy(div_busy),.valid(div_valid),.error(div_error),.result(div_result));
    kwt_sqrt64 square_root(.clk(clk),.rst_n(rst_n),.clear(math_clear),.start(sqrt_start),
        .radicand(sqrt_input),.busy(sqrt_busy),.valid(sqrt_valid),.result(sqrt_result));
    always @* begin
        a_enable=0;b_enable=0;b_write=0;a_address=0;b_address=0;b_write_data=pending;
        if(busy&&!clear) case(state)
            M_READ:begin a_enable=mac_issue;b_enable=mac_issue;a_address=a_next;b_address=b_next;end
            M_BIAS:begin a_enable=hb;a_address=pointer_bias;end
            A_READ:begin a_enable=1;b_enable=1;a_address=pointer_a;b_address=pointer_b;end
            G_READ:begin a_enable=1;a_address=pointer_a;end
            S_MAX_READ,S_EXP_READ:begin a_enable=1;a_address=pointer_a;end
            S_EXP_STORE:begin b_enable=1;b_write=1;b_address=pointer_exp;end
            S_DIV_READ:begin a_enable=1;a_address=pointer_a;end
            L_SUM_READ,L_VAR_READ:begin a_enable=1;a_address=pointer_a;end
            L_NORM_READ:begin a_enable=1;b_enable=1;a_address=pointer_a;b_address=pointer_b;end
            L_BIAS_READ:begin a_enable=1;a_address=pointer_bias;end
            WRITE:begin b_enable=1;b_write=1;b_address=pointer_out;end
            default:begin end
        endcase
    end
    always @(posedge clk) begin
        if(!rst_n||clear) begin
            busy<=0;done<=0;fault<=0;cycles<=0;state<=IDLE;op<=0;
            fields_invalid<=0;size_a<=0;size_b<=0;size_out<=0;end_a<=0;end_b<=0;end_out<=0;end_bias<=0;
            row<=0;col<=0;term<=0;element<=0;accumulator<=0;product<=0;sum<=0;mean<=0;
            pointer_a<=0;pointer_b<=0;pointer_bias<=0;pointer_out<=0;pointer_exp<=0;source_row<=0;destination_row<=0;total_elements<=0;
            pending<=0;coordinate<=0;row_max<=32'sh80000000;beta<=0;stddev<=0;
            denominator_value<=0;centered<=0;gamma_value<=0;
            reciprocal<=0;prob_exponent<=0;prob_numerator<=0;prob_product<=0;
            prob_quotient<=0;prob_qd<=0;prob_remainder<=0;prob_delta<=0;
            a_line_start<=0;b_column_start<=0;a_next<=0;b_next<=0;
            m_response_pending<=0;m_response_first<=0;m_response_last<=0;
            m_response2_pending<=0;m_response2_first<=0;m_response2_last<=0;a_buffer<=0;b_buffer<=0;read_return<=0;
            coefficient0<=0;coefficient1<=0;mix_product0<=0;mix_product1<=0;mix_sum<=0;lut_value<=0;
            lut_operand0<=0;lut_operand1<=0;
            result_value<=0;scaled_a<=0;scaled_b<=0;coordinate_input<=0;variance_mean<=0;gelu_boundary<=0;gelu_tail_shift<=0;
            div_start<=0;sqrt_start<=0;div_numerator<=0;div_denominator<=1;sqrt_input<=0;
            sa<=0;sb<=0;dst<=0;bb<=0;m<=0;n<=0;k<=0;sha<=0;shb<=0;outbits<=0;xf<=0;hb<=0;tb<=0;eps<=0;
        end else begin
            div_start<=0;sqrt_start<=0;
            if(start&&!busy) begin
                op<=opcode;sa<=source_a;sb<=source_b;dst<=destination;bb<=bias_base;
                m<=rows;n<=columns;k<=inner;sha<=shift_a;shb<=shift_b;
                outbits<=output_bits;xf<=input_fraction;hb<=has_bias;tb<=transpose_b;eps<=epsilon;
                busy<=1;done<=0;fault<=0;cycles<=0;row<=0;col<=0;term<=0;element<=0;
                accumulator<=0;sum<=0;row_max<=32'sh80000000;
                pointer_a<=source_a;pointer_b<=source_b;pointer_bias<=bias_base;pointer_out<=destination;pointer_exp<=destination;
                source_row<=source_a;destination_row<=destination;total_elements<=0;
                a_line_start<=source_a;b_column_start<=source_b;a_next<=source_a;b_next<=source_b;
                m_response_pending<=0;m_response_first<=0;m_response_last<=0;
                m_response2_pending<=0;m_response2_first<=0;m_response2_last<=0;
                gelu_boundary<=64'sd8<<<input_fraction;
                gelu_tail_shift<=$signed(shift_a)+$signed(shift_b)-1;
                // Separate descriptor capture, size multiplication, address
                // addition and validation. Command entry is not a long path
                // from widely spread AXI config registers to the FSM reset.
                state<=VALIDATE_SIZES;
            end else if(busy) begin
                cycles<=cycles+1;
                if(mac_in_ready) begin
                    m_response_pending<=mac_issue;
                    m_response2_pending<=m_response_pending;
                    m_response2_first<=m_response_first;m_response2_last<=m_response_last;
                    if(m_response_pending) begin a_buffer<=a_read_data;b_buffer<=b_read_data;end
                end
                if(mac_issue) begin
                    m_response_first<=term==0;m_response_last<=term==k-1;
                    term<=term+1;a_next<=a_next+1;b_next<=b_next+(tb?1:n);
                end
                case(state)
                    VALIDATE_SIZES:begin
                        size_a<=m*((ENABLE_MATRIX&&op==MAT)?k:n);size_out<=m*n;
                        size_b<=ENABLE_MATRIX?k*n:18'd0;
                        fields_invalid<=m==0||n==0||n>256||k>256||
                          (outbits!=16&&outbits!=24)||sha < -40||sha>60||shb < -40||shb>60||
                          (!ENABLE_MATRIX&&op==MAT)||(!ENABLE_GELU&&op==GELU)||
                          (op==MAT&&k==0)||(op==LN&&(n!=64||eps==0||(sha!=2&&sha!=3)||outbits!=24))||
                          (op==GELU&&(xf!=12||sha!=-11||(shb!=3&&shb!=4)||outbits!=24))||
                          (op==SOFTMAX&&((sha!=-7&&sha!=-6&&sha!=-5&&sha!=-4)||outbits!=24))||op<1||op>5;
                        state<=VALIDATE_ENDS;
                    end
                    VALIDATE_ENDS:begin
                        total_elements<=size_out[16:0];
                        end_a<={1'b0,sa}+size_a;end_out<={1'b0,dst}+size_out;
                        end_b<={1'b0,sb}+(op==LN?18'd64:(op==ADD?size_out:size_b));
                        end_bias<={1'b0,bb}+18'd64;state<=VALIDATE_CHECK;
                    end
                    VALIDATE_CHECK:begin
                        if(fields_invalid||end_a>131072||end_out>131072||
                          ((op==MAT||op==ADD||op==LN)&&end_b>131072)||
                          (op==LN&&end_bias>131072))begin busy<=0;done<=1;fault<=1;state<=IDLE;end
                        else case(op)
                            MAT:state<=M_READ;ADD:state<=A_READ;GELU:state<=G_READ;
                            SOFTMAX:state<=S_MAX_READ;LN:state<=L_SUM_READ;
                        endcase
                    end
                    M_READ:if(m_response2_pending&&mac_in_ready&&m_response2_last) state<=M_PRODUCT;
                    M_PRODUCT:if(mac_out_valid) begin accumulator<=$signed({{16{mac_out_data[47]}},mac_out_data});state<=M_BIAS;end
                    M_BIAS:begin read_return<=M_FINAL;state<=READ_CAPTURE;end
                    M_FINAL:begin result_value<=kwt_round64(accumulator,sha);beta<=hb?a_buffer:32'sd0;state<=M_ADD;end
                    M_ADD:begin result_value<=result_value+$signed({{32{beta[31]}},beta});state<=RESULT_SAT;end
                    A_READ:begin read_return<=A_VALUE;state<=READ_CAPTURE;end
                    A_VALUE:begin scaled_a<=kwt_round64(ax,sha);scaled_b<=kwt_round64(bx,shb);state<=A_SUM;end
                    A_SUM:begin result_value<=scaled_a+scaled_b;state<=RESULT_SAT;end
                    RESULT_SAT:begin pending<=$unsigned(kwt_sat32(result_value,$signed({26'd0,outbits})));state<=WRITE;end
                    G_READ:begin read_return<=G_VALUE;state<=READ_CAPTURE;end
                    G_VALUE:begin
                        if(ax>=gelu_boundary) begin result_value<=shb==3 ? (ax<<<9) : (ax<<<8);state<=RESULT_SAT;end
                        else if(ax<=-gelu_boundary) begin pending<=0;state<=WRITE;end
                        else begin coordinate_input<=ax+gelu_boundary;state<=G_COORD;end
                    end
                    G_COORD:begin coordinate<={5'b0,coordinate_input_bits[15:0],11'b0};state<=ROM_READ;end
                    ROM_READ:begin coefficient0<=17'd65536-{1'b0,coordinate[15:0]};coefficient1<={1'b0,coordinate[15:0]};state<=ROM_VALUE;end
                    ROM_VALUE:begin
                        // Separate synchronous ROM output delay from the
                        // wide DSP multiply cascade; coefficients are held.
                        lut_operand0<=lut0;lut_operand1<=lut1;state<=ROM_MULTIPLY;
                    end
                    ROM_MULTIPLY:begin
                        mix_product0<=lut_operand0*$signed({1'b0,coefficient0});
                        mix_product1<=lut_operand1*$signed({1'b0,coefficient1});state<=ROM_SUM;
                    end
                    ROM_SUM:begin mix_sum<=$signed(mix_product0)+$signed(mix_product1);state<=ROM_ROUND;end
                    ROM_ROUND:begin
                        if(op==SOFTMAX) begin pending<=rounded_lut_bits[31:0];state<=S_EXP_STORE;end
                        else begin lut_value<=$signed(rounded_lut_bits[31:0]);state<=ROM_SCALE;end
                    end
                    ROM_SCALE:begin
                        result_value<=shb==3 ? kwt_round64($signed({{32{lut_value[31]}},lut_value}),3) : kwt_round64($signed({{32{lut_value[31]}},lut_value}),4);
                        state<=RESULT_SAT;
                    end
                    S_MAX_READ:begin read_return<=S_MAX_VALUE;state<=READ_CAPTURE;end
                    S_MAX_VALUE:begin
                        if(a_buffer>row_max) row_max<=a_buffer;
                        if(col==n-1) begin col<=0;sum<=0;pointer_a<=source_row;state<=S_EXP_READ;end
                        else begin col<=col+1;pointer_a<=pointer_a+1;state<=S_MAX_READ;end
                    end
                    S_EXP_READ:begin read_return<=S_EXP_VALUE;state<=READ_CAPTURE;end
                    S_EXP_VALUE:begin coordinate_input<=$signed(row_max)-ax;state<=S_COORD;end
                    S_COORD:begin
                        if(soft_coordinate>=32'd402653184) begin pending<=0;state<=S_EXP_STORE;end
                        else begin coordinate<=soft_coordinate;state<=ROM_READ;end
                    end
                    S_EXP_STORE:begin
                        sum<=sum+$signed({1'b0,pending});
                        pointer_exp<=pointer_exp+1;
                        if(col==n-1) begin denominator_value<=$unsigned(sum)+pending;col<=0;pointer_a<=destination_row;state<=S_RECIP_START;end
                        else begin col<=col+1;pointer_a<=pointer_a+1;state<=S_EXP_READ;end
                    end
                    S_DIV_READ:begin read_return<=S_DIV_VALUE;state<=READ_CAPTURE;end
                    // One rounded reciprocal per row, then pipelined exact
                    // quotient correction for each value. D is in [2^30,2^38]
                    // and N<=2^53. R=round(2^63/D) approximates floor(N/D) to
                    // within one integer; +/-one correction restores exact
                    // division, including nearest-even and signed24 clamp.
                    S_RECIP_START:begin
                        div_numerator<=64'sh8000000000000000;
                        div_denominator<=denominator_value;div_start<=1;state<=S_RECIP_WAIT;
                    end
                    S_RECIP_WAIT:if(div_valid)begin
                        if(div_error)begin busy<=0;done<=1;fault<=1;state<=IDLE;end
                        else begin reciprocal<=$unsigned(-$signed(div_result));state<=S_DIV_READ;end
                    end
                    S_DIV_VALUE:begin
                        prob_exponent<=a_buffer_bits[30:0];prob_numerator<={a_buffer_bits[30:0],23'd0};state<=S_PROB_PRODUCT;
                    end
                    S_PROB_PRODUCT:begin prob_product<=prob_exponent*reciprocal;state<=S_PROB_QUOTIENT;end
                    S_PROB_QUOTIENT:begin prob_quotient<=prob_product[64:40];state<=S_PROB_QD;end
                    S_PROB_QD:begin prob_qd<=prob_quotient*denominator_value[38:0];state<=S_PROB_SUB;end
                    S_PROB_SUB:begin
                        prob_delta<=$signed({11'd0,prob_numerator})-$signed({1'b0,prob_qd});state<=S_PROB_CORRECT;
                    end
                    S_PROB_CORRECT:begin
                        if(prob_delta<0)begin prob_quotient<=prob_quotient-1;prob_remainder<=$unsigned(prob_delta)+denominator_value;end
                        else if(prob_delta>=$signed({1'b0,denominator_value}))begin
                            prob_quotient<=prob_quotient+1;prob_remainder<=$unsigned(prob_delta)-denominator_value;
                        end else prob_remainder<=$unsigned(prob_delta);
                        state<=S_PROB_ROUND;
                    end
                    S_PROB_ROUND:begin
                        result_value<=$signed({39'd0,prob_quotient}+((prob_remainder>denominator_value-prob_remainder)||
                          ((prob_remainder==denominator_value-prob_remainder)&&prob_quotient[0])));
                        state<=RESULT_SAT;
                    end
                    L_SUM_READ:begin read_return<=L_SUM_VALUE;state<=READ_CAPTURE;end
                    L_SUM_VALUE:begin
                        sum<=sum+ax;
                        if(col==63) state<=L_MEAN;
                        else begin col<=col+1;pointer_a<=pointer_a+1;state<=L_SUM_READ;end
                    end
                    L_MEAN:begin mean<=kwt_round64(sum,6);sum<=0;col<=0;pointer_a<=source_row;state<=L_VAR_READ;end
                    L_VAR_READ:begin read_return<=L_VAR_VALUE;state<=READ_CAPTURE;end
                    L_VAR_VALUE:begin centered<=ax-mean;state<=L_VAR_SQUARE;end
                    L_VAR_SQUARE:begin product<=centered*centered;state<=L_VAR_ACC;end
                    L_VAR_ACC:begin
                        sum<=sum+product;
                        if(col==63) state<=L_VAR_MEAN;
                        else begin col<=col+1;pointer_a<=pointer_a+1;state<=L_VAR_READ;end
                    end
                    L_VAR_MEAN:begin variance_mean<=kwt_round64(sum,6);state<=L_SQRT_START;end
                    L_SQRT_START:begin sqrt_input<=$unsigned(variance_mean)+eps;sqrt_start<=1;state<=SQRT_WAIT;end
                    SQRT_WAIT:if(sqrt_valid) begin stddev<=sqrt_result;col<=0;pointer_a<=source_row;pointer_b<=sb;pointer_bias<=bb;state<=L_NORM_READ;end
                    L_NORM_READ:begin read_return<=L_NORM_VALUE;state<=READ_CAPTURE;end
                    L_NORM_VALUE:begin centered<=ax-mean;gamma_value<=$signed(b_buffer_bits[23:0]);state<=L_NORM_PRODUCT;end
                    L_NORM_PRODUCT:begin product<=centered*gamma_value;state<=L_BIAS_READ;end
                    L_BIAS_READ:begin read_return<=L_DIV_START;state<=READ_CAPTURE;end
                    L_DIV_START:begin
                        beta<=a_buffer;
                        div_numerator<=product;
                        div_denominator<=sha==3?{29'b0,stddev,3'b0}:{30'b0,stddev,2'b0};
                        div_start<=1;state<=DIV_WAIT;
                    end
                    DIV_WAIT:if(div_valid) begin
                        if(div_error) begin busy<=0;done<=1;fault<=1;state<=IDLE;end
                        else begin result_value<=div_result+(op==LN?$signed({{32{beta[31]}},beta}):64'sd0);state<=RESULT_SAT;end
                    end
                    READ_CAPTURE:begin a_buffer<=a_read_data;b_buffer<=b_read_data;state<=read_return;end
                    WRITE:begin
                        element<=element+1;
                        pointer_out<=pointer_out+1;
                        if(element==total_elements-1) begin busy<=0;done<=1;state<=IDLE;end
                        else case(op)
                            MAT:begin
                                accumulator<=0;term<=0;m_response_pending<=0;m_response2_pending<=0;
                                if(col==n-1) begin
                                    col<=0;row<=row+1;a_line_start<=a_line_start+k;a_next<=a_line_start+k;
                                    b_column_start<=sb;b_next<=sb;pointer_bias<=bb;
                                end else begin
                                    col<=col+1;a_next<=a_line_start;b_column_start<=b_column_start+(tb?k:1);
                                    b_next<=b_column_start+(tb?k:1);
                                    pointer_bias<=pointer_bias+1;
                                end
                                state<=M_READ;
                            end
                            ADD:begin pointer_a<=pointer_a+1;pointer_b<=pointer_b+1;state<=A_READ;end
                            GELU:begin pointer_a<=pointer_a+1;state<=G_READ;end
                            SOFTMAX:begin
                                if(col==n-1) begin
                                    col<=0;row<=row+1;row_max<=32'sh80000000;
                                    source_row<=source_row+n;destination_row<=destination_row+n;
                                    pointer_a<=source_row+n;pointer_exp<=destination_row+n;state<=S_MAX_READ;
                                end else begin col<=col+1;pointer_a<=pointer_a+1;state<=S_DIV_READ;end
                            end
                            LN:begin
                                if(col==63) begin col<=0;row<=row+1;sum<=0;source_row<=source_row+64;pointer_a<=source_row+64;state<=L_SUM_READ;end
                                else begin col<=col+1;pointer_a<=pointer_a+1;pointer_b<=pointer_b+1;pointer_bias<=pointer_bias+1;state<=L_NORM_READ;end
                            end
                        endcase
                    end
                    default:begin busy<=0;done<=1;fault<=1;state<=IDLE;end
                endcase
            end
        end
    end
endmodule
