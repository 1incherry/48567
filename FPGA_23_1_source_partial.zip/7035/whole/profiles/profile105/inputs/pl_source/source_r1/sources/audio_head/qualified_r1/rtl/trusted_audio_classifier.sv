`timescale 1ns/1ps
// Actual original KWT head order: each class starts at +0, then 64 separately
// rounded products/adds, then bias, strict > argmax (earliest class on ties).
// The parent connects ONLY its authenticated static-word reader and actual
// sealed final CLS stream. There are no PS ports or software label inputs.
module trusted_audio_classifier_stream # (
 parameter integer FRACTION=20, parameter integer CLASSES=105,
 parameter integer CLASS_BITS=(CLASSES<2?1:$clog2(CLASSES))
)(
 input wire clk,security_reset_n,authorized,cancel,trusted_clear_fault,
 input wire [31:0] model_epoch,runtime_epoch,source_id,clip_id,generation,
 input wire [127:0] key_session_id,
 input wire start,output wire start_ready,
 input wire cls_valid,output wire cls_ready,input wire [5:0] cls_index,
 input wire [31:0] cls_data,input wire cls_last,
 output wire request_valid,input wire request_ready,output wire [8:0] request_object,
 output wire [31:0] request_word_index,
 input wire response_valid,output wire response_ready,input wire response_error,
 input wire [8:0] response_object,input wire [31:0] response_word_index,response_data,
 input wire [31:0] response_model_epoch,response_runtime_epoch,response_source_id,response_clip_id,response_generation,
 input wire [127:0] response_key_session_id,
 output wire busy,quiescent,result_visible,output wire done,output reg fault,
 output wire [CLASS_BITS-1:0] result_class,output wire [31:0] result_score,
 output wire logit_valid,input wire logit_ready,
 output wire [CLASS_BITS-1:0] logit_index,output wire [31:0] logit_data,
 output wire logit_last,output wire [287:0] logit_context,
 output wire [287:0] result_context
);
 localparam IDLE=0,LOAD=1,PREPARE=2,STATIC_REQUEST=3,STATIC_RESPONSE=4,
  MUL_REQUEST=5,MUL_RESPONSE=6,ADD_REQUEST=7,ADD_RESPONSE=8,COMPARE=9,LOGIT_OFFER=10;
 reg [3:0] state;
 reg [31:0] cls_memory[0:63];
 reg [5:0] load_index,feature_index;
 reg [CLASS_BITS-1:0] class_index,winner;
 reg [31:0] activation,weight,product,sum,best;
 reg bias_phase,cancelled,present,done_reg;
 // No parallel class-count-wide bus or register. Downstream local RAM stores the stream.
 reg [287:0] captured_context;
 wire [287:0] live_context={model_epoch,runtime_epoch,source_id,clip_id,generation,key_session_id};
 wire [287:0] response_context={response_model_epoch,response_runtime_epoch,response_source_id,response_clip_id,response_generation,response_key_session_id};
 wire context_ok=authorized&&!cancel&&live_context==captured_context&&!cancelled;
 wire new_context_ok=authorized&&!cancel&&model_epoch!=0&&runtime_epoch!=0&&clip_id!=0&&generation!=0&&key_session_id!=0;
 wire fp_ready,fp_valid,fp_quiet;
 wire [31:0] fp_data;wire [4:0] fp_flags;
 wire fp_issue=context_ok&&(state==MUL_REQUEST||state==ADD_REQUEST);
 wire fp_accept=state==MUL_RESPONSE||state==ADD_RESPONSE;
 audio_fp32_serial arithmetic(.clk(clk),.rst_n(security_reset_n),.request_valid(fp_issue),.request_ready(fp_ready),
  .operation_add(state==ADD_REQUEST),.operand_a(state==MUL_REQUEST?activation:sum),
  .operand_b(state==MUL_REQUEST?weight:bias_phase?weight:product),
  .response_valid(fp_valid),.response_ready(fp_accept),.response_data(fp_data),.response_flags(fp_flags),.quiescent(fp_quiet));
 assign start_ready=state==IDLE&&fp_quiet&&!fault&&new_context_ok;
 assign cls_ready=state==LOAD&&context_ok&&!fault;
 assign request_valid=state==STATIC_REQUEST;
 assign request_object=bias_phase?9'd312:9'd311;
 assign request_word_index=bias_phase?class_index:feature_index*32'd1*CLASSES+class_index;
 assign response_ready=state==STATIC_RESPONSE;
 assign busy=state!=IDLE||!fp_quiet;
 assign quiescent=state==IDLE&&fp_quiet;
 assign result_visible=present&&context_ok&&!fault&&state==IDLE;
 assign done=done_reg&&result_visible;
 assign result_class=result_visible?winner:{CLASS_BITS{1'b0}};
 assign result_score=result_visible?best:32'd0;
 assign logit_valid=state==LOGIT_OFFER&&context_ok&&!fault;
 assign logit_index=class_index;
 assign logit_data=logit_valid?sum:32'd0;
 assign logit_last=class_index==CLASSES-1;
 assign logit_context=logit_valid?captured_context:288'd0;
 assign result_context=result_visible?captured_context:288'd0;
 function automatic [31:0] scaled_int24(input [31:0] value);
  reg [23:0] magnitude,significand;reg [7:0] exponent;integer leading,k;
  begin
   magnitude=value[23]?(~value[23:0]+24'd1):value[23:0];leading=0;
   for(k=0;k<24;k=k+1)if(magnitude[k])leading=k;
   significand=magnitude<<(23-leading);exponent=127+leading-FRACTION;
   scaled_int24=magnitude==0?32'd0:{value[23],exponent,significand[22:0]};
  end
 endfunction
 function automatic greater(input [31:0] a,input [31:0] b);
  begin
   if(a[30:0]==0&&b[30:0]==0)greater=0;
   else if(a[31]!=b[31])greater=!a[31];
   else greater=a[31]?a[30:0]<b[30:0]:a[30:0]>b[30:0];
  end
 endfunction
 always @(posedge clk)begin
  if(!security_reset_n)begin
   state<=IDLE;load_index<=0;feature_index<=0;class_index<=0;winner<=0;
   activation<=0;weight<=0;product<=0;sum<=0;best<=0;bias_phase<=0;
   cancelled<=0;present<=0;captured_context<=0;done_reg<=0;fault<=0;
  end else begin
   done_reg<=0;
   if(trusted_clear_fault&&quiescent)fault<=0;
   if(!context_ok)present<=0;
   if(state!=IDLE&&!context_ok)cancelled<=1;
   // A request already offered remains stable until accepted; an accepted
   // response and arithmetic operation must actually drain before idle.
   if(state!=IDLE&&!context_ok&&state!=STATIC_REQUEST&&state!=STATIC_RESPONSE&&
     state!=MUL_RESPONSE&&state!=ADD_RESPONSE)begin state<=IDLE;fault<=1;end
   else case(state)
    IDLE:if(start&&start_ready)begin
     captured_context<=live_context;state<=LOAD;load_index<=0;feature_index<=0;class_index<=0;
     winner<=0;best<=0;sum<=0;cancelled<=0;present<=0;bias_phase<=0;
    end
    LOAD:if(cls_valid&&cls_ready)begin
     if(cls_index!=load_index||cls_last!=(load_index==63)||cls_data[31:24]!={8{cls_data[23]}})begin fault<=1;state<=IDLE;end
     else begin cls_memory[load_index]<=cls_data;if(load_index==63)state<=PREPARE;else load_index<=load_index+1'b1;end
    end
    PREPARE:begin activation<=scaled_int24(cls_memory[feature_index]);state<=STATIC_REQUEST;end
    STATIC_REQUEST:if(request_ready)state<=STATIC_RESPONSE;
    STATIC_RESPONSE:if(response_valid)begin
     if(!context_ok||response_error||response_object!=request_object||response_word_index!=request_word_index||
       response_context!=captured_context||response_data[30:23]==8'hff)begin fault<=1;state<=IDLE;end
     else begin weight<=response_data;state<=bias_phase?ADD_REQUEST:MUL_REQUEST;end
    end
    MUL_REQUEST:if(fp_ready)state<=MUL_RESPONSE;
    MUL_RESPONSE:if(fp_valid)begin
     if(!context_ok||(|fp_flags[4:2])||fp_data[30:23]==8'hff)begin fault<=1;state<=IDLE;end
     else begin product<=fp_data;state<=ADD_REQUEST;end
    end
    ADD_REQUEST:if(fp_ready)state<=ADD_RESPONSE;
    ADD_RESPONSE:if(fp_valid)begin
     if(!context_ok||(|fp_flags[4:2])||fp_data[30:23]==8'hff)begin fault<=1;state<=IDLE;end
     else begin
      sum<=fp_data;
      if(bias_phase)begin state<=LOGIT_OFFER;end
      else if(feature_index==63)begin bias_phase<=1;state<=STATIC_REQUEST;end
      else begin feature_index<=feature_index+1'b1;state<=PREPARE;end
     end
    end
    LOGIT_OFFER:if(logit_valid&&logit_ready)state<=COMPARE;
    COMPARE:begin
     if(class_index==0||greater(sum,best))begin winner<=class_index;best<=sum;end
     if(class_index==CLASSES-1)begin present<=1;done_reg<=1;state<=IDLE;end
     else begin class_index<=class_index+1'b1;feature_index<=0;bias_phase<=0;sum<=0;state<=PREPARE;end
    end
    default:begin fault<=1;state<=IDLE;end
   endcase
  end
 end
// synthesis translate_off
 initial begin
  if(CLASSES<1||CLASSES>128||CLASS_BITS<1||CLASS_BITS>7||2**CLASS_BITS<CLASSES)
   $fatal(1,"unsupported audio class parameter");
 end
 // synthesis translate_on
endmodule
