`timescale 1ns/1ps
// One externally framed 480-sample PCM16 window to 512 complex FFT bins.
// Frame extraction/hop160, magnitude, Mel, log and DCT are separate stages.
module kwt_audio_frame_fft #(
    parameter HANN_FILE="model/audio_hann_q30.hex",
    parameter TWIDDLE_FILE="model/audio_twiddle_q30.hex"
)(
    input wire clk,rst_n,clear,start,in_valid,
    input wire signed [15:0] in_pcm,
    output wire in_ready,out_valid,
    input wire out_ready,
    output wire signed [31:0] out_real,out_imag,
    output wire [8:0] out_index,
    output wire [5:0] out_fraction,
    output wire busy,done,overflow
);
    wire window_valid,window_ready,window_busy,window_done,window_overflow;
    wire signed [31:0] window_real;
    wire [8:0] window_index;wire [5:0] window_fraction;
    wire fft_busy,fft_overflow;
    assign busy=window_busy||fft_busy;
    assign overflow=window_overflow||fft_overflow;
    kwt_audio_window480 #(.HANN_FILE(HANN_FILE)) window_unit(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(start&&!busy),
        .in_valid(in_valid),.in_pcm(in_pcm),.in_ready(in_ready),
        .out_valid(window_valid),.out_ready(window_ready),.out_real(window_real),
        .out_index(window_index),.out_fraction(window_fraction),.busy(window_busy),
        .done(window_done),.overflow(window_overflow));
    kwt_audio_fft512 #(.TWIDDLE_FILE(TWIDDLE_FILE)) fft_unit(
        .clk(clk),.rst_n(rst_n),.clear(clear),.start(window_valid&&!fft_busy),
        .input_fraction(window_fraction),.in_valid(window_valid),.in_ready(window_ready),.in_real(window_real),
        .out_valid(out_valid),.out_ready(out_ready),.out_real(out_real),.out_imag(out_imag),
        .out_index(out_index),.out_fraction(out_fraction),.busy(fft_busy),.done(done),.overflow(fft_overflow));
endmodule
