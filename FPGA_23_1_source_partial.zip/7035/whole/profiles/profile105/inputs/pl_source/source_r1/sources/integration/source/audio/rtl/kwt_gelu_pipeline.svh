// Selected-profile GELU: one accepted SRAM input and one output per cycle
// after fill. ROM, multiply, add, rounding, scale and saturation each have
// register boundaries. Command semantics match scalar v3, including tails.
module kwt_gelu_pipeline #(parameter GELU_FILE="kwt_gelu.hex")(
    input wire clk,rst_n,clear,start,
    input wire [16:0] source,destination,
    input wire [7:0] rows,
    input wire [8:0] columns,
    input wire signed [7:0] shift_a,shift_b,
    input wire [5:0] input_fraction,output_bits,
    output reg busy,done,fault,
    output reg [31:0] cycles,
    output wire a_enable,b_enable,b_write,
    output wire [16:0] a_address,b_address,
    output wire [31:0] b_write_data,
    input wire signed [31:0] a_read_data
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
`ifdef KWT_CONST_ROM
    `include "source_r1/sources/integration/source/audio/rtl/kwt_nonlinear_constants.vh"
`endif
    reg [17:0] length,issued;
    reg [16:0] read_pointer,write_pointer;
    reg [7:0] valid,last,positive_tail,negative_tail;
    reg [16:0] addresses[0:7];
    reg signed [63:0] tail_values[0:7];
    reg [15:0] coordinate;
    reg [16:0] coefficient0,coefficient1;
    reg signed [31:0] lut0,lut1;
    // Preserve the full32x18 signed expression width through synthesis.
    // The numerical bound is narrower, but DSP mapping must see complete
    // signed products and an explicit extra carry/sign bit on the sum.
    reg signed [49:0] product0,product1;
    reg signed [50:0] sum;
    reg signed [31:0] rounded_lut,output_value;
    reg signed [63:0] scaled;
    reg scale_four;
`ifndef KWT_CONST_ROM
    (* ram_style="block" *) reg signed [31:0] gelu_rom[0:2048];
    initial $readmemh(GELU_FILE,gelu_rom);
`endif
    wire issue=busy&&!clear&&issued<length;
    assign a_enable=issue;
    assign a_address=read_pointer;
    assign b_enable=busy&&!clear&&valid[7];
    assign b_write=b_enable;
    assign b_address=addresses[7];
    assign b_write_data=$unsigned(output_value);
    wire [15:0] fraction={coordinate[4:0],11'd0};
    wire [31:0] rounded_lut_bits=$unsigned(rounded_lut);
    wire signed [63:0] wide_audio=$signed({{32{a_read_data[31]}},a_read_data});
    // Both supported shifts have a 32-bit result. Round in that signed
    // width, then explicitly extend the result for the saturation stage.
    wire signed [31:0] scale_three=(rounded_lut>>>3)+
        ((rounded_lut_bits[2]&&((|rounded_lut_bits[1:0])||rounded_lut_bits[3]))?32'sd1:32'sd0);
    wire signed [31:0] scale_four_value=(rounded_lut>>>4)+
        ((rounded_lut_bits[3]&&((|rounded_lut_bits[2:0])||rounded_lut_bits[4]))?32'sd1:32'sd0);
    integer stage;
    always @(posedge clk) begin
        if(!rst_n||clear) begin
            busy<=0;done<=0;fault<=0;cycles<=0;length<=0;issued<=0;read_pointer<=0;write_pointer<=0;
            valid<=0;last<=0;positive_tail<=0;negative_tail<=0;coordinate<=0;
            coefficient0<=0;coefficient1<=0;lut0<=0;lut1<=0;product0<=0;product1<=0;
            sum<=0;rounded_lut<=0;scaled<=0;output_value<=0;scale_four<=0;
            for(stage=0;stage<8;stage=stage+1)begin addresses[stage]<=0;tail_values[stage]<=0;end
        end else begin
            valid<={valid[6:0],issue};
            for(stage=1;stage<8;stage=stage+1)begin
                addresses[stage]<=addresses[stage-1];last[stage]<=last[stage-1];
            end
            for(stage=2;stage<8;stage=stage+1)begin
                positive_tail[stage]<=positive_tail[stage-1];negative_tail[stage]<=negative_tail[stage-1];
                tail_values[stage]<=tail_values[stage-1];
            end
            if(start&&!busy)begin
                busy<=1;done<=0;fault<=0;cycles<=0;length<=rows*columns;issued<=0;
                read_pointer<=source;write_pointer<=destination;valid<=0;last<=0;
                scale_four<=shift_b==4;
                if(rows==0||columns==0||columns>256||input_fraction!=12||shift_a!=-11||
                   (shift_b!=3&&shift_b!=4)||output_bits!=24||
                   ({1'b0,source}+rows*columns)>131072||({1'b0,destination}+rows*columns)>131072||
                   (source!=destination&&destination<({1'b0,source}+rows*columns)&&source<({1'b0,destination}+rows*columns)))begin
                    busy<=0;done<=1;fault<=1;
                end
            end else if(busy)begin
                cycles<=cycles+1;
                if(issue)begin
                    issued<=issued+1;read_pointer<=read_pointer+1;write_pointer<=write_pointer+1;
                    addresses[0]<=write_pointer;last[0]<=issued==length-1;
                end
                if(valid[0])begin
                    coordinate<=$unsigned(a_read_data+32'sd32768);
                    positive_tail[1]<=a_read_data>=32768;negative_tail[1]<=a_read_data<=-32768;
                    tail_values[1]<=scale_four?(wide_audio<<<8):(wide_audio<<<9);
                end
                if(valid[1])begin
`ifdef KWT_CONST_ROM
                    lut0<=kwt_gelu_constant({1'b0,coordinate[15:5]});lut1<=kwt_gelu_constant({1'b0,coordinate[15:5]}+12'd1);
`else
                    lut0<=gelu_rom[coordinate[15:5]];lut1<=gelu_rom[{1'b0,coordinate[15:5]}+12'd1];
`endif
                    coefficient0<=17'd65536-{1'b0,fraction};coefficient1<={1'b0,fraction};
                end
                if(valid[2])begin
                    product0<=lut0*$signed({1'b0,coefficient0});
                    product1<=lut1*$signed({1'b0,coefficient1});
                end
                if(valid[3])sum<=$signed(product0)+$signed(product1);
                if(valid[4])rounded_lut<=kwt_round64($signed({{13{sum[50]}},sum}),16);
                if(valid[5])begin
                    if(positive_tail[5])scaled<=tail_values[5];
                    else if(negative_tail[5])scaled<=0;
                    else scaled<=scale_four?$signed({{32{scale_four_value[31]}},scale_four_value}):
                                            $signed({{32{scale_three[31]}},scale_three});
                end
                if(valid[6])output_value<=kwt_sat32(scaled,24);
                if(valid[7]&&last[7])begin busy<=0;done<=1;end
            end
        end
    end
endmodule
