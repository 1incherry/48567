`timescale 1ns/1ps
// Normalized radix2 FFT butterfly. Signed32 operands and Q30 twiddles.
// Four registered stages, II1. Output writes occur four clocks after issue.
// The normalized frontend keeps outputs in signed32; overflow is explicit.
module kwt_audio_fft_butterfly(
    input wire clk,rst_n,clear,in_valid,
    input wire signed [31:0] ar,ai,br,bi,cosine,sine,
    input wire [8:0] address_a,address_b,
    input wire in_last,
    output wire out_valid,out_last,
    output wire [8:0] out_address_a,out_address_b,
    output wire signed [31:0] yr0,yi0,yr1,yi1,
    output wire overflow
);
    `include "source_r1/sources/integration/source/audio/rtl/kwt_math64.vh"
    reg [3:0] valid,last;
    reg [8:0] a0,a1,a2,a3,b0,b1,b2,b3;
    reg signed [31:0] ar0,ai0;
    reg signed [63:0] bc0,bs0,ic0,is0;
    reg signed [63:0] tr1,ti1,ar1,ai1;
    reg signed [63:0] r02,i02,r12,i12;
    reg signed [31:0] r03,i03,r13,i13;
    reg overflow3;
    wire signed [63:0] rr0=kwt_round64(r02,31),ri0=kwt_round64(i02,31);
    wire signed [63:0] rr1=kwt_round64(r12,31),ri1=kwt_round64(i12,31);
    function automatic outside32(input signed [63:0] value);
        outside32=value>64'sd2147483647||value< -64'sd2147483648;
    endfunction
    assign out_valid=valid[3]&&rst_n&&!clear;
    assign out_last=last[3]&&out_valid;
    assign out_address_a=a3;assign out_address_b=b3;
    assign yr0=r03;assign yi0=i03;assign yr1=r13;assign yi1=i13;
    assign overflow=overflow3&&out_valid;
    always @(posedge clk)begin
        if(!rst_n||clear)begin
            valid<=0;last<=0;a0<=0;a1<=0;a2<=0;a3<=0;b0<=0;b1<=0;b2<=0;b3<=0;
            ar0<=0;ai0<=0;bc0<=0;bs0<=0;ic0<=0;is0<=0;
            tr1<=0;ti1<=0;ar1<=0;ai1<=0;r02<=0;i02<=0;r12<=0;i12<=0;
            r03<=0;i03<=0;r13<=0;i13<=0;overflow3<=0;
        end else begin
            valid<={valid[2:0],in_valid};last<={last[2:0],in_valid&&in_last};
            if(in_valid)begin
                bc0<=br*cosine;bs0<=br*sine;ic0<=bi*cosine;is0<=bi*sine;
                ar0<=ar;ai0<=ai;a0<=address_a;b0<=address_b;
            end
            if(valid[0])begin
                tr1<=bc0+is0;ti1<=ic0-bs0;
                ar1<={{32{ar0[31]}},ar0}<<<30;ai1<={{32{ai0[31]}},ai0}<<<30;
                a1<=a0;b1<=b0;
            end
            if(valid[1])begin
                r02<=ar1+tr1;i02<=ai1+ti1;r12<=ar1-tr1;i12<=ai1-ti1;
                a2<=a1;b2<=b1;
            end
            if(valid[2])begin
                r03<=rr0[31:0];i03<=ri0[31:0];r13<=rr1[31:0];i13<=ri1[31:0];
                overflow3<=outside32(rr0)||outside32(ri0)||outside32(rr1)||outside32(ri1);
                a3<=a2;b3<=b2;
            end
        end
    end
endmodule
