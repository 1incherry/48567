`timescale 1ns/1ps
// Trusted internal single-operation AXI-Lite master. Once offered, individual
// AW/W/AR handshakes remain asserted across cancel until the real response.
module trusted_audio_word_bus(
 input wire clk,security_reset_n,
 input wire request_valid,output wire request_ready,input wire request_write,
 input wire [20:0]request_address,input wire [31:0]request_data,
 output wire response_valid,input wire response_ready,output wire response_error,
 output wire [31:0]response_data,output wire quiescent,
 output wire [20:0]m_awaddr,output wire m_awvalid,input wire m_awready,
 output wire [31:0]m_wdata,output wire [3:0]m_wstrb,output wire m_wvalid,input wire m_wready,
 input wire [1:0]m_bresp,input wire m_bvalid,output wire m_bready,
 output wire [20:0]m_araddr,output wire m_arvalid,input wire m_arready,
 input wire [31:0]m_rdata,input wire [1:0]m_rresp,input wire m_rvalid,output wire m_rready
);
 localparam IDLE=0,BUS=1,REPORT=2;
 reg[1:0]state;reg writing,aw_sent,w_sent,ar_sent,error;
 reg[20:0]address;reg[31:0]data,result;
 assign request_ready=state==IDLE;assign response_valid=state==REPORT;
 assign response_error=error;assign response_data=result;assign quiescent=state==IDLE;
 assign m_awaddr=address;assign m_awvalid=state==BUS&&writing&&!aw_sent;
 assign m_wdata=data;assign m_wstrb=15;assign m_wvalid=state==BUS&&writing&&!w_sent;
 assign m_bready=state==BUS&&writing&&aw_sent&&w_sent;
 assign m_araddr=address;assign m_arvalid=state==BUS&&!writing&&!ar_sent;
 assign m_rready=state==BUS&&!writing&&ar_sent;
 always @(posedge clk)begin
  if(!security_reset_n)begin state<=IDLE;writing<=0;aw_sent<=0;w_sent<=0;ar_sent<=0;error<=0;address<=0;data<=0;result<=0;end
  else case(state)
   IDLE:if(request_valid)begin state<=BUS;writing<=request_write;address<=request_address;data<=request_data;aw_sent<=0;w_sent<=0;ar_sent<=0;error<=0;result<=0;end
   BUS:begin
    if(m_awvalid&&m_awready)aw_sent<=1;
    if(m_wvalid&&m_wready)w_sent<=1;
    if(m_arvalid&&m_arready)ar_sent<=1;
    if(m_bvalid&&m_bready)begin error<=m_bresp!=0;state<=REPORT;end
    if(m_rvalid&&m_rready)begin error<=m_rresp!=0;result<=m_rdata;state<=REPORT;end
   end
   REPORT:if(response_ready)state<=IDLE;
   default:begin state<=IDLE;error<=1;end
  endcase
 end
endmodule
