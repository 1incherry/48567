`timescale 1ns/1ps
`include "system_compile.sv"
`include "trusted/npu_trusted_clock_root.sv"
`include "security_glue/trusted_ps_snapshot_axil.sv"
`include "provision/trusted_provision_vio_bridge.sv"
module npu_hp0_top #(parameter integer ENABLE_ORDINARY_SLOT_REPLAY=0, parameter integer ENABLE_ORDINARY_AUTORUN=0, parameter integer ENABLE_PHYSICAL_MIC=0, parameter integer ENABLE_FIRST_OBSERVED_FAULT_DIAGNOSTIC=0, parameter integer ENABLE_C3_EN_RESET=0,parameter integer ENABLE_PS_NORMAL_TASK_REQUEST=0,parameter integer ENABLE_MIC_RAW_DIAGNOSTICS=0) (
 input wire sys_clk_50m,sys_rst_n,
 inout wire c3_en_n,
 input wire mic_sd,output wire mic_bclk,mic_ws,
 input wire eth_rxc,input wire [3:0] eth_rxd,input wire eth_rx_ctl,
 output wire eth_txc,output wire [3:0] eth_txd,output wire eth_tx_ctl,
 output wire eth_rst_n,inout wire eth_mdio,output wire eth_mdc,
 output wire [2:0] status_led,
    inout wire [14:0] DDR_addr,
    inout wire [2:0] DDR_ba,
    inout wire DDR_cas_n,
    inout wire DDR_ck_n,
    inout wire DDR_ck_p,
    inout wire DDR_cke,
    inout wire DDR_cs_n,
    inout wire [3:0] DDR_dm,
    inout wire [31:0] DDR_dq,
    inout wire [3:0] DDR_dqs_n,
    inout wire [3:0] DDR_dqs_p,
    inout wire DDR_odt,
    inout wire DDR_ras_n,
    inout wire DDR_reset_n,
    inout wire DDR_we_n,
    inout wire FIXED_IO_ddr_vrn,
    inout wire FIXED_IO_ddr_vrp,
    inout wire [53:0] FIXED_IO_mio,
    inout wire FIXED_IO_ps_clk,
    inout wire FIXED_IO_ps_porb,
    inout wire FIXED_IO_ps_srstb,
    output wire HDMI_CLK_P,HDMI_CLK_N,HDMI_D0_P,HDMI_D0_N,
    output wire HDMI_D1_P,HDMI_D1_N,HDMI_D2_P,HDMI_D2_N,HDMI_TX_POWER_EN
);
wire FCLK_CLK0;
wire FCLK_CLK1;
wire FCLK_CLK2;
wire FCLK_RESET0_N;
wire [31:0] M_NPU_CTRL_araddr;
wire [2:0] M_NPU_CTRL_arprot;
wire M_NPU_CTRL_arready;
wire M_NPU_CTRL_arvalid;
wire [31:0] M_NPU_CTRL_awaddr;
wire [2:0] M_NPU_CTRL_awprot;
wire M_NPU_CTRL_awready;
wire M_NPU_CTRL_awvalid;
wire M_NPU_CTRL_bready;
wire [1:0] M_NPU_CTRL_bresp;
wire M_NPU_CTRL_bvalid;
wire [31:0] M_NPU_CTRL_rdata;
wire M_NPU_CTRL_rready;
wire [1:0] M_NPU_CTRL_rresp;
wire M_NPU_CTRL_rvalid;
wire [31:0] M_NPU_CTRL_wdata;
wire M_NPU_CTRL_wready;
wire [3:0] M_NPU_CTRL_wstrb;
wire M_NPU_CTRL_wvalid;
wire [0:0] NPU_ARESETN;
wire [31:0] S_NPU_AXI_araddr;
wire [1:0] S_NPU_AXI_arburst;
wire [3:0] S_NPU_AXI_arcache;
wire [7:0] S_NPU_AXI_arlen;
wire [0:0] S_NPU_AXI_arlock;
wire [2:0] S_NPU_AXI_arprot;
wire [3:0] S_NPU_AXI_arqos;
wire S_NPU_AXI_arready;
wire [2:0] S_NPU_AXI_arsize;
wire S_NPU_AXI_arvalid;
wire [31:0] S_NPU_AXI_awaddr;
wire [1:0] S_NPU_AXI_awburst;
wire [3:0] S_NPU_AXI_awcache;
wire [7:0] S_NPU_AXI_awlen;
wire [0:0] S_NPU_AXI_awlock;
wire [2:0] S_NPU_AXI_awprot;
wire [3:0] S_NPU_AXI_awqos;
wire S_NPU_AXI_awready;
wire [2:0] S_NPU_AXI_awsize;
wire S_NPU_AXI_awvalid;
wire S_NPU_AXI_bready;
wire [1:0] S_NPU_AXI_bresp;
wire S_NPU_AXI_bvalid;
wire [255:0] S_NPU_AXI_rdata;
wire S_NPU_AXI_rlast;
wire S_NPU_AXI_rready;
wire [1:0] S_NPU_AXI_rresp;
wire S_NPU_AXI_rvalid;
wire [255:0] S_NPU_AXI_wdata;
wire S_NPU_AXI_wlast;
wire S_NPU_AXI_wready;
wire [31:0] S_NPU_AXI_wstrb;
wire S_NPU_AXI_wvalid;
assign S_NPU_AXI_arcache = '0;
assign S_NPU_AXI_arlock = '0;
assign S_NPU_AXI_arprot = '0;
assign S_NPU_AXI_arqos = '0;
assign S_NPU_AXI_awcache = '0;
assign S_NPU_AXI_awlock = '0;
assign S_NPU_AXI_awprot = '0;
assign S_NPU_AXI_awqos = '0;
wire [31:0] M_HDMI_CTRL_araddr;
wire [2:0] M_HDMI_CTRL_arprot;
wire [0:0] M_HDMI_CTRL_arready;
wire [0:0] M_HDMI_CTRL_arvalid;
wire [31:0] M_HDMI_CTRL_awaddr;
wire [2:0] M_HDMI_CTRL_awprot;
wire [0:0] M_HDMI_CTRL_awready;
wire [0:0] M_HDMI_CTRL_awvalid;
wire [0:0] M_HDMI_CTRL_bready;
wire [1:0] M_HDMI_CTRL_bresp;
wire [0:0] M_HDMI_CTRL_bvalid;
wire [31:0] M_HDMI_CTRL_rdata;
wire [0:0] M_HDMI_CTRL_rready;
wire [1:0] M_HDMI_CTRL_rresp;
wire [0:0] M_HDMI_CTRL_rvalid;
wire [31:0] M_HDMI_CTRL_wdata;
wire [0:0] M_HDMI_CTRL_wready;
wire [3:0] M_HDMI_CTRL_wstrb;
wire [0:0] M_HDMI_CTRL_wvalid;
wire [31:0] S_HDMI_AXI_araddr;
wire [1:0] S_HDMI_AXI_arburst;
wire [3:0] S_HDMI_AXI_arcache;
wire [7:0] S_HDMI_AXI_arlen;
wire [0:0] S_HDMI_AXI_arlock;
wire [2:0] S_HDMI_AXI_arprot;
wire [3:0] S_HDMI_AXI_arqos;
wire [0:0] S_HDMI_AXI_arready;
wire [2:0] S_HDMI_AXI_arsize;
wire [0:0] S_HDMI_AXI_arvalid;
wire [31:0] S_HDMI_AXI_awaddr;
wire [1:0] S_HDMI_AXI_awburst;
wire [3:0] S_HDMI_AXI_awcache;
wire [7:0] S_HDMI_AXI_awlen;
wire [0:0] S_HDMI_AXI_awlock;
wire [2:0] S_HDMI_AXI_awprot;
wire [3:0] S_HDMI_AXI_awqos;
wire [0:0] S_HDMI_AXI_awready;
wire [2:0] S_HDMI_AXI_awsize;
wire [0:0] S_HDMI_AXI_awvalid;
wire [0:0] S_HDMI_AXI_bready;
wire [1:0] S_HDMI_AXI_bresp;
wire [0:0] S_HDMI_AXI_bvalid;
wire [63:0] S_HDMI_AXI_rdata;
wire [0:0] S_HDMI_AXI_rlast;
wire [0:0] S_HDMI_AXI_rready;
wire [1:0] S_HDMI_AXI_rresp;
wire [0:0] S_HDMI_AXI_rvalid;
wire [63:0] S_HDMI_AXI_wdata;
wire [0:0] S_HDMI_AXI_wlast;
wire [0:0] S_HDMI_AXI_wready;
wire [7:0] S_HDMI_AXI_wstrb;
wire [0:0] S_HDMI_AXI_wvalid;
wire [31:0] M_AUDIO_CTRL_araddr;
wire [2:0] M_AUDIO_CTRL_arprot;
wire [0:0] M_AUDIO_CTRL_arready;
wire [0:0] M_AUDIO_CTRL_arvalid;
wire [31:0] M_AUDIO_CTRL_awaddr;
wire [2:0] M_AUDIO_CTRL_awprot;
wire [0:0] M_AUDIO_CTRL_awready;
wire [0:0] M_AUDIO_CTRL_awvalid;
wire [0:0] M_AUDIO_CTRL_bready;
wire [1:0] M_AUDIO_CTRL_bresp;
wire [0:0] M_AUDIO_CTRL_bvalid;
wire [31:0] M_AUDIO_CTRL_rdata;
wire [0:0] M_AUDIO_CTRL_rready;
wire [1:0] M_AUDIO_CTRL_rresp;
wire [0:0] M_AUDIO_CTRL_rvalid;
wire [31:0] M_AUDIO_CTRL_wdata;
wire [0:0] M_AUDIO_CTRL_wready;
wire [3:0] M_AUDIO_CTRL_wstrb;
wire [0:0] M_AUDIO_CTRL_wvalid;
wire audio_active,audio_irq;
wire [31:0] M_ETH_CTRL_araddr;
wire [2:0] M_ETH_CTRL_arprot;
wire [0:0] M_ETH_CTRL_arready;
wire [0:0] M_ETH_CTRL_arvalid;
wire [31:0] M_ETH_CTRL_awaddr;
wire [2:0] M_ETH_CTRL_awprot;
wire [0:0] M_ETH_CTRL_awready;
wire [0:0] M_ETH_CTRL_awvalid;
wire [0:0] M_ETH_CTRL_bready;
wire [1:0] M_ETH_CTRL_bresp;
wire [0:0] M_ETH_CTRL_bvalid;
wire [31:0] M_ETH_CTRL_rdata;
wire [0:0] M_ETH_CTRL_rready;
wire [1:0] M_ETH_CTRL_rresp;
wire [0:0] M_ETH_CTRL_rvalid;
wire [31:0] M_ETH_CTRL_wdata;
wire [0:0] M_ETH_CTRL_wready;
wire [3:0] M_ETH_CTRL_wstrb;
wire [0:0] M_ETH_CTRL_wvalid;
wire eth_clk125,eth_resetn;

// The PS can cause a reset, but cannot retune the trusted clock root.
wire pl_raw100;
wire pl_clk100,slh_clk50,pl_ref200,pl_locked,pl_common_resetn,pl_reset100n,slh_resetn;
npu_trusted_clock_root u_trusted_clock(.sys_clk_50m(sys_clk_50m),.sys_rst_n(sys_rst_n),
 .ps_reset_n(1'b1),.clk100(pl_clk100),.clk50(slh_clk50),.ref200(pl_ref200),
 .locked(pl_locked),.common_reset_n(pl_common_resetn),.reset100_n(pl_reset100n),.reset50_n(slh_resetn),.raw100_trusted(pl_raw100));
wire [31:0] M_SLH_CTRL_awaddr;
wire [2:0] M_SLH_CTRL_awprot;
wire M_SLH_CTRL_awvalid;
wire M_SLH_CTRL_awready;
wire [31:0] M_SLH_CTRL_wdata;
wire [3:0] M_SLH_CTRL_wstrb;
wire M_SLH_CTRL_wvalid;
wire M_SLH_CTRL_wready;
wire [1:0] M_SLH_CTRL_bresp;
wire M_SLH_CTRL_bvalid;
wire M_SLH_CTRL_bready;
wire [31:0] M_SLH_CTRL_araddr;
wire [2:0] M_SLH_CTRL_arprot;
wire M_SLH_CTRL_arvalid;
wire M_SLH_CTRL_arready;
wire [31:0] M_SLH_CTRL_rdata;
wire [1:0] M_SLH_CTRL_rresp;
wire M_SLH_CTRL_rvalid;
wire M_SLH_CTRL_rready;

design_1_wrapper u_ps (
.TRUSTED_CLK100(pl_clk100),.TRUSTED_RESETN(pl_reset100n),
.SEC_CLK50(pl_clk100),.SEC_RESETN(pl_reset100n),
.M_SLH_CTRL_awaddr(M_SLH_CTRL_awaddr),
.M_SLH_CTRL_awprot(M_SLH_CTRL_awprot),
.M_SLH_CTRL_awvalid(M_SLH_CTRL_awvalid),
.M_SLH_CTRL_awready(M_SLH_CTRL_awready),
.M_SLH_CTRL_wdata(M_SLH_CTRL_wdata),
.M_SLH_CTRL_wstrb(M_SLH_CTRL_wstrb),
.M_SLH_CTRL_wvalid(M_SLH_CTRL_wvalid),
.M_SLH_CTRL_wready(M_SLH_CTRL_wready),
.M_SLH_CTRL_bresp(M_SLH_CTRL_bresp),
.M_SLH_CTRL_bvalid(M_SLH_CTRL_bvalid),
.M_SLH_CTRL_bready(M_SLH_CTRL_bready),
.M_SLH_CTRL_araddr(M_SLH_CTRL_araddr),
.M_SLH_CTRL_arprot(M_SLH_CTRL_arprot),
.M_SLH_CTRL_arvalid(M_SLH_CTRL_arvalid),
.M_SLH_CTRL_arready(M_SLH_CTRL_arready),
.M_SLH_CTRL_rdata(M_SLH_CTRL_rdata),
.M_SLH_CTRL_rresp(M_SLH_CTRL_rresp),
.M_SLH_CTRL_rvalid(M_SLH_CTRL_rvalid),
.M_SLH_CTRL_rready(M_SLH_CTRL_rready),

    .M_ETH_CTRL_araddr(M_ETH_CTRL_araddr),
    .M_ETH_CTRL_arprot(M_ETH_CTRL_arprot),
    .M_ETH_CTRL_arready(M_ETH_CTRL_arready),
    .M_ETH_CTRL_arvalid(M_ETH_CTRL_arvalid),
    .M_ETH_CTRL_awaddr(M_ETH_CTRL_awaddr),
    .M_ETH_CTRL_awprot(M_ETH_CTRL_awprot),
    .M_ETH_CTRL_awready(M_ETH_CTRL_awready),
    .M_ETH_CTRL_awvalid(M_ETH_CTRL_awvalid),
    .M_ETH_CTRL_bready(M_ETH_CTRL_bready),
    .M_ETH_CTRL_bresp(M_ETH_CTRL_bresp),
    .M_ETH_CTRL_bvalid(M_ETH_CTRL_bvalid),
    .M_ETH_CTRL_rdata(M_ETH_CTRL_rdata),
    .M_ETH_CTRL_rready(M_ETH_CTRL_rready),
    .M_ETH_CTRL_rresp(M_ETH_CTRL_rresp),
    .M_ETH_CTRL_rvalid(M_ETH_CTRL_rvalid),
    .M_ETH_CTRL_wdata(M_ETH_CTRL_wdata),
    .M_ETH_CTRL_wready(M_ETH_CTRL_wready),
    .M_ETH_CTRL_wstrb(M_ETH_CTRL_wstrb),
    .M_ETH_CTRL_wvalid(M_ETH_CTRL_wvalid),
.ETH_CLK125(eth_clk125),.ETH_ARESETN(eth_resetn),
    .M_AUDIO_CTRL_araddr(M_AUDIO_CTRL_araddr),
    .M_AUDIO_CTRL_arprot(M_AUDIO_CTRL_arprot),
    .M_AUDIO_CTRL_arready(M_AUDIO_CTRL_arready),
    .M_AUDIO_CTRL_arvalid(M_AUDIO_CTRL_arvalid),
    .M_AUDIO_CTRL_awaddr(M_AUDIO_CTRL_awaddr),
    .M_AUDIO_CTRL_awprot(M_AUDIO_CTRL_awprot),
    .M_AUDIO_CTRL_awready(M_AUDIO_CTRL_awready),
    .M_AUDIO_CTRL_awvalid(M_AUDIO_CTRL_awvalid),
    .M_AUDIO_CTRL_bready(M_AUDIO_CTRL_bready),
    .M_AUDIO_CTRL_bresp(M_AUDIO_CTRL_bresp),
    .M_AUDIO_CTRL_bvalid(M_AUDIO_CTRL_bvalid),
    .M_AUDIO_CTRL_rdata(M_AUDIO_CTRL_rdata),
    .M_AUDIO_CTRL_rready(M_AUDIO_CTRL_rready),
    .M_AUDIO_CTRL_rresp(M_AUDIO_CTRL_rresp),
    .M_AUDIO_CTRL_rvalid(M_AUDIO_CTRL_rvalid),
    .M_AUDIO_CTRL_wdata(M_AUDIO_CTRL_wdata),
    .M_AUDIO_CTRL_wready(M_AUDIO_CTRL_wready),
    .M_AUDIO_CTRL_wstrb(M_AUDIO_CTRL_wstrb),
    .M_AUDIO_CTRL_wvalid(M_AUDIO_CTRL_wvalid),
    .M_HDMI_CTRL_araddr(M_HDMI_CTRL_araddr),
    .M_HDMI_CTRL_arprot(M_HDMI_CTRL_arprot),
    .M_HDMI_CTRL_arready(M_HDMI_CTRL_arready),
    .M_HDMI_CTRL_arvalid(M_HDMI_CTRL_arvalid),
    .M_HDMI_CTRL_awaddr(M_HDMI_CTRL_awaddr),
    .M_HDMI_CTRL_awprot(M_HDMI_CTRL_awprot),
    .M_HDMI_CTRL_awready(M_HDMI_CTRL_awready),
    .M_HDMI_CTRL_awvalid(M_HDMI_CTRL_awvalid),
    .M_HDMI_CTRL_bready(M_HDMI_CTRL_bready),
    .M_HDMI_CTRL_bresp(M_HDMI_CTRL_bresp),
    .M_HDMI_CTRL_bvalid(M_HDMI_CTRL_bvalid),
    .M_HDMI_CTRL_rdata(M_HDMI_CTRL_rdata),
    .M_HDMI_CTRL_rready(M_HDMI_CTRL_rready),
    .M_HDMI_CTRL_rresp(M_HDMI_CTRL_rresp),
    .M_HDMI_CTRL_rvalid(M_HDMI_CTRL_rvalid),
    .M_HDMI_CTRL_wdata(M_HDMI_CTRL_wdata),
    .M_HDMI_CTRL_wready(M_HDMI_CTRL_wready),
    .M_HDMI_CTRL_wstrb(M_HDMI_CTRL_wstrb),
    .M_HDMI_CTRL_wvalid(M_HDMI_CTRL_wvalid),
    .S_HDMI_AXI_araddr(S_HDMI_AXI_araddr),
    .S_HDMI_AXI_arburst(S_HDMI_AXI_arburst),
    .S_HDMI_AXI_arcache(S_HDMI_AXI_arcache),
    .S_HDMI_AXI_arlen(S_HDMI_AXI_arlen),
    .S_HDMI_AXI_arlock(S_HDMI_AXI_arlock),
    .S_HDMI_AXI_arprot(S_HDMI_AXI_arprot),
    .S_HDMI_AXI_arqos(S_HDMI_AXI_arqos),
    .S_HDMI_AXI_arready(S_HDMI_AXI_arready),
    .S_HDMI_AXI_arsize(S_HDMI_AXI_arsize),
    .S_HDMI_AXI_arvalid(S_HDMI_AXI_arvalid),
    .S_HDMI_AXI_awaddr(S_HDMI_AXI_awaddr),
    .S_HDMI_AXI_awburst(S_HDMI_AXI_awburst),
    .S_HDMI_AXI_awcache(S_HDMI_AXI_awcache),
    .S_HDMI_AXI_awlen(S_HDMI_AXI_awlen),
    .S_HDMI_AXI_awlock(S_HDMI_AXI_awlock),
    .S_HDMI_AXI_awprot(S_HDMI_AXI_awprot),
    .S_HDMI_AXI_awqos(S_HDMI_AXI_awqos),
    .S_HDMI_AXI_awready(S_HDMI_AXI_awready),
    .S_HDMI_AXI_awsize(S_HDMI_AXI_awsize),
    .S_HDMI_AXI_awvalid(S_HDMI_AXI_awvalid),
    .S_HDMI_AXI_bready(S_HDMI_AXI_bready),
    .S_HDMI_AXI_bresp(S_HDMI_AXI_bresp),
    .S_HDMI_AXI_bvalid(S_HDMI_AXI_bvalid),
    .S_HDMI_AXI_rdata(S_HDMI_AXI_rdata),
    .S_HDMI_AXI_rlast(S_HDMI_AXI_rlast),
    .S_HDMI_AXI_rready(S_HDMI_AXI_rready),
    .S_HDMI_AXI_rresp(S_HDMI_AXI_rresp),
    .S_HDMI_AXI_rvalid(S_HDMI_AXI_rvalid),
    .S_HDMI_AXI_wdata(S_HDMI_AXI_wdata),
    .S_HDMI_AXI_wlast(S_HDMI_AXI_wlast),
    .S_HDMI_AXI_wready(S_HDMI_AXI_wready),
    .S_HDMI_AXI_wstrb(S_HDMI_AXI_wstrb),
    .S_HDMI_AXI_wvalid(S_HDMI_AXI_wvalid),
    .DDR_addr(DDR_addr),
    .DDR_ba(DDR_ba),
    .DDR_cas_n(DDR_cas_n),
    .DDR_ck_n(DDR_ck_n),
    .DDR_ck_p(DDR_ck_p),
    .DDR_cke(DDR_cke),
    .DDR_cs_n(DDR_cs_n),
    .DDR_dm(DDR_dm),
    .DDR_dq(DDR_dq),
    .DDR_dqs_n(DDR_dqs_n),
    .DDR_dqs_p(DDR_dqs_p),
    .DDR_odt(DDR_odt),
    .DDR_ras_n(DDR_ras_n),
    .DDR_reset_n(DDR_reset_n),
    .DDR_we_n(DDR_we_n),
    .FCLK_CLK0(FCLK_CLK0),
    .FCLK_CLK1(FCLK_CLK1),
    .FCLK_CLK2(FCLK_CLK2),
    .FCLK_RESET0_N(FCLK_RESET0_N),
    .FIXED_IO_ddr_vrn(FIXED_IO_ddr_vrn),
    .FIXED_IO_ddr_vrp(FIXED_IO_ddr_vrp),
    .FIXED_IO_mio(FIXED_IO_mio),
    .FIXED_IO_ps_clk(FIXED_IO_ps_clk),
    .FIXED_IO_ps_porb(FIXED_IO_ps_porb),
    .FIXED_IO_ps_srstb(FIXED_IO_ps_srstb),
    .M_NPU_CTRL_araddr(M_NPU_CTRL_araddr),
    .M_NPU_CTRL_arprot(M_NPU_CTRL_arprot),
    .M_NPU_CTRL_arready(M_NPU_CTRL_arready),
    .M_NPU_CTRL_arvalid(M_NPU_CTRL_arvalid),
    .M_NPU_CTRL_awaddr(M_NPU_CTRL_awaddr),
    .M_NPU_CTRL_awprot(M_NPU_CTRL_awprot),
    .M_NPU_CTRL_awready(M_NPU_CTRL_awready),
    .M_NPU_CTRL_awvalid(M_NPU_CTRL_awvalid),
    .M_NPU_CTRL_bready(M_NPU_CTRL_bready),
    .M_NPU_CTRL_bresp(M_NPU_CTRL_bresp),
    .M_NPU_CTRL_bvalid(M_NPU_CTRL_bvalid),
    .M_NPU_CTRL_rdata(M_NPU_CTRL_rdata),
    .M_NPU_CTRL_rready(M_NPU_CTRL_rready),
    .M_NPU_CTRL_rresp(M_NPU_CTRL_rresp),
    .M_NPU_CTRL_rvalid(M_NPU_CTRL_rvalid),
    .M_NPU_CTRL_wdata(M_NPU_CTRL_wdata),
    .M_NPU_CTRL_wready(M_NPU_CTRL_wready),
    .M_NPU_CTRL_wstrb(M_NPU_CTRL_wstrb),
    .M_NPU_CTRL_wvalid(M_NPU_CTRL_wvalid),
    .NPU_ARESETN(NPU_ARESETN),
    .S_NPU_AXI_araddr(S_NPU_AXI_araddr),
    .S_NPU_AXI_arburst(S_NPU_AXI_arburst),
    .S_NPU_AXI_arcache(S_NPU_AXI_arcache),
    .S_NPU_AXI_arlen(S_NPU_AXI_arlen),
    .S_NPU_AXI_arlock(S_NPU_AXI_arlock),
    .S_NPU_AXI_arprot(S_NPU_AXI_arprot),
    .S_NPU_AXI_arqos(S_NPU_AXI_arqos),
    .S_NPU_AXI_arready(S_NPU_AXI_arready),
    .S_NPU_AXI_arsize(S_NPU_AXI_arsize),
    .S_NPU_AXI_arvalid(S_NPU_AXI_arvalid),
    .S_NPU_AXI_awaddr(S_NPU_AXI_awaddr),
    .S_NPU_AXI_awburst(S_NPU_AXI_awburst),
    .S_NPU_AXI_awcache(S_NPU_AXI_awcache),
    .S_NPU_AXI_awlen(S_NPU_AXI_awlen),
    .S_NPU_AXI_awlock(S_NPU_AXI_awlock),
    .S_NPU_AXI_awprot(S_NPU_AXI_awprot),
    .S_NPU_AXI_awqos(S_NPU_AXI_awqos),
    .S_NPU_AXI_awready(S_NPU_AXI_awready),
    .S_NPU_AXI_awsize(S_NPU_AXI_awsize),
    .S_NPU_AXI_awvalid(S_NPU_AXI_awvalid),
    .S_NPU_AXI_bready(S_NPU_AXI_bready),
    .S_NPU_AXI_bresp(S_NPU_AXI_bresp),
    .S_NPU_AXI_bvalid(S_NPU_AXI_bvalid),
    .S_NPU_AXI_rdata(S_NPU_AXI_rdata),
    .S_NPU_AXI_rlast(S_NPU_AXI_rlast),
    .S_NPU_AXI_rready(S_NPU_AXI_rready),
    .S_NPU_AXI_rresp(S_NPU_AXI_rresp),
    .S_NPU_AXI_rvalid(S_NPU_AXI_rvalid),
    .S_NPU_AXI_wdata(S_NPU_AXI_wdata),
    .S_NPU_AXI_wlast(S_NPU_AXI_wlast),
    .S_NPU_AXI_wready(S_NPU_AXI_wready),
    .S_NPU_AXI_wstrb(S_NPU_AXI_wstrb),
    .S_NPU_AXI_wvalid(S_NPU_AXI_wvalid)
);


assign S_HDMI_AXI_arburst=2'b01;
assign S_HDMI_AXI_arcache=4'b0011;
assign S_HDMI_AXI_arlen=8'd255;
assign S_HDMI_AXI_arlock=0;assign S_HDMI_AXI_arprot=0;assign S_HDMI_AXI_arqos=0;
assign S_HDMI_AXI_arsize=3;
assign S_HDMI_AXI_awcache=0;assign S_HDMI_AXI_awlock=0;assign S_HDMI_AXI_awprot=0;assign S_HDMI_AXI_awqos=0;
wire trusted_pixel_clk,trusted_pixel_reset_n;
wire [11:0] trusted_pixel_x,trusted_pixel_y;
wire [23:0] trusted_pixel_rgb,trusted_overlay_rgb;
wire trusted_pixel_hs,trusted_pixel_vs,trusted_pixel_de,trusted_overlay_hs,trusted_overlay_vs,trusted_overlay_de;

// Ordinary PS gallery peripherals reuse the existing 100MHz HDMI AXI-Lite
// 4KiB window. No new PS BD port, NPU GO, model grant or authority is added.
wire [11:0] ordinary_page_awaddr,ordinary_page_araddr;
wire [31:0] ordinary_page_wdata;wire [3:0] ordinary_page_wstrb;
wire [3:0] ordinary_page_awvalid,ordinary_page_awready,ordinary_page_wvalid,ordinary_page_wready;
wire [3:0] ordinary_page_bvalid,ordinary_page_bready,ordinary_page_arvalid,ordinary_page_arready;
wire [3:0] ordinary_page_rvalid,ordinary_page_rready;
wire [7:0] ordinary_page_bresp,ordinary_page_rresp;wire [127:0] ordinary_page_rdata;
ordinary_hdmi_axil_router #(.ENABLE_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY),.ENABLE_C3_EN_RESET(ENABLE_C3_EN_RESET),.ENABLE_PS_NORMAL_TASK_REQUEST(ENABLE_PS_NORMAL_TASK_REQUEST),.ENABLE_MIC_RAW_DIAGNOSTICS(ENABLE_MIC_RAW_DIAGNOSTICS)) u_ordinary_control_router(.clk(pl_clk100),.rst_n(pl_reset100n),
 .s_awaddr(M_HDMI_CTRL_awaddr[11:0]),.s_araddr(M_HDMI_CTRL_araddr[11:0]),
 .s_awvalid(M_HDMI_CTRL_awvalid),.s_wvalid(M_HDMI_CTRL_wvalid),.s_bready(M_HDMI_CTRL_bready),
 .s_arvalid(M_HDMI_CTRL_arvalid),.s_rready(M_HDMI_CTRL_rready),.s_wdata(M_HDMI_CTRL_wdata),.s_wstrb(M_HDMI_CTRL_wstrb),
 .s_awready(M_HDMI_CTRL_awready),.s_wready(M_HDMI_CTRL_wready),.s_arready(M_HDMI_CTRL_arready),
 .s_bvalid(M_HDMI_CTRL_bvalid),.s_rvalid(M_HDMI_CTRL_rvalid),.s_bresp(M_HDMI_CTRL_bresp),.s_rresp(M_HDMI_CTRL_rresp),.s_rdata(M_HDMI_CTRL_rdata),
 .m_awaddr(ordinary_page_awaddr),.m_araddr(ordinary_page_araddr),.m_wdata(ordinary_page_wdata),.m_wstrb(ordinary_page_wstrb),
 .m_awvalid(ordinary_page_awvalid),.m_awready(ordinary_page_awready),.m_wvalid(ordinary_page_wvalid),.m_wready(ordinary_page_wready),
 .m_bvalid(ordinary_page_bvalid),.m_bready(ordinary_page_bready),.m_bresp(ordinary_page_bresp),
 .m_arvalid(ordinary_page_arvalid),.m_arready(ordinary_page_arready),.m_rvalid(ordinary_page_rvalid),.m_rready(ordinary_page_rready),
 .m_rresp(ordinary_page_rresp),.m_rdata(ordinary_page_rdata));


// Display-only preview observes actual HDMI completion; the original scan path
// and the NN/tensor/model authentication remain unchanged.
wire[31:0] ordinary_hdmi_ack_seq,ordinary_hdmi_active_base,ordinary_hdmi_frames;
wire ordinary_hdmi_healthy;
wire normal_request_valid;wire[31:0]normal_request_command,normal_request_epoch,normal_request_model,normal_result_word,normal_status_word;wire[3:0]normal_request_strobes;wire[7:0]normal_request_error;wire[223:0]normal_witness_words;
wire[511:0]mic_raw_diagnostic_words;
wire c3_reset_accept,c3_reset_busy,c3_en_observed_high;
wire[31:0] c3_reset_accepted_count,c3_reset_completed_count;
generate if(ENABLE_C3_EN_RESET!=0)begin:g_c3_en_management
 c3_en_open_drain_pulse #(.PULSE_CYCLES(5000000)) u_pulse(
  .clk(pl_clk100),.board_resetn(pl_reset100n&&sys_rst_n),.cmd_accept(c3_reset_accept),
  .busy(c3_reset_busy),.done_pulse(),.accepted_count(c3_reset_accepted_count),
  .completed_count(c3_reset_completed_count),.rejected_busy_count(),
  .en_observed_high(c3_en_observed_high),.c3_en_n(c3_en_n));
end else begin:g_c3_en_disabled
 assign c3_en_n=1'bz;
 assign c3_reset_busy=1'b0;assign c3_en_observed_high=1'b0;
 assign c3_reset_accepted_count=32'd0;assign c3_reset_completed_count=32'd0;
end endgenerate
hdmi_quad_top #(.ENABLE_C3_EN_RESET(ENABLE_C3_EN_RESET),.ENABLE_PS_NORMAL_TASK_REQUEST(ENABLE_PS_NORMAL_TASK_REQUEST),.ENABLE_MIC_RAW_DIAGNOSTICS(ENABLE_MIC_RAW_DIAGNOSTICS)) u_hdmi(
 .mic_raw_diagnostic_words(mic_raw_diagnostic_words),
 .normal_request_valid(normal_request_valid),.normal_request_command(normal_request_command),.normal_request_epoch(normal_request_epoch),.normal_request_model(normal_request_model),.normal_request_strobes(normal_request_strobes),.normal_request_error(normal_request_error),.normal_result_word(normal_result_word),.normal_status_word(normal_status_word),.normal_witness_words(normal_witness_words),
 .c3_reset_accept(c3_reset_accept),.c3_reset_busy(c3_reset_busy),.c3_en_observed_high(c3_en_observed_high),
 .c3_reset_accepted_count(c3_reset_accepted_count),.c3_reset_completed_count(c3_reset_completed_count),
 .observation_ack_seq(ordinary_hdmi_ack_seq),.observation_active_base(ordinary_hdmi_active_base),
 .observation_frames(ordinary_hdmi_frames),.observation_healthy(ordinary_hdmi_healthy),.trusted_pixel_clk(trusted_pixel_clk),.trusted_pixel_reset_n(trusted_pixel_reset_n),
 .trusted_pixel_x(trusted_pixel_x),.trusted_pixel_y(trusted_pixel_y),.trusted_pixel_rgb(trusted_pixel_rgb),
 .trusted_pixel_hs(trusted_pixel_hs),.trusted_pixel_vs(trusted_pixel_vs),.trusted_pixel_de(trusted_pixel_de),
 .trusted_overlay_rgb(trusted_overlay_rgb),.trusted_overlay_hs(trusted_overlay_hs),.trusted_overlay_vs(trusted_overlay_vs),.trusted_overlay_de(trusted_overlay_de),.clk(pl_clk100),.ref200(pl_ref200),.rst_n(pl_reset100n),
.c_awaddr({20'd0,ordinary_page_awaddr}),
.c_wdata(ordinary_page_wdata),
.c_araddr({20'd0,ordinary_page_araddr}),
.c_wstrb(ordinary_page_wstrb),
.c_awvalid(ordinary_page_awvalid[0]),
.c_wvalid(ordinary_page_wvalid[0]),
.c_bready(ordinary_page_bready[0]),
.c_arvalid(ordinary_page_arvalid[0]),
.c_rready(ordinary_page_rready[0]),
.c_awready(ordinary_page_awready[0]),
.c_wready(ordinary_page_wready[0]),
.c_arready(ordinary_page_arready[0]),
.c_bvalid(ordinary_page_bvalid[0]),
.c_rvalid(ordinary_page_rvalid[0]),
.c_bresp(ordinary_page_bresp[1:0]),
.c_rresp(ordinary_page_rresp[1:0]),
.c_rdata(ordinary_page_rdata[31:0]),
.m_araddr(S_HDMI_AXI_araddr),
.m_arvalid(S_HDMI_AXI_arvalid),
.m_arready(S_HDMI_AXI_arready),
.m_rdata(S_HDMI_AXI_rdata),
.m_rresp(S_HDMI_AXI_rresp),
.m_rlast(S_HDMI_AXI_rlast),
.m_rvalid(S_HDMI_AXI_rvalid),
.m_rready(S_HDMI_AXI_rready),
.HDMI_CLK_P(HDMI_CLK_P),
.HDMI_CLK_N(HDMI_CLK_N),
.HDMI_D0_P(HDMI_D0_P),
.HDMI_D0_N(HDMI_D0_N),
.HDMI_D1_P(HDMI_D1_P),
.HDMI_D1_N(HDMI_D1_N),
.HDMI_D2_P(HDMI_D2_P),
.HDMI_D2_N(HDMI_D2_N),
.HDMI_TX_POWER_EN(HDMI_TX_POWER_EN));


wire [7:0] frame_tx_data,frame_rx_data;
wire frame_tx_valid,frame_tx_last,frame_tx_ready,frame_tx_clk,frame_tx_reset;
wire frame_rx_valid,frame_rx_last,frame_rx_bad,frame_rx_clk,frame_rx_reset;
eth_boardlink_nfr_axil u_eth(
.frame_tx_data(frame_tx_data),.frame_tx_valid(frame_tx_valid),.frame_tx_last(frame_tx_last),.frame_tx_ready(frame_tx_ready),
.frame_tx_clk(frame_tx_clk),.frame_tx_reset(frame_tx_reset),
.frame_rx_data(frame_rx_data),.frame_rx_valid(frame_rx_valid),.frame_rx_last(frame_rx_last),.frame_rx_bad(frame_rx_bad),
.frame_rx_clk(frame_rx_clk),.frame_rx_reset(frame_rx_reset),.sys_clk_50m(sys_clk_50m),.sys_rst_n(sys_rst_n),.bus_clk125(eth_clk125),.bus_resetn(eth_resetn),
.eth_rxc(eth_rxc),.eth_rxd(eth_rxd),.eth_rx_ctl(eth_rx_ctl),.eth_txc(eth_txc),.eth_txd(eth_txd),.eth_tx_ctl(eth_tx_ctl),.eth_rst_n(eth_rst_n),.eth_mdio(eth_mdio),.eth_mdc(eth_mdc),.status_led(status_led),
.c_awaddr(M_ETH_CTRL_awaddr),
.c_awvalid(M_ETH_CTRL_awvalid),
.c_awready(M_ETH_CTRL_awready),
.c_wdata(M_ETH_CTRL_wdata),
.c_wstrb(M_ETH_CTRL_wstrb),
.c_wvalid(M_ETH_CTRL_wvalid),
.c_wready(M_ETH_CTRL_wready),
.c_bresp(M_ETH_CTRL_bresp),
.c_bvalid(M_ETH_CTRL_bvalid),
.c_bready(M_ETH_CTRL_bready),
.c_araddr(M_ETH_CTRL_araddr),
.c_arvalid(M_ETH_CTRL_arvalid),
.c_arready(M_ETH_CTRL_arready),
.c_rdata(M_ETH_CTRL_rdata),
.c_rresp(M_ETH_CTRL_rresp),
.c_rvalid(M_ETH_CTRL_rvalid),
.c_rready(M_ETH_CTRL_rready));

wire v_clk;
wire v_trusted_por_n;
wire v_clock_locked;
wire v_ps_reset_n;
wire v_external_memory_available;
wire v_external_resources_quiescent;
wire [31:0] v_debug_command;
wire [31:0] v_debug_resume_epoch;
wire [127:0] v_debug_key;
wire [127:0] v_debug_session_id;
wire [127:0] v_debug_key_fingerprint;
wire [31:0] v_ack_word;
wire [31:0] v_status_word;
wire [31:0] v_last_sequence_word;
wire v_security_reset_n;
wire v_arith_reset_n;
wire v_authorized;
wire v_key_valid;
wire v_active;
wire v_quiescent;
wire v_fault;
wire v_job_done;
wire [31:0] v_authorization_epoch;
wire [31:0] v_model_epoch;
wire [127:0] v_key_session_id;
wire v_raw_model_authorized;
wire v_model_lease_valid;
wire [11:0] v_PS_AWADDR;
wire [11:0] v_PS_ARADDR;
wire v_PS_AWVALID;
wire v_PS_WVALID;
wire v_PS_BREADY;
wire v_PS_ARVALID;
wire v_PS_RREADY;
wire [31:0] v_PS_WDATA;
wire [3:0] v_PS_WSTRB;
wire v_PS_AWREADY;
wire v_PS_WREADY;
wire v_PS_BVALID;
wire v_PS_ARREADY;
wire v_PS_RVALID;
wire [1:0] v_PS_BRESP;
wire [1:0] v_PS_RRESP;
wire [31:0] v_PS_RDATA;
wire v_packet_valid;
wire [383:0] v_packet_header;
wire v_packet_release;
wire v_payload_read;
wire [9:0] v_payload_address;
wire [7:0] v_payload_data;
wire v_payload_read_valid;
wire v_response_valid;
wire v_response_ready;
wire [7:0] v_response_kind;
wire [7:0] v_response_flags;
wire [31:0] v_response_offset;
wire [31:0] v_response_frame_crc;
wire [31:0] v_response_session_id;
wire [31:0] v_response_frame_id;
wire [31:0] v_response_total_bytes;
wire [15:0] v_response_width;
wire [15:0] v_response_height;
wire [31:0] v_completed_frames;
wire [31:0] v_rejected_completions;
wire [31:0] v_committed_offset;
wire [31:0] v_received_crc;
wire v_observation_frame_start;
wire v_observation_ingress_done;
wire v_observation_page_accept;
wire v_observation_page_input_wait;
wire [31:0] v_observation_page_index;
wire [31:0] v_observation_model_address;
wire [31:0] v_observation_proof_address;
wire [2:0] v_service_committed_owner;
wire [1:0] v_hp_committed_owner;
wire v_metrics_valid;
wire v_metrics_fault;
wire [63:0] v_metrics_total;
wire [63:0] v_metrics_ingress;
wire [63:0] v_metrics_yolo;
wire [255:0] v_metrics_frontend;
wire [255:0] v_metrics_nn;
wire [255:0] v_metrics_head;
wire [63:0] v_metrics_page_input_wait;
wire [63:0] v_metrics_mac_busy;
wire [63:0] v_metrics_pool_wait;
wire [3:0] v_metrics_roi_measured;
wire [31:0] v_metrics_sequence;
wire [63:0] v_frame_elapsed_cycles;
wire v_record_visible;
wire v_record_commit_pulse;
wire [31:0] v_record_camera;
wire [31:0] v_record_session;
wire [31:0] v_record_frame;
wire [31:0] v_record_epoch;
wire [127:0] v_record_key_session;
wire [2:0] v_record_count;
wire [895:0] v_record_rois;
wire [51:0] v_record_indices;
wire [511:0] v_record_results;
wire v_observation_pool_wait;
wire v_observation_yolo_start;
wire v_observation_yolo_done;
wire v_observation_frontend_start;
wire v_observation_nn_start;
wire v_observation_nn_done;
wire v_observation_head_start;
wire [31:0] v_observation_roi_index;
wire [31:0] v_observation_generation;
wire [3:0] v_observation_block;
wire v_observation_norm3_valid;
wire v_observation_norm3_done;
wire [15:0] v_observation_norm3_address;
wire [15:0] v_observation_norm3_data;
wire v_observation_logit_valid;
wire [7:0] v_observation_logit_class;
wire [63:0] v_observation_logit_data;
wire v_observation_result_valid;
wire [7:0] v_observation_result_class;
wire [63:0] v_observation_result_logit;
wire [31:0] v_observation_consumer_session;
wire [31:0] v_observation_consumer_frame;
wire [31:0] v_observation_consumer_epoch;
wire [31:0] v_observation_context_camera;
wire [31:0] v_observation_context_session;
wire [31:0] v_observation_context_frame;
wire [31:0] v_observation_context_epoch;
wire [31:0] v_M_AXI_ARADDR;
wire [7:0] v_M_AXI_ARLEN;
wire [2:0] v_M_AXI_ARSIZE;
wire [1:0] v_M_AXI_ARBURST;
wire v_M_AXI_ARVALID;
wire v_M_AXI_ARREADY;
wire [255:0] v_M_AXI_RDATA;
wire [1:0] v_M_AXI_RRESP;
wire v_M_AXI_RLAST;
wire v_M_AXI_RVALID;
wire v_M_AXI_RREADY;
wire [31:0] v_M_AXI_AWADDR;
wire [7:0] v_M_AXI_AWLEN;
wire [2:0] v_M_AXI_AWSIZE;
wire [1:0] v_M_AXI_AWBURST;
wire v_M_AXI_AWVALID;
wire v_M_AXI_AWREADY;
wire [255:0] v_M_AXI_WDATA;
wire [31:0] v_M_AXI_WSTRB;
wire v_M_AXI_WLAST;
wire v_M_AXI_WVALID;
wire v_M_AXI_WREADY;
wire [1:0] v_M_AXI_BRESP;
wire v_M_AXI_BVALID;
wire v_M_AXI_BREADY;
wire a_clk;
wire a_security_reset_n;
wire a_trusted_can_enable;
wire a_committed_owner_grant;
wire a_cancel;
wire a_claim;
wire a_audio_active;
wire a_audio_busy;
wire a_irq;
wire a_cache_clean;
wire a_cache_idle;
wire a_cache_fault;
wire a_management_quiet;
wire a_fence_quiet;
wire a_quiescent;
wire a_fault;
wire [20:0] a_s_axi_awaddr;
wire [2:0] a_s_axi_awprot;
wire a_s_axi_awvalid;
wire a_s_axi_awready;
wire [31:0] a_s_axi_wdata;
wire [3:0] a_s_axi_wstrb;
wire a_s_axi_wvalid;
wire a_s_axi_wready;
wire [1:0] a_s_axi_bresp;
wire a_s_axi_bvalid;
wire a_s_axi_bready;
wire [20:0] a_s_axi_araddr;
wire [2:0] a_s_axi_arprot;
wire a_s_axi_arvalid;
wire a_s_axi_arready;
wire [31:0] a_s_axi_rdata;
wire [1:0] a_s_axi_rresp;
wire a_s_axi_rvalid;
wire a_s_axi_rready;
wire [31:0] a_M_AXI_ARADDR;
wire [7:0] a_M_AXI_ARLEN;
wire [2:0] a_M_AXI_ARSIZE;
wire [1:0] a_M_AXI_ARBURST;
wire a_M_AXI_ARVALID;
wire a_M_AXI_ARREADY;
wire [255:0] a_M_AXI_RDATA;
wire [1:0] a_M_AXI_RRESP;
wire a_M_AXI_RLAST;
wire a_M_AXI_RVALID;
wire a_M_AXI_RREADY;
wire [31:0] a_M_AXI_AWADDR;
wire [7:0] a_M_AXI_AWLEN;
wire [2:0] a_M_AXI_AWSIZE;
wire [1:0] a_M_AXI_AWBURST;
wire a_M_AXI_AWVALID;
wire a_M_AXI_AWREADY;
wire [255:0] a_M_AXI_WDATA;
wire [31:0] a_M_AXI_WSTRB;
wire a_M_AXI_WLAST;
wire a_M_AXI_WVALID;
wire a_M_AXI_WREADY;
wire [1:0] a_M_AXI_BRESP;
wire a_M_AXI_BVALID;
wire a_M_AXI_BREADY;
assign M_SLH_CTRL_awready=v_PS_AWREADY;
assign M_SLH_CTRL_wready=v_PS_WREADY;
assign M_SLH_CTRL_bvalid=v_PS_BVALID;
assign M_SLH_CTRL_arready=v_PS_ARREADY;
assign M_SLH_CTRL_rvalid=v_PS_RVALID;
assign M_SLH_CTRL_bresp=v_PS_BRESP;
assign M_SLH_CTRL_rresp=v_PS_RRESP;
assign M_SLH_CTRL_rdata=v_PS_RDATA;

// The display framebuffer and legacy Ethernet message CSRs remain trust-0
// diagnostics. The authenticated record below comes ONLY from the PL bank.
wire [1:0] av_owner;wire av_quiet,av_fault,av_match;
wire audio_ps_quiet,compute_ps_quiet;
wire v_audio_record_commit,v_audio_record_visible,v_audio_job_accepted,v_audio_active,v_audio_quiescent,v_audio_fault;
wire [287:0]v_audio_record_context;wire[6:0]v_audio_record_class;wire[31:0]v_audio_record_score;
wire[31:0]v_next_capture_session,v_next_capture_frame,v_next_capture_status;
wire[63:0]v_audio_total_cycles,v_audio_post_pcm_cycles;wire[31:0]v_audio_sequence,report_sequence;wire[7:0]v_audio_phase;
wire [31:0] debug_command,debug_resume_epoch;
wire [127:0] debug_key,debug_session_id,debug_key_fingerprint;
trusted_provision_vio_bridge u_provision_vio(.clk(pl_clk100),
 .debug_command(debug_command),.debug_resume_epoch(debug_resume_epoch),
 .debug_key(debug_key),.debug_session_id(debug_session_id),.debug_key_fingerprint(debug_key_fingerprint),
 .ack_word(v_ack_word),.status_word(v_status_word),.controller_epoch(v_authorization_epoch),
 .controller_session_id(v_key_session_id),.last_sequence_word(v_last_sequence_word));
wire packet_valid,packet_release,payload_read,payload_read_valid;
wire [383:0] packet_header;wire [9:0] payload_address;wire [7:0] payload_data;
wire response_ready,transport_tx_quiescent;
wire outputs_ready,outputs_quiet,outputs_fault;
wire [7:0] control_tx_data,report_tx_data;
wire control_tx_valid,control_tx_last,control_tx_ready,report_tx_valid,report_tx_last,report_tx_ready;

// Typed PS_UNTRUSTED history only. It cannot impersonate NTR/NAR inference
// records; B means local enqueue, while SENT follows true final MAC acceptance.

wire replay_offer_valid,replay_offer_ready,replay_offer_held,replay_offer_cache_clean,replay_offer_cancel;
wire[6:0] replay_offer_slot,replay_selected_slot;
wire[63:0] replay_offer_generation,replay_offer_batch,replay_selected_generation,replay_selected_batch;
wire[31:0] replay_offer_expected_model,replay_receipt_ack_token,replay_token,replay_exec_session,replay_exec_frame,replay_exec_epoch,replay_exec_model;
wire[127:0]replay_exec_key;
wire replay_receipt_ack,replay_busy,replay_active,replay_receipt_valid,replay_receipt_failed,replay_exhausted,replay_offer_interface_quiet;
wire[7:0]replay_receipt_error;
ordinary_replay_offer_axil #(.ENABLE(ENABLE_ORDINARY_SLOT_REPLAY)) u_ordinary_replay_offer(
 .clk(pl_clk100),.rst_n(pl_reset100n),.s_awaddr(ordinary_page_awaddr-12'ha00),.s_araddr(ordinary_page_araddr-12'ha00),
 .s_awvalid(ordinary_page_awvalid[3]),.s_wvalid(ordinary_page_wvalid[3]),.s_bready(ordinary_page_bready[3]),.s_arvalid(ordinary_page_arvalid[3]),.s_rready(ordinary_page_rready[3]),
 .s_wdata(ordinary_page_wdata),.s_wstrb(ordinary_page_wstrb),.s_awready(ordinary_page_awready[3]),.s_wready(ordinary_page_wready[3]),.s_arready(ordinary_page_arready[3]),
 .s_bvalid(ordinary_page_bvalid[3]),.s_rvalid(ordinary_page_rvalid[3]),.s_bresp(ordinary_page_bresp[7:6]),.s_rresp(ordinary_page_rresp[7:6]),.s_rdata(ordinary_page_rdata[127:96]),
 .offer_valid(replay_offer_valid),.offer_ready(replay_offer_ready),.offer_slot(replay_offer_slot),.offer_generation(replay_offer_generation),.offer_batch(replay_offer_batch),
 .offer_held(replay_offer_held),.offer_cache_clean(replay_offer_cache_clean),.offer_expected_model(replay_offer_expected_model),.offer_cancel(replay_offer_cancel),
 .receipt_ack(replay_receipt_ack),.receipt_ack_token(replay_receipt_ack_token),.busy(replay_busy),.active(replay_active),.receipt_valid(replay_receipt_valid),.receipt_failed(replay_receipt_failed),.exhausted(replay_exhausted),.receipt_error(replay_receipt_error),
 .selected_slot(replay_selected_slot),.selected_generation(replay_selected_generation),.selected_batch(replay_selected_batch),.token(replay_token),
 .exec_session(replay_exec_session),.exec_frame(replay_exec_frame),.exec_epoch(replay_exec_epoch),.exec_model(replay_exec_model),.exec_key(replay_exec_key),.interface_quiet(replay_offer_interface_quiet));

wire ordinary_his_begin_valid,ordinary_his_begin_ready,ordinary_his_word_valid,ordinary_his_word_ready,ordinary_his_word_last;
wire [31:0] ordinary_his_token,ordinary_his_word,ordinary_his_completed_token,ordinary_his_started_token;
wire ordinary_his_completed,ordinary_his_error,ordinary_his_started,ordinary_his_quiet,ordinary_his_fault;
wire [7:0] ordinary_his_tx_data,ordinary_report_data;
wire ordinary_his_tx_valid,ordinary_his_tx_last,ordinary_his_tx_ready;
wire ordinary_report_valid,ordinary_report_last,ordinary_report_ready;
typed_his_hna1_tx_mailbox #(.HONOR_TRANSPORT_FAULT(1),.ENABLE_HNA1(1),.HISTORY_WIDTH(1920),.HISTORY_HEIGHT(1080)) u_ordinary_his_mailbox(
 .clk(pl_clk100),.board_resetn(pl_reset100n),
 .s_awaddr(ordinary_page_awaddr-12'h800),.s_araddr(ordinary_page_araddr-12'h800),
 .s_awvalid(ordinary_page_awvalid[2]),.s_wvalid(ordinary_page_wvalid[2]),.s_bready(ordinary_page_bready[2]),
 .s_arvalid(ordinary_page_arvalid[2]),.s_rready(ordinary_page_rready[2]),.s_wdata(ordinary_page_wdata),.s_wstrb(ordinary_page_wstrb),
 .s_awready(ordinary_page_awready[2]),.s_wready(ordinary_page_wready[2]),.s_arready(ordinary_page_arready[2]),
 .s_bvalid(ordinary_page_bvalid[2]),.s_rvalid(ordinary_page_rvalid[2]),.s_bresp(ordinary_page_bresp[5:4]),
 .s_rresp(ordinary_page_rresp[5:4]),.s_rdata(ordinary_page_rdata[95:64]),
 .packet_begin_valid(ordinary_his_begin_valid),.packet_begin_ready(ordinary_his_begin_ready),.packet_token(ordinary_his_token),
 .word_valid(ordinary_his_word_valid),.word_ready(ordinary_his_word_ready),.word_data(ordinary_his_word),.word_last(ordinary_his_word_last),
 .completion_valid(ordinary_his_completed),.completion_error(ordinary_his_error),.completion_token(ordinary_his_completed_token),
 .mac_started_valid(ordinary_his_started),.mac_started_token(ordinary_his_started_token),
 .local_busy(),.local_fault(),.local_error(),.sent_count(),.rejected_count(),.transport_fault(ordinary_his_fault));
untrusted_his1_narrow_transport u_ordinary_his_transport(.clk(pl_clk100),.board_resetn(pl_reset100n),
 .packet_begin_valid(ordinary_his_begin_valid),.packet_begin_ready(ordinary_his_begin_ready),.packet_token(ordinary_his_token),
 .word_valid(ordinary_his_word_valid),.word_ready(ordinary_his_word_ready),.word_data(ordinary_his_word),.word_last(ordinary_his_word_last),
 .completion_valid(ordinary_his_completed),.completion_error(ordinary_his_error),.completion_token(ordinary_his_completed_token),
 .mac_started_valid(ordinary_his_started),.mac_started_token(ordinary_his_started_token),.quiescent(ordinary_his_quiet),.fault(ordinary_his_fault),
 .tx_clk(frame_tx_clk),.tx_reset_n(!frame_tx_reset),.tx_data(ordinary_his_tx_data),.tx_valid(ordinary_his_tx_valid),.tx_last(ordinary_his_tx_last),.tx_ready(ordinary_his_tx_ready));
nfr_tx_arbiter u_ordinary_history_arbiter(.clk(frame_tx_clk),.rst(frame_tx_reset),
 .frame_data(report_tx_data),.frame_valid(report_tx_valid),.frame_last(report_tx_last),.frame_ready(report_tx_ready),
 .legacy_data(ordinary_his_tx_data),.legacy_valid(ordinary_his_tx_valid),.legacy_last(ordinary_his_tx_last),.legacy_ready(ordinary_his_tx_ready),
 .mac_data(ordinary_report_data),.mac_valid(ordinary_report_valid),.mac_last(ordinary_report_last),.mac_ready(ordinary_report_ready));

nfr_tx_arbiter u_report_arbiter(.clk(frame_tx_clk),.rst(frame_tx_reset),
 .frame_data(control_tx_data),.frame_valid(control_tx_valid),.frame_last(control_tx_last),.frame_ready(control_tx_ready),
 .legacy_data(ordinary_report_data),.legacy_valid(ordinary_report_valid),.legacy_last(ordinary_report_last),.legacy_ready(ordinary_report_ready),
 .mac_data(frame_tx_data),.mac_valid(frame_tx_valid),.mac_last(frame_tx_last),.mac_ready(frame_tx_ready));
trusted_av_record_outputs #(.CLOSED_READY_START(1)) u_outputs(.clk(pl_clk100),.security_reset_n(v_security_reset_n),.authorization_live(v_authorized),
 .job_start(v_observation_frame_start||v_audio_job_accepted),.record_commit(v_record_commit_pulse),.record_visible(v_record_visible),
 .record_camera(v_record_camera),.record_session(v_record_session),.record_frame(v_record_frame),.record_epoch(v_record_epoch),
 .record_key_session(v_record_key_session),.record_count(v_record_count),.record_rois(v_record_rois),.record_indices(v_record_indices),.record_results(v_record_results),
 .audio_record_commit(v_audio_record_commit),.audio_record_visible(v_audio_record_visible),.audio_record_context(v_audio_record_context),.audio_record_class(v_audio_record_class),.audio_record_score(v_audio_record_score),.report_sequence(report_sequence),
 .admission_ready(outputs_ready),.quiescent(outputs_quiet),.fault(outputs_fault),
 .tx_clk(frame_tx_clk),.tx_reset_n(!frame_tx_reset),.tx_data(report_tx_data),.tx_valid(report_tx_valid),.tx_last(report_tx_last),.tx_ready(report_tx_ready),
 .pixel_clk(trusted_pixel_clk),.pixel_reset_n(trusted_pixel_reset_n),.pixel_x(trusted_pixel_x),.pixel_y(trusted_pixel_y),
 .pixel_rgb(trusted_pixel_rgb),.pixel_hs(trusted_pixel_hs),.pixel_vs(trusted_pixel_vs),.pixel_de(trusted_pixel_de),
 .overlay_rgb(trusted_overlay_rgb),.overlay_hs(trusted_overlay_hs),.overlay_vs(trusted_overlay_vs),.overlay_de(trusted_overlay_de));

// A single allocator owns the camera wire for preview and NN captures. Preview
// writes only 0x25000000/0x25800000 on HP1, never NN RAW220 or model storage.
wire[767:0]ordinary_nfr_endpoint_diag;wire[383:0]ordinary_nfr_raw_diag;wire[31:0]ordinary_nfr_route_diag;
wire[1279:0]ordinary_nfr_diag={32'd0,ordinary_nfr_route_diag,ordinary_nfr_raw_diag,ordinary_nfr_endpoint_diag,32'h00010000,32'h4e464431};
wire ordinary_nn_request_ready,ordinary_nn_owner_opened,ordinary_nn_abort;
wire ordinary_preview_quiet,ordinary_preview_fault,ordinary_allocator_exhausted;
wire[4:0] ordinary_preview_diagnostic_fault_leaves;
wire[31:0] ordinary_next_session,ordinary_next_frame,ordinary_nn_raw_crc;
wire ordinary_raw_consume_done,ordinary_packet_quiescent,ordinary_response_quiescent;
wire ordinary_preview_allowed,ordinary_nn_request,ordinary_nn_active,ordinary_nn_retired,ordinary_nn_error;
wire ordinary_nn_raw_sealed,ordinary_nn_raw_frame_ready,ordinary_nn_raw_transport_idle,ordinary_nn_raw_slot_ready;
wire ordinary_owner_close,ordinary_owner_open,ordinary_owner_purpose_nn,ordinary_owner_closed,ordinary_owner_opened;
wire[31:0] ordinary_owner_session,ordinary_owner_frame,ordinary_owner_epoch;
wire ordinary_endpoint_live,ordinary_endpoint_fault,ordinary_packet_purpose_nn;
wire[31:0] ordinary_packet_epoch;
wire ordinary_response_valid;
wire[7:0] ordinary_response_kind,ordinary_response_flags;
wire[31:0] ordinary_response_offset,ordinary_response_frame_crc,ordinary_response_session_id,ordinary_response_frame_id,ordinary_response_total_bytes;
wire[15:0] ordinary_response_width,ordinary_response_height;
wire ordinary_preview_execution_authorized;
wire ordinary_preview_root_live=ordinary_preview_execution_authorized&&v_key_valid;
wire ordinary_pending_nn_intent;
wire ordinary_flow_ack_valid;wire[351:0]ordinary_flow_ack;
wire[31:0]ordinary_flow_status,ordinary_flow_ticket;wire[319:0]ordinary_flow_expected;
ordinary_camera_preview_engine #(.CONTINUOUS_NN_PREVIEW(1)) u_ordinary_preview( .diagnostic_route(ordinary_nfr_route_diag),
 // Accepted HP1 transactions survive an authorization revoke until real B
 // completion. Revoke uses trusted_cancel; only the board reset clears state.
 .clk(pl_clk100),.rst_n(pl_reset100n),.root_live(ordinary_preview_root_live),.authorization_epoch(v_authorization_epoch),
 .trusted_cancel(!ordinary_preview_root_live),.preview_enable(ordinary_preview_allowed),
 .nn_raw_sealed(ordinary_nn_raw_sealed),.nn_raw_frame_ready(ordinary_nn_raw_frame_ready),
 .nn_pending_intent(ordinary_pending_nn_intent),
 .nn_raw_transport_idle(ordinary_nn_raw_transport_idle),.nn_raw_slot_ready(ordinary_nn_raw_slot_ready),.nn_raw_crc(ordinary_nn_raw_crc),
 .nn_raw_consume_done(ordinary_raw_consume_done),.nn_retire_pulse(),.nn_retire_failed(),
 .nn_request(ordinary_nn_request),.nn_active(ordinary_nn_active),.nn_retired(ordinary_nn_retired),.nn_error(ordinary_nn_error),
 .nn_request_ready(ordinary_nn_request_ready),.nn_owner_opened(ordinary_nn_owner_opened),.nn_abort(ordinary_nn_abort),
 .resources_quiet(ordinary_preview_quiet),.fault(ordinary_preview_fault),
 .diagnostic_fault_leaves(ordinary_preview_diagnostic_fault_leaves),
 .next_session(ordinary_next_session),.next_frame(ordinary_next_frame),.exhausted(ordinary_allocator_exhausted),
 .owner_close(ordinary_owner_close),.owner_open(ordinary_owner_open),.owner_purpose_nn(ordinary_owner_purpose_nn),
 .owner_session(ordinary_owner_session),.owner_frame(ordinary_owner_frame),.owner_epoch(ordinary_owner_epoch),
 .owner_closed(ordinary_owner_closed),.owner_opened(ordinary_owner_opened),
 .packet_path_quiescent(ordinary_packet_quiescent),.response_tx_quiescent(ordinary_response_quiescent),
 .endpoint_live(ordinary_endpoint_live),.endpoint_fault(ordinary_endpoint_fault),
 .packet_valid(packet_valid),.packet_header(packet_header),.packet_purpose_nn(ordinary_packet_purpose_nn),.packet_epoch(ordinary_packet_epoch),
 .packet_release(packet_release),.payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
 .response_valid(ordinary_response_valid),.response_ready(response_ready),.response_kind(ordinary_response_kind),.response_flags(ordinary_response_flags),
 .response_offset(ordinary_response_offset),.response_frame_crc(ordinary_response_frame_crc),
 .response_session_id(ordinary_response_session_id),.response_frame_id(ordinary_response_frame_id),
 .response_total_bytes(ordinary_response_total_bytes),.response_width(ordinary_response_width),.response_height(ordinary_response_height),
 .nn_packet_valid(v_packet_valid),.nn_packet_header(v_packet_header),.nn_packet_release(v_packet_release),
 .nn_payload_read(v_payload_read),.nn_payload_address(v_payload_address),.nn_payload_data(v_payload_data),.nn_payload_read_valid(v_payload_read_valid),
 .nn_response_valid(v_response_valid),.nn_response_ready(v_response_ready),.nn_response_kind(v_response_kind),.nn_response_flags(v_response_flags),
 .nn_response_offset(v_response_offset),.nn_response_frame_crc(v_response_frame_crc),
 .nn_response_session_id(v_response_session_id),.nn_response_frame_id(v_response_frame_id),
 .nn_response_total_bytes(v_response_total_bytes),.nn_response_width(v_response_width),.nn_response_height(v_response_height),
 .s_axi_awaddr(ordinary_page_awaddr-12'h800),.s_axi_araddr(ordinary_page_araddr-12'h800),
 .s_axi_awvalid(ordinary_page_awvalid[1]),.s_axi_wvalid(ordinary_page_wvalid[1]),.s_axi_bready(ordinary_page_bready[1]),
 .s_axi_arvalid(ordinary_page_arvalid[1]),.s_axi_rready(ordinary_page_rready[1]),.s_axi_wdata(ordinary_page_wdata),.s_axi_wstrb(ordinary_page_wstrb),
 .s_axi_awready(ordinary_page_awready[1]),.s_axi_wready(ordinary_page_wready[1]),.s_axi_arready(ordinary_page_arready[1]),
 .s_axi_bvalid(ordinary_page_bvalid[1]),.s_axi_rvalid(ordinary_page_rvalid[1]),.s_axi_bresp(ordinary_page_bresp[3:2]),
 .s_axi_rresp(ordinary_page_rresp[3:2]),.s_axi_rdata(ordinary_page_rdata[63:32]),
 .hdmi_ack_seq(ordinary_hdmi_ack_seq),.hdmi_active_base(ordinary_hdmi_active_base),.hdmi_frames(ordinary_hdmi_frames),.hdmi_healthy(ordinary_hdmi_healthy),
 .m_awaddr(S_HDMI_AXI_awaddr),.m_awlen(S_HDMI_AXI_awlen),.m_awsize(S_HDMI_AXI_awsize),.m_awburst(S_HDMI_AXI_awburst),
 .m_awvalid(S_HDMI_AXI_awvalid),.m_awready(S_HDMI_AXI_awready),.m_wdata(S_HDMI_AXI_wdata),.m_wstrb(S_HDMI_AXI_wstrb),
 .m_wlast(S_HDMI_AXI_wlast),.m_wvalid(S_HDMI_AXI_wvalid),.m_wready(S_HDMI_AXI_wready),.m_bresp(S_HDMI_AXI_bresp),
 .m_bvalid(S_HDMI_AXI_bvalid),.m_bready(S_HDMI_AXI_bready),
 .completed_pulse(),.completed_bank(),.completed_sequence(),.completed_base(),.completed_session(),.completed_frame(),.completed_epoch(),.completed_bytes(),.completed_crc());
assign transport_tx_quiescent=ordinary_response_quiescent;
nfr_owned_native_endpoint #(.REGISTERED_CHANNEL_LIVE(1)) u_frames( .diagnostic_words(ordinary_nfr_endpoint_diag),
 .owner_close(ordinary_owner_close),.owner_open(ordinary_owner_open),.owner_purpose_nn(ordinary_owner_purpose_nn),
 .owner_session(ordinary_owner_session),.owner_frame(ordinary_owner_frame),.owner_epoch(ordinary_owner_epoch),
 .owner_closed(ordinary_owner_closed),.owner_opened(ordinary_owner_opened),.packet_quiescent(ordinary_packet_quiescent),
 .channel_live(ordinary_endpoint_live),.response_quiescent(ordinary_response_quiescent),.response_fault(ordinary_endpoint_fault),
 .packet_purpose_nn(ordinary_packet_purpose_nn),.packet_epoch(ordinary_packet_epoch),
 .received_packets(),.bad_packets(),.busy_drops(),.foreign_drops(),.clk(pl_clk100),.rst_n(pl_reset100n),
 .rx_clk(frame_rx_clk),.rx_reset(frame_rx_reset),.rx_data(frame_rx_data),.rx_valid(frame_rx_valid),.rx_last(frame_rx_last),.rx_bad(frame_rx_bad),
 .tx_clk(frame_tx_clk),.tx_reset(frame_tx_reset),.tx_data(control_tx_data),.tx_valid(control_tx_valid),.tx_last(control_tx_last),.tx_ready(control_tx_ready),
 .packet_valid(packet_valid),.packet_header(packet_header),.packet_release(packet_release),
 .payload_read(payload_read),.payload_address(payload_address),.payload_data(payload_data),.payload_read_valid(payload_read_valid),
 .response_valid(ordinary_response_valid),.response_ready(response_ready),.response_kind(ordinary_response_kind),.response_flags(ordinary_response_flags),
 .response_offset(ordinary_response_offset),.response_frame_crc(ordinary_response_frame_crc),.response_session_id(ordinary_response_session_id),
 .response_frame_id(ordinary_response_frame_id),.response_total_bytes(ordinary_response_total_bytes),.response_width(ordinary_response_width),.response_height(ordinary_response_height));

wire[223:0]v_camera_first_cause;
wire [4223:0] authenticated_snapshot={v_next_capture_status,v_authorization_epoch,v_next_capture_frame,v_next_capture_session,v_audio_post_pcm_cycles[63:32],v_audio_post_pcm_cycles[31:0],32'h41565033,report_sequence,v_audio_sequence,v_audio_total_cycles[63:32],v_audio_total_cycles[31:0],128'd0,v_camera_first_cause,v_audio_record_score,{21'd0,(v_audio_record_visible&&!v_audio_active),v_audio_fault,v_audio_active,v_audio_record_visible,v_audio_record_class},v_audio_record_context[256+:32],v_audio_record_context[224+:32],v_audio_record_context[192+:32],v_audio_record_context[160+:32],v_audio_record_context[128+:32],v_audio_record_context[96+:32],v_audio_record_context[64+:32],v_audio_record_context[32+:32],v_audio_record_context[0+:32],{12'd0,v_record_indices[51:32]},v_record_indices[31:0],v_metrics_head[224+:32],v_metrics_head[192+:32],v_metrics_head[160+:32],v_metrics_head[128+:32],v_metrics_head[96+:32],v_metrics_head[64+:32],v_metrics_head[32+:32],v_metrics_head[0+:32],v_metrics_nn[224+:32],v_metrics_nn[192+:32],v_metrics_nn[160+:32],v_metrics_nn[128+:32],v_metrics_nn[96+:32],v_metrics_nn[64+:32],v_metrics_nn[32+:32],v_metrics_nn[0+:32],v_metrics_frontend[224+:32],v_metrics_frontend[192+:32],v_metrics_frontend[160+:32],v_metrics_frontend[128+:32],v_metrics_frontend[96+:32],v_metrics_frontend[64+:32],v_metrics_frontend[32+:32],v_metrics_frontend[0+:32],v_frame_elapsed_cycles[63:32],v_frame_elapsed_cycles[31:0],v_metrics_pool_wait[63:32],v_metrics_pool_wait[31:0],v_metrics_mac_busy[63:32],v_metrics_mac_busy[31:0],v_metrics_page_input_wait[63:32],v_metrics_page_input_wait[31:0],v_metrics_yolo[63:32],v_metrics_yolo[31:0],v_metrics_ingress[63:32],v_metrics_ingress[31:0],v_metrics_total[63:32],v_metrics_total[31:0],v_metrics_sequence,{28'd0,v_metrics_roi_measured},v_record_rois[864+:32],v_record_rois[832+:32],v_record_rois[800+:32],v_record_rois[768+:32],v_record_rois[736+:32],v_record_rois[704+:32],v_record_rois[672+:32],v_record_rois[640+:32],v_record_rois[608+:32],v_record_rois[576+:32],v_record_rois[544+:32],v_record_rois[512+:32],v_record_rois[480+:32],v_record_rois[448+:32],v_record_rois[416+:32],v_record_rois[384+:32],v_record_rois[352+:32],v_record_rois[320+:32],v_record_rois[288+:32],v_record_rois[256+:32],v_record_rois[224+:32],v_record_rois[192+:32],v_record_rois[160+:32],v_record_rois[128+:32],v_record_rois[96+:32],v_record_rois[64+:32],v_record_rois[32+:32],v_record_rois[0+:32],v_record_results[480+:32],v_record_results[448+:32],v_record_results[416+:32],v_record_results[384+:32],v_record_results[352+:32],v_record_results[320+:32],v_record_results[288+:32],v_record_results[256+:32],v_record_results[224+:32],v_record_results[192+:32],v_record_results[160+:32],v_record_results[128+:32],v_record_results[96+:32],v_record_results[64+:32],v_record_results[32+:32],v_record_results[0+:32],v_record_key_session[96+:32],v_record_key_session[64+:32],v_record_key_session[32+:32],v_record_key_session[0+:32],{29'd0,v_record_count},v_record_epoch,v_record_frame,v_record_session,v_record_camera,v_model_epoch,v_authorization_epoch,{23'd0,v_metrics_fault,v_metrics_valid,v_record_visible,v_key_valid,v_authorized,v_fault,v_quiescent,v_active,1'b0},32'h46505332};
trusted_ps_snapshot_axil #(.ENABLE_ORDINARY_FLOW(ENABLE_ORDINARY_AUTORUN),.SNAPSHOT_WORDS(132),.DIAGNOSTIC_WORDS(40)) u_ps_readonly(.diagnostic_words_flat(ordinary_nfr_diag),.clk(pl_clk100),.security_reset_n(v_security_reset_n),.snapshot_words_flat(authenticated_snapshot),
.flow_status(ordinary_flow_status),.flow_ticket(ordinary_flow_ticket),.flow_expected(ordinary_flow_expected),.flow_ack_valid(ordinary_flow_ack_valid),.flow_ack(ordinary_flow_ack),.blocked_writes(),.interface_quiescent(compute_ps_quiet),
.s_axi_awaddr(M_NPU_CTRL_awaddr[11:0]),
.s_axi_awvalid(M_NPU_CTRL_awvalid),
.s_axi_awready(M_NPU_CTRL_awready),
.s_axi_wdata(M_NPU_CTRL_wdata),
.s_axi_wstrb(M_NPU_CTRL_wstrb),
.s_axi_wvalid(M_NPU_CTRL_wvalid),
.s_axi_wready(M_NPU_CTRL_wready),
.s_axi_bresp(M_NPU_CTRL_bresp),
.s_axi_bvalid(M_NPU_CTRL_bvalid),
.s_axi_bready(M_NPU_CTRL_bready),
.s_axi_araddr(M_NPU_CTRL_araddr[11:0]),
.s_axi_arvalid(M_NPU_CTRL_arvalid),
.s_axi_arready(M_NPU_CTRL_arready),
.s_axi_rdata(M_NPU_CTRL_rdata),
.s_axi_rresp(M_NPU_CTRL_rresp),
.s_axi_rvalid(M_NPU_CTRL_rvalid),
.s_axi_rready(M_NPU_CTRL_rready));
// The unique AV system contains its own actual ingress/vision/audio DDR arbiter.
assign av_owner=1;assign av_fault=0;assign av_match=1;assign av_quiet=v_quiescent;
assign v_clk=pl_clk100;
assign v_trusted_por_n=sys_rst_n;
assign v_clock_locked=pl_locked;
assign v_ps_reset_n=FCLK_RESET0_N&&!outputs_fault;
assign v_external_memory_available=outputs_ready;
assign v_external_resources_quiescent=audio_ps_quiet&&compute_ps_quiet&&transport_tx_quiescent&&outputs_quiet&&replay_offer_interface_quiet;
assign v_debug_command=debug_command;
assign v_debug_resume_epoch=debug_resume_epoch;
assign v_debug_key=debug_key;
assign v_debug_session_id=debug_session_id;
assign v_debug_key_fingerprint=debug_key_fingerprint;
assign v_PS_AWADDR=M_SLH_CTRL_awaddr[11:0];
assign v_PS_ARADDR=M_SLH_CTRL_araddr[11:0];
assign v_PS_AWVALID=M_SLH_CTRL_awvalid;
assign v_PS_WVALID=M_SLH_CTRL_wvalid;
assign v_PS_BREADY=M_SLH_CTRL_bready;
assign v_PS_ARVALID=M_SLH_CTRL_arvalid;
assign v_PS_RREADY=M_SLH_CTRL_rready;
assign v_PS_WDATA=M_SLH_CTRL_wdata;
assign v_PS_WSTRB=M_SLH_CTRL_wstrb;














npu_full_pool_sm4_av_system #(.ENABLE_MIC_RAW_DIAGNOSTICS(ENABLE_MIC_RAW_DIAGNOSTICS),.ENABLE_PS_NORMAL_TASK_REQUEST(ENABLE_PS_NORMAL_TASK_REQUEST),.ENABLE_FIRST_OBSERVED_FAULT_DIAGNOSTIC(ENABLE_FIRST_OBSERVED_FAULT_DIAGNOSTIC),.ENABLE_PHYSICAL_MIC(ENABLE_PHYSICAL_MIC),.ENABLE_ORDINARY_AUTORUN(ENABLE_ORDINARY_AUTORUN),.ENABLE_ORDINARY_SLOT_REPLAY(ENABLE_ORDINARY_SLOT_REPLAY),.PIPELINED_TRUSTED_CONTROL(1),.ENABLE_ORDINARY_PREVIEW(1),.AUDIO_PARALLEL_CLOCK(1),.CLOSED_OUTPUT_FAULT_COFACTOR(1),.FRONTEND_JOB_TIMEOUT_CYCLES(32'd3000000000),.FRAME_JOB_TIMEOUT_CYCLES(64'd16000000000),.PROPAGATE_FRONTEND_CANCEL(1)) u_system( .observation_raw_diagnostic_words(ordinary_nfr_raw_diag),
 .normal_request_valid(normal_request_valid),.normal_request_command(normal_request_command),.normal_request_epoch(normal_request_epoch),.normal_request_model(normal_request_model),.normal_request_strobes(normal_request_strobes),.normal_request_error(normal_request_error),.normal_result_word(normal_result_word),.normal_status_word(normal_status_word),.normal_witness_words(normal_witness_words),
 .mic_sd(mic_sd),.mic_bclk(mic_bclk),.mic_ws(mic_ws),.mic_raw_diagnostic_words(mic_raw_diagnostic_words),

 .replay_offer_valid(replay_offer_valid),.replay_offer_ready(replay_offer_ready),.replay_offer_slot(replay_offer_slot),.replay_offer_generation(replay_offer_generation),.replay_offer_batch(replay_offer_batch),
 .replay_offer_held(replay_offer_held),.replay_offer_cache_clean(replay_offer_cache_clean),.replay_offer_expected_model(replay_offer_expected_model),.replay_offer_cancel(replay_offer_cancel),
 .replay_receipt_ack(replay_receipt_ack),.replay_receipt_ack_token(replay_receipt_ack_token),.replay_busy(replay_busy),.replay_active(replay_active),.replay_receipt_valid(replay_receipt_valid),.replay_receipt_failed(replay_receipt_failed),.replay_exhausted(replay_exhausted),.replay_receipt_error(replay_receipt_error),
 .replay_selected_slot(replay_selected_slot),.replay_selected_generation(replay_selected_generation),.replay_selected_batch(replay_selected_batch),.replay_token(replay_token),
 .replay_exec_session(replay_exec_session),.replay_exec_frame(replay_exec_frame),.replay_exec_epoch(replay_exec_epoch),.replay_exec_model(replay_exec_model),.replay_exec_key(replay_exec_key),

 .ordinary_nn_request_ready(ordinary_nn_request_ready),.ordinary_nn_owner_opened(ordinary_nn_owner_opened),.ordinary_nn_abort(ordinary_nn_abort),
 .ordinary_preview_quiet(ordinary_preview_quiet),.ordinary_preview_fault(ordinary_preview_fault),
 .ordinary_preview_diagnostic_fault_leaves(ordinary_preview_diagnostic_fault_leaves),
 .ordinary_next_session(ordinary_next_session),.ordinary_next_frame(ordinary_next_frame),.ordinary_allocator_exhausted(ordinary_allocator_exhausted),
 .ordinary_raw_consume_done(ordinary_raw_consume_done),.ordinary_packet_quiescent(ordinary_packet_quiescent),.ordinary_response_quiescent(ordinary_response_quiescent),
 .ordinary_preview_allowed(ordinary_preview_allowed),.ordinary_nn_request(ordinary_nn_request),.ordinary_nn_active(ordinary_nn_active),
 .ordinary_nn_retired(ordinary_nn_retired),.ordinary_nn_error(ordinary_nn_error),.ordinary_nn_raw_sealed(ordinary_nn_raw_sealed),
 .ordinary_nn_raw_frame_ready(ordinary_nn_raw_frame_ready),.ordinary_nn_raw_transport_idle(ordinary_nn_raw_transport_idle),
 .ordinary_flow_ack_valid(ordinary_flow_ack_valid),.ordinary_flow_ack(ordinary_flow_ack),
 .ordinary_physical_output_quiet(transport_tx_quiescent&&outputs_quiet),
 .ordinary_flow_status(ordinary_flow_status),.ordinary_flow_ticket(ordinary_flow_ticket),.ordinary_flow_expected(ordinary_flow_expected),.ordinary_pending_nn_intent(ordinary_pending_nn_intent),
 .ordinary_nn_raw_slot_ready(ordinary_nn_raw_slot_ready),.ordinary_nn_raw_crc(ordinary_nn_raw_crc),
.outputs_fault_for_cofactor(outputs_fault),.ps_reset_f0_for_cofactor(FCLK_RESET0_N&&!1'b0),.execution_authorized_probe(ordinary_preview_execution_authorized),
.trusted_audio_raw_clk(pl_raw100),
.observation_camera_first_cause(v_camera_first_cause),
.observation_next_capture_session(v_next_capture_session),.observation_next_capture_frame(v_next_capture_frame),.observation_next_capture_status(v_next_capture_status),
.audio_record_commit(v_audio_record_commit),.audio_record_visible(v_audio_record_visible),.audio_record_context(v_audio_record_context),.audio_record_class(v_audio_record_class),.audio_record_score(v_audio_record_score),.audio_job_accepted(v_audio_job_accepted),.audio_active(v_audio_active),.audio_quiescent(v_audio_quiescent),.audio_fault(v_audio_fault),.audio_phase(v_audio_phase),.audio_total_cycles(v_audio_total_cycles),.audio_post_pcm_cycles(v_audio_post_pcm_cycles),.audio_sequence(v_audio_sequence),
.clk(v_clk),
.trusted_por_n(v_trusted_por_n),
.clock_locked(v_clock_locked),
.ps_reset_n(v_ps_reset_n),
.external_memory_available(v_external_memory_available),
.external_resources_quiescent(v_external_resources_quiescent),
.debug_command(v_debug_command),
.debug_resume_epoch(v_debug_resume_epoch),
.debug_key(v_debug_key),
.debug_session_id(v_debug_session_id),
.debug_key_fingerprint(v_debug_key_fingerprint),
.ack_word(v_ack_word),
.status_word(v_status_word),
.last_sequence_word(v_last_sequence_word),
.security_reset_n(v_security_reset_n),
.arith_reset_n(v_arith_reset_n),
.authorized(v_authorized),
.key_valid(v_key_valid),
.active(v_active),
.quiescent(v_quiescent),
.fault(v_fault),
.job_done(v_job_done),
.authorization_epoch(v_authorization_epoch),
.model_epoch(v_model_epoch),
.key_session_id(v_key_session_id),
.raw_model_authorized(v_raw_model_authorized),
.model_lease_valid(v_model_lease_valid),
.PS_AWADDR(v_PS_AWADDR),
.PS_ARADDR(v_PS_ARADDR),
.PS_AWVALID(v_PS_AWVALID),
.PS_WVALID(v_PS_WVALID),
.PS_BREADY(v_PS_BREADY),
.PS_ARVALID(v_PS_ARVALID),
.PS_RREADY(v_PS_RREADY),
.PS_WDATA(v_PS_WDATA),
.PS_WSTRB(v_PS_WSTRB),
.PS_AWREADY(v_PS_AWREADY),
.PS_WREADY(v_PS_WREADY),
.PS_BVALID(v_PS_BVALID),
.PS_ARREADY(v_PS_ARREADY),
.PS_RVALID(v_PS_RVALID),
.PS_BRESP(v_PS_BRESP),
.PS_RRESP(v_PS_RRESP),
.PS_RDATA(v_PS_RDATA),
.packet_valid(v_packet_valid),
.packet_header(v_packet_header),
.packet_release(v_packet_release),
.payload_read(v_payload_read),
.payload_address(v_payload_address),
.payload_data(v_payload_data),
.payload_read_valid(v_payload_read_valid),
.response_valid(v_response_valid),
.response_ready(v_response_ready),
.response_kind(v_response_kind),
.response_flags(v_response_flags),
.response_offset(v_response_offset),
.response_frame_crc(v_response_frame_crc),
.response_session_id(v_response_session_id),
.response_frame_id(v_response_frame_id),
.response_total_bytes(v_response_total_bytes),
.response_width(v_response_width),
.response_height(v_response_height),
.completed_frames(v_completed_frames),
.rejected_completions(v_rejected_completions),
.committed_offset(v_committed_offset),
.received_crc(v_received_crc),
.observation_frame_start(v_observation_frame_start),
.observation_ingress_done(v_observation_ingress_done),
.observation_page_accept(v_observation_page_accept),
.observation_page_input_wait(v_observation_page_input_wait),
.observation_page_index(v_observation_page_index),
.observation_model_address(v_observation_model_address),
.observation_proof_address(v_observation_proof_address),
.service_committed_owner(v_service_committed_owner),
.hp_committed_owner(v_hp_committed_owner),
.metrics_valid(v_metrics_valid),
.metrics_fault(v_metrics_fault),
.metrics_total(v_metrics_total),
.metrics_ingress(v_metrics_ingress),
.metrics_yolo(v_metrics_yolo),
.metrics_frontend(v_metrics_frontend),
.metrics_nn(v_metrics_nn),
.metrics_head(v_metrics_head),
.metrics_page_input_wait(v_metrics_page_input_wait),
.metrics_mac_busy(v_metrics_mac_busy),
.metrics_pool_wait(v_metrics_pool_wait),
.metrics_roi_measured(v_metrics_roi_measured),
.metrics_sequence(v_metrics_sequence),
.frame_elapsed_cycles(v_frame_elapsed_cycles),
.record_visible(v_record_visible),
.record_commit_pulse(v_record_commit_pulse),
.record_camera(v_record_camera),
.record_session(v_record_session),
.record_frame(v_record_frame),
.record_epoch(v_record_epoch),
.record_key_session(v_record_key_session),
.record_count(v_record_count),
.record_rois(v_record_rois),
.record_indices(v_record_indices),
.record_results(v_record_results),
.observation_pool_wait(v_observation_pool_wait),
.observation_yolo_start(v_observation_yolo_start),
.observation_yolo_done(v_observation_yolo_done),
.observation_frontend_start(v_observation_frontend_start),
.observation_nn_start(v_observation_nn_start),
.observation_nn_done(v_observation_nn_done),
.observation_head_start(v_observation_head_start),
.observation_roi_index(v_observation_roi_index),
.observation_generation(v_observation_generation),
.observation_block(v_observation_block),
.observation_norm3_valid(v_observation_norm3_valid),
.observation_norm3_done(v_observation_norm3_done),
.observation_norm3_address(v_observation_norm3_address),
.observation_norm3_data(v_observation_norm3_data),
.observation_logit_valid(v_observation_logit_valid),
.observation_logit_class(v_observation_logit_class),
.observation_logit_data(v_observation_logit_data),
.observation_result_valid(v_observation_result_valid),
.observation_result_class(v_observation_result_class),
.observation_result_logit(v_observation_result_logit),
.observation_consumer_session(v_observation_consumer_session),
.observation_consumer_frame(v_observation_consumer_frame),
.observation_consumer_epoch(v_observation_consumer_epoch),
.observation_context_camera(v_observation_context_camera),
.observation_context_session(v_observation_context_session),
.observation_context_frame(v_observation_context_frame),
.observation_context_epoch(v_observation_context_epoch),
.M_AXI_ARADDR(v_M_AXI_ARADDR),
.M_AXI_ARLEN(v_M_AXI_ARLEN),
.M_AXI_ARSIZE(v_M_AXI_ARSIZE),
.M_AXI_ARBURST(v_M_AXI_ARBURST),
.M_AXI_ARVALID(v_M_AXI_ARVALID),
.M_AXI_ARREADY(v_M_AXI_ARREADY),
.M_AXI_RDATA(v_M_AXI_RDATA),
.M_AXI_RRESP(v_M_AXI_RRESP),
.M_AXI_RLAST(v_M_AXI_RLAST),
.M_AXI_RVALID(v_M_AXI_RVALID),
.M_AXI_RREADY(v_M_AXI_RREADY),
.M_AXI_AWADDR(v_M_AXI_AWADDR),
.M_AXI_AWLEN(v_M_AXI_AWLEN),
.M_AXI_AWSIZE(v_M_AXI_AWSIZE),
.M_AXI_AWBURST(v_M_AXI_AWBURST),
.M_AXI_AWVALID(v_M_AXI_AWVALID),
.M_AXI_AWREADY(v_M_AXI_AWREADY),
.M_AXI_WDATA(v_M_AXI_WDATA),
.M_AXI_WSTRB(v_M_AXI_WSTRB),
.M_AXI_WLAST(v_M_AXI_WLAST),
.M_AXI_WVALID(v_M_AXI_WVALID),
.M_AXI_WREADY(v_M_AXI_WREADY),
.M_AXI_BRESP(v_M_AXI_BRESP),
.M_AXI_BVALID(v_M_AXI_BVALID),
.M_AXI_BREADY(v_M_AXI_BREADY));
assign S_NPU_AXI_araddr=v_M_AXI_ARADDR;
assign S_NPU_AXI_arlen=v_M_AXI_ARLEN;
assign S_NPU_AXI_arsize=v_M_AXI_ARSIZE;
assign S_NPU_AXI_arburst=v_M_AXI_ARBURST;
assign S_NPU_AXI_arvalid=v_M_AXI_ARVALID;
assign v_M_AXI_ARREADY=S_NPU_AXI_arready;
assign v_M_AXI_RDATA=S_NPU_AXI_rdata;
assign v_M_AXI_RRESP=S_NPU_AXI_rresp;
assign v_M_AXI_RLAST=S_NPU_AXI_rlast;
assign v_M_AXI_RVALID=S_NPU_AXI_rvalid;
assign S_NPU_AXI_rready=v_M_AXI_RREADY;
assign S_NPU_AXI_awaddr=v_M_AXI_AWADDR;
assign S_NPU_AXI_awlen=v_M_AXI_AWLEN;
assign S_NPU_AXI_awsize=v_M_AXI_AWSIZE;
assign S_NPU_AXI_awburst=v_M_AXI_AWBURST;
assign S_NPU_AXI_awvalid=v_M_AXI_AWVALID;
assign v_M_AXI_AWREADY=S_NPU_AXI_awready;
assign S_NPU_AXI_wdata=v_M_AXI_WDATA;
assign S_NPU_AXI_wstrb=v_M_AXI_WSTRB;
assign S_NPU_AXI_wlast=v_M_AXI_WLAST;
assign S_NPU_AXI_wvalid=v_M_AXI_WVALID;
assign v_M_AXI_WREADY=S_NPU_AXI_wready;
assign v_M_AXI_BRESP=S_NPU_AXI_bresp;
assign v_M_AXI_BVALID=S_NPU_AXI_bvalid;
assign S_NPU_AXI_bready=v_M_AXI_BREADY;
// Former PS audio control alias is read-only status, never trusted PCM/GO.
trusted_ps_snapshot_axil #(.ADDR_WIDTH(21),.SNAPSHOT_WORDS(132)) u_audio_readonly(
.clk(pl_clk100),.security_reset_n(v_security_reset_n),.snapshot_words_flat(authenticated_snapshot),.blocked_writes(),.interface_quiescent(audio_ps_quiet),
.s_axi_awaddr(M_AUDIO_CTRL_awaddr[20:0]),.s_axi_awvalid(M_AUDIO_CTRL_awvalid),.s_axi_awready(M_AUDIO_CTRL_awready),
.s_axi_wdata(M_AUDIO_CTRL_wdata),.s_axi_wstrb(M_AUDIO_CTRL_wstrb),.s_axi_wvalid(M_AUDIO_CTRL_wvalid),.s_axi_wready(M_AUDIO_CTRL_wready),
.s_axi_bresp(M_AUDIO_CTRL_bresp),.s_axi_bvalid(M_AUDIO_CTRL_bvalid),.s_axi_bready(M_AUDIO_CTRL_bready),
.s_axi_araddr(M_AUDIO_CTRL_araddr[20:0]),.s_axi_arvalid(M_AUDIO_CTRL_arvalid),.s_axi_arready(M_AUDIO_CTRL_arready),
.s_axi_rdata(M_AUDIO_CTRL_rdata),.s_axi_rresp(M_AUDIO_CTRL_rresp),.s_axi_rvalid(M_AUDIO_CTRL_rvalid),.s_axi_rready(M_AUDIO_CTRL_rready));
endmodule
