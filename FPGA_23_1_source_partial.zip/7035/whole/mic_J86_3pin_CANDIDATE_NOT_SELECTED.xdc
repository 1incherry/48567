# FILE-ONLY CANDIDATE. Not added to current R10, not implemented-pin or IO-timing qualification.
# Root photo confirms J86 silk AC18/AC19/AD18/AD19/GND/PWR order; actual connected/powered state still unknown.
# Select only after root authorizes a NEW microphone PL project and confirms the physical connection.
set_property PACKAGE_PIN AC18 [get_ports mic_bclk]
set_property PACKAGE_PIN AC19 [get_ports mic_ws]
set_property PACKAGE_PIN AD18 [get_ports mic_sd]
set_property IOSTANDARD LVCMOS33 [get_ports {mic_bclk mic_ws mic_sd}]
# AD19 intentionally has no port. No input-delay/falsepath/multicycle exception invented here.
# External SD-return timing must be supplied from the actual module/board contract before final timing qualification.
