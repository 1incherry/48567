# Independent future candidate only; never added to the current R11 project.
# Board schematic Rev0.5: J86p4 -> AD19, Bank9 VCCO_9=3.3V; J86p5=GND.
set_property PACKAGE_PIN AD19 [get_ports c3_en_n]
set_property IOSTANDARD LVCMOS33 [get_ports c3_en_n]
set_property PULLDOWN false [get_ports c3_en_n]
set_property PULLUP false [get_ports c3_en_n]
# No invented external timing, broad clock cut, or security/reset exception.
